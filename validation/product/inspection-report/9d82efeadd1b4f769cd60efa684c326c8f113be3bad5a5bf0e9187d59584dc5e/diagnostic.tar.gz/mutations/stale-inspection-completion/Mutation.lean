import Uorc.Uorc.Product.InspectionReportScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !InspectionReportScenarios.staleCompletionControl then
  IO.println "FAIL staleCompletionControl"
  throw (IO.userError "planted product defect rejected")
 IO.println "UNEXPECTED ACCEPTANCE"
