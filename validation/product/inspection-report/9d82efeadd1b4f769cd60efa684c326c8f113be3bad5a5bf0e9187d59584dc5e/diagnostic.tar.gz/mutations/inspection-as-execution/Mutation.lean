import Uorc.Uorc.Product.InspectionReportScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !InspectionReportScenarios.executionPromotionControl then
  IO.println "FAIL executionPromotionControl"
  throw (IO.userError "planted product defect rejected")
 IO.println "UNEXPECTED ACCEPTANCE"
