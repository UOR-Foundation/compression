import Uorc.Uorc.Product.InspectionReportScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !InspectionReportScenarios.staleTakeControl then
  IO.println "FAIL staleTakeControl"
  throw (IO.userError "planted product defect rejected")
 IO.println "UNEXPECTED ACCEPTANCE"
