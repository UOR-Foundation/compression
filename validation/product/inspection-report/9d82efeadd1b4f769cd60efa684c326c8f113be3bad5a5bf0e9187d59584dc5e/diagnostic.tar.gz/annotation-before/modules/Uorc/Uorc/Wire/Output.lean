module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeValue
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Wire.Output

public inductive Mode where
  | measure
  | stream

public inductive Event where
  | byte (_ : UInt8)
  | borrowedSpan (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : UInt64) (_ : UInt64)
  | «end»

public inductive Ack where
  | consumed
  | takeSpan

public structure Digit where
  byte : UInt8
  remaining : UInt64
  finished : Bool

@[expose] public def byteWord (value : UInt8) : UInt64 := (match (LexLeanRuntime.checkedConvert (value) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some nLocal1 => nLocal1)

@[expose] public def digit (value : UInt64) : Digit := (let lowLocal2 : UInt64 := (LexLeanRuntime.bitAnd (value) ((127 : UInt64)) : UInt64); (let finishedLocal3 : Bool := Uorc.Uorc.Core.Heap.less (value) ((128 : UInt64)); ({ byte := (match (LexLeanRuntime.checkedConvert ((if finishedLocal3 then lowLocal2 else Uorc.Uorc.Core.Heap.wordAdd (lowLocal2) ((128 : UInt64)))) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some byteLocal4 => byteLocal4), remaining := (match (LexLeanRuntime.shiftRight (value) ((7 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some remainingLocal5 => remainingLocal5), finished := finishedLocal3 } : Digit)))

@[expose] public def length (event : Event) : UInt64 := (match event with | Event.byte _ => (1 : UInt64) | Event.borrowedSpan _ _ lengthLocal9 => lengthLocal9 | Event.«end» => (0 : UInt64))

@[expose] public def spanImage (event : Event) : Uorc.Uorc.Core.RuntimeValue.Handle := (match event with | Event.byte _ => Uorc.Uorc.Core.RuntimeValue.nullHandle | Event.borrowedSpan imageLocal11 _ _ => imageLocal11 | Event.«end» => Uorc.Uorc.Core.RuntimeValue.nullHandle)

end Uorc.Uorc.Wire.Output
