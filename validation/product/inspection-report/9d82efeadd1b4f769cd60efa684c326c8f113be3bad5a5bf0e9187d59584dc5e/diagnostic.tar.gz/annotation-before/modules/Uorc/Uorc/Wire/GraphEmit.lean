module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Bytes
public import Uorc.Uorc.Core.Graph
public import Uorc.Uorc.Core.Types
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Wire.GraphEmit

public inductive EmitError where
  | invalidQuantum
  | invalidByte
  | invalidRope

public inductive Task where
  | byte (_ : Nat)
  | number (_ : Nat)
  | rope (_ : Uorc.Uorc.Core.Bytes.Cursor) (_ : Nat)
  | types (_ : List (Uorc.Uorc.Core.Types.ValueType))
  | countTypes (_ : List (Uorc.Uorc.Core.Types.ValueType)) (_ : List (Uorc.Uorc.Core.Types.ValueType)) (_ : Nat)
  | references (_ : List (Nat))
  | countReferences (_ : List (Nat)) (_ : List (Nat)) (_ : Nat)
  | instructions (_ : List (Uorc.Uorc.Core.Graph.Instruction))
  | countInstructions (_ : List (Uorc.Uorc.Core.Graph.Instruction)) (_ : List (Uorc.Uorc.Core.Graph.Instruction)) (_ : Nat)
  | blocks (_ : List (Uorc.Uorc.Core.Graph.Block))
  | countBlocks (_ : List (Uorc.Uorc.Core.Graph.Block)) (_ : List (Uorc.Uorc.Core.Graph.Block)) (_ : Nat)
  | instruction (_ : Uorc.Uorc.Core.Graph.Instruction)
  | block (_ : Uorc.Uorc.Core.Graph.Block)

public structure State where
  pending : List (Task)
  position : Nat
  work : Nat

public inductive Event where
  | advanced (_ : State)
  | produced (_ : ByteArray) (_ : State)
  | complete (_ : Nat) (_ : Nat)
  | failed (_ : EmitError) (_ : Nat) (_ : Nat)

@[expose] public def typeCode (value : Uorc.Uorc.Core.Types.ValueType) : Nat := (match value with | Uorc.Uorc.Core.Types.ValueType.natural => 0 | Uorc.Uorc.Core.Types.ValueType.byte => 1 | Uorc.Uorc.Core.Types.ValueType.predicate => 2 | Uorc.Uorc.Core.Types.ValueType.sequence => 3 | Uorc.Uorc.Core.Types.ValueType.store => 4)

@[expose] public def instructionTasks (value : Uorc.Uorc.Core.Graph.Instruction) : List (Task) := (match value with | Uorc.Uorc.Core.Graph.Instruction.naturalConstant x0 => (Task.byte (0) :: (Task.number (Uorc.Uorc.Core.Types.wordToNat (x0)) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.byteConstant x0 => (Task.byte (1) :: (Task.byte ((let __widen0 : UInt8 := x0; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.predicateConstant x0 => (Task.byte (2) :: (Task.byte ((if x0 then 1 else 0)) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.sequenceConstant x0 => (Task.byte (3) :: (Task.number (Uorc.Uorc.Core.Bytes.length (Uorc.Uorc.Core.Bytes.fromBytes (x0))) :: (Task.rope (Uorc.Uorc.Core.Bytes.cursor (Uorc.Uorc.Core.Bytes.fromBytes (x0))) (Uorc.Uorc.Core.Bytes.length (Uorc.Uorc.Core.Bytes.fromBytes (x0))) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalAdd x0 x1 => (Task.byte (4) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalSubtract x0 x1 => (Task.byte (5) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalMultiply x0 x1 => (Task.byte (6) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalDivide x0 x1 => (Task.byte (7) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalRemainder x0 x1 => (Task.byte (8) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalAnd x0 x1 => (Task.byte (9) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalOr x0 x1 => (Task.byte (10) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalXor x0 x1 => (Task.byte (11) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalNot x0 => (Task.byte (12) :: (Task.number (x0) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.naturalShiftLeft x0 x1 => (Task.byte (13) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalShiftRight x0 x1 => (Task.byte (14) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalEqual x0 x1 => (Task.byte (15) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalLess x0 x1 => (Task.byte (16) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.byteEqual x0 x1 => (Task.byte (17) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.byteLess x0 x1 => (Task.byte (18) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.naturalToByte x0 => (Task.byte (19) :: (Task.number (x0) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.byteToNatural x0 => (Task.byte (20) :: (Task.number (x0) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.predicateNot x0 => (Task.byte (21) :: (Task.number (x0) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.predicateAnd x0 x1 => (Task.byte (22) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.predicateOr x0 x1 => (Task.byte (23) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.sequenceLength x0 => (Task.byte (24) :: (Task.number (x0) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.sequenceIndex x0 x1 => (Task.byte (25) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.sequenceSlice x0 x1 x2 => (Task.byte (26) :: (Task.number (x0) :: (Task.number (x1) :: (Task.number (x2) :: ([] : List (Task)))))) | Uorc.Uorc.Core.Graph.Instruction.sequenceConcat x0 x1 => (Task.byte (27) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.sequenceEqual x0 x1 => (Task.byte (28) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.singletonSequence x0 => (Task.byte (29) :: (Task.number (x0) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.basisGet x0 => (Task.byte (30) :: (Task.number (x0) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.storeNew x0 => (Task.byte (31) :: (Task.number (x0) :: ([] : List (Task)))) | Uorc.Uorc.Core.Graph.Instruction.storeRead x0 x1 => (Task.byte (32) :: (Task.number (x0) :: (Task.number (x1) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.storeWrite x0 x1 x2 => (Task.byte (33) :: (Task.number (x0) :: (Task.number (x1) :: (Task.number (x2) :: ([] : List (Task)))))) | Uorc.Uorc.Core.Graph.Instruction.choose x0 x1 x2 => (Task.byte (34) :: (Task.number (x0) :: (Task.number (x1) :: (Task.number (x2) :: ([] : List (Task)))))) | Uorc.Uorc.Core.Graph.Instruction.apply x0 x1 => (Task.byte (35) :: (Task.number (x0) :: (Task.countReferences (x1) (x1) (0) :: ([] : List (Task))))) | Uorc.Uorc.Core.Graph.Instruction.tabulate x0 x1 x2 => (Task.byte (36) :: (Task.number (x0) :: (Task.number (x1) :: (Task.countReferences (x2) (x2) (0) :: ([] : List (Task)))))) | Uorc.Uorc.Core.Graph.Instruction.fold x0 x1 x2 x3 => (Task.byte (37) :: (Task.number (x0) :: (Task.number (x1) :: (Task.number (x2) :: (Task.countReferences (x3) (x3) (0) :: ([] : List (Task))))))) | Uorc.Uorc.Core.Graph.Instruction.scan x0 x1 x2 x3 x4 x5 => (Task.byte (38) :: (Task.number (x0) :: (Task.number (x1) :: (Task.number (x2) :: (Task.countReferences (x3) (x3) (0) :: (Task.number (x4) :: (Task.countReferences (x5) (x5) (0) :: ([] : List (Task))))))))) | Uorc.Uorc.Core.Graph.Instruction.sequenceRopeConstant x0 => (Task.byte (3) :: (Task.number (Uorc.Uorc.Core.Bytes.length (x0)) :: (Task.rope (Uorc.Uorc.Core.Bytes.cursor (x0)) (Uorc.Uorc.Core.Bytes.length (x0)) :: ([] : List (Task))))))

@[expose] public def opcode (value : Uorc.Uorc.Core.Graph.Instruction) : Nat := (match value with | Uorc.Uorc.Core.Graph.Instruction.naturalConstant _ => 0 | Uorc.Uorc.Core.Graph.Instruction.byteConstant _ => 1 | Uorc.Uorc.Core.Graph.Instruction.predicateConstant _ => 2 | Uorc.Uorc.Core.Graph.Instruction.sequenceConstant _ => 3 | Uorc.Uorc.Core.Graph.Instruction.naturalAdd _ _ => 4 | Uorc.Uorc.Core.Graph.Instruction.naturalSubtract _ _ => 5 | Uorc.Uorc.Core.Graph.Instruction.naturalMultiply _ _ => 6 | Uorc.Uorc.Core.Graph.Instruction.naturalDivide _ _ => 7 | Uorc.Uorc.Core.Graph.Instruction.naturalRemainder _ _ => 8 | Uorc.Uorc.Core.Graph.Instruction.naturalAnd _ _ => 9 | Uorc.Uorc.Core.Graph.Instruction.naturalOr _ _ => 10 | Uorc.Uorc.Core.Graph.Instruction.naturalXor _ _ => 11 | Uorc.Uorc.Core.Graph.Instruction.naturalNot _ => 12 | Uorc.Uorc.Core.Graph.Instruction.naturalShiftLeft _ _ => 13 | Uorc.Uorc.Core.Graph.Instruction.naturalShiftRight _ _ => 14 | Uorc.Uorc.Core.Graph.Instruction.naturalEqual _ _ => 15 | Uorc.Uorc.Core.Graph.Instruction.naturalLess _ _ => 16 | Uorc.Uorc.Core.Graph.Instruction.byteEqual _ _ => 17 | Uorc.Uorc.Core.Graph.Instruction.byteLess _ _ => 18 | Uorc.Uorc.Core.Graph.Instruction.naturalToByte _ => 19 | Uorc.Uorc.Core.Graph.Instruction.byteToNatural _ => 20 | Uorc.Uorc.Core.Graph.Instruction.predicateNot _ => 21 | Uorc.Uorc.Core.Graph.Instruction.predicateAnd _ _ => 22 | Uorc.Uorc.Core.Graph.Instruction.predicateOr _ _ => 23 | Uorc.Uorc.Core.Graph.Instruction.sequenceLength _ => 24 | Uorc.Uorc.Core.Graph.Instruction.sequenceIndex _ _ => 25 | Uorc.Uorc.Core.Graph.Instruction.sequenceSlice _ _ _ => 26 | Uorc.Uorc.Core.Graph.Instruction.sequenceConcat _ _ => 27 | Uorc.Uorc.Core.Graph.Instruction.sequenceEqual _ _ => 28 | Uorc.Uorc.Core.Graph.Instruction.singletonSequence _ => 29 | Uorc.Uorc.Core.Graph.Instruction.basisGet _ => 30 | Uorc.Uorc.Core.Graph.Instruction.storeNew _ => 31 | Uorc.Uorc.Core.Graph.Instruction.storeRead _ _ => 32 | Uorc.Uorc.Core.Graph.Instruction.storeWrite _ _ _ => 33 | Uorc.Uorc.Core.Graph.Instruction.choose _ _ _ => 34 | Uorc.Uorc.Core.Graph.Instruction.apply _ _ => 35 | Uorc.Uorc.Core.Graph.Instruction.tabulate _ _ _ => 36 | Uorc.Uorc.Core.Graph.Instruction.fold _ _ _ _ => 37 | Uorc.Uorc.Core.Graph.Instruction.scan _ _ _ _ _ _ => 38 | Uorc.Uorc.Core.Graph.Instruction.sequenceRopeConstant _ => 3)

@[expose] public def start (graph : Uorc.Uorc.Core.Graph.Graph) : State := ({ pending := (Task.countBlocks ((graph).blocks) ((graph).blocks) (0) :: (Task.number ((graph).entry) :: ([] : List (Task)))), position := 0, work := 0 } : State)

@[expose] public def step (s : State) (quantum : Nat) : Event := (if (Nat.beq (quantum) (0)) then Event.failed (EmitError.invalidQuantum) ((s).position) (((s).work + 1)) else (match (s).pending with | List.nil => Event.complete ((s).position) ((s).work) | List.cons head tail => (match head with | Task.byte value => (match Uorc.Uorc.Core.Types.wordOfNatAux (8) (value) with | Option.none => Event.failed (EmitError.invalidByte) ((s).position) (((s).work + 1)) | Option.some byteWord => (match (LexLeanRuntime.checkedConvert (byteWord) : Option (UInt8)) with | Option.none => Event.failed (EmitError.invalidByte) ((s).position) (((s).work + 1)) | Option.some byteValue => Event.produced (Uorc.Uorc.Core.Types.singletonSequence (byteValue)) (({ pending := tail, position := ((s).position + 1), work := ((s).work + 1) } : State)))) | Task.number value => (if (Nat.blt (value) (128)) then (match Uorc.Uorc.Core.Types.wordOfNatAux (8) (value) with | Option.none => Event.failed (EmitError.invalidByte) ((s).position) (((s).work + 1)) | Option.some byteWord => (match (LexLeanRuntime.checkedConvert (byteWord) : Option (UInt8)) with | Option.none => Event.failed (EmitError.invalidByte) ((s).position) (((s).work + 1)) | Option.some byteValue => Event.produced (Uorc.Uorc.Core.Types.singletonSequence (byteValue)) (({ pending := tail, position := ((s).position + 1), work := ((s).work + 1) } : State)))) else (match Uorc.Uorc.Core.Types.wordOfNatAux (8) (((LexLeanRuntime.remainder (value) (128) (0) : Nat) + 128)) with | Option.none => Event.failed (EmitError.invalidByte) ((s).position) (((s).work + 1)) | Option.some byteWord => (match (LexLeanRuntime.checkedConvert (byteWord) : Option (UInt8)) with | Option.none => Event.failed (EmitError.invalidByte) ((s).position) (((s).work + 1)) | Option.some byteValue => Event.produced (Uorc.Uorc.Core.Types.singletonSequence (byteValue)) (({ pending := (Task.number ((LexLeanRuntime.quotient (value) (128) (0) : Nat)) :: tail), position := ((s).position + 1), work := ((s).work + 1) } : State))))) | Task.rope value remaining => (match Uorc.Uorc.Core.Bytes.nextChunk (value) (quantum) with | Except.error _ => Event.failed (EmitError.invalidRope) ((s).position) (((s).work + 1)) | Except.ok ropeEvent => (match ropeEvent with | Uorc.Uorc.Core.Bytes.CursorEvent.advanced next => Event.advanced (({ pending := (Task.rope (next) (remaining) :: tail), position := (s).position, work := ((s).work + 1) } : State)) | Uorc.Uorc.Core.Bytes.CursorEvent.produced chunk next => Event.produced (chunk) (({ pending := (Task.rope (next) ((LexLeanRuntime.subtract (remaining) ((LexLeanRuntime.length (chunk) : Nat)) : Nat)) :: tail), position := ((s).position + (LexLeanRuntime.length (chunk) : Nat)), work := ((s).work + 1) } : State)) | Uorc.Uorc.Core.Bytes.CursorEvent.done => Event.advanced (({ pending := tail, position := (s).position, work := ((s).work + 1) } : State)))) | Task.countTypes remaining original count => (match remaining with | List.nil => Event.advanced (({ pending := (Task.number (count) :: (Task.types (original) :: tail)), position := (s).position, work := ((s).work + 1) } : State)) | List.cons _ rest => Event.advanced (({ pending := (Task.countTypes (rest) (original) ((count + 1)) :: tail), position := (s).position, work := ((s).work + 1) } : State))) | Task.types values => (match values with | List.nil => Event.advanced (({ pending := tail, position := (s).position, work := ((s).work + 1) } : State)) | List.cons itemHead rest => Event.advanced (({ pending := (Task.byte (typeCode (itemHead)) :: (Task.types (rest) :: tail)), position := (s).position, work := ((s).work + 1) } : State))) | Task.countReferences remaining original count => (match remaining with | List.nil => Event.advanced (({ pending := (Task.number (count) :: (Task.references (original) :: tail)), position := (s).position, work := ((s).work + 1) } : State)) | List.cons _ rest => Event.advanced (({ pending := (Task.countReferences (rest) (original) ((count + 1)) :: tail), position := (s).position, work := ((s).work + 1) } : State))) | Task.references values => (match values with | List.nil => Event.advanced (({ pending := tail, position := (s).position, work := ((s).work + 1) } : State)) | List.cons itemHead rest => Event.advanced (({ pending := (Task.number (itemHead) :: (Task.references (rest) :: tail)), position := (s).position, work := ((s).work + 1) } : State))) | Task.countInstructions remaining original count => (match remaining with | List.nil => Event.advanced (({ pending := (Task.number (count) :: (Task.instructions (original) :: tail)), position := (s).position, work := ((s).work + 1) } : State)) | List.cons _ rest => Event.advanced (({ pending := (Task.countInstructions (rest) (original) ((count + 1)) :: tail), position := (s).position, work := ((s).work + 1) } : State))) | Task.instructions values => (match values with | List.nil => Event.advanced (({ pending := tail, position := (s).position, work := ((s).work + 1) } : State)) | List.cons itemHead rest => Event.advanced (({ pending := (Task.instruction (itemHead) :: (Task.instructions (rest) :: tail)), position := (s).position, work := ((s).work + 1) } : State))) | Task.countBlocks remaining original count => (match remaining with | List.nil => Event.advanced (({ pending := (Task.number (count) :: (Task.blocks (original) :: tail)), position := (s).position, work := ((s).work + 1) } : State)) | List.cons _ rest => Event.advanced (({ pending := (Task.countBlocks (rest) (original) ((count + 1)) :: tail), position := (s).position, work := ((s).work + 1) } : State))) | Task.blocks values => (match values with | List.nil => Event.advanced (({ pending := tail, position := (s).position, work := ((s).work + 1) } : State)) | List.cons itemHead rest => Event.advanced (({ pending := (Task.block (itemHead) :: (Task.blocks (rest) :: tail)), position := (s).position, work := ((s).work + 1) } : State))) | Task.instruction value => Event.advanced (({ pending := (LexLeanRuntime.append (instructionTasks (value)) (tail) : List (Task)), position := (s).position, work := ((s).work + 1) } : State)) | Task.block value => Event.advanced (({ pending := (Task.countTypes ((value).parameters) ((value).parameters) (0) :: (Task.byte (typeCode ((value).result)) :: (Task.countInstructions ((value).instructions) ((value).instructions) (0) :: (Task.number ((value).returnDistance) :: tail)))), position := (s).position, work := ((s).work + 1) } : State)))))

@[expose] public def measureStep (s : State) : Event := (match (s).pending with | List.nil => Event.complete ((s).position) ((s).work) | List.cons head tail => (match head with | Task.byte _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.number _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.rope _ remainingBytes => Event.advanced (({ pending := tail, position := ((s).position + remainingBytes), work := ((s).work + 1) } : State)) | Task.types _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.countTypes _ _ _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.references _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.countReferences _ _ _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.instructions _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.countInstructions _ _ _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.blocks _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.countBlocks _ _ _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.instruction _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events)) | Task.block _ => (match step (s) (1) with | Event.advanced next => Event.advanced (next) | Event.produced _ next => Event.advanced (next) | Event.complete count events => Event.complete (count) (events) | Event.failed error offset events => Event.failed (error) (offset) (events))))

@[expose] public def collectFixture : (fuel : Nat) -> (s : State) -> (acc : ByteArray) -> Option (ByteArray)
  | Nat.zero, _s, _acc => Option.none
  | Nat.succ remaining, s, acc => (match step (s) (16) with | Event.complete _ _ => Option.some (acc) | Event.failed _ _ _ => Option.none | Event.advanced next => collectFixture (remaining) (next) (acc) | Event.produced chunk next => collectFixture (remaining) (next) ((LexLeanRuntime.append (acc) (chunk) : ByteArray)))

public theorem literal_empty : (collectFixture (1000) (start (Uorc.Uorc.Core.Graph.literalGraph (_root_.ByteArray.mk #[]))) (_root_.ByteArray.mk #[]) = Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 0))])) := by
  rfl

public theorem literal_00 : (collectFixture (1000) (start (Uorc.Uorc.Core.Graph.literalGraph (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))]))) (_root_.ByteArray.mk #[]) = Option.some ((let __byte1 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 1); _root_.ByteArray.mk #[__byte1, (_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 3)), __byte1, (_root_.UInt8.ofNat (nat_lit 3)), __byte1, (_root_.UInt8.ofNat (nat_lit 0)), __byte1, (_root_.UInt8.ofNat (nat_lit 0))]))) := by
  rfl

public theorem literal_00ff80 : (collectFixture (1000) (start (Uorc.Uorc.Core.Graph.literalGraph (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255)), (_root_.UInt8.ofNat (nat_lit 128))]))) (_root_.ByteArray.mk #[]) = Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255)), (_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 0))])) := by
  rfl

public theorem literal_00017f80ff : (collectFixture (1000) (start (Uorc.Uorc.Core.Graph.literalGraph (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 127)), (_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 255))]))) (_root_.ByteArray.mk #[]) = Option.some ((let __byte1 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 1); _root_.ByteArray.mk #[__byte1, (_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 3)), __byte1, (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 5)), (_root_.UInt8.ofNat (nat_lit 0)), __byte1, (_root_.UInt8.ofNat (nat_lit 127)), (_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 255)), __byte1, (_root_.UInt8.ofNat (nat_lit 0))]))) := by
  rfl

public theorem partition_independent_literal : (collectFixture (1000) (start (Uorc.Uorc.Core.Graph.literalRopeGraph (Uorc.Uorc.Core.Bytes.join (Uorc.Uorc.Core.Bytes.fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))])) (Uorc.Uorc.Core.Bytes.fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 255)), (_root_.UInt8.ofNat (nat_lit 128))]))))) (_root_.ByteArray.mk #[]) = Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255)), (_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 0))])) := by
  rfl

public theorem opcode_naturalConstant : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalConstant ((0 : UInt64))) = 0) := by
  rfl

public theorem opcode_byteConstant : (opcode (Uorc.Uorc.Core.Graph.Instruction.byteConstant ((0 : UInt8))) = 1) := by
  rfl

public theorem opcode_predicateConstant : (opcode (Uorc.Uorc.Core.Graph.Instruction.predicateConstant (false)) = 2) := by
  rfl

public theorem opcode_sequenceConstant : (opcode (Uorc.Uorc.Core.Graph.Instruction.sequenceConstant (_root_.ByteArray.mk #[])) = 3) := by
  rfl

public theorem opcode_naturalAdd : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalAdd (0) (0)) = 4) := by
  rfl

public theorem opcode_naturalSubtract : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalSubtract (0) (0)) = 5) := by
  rfl

public theorem opcode_naturalMultiply : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalMultiply (0) (0)) = 6) := by
  rfl

public theorem opcode_naturalDivide : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalDivide (0) (0)) = 7) := by
  rfl

public theorem opcode_naturalRemainder : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalRemainder (0) (0)) = 8) := by
  rfl

public theorem opcode_naturalAnd : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalAnd (0) (0)) = 9) := by
  rfl

public theorem opcode_naturalOr : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalOr (0) (0)) = 10) := by
  rfl

public theorem opcode_naturalXor : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalXor (0) (0)) = 11) := by
  rfl

public theorem opcode_naturalNot : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalNot (0)) = 12) := by
  rfl

public theorem opcode_naturalShiftLeft : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalShiftLeft (0) (0)) = 13) := by
  rfl

public theorem opcode_naturalShiftRight : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalShiftRight (0) (0)) = 14) := by
  rfl

public theorem opcode_naturalEqual : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalEqual (0) (0)) = 15) := by
  rfl

public theorem opcode_naturalLess : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalLess (0) (0)) = 16) := by
  rfl

public theorem opcode_byteEqual : (opcode (Uorc.Uorc.Core.Graph.Instruction.byteEqual (0) (0)) = 17) := by
  rfl

public theorem opcode_byteLess : (opcode (Uorc.Uorc.Core.Graph.Instruction.byteLess (0) (0)) = 18) := by
  rfl

public theorem opcode_naturalToByte : (opcode (Uorc.Uorc.Core.Graph.Instruction.naturalToByte (0)) = 19) := by
  rfl

public theorem opcode_byteToNatural : (opcode (Uorc.Uorc.Core.Graph.Instruction.byteToNatural (0)) = 20) := by
  rfl

public theorem opcode_predicateNot : (opcode (Uorc.Uorc.Core.Graph.Instruction.predicateNot (0)) = 21) := by
  rfl

public theorem opcode_predicateAnd : (opcode (Uorc.Uorc.Core.Graph.Instruction.predicateAnd (0) (0)) = 22) := by
  rfl

public theorem opcode_predicateOr : (opcode (Uorc.Uorc.Core.Graph.Instruction.predicateOr (0) (0)) = 23) := by
  rfl

public theorem opcode_sequenceLength : (opcode (Uorc.Uorc.Core.Graph.Instruction.sequenceLength (0)) = 24) := by
  rfl

public theorem opcode_sequenceIndex : (opcode (Uorc.Uorc.Core.Graph.Instruction.sequenceIndex (0) (0)) = 25) := by
  rfl

public theorem opcode_sequenceSlice : (opcode (Uorc.Uorc.Core.Graph.Instruction.sequenceSlice (0) (0) (0)) = 26) := by
  rfl

public theorem opcode_sequenceConcat : (opcode (Uorc.Uorc.Core.Graph.Instruction.sequenceConcat (0) (0)) = 27) := by
  rfl

public theorem opcode_sequenceEqual : (opcode (Uorc.Uorc.Core.Graph.Instruction.sequenceEqual (0) (0)) = 28) := by
  rfl

public theorem opcode_singletonSequence : (opcode (Uorc.Uorc.Core.Graph.Instruction.singletonSequence (0)) = 29) := by
  rfl

public theorem opcode_basisGet : (opcode (Uorc.Uorc.Core.Graph.Instruction.basisGet (0)) = 30) := by
  rfl

public theorem opcode_storeNew : (opcode (Uorc.Uorc.Core.Graph.Instruction.storeNew (0)) = 31) := by
  rfl

public theorem opcode_storeRead : (opcode (Uorc.Uorc.Core.Graph.Instruction.storeRead (0) (0)) = 32) := by
  rfl

public theorem opcode_storeWrite : (opcode (Uorc.Uorc.Core.Graph.Instruction.storeWrite (0) (0) (0)) = 33) := by
  rfl

public theorem opcode_choose : (opcode (Uorc.Uorc.Core.Graph.Instruction.choose (0) (0) (0)) = 34) := by
  rfl

public theorem opcode_apply : (opcode (Uorc.Uorc.Core.Graph.Instruction.apply (0) (([] : List (Nat)))) = 35) := by
  rfl

public theorem opcode_tabulate : (opcode (Uorc.Uorc.Core.Graph.Instruction.tabulate (0) (0) (([] : List (Nat)))) = 36) := by
  rfl

public theorem opcode_fold : (opcode (Uorc.Uorc.Core.Graph.Instruction.fold (0) (0) (0) (([] : List (Nat)))) = 37) := by
  rfl

public theorem opcode_scan : (opcode (Uorc.Uorc.Core.Graph.Instruction.scan (0) (0) (0) (([] : List (Nat))) (0) (([] : List (Nat)))) = 38) := by
  rfl

@[expose] public def profileBoundary : String := "This source assigns new explicit graph opcode and type tags. It does not assert compatibility with unavailable draft01 or draft02 graph vectors. Numeric structural fields use shortest unsigned base128 naturals; naturalConstant is additionally checked UInt64. Byte literals serialize by logical bytes independent of rope shape. Entry is a zero-based block index; local and called-block references retain validated backward-distance semantics. Production start/step emits bounded chunks and never accumulates the entire wire output."

end Uorc.Uorc.Wire.GraphEmit
