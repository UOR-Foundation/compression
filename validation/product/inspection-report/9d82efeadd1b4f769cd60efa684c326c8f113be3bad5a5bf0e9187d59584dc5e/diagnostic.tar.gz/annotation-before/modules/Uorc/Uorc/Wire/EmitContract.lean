module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Wire.EmitContract

public structure Scenario where
  id : String
  given : String
  when : String
  «then» : String
  owner : String

@[expose] public def uc_wire_emit_01 : Scenario := ({ id := "UC-WIRE-EMIT-01", given := "charged program metadata for all 39 wire opcodes", when := "measure then emit with the same achieved arena and usage", «then» := "exact bytes agree with independent GraphEmit/GraphParse diagnostics", owner := "Uorc.Wire.ProgramEmitScenarios.run" } : Scenario)

@[expose] public def uc_wire_emit_02 : Scenario := ({ id := "UC-WIRE-EMIT-02", given := "a borrowed literal span under the wire owner", when := "acknowledge, cancel, fail or pause before a sink finishes", «then» := "no root is released before consumption or retained-ticket transfer", owner := "Uorc.Wire.ProgramEmitScenarios.runOwnership" } : Scenario)

@[expose] public def uc_wire_emit_03 : Scenario := ({ id := "UC-WIRE-EMIT-03", given := "invalid scalar/metadata or insufficient work/output allowance", when := "advance after earlier output events", «then» := "typed retained failure or exact resumable pause without another arena snapshot", owner := "Uorc.Wire.ProgramEmitScenarios.runNegatives" } : Scenario)

@[expose] public def uc_wire_emit_04 : Scenario := ({ id := "UC-WIRE-EMIT-04", given := "ordered lengths stored in charged indexed metadata, including empty objects", when := "emit a frame using the identity owner supplied descriptor and integrity span seam", «then» := "headers, body measure and borrowed spans are exact; no hash identity or accepted-format token is invented", owner := "Uorc.Wire.FrameEmitScenarios.run" } : Scenario)

@[expose] public def boundary : String := "The production emitter reads RuntimeProgram.Program/BorrowedBlock/BorrowedInstruction metadata. GraphEmit and GraphParse remain diagnostics only. Fixed producer controls contain no Arena; the driving session moves one actual Arena and Usage through each operation. A controller detaches admission only at the acknowledged stable boundary through the Core-owned typed transfer interface, never by accepting an arbitrary validation snapshot. The frame identity and integrity construction are supplied by their separate source owner; format-2 meanings are unchanged and no new accepted-format claim is made here."

end Uorc.Uorc.Wire.EmitContract
