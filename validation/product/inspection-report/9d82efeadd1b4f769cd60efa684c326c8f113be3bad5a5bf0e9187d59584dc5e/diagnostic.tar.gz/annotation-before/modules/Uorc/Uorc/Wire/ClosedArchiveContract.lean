module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Wire.ClosedArchiveContract

public structure Scenario where
  id : String
  given : String
  when : String
  «then» : String
  owner : String

@[expose] public def closed_01 : Scenario := ({ id := "UC-WIRE-CLOSED-01", given := "charged immutable archive snapshot, ordered empty objects", when := "bounded read, parse and reserved length-store transitions", «then» := "one arena, all ordered lengths retained; exact body/preimage fences", owner := "Uorc.Wire.ArchiveSnapshotScenarios.run" } : Scenario)

@[expose] public def closed_02 : Scenario := ({ id := "UC-WIRE-CLOSED-02", given := "truncated, trailing, invalid header and resource pauses", when := "resume or cancel after earlier committed lengths", «then» := "typed retained failure and actual cursor cleanup", owner := "Uorc.Wire.ArchiveSnapshotScenarios.run" } : Scenario)

@[expose] public def closed_03 : Scenario := ({ id := "UC-WIRE-CLOSED-03", given := "raw, self-contained and conditional program archives", when := "integrity and exact basis identity before admission seal", «then» := "only actual Core Ready reaches machine and object output", owner := "Uorc.Wire.ClosedArchiveScenarios.run" } : Scenario)

@[expose] public def closed_04 : Scenario := ({ id := "UC-WIRE-CLOSED-04", given := "pending input image or output ticket", when := "cancel, pause or publication failure", «then» := "achieved ledger and all cleanup ownership remain available", owner := "Uorc.Wire.ClosedArchiveScenarios.run" } : Scenario)

end Uorc.Uorc.Wire.ClosedArchiveContract
