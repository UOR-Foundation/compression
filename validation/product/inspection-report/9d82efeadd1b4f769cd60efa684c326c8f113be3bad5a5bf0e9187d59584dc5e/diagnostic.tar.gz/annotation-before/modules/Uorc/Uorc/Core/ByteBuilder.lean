module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Bytes
public import Uorc.Uorc.Core.Resources
public import Uorc.Uorc.Core.Types
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.ByteBuilder

public inductive Error where
  | invalidState
  | addressSpaceExhausted
  | rope (_ : Uorc.Uorc.Core.Bytes.RopeError)
  | zeroBlockSize

public structure Builder where
  completed : Uorc.Uorc.Core.Bytes.Rope
  bins : List (Option (ByteArray))
  buffered : Nat
  capacity : Nat

public inductive Work where
  | beginByte (_ : Builder) (_ : UInt8)
  | merging (_ : Uorc.Uorc.Core.Bytes.Rope) (_ : ByteArray) (_ : List (Option (ByteArray))) (_ : Nat) (_ : Nat) (_ : Nat)
  | rebuilding (_ : Uorc.Uorc.Core.Bytes.Rope) (_ : List (Option (ByteArray))) (_ : Nat) (_ : Nat) (_ : Nat)
  | flushing (_ : Uorc.Uorc.Core.Bytes.Work) (_ : Nat)
  | tail (_ : Uorc.Uorc.Core.Bytes.Rope) (_ : List (Option (ByteArray))) (_ : ByteArray)
  | tailFlushing (_ : Uorc.Uorc.Core.Bytes.Work)

public inductive Event where
  | advanced (_ : Work)
  | appended (_ : Builder)
  | finished (_ : Uorc.Uorc.Core.Bytes.Rope)
  | failed (_ : Error)

@[expose] public def blockSize : Nat := 4096

@[expose] public def empty : Builder := ({ completed := Uorc.Uorc.Core.Bytes.Rope.empty, bins := ([] : List (Option (ByteArray))), buffered := 0, capacity := 4096 } : Builder)

@[expose] public def chooseCapacity : (depth : Nat) -> (current : Nat) -> (limit : Nat) -> Nat
  | Nat.zero, current, _limit => current
  | Nat.succ remainingDepth, current, limit => (if (Nat.ble (current) (2048)) then (if (Nat.ble ((LexLeanRuntime.multiply (2) (current) : Nat)) (limit)) then chooseCapacity (remainingDepth) ((LexLeanRuntime.multiply (2) (current) : Nat)) (limit) else current) else current)

@[expose] public def start (maxLeafBytes : Nat) : Except (Error) (Builder) := (if (Nat.beq (maxLeafBytes) (0)) then Except.error (Error.zeroBlockSize) else Except.ok (({ completed := Uorc.Uorc.Core.Bytes.Rope.empty, bins := ([] : List (Option (ByteArray))), buffered := 0, capacity := chooseCapacity (12) (1) (maxLeafBytes) } : Builder)))

@[expose] public def appendByte (builder : Builder) (value : UInt8) : Work := Work.beginByte (builder) (value)

@[expose] public def finish (builder : Builder) : Work := Work.tail ((builder).completed) ((builder).bins) (_root_.ByteArray.mk #[])

@[expose] public def eventWork (workValue : Work) : Nat := (match workValue with | Work.beginByte _ _ => 9 | Work.merging _ carry remainingBins _ _ _ => (match remainingBins with | List.nil => 1 | List.cons headBin _ => (match headBin with | Option.none => 1 | Option.some oldBlock => (if ((Nat.ble ((LexLeanRuntime.length (oldBlock) : Nat)) (4096)) && (Nat.ble ((LexLeanRuntime.length (carry) : Nat)) (4096))) then (1 + ((LexLeanRuntime.length (oldBlock) : Nat) + (LexLeanRuntime.length (carry) : Nat))) else 1))) | Work.rebuilding _ _ _ _ _ => 1 | Work.flushing _ _ => 1 | Work.tail _ remainingBins tailBytes => (match remainingBins with | List.nil => 1 | List.cons headBin _ => (match headBin with | Option.none => 1 | Option.some oldBlock => (if (Nat.beq ((LexLeanRuntime.length (tailBytes) : Nat)) (0)) then 1 else (if ((Nat.ble ((LexLeanRuntime.length (oldBlock) : Nat)) (4096)) && (Nat.ble ((LexLeanRuntime.length (tailBytes) : Nat)) (4096))) then (1 + ((LexLeanRuntime.length (oldBlock) : Nat) + (LexLeanRuntime.length (tailBytes) : Nat))) else 1)))) | Work.tailFlushing _ => 1)

@[expose] public def step (workValue : Work) : Event := (match workValue with | Work.beginByte builder value => (if (Nat.blt ((builder).buffered) ((builder).capacity)) then Event.advanced (Work.merging ((builder).completed) (Uorc.Uorc.Core.Types.singletonSequence (value)) ((builder).bins) (0) (((builder).buffered + 1)) ((builder).capacity)) else Event.failed (Error.invalidState)) | Work.merging completed carry remainingBins zeros count capacity => (if ((Nat.blt (0) (capacity)) && (Nat.ble (capacity) (4096))) then (if (Nat.beq ((LexLeanRuntime.length (carry) : Nat)) (capacity)) then (match remainingBins with | List.nil => (if (Nat.beq (count) (capacity)) then (if Uorc.Uorc.Core.Resources.fitsAddition (18446744073709551615) (Uorc.Uorc.Core.Bytes.length (completed)) ((LexLeanRuntime.length (carry) : Nat)) then Event.advanced (Work.flushing (Uorc.Uorc.Core.Bytes.startJoin (completed) (Uorc.Uorc.Core.Bytes.fromBytes (carry))) (capacity)) else Event.failed (Error.addressSpaceExhausted)) else Event.failed (Error.invalidState)) | List.cons _ _ => Event.failed (Error.invalidState)) else (if ((Nat.blt (0) ((LexLeanRuntime.length (carry) : Nat))) && (Nat.blt ((LexLeanRuntime.length (carry) : Nat)) (capacity))) then (match remainingBins with | List.nil => Event.advanced (Work.rebuilding (completed) ((Option.some (carry) :: ([] : List (Option (ByteArray))))) (zeros) (count) (capacity)) | List.cons headBin restBins => (match headBin with | Option.none => Event.advanced (Work.rebuilding (completed) ((Option.some (carry) :: restBins)) (zeros) (count) (capacity)) | Option.some oldBlock => (if ((Nat.beq ((LexLeanRuntime.length (oldBlock) : Nat)) ((LexLeanRuntime.length (carry) : Nat))) && (Nat.ble ((LexLeanRuntime.length (carry) : Nat)) ((LexLeanRuntime.quotient (capacity) (2) (0) : Nat)))) then Event.advanced (Work.merging (completed) ((LexLeanRuntime.append (oldBlock) (carry) : ByteArray)) (restBins) ((zeros + 1)) (count) (capacity)) else Event.failed (Error.invalidState)))) else Event.failed (Error.invalidState))) else Event.failed (Error.invalidState)) | Work.rebuilding completed bins zeros count capacity => (match zeros with | Nat.zero => Event.appended (({ completed := completed, bins := bins, buffered := count, capacity := capacity } : Builder)) | Nat.succ remainingZeros => Event.advanced (Work.rebuilding (completed) ((Option.none :: bins)) (remainingZeros) (count) (capacity))) | Work.flushing ropeWork capacity => (match Uorc.Uorc.Core.Bytes.workStep (ropeWork) with | Uorc.Uorc.Core.Bytes.WorkEvent.advanced nextWork => Event.advanced (Work.flushing (nextWork) (capacity)) | Uorc.Uorc.Core.Bytes.WorkEvent.sequenceDone completedRope => Event.appended (({ completed := completedRope, bins := ([] : List (Option (ByteArray))), buffered := 0, capacity := capacity } : Builder)) | Uorc.Uorc.Core.Bytes.WorkEvent.byteDone _ => Event.failed (Error.invalidState) | Uorc.Uorc.Core.Bytes.WorkEvent.failed ropeError => Event.failed (Error.rope (ropeError))) | Work.tail completed remainingBins tailBytes => (match remainingBins with | List.nil => (if (Nat.beq ((LexLeanRuntime.length (tailBytes) : Nat)) (0)) then Event.finished (completed) else (if Uorc.Uorc.Core.Resources.fitsAddition (18446744073709551615) (Uorc.Uorc.Core.Bytes.length (completed)) ((LexLeanRuntime.length (tailBytes) : Nat)) then Event.advanced (Work.tailFlushing (Uorc.Uorc.Core.Bytes.startJoin (completed) (Uorc.Uorc.Core.Bytes.fromBytes (tailBytes)))) else Event.failed (Error.addressSpaceExhausted))) | List.cons headBin restBins => (match headBin with | Option.none => Event.advanced (Work.tail (completed) (restBins) (tailBytes)) | Option.some oldBlock => (if ((Nat.ble ((LexLeanRuntime.length (oldBlock) : Nat)) (4096)) && (Nat.ble ((LexLeanRuntime.length (tailBytes) : Nat)) ((LexLeanRuntime.subtract (4096) ((LexLeanRuntime.length (oldBlock) : Nat)) : Nat)))) then Event.advanced (Work.tail (completed) (restBins) ((if (Nat.beq ((LexLeanRuntime.length (tailBytes) : Nat)) (0)) then oldBlock else (LexLeanRuntime.append (oldBlock) (tailBytes) : ByteArray)))) else Event.failed (Error.invalidState)))) | Work.tailFlushing ropeWork => (match Uorc.Uorc.Core.Bytes.workStep (ropeWork) with | Uorc.Uorc.Core.Bytes.WorkEvent.advanced nextWork => Event.advanced (Work.tailFlushing (nextWork)) | Uorc.Uorc.Core.Bytes.WorkEvent.sequenceDone completedRope => Event.finished (completedRope) | Uorc.Uorc.Core.Bytes.WorkEvent.byteDone _ => Event.failed (Error.invalidState) | Uorc.Uorc.Core.Bytes.WorkEvent.failed ropeError => Event.failed (Error.rope (ropeError))))

@[expose] public def runEvents : (fuel : Nat) -> (workValue : Work) -> Event
  | Nat.zero, workValue => Event.advanced (workValue)
  | Nat.succ remainingFuel, workValue => (match step (workValue) with | Event.advanced nextWork => runEvents (remainingFuel) (nextWork) | Event.appended builder => Event.appended (builder) | Event.finished rope => Event.finished (rope) | Event.failed error => Event.failed (error))

@[expose] public def binsMeaning : (bins : List (Option (ByteArray))) -> Uorc.Uorc.Core.Bytes.Rope
  | List.nil => Uorc.Uorc.Core.Bytes.Rope.empty
  | List.cons headBin restBins => (match headBin with | Option.none => binsMeaning (restBins) | Option.some chunk => Uorc.Uorc.Core.Bytes.join (binsMeaning (restBins)) (Uorc.Uorc.Core.Bytes.fromBytes (chunk)))

@[expose] public def meaning (builder : Builder) : Uorc.Uorc.Core.Bytes.Rope := Uorc.Uorc.Core.Bytes.join ((builder).completed) (binsMeaning ((builder).bins))

public theorem default_builder_leaf_size_is_4096 : (blockSize = 4096) := by
  rfl

public theorem empty_builder_finishes_without_payload_copy : (step (finish (empty)) = Event.finished (Uorc.Uorc.Core.Bytes.Rope.empty)) := by
  rfl

public theorem one_byte_append_has_nine_initial_work_units : (eventWork (appendByte (empty) ((255 : UInt8))) = 9) := by
  rfl

public theorem equal_blocks_copy_both_inputs : (eventWork (Work.merging (Uorc.Uorc.Core.Bytes.Rope.empty) (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 51)), (_root_.UInt8.ofNat (nat_lit 68))]) ((Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34))]) :: ([] : List (Option (ByteArray))))) (1) (4) (4096)) = 5) := by
  rfl

public theorem zero_builder_events_preserves_work (workValue : Work) : (runEvents (0) (workValue) = Event.advanced (workValue)) := by
  rfl

public theorem zero_leaf_policy_is_typed : (start (0) = Except.error (Error.zeroBlockSize)) := by
  rfl

public theorem positive_nonpower_policy_selects_bounded_leaf : ((match start (3000) with | Except.error _ => 0 | Except.ok builder => (builder).capacity) = 2048) := by
  rfl

@[expose] public def binsSize : (bins : List (Option (ByteArray))) -> Nat
  | List.nil => 0
  | List.cons headBin restBins => (match headBin with | Option.none => binsSize (restBins) | Option.some chunk => ((LexLeanRuntime.length (chunk) : Nat) + binsSize (restBins)))

@[expose] public def validBins : (levels : Nat) -> (expectedSize : Nat) -> (bins : List (Option (ByteArray))) -> Bool
  | Nat.zero, _expectedSize, bins => (match bins with | List.nil => true | List.cons _ _ => false)
  | Nat.succ remainingLevels, expectedSize, bins => (match bins with | List.nil => true | List.cons headBin restBins => ((match headBin with | Option.none => true | Option.some chunk => (Nat.beq ((LexLeanRuntime.length (chunk) : Nat)) (expectedSize))) && validBins (remainingLevels) ((LexLeanRuntime.multiply (2) (expectedSize) : Nat)) (restBins)))

@[expose] public def valid (builder : Builder) : Bool := (((Nat.blt (0) ((builder).capacity)) && (Nat.ble ((builder).capacity) (4096))) && ((Nat.beq (chooseCapacity (12) (1) ((builder).capacity)) ((builder).capacity)) && ((Nat.blt ((builder).buffered) ((builder).capacity)) && ((Nat.beq (binsSize ((builder).bins)) ((builder).buffered)) && validBins (12) (1) ((builder).bins)))))

public theorem default_empty_builder_is_valid : (valid (empty) = true) := by
  rfl

public theorem three_byte_carry_bins_are_valid : (valid (({ completed := Uorc.Uorc.Core.Bytes.Rope.empty, bins := (Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 51))]) :: (Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34))]) :: ([] : List (Option (ByteArray))))), buffered := 3, capacity := 4096 } : Builder)) = true) := by
  rfl

public theorem finishing_bins_preserves_byte_order : (runEvents (20) (finish (({ completed := Uorc.Uorc.Core.Bytes.Rope.empty, bins := (Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 51))]) :: (Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34))]) :: ([] : List (Option (ByteArray))))), buffered := 3, capacity := 4096 } : Builder))) = Event.finished (Uorc.Uorc.Core.Bytes.Rope.leaf (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 51))]))) := by
  rfl

public theorem full_leaf_coalesces_and_drops_singleton_bins : (runEvents (20) (appendByte (({ completed := Uorc.Uorc.Core.Bytes.Rope.empty, bins := (Option.some (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 17))]) :: ([] : List (Option (ByteArray)))), buffered := 1, capacity := 2 } : Builder)) ((34 : UInt8))) = Event.appended (({ completed := Uorc.Uorc.Core.Bytes.Rope.leaf (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34))]), bins := ([] : List (Option (ByteArray))), buffered := 0, capacity := 2 } : Builder))) := by
  rfl

public theorem vacant_bin_preserves_payload_order (olderBins : List (Option (ByteArray))) : (binsMeaning ((Option.none :: olderBins)) = binsMeaning (olderBins)) := by
  rfl

public theorem occupied_bin_follows_every_older_bin (newerBlock : ByteArray) (olderBins : List (Option (ByteArray))) : (binsMeaning ((Option.some (newerBlock) :: olderBins)) = Uorc.Uorc.Core.Bytes.join (binsMeaning (olderBins)) (Uorc.Uorc.Core.Bytes.fromBytes (newerBlock))) := by
  rfl

public theorem two_occupied_bins_keep_oldest_first (newerBlock : ByteArray) (olderBlock : ByteArray) (olderBins : List (Option (ByteArray))) : (binsMeaning ((Option.some (newerBlock) :: (Option.some (olderBlock) :: olderBins))) = Uorc.Uorc.Core.Bytes.join (Uorc.Uorc.Core.Bytes.join (binsMeaning (olderBins)) (Uorc.Uorc.Core.Bytes.fromBytes (olderBlock))) (Uorc.Uorc.Core.Bytes.fromBytes (newerBlock))) := by
  rfl

public theorem tail_vacant_bin_advances_without_copy (completed : Uorc.Uorc.Core.Bytes.Rope) (olderBins : List (Option (ByteArray))) (tailBytes : ByteArray) : (step (Work.tail (completed) ((Option.none :: olderBins)) (tailBytes)) = Event.advanced (Work.tail (completed) (olderBins) (tailBytes))) := by
  rfl

public theorem rebuilding_zero_commits_exact_bin_order (completed : Uorc.Uorc.Core.Bytes.Rope) (bins : List (Option (ByteArray))) (count : Nat) (capacity : Nat) : (step (Work.rebuilding (completed) (bins) (0) (count) (capacity)) = Event.appended (({ completed := completed, bins := bins, buffered := count, capacity := capacity } : Builder))) := by
  rfl

public theorem finished_empty_tail_retains_completed_rope (completed : Uorc.Uorc.Core.Bytes.Rope) : (step (Work.tail (completed) (([] : List (Option (ByteArray)))) (_root_.ByteArray.mk #[])) = Event.finished (completed)) := by
  rfl

@[expose] public def vacantPrefix : (vacancies : Nat) -> (binValues : List (Option (ByteArray))) -> List (Option (ByteArray))
  | Nat.zero, binValues => binValues
  | Nat.succ remainingVacancies, binValues => vacantPrefix (remainingVacancies) ((Option.none :: binValues))

public theorem vacant_prefix_preserves_every_payload (vacancies : Nat) (binValues : List (Option (ByteArray))) : (binsMeaning (vacantPrefix (vacancies) (binValues)) = binsMeaning (binValues)) := by
  induction vacancies generalizing binValues with
  | zero =>
    rfl
  | succ remainingVacancies ih =>
    simp only [binsMeaning, ih, vacantPrefix]

public theorem one_event_advances_one_rebuilding_vacancy (fuel : Nat) (vacancies : Nat) (binValues : List (Option (ByteArray))) (completed : Uorc.Uorc.Core.Bytes.Rope) (count : Nat) (capacity : Nat) : (runEvents ((fuel + 1)) (Work.rebuilding (completed) (binValues) ((vacancies + 1)) (count) (capacity)) = runEvents (fuel) (Work.rebuilding (completed) ((Option.none :: binValues)) (vacancies) (count) (capacity))) := by
  rfl

public theorem rebuilding_commits_all_vacancies_in_exact_event_count (vacancies : Nat) (binValues : List (Option (ByteArray))) (completed : Uorc.Uorc.Core.Bytes.Rope) (count : Nat) (capacity : Nat) : (runEvents ((vacancies + 1)) (Work.rebuilding (completed) (binValues) (vacancies) (count) (capacity)) = Event.appended (({ completed := completed, bins := vacantPrefix (vacancies) (binValues), buffered := count, capacity := capacity } : Builder))) := by
  induction vacancies generalizing binValues with
  | zero =>
    rfl
  | succ remainingVacancies ih =>
    simp only [ih, one_event_advances_one_rebuilding_vacancy, vacantPrefix]

end Uorc.Uorc.Core.ByteBuilder
