module
public import Init
public import LexLeanRuntime.Portable
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Wire.Cursor

public inductive ReadError where
  | invalidCursor
  | invalidQuantum
  | truncated
  | overflow
  | nonShortest

public structure Cursor where
  parts : List (ByteArray)
  offset : Nat
  position : Nat

public structure LocatedError where
  kind : ReadError
  offset : Nat

public inductive ReadEvent where
  | advanced (_ : Cursor)
  | byte (_ : UInt8) (_ : Cursor)
  | «end» (_ : Cursor)
  | failed (_ : LocatedError)

@[expose] public def start (parts : List (ByteArray)) : Cursor := ({ parts := parts, offset := 0, position := 0 } : Cursor)

@[expose] public def readStep (c : Cursor) : ReadEvent := (match (c).parts with | List.nil => (if (Nat.beq ((c).offset) (0)) then ReadEvent.«end» (c) else ReadEvent.failed (({ kind := ReadError.invalidCursor, offset := (c).position } : LocatedError))) | List.cons head tail => (if (Nat.blt ((c).offset) ((LexLeanRuntime.length (head) : Nat))) then (match (LexLeanRuntime.index (head) ((c).offset) : Option (UInt8)) with | Option.none => ReadEvent.failed (({ kind := ReadError.invalidCursor, offset := (c).position } : LocatedError)) | Option.some b => ReadEvent.byte (b) (({ parts := (c).parts, offset := ((c).offset + 1), position := ((c).position + 1) } : Cursor))) else (if (Nat.beq ((c).offset) ((LexLeanRuntime.length (head) : Nat))) then ReadEvent.advanced (({ parts := tail, offset := 0, position := (c).position } : Cursor)) else ReadEvent.failed (({ kind := ReadError.invalidCursor, offset := (c).position } : LocatedError)))))

public inductive ChunkEvent where
  | advanced (_ : Cursor)
  | bytes (_ : ByteArray) (_ : Cursor)
  | «end» (_ : Cursor)
  | failed (_ : LocatedError)

@[expose] public def readChunkStep (c : Cursor) (quantum : Nat) : ChunkEvent := (if (Nat.beq (quantum) (0)) then ChunkEvent.failed (({ kind := ReadError.invalidQuantum, offset := (c).position } : LocatedError)) else (match (c).parts with | List.nil => (if (Nat.beq ((c).offset) (0)) then ChunkEvent.«end» (c) else ChunkEvent.failed (({ kind := ReadError.invalidCursor, offset := (c).position } : LocatedError))) | List.cons head tail => (if (Nat.blt ((c).offset) ((LexLeanRuntime.length (head) : Nat))) then (match (LexLeanRuntime.slice (head) ((c).offset) ((if (Nat.blt ((LexLeanRuntime.subtract ((LexLeanRuntime.length (head) : Nat)) ((c).offset) : Nat)) (quantum)) then (LexLeanRuntime.subtract ((LexLeanRuntime.length (head) : Nat)) ((c).offset) : Nat) else quantum)) : Option (ByteArray)) with | Option.none => ChunkEvent.failed (({ kind := ReadError.invalidCursor, offset := (c).position } : LocatedError)) | Option.some chunk => ChunkEvent.bytes (chunk) (({ parts := (c).parts, offset := ((c).offset + (if (Nat.blt ((LexLeanRuntime.subtract ((LexLeanRuntime.length (head) : Nat)) ((c).offset) : Nat)) (quantum)) then (LexLeanRuntime.subtract ((LexLeanRuntime.length (head) : Nat)) ((c).offset) : Nat) else quantum)), position := ((c).position + (if (Nat.blt ((LexLeanRuntime.subtract ((LexLeanRuntime.length (head) : Nat)) ((c).offset) : Nat)) (quantum)) then (LexLeanRuntime.subtract ((LexLeanRuntime.length (head) : Nat)) ((c).offset) : Nat) else quantum)) } : Cursor))) else (if (Nat.beq ((c).offset) ((LexLeanRuntime.length (head) : Nat))) then ChunkEvent.advanced (({ parts := tail, offset := 0, position := (c).position } : Cursor)) else ChunkEvent.failed (({ kind := ReadError.invalidCursor, offset := (c).position } : LocatedError))))))

public structure UlebState where
  cursor : Cursor
  start : Nat
  value : Nat
  factor : Nat
  consumed : Nat

public inductive UlebEvent where
  | more (_ : UlebState)
  | done (_ : Nat) (_ : Cursor)
  | failed (_ : LocatedError)

@[expose] public def startUleb (c : Cursor) : UlebState := ({ cursor := c, start := (c).position, value := 0, factor := 1, consumed := 0 } : UlebState)

@[expose] public def ulebStep (u : UlebState) : UlebEvent := (if (Nat.ble (10) ((u).consumed)) then UlebEvent.failed (({ kind := ReadError.overflow, offset := ((u).start + (u).consumed) } : LocatedError)) else (match readStep ((u).cursor) with | ReadEvent.advanced next => UlebEvent.more (({ cursor := next, start := (u).start, value := (u).value, factor := (u).factor, consumed := (u).consumed } : UlebState)) | ReadEvent.byte b next => (if (Nat.blt ((let __widen0 : UInt8 := b; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) (128)) then (if ((Nat.beq ((u).consumed) (9)) && ((Nat.blt (1) ((LexLeanRuntime.remainder ((let __widen1 : UInt8 := b; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) (128) (0) : Nat))) && true)) then UlebEvent.failed (({ kind := ReadError.overflow, offset := ((u).start + (u).consumed) } : LocatedError)) else (if ((Nat.blt (0) ((u).consumed)) && ((Nat.beq ((LexLeanRuntime.remainder ((let __widen2 : UInt8 := b; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen2) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen2) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen2) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen2) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen2) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen2) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen2) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen2) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) (128) (0) : Nat)) (0)) && true)) then UlebEvent.failed (({ kind := ReadError.nonShortest, offset := ((u).start + (u).consumed) } : LocatedError)) else UlebEvent.done (((u).value + (LexLeanRuntime.multiply ((LexLeanRuntime.remainder ((let __widen3 : UInt8 := b; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen3) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen3) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen3) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen3) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen3) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen3) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen3) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen3) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) (128) (0) : Nat)) ((u).factor) : Nat))) (next))) else UlebEvent.more (({ cursor := next, start := (u).start, value := (if (Nat.beq ((u).consumed) (9)) then (u).value else ((u).value + (LexLeanRuntime.multiply ((LexLeanRuntime.remainder ((let __widen4 : UInt8 := b; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen4) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen4) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen4) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen4) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen4) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen4) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen4) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen4) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) (128) (0) : Nat)) ((u).factor) : Nat))), factor := (if (Nat.beq ((u).consumed) (9)) then (u).factor else (LexLeanRuntime.multiply ((u).factor) (128) : Nat)), consumed := ((u).consumed + 1) } : UlebState))) | ReadEvent.«end» _ => UlebEvent.failed (({ kind := ReadError.truncated, offset := ((u).start + (u).consumed) } : LocatedError)) | ReadEvent.failed error => UlebEvent.failed (error)))

@[expose] public def runUleb : (fuel : Nat) -> (u : UlebState) -> UlebEvent
  | Nat.zero, u => UlebEvent.more (u)
  | Nat.succ remaining, u => (match ulebStep (u) with | UlebEvent.more next => runUleb (remaining) (next) | UlebEvent.done value next => UlebEvent.done (value) (next) | UlebEvent.failed error => UlebEvent.failed (error))

public theorem empty_cursor : (readStep (start (([] : List (ByteArray)))) = ReadEvent.«end» (start (([] : List (ByteArray))))) := by
  rfl

public theorem empty_chunk_advances : (readStep (start ((_root_.ByteArray.mk #[] :: ([] : List (ByteArray))))) = ReadEvent.advanced (start (([] : List (ByteArray))))) := by
  rfl

public theorem uleb_0 : (runUleb (30) (startUleb (start ((_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))] :: ([] : List (ByteArray)))))) = UlebEvent.done (0) (({ parts := (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))] :: ([] : List (ByteArray))), offset := 1, position := 1 } : Cursor))) := by
  rfl

public theorem uleb_1 : (runUleb (30) (startUleb (start ((_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1))] :: ([] : List (ByteArray)))))) = UlebEvent.done (1) (({ parts := (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1))] :: ([] : List (ByteArray))), offset := 1, position := 1 } : Cursor))) := by
  rfl

public theorem uleb_127 : (runUleb (30) (startUleb (start ((_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 127))] :: ([] : List (ByteArray)))))) = UlebEvent.done (127) (({ parts := (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 127))] :: ([] : List (ByteArray))), offset := 1, position := 1 } : Cursor))) := by
  rfl

public theorem uleb_128 : (runUleb (30) (startUleb (start ((_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 1))] :: ([] : List (ByteArray)))))) = UlebEvent.done (128) (({ parts := (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 1))] :: ([] : List (ByteArray))), offset := 2, position := 2 } : Cursor))) := by
  rfl

public theorem uleb_16384 : (runUleb (30) (startUleb (start ((_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 1))] :: ([] : List (ByteArray)))))) = UlebEvent.done (16384) (({ parts := (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 1))] :: ([] : List (ByteArray))), offset := 3, position := 3 } : Cursor))) := by
  rfl

public theorem uleb_18446744073709551615 : (runUleb (30) (startUleb (start (((let __byte255 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 255); _root_.ByteArray.mk #[__byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, (_root_.UInt8.ofNat (nat_lit 1))]) :: ([] : List (ByteArray)))))) = UlebEvent.done (18446744073709551615) (({ parts := ((let __byte255 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 255); _root_.ByteArray.mk #[__byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, (_root_.UInt8.ofNat (nat_lit 1))]) :: ([] : List (ByteArray))), offset := 10, position := 10 } : Cursor))) := by
  rfl

public theorem uleb_across_empty_partitions : (runUleb (30) (startUleb (start ((_root_.ByteArray.mk #[] :: (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 128))] :: (_root_.ByteArray.mk #[] :: (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1))] :: ([] : List (ByteArray))))))))) = UlebEvent.done (128) (({ parts := (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1))] :: ([] : List (ByteArray))), offset := 1, position := 2 } : Cursor))) := by
  rfl

public theorem truncated : (runUleb (40) (startUleb (start ((_root_.ByteArray.mk #[] :: ([] : List (ByteArray)))))) = UlebEvent.failed (({ kind := ReadError.truncated, offset := 0 } : LocatedError))) := by
  rfl

public theorem truncated_continuation : (runUleb (40) (startUleb (start ((_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 128))] :: ([] : List (ByteArray)))))) = UlebEvent.failed (({ kind := ReadError.truncated, offset := 1 } : LocatedError))) := by
  rfl

public theorem overlong : (runUleb (40) (startUleb (start ((_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 0))] :: ([] : List (ByteArray)))))) = UlebEvent.failed (({ kind := ReadError.nonShortest, offset := 1 } : LocatedError))) := by
  rfl

public theorem terminal_overflow : (runUleb (40) (startUleb (start (((let __byte255 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 255); _root_.ByteArray.mk #[__byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, (_root_.UInt8.ofNat (nat_lit 2))]) :: ([] : List (ByteArray)))))) = UlebEvent.failed (({ kind := ReadError.overflow, offset := 9 } : LocatedError))) := by
  rfl

public theorem continuation_overflow : (runUleb (40) (startUleb (start (((let __byte128 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 128); _root_.ByteArray.mk #[__byte128, __byte128, __byte128, __byte128, __byte128, __byte128, __byte128, __byte128, __byte128, __byte128]) :: ([] : List (ByteArray)))))) = UlebEvent.failed (({ kind := ReadError.overflow, offset := 10 } : LocatedError))) := by
  rfl

end Uorc.Uorc.Wire.Cursor
