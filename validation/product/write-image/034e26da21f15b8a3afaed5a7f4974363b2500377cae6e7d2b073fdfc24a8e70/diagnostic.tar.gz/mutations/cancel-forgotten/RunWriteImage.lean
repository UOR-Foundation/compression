import Uorc.Uorc.Product.WriteImageScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !WriteImageScenarios.cancellationLatchControl then throw (IO.userError "FAIL cancellationLatchControl")
 IO.println "PASS cancellationLatchControl"
