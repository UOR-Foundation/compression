import Uorc.Uorc.Product.WriteImageScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !WriteImageScenarios.copyPrepaymentControl then throw (IO.userError "FAIL copyPrepaymentControl")
 IO.println "PASS copyPrepaymentControl"
