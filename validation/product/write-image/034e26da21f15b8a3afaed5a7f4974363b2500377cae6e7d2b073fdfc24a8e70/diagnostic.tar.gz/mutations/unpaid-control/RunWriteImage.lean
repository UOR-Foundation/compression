import Uorc.Uorc.Product.WriteImageScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !WriteImageScenarios.controlPrepaymentControl then throw (IO.userError "FAIL controlPrepaymentControl")
 IO.println "PASS controlPrepaymentControl"
