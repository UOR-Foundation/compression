import Uorc.Uorc.Product.WriteImageScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !WriteImageScenarios.staleSameRunReceiptControl then throw (IO.userError "FAIL staleSameRunReceiptControl")
 IO.println "PASS staleSameRunReceiptControl"
