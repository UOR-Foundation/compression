import Uorc.Uorc.Product.WriteImageScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !WriteImageScenarios.immutableAttachmentControl then throw (IO.userError "FAIL immutableAttachmentControl")
 IO.println "PASS immutableAttachmentControl"
