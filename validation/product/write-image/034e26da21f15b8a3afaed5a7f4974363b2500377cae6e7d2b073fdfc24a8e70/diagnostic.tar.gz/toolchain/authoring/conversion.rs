use std::{env,fs};
fn main() {
    for path in env::args().skip(1) {
        let text=fs::read_to_string(&path).expect("read source");
        let mut module=lexlean::sdk::read_module(&text).expect("official SDK reads data form");
        module["spec"]=serde_json::Value::String("lexlean/semantic-module/2".to_owned());
        let data=lexlean::sdk::write_module(&text,&module).expect("official SDK writes module");
        let notation=lexlean::sdk::to_notation(&data).expect("official SDK renders notation");
        assert_eq!(lexlean::sdk::read_module(&notation).expect("official SDK rereads notation"),module);
        fs::write(&path,notation.replace("lexlean.std.bool@1.1.0","lexlean.std.bool@1.2.0")).expect("write diagnostic projection");
    }
}
