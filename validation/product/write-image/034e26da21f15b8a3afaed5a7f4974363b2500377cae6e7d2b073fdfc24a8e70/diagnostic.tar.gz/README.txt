write-image frozen diagnostic checkpoint

Extract project inputs under project/, exact generated Lean under generation/modules/, and the three official SDK runtime modules under sdk-runtime/modules/. The actual VM harness and axiom query script are under runtime/. Results and five owning mutants are retained.

Use a matching LexLean/Lean toolchain from toolchain/identity.json. This archive does not ship tool binaries or claim pinned-SDK/native/Wasm/closed-archive acceptance. No qualification was rerun while packaging. Before-annotation inputs are accompanied by every prior generated Lean module to inspect byte equality.

Build 034e26da21f15b8a3afaed5a7f4974363b2500377cae6e7d2b073fdfc24a8e70
Source 3dae00e64a693a524f3fdecee1f35dc8981b741e0f3aac06af802f7358b5b2ec
Semantic 6598aaa91bb4e42897b3471f7b524e90730b907b659c1ab202387d72ddc0c199

The embedded build manifests may inventory compiler outputs beyond the Lean subset archived here; they are provenance records, not accepted-export receipts.
