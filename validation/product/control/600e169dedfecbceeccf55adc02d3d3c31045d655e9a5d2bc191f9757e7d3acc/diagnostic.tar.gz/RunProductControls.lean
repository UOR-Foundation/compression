import Uorc.Uorc.Product.Scenarios
open Uorc.Uorc.Product

def main : IO Unit := do
  let mut failures : Nat := 0
  let mut total : Nat := 0
  for c in Scenarios.cases do
    total := total + 1
    if !(Scenarios.runCase c) then
      failures := failures + 1
      IO.println s!"FAIL {c.id}"
  for o in Scenarios.observations do
    total := total + 1
    if !o.passed then
      failures := failures + 1
      IO.println s!"FAIL {o.id}"
  IO.println s!"{total - failures}/{total} product control and presentation scenarios passed"
  if total == 0 then throw (IO.userError "empty scenario inventory")
  if failures != 0 then throw (IO.userError "product scenarios failed")
