module
import Uorc.Uorc.Product.Session
#print axioms Uorc.Uorc.Product.Session.Phase
#print axioms Uorc.Uorc.Product.Session.ResultKind
#print axioms Uorc.Uorc.Product.Session.Session
#print axioms Uorc.Uorc.Product.Session.begin
#print axioms Uorc.Uorc.Product.Session.cancel
#print axioms Uorc.Uorc.Product.Session.cancel_invalidates_running_result
#print axioms Uorc.Uorc.Product.Session.completion_is_idempotent
#print axioms Uorc.Uorc.Product.Session.current_checked_result_has_download
#print axioms Uorc.Uorc.Product.Session.edit
#print axioms Uorc.Uorc.Product.Session.edit_invalidates_running_result
#print axioms Uorc.Uorc.Product.Session.failure_has_no_archive_download
#print axioms Uorc.Uorc.Product.Session.finish
#print axioms Uorc.Uorc.Product.Session.first_run_serial
#print axioms Uorc.Uorc.Product.Session.hasDownload
#print axioms Uorc.Uorc.Product.Session.initial
#print axioms Uorc.Uorc.Product.Session.initial_has_no_download
#print axioms Uorc.Uorc.Product.Session.inspection_has_no_archive_download
#print axioms Uorc.Uorc.Product.Session.late_wrong_revision_is_ignored
#print axioms Uorc.Uorc.Product.Session.ownsRun
#print axioms Uorc.Uorc.Product.Session.retry_invalidates_previous_result
