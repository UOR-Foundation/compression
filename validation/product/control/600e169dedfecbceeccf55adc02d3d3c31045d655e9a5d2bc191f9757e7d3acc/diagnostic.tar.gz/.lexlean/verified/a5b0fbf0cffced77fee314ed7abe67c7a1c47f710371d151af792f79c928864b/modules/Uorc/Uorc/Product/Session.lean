module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
namespace Uorc.Uorc.Product.Session

public inductive Phase where
  | idle
  | admitting
  | searching
  | verifying
  | complete
  | cancelled
  | failed

public inductive ResultKind where
  | none
  | inspection
  | checkedArchive
  | checkedReconstruction
  | checkedMinimum
  | failure

public structure Session where
  revision : Nat
  serial : Nat
  active : Bool
  hasResult : Bool
  phase : Phase
  result : ResultKind

@[expose] public def initial : Session := ({ revision := 0, serial := 0, active := false, hasResult := false, phase := Phase.idle, result := ResultKind.none } : Session)

@[expose] public def begin (s : Session) : Session := ({ revision := (s).revision, serial := ((s).serial + 1), active := true, hasResult := false, phase := Phase.admitting, result := ResultKind.none } : Session)

@[expose] public def edit (s : Session) : Session := ({ revision := ((s).revision + 1), serial := (s).serial, active := false, hasResult := false, phase := Phase.idle, result := ResultKind.none } : Session)

@[expose] public def cancel (s : Session) : Session := (if (s).active then ({ revision := (s).revision, serial := (s).serial, active := false, hasResult := false, phase := Phase.cancelled, result := ResultKind.none } : Session) else s)

@[expose] public def ownsRun (s : Session) (runSerial : Nat) (runRevision : Nat) : Bool := ((s).active && ((Nat.beq ((s).serial) (runSerial)) && ((Nat.beq ((s).revision) (runRevision)) && true)))

@[expose] public def finish (s : Session) (runSerial : Nat) (runRevision : Nat) (result : ResultKind) : Session := (if ownsRun (s) (runSerial) (runRevision) then ({ revision := (s).revision, serial := (s).serial, active := false, hasResult := true, phase := (match result with | ResultKind.none => Phase.failed | ResultKind.inspection => Phase.complete | ResultKind.checkedArchive => Phase.complete | ResultKind.checkedReconstruction => Phase.complete | ResultKind.checkedMinimum => Phase.complete | ResultKind.failure => Phase.failed), result := result } : Session) else s)

@[expose] public def hasDownload (s : Session) : Bool := ((s).hasResult && ((match (s).result with | ResultKind.none => false | ResultKind.inspection => false | ResultKind.checkedArchive => true | ResultKind.checkedReconstruction => true | ResultKind.checkedMinimum => true | ResultKind.failure => false) && true))

public theorem initial_has_no_download : (hasDownload (initial) = false) := by
  rfl

public theorem first_run_serial : ((begin (initial)).serial = 1) := by
  rfl

public theorem edit_invalidates_running_result : (finish (edit (begin (initial))) (1) (0) (ResultKind.checkedArchive) = edit (begin (initial))) := by
  rfl

public theorem cancel_invalidates_running_result : (finish (cancel (begin (initial))) (1) (0) (ResultKind.checkedArchive) = cancel (begin (initial))) := by
  rfl

public theorem retry_invalidates_previous_result : (finish (begin (begin (initial))) (1) (0) (ResultKind.checkedArchive) = begin (begin (initial))) := by
  rfl

public theorem current_checked_result_has_download : (hasDownload (finish (begin (initial)) (1) (0) (ResultKind.checkedArchive)) = true) := by
  rfl

public theorem inspection_has_no_archive_download : (hasDownload (finish (begin (initial)) (1) (0) (ResultKind.inspection)) = false) := by
  rfl

public theorem failure_has_no_archive_download : (hasDownload (finish (begin (initial)) (1) (0) (ResultKind.failure)) = false) := by
  rfl

public theorem late_wrong_revision_is_ignored : (finish (begin (initial)) (1) (1) (ResultKind.checkedArchive) = begin (initial)) := by
  rfl

public theorem completion_is_idempotent : (finish (finish (begin (initial)) (1) (0) (ResultKind.checkedArchive)) (1) (0) (ResultKind.failure) = finish (begin (initial)) (1) (0) (ResultKind.checkedArchive)) := by
  rfl

end Uorc.Uorc.Product.Session
