module
public import Init
public import Uorc.Uorc.Product.Evidence
public import Uorc.Uorc.Product.Storage
public import Uorc.Uorc.Product.StreamProtocol
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
namespace Uorc.Uorc.Product.Api

public structure ResourceRef where
  «instance» : Nat
  slot : Nat
  generation : Nat

public structure Span where
  resource : ResourceRef
  offset : Nat
  length : Nat

public structure Limits where
  decodeWork : Nat
  checkerWork : Nat
  replayWork : Nat
  searchWork : Nat
  outputBytes : Option (Nat)
  ownedBytes : Nat
  storage : Uorc.Uorc.Product.Storage.Limits

public structure Scope where
  identity : ByteArray
  domain : ResourceRef
  basis : Option (ResourceRef)
  limits : Limits

public inductive Certificate where
  | absent
  | «open» (_ : Scope)
  | failed (_ : Scope)
  | incomplete (_ : Scope)
  | checked (_ : Scope)

public inductive SearchStatus where
  | notRequested
  | running
  | effortEnded
  | exhausted
  | incomplete

public inductive ControlError where
  | busy
  | closed
  | detached
  | noRequest
  | noCheckpoint
  | noOutput
  | publicationPending
  | publicationUnknown
  | inputOrder
  | inputAfterEnd
  | noDemand
  | wrongInstance
  | invalidEffort
  | noPublicationPending
  | missingInput
  | missingArchive
  | missingComparison
  | invalidLimit

public inductive ResourceKind where
  | memory
  | work
  | output
  | handle
  | chunk

public inductive Failure where
  | malformedArchive (_ : Nat) (_ : String)
  | semanticDecode (_ : Nat) (_ : String)
  | missingBasis (_ : ByteArray)
  | wrongBasis (_ : ByteArray)
  | incompleteSearch
  | incompleteProof
  | resourceRefusal (_ : ResourceKind) (_ : Nat)
  | cancelled
  | inputIo (_ : String)
  | publicationIo (_ : Uorc.Uorc.Product.StreamProtocol.Publication) (_ : String)
  | control (_ : ControlError)
  | protocol (_ : Uorc.Uorc.Product.StreamProtocol.ProtocolError)
  | byteMismatch
  | verificationIncomplete
  | invalidCheckpoint (_ : String)
  | invalidReport (_ : String)
  | storage (_ : Uorc.Uorc.Product.Storage.Error)

public inductive HostFailure where
  | computeError
  | fatal
  | unknown

public structure Common where
  limits : Limits
  basis : Option (ResourceRef)

public structure CompressRequest where
  input : ResourceRef
  options : Common

public structure ArchiveRequest where
  archive : ResourceRef
  options : Common

public structure VerifyRequest where
  archive : ResourceRef
  originals : Option (ResourceRef)
  certificate : Option (ResourceRef)
  options : Common

public structure ResumeRequest where
  input : ResourceRef
  checkpoint : ResourceRef
  options : Common

public structure BasisRequest where
  input : ResourceRef
  options : Common

public structure FrontierRequest where
  input : ResourceRef
  incumbent : Option (ResourceRef)
  options : Common

public structure CompareRequest where
  left : ResourceRef
  right : ResourceRef
  originals : Option (ResourceRef)
  options : Common

public structure ToolRequest where
  input : ResourceRef
  options : Common

public inductive Request where
  | compress (_ : CompressRequest)
  | decompress (_ : ArchiveRequest)
  | inspect (_ : ArchiveRequest)
  | verify (_ : VerifyRequest)
  | resume (_ : ResumeRequest)
  | buildBasis (_ : BasisRequest)
  | analyzeFrontier (_ : FrontierRequest)
  | compare (_ : CompareRequest)
  | runAcceptance (_ : ToolRequest)
  | runCoreRequest (_ : ToolRequest)

public structure Progress where
  inputBytes : Nat
  objects : Nat
  candidates : Nat
  checkedCandidates : Nat
  work : Nat
  stage : String

public structure Run where
  «instance» : Nat
  serial : Nat
  revision : Nat

@[expose] public def operation (request : Request) : Uorc.Uorc.Product.Evidence.Operation := (match request with | Request.compress _ => Uorc.Uorc.Product.Evidence.Operation.compress | Request.decompress _ => Uorc.Uorc.Product.Evidence.Operation.decompress | Request.inspect _ => Uorc.Uorc.Product.Evidence.Operation.inspect | Request.verify _ => Uorc.Uorc.Product.Evidence.Operation.verify | Request.resume _ => Uorc.Uorc.Product.Evidence.Operation.resume | Request.buildBasis _ => Uorc.Uorc.Product.Evidence.Operation.buildBasis | Request.analyzeFrontier _ => Uorc.Uorc.Product.Evidence.Operation.analyzeFrontier | Request.compare _ => Uorc.Uorc.Product.Evidence.Operation.compare | Request.runAcceptance _ => Uorc.Uorc.Product.Evidence.Operation.runAcceptance | Request.runCoreRequest _ => Uorc.Uorc.Product.Evidence.Operation.runCoreRequest)

@[expose] public def options (request : Request) : Common := (match request with | Request.compress r => (r).options | Request.decompress r => (r).options | Request.inspect r => (r).options | Request.verify r => (r).options | Request.resume r => (r).options | Request.buildBasis r => (r).options | Request.analyzeFrontier r => (r).options | Request.compare r => (r).options | Request.runAcceptance r => (r).options | Request.runCoreRequest r => (r).options)

@[expose] public def certificateCheck (certificate : Certificate) : Uorc.Uorc.Product.Evidence.CertificateCheck := (match certificate with | Certificate.absent => Uorc.Uorc.Product.Evidence.CertificateCheck.absent | Certificate.«open» _ => Uorc.Uorc.Product.Evidence.CertificateCheck.incomplete | Certificate.failed _ => Uorc.Uorc.Product.Evidence.CertificateCheck.invalid | Certificate.incomplete _ => Uorc.Uorc.Product.Evidence.CertificateCheck.incomplete | Certificate.checked _ => Uorc.Uorc.Product.Evidence.CertificateCheck.valid)

@[expose] public def boundary : String := "ResourceRef is an adapter lease identified by instance, slot and generation. It carries actual charged bytes or a source-owned job, never a basis-name substitution. The host validates ownership and span extent before borrowing and accounts transferred roots. These pure request/admission roots do not execute an archive or establish observations. Native Library/V1 may return modeled Result inside the generated outer ComputeError; SDK errors are not UORC semantic decode failures. The persistent adapter remains a separate versioned contract."

@[expose] public def sameResource (left : ResourceRef) (right : ResourceRef) : Bool := ((Nat.beq ((left).«instance») ((right).«instance»)) && ((Nat.beq ((left).slot) ((right).slot)) && ((Nat.beq ((left).generation) ((right).generation)) && true)))

@[expose] public def originalsAvailable (request : Request) : Bool := (match request with | Request.compress _ => true | Request.decompress _ => false | Request.inspect _ => false | Request.verify r => (match (r).originals with | Option.none => false | Option.some _ => true) | Request.resume _ => true | Request.buildBasis _ => false | Request.analyzeFrontier _ => false | Request.compare r => (match (r).originals with | Option.none => false | Option.some _ => true) | Request.runAcceptance _ => false | Request.runCoreRequest _ => false)

public structure ArchiveSummary where
  formatIdentity : ByteArray
  profileIdentity : ByteArray
  integrityIdentity : ByteArray
  objects : Nat
  exactArchiveBytes : Nat
  externalBasisRequired : Bool

public structure BasisManifest where
  identity : ByteArray
  objects : Nat
  bytes : Nat

public structure FrontierReport where
  points : ResourceRef
  pointCount : Nat
  checkedPoints : Nat
  incompletePoints : Nat

public inductive SizeRelation where
  | leftSmaller
  | equal
  | rightSmaller

public structure DeveloperReport where
  sourceIdentity : ByteArray
  compilerIdentity : ByteArray
  sdkIdentity : ByteArray
  checks : Nat
  failures : Nat
  executed : Bool

public inductive PhysicalScope where
  | process
  | «instance»
  | host

public structure PhysicalObservation where
  rssBytes : Option (Nat)
  allocatedStorageBytes : Option (Nat)
  scope : PhysicalScope
  sequence : Nat

public structure Accounting where
  inputBytes : Nat
  exactArchiveBytes : Nat
  transportBytes : Nat
  externalBasisBytes : Nat
  basisTransferBytes : Nat
  decodeWork : Nat
  checkerWork : Nat
  replayWork : Nat
  searchWork : Nat
  peakOwnedBytes : Nat
  objects : Nat
  outputBytes : Nat
  storage : Uorc.Uorc.Product.Storage.Usage
  physical : Option (PhysicalObservation)

public structure ComparedArchive where
  accounting : Accounting
  facts : Uorc.Uorc.Product.Evidence.EvidenceFacts
  originalsAvailable : Bool
  certificate : Certificate

public structure ComparisonReport where
  left : ComparedArchive
  right : ComparedArchive
  originalsComparedEqual : Bool

public inductive Details where
  | archive (_ : ArchiveSummary)
  | reconstruction (_ : ArchiveSummary)
  | inspection (_ : ArchiveSummary)
  | verification (_ : Nat)
  | basis (_ : BasisManifest)
  | frontier (_ : FrontierReport)
  | comparison (_ : ComparisonReport)
  | developer (_ : DeveloperReport)

public structure Report where
  accounting : Accounting
  facts : Uorc.Uorc.Product.Evidence.EvidenceFacts
  boundariesComplete : Bool
  originalsAvailable : Bool
  finalCheck : Uorc.Uorc.Product.Evidence.FinalCheck
  certificate : Certificate
  search : SearchStatus
  artifactChecked : Bool
  output : Option (ResourceRef)
  details : Option (Details)

@[expose] public def admission (argOperation : Uorc.Uorc.Product.Evidence.Operation) (report : Report) : Uorc.Uorc.Product.Evidence.PublicationDecision := (match argOperation with | Uorc.Uorc.Product.Evidence.Operation.compress => (if (((report).facts).parsed && (((report).facts).integrityChecked && (((report).facts).executed && ((report).boundariesComplete && ((report).originalsAvailable && (((report).facts).originalCompared && true)))))) then Uorc.Uorc.Product.Evidence.publicationDecision ((report).finalCheck) (false) (certificateCheck ((report).certificate)) else Uorc.Uorc.Product.Evidence.PublicationDecision.verificationIncomplete) | Uorc.Uorc.Product.Evidence.Operation.decompress => Uorc.Uorc.Product.Evidence.decompressionPublicationDecision (((report).facts).parsed) (((report).facts).integrityChecked) (((report).facts).executed) ((report).boundariesComplete) (false) | Uorc.Uorc.Product.Evidence.Operation.inspect => (if ((report).facts).parsed then Uorc.Uorc.Product.Evidence.PublicationDecision.publish else Uorc.Uorc.Product.Evidence.PublicationDecision.verificationIncomplete) | Uorc.Uorc.Product.Evidence.Operation.verify => (if (report).originalsAvailable then (if (((report).facts).parsed && (((report).facts).integrityChecked && (((report).facts).executed && (((report).facts).originalCompared && ((report).boundariesComplete && true))))) then Uorc.Uorc.Product.Evidence.publicationDecision ((report).finalCheck) (false) (certificateCheck ((report).certificate)) else Uorc.Uorc.Product.Evidence.PublicationDecision.verificationIncomplete) else Uorc.Uorc.Product.Evidence.decompressionPublicationDecision (((report).facts).parsed) (((report).facts).integrityChecked) (((report).facts).executed) ((report).boundariesComplete) (false)) | Uorc.Uorc.Product.Evidence.Operation.resume => (if (((report).facts).parsed && (((report).facts).integrityChecked && (((report).facts).executed && ((report).boundariesComplete && ((report).originalsAvailable && (((report).facts).originalCompared && true)))))) then Uorc.Uorc.Product.Evidence.publicationDecision ((report).finalCheck) (false) (certificateCheck ((report).certificate)) else Uorc.Uorc.Product.Evidence.PublicationDecision.verificationIncomplete) | Uorc.Uorc.Product.Evidence.Operation.buildBasis => (if (report).artifactChecked then Uorc.Uorc.Product.Evidence.PublicationDecision.publish else Uorc.Uorc.Product.Evidence.PublicationDecision.verificationIncomplete) | Uorc.Uorc.Product.Evidence.Operation.analyzeFrontier => Uorc.Uorc.Product.Evidence.PublicationDecision.publish | Uorc.Uorc.Product.Evidence.Operation.compare => Uorc.Uorc.Product.Evidence.PublicationDecision.publish | Uorc.Uorc.Product.Evidence.Operation.runAcceptance => Uorc.Uorc.Product.Evidence.PublicationDecision.publish | Uorc.Uorc.Product.Evidence.Operation.runCoreRequest => Uorc.Uorc.Product.Evidence.PublicationDecision.publish)

@[expose] public def evidenceView (argOperation : Uorc.Uorc.Product.Evidence.Operation) (report : Report) : Uorc.Uorc.Product.Evidence.EvidenceView := Uorc.Uorc.Product.Evidence.presentEvidence (argOperation) ((report).originalsAvailable) (({ parsed := ((report).facts).parsed, integrityChecked := ((report).facts).integrityChecked, executed := (((report).facts).executed && ((report).boundariesComplete && true)), originalCompared := (((report).facts).originalCompared && ((match (report).finalCheck with | Uorc.Uorc.Product.Evidence.FinalCheck.equal => true | Uorc.Uorc.Product.Evidence.FinalCheck.different => false | Uorc.Uorc.Product.Evidence.FinalCheck.incomplete => false | Uorc.Uorc.Product.Evidence.FinalCheck.cancelled => false) && true)), certificateChecked := (((report).facts).certificateChecked && ((match certificateCheck ((report).certificate) with | Uorc.Uorc.Product.Evidence.CertificateCheck.absent => false | Uorc.Uorc.Product.Evidence.CertificateCheck.valid => true | Uorc.Uorc.Product.Evidence.CertificateCheck.invalid => false | Uorc.Uorc.Product.Evidence.CertificateCheck.incomplete => false) && true)) } : Uorc.Uorc.Product.Evidence.EvidenceFacts))

@[expose] public def bindReport (request : Request) (report : Report) : Report := ({ accounting := (report).accounting, facts := (report).facts, boundariesComplete := (report).boundariesComplete, originalsAvailable := originalsAvailable (request), finalCheck := (report).finalCheck, certificate := (report).certificate, search := (report).search, artifactChecked := (report).artifactChecked, output := (report).output, details := (report).details } : Report)

@[expose] public def compareExactArchiveBytes (left : Accounting) (right : Accounting) : SizeRelation := (if (Nat.blt ((left).exactArchiveBytes) ((right).exactArchiveBytes)) then SizeRelation.leftSmaller else (if (Nat.beq ((left).exactArchiveBytes) ((right).exactArchiveBytes)) then SizeRelation.equal else SizeRelation.rightSmaller))

@[expose] public def archivePlusBasisTransfer (accounting : Accounting) : Nat := ((accounting).exactArchiveBytes + (accounting).basisTransferBytes)

public theorem archive_basis_transfer_is_explicit (accounting : Accounting) : (archivePlusBasisTransfer (accounting) = ((accounting).exactArchiveBytes + (accounting).basisTransferBytes)) := by
  rfl

public structure FailureReport where
  failure : Failure
  achieved : Accounting
  publication : Uorc.Uorc.Product.StreamProtocol.Publication

public inductive CustodyReason where
  | «open»
  | pendingIo
  | imageTicket
  | storage
  | resourceLease
  | job
  | arena
  | receipt
  | effect
  | quarantine

public inductive ReleaseDisposition where
  | retain (_ : CustodyReason)
  | releasable

end Uorc.Uorc.Product.Api
