module
import Uorc.Uorc.Product.Selection
#print axioms Uorc.Uorc.Product.Selection.Item
#print axioms Uorc.Uorc.Product.Selection.boundary
#print axioms Uorc.Uorc.Product.Selection.contains
#print axioms Uorc.Uorc.Product.Selection.count
#print axioms Uorc.Uorc.Product.Selection.find
#print axioms Uorc.Uorc.Product.Selection.insertAt
#print axioms Uorc.Uorc.Product.Selection.moveTo
#print axioms Uorc.Uorc.Product.Selection.remove
#print axioms Uorc.Uorc.Product.Selection.sameOrder
#print axioms Uorc.Uorc.Product.Selection.valid
#print axioms Uorc.Uorc.Product.Selection.valid_cons_binding
