module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
namespace Uorc.Uorc.Product.Storage

namespace LexLeanRuntime

public class ToMathInt (α : Type) where
  toInt : α -> Int

public class Fixed (α : Type) extends ToMathInt α where
  fromInt : Int -> α
  minimum : Int
  maximum : Int
  bitAnd : α -> α -> α
  bitOr : α -> α -> α
  bitXor : α -> α -> α
  bitNot : α -> α
  shiftLeft : α -> UInt32 -> Option α
  shiftRight : α -> UInt32 -> Option α

public instance : ToMathInt Int where toInt := fun value => value

public instance : Fixed Int8 where
  toInt := Int8.toInt
  fromInt := Int8.ofInt
  minimum := -128
  maximum := 127
  bitAnd := Int8.land
  bitOr := Int8.lor
  bitXor := Int8.xor
  bitNot := Int8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (Int8.shiftLeft value (Int8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (Int8.shiftRight value (Int8.ofNat amount.toNat)) else none

public instance : Fixed Int16 where
  toInt := Int16.toInt
  fromInt := Int16.ofInt
  minimum := -32768
  maximum := 32767
  bitAnd := Int16.land
  bitOr := Int16.lor
  bitXor := Int16.xor
  bitNot := Int16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (Int16.shiftLeft value (Int16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (Int16.shiftRight value (Int16.ofNat amount.toNat)) else none

public instance : Fixed Int32 where
  toInt := Int32.toInt
  fromInt := Int32.ofInt
  minimum := -2147483648
  maximum := 2147483647
  bitAnd := Int32.land
  bitOr := Int32.lor
  bitXor := Int32.xor
  bitNot := Int32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (Int32.shiftLeft value (Int32.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (Int32.shiftRight value (Int32.ofNat amount.toNat)) else none

public instance : Fixed Int64 where
  toInt := Int64.toInt
  fromInt := Int64.ofInt
  minimum := -9223372036854775808
  maximum := 9223372036854775807
  bitAnd := Int64.land
  bitOr := Int64.lor
  bitXor := Int64.xor
  bitNot := Int64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (Int64.shiftLeft value (Int64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (Int64.shiftRight value (Int64.ofNat amount.toNat)) else none

public instance : Fixed UInt8 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt8.ofInt
  minimum := 0
  maximum := 255
  bitAnd := UInt8.land
  bitOr := UInt8.lor
  bitXor := UInt8.xor
  bitNot := UInt8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (UInt8.shiftLeft value (UInt8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (UInt8.shiftRight value (UInt8.ofNat amount.toNat)) else none

public instance : Fixed UInt16 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt16.ofInt
  minimum := 0
  maximum := 65535
  bitAnd := UInt16.land
  bitOr := UInt16.lor
  bitXor := UInt16.xor
  bitNot := UInt16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (UInt16.shiftLeft value (UInt16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (UInt16.shiftRight value (UInt16.ofNat amount.toNat)) else none

public instance : Fixed UInt32 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt32.ofInt
  minimum := 0
  maximum := 4294967295
  bitAnd := UInt32.land
  bitOr := UInt32.lor
  bitXor := UInt32.xor
  bitNot := UInt32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (UInt32.shiftLeft value amount) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (UInt32.shiftRight value amount) else none

public instance : Fixed UInt64 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt64.ofInt
  minimum := 0
  maximum := 18446744073709551615
  bitAnd := UInt64.land
  bitOr := UInt64.lor
  bitXor := UInt64.xor
  bitNot := UInt64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (UInt64.shiftLeft value (UInt64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (UInt64.shiftRight value (UInt64.ofNat amount.toNat)) else none

@[expose] public def checkedFromInt {α : Type} [Fixed α] (value : Int) : Option α :=
  if value < Fixed.minimum (α := α) then none else if Fixed.maximum (α := α) < value then none else some (Fixed.fromInt value)

@[expose] public def checkedConvert {α β : Type} [ToMathInt α] [Fixed β] (value : α) : Option β :=
  checkedFromInt (ToMathInt.toInt value)

@[expose] public def checkedAdd {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left + ToMathInt.toInt right)

@[expose] public def checkedSubtract {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left - ToMathInt.toInt right)

@[expose] public def checkedMultiply {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left * ToMathInt.toInt right)

@[expose] public def checkedNegate {α : Type} [Fixed α] (value : α) : Option α :=
  checkedFromInt (-ToMathInt.toInt value)

@[expose] public def checkedQuotient {α : Type} [Fixed α] (left right : α) : Option α :=
  if ToMathInt.toInt right = 0 then none else checkedFromInt (Int.tdiv (ToMathInt.toInt left) (ToMathInt.toInt right))

@[expose] public def checkedAddInt64 (left right : Int64) : Option Int64 :=
  let value := left + right
  if (0 < right && value < left) || (right < 0 && left < value) then none else some value

@[expose] public def checkedSubtractInt64 (left right : Int64) : Option Int64 :=
  let value := left - right
  if (0 < right && left < value) || (right < 0 && value < left) then none else some value

@[expose] public def checkedNegateInt64 (value : Int64) : Option Int64 :=
  if value == (-9223372036854775808 : Int64) then none else some (-value)

public def magnitudeInt64 (value : Int64) : UInt64 :=
  let bits := value.toUInt64
  if value < 0 then 0 - bits else bits

public def signedMagnitudeInt64 (negative : Bool) (value : UInt64) : Int64 :=
  (if negative then 0 - value else value).toInt64

public def divideMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> UInt64 -> UInt64
  | 0, _, _, _, quotient => quotient
  | Nat.succ fuel, source, divisor, remainder, quotient =>
      let high := 9223372036854775808 <= source
      let source := source + source
      let remainder := remainder + remainder + if high then 1 else 0
      let quotient := quotient + quotient
      if divisor <= remainder then
        divideMagnitudeInt64 fuel source divisor (remainder - divisor) (quotient + 1)
      else
        divideMagnitudeInt64 fuel source divisor remainder quotient

@[expose] public def checkedQuotientInt64 (left right : Int64) : Option Int64 :=
  if right == 0 then none
  else if left == (-9223372036854775808 : Int64) && right == (-1 : Int64) then none
  else
    let negative := (left < 0) != (right < 0)
    some (signedMagnitudeInt64 negative
      (divideMagnitudeInt64 64 (magnitudeInt64 left) (magnitudeInt64 right) 0 0))

public def multiplyMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> Bool -> Option UInt64
  | 0, _, _, accumulator, _ => some accumulator
  | Nat.succ fuel, source, multiplicand, accumulator, negative =>
      let high := 9223372036854775808 <= source
      let limit := if negative then 9223372036854775808 else 9223372036854775807
      let halfLimit := if negative then 4611686018427387904 else 4611686018427387903
      if halfLimit < accumulator then none
      else
        let doubled := accumulator + accumulator
        if high then
          if limit < multiplicand || limit - multiplicand < doubled then none
          else multiplyMagnitudeInt64 fuel (source + source) multiplicand
            (doubled + multiplicand) negative
        else
          multiplyMagnitudeInt64 fuel (source + source) multiplicand doubled negative

@[expose] public def checkedMultiplyInt64 (left right : Int64) : Option Int64 :=
  let negative := (left < 0) != (right < 0)
  match multiplyMagnitudeInt64 64 (magnitudeInt64 right) (magnitudeInt64 left) 0 negative with
  | none => none
  | some value => some (signedMagnitudeInt64 negative value)

@[noinline] public def subtract {α : Type} [Sub α] (left right : α) : α := left - right
@[noinline] public def multiply {α : Type} [Mul α] (left right : α) : α := left * right
@[noinline] public def negate {α : Type} [Neg α] (value : α) : α := -value

public class Quotient (α : Type) where
  quotient : α -> α -> α
  remainder : α -> α -> α
  isZero : α -> Bool

public instance : Quotient Nat where
  quotient := Nat.div
  remainder := Nat.mod
  isZero := fun value => value == 0

public instance : Quotient Int where
  quotient := Int.tdiv
  remainder := Int.tmod
  isZero := fun value => value == 0

@[noinline] public def quotient {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.quotient left right

@[noinline] public def remainder {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.remainder left right

@[expose] public def bitAnd {α : Type} [Fixed α] (left right : α) : α := Fixed.bitAnd left right
@[expose] public def bitOr {α : Type} [Fixed α] (left right : α) : α := Fixed.bitOr left right
@[expose] public def bitXor {α : Type} [Fixed α] (left right : α) : α := Fixed.bitXor left right
@[expose] public def bitNot {α : Type} [Fixed α] (value : α) : α := Fixed.bitNot value
@[expose] public def shiftLeft {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftLeft value amount
@[expose] public def shiftRight {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftRight value amount

public class Appendable (α : Type) where append : α -> α -> α
public instance {α : Type} : Appendable (List α) where append := List.append
public instance : Appendable ByteArray where append := ByteArray.append
@[expose] public def append {α : Type} [Appendable α] (left right : α) : α := Appendable.append left right

public class Lengthable (α : Type) where length : α -> Nat
public instance {α : Type} : Lengthable (List α) where length := List.length
public instance : Lengthable ByteArray where length := ByteArray.size
public instance : Lengthable String where length := String.length
@[expose] public def length {α : Type} [Lengthable α] (value : α) : Nat := Lengthable.length value

@[expose] public def listIndex {α : Type} : List α -> Nat -> Option α
  | [], _ => none
  | head :: _, 0 => some head
  | _ :: tail, index + 1 => listIndex tail index

public class Indexable (α β : Type) where index : α -> Nat -> Option β
public instance {α : Type} : Indexable (List α) α where index := listIndex
public instance : Indexable ByteArray UInt8 where index := fun value offset => value.data[offset]?
@[noinline] public def index {α β : Type} [Indexable α β] (value : α) (offset : Nat) : Option β := Indexable.index value offset

public class Sliceable (α : Type) where slice : α -> Nat -> Nat -> Option α
public instance {α : Type} : Sliceable (List α) where
  slice := fun value start count => if start + count <= value.length then some ((value.drop start).take count) else none
public instance : Sliceable ByteArray where
  slice := fun value start count => if start + count <= value.size then some (value.extract start (start + count)) else none
@[noinline] public def slice {α : Type} [Sliceable α] (value : α) (start count : Nat) : Option α := Sliceable.slice value start count

@[noinline] public def utf8Encode (value : String) : ByteArray := value.toUTF8
@[noinline] public def utf8Decode (value : ByteArray) : Option String := String.fromUTF8? value
@[noinline] public def compareBytes (left right : ByteArray) : Ordering := compare left.toList right.toList
@[expose] public def equal {α : Type} [BEq α] (left right : α) : Bool := left == right

@[noinline] public def splitExact (value delimiter : String) (maximum : UInt32) : Option (List String) :=
  let fields := value.splitOn delimiter
  if delimiter.isEmpty || maximum.toNat < fields.length then none else some fields

@[noinline] public def join (values : List String) (delimiter : String) : String := delimiter.intercalate values

public class Decimal (α : Type) where
  parse : String -> Option α
  format : α -> String

public instance : Decimal Int where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then some parsed else none | none => none
  format := toString

public instance {α : Type} [Fixed α] [ToString α] : Decimal α where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then checkedFromInt parsed else none | none => none
  format := toString

@[noinline] public def parseDecimal {α : Type} [Decimal α] (value : String) : Option α := Decimal.parse value
@[noinline] public def formatDecimal {α : Type} [Decimal α] (value : α) : String := Decimal.format value

end LexLeanRuntime

public inductive Category where
  | stagedOutput
  | inputSpool
  | spill
  | publicationCopy

public structure Amounts where
  stagedOutput : Nat
  inputSpool : Nat
  spill : Nat
  publicationCopy : Nat

public structure Limits where
  total : Option (Nat)
  stagedOutput : Option (Nat)
  inputSpool : Option (Nat)
  spill : Option (Nat)
  publicationCopy : Option (Nat)

public structure Usage where
  retained : Amounts
  reserved : Amounts
  peakRetainedBytes : Nat
  peakAdmittedBytes : Nat

public inductive Error where
  | quotaTotal (_ : Nat) (_ : Nat) (_ : Nat)
  | quotaCategory (_ : Category) (_ : Nat) (_ : Nat) (_ : Nat)
  | reservationExtent (_ : Category) (_ : Nat) (_ : Nat)
  | releaseExtent (_ : Category) (_ : Nat) (_ : Nat)

public structure State where
  usage : Usage
  error : Option (Error)

public inductive Event where
  | reserve (_ : Category) (_ : Nat)
  | written (_ : Category) (_ : Nat) (_ : Nat)
  | failedWrite (_ : Category) (_ : Nat) (_ : Nat)
  | release (_ : Category) (_ : Nat)
  | transfer (_ : Category) (_ : Nat)

@[expose] public def zeroAmounts : Amounts := ({ stagedOutput := 0, inputSpool := 0, spill := 0, publicationCopy := 0 } : Amounts)

@[expose] public def unlimitedRequest : Limits := ({ total := Option.none, stagedOutput := Option.none, inputSpool := Option.none, spill := Option.none, publicationCopy := Option.none } : Limits)

@[expose] public def zeroUsage : Usage := ({ retained := zeroAmounts, reserved := zeroAmounts, peakRetainedBytes := 0, peakAdmittedBytes := 0 } : Usage)

@[expose] public def initial : State := ({ usage := zeroUsage, error := Option.none } : State)

@[expose] public def totalAmounts (amounts : Amounts) : Nat := ((((0 + (amounts).stagedOutput) + (amounts).inputSpool) + (amounts).spill) + (amounts).publicationCopy)

@[expose] public def retainedBytes (usage : Usage) : Nat := totalAmounts ((usage).retained)

@[expose] public def reservedBytes (usage : Usage) : Nat := totalAmounts ((usage).reserved)

@[expose] public def admittedBytes (usage : Usage) : Nat := (retainedBytes (usage) + reservedBytes (usage))

@[expose] public def amount (amounts : Amounts) (category : Category) : Nat := (match category with | Category.stagedOutput => (amounts).stagedOutput | Category.inputSpool => (amounts).inputSpool | Category.spill => (amounts).spill | Category.publicationCopy => (amounts).publicationCopy)

@[expose] public def limit (limits : Limits) (category : Category) : Option (Nat) := (match category with | Category.stagedOutput => (limits).stagedOutput | Category.inputSpool => (limits).inputSpool | Category.spill => (limits).spill | Category.publicationCopy => (limits).publicationCopy)

@[expose] public def setAmount (amounts : Amounts) (category : Category) (bytes : Nat) : Amounts := (match category with | Category.stagedOutput => ({ stagedOutput := bytes, inputSpool := (amounts).inputSpool, spill := (amounts).spill, publicationCopy := (amounts).publicationCopy } : Amounts) | Category.inputSpool => ({ stagedOutput := (amounts).stagedOutput, inputSpool := bytes, spill := (amounts).spill, publicationCopy := (amounts).publicationCopy } : Amounts) | Category.spill => ({ stagedOutput := (amounts).stagedOutput, inputSpool := (amounts).inputSpool, spill := bytes, publicationCopy := (amounts).publicationCopy } : Amounts) | Category.publicationCopy => ({ stagedOutput := (amounts).stagedOutput, inputSpool := (amounts).inputSpool, spill := (amounts).spill, publicationCopy := bytes } : Amounts))

@[expose] public def maximum (left : Nat) (right : Nat) : Nat := (if (Nat.blt (left) (right)) then right else left)

@[expose] public def fits (argLimit : Option (Nat)) (used : Nat) (increase : Nat) : Bool := (match argLimit with | Option.none => true | Option.some bindingMaximum => (!(Nat.blt (bindingMaximum) ((used + increase)))))

@[expose] public def reserve (limits : Limits) (usage : Usage) (category : Category) (bytes : Nat) : Except (Error) (Usage) := (if fits ((limits).total) (admittedBytes (usage)) (bytes) then (if fits (limit (limits) (category)) ((amount ((usage).retained) (category) + amount ((usage).reserved) (category))) (bytes) then Except.ok (({ retained := (usage).retained, reserved := setAmount ((usage).reserved) (category) ((amount ((usage).reserved) (category) + bytes)), peakRetainedBytes := maximum ((usage).peakRetainedBytes) (totalAmounts ((usage).retained)), peakAdmittedBytes := maximum ((usage).peakAdmittedBytes) ((totalAmounts ((usage).retained) + totalAmounts (setAmount ((usage).reserved) (category) ((amount ((usage).reserved) (category) + bytes))))) } : Usage)) else Except.error (Error.quotaCategory (category) ((amount ((usage).retained) (category) + amount ((usage).reserved) (category))) (bytes) ((match limit (limits) (category) with | Option.none => 0 | Option.some bindingMaximum => bindingMaximum)))) else Except.error (Error.quotaTotal (admittedBytes (usage)) (bytes) ((match (limits).total with | Option.none => 0 | Option.some bindingMaximum => bindingMaximum))))

@[expose] public def recordWrite (usage : Usage) (category : Category) (reservation : Nat) (achieved : Nat) : Except (Error) (Usage) := (if ((!(Nat.blt (amount ((usage).reserved) (category)) (reservation))) && ((!(Nat.blt (reservation) (achieved))) && true)) then Except.ok (({ retained := setAmount ((usage).retained) (category) ((amount ((usage).retained) (category) + achieved)), reserved := setAmount ((usage).reserved) (category) ((LexLeanRuntime.subtract (amount ((usage).reserved) (category)) (reservation) : Nat)), peakRetainedBytes := maximum ((usage).peakRetainedBytes) (totalAmounts (setAmount ((usage).retained) (category) ((amount ((usage).retained) (category) + achieved)))), peakAdmittedBytes := maximum ((usage).peakAdmittedBytes) ((totalAmounts (setAmount ((usage).retained) (category) ((amount ((usage).retained) (category) + achieved))) + totalAmounts (setAmount ((usage).reserved) (category) ((LexLeanRuntime.subtract (amount ((usage).reserved) (category)) (reservation) : Nat))))) } : Usage)) else Except.error (Error.reservationExtent (category) (reservation) (achieved)))

@[expose] public def release (usage : Usage) (category : Category) (bytes : Nat) : Except (Error) (Usage) := (if (!(Nat.blt (amount ((usage).retained) (category)) (bytes))) then Except.ok (({ retained := setAmount ((usage).retained) (category) ((LexLeanRuntime.subtract (amount ((usage).retained) (category)) (bytes) : Nat)), reserved := (usage).reserved, peakRetainedBytes := maximum ((usage).peakRetainedBytes) (totalAmounts (setAmount ((usage).retained) (category) ((LexLeanRuntime.subtract (amount ((usage).retained) (category)) (bytes) : Nat)))), peakAdmittedBytes := maximum ((usage).peakAdmittedBytes) ((totalAmounts (setAmount ((usage).retained) (category) ((LexLeanRuntime.subtract (amount ((usage).retained) (category)) (bytes) : Nat))) + totalAmounts ((usage).reserved))) } : Usage)) else Except.error (Error.releaseExtent (category) (amount ((usage).retained) (category)) (bytes)))

@[expose] public def step (limits : Limits) (state : State) (event : Event) : State := (match event with | Event.reserve category bytes => (match reserve (limits) ((state).usage) (category) (bytes) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)) | Event.written category reservation achieved => (match recordWrite ((state).usage) (category) (reservation) (achieved) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)) | Event.failedWrite category reservation achieved => (match recordWrite ((state).usage) (category) (reservation) (achieved) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)) | Event.release category bytes => (match release ((state).usage) (category) (bytes) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)) | Event.transfer category bytes => (match release ((state).usage) (category) (bytes) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)))

@[expose] public def run : (limits : Limits) -> (state : State) -> (events : List (Event)) -> State
  | _limits, state, List.nil => state
  | limits, state, List.cons head tail => run (limits) (step (limits) (state) (head)) (tail)

@[expose] public def controls : Bool := ((Nat.beq (retainedBytes ((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.failedWrite (Category.stagedOutput) (100) (37) :: ([] : List (Event)))))).usage)) (37)) && ((Nat.beq (reservedBytes ((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.failedWrite (Category.stagedOutput) (100) (37) :: ([] : List (Event)))))).usage)) (0)) && ((Nat.beq (((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.failedWrite (Category.stagedOutput) (100) (37) :: ([] : List (Event)))))).usage).peakAdmittedBytes) (100)) && ((Nat.beq (((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.failedWrite (Category.stagedOutput) (100) (37) :: ([] : List (Event)))))).usage).peakRetainedBytes) (37)) && ((match (run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (101) :: ([] : List (Event))))).error with | Option.none => false | Option.some _ => true) && ((Nat.beq (admittedBytes ((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (101) :: ([] : List (Event))))).usage)) (0)) && ((Nat.beq (retainedBytes ((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.written (Category.stagedOutput) (100) (80) :: (Event.transfer (Category.stagedOutput) (80) :: ([] : List (Event))))))).usage)) (0)) && ((Nat.beq (((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.written (Category.stagedOutput) (100) (80) :: (Event.transfer (Category.stagedOutput) (80) :: ([] : List (Event))))))).usage).peakRetainedBytes) (80)) && ((match (run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.release (Category.stagedOutput) (1) :: ([] : List (Event))))).error with | Option.none => false | Option.some _ => true) && ((match (run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.written (Category.stagedOutput) (1) (1) :: ([] : List (Event))))).error with | Option.none => false | Option.some _ => true) && true))))))))))

@[expose] public def boundary : String := "This ledger accounts unique product-owned storage allocations and reservations, separately from logical arena bytes. Requested None quotas impose no additional product size ceiling; actual host storage admission is still required. The source-owned adapter validates the reservation lease and exactly-once acknowledgment before applying these counter transitions. A partial failed write records achieved retained bytes and releases only its unused reservation. Custody transfer does not allocate another copy; a copy requires a separately admitted publicationCopy allocation. Physical RSS and physical storage observations are optional measurements, not inferred from these counters."

@[expose] public def sameUsage (left : Usage) (right : Usage) : Bool := ((Nat.beq (((left).retained).stagedOutput) (((right).retained).stagedOutput)) && ((Nat.beq (((left).retained).inputSpool) (((right).retained).inputSpool)) && ((Nat.beq (((left).retained).spill) (((right).retained).spill)) && ((Nat.beq (((left).retained).publicationCopy) (((right).retained).publicationCopy)) && ((Nat.beq (((left).reserved).stagedOutput) (((right).reserved).stagedOutput)) && ((Nat.beq (((left).reserved).inputSpool) (((right).reserved).inputSpool)) && ((Nat.beq (((left).reserved).spill) (((right).reserved).spill)) && ((Nat.beq (((left).reserved).publicationCopy) (((right).reserved).publicationCopy)) && ((Nat.beq ((left).peakRetainedBytes) ((right).peakRetainedBytes)) && ((Nat.beq ((left).peakAdmittedBytes) ((right).peakAdmittedBytes)) && true))))))))))

end Uorc.Uorc.Product.Storage
