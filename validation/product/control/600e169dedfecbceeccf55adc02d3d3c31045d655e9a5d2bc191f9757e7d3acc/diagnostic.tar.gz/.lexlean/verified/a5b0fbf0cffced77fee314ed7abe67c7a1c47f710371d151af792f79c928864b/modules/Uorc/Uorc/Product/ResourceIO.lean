module
public import Init
public import Uorc.Uorc.Product.Api
public import Uorc.Uorc.Product.Storage
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
namespace Uorc.Uorc.Product.ResourceIO

namespace LexLeanRuntime

public class ToMathInt (α : Type) where
  toInt : α -> Int

public class Fixed (α : Type) extends ToMathInt α where
  fromInt : Int -> α
  minimum : Int
  maximum : Int
  bitAnd : α -> α -> α
  bitOr : α -> α -> α
  bitXor : α -> α -> α
  bitNot : α -> α
  shiftLeft : α -> UInt32 -> Option α
  shiftRight : α -> UInt32 -> Option α

public instance : ToMathInt Int where toInt := fun value => value

public instance : Fixed Int8 where
  toInt := Int8.toInt
  fromInt := Int8.ofInt
  minimum := -128
  maximum := 127
  bitAnd := Int8.land
  bitOr := Int8.lor
  bitXor := Int8.xor
  bitNot := Int8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (Int8.shiftLeft value (Int8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (Int8.shiftRight value (Int8.ofNat amount.toNat)) else none

public instance : Fixed Int16 where
  toInt := Int16.toInt
  fromInt := Int16.ofInt
  minimum := -32768
  maximum := 32767
  bitAnd := Int16.land
  bitOr := Int16.lor
  bitXor := Int16.xor
  bitNot := Int16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (Int16.shiftLeft value (Int16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (Int16.shiftRight value (Int16.ofNat amount.toNat)) else none

public instance : Fixed Int32 where
  toInt := Int32.toInt
  fromInt := Int32.ofInt
  minimum := -2147483648
  maximum := 2147483647
  bitAnd := Int32.land
  bitOr := Int32.lor
  bitXor := Int32.xor
  bitNot := Int32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (Int32.shiftLeft value (Int32.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (Int32.shiftRight value (Int32.ofNat amount.toNat)) else none

public instance : Fixed Int64 where
  toInt := Int64.toInt
  fromInt := Int64.ofInt
  minimum := -9223372036854775808
  maximum := 9223372036854775807
  bitAnd := Int64.land
  bitOr := Int64.lor
  bitXor := Int64.xor
  bitNot := Int64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (Int64.shiftLeft value (Int64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (Int64.shiftRight value (Int64.ofNat amount.toNat)) else none

public instance : Fixed UInt8 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt8.ofInt
  minimum := 0
  maximum := 255
  bitAnd := UInt8.land
  bitOr := UInt8.lor
  bitXor := UInt8.xor
  bitNot := UInt8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (UInt8.shiftLeft value (UInt8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (UInt8.shiftRight value (UInt8.ofNat amount.toNat)) else none

public instance : Fixed UInt16 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt16.ofInt
  minimum := 0
  maximum := 65535
  bitAnd := UInt16.land
  bitOr := UInt16.lor
  bitXor := UInt16.xor
  bitNot := UInt16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (UInt16.shiftLeft value (UInt16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (UInt16.shiftRight value (UInt16.ofNat amount.toNat)) else none

public instance : Fixed UInt32 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt32.ofInt
  minimum := 0
  maximum := 4294967295
  bitAnd := UInt32.land
  bitOr := UInt32.lor
  bitXor := UInt32.xor
  bitNot := UInt32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (UInt32.shiftLeft value amount) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (UInt32.shiftRight value amount) else none

public instance : Fixed UInt64 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt64.ofInt
  minimum := 0
  maximum := 18446744073709551615
  bitAnd := UInt64.land
  bitOr := UInt64.lor
  bitXor := UInt64.xor
  bitNot := UInt64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (UInt64.shiftLeft value (UInt64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (UInt64.shiftRight value (UInt64.ofNat amount.toNat)) else none

@[expose] public def checkedFromInt {α : Type} [Fixed α] (value : Int) : Option α :=
  if value < Fixed.minimum (α := α) then none else if Fixed.maximum (α := α) < value then none else some (Fixed.fromInt value)

@[expose] public def checkedConvert {α β : Type} [ToMathInt α] [Fixed β] (value : α) : Option β :=
  checkedFromInt (ToMathInt.toInt value)

@[expose] public def checkedAdd {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left + ToMathInt.toInt right)

@[expose] public def checkedSubtract {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left - ToMathInt.toInt right)

@[expose] public def checkedMultiply {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left * ToMathInt.toInt right)

@[expose] public def checkedNegate {α : Type} [Fixed α] (value : α) : Option α :=
  checkedFromInt (-ToMathInt.toInt value)

@[expose] public def checkedQuotient {α : Type} [Fixed α] (left right : α) : Option α :=
  if ToMathInt.toInt right = 0 then none else checkedFromInt (Int.tdiv (ToMathInt.toInt left) (ToMathInt.toInt right))

@[expose] public def checkedAddInt64 (left right : Int64) : Option Int64 :=
  let value := left + right
  if (0 < right && value < left) || (right < 0 && left < value) then none else some value

@[expose] public def checkedSubtractInt64 (left right : Int64) : Option Int64 :=
  let value := left - right
  if (0 < right && left < value) || (right < 0 && value < left) then none else some value

@[expose] public def checkedNegateInt64 (value : Int64) : Option Int64 :=
  if value == (-9223372036854775808 : Int64) then none else some (-value)

public def magnitudeInt64 (value : Int64) : UInt64 :=
  let bits := value.toUInt64
  if value < 0 then 0 - bits else bits

public def signedMagnitudeInt64 (negative : Bool) (value : UInt64) : Int64 :=
  (if negative then 0 - value else value).toInt64

public def divideMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> UInt64 -> UInt64
  | 0, _, _, _, quotient => quotient
  | Nat.succ fuel, source, divisor, remainder, quotient =>
      let high := 9223372036854775808 <= source
      let source := source + source
      let remainder := remainder + remainder + if high then 1 else 0
      let quotient := quotient + quotient
      if divisor <= remainder then
        divideMagnitudeInt64 fuel source divisor (remainder - divisor) (quotient + 1)
      else
        divideMagnitudeInt64 fuel source divisor remainder quotient

@[expose] public def checkedQuotientInt64 (left right : Int64) : Option Int64 :=
  if right == 0 then none
  else if left == (-9223372036854775808 : Int64) && right == (-1 : Int64) then none
  else
    let negative := (left < 0) != (right < 0)
    some (signedMagnitudeInt64 negative
      (divideMagnitudeInt64 64 (magnitudeInt64 left) (magnitudeInt64 right) 0 0))

public def multiplyMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> Bool -> Option UInt64
  | 0, _, _, accumulator, _ => some accumulator
  | Nat.succ fuel, source, multiplicand, accumulator, negative =>
      let high := 9223372036854775808 <= source
      let limit := if negative then 9223372036854775808 else 9223372036854775807
      let halfLimit := if negative then 4611686018427387904 else 4611686018427387903
      if halfLimit < accumulator then none
      else
        let doubled := accumulator + accumulator
        if high then
          if limit < multiplicand || limit - multiplicand < doubled then none
          else multiplyMagnitudeInt64 fuel (source + source) multiplicand
            (doubled + multiplicand) negative
        else
          multiplyMagnitudeInt64 fuel (source + source) multiplicand doubled negative

@[expose] public def checkedMultiplyInt64 (left right : Int64) : Option Int64 :=
  let negative := (left < 0) != (right < 0)
  match multiplyMagnitudeInt64 64 (magnitudeInt64 right) (magnitudeInt64 left) 0 negative with
  | none => none
  | some value => some (signedMagnitudeInt64 negative value)

@[noinline] public def subtract {α : Type} [Sub α] (left right : α) : α := left - right
@[noinline] public def multiply {α : Type} [Mul α] (left right : α) : α := left * right
@[noinline] public def negate {α : Type} [Neg α] (value : α) : α := -value

public class Quotient (α : Type) where
  quotient : α -> α -> α
  remainder : α -> α -> α
  isZero : α -> Bool

public instance : Quotient Nat where
  quotient := Nat.div
  remainder := Nat.mod
  isZero := fun value => value == 0

public instance : Quotient Int where
  quotient := Int.tdiv
  remainder := Int.tmod
  isZero := fun value => value == 0

@[noinline] public def quotient {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.quotient left right

@[noinline] public def remainder {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.remainder left right

@[expose] public def bitAnd {α : Type} [Fixed α] (left right : α) : α := Fixed.bitAnd left right
@[expose] public def bitOr {α : Type} [Fixed α] (left right : α) : α := Fixed.bitOr left right
@[expose] public def bitXor {α : Type} [Fixed α] (left right : α) : α := Fixed.bitXor left right
@[expose] public def bitNot {α : Type} [Fixed α] (value : α) : α := Fixed.bitNot value
@[expose] public def shiftLeft {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftLeft value amount
@[expose] public def shiftRight {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftRight value amount

public class Appendable (α : Type) where append : α -> α -> α
public instance {α : Type} : Appendable (List α) where append := List.append
public instance : Appendable ByteArray where append := ByteArray.append
@[expose] public def append {α : Type} [Appendable α] (left right : α) : α := Appendable.append left right

public class Lengthable (α : Type) where length : α -> Nat
public instance {α : Type} : Lengthable (List α) where length := List.length
public instance : Lengthable ByteArray where length := ByteArray.size
public instance : Lengthable String where length := String.length
@[expose] public def length {α : Type} [Lengthable α] (value : α) : Nat := Lengthable.length value

@[expose] public def listIndex {α : Type} : List α -> Nat -> Option α
  | [], _ => none
  | head :: _, 0 => some head
  | _ :: tail, index + 1 => listIndex tail index

public class Indexable (α β : Type) where index : α -> Nat -> Option β
public instance {α : Type} : Indexable (List α) α where index := listIndex
public instance : Indexable ByteArray UInt8 where index := fun value offset => value.data[offset]?
@[noinline] public def index {α β : Type} [Indexable α β] (value : α) (offset : Nat) : Option β := Indexable.index value offset

public class Sliceable (α : Type) where slice : α -> Nat -> Nat -> Option α
public instance {α : Type} : Sliceable (List α) where
  slice := fun value start count => if start + count <= value.length then some ((value.drop start).take count) else none
public instance : Sliceable ByteArray where
  slice := fun value start count => if start + count <= value.size then some (value.extract start (start + count)) else none
@[noinline] public def slice {α : Type} [Sliceable α] (value : α) (start count : Nat) : Option α := Sliceable.slice value start count

@[noinline] public def utf8Encode (value : String) : ByteArray := value.toUTF8
@[noinline] public def utf8Decode (value : ByteArray) : Option String := String.fromUTF8? value
@[noinline] public def compareBytes (left right : ByteArray) : Ordering := compare left.toList right.toList
@[expose] public def equal {α : Type} [BEq α] (left right : α) : Bool := left == right

@[noinline] public def splitExact (value delimiter : String) (maximum : UInt32) : Option (List String) :=
  let fields := value.splitOn delimiter
  if delimiter.isEmpty || maximum.toNat < fields.length then none else some fields

@[noinline] public def join (values : List String) (delimiter : String) : String := delimiter.intercalate values

public class Decimal (α : Type) where
  parse : String -> Option α
  format : α -> String

public instance : Decimal Int where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then some parsed else none | none => none
  format := toString

public instance {α : Type} [Fixed α] [ToString α] : Decimal α where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then checkedFromInt parsed else none | none => none
  format := toString

@[noinline] public def parseDecimal {α : Type} [Decimal α] (value : String) : Option α := Decimal.parse value
@[noinline] public def formatDecimal {α : Type} [Decimal α] (value : α) : String := Decimal.format value

end LexLeanRuntime

public inductive Access where
  | immutableSeekable
  | singlePass

public structure Source where
  resource : Uorc.Uorc.Product.Api.ResourceRef
  length : Option (Nat)
  access : Access

public inductive ReadPhase where
  | ready
  | waiting
  | cancelling
  | holding
  | complete
  | cancelled
  | failed

public inductive Error where
  | invalidQuantum
  | wrongSource
  | staleReply
  | wrongOffset
  | oversizedReply
  | sourceLengthMismatch
  | noProgress
  | readFailure
  | writeFailure
  | writeExtent
  | notReady
  | cancelled

public structure ReadRequest where
  run : Uorc.Uorc.Product.Api.Run
  source : Uorc.Uorc.Product.Api.ResourceRef
  ticket : Nat
  offset : Nat
  maximum : Nat

public structure ReadReply where
  run : Uorc.Uorc.Product.Api.Run
  source : Uorc.Uorc.Product.Api.ResourceRef
  ticket : Nat
  offset : Nat
  span : Option (Uorc.Uorc.Product.Api.Span)
  eof : Bool
  failed : Bool

public structure Reader where
  run : Uorc.Uorc.Product.Api.Run
  source : Source
  quantum : Nat
  offset : Nat
  ticket : Nat
  phase : ReadPhase
  request : Option (ReadRequest)
  held : Option (Uorc.Uorc.Product.Api.Span)
  eof : Bool
  error : Option (Error)

public structure ReadStep where
  state : Reader
  request : Option (ReadRequest)
  release : Option (Uorc.Uorc.Product.Api.ResourceRef)

@[expose] public def startRead (run : Uorc.Uorc.Product.Api.Run) (source : Source) (quantum : Nat) : Reader := ({ run := run, source := source, quantum := quantum, offset := 0, ticket := 0, phase := ReadPhase.ready, request := Option.none, held := Option.none, eof := false, error := Option.none } : Reader)

@[expose] public def maximum (s : Reader) : Nat := (match ((s).source).length with | Option.none => (s).quantum | Option.some length => (if (Nat.beq (length) ((s).offset)) then 1 else (if (Nat.blt ((s).quantum) ((LexLeanRuntime.subtract (length) ((s).offset) : Nat))) then (s).quantum else (LexLeanRuntime.subtract (length) ((s).offset) : Nat))))

@[expose] public def requestRead (s : Reader) : ReadStep := (match (s).phase with | ReadPhase.ready => (if (Nat.beq ((s).quantum) (0)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := (s).request, held := (s).held, eof := (s).eof, error := Option.some (Error.invalidQuantum) } : Reader), request := Option.none, release := Option.none } : ReadStep) else ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := ((s).ticket + 1), phase := ReadPhase.waiting, request := Option.some (({ run := (s).run, source := ((s).source).resource, ticket := ((s).ticket + 1), offset := (s).offset, maximum := maximum (s) } : ReadRequest)), held := (s).held, eof := (s).eof, error := (s).error } : Reader), request := Option.some (({ run := (s).run, source := ((s).source).resource, ticket := ((s).ticket + 1), offset := (s).offset, maximum := maximum (s) } : ReadRequest)), release := Option.none } : ReadStep)) | ReadPhase.waiting => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.holding => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.complete => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.cancelled => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.failed => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.cancelling => ({ state := s, request := Option.none, release := Option.none } : ReadStep))

@[expose] public def replyLength (reply : ReadReply) : Nat := (match (reply).span with | Option.none => 0 | Option.some span => (span).length)

@[expose] public def lengthValid (s : Reader) (reply : ReadReply) : Bool := (match ((s).source).length with | Option.none => true | Option.some length => ((!(Nat.blt (length) (((s).offset + replyLength (reply))))) && ((if (reply).eof then (Nat.beq (length) (((s).offset + replyLength (reply)))) else true) && true)))

@[expose] public def consumeRead (s : Reader) : ReadStep := (match (s).phase with | ReadPhase.ready => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.waiting => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.holding => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := (if (s).eof then ReadPhase.complete else ReadPhase.ready), request := (s).request, held := Option.none, eof := (s).eof, error := (s).error } : Reader), request := Option.none, release := (match (s).held with | Option.none => Option.none | Option.some span => Option.some ((span).resource)) } : ReadStep) | ReadPhase.complete => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.cancelled => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.failed => ({ state := s, request := Option.none, release := Option.none } : ReadStep) | ReadPhase.cancelling => ({ state := s, request := Option.none, release := Option.none } : ReadStep))

public inductive WritePhase where
  | ready
  | waiting
  | complete
  | cancelled
  | failed

public structure WriteRequest where
  run : Uorc.Uorc.Product.Api.Run
  destination : Uorc.Uorc.Product.Api.ResourceRef
  ticket : Nat
  offset : Nat
  span : Uorc.Uorc.Product.Api.Span

public structure WriteReply where
  run : Uorc.Uorc.Product.Api.Run
  destination : Uorc.Uorc.Product.Api.ResourceRef
  ticket : Nat
  offset : Nat
  written : Nat
  failed : Bool

public structure Writer where
  run : Uorc.Uorc.Product.Api.Run
  destination : Uorc.Uorc.Product.Api.ResourceRef
  category : Uorc.Uorc.Product.Storage.Category
  limits : Uorc.Uorc.Product.Storage.Limits
  storage : Uorc.Uorc.Product.Storage.State
  offset : Nat
  ticket : Nat
  phase : WritePhase
  pending : Option (WriteRequest)
  remaining : Option (Uorc.Uorc.Product.Api.Span)
  error : Option (Error)

public structure WriteStep where
  state : Writer
  request : Option (WriteRequest)
  consumed : Option (Uorc.Uorc.Product.Api.ResourceRef)

@[expose] public def startWrite (run : Uorc.Uorc.Product.Api.Run) (destination : Uorc.Uorc.Product.Api.ResourceRef) (category : Uorc.Uorc.Product.Storage.Category) (limits : Uorc.Uorc.Product.Storage.Limits) : Writer := ({ run := run, destination := destination, category := category, limits := limits, storage := Uorc.Uorc.Product.Storage.initial, offset := 0, ticket := 0, phase := WritePhase.ready, pending := Option.none, remaining := Option.none, error := Option.none } : Writer)

@[expose] public def beginWrite (s : Writer) (span : Uorc.Uorc.Product.Api.Span) (storageState : Uorc.Uorc.Product.Storage.State) : WriteStep := (match (storageState).error with | Option.some _ => ({ state := ({ run := (s).run, destination := (s).destination, category := (s).category, limits := (s).limits, storage := storageState, offset := (s).offset, ticket := (s).ticket, phase := WritePhase.failed, pending := (s).pending, remaining := Option.some (span), error := (s).error } : Writer), request := Option.none, consumed := Option.none } : WriteStep) | Option.none => ({ state := ({ run := (s).run, destination := (s).destination, category := (s).category, limits := (s).limits, storage := storageState, offset := (s).offset, ticket := ((s).ticket + 1), phase := WritePhase.waiting, pending := Option.some (({ run := (s).run, destination := (s).destination, ticket := ((s).ticket + 1), offset := (s).offset, span := span } : WriteRequest)), remaining := Option.some (span), error := (s).error } : Writer), request := Option.some (({ run := (s).run, destination := (s).destination, ticket := ((s).ticket + 1), offset := (s).offset, span := span } : WriteRequest)), consumed := Option.none } : WriteStep))

@[expose] public def requestWrite (s : Writer) (span : Uorc.Uorc.Product.Api.Span) : WriteStep := (match (s).phase with | WritePhase.ready => beginWrite (s) (span) (Uorc.Uorc.Product.Storage.step ((s).limits) ((s).storage) (Uorc.Uorc.Product.Storage.Event.reserve ((s).category) ((span).length))) | WritePhase.waiting => ({ state := s, request := Option.none, consumed := Option.none } : WriteStep) | WritePhase.complete => ({ state := s, request := Option.none, consumed := Option.none } : WriteStep) | WritePhase.cancelled => ({ state := s, request := Option.none, consumed := Option.none } : WriteStep) | WritePhase.failed => ({ state := s, request := Option.none, consumed := Option.none } : WriteStep))

@[expose] public def continueWrite (s : Writer) : WriteStep := (match (s).remaining with | Option.none => ({ state := s, request := Option.none, consumed := Option.none } : WriteStep) | Option.some span => requestWrite (s) (span))

@[expose] public def cancelWrite (s : Writer) : WriteStep := ({ state := ({ run := (s).run, destination := (s).destination, category := (s).category, limits := (s).limits, storage := (s).storage, offset := (s).offset, ticket := (s).ticket, phase := WritePhase.cancelled, pending := (s).pending, remaining := (s).remaining, error := Option.some (Error.cancelled) } : Writer), request := Option.none, consumed := Option.none } : WriteStep)

@[expose] public def boundary : String := "Read requests own resource identity, ticket, offset and bounded demand. Seekable rereads use immutable leases; unknown-length or mutable single-pass originals are first copied to an admitted spool and sealed before reuse/header publication. Reader/Writer retain at most a bounded span per active request; whole input and candidate files are not placed in the arena. Each reply is validated against the source-owned request. Partial writes record achieved storage even on failure. Source operation bindings carry the single actual arena/caller roots/usage through producer acknowledgments; these cursors contain only leases/control metadata and never an arena snapshot. A held span remains in caller roots until consumer acknowledgment, and cancellation cannot pretend that a pending write or publication rolled back."

@[expose] public def sameRunIdentity (left : Uorc.Uorc.Product.Api.Run) (right : Uorc.Uorc.Product.Api.Run) : Bool := ((Nat.beq ((left).«instance») ((right).«instance»)) && ((Nat.beq ((left).serial) ((right).serial)) && ((Nat.beq ((left).revision) ((right).revision)) && true)))

@[expose] public def spanTicket (span : Uorc.Uorc.Product.Api.Span) : Option (Uorc.Uorc.Product.Api.ResourceRef) := (if (Nat.beq ((span).length) (0)) then Option.none else Option.some ((span).resource))

@[expose] public def cancelRead (s : Reader) : ReadStep := ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := (if (match (s).request with | Option.none => false | Option.some _ => true) then ReadPhase.cancelling else ReadPhase.cancelled), request := (s).request, held := Option.none, eof := (s).eof, error := Option.some (Error.cancelled) } : Reader), request := Option.none, release := (match (s).held with | Option.none => Option.none | Option.some held => spanTicket (held)) } : ReadStep)

@[expose] public def incomingTicket (s : Reader) (reply : ReadReply) : Option (Uorc.Uorc.Product.Api.ResourceRef) := (match (reply).span with | Option.none => Option.none | Option.some incoming => (match (s).held with | Option.none => spanTicket (incoming) | Option.some held => (if Uorc.Uorc.Product.Api.sameResource ((held).resource) ((incoming).resource) then Option.none else spanTicket (incoming))))

@[expose] public def readMatches (s : Reader) (reply : ReadReply) : Bool := (match (s).request with | Option.none => false | Option.some request => (sameRunIdentity ((request).run) ((reply).run) && (Uorc.Uorc.Product.Api.sameResource ((request).source) ((reply).source) && ((Nat.beq ((request).ticket) ((reply).ticket)) && ((Nat.beq ((request).offset) ((reply).offset)) && true)))))

@[expose] public def readReply (s : Reader) (reply : ReadReply) : ReadStep := (match (s).phase with | ReadPhase.ready => (if readMatches (s) (reply) then (if (reply).failed then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.readFailure) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!(match (reply).span with | Option.none => true | Option.some span => (Nat.beq (((span).resource).«instance») (((s).run).«instance»)))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.wrongSource) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (Nat.blt (maximum (s)) (replyLength (reply))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.oversizedReply) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!lengthValid (s) (reply)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.sourceLengthMismatch) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if ((Nat.beq (replyLength (reply)) (0)) && ((!(reply).eof) && true)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.noProgress) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := ((s).offset + replyLength (reply)), ticket := (s).ticket, phase := (if (Nat.beq (replyLength (reply)) (0)) then ReadPhase.complete else ReadPhase.holding), request := Option.none, held := (if (Nat.beq (replyLength (reply)) (0)) then Option.none else (reply).span), eof := (reply).eof, error := Option.none } : Reader), request := Option.none, release := Option.none } : ReadStep)))))) else ({ state := s, request := Option.none, release := incomingTicket (s) (reply) } : ReadStep)) | ReadPhase.waiting => (if readMatches (s) (reply) then (if (reply).failed then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.readFailure) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!(match (reply).span with | Option.none => true | Option.some span => (Nat.beq (((span).resource).«instance») (((s).run).«instance»)))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.wrongSource) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (Nat.blt (maximum (s)) (replyLength (reply))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.oversizedReply) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!lengthValid (s) (reply)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.sourceLengthMismatch) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if ((Nat.beq (replyLength (reply)) (0)) && ((!(reply).eof) && true)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.noProgress) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := ((s).offset + replyLength (reply)), ticket := (s).ticket, phase := (if (Nat.beq (replyLength (reply)) (0)) then ReadPhase.complete else ReadPhase.holding), request := Option.none, held := (if (Nat.beq (replyLength (reply)) (0)) then Option.none else (reply).span), eof := (reply).eof, error := Option.none } : Reader), request := Option.none, release := Option.none } : ReadStep)))))) else ({ state := s, request := Option.none, release := incomingTicket (s) (reply) } : ReadStep)) | ReadPhase.cancelling => (if readMatches (s) (reply) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.cancelled, request := Option.none, held := Option.none, eof := (s).eof, error := (s).error } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else ({ state := s, request := Option.none, release := incomingTicket (s) (reply) } : ReadStep)) | ReadPhase.holding => (if readMatches (s) (reply) then (if (reply).failed then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.readFailure) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!(match (reply).span with | Option.none => true | Option.some span => (Nat.beq (((span).resource).«instance») (((s).run).«instance»)))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.wrongSource) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (Nat.blt (maximum (s)) (replyLength (reply))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.oversizedReply) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!lengthValid (s) (reply)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.sourceLengthMismatch) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if ((Nat.beq (replyLength (reply)) (0)) && ((!(reply).eof) && true)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.noProgress) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := ((s).offset + replyLength (reply)), ticket := (s).ticket, phase := (if (Nat.beq (replyLength (reply)) (0)) then ReadPhase.complete else ReadPhase.holding), request := Option.none, held := (if (Nat.beq (replyLength (reply)) (0)) then Option.none else (reply).span), eof := (reply).eof, error := Option.none } : Reader), request := Option.none, release := Option.none } : ReadStep)))))) else ({ state := s, request := Option.none, release := incomingTicket (s) (reply) } : ReadStep)) | ReadPhase.complete => (if readMatches (s) (reply) then (if (reply).failed then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.readFailure) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!(match (reply).span with | Option.none => true | Option.some span => (Nat.beq (((span).resource).«instance») (((s).run).«instance»)))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.wrongSource) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (Nat.blt (maximum (s)) (replyLength (reply))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.oversizedReply) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!lengthValid (s) (reply)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.sourceLengthMismatch) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if ((Nat.beq (replyLength (reply)) (0)) && ((!(reply).eof) && true)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.noProgress) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := ((s).offset + replyLength (reply)), ticket := (s).ticket, phase := (if (Nat.beq (replyLength (reply)) (0)) then ReadPhase.complete else ReadPhase.holding), request := Option.none, held := (if (Nat.beq (replyLength (reply)) (0)) then Option.none else (reply).span), eof := (reply).eof, error := Option.none } : Reader), request := Option.none, release := Option.none } : ReadStep)))))) else ({ state := s, request := Option.none, release := incomingTicket (s) (reply) } : ReadStep)) | ReadPhase.cancelled => (if readMatches (s) (reply) then (if (reply).failed then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.readFailure) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!(match (reply).span with | Option.none => true | Option.some span => (Nat.beq (((span).resource).«instance») (((s).run).«instance»)))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.wrongSource) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (Nat.blt (maximum (s)) (replyLength (reply))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.oversizedReply) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!lengthValid (s) (reply)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.sourceLengthMismatch) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if ((Nat.beq (replyLength (reply)) (0)) && ((!(reply).eof) && true)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.noProgress) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := ((s).offset + replyLength (reply)), ticket := (s).ticket, phase := (if (Nat.beq (replyLength (reply)) (0)) then ReadPhase.complete else ReadPhase.holding), request := Option.none, held := (if (Nat.beq (replyLength (reply)) (0)) then Option.none else (reply).span), eof := (reply).eof, error := Option.none } : Reader), request := Option.none, release := Option.none } : ReadStep)))))) else ({ state := s, request := Option.none, release := incomingTicket (s) (reply) } : ReadStep)) | ReadPhase.failed => (if readMatches (s) (reply) then (if (reply).failed then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.readFailure) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!(match (reply).span with | Option.none => true | Option.some span => (Nat.beq (((span).resource).«instance») (((s).run).«instance»)))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.wrongSource) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (Nat.blt (maximum (s)) (replyLength (reply))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.oversizedReply) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if (!lengthValid (s) (reply)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.sourceLengthMismatch) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else (if ((Nat.beq (replyLength (reply)) (0)) && ((!(reply).eof) && true)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.failed, request := Option.none, held := Option.none, eof := (s).eof, error := Option.some (Error.noProgress) } : Reader), request := Option.none, release := incomingTicket (s) (reply) } : ReadStep) else ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := ((s).offset + replyLength (reply)), ticket := (s).ticket, phase := (if (Nat.beq (replyLength (reply)) (0)) then ReadPhase.complete else ReadPhase.holding), request := Option.none, held := (if (Nat.beq (replyLength (reply)) (0)) then Option.none else (reply).span), eof := (reply).eof, error := Option.none } : Reader), request := Option.none, release := Option.none } : ReadStep)))))) else ({ state := s, request := Option.none, release := incomingTicket (s) (reply) } : ReadStep)))

@[expose] public def writeMatches (s : Writer) (reply : WriteReply) : Bool := (match (s).pending with | Option.none => false | Option.some request => (sameRunIdentity ((request).run) ((reply).run) && (Uorc.Uorc.Product.Api.sameResource ((request).destination) ((reply).destination) && ((Nat.beq ((request).ticket) ((reply).ticket)) && ((Nat.beq ((request).offset) ((reply).offset)) && true)))))

@[expose] public def writeReply (s : Writer) (reply : WriteReply) : WriteStep := (match (s).pending with | Option.none => ({ state := s, request := Option.none, consumed := Option.none } : WriteStep) | Option.some request => (if writeMatches (s) (reply) then (if (!(Nat.blt (((request).span).length) ((reply).written))) then ({ state := ({ run := (s).run, destination := (s).destination, category := (s).category, limits := (s).limits, storage := Uorc.Uorc.Product.Storage.step ((s).limits) ((s).storage) (Uorc.Uorc.Product.Storage.Event.failedWrite ((s).category) (((request).span).length) ((reply).written)), offset := ((s).offset + (reply).written), ticket := (s).ticket, phase := (if ((reply).failed || ((Nat.beq ((reply).written) (0)) && ((!(Nat.beq (((request).span).length) (0))) && true))) then WritePhase.failed else WritePhase.ready), pending := Option.none, remaining := (if (Nat.beq ((reply).written) (((request).span).length)) then Option.none else Option.some (({ resource := ((request).span).resource, offset := (((request).span).offset + (reply).written), length := (LexLeanRuntime.subtract (((request).span).length) ((reply).written) : Nat) } : Uorc.Uorc.Product.Api.Span))), error := (if ((reply).failed || ((Nat.beq ((reply).written) (0)) && ((!(Nat.beq (((request).span).length) (0))) && true))) then Option.some (Error.writeFailure) else Option.none) } : Writer), request := Option.none, consumed := (if (Nat.beq ((reply).written) (((request).span).length)) then Option.some (((request).span).resource) else Option.none) } : WriteStep) else ({ state := ({ run := (s).run, destination := (s).destination, category := (s).category, limits := (s).limits, storage := (s).storage, offset := (s).offset, ticket := (s).ticket, phase := WritePhase.failed, pending := (s).pending, remaining := (s).remaining, error := Option.some (Error.writeExtent) } : Writer), request := Option.none, consumed := Option.none } : WriteStep)) else ({ state := s, request := Option.none, consumed := Option.none } : WriteStep)))

@[expose] public def controls : Bool := ((Nat.beq ((match (requestRead (startRead (({ «instance» := 1, serial := 1, revision := 0 } : Uorc.Uorc.Product.Api.Run)) (({ resource := ({ «instance» := 1, slot := 1, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef), length := Option.some (100000000), access := Access.immutableSeekable } : Source)) (4096))).request with | Option.none => 0 | Option.some request => (request).maximum)) (4096)) && ((Nat.beq (((writeReply ((requestWrite (startWrite (({ «instance» := 1, serial := 1, revision := 0 } : Uorc.Uorc.Product.Api.Run)) (({ «instance» := 1, slot := 2, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef)) (Uorc.Uorc.Product.Storage.Category.inputSpool) (Uorc.Uorc.Product.Storage.unlimitedRequest)) (({ resource := ({ «instance» := 1, slot := 3, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef), offset := 0, length := 4 } : Uorc.Uorc.Product.Api.Span))).state) (({ run := ({ «instance» := 1, serial := 1, revision := 0 } : Uorc.Uorc.Product.Api.Run), destination := ({ «instance» := 1, slot := 2, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef), ticket := 1, offset := 0, written := 2, failed := true } : WriteReply))).state).offset) (2)) && ((Nat.beq (Uorc.Uorc.Product.Storage.retainedBytes ((((writeReply ((requestWrite (startWrite (({ «instance» := 1, serial := 1, revision := 0 } : Uorc.Uorc.Product.Api.Run)) (({ «instance» := 1, slot := 2, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef)) (Uorc.Uorc.Product.Storage.Category.inputSpool) (Uorc.Uorc.Product.Storage.unlimitedRequest)) (({ resource := ({ «instance» := 1, slot := 3, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef), offset := 0, length := 4 } : Uorc.Uorc.Product.Api.Span))).state) (({ run := ({ «instance» := 1, serial := 1, revision := 0 } : Uorc.Uorc.Product.Api.Run), destination := ({ «instance» := 1, slot := 2, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef), ticket := 1, offset := 0, written := 2, failed := true } : WriteReply))).state).storage).usage)) (2)) && ((Nat.beq (Uorc.Uorc.Product.Storage.reservedBytes ((((writeReply ((requestWrite (startWrite (({ «instance» := 1, serial := 1, revision := 0 } : Uorc.Uorc.Product.Api.Run)) (({ «instance» := 1, slot := 2, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef)) (Uorc.Uorc.Product.Storage.Category.inputSpool) (Uorc.Uorc.Product.Storage.unlimitedRequest)) (({ resource := ({ «instance» := 1, slot := 3, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef), offset := 0, length := 4 } : Uorc.Uorc.Product.Api.Span))).state) (({ run := ({ «instance» := 1, serial := 1, revision := 0 } : Uorc.Uorc.Product.Api.Run), destination := ({ «instance» := 1, slot := 2, generation := 1 } : Uorc.Uorc.Product.Api.ResourceRef), ticket := 1, offset := 0, written := 2, failed := true } : WriteReply))).state).storage).usage)) (0)) && true))))

@[expose] public def startWriteWithStorage (run : Uorc.Uorc.Product.Api.Run) (destination : Uorc.Uorc.Product.Api.ResourceRef) (category : Uorc.Uorc.Product.Storage.Category) (limits : Uorc.Uorc.Product.Storage.Limits) (storage : Uorc.Uorc.Product.Storage.State) : Writer := ({ run := run, destination := destination, category := category, limits := limits, storage := storage, offset := 0, ticket := 0, phase := WritePhase.ready, pending := Option.none, remaining := Option.none, error := Option.none } : Writer)

public inductive PreparationPhase where
  | waitingSpool
  | reading
  | writing
  | sealing
  | ready
  | cancelling
  | releasing
  | cancelled
  | failed

public structure Preparation where
  run : Uorc.Uorc.Product.Api.Run
  source : Source
  quantum : Nat
  limits : Uorc.Uorc.Product.Storage.Limits
  storage : Uorc.Uorc.Product.Storage.State
  reader : Reader
  writer : Option (Writer)
  phase : PreparationPhase
  stable : Option (Source)
  creationPending : Bool
  sealPending : Bool

public inductive Command where
  | createSpool (_ : Uorc.Uorc.Product.Api.Run)
  | read (_ : ReadRequest)
  | write (_ : WriteRequest)
  | «seal» (_ : Uorc.Uorc.Product.Api.ResourceRef) (_ : Nat)
  | release (_ : Uorc.Uorc.Product.Api.ResourceRef)
  | cancelWrite (_ : Uorc.Uorc.Product.Api.Run)
  | deleteSpool (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.Api.ResourceRef) (_ : Nat)
  | cancelRead (_ : ReadRequest)

public structure PreparationStep where
  state : Preparation
  commands : List (Command)

@[expose] public def appendCommands : (left : List (Command)) -> (right : List (Command)) -> List (Command)
  | List.nil, right => right
  | List.cons head tail, right => (head :: appendCommands (tail) (right))

@[expose] public def requiresSpool (source : Source) : Bool := (match (source).access with | Access.singlePass => true | Access.immutableSeekable => (match (source).length with | Option.none => true | Option.some _ => false))

@[expose] public def startPreparation (run : Uorc.Uorc.Product.Api.Run) (source : Source) (quantum : Nat) (limits : Uorc.Uorc.Product.Storage.Limits) (storage : Uorc.Uorc.Product.Storage.State) : PreparationStep := (if (Nat.beq (quantum) (0)) then ({ state := ({ run := run, source := source, quantum := quantum, limits := limits, storage := storage, reader := (requestRead (startRead (run) (source) (quantum))).state, writer := Option.none, phase := PreparationPhase.failed, stable := Option.none, creationPending := requiresSpool (source), sealPending := false } : Preparation), commands := ([] : List (Command)) } : PreparationStep) else ({ state := ({ run := run, source := source, quantum := quantum, limits := limits, storage := storage, reader := startRead (run) (source) (quantum), writer := Option.none, phase := (if requiresSpool (source) then PreparationPhase.waitingSpool else PreparationPhase.ready), stable := (if requiresSpool (source) then Option.none else Option.some (source)), creationPending := requiresSpool (source), sealPending := false } : Preparation), commands := (if requiresSpool (source) then (Command.createSpool (run) :: ([] : List (Command))) else ([] : List (Command))) } : PreparationStep))

@[expose] public def spoolReady (s : Preparation) (resource : Uorc.Uorc.Product.Api.ResourceRef) : PreparationStep := (match (s).phase with | PreparationPhase.waitingSpool => (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (requestRead ((s).reader)).state, writer := Option.some (startWriteWithStorage ((s).run) (resource) (Uorc.Uorc.Product.Storage.Category.inputSpool) ((s).limits) ((s).storage)), phase := PreparationPhase.reading, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation), commands := (match (requestRead ((s).reader)).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.read (commandValue) :: ([] : List (Command)))) } : PreparationStep) else ({ state := s, commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep)) | PreparationPhase.reading => ({ state := (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep) | PreparationPhase.writing => ({ state := (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep) | PreparationPhase.sealing => ({ state := (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep) | PreparationPhase.ready => ({ state := (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep) | PreparationPhase.cancelling => ({ state := (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep) | PreparationPhase.releasing => ({ state := (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep) | PreparationPhase.cancelled => ({ state := (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep) | PreparationPhase.failed => ({ state := (if (Nat.beq ((resource).«instance») (((s).run).«instance»)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := (Command.release (resource) :: ([] : List (Command))) } : PreparationStep))

@[expose] public def preparationConsumed (s : Preparation) (writer : Writer) (consumed : ReadStep) : PreparationStep := (match ((consumed).state).phase with | ReadPhase.ready => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (requestRead ((consumed).state)).state, writer := (s).writer, phase := PreparationPhase.reading, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (requestRead ((consumed).state)).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.read (commandValue) :: ([] : List (Command)))) } : PreparationStep) | ReadPhase.waiting => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (requestRead ((consumed).state)).state, writer := (s).writer, phase := PreparationPhase.reading, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (requestRead ((consumed).state)).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.read (commandValue) :: ([] : List (Command)))) } : PreparationStep) | ReadPhase.holding => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (requestRead ((consumed).state)).state, writer := (s).writer, phase := PreparationPhase.reading, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (requestRead ((consumed).state)).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.read (commandValue) :: ([] : List (Command)))) } : PreparationStep) | ReadPhase.complete => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (consumed).state, writer := (s).writer, phase := PreparationPhase.sealing, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (Command.«seal» ((writer).destination) ((writer).offset) :: ([] : List (Command))) } : PreparationStep) | ReadPhase.cancelled => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (requestRead ((consumed).state)).state, writer := (s).writer, phase := PreparationPhase.reading, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (requestRead ((consumed).state)).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.read (commandValue) :: ([] : List (Command)))) } : PreparationStep) | ReadPhase.failed => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (requestRead ((consumed).state)).state, writer := (s).writer, phase := PreparationPhase.reading, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (requestRead ((consumed).state)).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.read (commandValue) :: ([] : List (Command)))) } : PreparationStep) | ReadPhase.cancelling => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (requestRead ((consumed).state)).state, writer := (s).writer, phase := PreparationPhase.reading, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (requestRead ((consumed).state)).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.read (commandValue) :: ([] : List (Command)))) } : PreparationStep))

@[expose] public def preparationWriteFailed (s : Preparation) (writer : Writer) : PreparationStep := ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (writer).storage, reader := (cancelRead ((s).reader)).state, writer := Option.some (writer), phase := PreparationPhase.failed, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (cancelRead ((s).reader)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command)))) } : PreparationStep)

@[expose] public def preparationWriteIssued (s : Preparation) (issued : WriteStep) : PreparationStep := (match ((issued).state).phase with | WritePhase.ready => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := ((issued).state).storage, reader := (s).reader, writer := Option.some ((issued).state), phase := (match ((issued).state).phase with | WritePhase.ready => PreparationPhase.failed | WritePhase.waiting => PreparationPhase.writing | WritePhase.complete => PreparationPhase.failed | WritePhase.cancelled => PreparationPhase.failed | WritePhase.failed => PreparationPhase.failed), stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (issued).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.write (commandValue) :: ([] : List (Command)))) } : PreparationStep) | WritePhase.waiting => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := ((issued).state).storage, reader := (s).reader, writer := Option.some ((issued).state), phase := (match ((issued).state).phase with | WritePhase.ready => PreparationPhase.failed | WritePhase.waiting => PreparationPhase.writing | WritePhase.complete => PreparationPhase.failed | WritePhase.cancelled => PreparationPhase.failed | WritePhase.failed => PreparationPhase.failed), stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (issued).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.write (commandValue) :: ([] : List (Command)))) } : PreparationStep) | WritePhase.complete => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := ((issued).state).storage, reader := (s).reader, writer := Option.some ((issued).state), phase := (match ((issued).state).phase with | WritePhase.ready => PreparationPhase.failed | WritePhase.waiting => PreparationPhase.writing | WritePhase.complete => PreparationPhase.failed | WritePhase.cancelled => PreparationPhase.failed | WritePhase.failed => PreparationPhase.failed), stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (issued).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.write (commandValue) :: ([] : List (Command)))) } : PreparationStep) | WritePhase.cancelled => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := ((issued).state).storage, reader := (s).reader, writer := Option.some ((issued).state), phase := (match ((issued).state).phase with | WritePhase.ready => PreparationPhase.failed | WritePhase.waiting => PreparationPhase.writing | WritePhase.complete => PreparationPhase.failed | WritePhase.cancelled => PreparationPhase.failed | WritePhase.failed => PreparationPhase.failed), stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (issued).request with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.write (commandValue) :: ([] : List (Command)))) } : PreparationStep) | WritePhase.failed => preparationWriteFailed (s) ((issued).state))

@[expose] public def preparationReadAccepted (s : Preparation) (writer : Writer) (accepted : ReadStep) : PreparationStep := (match ((accepted).state).held with | Option.none => (match ((accepted).state).phase with | ReadPhase.ready => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | ReadPhase.waiting => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | ReadPhase.holding => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | ReadPhase.complete => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := PreparationPhase.sealing, stable := (s).stable, creationPending := (s).creationPending, sealPending := true } : Preparation), commands := (Command.«seal» ((writer).destination) ((writer).offset) :: ([] : List (Command))) } : PreparationStep) | ReadPhase.cancelled => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | ReadPhase.failed => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := PreparationPhase.failed, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | ReadPhase.cancelling => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep)) | Option.some span => preparationWriteIssued (({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation)) (requestWrite (writer) (span)))

@[expose] public def preparationReadState (s : Preparation) (accepted : ReadStep) : PreparationStep := (match (s).phase with | PreparationPhase.waitingSpool => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.reading => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => preparationReadAccepted (s) (writer) (accepted)) | PreparationPhase.writing => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.sealing => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.ready => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelling => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.releasing => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelled => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.failed => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (accepted).state, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep))

@[expose] public def preparationRead (s : Preparation) (reply : ReadReply) : PreparationStep := ({ state := (preparationReadState (s) (readReply ((s).reader) (reply))).state, commands := appendCommands ((match (readReply ((s).reader) (reply)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command))))) ((preparationReadState (s) (readReply ((s).reader) (reply))).commands) } : PreparationStep)

@[expose] public def preparationFinishSpan (s : Preparation) (writer : Writer) : PreparationStep := ({ state := (preparationConsumed (({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (writer).storage, reader := (s).reader, writer := Option.some (writer), phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation)) (writer) (consumeRead ((s).reader))).state, commands := appendCommands ((match (consumeRead ((s).reader)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command))))) ((preparationConsumed (({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (writer).storage, reader := (s).reader, writer := Option.some (writer), phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation)) (writer) (consumeRead ((s).reader))).commands) } : PreparationStep)

@[expose] public def preparationWriteAccepted (s : Preparation) (acknowledged : WriteStep) : PreparationStep := (match ((acknowledged).state).pending with | Option.some _ => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.none => (match ((acknowledged).state).phase with | WritePhase.ready => (match ((acknowledged).state).remaining with | Option.none => preparationFinishSpan (s) ((acknowledged).state) | Option.some _ => preparationWriteIssued (s) (continueWrite ((acknowledged).state))) | WritePhase.waiting => (match ((acknowledged).state).remaining with | Option.none => preparationFinishSpan (s) ((acknowledged).state) | Option.some _ => preparationWriteIssued (s) (continueWrite ((acknowledged).state))) | WritePhase.complete => (match ((acknowledged).state).remaining with | Option.none => preparationFinishSpan (s) ((acknowledged).state) | Option.some _ => preparationWriteIssued (s) (continueWrite ((acknowledged).state))) | WritePhase.cancelled => (match ((acknowledged).state).remaining with | Option.none => preparationFinishSpan (s) ((acknowledged).state) | Option.some _ => preparationWriteIssued (s) (continueWrite ((acknowledged).state))) | WritePhase.failed => preparationWriteFailed (s) ((acknowledged).state)))

@[expose] public def preparationWritten (s : Preparation) (reply : WriteReply) : PreparationStep := (match (s).phase with | PreparationPhase.waitingSpool => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.reading => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.writing => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => preparationWriteAccepted (s) (writeReply (writer) (reply))) | PreparationPhase.sealing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.ready => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelling => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.releasing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelled => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.failed => ({ state := s, commands := ([] : List (Command)) } : PreparationStep))

@[expose] public def spoolSealed (s : Preparation) (sealedFor : Uorc.Uorc.Product.Api.ResourceRef) (source : Source) : PreparationStep := (match (s).phase with | PreparationPhase.waitingSpool => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)) | PreparationPhase.reading => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)) | PreparationPhase.writing => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)) | PreparationPhase.sealing => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => (if (Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) && (Uorc.Uorc.Product.Api.sameResource (sealedFor) ((source).resource) && ((match (source).access with | Access.immutableSeekable => true | Access.singlePass => false) && ((match (source).length with | Option.none => false | Option.some knownLength => (Nat.beq (knownLength) ((writer).offset))) && true)))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.ready, stable := Option.some (source), creationPending := (s).creationPending, sealPending := false } : Preparation), commands := ([] : List (Command)) } : PreparationStep) else ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.failed, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation), commands := ([] : List (Command)) } : PreparationStep))) | PreparationPhase.ready => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)) | PreparationPhase.cancelling => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)) | PreparationPhase.releasing => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)) | PreparationPhase.cancelled => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)) | PreparationPhase.failed => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if Uorc.Uorc.Product.Api.sameResource (sealedFor) ((writer).destination) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)))

@[expose] public def cancelPreparation (s : Preparation) : PreparationStep := (match (s).phase with | PreparationPhase.waitingSpool => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (cancelRead ((s).reader)).state, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := appendCommands ((match (cancelRead ((s).reader)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command))))) ((match ((s).reader).request with | Option.none => ([] : List (Command)) | Option.some pendingRead => (Command.cancelRead (pendingRead) :: ([] : List (Command))))) } : PreparationStep) | PreparationPhase.reading => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (cancelRead ((s).reader)).state, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := appendCommands ((match (cancelRead ((s).reader)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command))))) ((match ((s).reader).request with | Option.none => ([] : List (Command)) | Option.some pendingRead => (Command.cancelRead (pendingRead) :: ([] : List (Command))))) } : PreparationStep) | PreparationPhase.writing => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.cancelling, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (Command.cancelWrite ((s).run) :: ([] : List (Command))) } : PreparationStep) | PreparationPhase.sealing => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (cancelRead ((s).reader)).state, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := appendCommands ((match (cancelRead ((s).reader)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command))))) ((match ((s).reader).request with | Option.none => ([] : List (Command)) | Option.some pendingRead => (Command.cancelRead (pendingRead) :: ([] : List (Command))))) } : PreparationStep) | PreparationPhase.ready => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (cancelRead ((s).reader)).state, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := appendCommands ((match (cancelRead ((s).reader)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command))))) ((match ((s).reader).request with | Option.none => ([] : List (Command)) | Option.some pendingRead => (Command.cancelRead (pendingRead) :: ([] : List (Command))))) } : PreparationStep) | PreparationPhase.cancelling => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.releasing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelled => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.failed => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (cancelRead ((s).reader)).state, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := appendCommands ((match (cancelRead ((s).reader)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command))))) ((match ((s).reader).request with | Option.none => ([] : List (Command)) | Option.some pendingRead => (Command.cancelRead (pendingRead) :: ([] : List (Command))))) } : PreparationStep))

@[expose] public def cancelledWriteAccepted (s : Preparation) (acknowledged : WriteStep) : PreparationStep := (match ((acknowledged).state).pending with | Option.some _ => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.none => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := ((acknowledged).state).storage, reader := (cancelRead ((s).reader)).state, writer := Option.some ((acknowledged).state), phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (match (cancelRead ((s).reader)).release with | Option.none => ([] : List (Command)) | Option.some commandValue => (Command.release (commandValue) :: ([] : List (Command)))) } : PreparationStep))

@[expose] public def cancelledWriteAcknowledged (s : Preparation) (reply : WriteReply) : PreparationStep := (match (s).phase with | PreparationPhase.waitingSpool => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.reading => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.writing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.sealing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.ready => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelling => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => cancelledWriteAccepted (s) (writeReply (writer) (reply))) | PreparationPhase.releasing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelled => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.failed => ({ state := s, commands := ([] : List (Command)) } : PreparationStep))

@[expose] public def cleanupPreparation (s : Preparation) : PreparationStep := (if ((!(s).creationPending) && ((!(s).sealPending) && ((!(match ((s).reader).request with | Option.none => false | Option.some _ => true)) && ((!(match ((s).reader).held with | Option.none => false | Option.some _ => true)) && true)))) then (match (s).phase with | PreparationPhase.waitingSpool => (match (s).writer with | Option.none => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.releasing, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (Command.deleteSpool ((s).run) ((writer).destination) ((writer).offset) :: ([] : List (Command))) } : PreparationStep)) | PreparationPhase.reading => (match (s).writer with | Option.none => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.releasing, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (Command.deleteSpool ((s).run) ((writer).destination) ((writer).offset) :: ([] : List (Command))) } : PreparationStep)) | PreparationPhase.writing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.sealing => (match (s).writer with | Option.none => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.releasing, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (Command.deleteSpool ((s).run) ((writer).destination) ((writer).offset) :: ([] : List (Command))) } : PreparationStep)) | PreparationPhase.ready => (match (s).writer with | Option.none => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.releasing, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (Command.deleteSpool ((s).run) ((writer).destination) ((writer).offset) :: ([] : List (Command))) } : PreparationStep)) | PreparationPhase.cancelling => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.releasing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelled => (match (s).writer with | Option.none => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.releasing, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (Command.deleteSpool ((s).run) ((writer).destination) ((writer).offset) :: ([] : List (Command))) } : PreparationStep)) | PreparationPhase.failed => (match (s).writer with | Option.none => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.cancelled, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.releasing, stable := Option.none, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := (Command.deleteSpool ((s).run) ((writer).destination) ((writer).offset) :: ([] : List (Command))) } : PreparationStep))) else ({ state := s, commands := ([] : List (Command)) } : PreparationStep))

@[expose] public def spoolDeleted (s : Preparation) (run : Uorc.Uorc.Product.Api.Run) (resource : Uorc.Uorc.Product.Api.ResourceRef) (freed : Nat) : PreparationStep := (match (s).phase with | PreparationPhase.waitingSpool => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.reading => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.writing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.sealing => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.ready => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.cancelling => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.releasing => (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => (if (sameRunIdentity ((s).run) (run) && (Uorc.Uorc.Product.Api.sameResource ((writer).destination) (resource) && ((!(Nat.blt ((writer).offset) (freed))) && true))) then ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := Uorc.Uorc.Product.Storage.step ((s).limits) ((s).storage) (Uorc.Uorc.Product.Storage.Event.release (Uorc.Uorc.Product.Storage.Category.inputSpool) (freed)), reader := (s).reader, writer := (if (Nat.beq ((writer).offset) (freed)) then Option.none else Option.some (({ run := (writer).run, destination := (writer).destination, category := (writer).category, limits := (writer).limits, storage := Uorc.Uorc.Product.Storage.step ((s).limits) ((s).storage) (Uorc.Uorc.Product.Storage.Event.release (Uorc.Uorc.Product.Storage.Category.inputSpool) (freed)), offset := (LexLeanRuntime.subtract ((writer).offset) (freed) : Nat), ticket := (writer).ticket, phase := (writer).phase, pending := (writer).pending, remaining := (writer).remaining, error := (writer).error } : Writer))), phase := (if (Nat.beq ((writer).offset) (freed)) then PreparationPhase.cancelled else PreparationPhase.failed), stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep) else ({ state := s, commands := ([] : List (Command)) } : PreparationStep))) | PreparationPhase.cancelled => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | PreparationPhase.failed => ({ state := s, commands := ([] : List (Command)) } : PreparationStep))

public theorem cancel_read_preserves_pending_receipt_identity (reader : Reader) : (((cancelRead (reader)).state).request = (reader).request) := by
  rfl

public theorem cancel_read_releases_ticket_at_most_once (reader : Reader) : ((cancelRead ((cancelRead (reader)).state)).release = Option.none) := by
  rfl

public structure ReadCancellationReply where
  run : Uorc.Uorc.Product.Api.Run
  source : Uorc.Uorc.Product.Api.ResourceRef
  ticket : Nat
  offset : Nat
  stopped : Bool

@[expose] public def cancelReadAcknowledged (s : Reader) (receipt : ReadCancellationReply) : Reader := (match (s).phase with | ReadPhase.ready => s | ReadPhase.waiting => s | ReadPhase.cancelling => (if (match (s).request with | Option.none => false | Option.some pending => (sameRunIdentity ((pending).run) ((receipt).run) && (Uorc.Uorc.Product.Api.sameResource ((pending).source) ((receipt).source) && ((Nat.beq ((pending).ticket) ((receipt).ticket)) && ((Nat.beq ((pending).offset) ((receipt).offset)) && ((receipt).stopped && true)))))) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, offset := (s).offset, ticket := (s).ticket, phase := ReadPhase.cancelled, request := Option.none, held := (s).held, eof := (s).eof, error := (s).error } : Reader) else s) | ReadPhase.holding => s | ReadPhase.complete => s | ReadPhase.cancelled => s | ReadPhase.failed => s)

@[expose] public def cancelledReadAcknowledged (s : Preparation) (receipt : ReadCancellationReply) : PreparationStep := ({ state := ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := cancelReadAcknowledged ((s).reader) (receipt), writer := (s).writer, phase := (s).phase, stable := (s).stable, creationPending := (s).creationPending, sealPending := (s).sealPending } : Preparation), commands := ([] : List (Command)) } : PreparationStep)

@[expose] public def spoolCreationFailed (s : Preparation) (bindingRun : Uorc.Uorc.Product.Api.Run) : PreparationStep := ({ state := (if ((s).creationPending && (sameRunIdentity ((s).run) (bindingRun) && true)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.failed, stable := (s).stable, creationPending := false, sealPending := (s).sealPending } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep)

@[expose] public def spoolSealStopped (s : Preparation) (bindingRun : Uorc.Uorc.Product.Api.Run) (resource : Uorc.Uorc.Product.Api.ResourceRef) (stopped : Bool) : PreparationStep := (match (s).writer with | Option.none => ({ state := s, commands := ([] : List (Command)) } : PreparationStep) | Option.some writer => ({ state := (if ((s).sealPending && ((stopped && (sameRunIdentity ((s).run) (bindingRun) && (Uorc.Uorc.Product.Api.sameResource ((writer).destination) (resource) && true))) && true)) then ({ run := (s).run, source := (s).source, quantum := (s).quantum, limits := (s).limits, storage := (s).storage, reader := (s).reader, writer := (s).writer, phase := PreparationPhase.failed, stable := (s).stable, creationPending := (s).creationPending, sealPending := false } : Preparation) else s), commands := ([] : List (Command)) } : PreparationStep))

@[expose] public def readerDisposition (s : Reader) : Uorc.Uorc.Product.Api.ReleaseDisposition := (if (match (s).request with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.pendingIo) else (if (match (s).held with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.imageTicket) else Uorc.Uorc.Product.Api.ReleaseDisposition.releasable))

@[expose] public def readStepDisposition (s : ReadStep) : Uorc.Uorc.Product.Api.ReleaseDisposition := (if (match (s).release with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.imageTicket) else readerDisposition ((s).state))

@[expose] public def writerDisposition (s : Writer) : Uorc.Uorc.Product.Api.ReleaseDisposition := (if (match (s).pending with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.pendingIo) else (if (match (s).remaining with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.imageTicket) else (if ((!(Nat.beq (Uorc.Uorc.Product.Storage.retainedBytes (((s).storage).usage)) (0))) || (!(Nat.beq (Uorc.Uorc.Product.Storage.reservedBytes (((s).storage).usage)) (0)))) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.storage) else Uorc.Uorc.Product.Api.ReleaseDisposition.releasable)))

@[expose] public def writeStepDisposition (s : WriteStep) : Uorc.Uorc.Product.Api.ReleaseDisposition := (if (match (s).consumed with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.receipt) else writerDisposition ((s).state))

@[expose] public def preparationDisposition (s : Preparation) : Uorc.Uorc.Product.Api.ReleaseDisposition := (if ((s).creationPending || (s).sealPending) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.pendingIo) else (if (match ((s).reader).request with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.pendingIo) else (if (match ((s).reader).held with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.imageTicket) else (if ((!(Nat.beq (Uorc.Uorc.Product.Storage.retainedBytes (((s).storage).usage)) (0))) || (!(Nat.beq (Uorc.Uorc.Product.Storage.reservedBytes (((s).storage).usage)) (0)))) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.storage) else (if (match (s).writer with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.resourceLease) else Uorc.Uorc.Product.Api.ReleaseDisposition.releasable)))))

@[expose] public def preparationStepDisposition (s : PreparationStep) : Uorc.Uorc.Product.Api.ReleaseDisposition := (if (match (s).commands with | List.nil => false | List.cons _ _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.effect) else preparationDisposition ((s).state))

end Uorc.Uorc.Product.ResourceIO
