module
public import Init
public import Uorc.Uorc.Product.Api
public import Uorc.Uorc.Product.Control
public import Uorc.Uorc.Product.Evidence
public import Uorc.Uorc.Product.Selection
public import Uorc.Uorc.Product.Session
public import Uorc.Uorc.Product.Storage
public import Uorc.Uorc.Product.StreamProtocol
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
namespace Uorc.Uorc.Product.Workspace

namespace LexLeanRuntime

public class ToMathInt (α : Type) where
  toInt : α -> Int

public class Fixed (α : Type) extends ToMathInt α where
  fromInt : Int -> α
  minimum : Int
  maximum : Int
  bitAnd : α -> α -> α
  bitOr : α -> α -> α
  bitXor : α -> α -> α
  bitNot : α -> α
  shiftLeft : α -> UInt32 -> Option α
  shiftRight : α -> UInt32 -> Option α

public instance : ToMathInt Int where toInt := fun value => value

public instance : Fixed Int8 where
  toInt := Int8.toInt
  fromInt := Int8.ofInt
  minimum := -128
  maximum := 127
  bitAnd := Int8.land
  bitOr := Int8.lor
  bitXor := Int8.xor
  bitNot := Int8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (Int8.shiftLeft value (Int8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (Int8.shiftRight value (Int8.ofNat amount.toNat)) else none

public instance : Fixed Int16 where
  toInt := Int16.toInt
  fromInt := Int16.ofInt
  minimum := -32768
  maximum := 32767
  bitAnd := Int16.land
  bitOr := Int16.lor
  bitXor := Int16.xor
  bitNot := Int16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (Int16.shiftLeft value (Int16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (Int16.shiftRight value (Int16.ofNat amount.toNat)) else none

public instance : Fixed Int32 where
  toInt := Int32.toInt
  fromInt := Int32.ofInt
  minimum := -2147483648
  maximum := 2147483647
  bitAnd := Int32.land
  bitOr := Int32.lor
  bitXor := Int32.xor
  bitNot := Int32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (Int32.shiftLeft value (Int32.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (Int32.shiftRight value (Int32.ofNat amount.toNat)) else none

public instance : Fixed Int64 where
  toInt := Int64.toInt
  fromInt := Int64.ofInt
  minimum := -9223372036854775808
  maximum := 9223372036854775807
  bitAnd := Int64.land
  bitOr := Int64.lor
  bitXor := Int64.xor
  bitNot := Int64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (Int64.shiftLeft value (Int64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (Int64.shiftRight value (Int64.ofNat amount.toNat)) else none

public instance : Fixed UInt8 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt8.ofInt
  minimum := 0
  maximum := 255
  bitAnd := UInt8.land
  bitOr := UInt8.lor
  bitXor := UInt8.xor
  bitNot := UInt8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (UInt8.shiftLeft value (UInt8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (UInt8.shiftRight value (UInt8.ofNat amount.toNat)) else none

public instance : Fixed UInt16 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt16.ofInt
  minimum := 0
  maximum := 65535
  bitAnd := UInt16.land
  bitOr := UInt16.lor
  bitXor := UInt16.xor
  bitNot := UInt16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (UInt16.shiftLeft value (UInt16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (UInt16.shiftRight value (UInt16.ofNat amount.toNat)) else none

public instance : Fixed UInt32 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt32.ofInt
  minimum := 0
  maximum := 4294967295
  bitAnd := UInt32.land
  bitOr := UInt32.lor
  bitXor := UInt32.xor
  bitNot := UInt32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (UInt32.shiftLeft value amount) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (UInt32.shiftRight value amount) else none

public instance : Fixed UInt64 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt64.ofInt
  minimum := 0
  maximum := 18446744073709551615
  bitAnd := UInt64.land
  bitOr := UInt64.lor
  bitXor := UInt64.xor
  bitNot := UInt64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (UInt64.shiftLeft value (UInt64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (UInt64.shiftRight value (UInt64.ofNat amount.toNat)) else none

@[expose] public def checkedFromInt {α : Type} [Fixed α] (value : Int) : Option α :=
  if value < Fixed.minimum (α := α) then none else if Fixed.maximum (α := α) < value then none else some (Fixed.fromInt value)

@[expose] public def checkedConvert {α β : Type} [ToMathInt α] [Fixed β] (value : α) : Option β :=
  checkedFromInt (ToMathInt.toInt value)

@[expose] public def checkedAdd {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left + ToMathInt.toInt right)

@[expose] public def checkedSubtract {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left - ToMathInt.toInt right)

@[expose] public def checkedMultiply {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left * ToMathInt.toInt right)

@[expose] public def checkedNegate {α : Type} [Fixed α] (value : α) : Option α :=
  checkedFromInt (-ToMathInt.toInt value)

@[expose] public def checkedQuotient {α : Type} [Fixed α] (left right : α) : Option α :=
  if ToMathInt.toInt right = 0 then none else checkedFromInt (Int.tdiv (ToMathInt.toInt left) (ToMathInt.toInt right))

@[expose] public def checkedAddInt64 (left right : Int64) : Option Int64 :=
  let value := left + right
  if (0 < right && value < left) || (right < 0 && left < value) then none else some value

@[expose] public def checkedSubtractInt64 (left right : Int64) : Option Int64 :=
  let value := left - right
  if (0 < right && left < value) || (right < 0 && value < left) then none else some value

@[expose] public def checkedNegateInt64 (value : Int64) : Option Int64 :=
  if value == (-9223372036854775808 : Int64) then none else some (-value)

public def magnitudeInt64 (value : Int64) : UInt64 :=
  let bits := value.toUInt64
  if value < 0 then 0 - bits else bits

public def signedMagnitudeInt64 (negative : Bool) (value : UInt64) : Int64 :=
  (if negative then 0 - value else value).toInt64

public def divideMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> UInt64 -> UInt64
  | 0, _, _, _, quotient => quotient
  | Nat.succ fuel, source, divisor, remainder, quotient =>
      let high := 9223372036854775808 <= source
      let source := source + source
      let remainder := remainder + remainder + if high then 1 else 0
      let quotient := quotient + quotient
      if divisor <= remainder then
        divideMagnitudeInt64 fuel source divisor (remainder - divisor) (quotient + 1)
      else
        divideMagnitudeInt64 fuel source divisor remainder quotient

@[expose] public def checkedQuotientInt64 (left right : Int64) : Option Int64 :=
  if right == 0 then none
  else if left == (-9223372036854775808 : Int64) && right == (-1 : Int64) then none
  else
    let negative := (left < 0) != (right < 0)
    some (signedMagnitudeInt64 negative
      (divideMagnitudeInt64 64 (magnitudeInt64 left) (magnitudeInt64 right) 0 0))

public def multiplyMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> Bool -> Option UInt64
  | 0, _, _, accumulator, _ => some accumulator
  | Nat.succ fuel, source, multiplicand, accumulator, negative =>
      let high := 9223372036854775808 <= source
      let limit := if negative then 9223372036854775808 else 9223372036854775807
      let halfLimit := if negative then 4611686018427387904 else 4611686018427387903
      if halfLimit < accumulator then none
      else
        let doubled := accumulator + accumulator
        if high then
          if limit < multiplicand || limit - multiplicand < doubled then none
          else multiplyMagnitudeInt64 fuel (source + source) multiplicand
            (doubled + multiplicand) negative
        else
          multiplyMagnitudeInt64 fuel (source + source) multiplicand doubled negative

@[expose] public def checkedMultiplyInt64 (left right : Int64) : Option Int64 :=
  let negative := (left < 0) != (right < 0)
  match multiplyMagnitudeInt64 64 (magnitudeInt64 right) (magnitudeInt64 left) 0 negative with
  | none => none
  | some value => some (signedMagnitudeInt64 negative value)

@[noinline] public def subtract {α : Type} [Sub α] (left right : α) : α := left - right
@[noinline] public def multiply {α : Type} [Mul α] (left right : α) : α := left * right
@[noinline] public def negate {α : Type} [Neg α] (value : α) : α := -value

public class Quotient (α : Type) where
  quotient : α -> α -> α
  remainder : α -> α -> α
  isZero : α -> Bool

public instance : Quotient Nat where
  quotient := Nat.div
  remainder := Nat.mod
  isZero := fun value => value == 0

public instance : Quotient Int where
  quotient := Int.tdiv
  remainder := Int.tmod
  isZero := fun value => value == 0

@[noinline] public def quotient {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.quotient left right

@[noinline] public def remainder {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.remainder left right

@[expose] public def bitAnd {α : Type} [Fixed α] (left right : α) : α := Fixed.bitAnd left right
@[expose] public def bitOr {α : Type} [Fixed α] (left right : α) : α := Fixed.bitOr left right
@[expose] public def bitXor {α : Type} [Fixed α] (left right : α) : α := Fixed.bitXor left right
@[expose] public def bitNot {α : Type} [Fixed α] (value : α) : α := Fixed.bitNot value
@[expose] public def shiftLeft {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftLeft value amount
@[expose] public def shiftRight {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftRight value amount

public class Appendable (α : Type) where append : α -> α -> α
public instance {α : Type} : Appendable (List α) where append := List.append
public instance : Appendable ByteArray where append := ByteArray.append
@[expose] public def append {α : Type} [Appendable α] (left right : α) : α := Appendable.append left right

public class Lengthable (α : Type) where length : α -> Nat
public instance {α : Type} : Lengthable (List α) where length := List.length
public instance : Lengthable ByteArray where length := ByteArray.size
public instance : Lengthable String where length := String.length
@[expose] public def length {α : Type} [Lengthable α] (value : α) : Nat := Lengthable.length value

@[expose] public def listIndex {α : Type} : List α -> Nat -> Option α
  | [], _ => none
  | head :: _, 0 => some head
  | _ :: tail, index + 1 => listIndex tail index

public class Indexable (α β : Type) where index : α -> Nat -> Option β
public instance {α : Type} : Indexable (List α) α where index := listIndex
public instance : Indexable ByteArray UInt8 where index := fun value offset => value.data[offset]?
@[noinline] public def index {α β : Type} [Indexable α β] (value : α) (offset : Nat) : Option β := Indexable.index value offset

public class Sliceable (α : Type) where slice : α -> Nat -> Nat -> Option α
public instance {α : Type} : Sliceable (List α) where
  slice := fun value start count => if start + count <= value.length then some ((value.drop start).take count) else none
public instance : Sliceable ByteArray where
  slice := fun value start count => if start + count <= value.size then some (value.extract start (start + count)) else none
@[noinline] public def slice {α : Type} [Sliceable α] (value : α) (start count : Nat) : Option α := Sliceable.slice value start count

@[noinline] public def utf8Encode (value : String) : ByteArray := value.toUTF8
@[noinline] public def utf8Decode (value : ByteArray) : Option String := String.fromUTF8? value
@[noinline] public def compareBytes (left right : ByteArray) : Ordering := compare left.toList right.toList
@[expose] public def equal {α : Type} [BEq α] (left right : α) : Bool := left == right

@[noinline] public def splitExact (value delimiter : String) (maximum : UInt32) : Option (List String) :=
  let fields := value.splitOn delimiter
  if delimiter.isEmpty || maximum.toNat < fields.length then none else some fields

@[noinline] public def join (values : List String) (delimiter : String) : String := delimiter.intercalate values

public class Decimal (α : Type) where
  parse : String -> Option α
  format : α -> String

public instance : Decimal Int where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then some parsed else none | none => none
  format := toString

public instance {α : Type} [Fixed α] [ToString α] : Decimal α where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then checkedFromInt parsed else none | none => none
  format := toString

@[noinline] public def parseDecimal {α : Type} [Decimal α] (value : String) : Option α := Decimal.parse value
@[noinline] public def formatDecimal {α : Type} [Decimal α] (value : α) : String := Decimal.format value

end LexLeanRuntime

public inductive Slot where
  | input
  | archive
  | basis
  | originals
  | checkpoint
  | comparison

public structure Draft where
  operation : Uorc.Uorc.Product.Evidence.Operation
  input : Option (Uorc.Uorc.Product.Api.ResourceRef)
  archive : Option (Uorc.Uorc.Product.Api.ResourceRef)
  basis : Option (Uorc.Uorc.Product.Api.ResourceRef)
  originals : Option (Uorc.Uorc.Product.Api.ResourceRef)
  checkpoint : Option (Uorc.Uorc.Product.Api.ResourceRef)
  comparison : Option (Uorc.Uorc.Product.Api.ResourceRef)
  limits : Uorc.Uorc.Product.Api.Limits

@[expose] public def defaultLimits : Uorc.Uorc.Product.Api.Limits := ({ decodeWork := 10000000, checkerWork := 10000000, replayWork := 10000000, searchWork := 1000000, outputBytes := Option.none, ownedBytes := 268435456, storage := Uorc.Uorc.Product.Storage.unlimitedRequest } : Uorc.Uorc.Product.Api.Limits)

@[expose] public def selectedResource (draft : Draft) (slot : Slot) : Option (Uorc.Uorc.Product.Api.ResourceRef) := (match slot with | Slot.input => (draft).input | Slot.archive => (draft).archive | Slot.basis => (draft).basis | Slot.originals => (draft).originals | Slot.checkpoint => (draft).checkpoint | Slot.comparison => (draft).comparison)

@[expose] public def setSlot (draft : Draft) (slot : Slot) (resource : Option (Uorc.Uorc.Product.Api.ResourceRef)) : Draft := (match slot with | Slot.input => ({ operation := (draft).operation, input := resource, archive := (draft).archive, basis := (draft).basis, originals := (draft).originals, checkpoint := (draft).checkpoint, comparison := (draft).comparison, limits := (draft).limits } : Draft) | Slot.archive => ({ operation := (draft).operation, input := (draft).input, archive := resource, basis := (draft).basis, originals := (draft).originals, checkpoint := (draft).checkpoint, comparison := (draft).comparison, limits := (draft).limits } : Draft) | Slot.basis => ({ operation := (draft).operation, input := (draft).input, archive := (draft).archive, basis := resource, originals := (draft).originals, checkpoint := (draft).checkpoint, comparison := (draft).comparison, limits := (draft).limits } : Draft) | Slot.originals => ({ operation := (draft).operation, input := (draft).input, archive := (draft).archive, basis := (draft).basis, originals := resource, checkpoint := (draft).checkpoint, comparison := (draft).comparison, limits := (draft).limits } : Draft) | Slot.checkpoint => ({ operation := (draft).operation, input := (draft).input, archive := (draft).archive, basis := (draft).basis, originals := (draft).originals, checkpoint := resource, comparison := (draft).comparison, limits := (draft).limits } : Draft) | Slot.comparison => ({ operation := (draft).operation, input := (draft).input, archive := (draft).archive, basis := (draft).basis, originals := (draft).originals, checkpoint := (draft).checkpoint, comparison := resource, limits := (draft).limits } : Draft))

@[expose] public def request (draft : Draft) : Except (Uorc.Uorc.Product.Api.ControlError) (Uorc.Uorc.Product.Api.Request) := (match (draft).operation with | Uorc.Uorc.Product.Evidence.Operation.compress => (match (draft).input with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingInput) | Option.some input => Except.ok (Uorc.Uorc.Product.Api.Request.compress (({ input := input, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.CompressRequest)))) | Uorc.Uorc.Product.Evidence.Operation.decompress => (match (draft).archive with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingArchive) | Option.some archive => Except.ok (Uorc.Uorc.Product.Api.Request.decompress (({ archive := archive, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.ArchiveRequest)))) | Uorc.Uorc.Product.Evidence.Operation.inspect => (match (draft).archive with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingArchive) | Option.some archive => Except.ok (Uorc.Uorc.Product.Api.Request.inspect (({ archive := archive, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.ArchiveRequest)))) | Uorc.Uorc.Product.Evidence.Operation.verify => (match (draft).archive with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingArchive) | Option.some archive => Except.ok (Uorc.Uorc.Product.Api.Request.verify (({ archive := archive, originals := (draft).originals, certificate := Option.none, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.VerifyRequest)))) | Uorc.Uorc.Product.Evidence.Operation.resume => (match (draft).input with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingInput) | Option.some input => (match (draft).checkpoint with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.noCheckpoint) | Option.some checkpoint => Except.ok (Uorc.Uorc.Product.Api.Request.resume (({ input := input, checkpoint := checkpoint, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.ResumeRequest))))) | Uorc.Uorc.Product.Evidence.Operation.buildBasis => (match (draft).input with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingInput) | Option.some input => Except.ok (Uorc.Uorc.Product.Api.Request.buildBasis (({ input := input, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.BasisRequest)))) | Uorc.Uorc.Product.Evidence.Operation.analyzeFrontier => (match (draft).input with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingInput) | Option.some input => Except.ok (Uorc.Uorc.Product.Api.Request.analyzeFrontier (({ input := input, incumbent := (draft).archive, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.FrontierRequest)))) | Uorc.Uorc.Product.Evidence.Operation.compare => (match (draft).archive with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingArchive) | Option.some archive => (match (draft).comparison with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingComparison) | Option.some comparison => Except.ok (Uorc.Uorc.Product.Api.Request.compare (({ left := archive, right := comparison, originals := (draft).originals, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.CompareRequest))))) | Uorc.Uorc.Product.Evidence.Operation.runAcceptance => (match (draft).input with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingInput) | Option.some input => Except.ok (Uorc.Uorc.Product.Api.Request.runAcceptance (({ input := input, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.ToolRequest)))) | Uorc.Uorc.Product.Evidence.Operation.runCoreRequest => (match (draft).input with | Option.none => Except.error (Uorc.Uorc.Product.Api.ControlError.missingInput) | Option.some input => Except.ok (Uorc.Uorc.Product.Api.Request.runCoreRequest (({ input := input, options := ({ limits := (draft).limits, basis := (draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.ToolRequest)))))

@[expose] public def selectionEffects (old : Option (Uorc.Uorc.Product.Api.ResourceRef)) (incoming : Option (Uorc.Uorc.Product.Api.ResourceRef)) : List (Uorc.Uorc.Product.Control.Effect) := (match old with | Option.none => ([] : List (Uorc.Uorc.Product.Control.Effect)) | Option.some oldResource => (match incoming with | Option.none => (Uorc.Uorc.Product.Control.Effect.release (oldResource) :: ([] : List (Uorc.Uorc.Product.Control.Effect))) | Option.some newResource => (if Uorc.Uorc.Product.Api.sameResource (oldResource) (newResource) then ([] : List (Uorc.Uorc.Product.Control.Effect)) else (Uorc.Uorc.Product.Control.Effect.release (oldResource) :: ([] : List (Uorc.Uorc.Product.Control.Effect))))))

@[expose] public def releaseDraft (draft : Draft) : List (Uorc.Uorc.Product.Control.Effect) := Uorc.Uorc.Product.Control.appendEffects (Uorc.Uorc.Product.Control.releaseOutput ((draft).input)) (Uorc.Uorc.Product.Control.appendEffects (Uorc.Uorc.Product.Control.releaseOutput ((draft).archive)) (Uorc.Uorc.Product.Control.appendEffects (Uorc.Uorc.Product.Control.releaseOutput ((draft).basis)) (Uorc.Uorc.Product.Control.appendEffects (Uorc.Uorc.Product.Control.releaseOutput ((draft).originals)) (Uorc.Uorc.Product.Control.appendEffects (Uorc.Uorc.Product.Control.releaseOutput ((draft).checkpoint)) (Uorc.Uorc.Product.Control.appendEffects (Uorc.Uorc.Product.Control.releaseOutput ((draft).comparison)) (([] : List (Uorc.Uorc.Product.Control.Effect))))))))

@[expose] public def sameSlot (left : Slot) (right : Slot) : Bool := (match left with | Slot.input => (match right with | Slot.input => true | Slot.archive => false | Slot.basis => false | Slot.originals => false | Slot.checkpoint => false | Slot.comparison => false) | Slot.archive => (match right with | Slot.input => false | Slot.archive => true | Slot.basis => false | Slot.originals => false | Slot.checkpoint => false | Slot.comparison => false) | Slot.basis => (match right with | Slot.input => false | Slot.archive => false | Slot.basis => true | Slot.originals => false | Slot.checkpoint => false | Slot.comparison => false) | Slot.originals => (match right with | Slot.input => false | Slot.archive => false | Slot.basis => false | Slot.originals => true | Slot.checkpoint => false | Slot.comparison => false) | Slot.checkpoint => (match right with | Slot.input => false | Slot.archive => false | Slot.basis => false | Slot.originals => false | Slot.checkpoint => true | Slot.comparison => false) | Slot.comparison => (match right with | Slot.input => false | Slot.archive => false | Slot.basis => false | Slot.originals => false | Slot.checkpoint => false | Slot.comparison => true))

public inductive Action where
  | cancel
  | navigate (_ : Uorc.Uorc.Product.Control.Page)
  | back
  | detach
  | close
  | shutdown
  | download
  | extend (_ : Nat)
  | retryPublication

public inductive Intent where
  | choose (_ : Uorc.Uorc.Product.Evidence.Operation)
  | pick (_ : Slot)
  | selected (_ : Slot) (_ : Uorc.Uorc.Product.Api.Run) (_ : Nat) (_ : Uorc.Uorc.Product.Api.ResourceRef) (_ : List (Uorc.Uorc.Product.Selection.Item))
  | remove (_ : Slot)
  | limits (_ : Uorc.Uorc.Product.Api.Limits)
  | start
  | control (_ : Action)
  | continueSearch (_ : Nat)
  | removeItem (_ : Slot) (_ : Nat)
  | moveItem (_ : Slot) (_ : Nat) (_ : Nat)
  | collectionEdited (_ : Uorc.Uorc.Product.Api.Run) (_ : Nat) (_ : Uorc.Uorc.Product.Api.ResourceRef) (_ : List (Uorc.Uorc.Product.Selection.Item))
  | collectionEditFailed (_ : Uorc.Uorc.Product.Api.Run) (_ : Nat) (_ : String)

public inductive RuntimeNotice where
  | cleanupComplete (_ : Nat)
  | demand (_ : Uorc.Uorc.Product.Api.Run)
  | progress (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.Api.Progress)
  | checkpoint (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.Api.ResourceRef)
  | completed (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.Api.Report)
  | failed (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.Api.FailureReport)
  | hostFailed (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.Api.HostFailure)
  | publication (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.StreamProtocol.Publication)
  | staged (_ : Uorc.Uorc.Product.Api.Run) (_ : Nat)
  | storage (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.Storage.Event)
  | retiredStorage (_ : Uorc.Uorc.Product.Api.Run) (_ : Uorc.Uorc.Product.Storage.Event)
  | retiredCleanupComplete (_ : Uorc.Uorc.Product.Api.Run)

public inductive FocusTarget where
  | file (_ : Slot)
  | operation
  | status
  | result
  | error
  | heading

public structure FocusRequest where
  serial : Nat
  target : FocusTarget

public structure SelectedItems where
  slot : Slot
  items : List (Uorc.Uorc.Product.Selection.Item)

public structure CollectionEdit where
  slot : Slot
  run : Uorc.Uorc.Product.Api.Run
  pickerSerial : Nat
  previous : Uorc.Uorc.Product.Api.ResourceRef
  items : List (Uorc.Uorc.Product.Selection.Item)
  previousItems : List (Uorc.Uorc.Product.Selection.Item)

public inductive Effect where
  | control (_ : Uorc.Uorc.Product.Control.Effect)
  | pick (_ : Slot) (_ : Uorc.Uorc.Product.Api.Run) (_ : Nat)
  | editCollection (_ : CollectionEdit)
  | cancelCollection (_ : CollectionEdit)

@[expose] public def liftEffects : (effects : List (Uorc.Uorc.Product.Control.Effect)) -> List (Effect)
  | List.nil => ([] : List (Effect))
  | List.cons head tail => (Effect.control (head) :: liftEffects (tail))

public structure State where
  control : Uorc.Uorc.Product.Control.State
  draft : Draft
  pickerSerial : Nat
  pickerSlot : Option (Slot)
  focusRequest : FocusRequest
  selectedItems : List (SelectedItems)
  collectionEdit : Option (CollectionEdit)

public structure Update where
  state : State
  effects : List (Effect)

@[expose] public def initial («instance» : Nat) : State := ({ control := Uorc.Uorc.Product.Control.initial («instance»), draft := ({ operation := Uorc.Uorc.Product.Evidence.Operation.compress, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := defaultLimits } : Draft), pickerSerial := 0, pickerSlot := Option.none, focusRequest := ({ serial := 0, target := FocusTarget.file (Slot.input) } : FocusRequest), selectedItems := ([] : List (SelectedItems)), collectionEdit := Option.none } : State)

@[expose] public def fromControl (s : State) (draft : Draft) (transition : Uorc.Uorc.Product.Control.Transition) : Update := ({ state := ({ control := (transition).state, draft := draft, pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects ((transition).effects) } : Update)

@[expose] public def changed (s : State) (draft : Draft) : Update := fromControl (s) (draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.edit))

@[expose] public def choose (s : State) (draft : Draft) (operation : Uorc.Uorc.Product.Evidence.Operation) : Update := changed (s) (({ operation := operation, input := (draft).input, archive := (draft).archive, basis := (draft).basis, originals := (draft).originals, checkpoint := (draft).checkpoint, comparison := (draft).comparison, limits := (draft).limits } : Draft))

@[expose] public def setLimits (s : State) (draft : Draft) (limits : Uorc.Uorc.Product.Api.Limits) : Update := changed (s) (({ operation := (draft).operation, input := (draft).input, archive := (draft).archive, basis := (draft).basis, originals := (draft).originals, checkpoint := (draft).checkpoint, comparison := (draft).comparison, limits := limits } : Draft))

@[expose] public def select (s : State) (slot : Slot) (resource : Option (Uorc.Uorc.Product.Api.ResourceRef)) : Update := ({ state := (changed (s) (setSlot ((s).draft) (slot) (resource))).state, effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (selectionEffects (selectedResource ((s).draft) (slot)) (resource)) ((Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.edit)).effects)) } : Update)

@[expose] public def shutdown (s : State) : Update := (match (s).collectionEdit with | Option.none => (if ((s).control).closed then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.shutdown ((s).control)) else ({ state := ({ control := (Uorc.Uorc.Product.Control.shutdown ((s).control)).state, draft := ({ operation := ((s).draft).operation, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := ((s).draft).limits } : Draft), pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (releaseDraft ((s).draft)) ((Uorc.Uorc.Product.Control.shutdown ((s).control)).effects)) } : Update)) | Option.some pendingEdit => ({ state := ({ control := (((if ((s).control).closed then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.shutdown ((s).control)) else ({ state := ({ control := (Uorc.Uorc.Product.Control.shutdown ((s).control)).state, draft := ({ operation := ((s).draft).operation, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := ((s).draft).limits } : Draft), pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (releaseDraft ((s).draft)) ((Uorc.Uorc.Product.Control.shutdown ((s).control)).effects)) } : Update))).state).control, draft := (((if ((s).control).closed then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.shutdown ((s).control)) else ({ state := ({ control := (Uorc.Uorc.Product.Control.shutdown ((s).control)).state, draft := ({ operation := ((s).draft).operation, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := ((s).draft).limits } : Draft), pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (releaseDraft ((s).draft)) ((Uorc.Uorc.Product.Control.shutdown ((s).control)).effects)) } : Update))).state).draft, pickerSerial := (((if ((s).control).closed then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.shutdown ((s).control)) else ({ state := ({ control := (Uorc.Uorc.Product.Control.shutdown ((s).control)).state, draft := ({ operation := ((s).draft).operation, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := ((s).draft).limits } : Draft), pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (releaseDraft ((s).draft)) ((Uorc.Uorc.Product.Control.shutdown ((s).control)).effects)) } : Update))).state).pickerSerial, pickerSlot := (((if ((s).control).closed then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.shutdown ((s).control)) else ({ state := ({ control := (Uorc.Uorc.Product.Control.shutdown ((s).control)).state, draft := ({ operation := ((s).draft).operation, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := ((s).draft).limits } : Draft), pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (releaseDraft ((s).draft)) ((Uorc.Uorc.Product.Control.shutdown ((s).control)).effects)) } : Update))).state).pickerSlot, focusRequest := (((if ((s).control).closed then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.shutdown ((s).control)) else ({ state := ({ control := (Uorc.Uorc.Product.Control.shutdown ((s).control)).state, draft := ({ operation := ((s).draft).operation, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := ((s).draft).limits } : Draft), pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (releaseDraft ((s).draft)) ((Uorc.Uorc.Product.Control.shutdown ((s).control)).effects)) } : Update))).state).focusRequest, selectedItems := (((if ((s).control).closed then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.shutdown ((s).control)) else ({ state := ({ control := (Uorc.Uorc.Product.Control.shutdown ((s).control)).state, draft := ({ operation := ((s).draft).operation, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := ((s).draft).limits } : Draft), pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (releaseDraft ((s).draft)) ((Uorc.Uorc.Product.Control.shutdown ((s).control)).effects)) } : Update))).state).selectedItems, collectionEdit := Option.none } : State), effects := (Effect.cancelCollection (pendingEdit) :: (Effect.control (Uorc.Uorc.Product.Control.Effect.release ((pendingEdit).previous)) :: ((if ((s).control).closed then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.shutdown ((s).control)) else ({ state := ({ control := (Uorc.Uorc.Product.Control.shutdown ((s).control)).state, draft := ({ operation := ((s).draft).operation, input := Option.none, archive := Option.none, basis := Option.none, originals := Option.none, checkpoint := Option.none, comparison := Option.none, limits := ((s).draft).limits } : Draft), pickerSerial := (s).pickerSerial, pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := liftEffects (Uorc.Uorc.Product.Control.appendEffects (releaseDraft ((s).draft)) ((Uorc.Uorc.Product.Control.shutdown ((s).control)).effects)) } : Update))).effects)) } : Update))

@[expose] public def acceptPicker (s : State) (slotRequested : Slot) (run : Uorc.Uorc.Product.Api.Run) (pickerSerial : Nat) (resource : Uorc.Uorc.Product.Api.ResourceRef) : Bool := (Uorc.Uorc.Product.Control.sameRun ((s).control) (run) && ((Nat.beq ((s).pickerSerial) (pickerSerial)) && ((Nat.beq ((resource).«instance») (((s).control).«instance»)) && ((match (s).pickerSlot with | Option.none => false | Option.some slot => sameSlot (slot) (slotRequested)) && true))))

@[expose] public def pick (s : State) (slot : Slot) : Update := (if (((s).control).attached && ((!((s).control).closed) && true)) then ({ state := ({ control := (s).control, draft := (s).draft, pickerSerial := ((s).pickerSerial + 1), pickerSlot := Option.some (slot), focusRequest := (s).focusRequest, selectedItems := (s).selectedItems, collectionEdit := (s).collectionEdit } : State), effects := (Effect.pick (slot) (Uorc.Uorc.Product.Control.run ((s).control)) (((s).pickerSerial + 1)) :: ([] : List (Effect))) } : Update) else ({ state := s, effects := ([] : List (Effect)) } : Update))

@[expose] public def continueSearch (s : State) (credit : Nat) : Update := (if (((s).control).session).active then fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.extend ((s).control) (credit)) else (match ((s).control).checkpoint with | Option.none => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.reject ((s).control) (Uorc.Uorc.Product.Api.Failure.control (Uorc.Uorc.Product.Api.ControlError.noCheckpoint))) | Option.some checkpoint => (match ((s).draft).input with | Option.none => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.reject ((s).control) (Uorc.Uorc.Product.Api.Failure.control (Uorc.Uorc.Product.Api.ControlError.missingInput))) | Option.some input => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.resume ((s).control) (({ input := input, checkpoint := checkpoint, options := ({ limits := ({ decodeWork := (((s).draft).limits).decodeWork, checkerWork := (((s).draft).limits).checkerWork, replayWork := (((s).draft).limits).replayWork, searchWork := ((((s).draft).limits).searchWork + credit), outputBytes := (((s).draft).limits).outputBytes, ownedBytes := (((s).draft).limits).ownedBytes, storage := (((s).draft).limits).storage } : Uorc.Uorc.Product.Api.Limits), basis := ((s).draft).basis } : Uorc.Uorc.Product.Api.Common) } : Uorc.Uorc.Product.Api.ResumeRequest))))))

@[expose] public def controlIntent (s : State) (event : Action) : Update := (match event with | Action.cancel => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.cancel)) | Action.navigate v0 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.navigate (v0))) | Action.back => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.back)) | Action.detach => shutdown (s) | Action.close => shutdown (s) | Action.shutdown => shutdown (s) | Action.download => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.download)) | Action.extend v0 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.extend (v0))) | Action.retryPublication => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.retryPublication)))

@[expose] public def requestFocus (s : State) (update : Update) (target : FocusTarget) : Update := ({ state := ({ control := ((update).state).control, draft := ((update).state).draft, pickerSerial := ((update).state).pickerSerial, pickerSlot := ((update).state).pickerSlot, focusRequest := ({ serial := (((s).focusRequest).serial + 1), target := target } : FocusRequest), selectedItems := ((update).state).selectedItems, collectionEdit := ((update).state).collectionEdit } : State), effects := (update).effects } : Update)

@[expose] public def intentFocus (s : State) (intent : Intent) (update : Update) : Update := (if (match (((update).state).control).error with | Option.none => (match (((update).state).control).hostFailure with | Option.none => false | Option.some _ => true) | Option.some _ => true) then requestFocus (s) (update) (FocusTarget.error) else (match intent with | Intent.choose _ => requestFocus (s) (update) (FocusTarget.operation) | Intent.pick _ => update | Intent.selected v0 _ _ _ _ => requestFocus (s) (update) (FocusTarget.file (v0)) | Intent.remove v0 => requestFocus (s) (update) (FocusTarget.file (v0)) | Intent.limits _ => update | Intent.start => requestFocus (s) (update) (FocusTarget.status) | Intent.control v0 => (match v0 with | Action.cancel => requestFocus (s) (update) (FocusTarget.status) | Action.navigate _ => requestFocus (s) (update) (FocusTarget.heading) | Action.back => requestFocus (s) (update) (FocusTarget.heading) | Action.detach => update | Action.close => update | Action.shutdown => update | Action.download => requestFocus (s) (update) (FocusTarget.status) | Action.extend _ => requestFocus (s) (update) (FocusTarget.status) | Action.retryPublication => requestFocus (s) (update) (FocusTarget.status)) | Intent.continueSearch _ => requestFocus (s) (update) (FocusTarget.status) | Intent.removeItem slot _ => requestFocus (s) (update) (FocusTarget.file (slot)) | Intent.moveItem slot _ _ => requestFocus (s) (update) (FocusTarget.file (slot)) | Intent.collectionEdited _ _ _ _ => update | Intent.collectionEditFailed _ _ _ => update))

@[expose] public def runtimeFocus (s : State) (notice : RuntimeNotice) (update : Update) : Update := (match notice with | RuntimeNotice.cleanupComplete _ => update | RuntimeNotice.demand _ => update | RuntimeNotice.progress _ _ => update | RuntimeNotice.checkpoint _ _ => update | RuntimeNotice.completed v0 _ => (if Uorc.Uorc.Product.Control.owns ((s).control) (v0) then (if (match (((update).state).control).error with | Option.none => (match (((update).state).control).hostFailure with | Option.none => false | Option.some _ => true) | Option.some _ => true) then requestFocus (s) (update) (FocusTarget.error) else requestFocus (s) (update) (FocusTarget.result)) else update) | RuntimeNotice.failed v0 _ => (if (Uorc.Uorc.Product.Control.sameRun ((s).control) (v0) && ((if ((s).control).publicationPending then true else (((s).control).session).active) && true)) then (if (match (((update).state).control).error with | Option.none => (match (((update).state).control).hostFailure with | Option.none => false | Option.some _ => true) | Option.some _ => true) then requestFocus (s) (update) (FocusTarget.error) else requestFocus (s) (update) (FocusTarget.result)) else update) | RuntimeNotice.hostFailed v0 _ => (if Uorc.Uorc.Product.Control.owns ((s).control) (v0) then (if (match (((update).state).control).error with | Option.none => (match (((update).state).control).hostFailure with | Option.none => false | Option.some _ => true) | Option.some _ => true) then requestFocus (s) (update) (FocusTarget.error) else requestFocus (s) (update) (FocusTarget.result)) else update) | RuntimeNotice.publication v0 _ => (if (Uorc.Uorc.Product.Control.sameRun ((s).control) (v0) && (((s).control).publicationPending && true)) then (if (match (((update).state).control).error with | Option.none => (match (((update).state).control).hostFailure with | Option.none => false | Option.some _ => true) | Option.some _ => true) then requestFocus (s) (update) (FocusTarget.error) else requestFocus (s) (update) (FocusTarget.result)) else update) | RuntimeNotice.staged _ _ => update | RuntimeNotice.storage v0 _ => (if (Uorc.Uorc.Product.Control.sameRun ((s).control) (v0) && ((match ((s).control).error with | Option.none => true | Option.some _ => false) && ((match (((update).state).control).error with | Option.none => (match (((update).state).control).hostFailure with | Option.none => false | Option.some _ => true) | Option.some _ => true) && true))) then requestFocus (s) (update) (FocusTarget.error) else update) | RuntimeNotice.retiredStorage _ _ => update | RuntimeNotice.retiredCleanupComplete _ => update)

@[expose] public def receiveRuntime (s : State) (notice : RuntimeNotice) : Update := runtimeFocus (s) (notice) ((match notice with | RuntimeNotice.cleanupComplete v0 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.cleanupComplete (v0))) | RuntimeNotice.demand v0 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.demand (v0))) | RuntimeNotice.progress v0 v1 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.progress (v0) (v1))) | RuntimeNotice.checkpoint v0 v1 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.checkpoint (v0) (v1))) | RuntimeNotice.completed v0 v1 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.completed (v0) (v1))) | RuntimeNotice.failed v0 v1 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.failed (v0) (v1))) | RuntimeNotice.hostFailed v0 v1 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.hostFailed (v0) (v1))) | RuntimeNotice.publication v0 v1 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.publication (v0) (v1))) | RuntimeNotice.staged v0 v1 => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.staged (v0) (v1))) | RuntimeNotice.storage run event => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.storage (run) (event))) | RuntimeNotice.retiredStorage owner storageEvent => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.retiredStorage (owner) (storageEvent))) | RuntimeNotice.retiredCleanupComplete owner => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.retiredCleanupComplete (owner)))))

@[expose] public def itemsFor : (selections : List (SelectedItems)) -> (slot : Slot) -> List (Uorc.Uorc.Product.Selection.Item)
  | List.nil, _slot => ([] : List (Uorc.Uorc.Product.Selection.Item))
  | List.cons head tail, slot => (if sameSlot ((head).slot) (slot) then (head).items else itemsFor (tail) (slot))

@[expose] public def setItems : (selections : List (SelectedItems)) -> (slot : Slot) -> (items : List (Uorc.Uorc.Product.Selection.Item)) -> List (SelectedItems)
  | List.nil, slot, items => (({ slot := slot, items := items } : SelectedItems) :: ([] : List (SelectedItems)))
  | List.cons head tail, slot, items => (if sameSlot ((head).slot) (slot) then (({ slot := slot, items := items } : SelectedItems) :: tail) else (head :: setItems (tail) (slot) (items)))

@[expose] public def selectedUpdate (s : State) (slot : Slot) (resource : Uorc.Uorc.Product.Api.ResourceRef) (items : List (Uorc.Uorc.Product.Selection.Item)) : Update := ({ state := ({ control := ((select (s) (slot) (Option.some (resource))).state).control, draft := ((select (s) (slot) (Option.some (resource))).state).draft, pickerSerial := ((select (s) (slot) (Option.some (resource))).state).pickerSerial, pickerSlot := ((select (s) (slot) (Option.some (resource))).state).pickerSlot, focusRequest := ((select (s) (slot) (Option.some (resource))).state).focusRequest, selectedItems := setItems ((s).selectedItems) (slot) (items), collectionEdit := ((select (s) (slot) (Option.some (resource))).state).collectionEdit } : State), effects := (select (s) (slot) (Option.some (resource))).effects } : Update)

@[expose] public def beginCollectionEdit (s : State) (slot : Slot) (items : List (Uorc.Uorc.Product.Selection.Item)) : Update := (match (s).collectionEdit with | Option.some _ => ({ state := s, effects := ([] : List (Effect)) } : Update) | Option.none => (match selectedResource ((s).draft) (slot) with | Option.none => ({ state := s, effects := ([] : List (Effect)) } : Update) | Option.some previous => ({ state := ({ control := (Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.edit)).state, draft := setSlot ((s).draft) (slot) (Option.none), pickerSerial := ((s).pickerSerial + 1), pickerSlot := Option.none, focusRequest := (s).focusRequest, selectedItems := setItems ((s).selectedItems) (slot) (items), collectionEdit := Option.some (({ slot := slot, run := Uorc.Uorc.Product.Control.run ((Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.edit)).state), pickerSerial := ((s).pickerSerial + 1), previous := previous, items := items, previousItems := itemsFor ((s).selectedItems) (slot) } : CollectionEdit)) } : State), effects := (Effect.editCollection (({ slot := slot, run := Uorc.Uorc.Product.Control.run ((Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.edit)).state), pickerSerial := ((s).pickerSerial + 1), previous := previous, items := items, previousItems := itemsFor ((s).selectedItems) (slot) } : CollectionEdit)) :: liftEffects ((Uorc.Uorc.Product.Control.step ((s).control) (Uorc.Uorc.Product.Control.Event.edit)).effects)) } : Update)))

@[expose] public def collectionEdited (s : State) (run : Uorc.Uorc.Product.Api.Run) (pickerSerial : Nat) (resource : Uorc.Uorc.Product.Api.ResourceRef) (items : List (Uorc.Uorc.Product.Selection.Item)) : Update := (match (s).collectionEdit with | Option.none => ({ state := s, effects := (Effect.control (Uorc.Uorc.Product.Control.Effect.release (resource)) :: ([] : List (Effect))) } : Update) | Option.some edit => (if (Uorc.Uorc.Product.Control.sameRun ((s).control) (run) && ((Nat.beq ((edit).pickerSerial) (pickerSerial)) && ((Nat.beq ((resource).«instance») (((s).control).«instance»)) && (Uorc.Uorc.Product.Selection.valid (items) && (Uorc.Uorc.Product.Selection.sameOrder ((edit).items) (items) && true))))) then ({ state := ({ control := ((selectedUpdate (s) ((edit).slot) (resource) (items)).state).control, draft := ((selectedUpdate (s) ((edit).slot) (resource) (items)).state).draft, pickerSerial := ((selectedUpdate (s) ((edit).slot) (resource) (items)).state).pickerSerial, pickerSlot := ((selectedUpdate (s) ((edit).slot) (resource) (items)).state).pickerSlot, focusRequest := ((selectedUpdate (s) ((edit).slot) (resource) (items)).state).focusRequest, selectedItems := ((selectedUpdate (s) ((edit).slot) (resource) (items)).state).selectedItems, collectionEdit := Option.none } : State), effects := (Effect.control (Uorc.Uorc.Product.Control.Effect.release ((edit).previous)) :: (selectedUpdate (s) ((edit).slot) (resource) (items)).effects) } : Update) else ({ state := s, effects := (Effect.control (Uorc.Uorc.Product.Control.Effect.release (resource)) :: ([] : List (Effect))) } : Update)))

@[expose] public def abortCollectionEdit (s : State) : Update := (match (s).collectionEdit with | Option.none => ({ state := s, effects := ([] : List (Effect)) } : Update) | Option.some edit => ({ state := ({ control := (s).control, draft := setSlot ((s).draft) ((edit).slot) (Option.some ((edit).previous)), pickerSerial := ((s).pickerSerial + 1), pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := setItems ((s).selectedItems) ((edit).slot) ((edit).previousItems), collectionEdit := Option.none } : State), effects := (Effect.cancelCollection (edit) :: ([] : List (Effect))) } : Update))

@[expose] public def collectionEditFailed (s : State) (run : Uorc.Uorc.Product.Api.Run) (pickerSerial : Nat) (detail : String) : Update := (match (s).collectionEdit with | Option.none => ({ state := s, effects := ([] : List (Effect)) } : Update) | Option.some edit => (if (Uorc.Uorc.Product.Control.sameRun ((s).control) (run) && ((Nat.beq ((edit).pickerSerial) (pickerSerial)) && true)) then ({ state := ({ control := (Uorc.Uorc.Product.Control.reject ((s).control) (Uorc.Uorc.Product.Api.Failure.inputIo (detail))).state, draft := (({ control := (s).control, draft := setSlot ((s).draft) ((edit).slot) (Option.some ((edit).previous)), pickerSerial := ((s).pickerSerial + 1), pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := setItems ((s).selectedItems) ((edit).slot) ((edit).previousItems), collectionEdit := Option.none } : State)).draft, pickerSerial := (({ control := (s).control, draft := setSlot ((s).draft) ((edit).slot) (Option.some ((edit).previous)), pickerSerial := ((s).pickerSerial + 1), pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := setItems ((s).selectedItems) ((edit).slot) ((edit).previousItems), collectionEdit := Option.none } : State)).pickerSerial, pickerSlot := (({ control := (s).control, draft := setSlot ((s).draft) ((edit).slot) (Option.some ((edit).previous)), pickerSerial := ((s).pickerSerial + 1), pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := setItems ((s).selectedItems) ((edit).slot) ((edit).previousItems), collectionEdit := Option.none } : State)).pickerSlot, focusRequest := (({ control := (s).control, draft := setSlot ((s).draft) ((edit).slot) (Option.some ((edit).previous)), pickerSerial := ((s).pickerSerial + 1), pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := setItems ((s).selectedItems) ((edit).slot) ((edit).previousItems), collectionEdit := Option.none } : State)).focusRequest, selectedItems := (({ control := (s).control, draft := setSlot ((s).draft) ((edit).slot) (Option.some ((edit).previous)), pickerSerial := ((s).pickerSerial + 1), pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := setItems ((s).selectedItems) ((edit).slot) ((edit).previousItems), collectionEdit := Option.none } : State)).selectedItems, collectionEdit := (({ control := (s).control, draft := setSlot ((s).draft) ((edit).slot) (Option.some ((edit).previous)), pickerSerial := ((s).pickerSerial + 1), pickerSlot := (s).pickerSlot, focusRequest := (s).focusRequest, selectedItems := setItems ((s).selectedItems) ((edit).slot) ((edit).previousItems), collectionEdit := Option.none } : State)).collectionEdit } : State), effects := ([] : List (Effect)) } : Update) else ({ state := s, effects := ([] : List (Effect)) } : Update)))

@[expose] public def dispatchCore (s : State) (intent : Intent) : Update := intentFocus (s) (intent) ((match intent with | Intent.choose operation => choose (s) ((s).draft) (operation) | Intent.pick slot => pick (s) (slot) | Intent.selected slot run pickerSerial resource items => (if (acceptPicker (s) (slot) (run) (pickerSerial) (resource) && (Uorc.Uorc.Product.Selection.valid (items) && true)) then selectedUpdate (s) (slot) (resource) (items) else ({ state := s, effects := (Effect.control (Uorc.Uorc.Product.Control.Effect.release (resource)) :: ([] : List (Effect))) } : Update)) | Intent.remove slot => ({ state := ({ control := ((select (s) (slot) (Option.none)).state).control, draft := ((select (s) (slot) (Option.none)).state).draft, pickerSerial := ((select (s) (slot) (Option.none)).state).pickerSerial, pickerSlot := ((select (s) (slot) (Option.none)).state).pickerSlot, focusRequest := ((select (s) (slot) (Option.none)).state).focusRequest, selectedItems := setItems ((s).selectedItems) (slot) (([] : List (Uorc.Uorc.Product.Selection.Item))), collectionEdit := ((select (s) (slot) (Option.none)).state).collectionEdit } : State), effects := (select (s) (slot) (Option.none)).effects } : Update) | Intent.limits limits => setLimits (s) ((s).draft) (limits) | Intent.start => (match request ((s).draft) with | Except.error err => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.reject ((s).control) (Uorc.Uorc.Product.Api.Failure.control (err))) | Except.ok bindingRequest => fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.start ((s).control) (bindingRequest))) | Intent.control event => controlIntent (s) (event) | Intent.continueSearch credit => continueSearch (s) (credit) | Intent.removeItem slot selectedItemId => beginCollectionEdit (s) (slot) (Uorc.Uorc.Product.Selection.remove (itemsFor ((s).selectedItems) (slot)) (selectedItemId)) | Intent.moveItem slot selectedItemId position => beginCollectionEdit (s) (slot) (Uorc.Uorc.Product.Selection.moveTo (itemsFor ((s).selectedItems) (slot)) (selectedItemId) (position)) | Intent.collectionEdited run pickerSerial resource items => collectionEdited (s) (run) (pickerSerial) (resource) (items) | Intent.collectionEditFailed run pickerSerial detail => collectionEditFailed (s) (run) (pickerSerial) (detail)))

@[expose] public def abortsCollectionEdit (intent : Intent) : Bool := (match intent with | Intent.choose _ => true | Intent.pick _ => true | Intent.selected _ _ _ _ _ => false | Intent.remove _ => true | Intent.limits _ => true | Intent.start => false | Intent.control i0 => (match i0 with | Action.cancel => true | Action.navigate _ => false | Action.back => false | Action.detach => false | Action.close => false | Action.shutdown => false | Action.download => false | Action.extend _ => false | Action.retryPublication => false) | Intent.continueSearch _ => false | Intent.removeItem _ _ => false | Intent.moveItem _ _ _ => false | Intent.collectionEdited _ _ _ _ => false | Intent.collectionEditFailed _ _ _ => false)

@[expose] public def appendWorkspaceEffects : (left : List (Effect)) -> (right : List (Effect)) -> List (Effect)
  | List.nil, right => right
  | List.cons head tail, right => (head :: appendWorkspaceEffects (tail) (right))

@[expose] public def dispatch (s : State) (intent : Intent) : Update := (if abortsCollectionEdit (intent) then ({ state := (dispatchCore ((abortCollectionEdit (s)).state) (intent)).state, effects := appendWorkspaceEffects ((abortCollectionEdit (s)).effects) ((dispatchCore ((abortCollectionEdit (s)).state) (intent)).effects) } : Update) else dispatchCore (s) (intent))

public inductive UserIntent where
  | choose (_ : Uorc.Uorc.Product.Evidence.Operation)
  | pick (_ : Slot)
  | remove (_ : Slot)
  | limits (_ : Uorc.Uorc.Product.Api.Limits)
  | start
  | control (_ : Action)
  | continueSearch (_ : Nat)
  | removeItem (_ : Slot) (_ : Nat)
  | moveItem (_ : Slot) (_ : Nat) (_ : Nat)

public structure BoundUserIntent where
  run : Uorc.Uorc.Product.Api.Run
  selectionSerial : Nat
  intent : UserIntent

public inductive InvocationDisposition where
  | applied
  | stale

public structure Invocation where
  update : Update
  disposition : InvocationDisposition
  message : String

@[expose] public def bindUser (s : State) (intent : UserIntent) : BoundUserIntent := ({ run := Uorc.Uorc.Product.Control.run ((s).control), selectionSerial := (s).pickerSerial, intent := intent } : BoundUserIntent)

@[expose] public def internalUserIntent (intent : UserIntent) : Intent := (match intent with | UserIntent.choose u0 => Intent.choose (u0) | UserIntent.pick u0 => Intent.pick (u0) | UserIntent.remove u0 => Intent.remove (u0) | UserIntent.limits u0 => Intent.limits (u0) | UserIntent.start => Intent.start | UserIntent.control u0 => Intent.control (u0) | UserIntent.continueSearch u0 => Intent.continueSearch (u0) | UserIntent.removeItem u0 u1 => Intent.removeItem (u0) (u1) | UserIntent.moveItem u0 u1 u2 => Intent.moveItem (u0) (u1) (u2))

@[expose] public def invokeUser (s : State) (bound : BoundUserIntent) : Invocation := (if (Uorc.Uorc.Product.Control.sameRun ((s).control) ((bound).run) && ((Nat.beq ((s).pickerSerial) ((bound).selectionSerial)) && true)) then ({ update := dispatch (s) (internalUserIntent ((bound).intent)), disposition := InvocationDisposition.applied, message := "" } : Invocation) else ({ update := ({ state := s, effects := ([] : List (Effect)) } : Update), disposition := InvocationDisposition.stale, message := "The selection or operation changed; this action was not applied." } : Invocation))

public inductive LimitKey where
  | decodeWork
  | checkerWork
  | replayWork
  | searchWork
  | outputBytes
  | ownedBytes
  | storageTotal
  | stagedOutput
  | inputSpool
  | spill
  | publicationCopy

public structure BoundLimit where
  run : Uorc.Uorc.Product.Api.Run
  selectionSerial : Nat
  key : LimitKey

public structure NumberEdit where
  update : Update
  accepted : Bool
  message : String

@[expose] public def bindLimit (s : State) (key : LimitKey) : BoundLimit := ({ run := Uorc.Uorc.Product.Control.run ((s).control), selectionSerial := (s).pickerSerial, key := key } : BoundLimit)

@[expose] public def optionalLimit (key : LimitKey) : Bool := (match key with | LimitKey.decodeWork => false | LimitKey.checkerWork => false | LimitKey.replayWork => false | LimitKey.searchWork => false | LimitKey.outputBytes => true | LimitKey.ownedBytes => false | LimitKey.storageTotal => true | LimitKey.stagedOutput => true | LimitKey.inputSpool => true | LimitKey.spill => true | LimitKey.publicationCopy => true)

@[expose] public def setLimitValue (limits : Uorc.Uorc.Product.Api.Limits) (key : LimitKey) (value : Option (Nat)) : Uorc.Uorc.Product.Api.Limits := (match key with | LimitKey.decodeWork => ({ decodeWork := (match value with | Option.none => 0 | Option.some number => number), checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := (limits).storage } : Uorc.Uorc.Product.Api.Limits) | LimitKey.checkerWork => ({ decodeWork := (limits).decodeWork, checkerWork := (match value with | Option.none => 0 | Option.some number => number), replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := (limits).storage } : Uorc.Uorc.Product.Api.Limits) | LimitKey.replayWork => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (match value with | Option.none => 0 | Option.some number => number), searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := (limits).storage } : Uorc.Uorc.Product.Api.Limits) | LimitKey.searchWork => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (match value with | Option.none => 0 | Option.some number => number), outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := (limits).storage } : Uorc.Uorc.Product.Api.Limits) | LimitKey.outputBytes => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := value, ownedBytes := (limits).ownedBytes, storage := (limits).storage } : Uorc.Uorc.Product.Api.Limits) | LimitKey.ownedBytes => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (match value with | Option.none => 0 | Option.some number => number), storage := (limits).storage } : Uorc.Uorc.Product.Api.Limits) | LimitKey.storageTotal => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := ({ total := value, stagedOutput := ((limits).storage).stagedOutput, inputSpool := ((limits).storage).inputSpool, spill := ((limits).storage).spill, publicationCopy := ((limits).storage).publicationCopy } : Uorc.Uorc.Product.Storage.Limits) } : Uorc.Uorc.Product.Api.Limits) | LimitKey.stagedOutput => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := ({ total := ((limits).storage).total, stagedOutput := value, inputSpool := ((limits).storage).inputSpool, spill := ((limits).storage).spill, publicationCopy := ((limits).storage).publicationCopy } : Uorc.Uorc.Product.Storage.Limits) } : Uorc.Uorc.Product.Api.Limits) | LimitKey.inputSpool => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := ({ total := ((limits).storage).total, stagedOutput := ((limits).storage).stagedOutput, inputSpool := value, spill := ((limits).storage).spill, publicationCopy := ((limits).storage).publicationCopy } : Uorc.Uorc.Product.Storage.Limits) } : Uorc.Uorc.Product.Api.Limits) | LimitKey.spill => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := ({ total := ((limits).storage).total, stagedOutput := ((limits).storage).stagedOutput, inputSpool := ((limits).storage).inputSpool, spill := value, publicationCopy := ((limits).storage).publicationCopy } : Uorc.Uorc.Product.Storage.Limits) } : Uorc.Uorc.Product.Api.Limits) | LimitKey.publicationCopy => ({ decodeWork := (limits).decodeWork, checkerWork := (limits).checkerWork, replayWork := (limits).replayWork, searchWork := (limits).searchWork, outputBytes := (limits).outputBytes, ownedBytes := (limits).ownedBytes, storage := ({ total := ((limits).storage).total, stagedOutput := ((limits).storage).stagedOutput, inputSpool := ((limits).storage).inputSpool, spill := ((limits).storage).spill, publicationCopy := value } : Uorc.Uorc.Product.Storage.Limits) } : Uorc.Uorc.Product.Api.Limits))

@[expose] public def byteDigit (digit : UInt8) : Option (Nat) := (if (LexLeanRuntime.equal (digit) ((48 : UInt8)) : Bool) then Option.some (0) else (if (LexLeanRuntime.equal (digit) ((49 : UInt8)) : Bool) then Option.some (1) else (if (LexLeanRuntime.equal (digit) ((50 : UInt8)) : Bool) then Option.some (2) else (if (LexLeanRuntime.equal (digit) ((51 : UInt8)) : Bool) then Option.some (3) else (if (LexLeanRuntime.equal (digit) ((52 : UInt8)) : Bool) then Option.some (4) else (if (LexLeanRuntime.equal (digit) ((53 : UInt8)) : Bool) then Option.some (5) else (if (LexLeanRuntime.equal (digit) ((54 : UInt8)) : Bool) then Option.some (6) else (if (LexLeanRuntime.equal (digit) ((55 : UInt8)) : Bool) then Option.some (7) else (if (LexLeanRuntime.equal (digit) ((56 : UInt8)) : Bool) then Option.some (8) else (if (LexLeanRuntime.equal (digit) ((57 : UInt8)) : Bool) then Option.some (9) else Option.none))))))))))

@[expose] public def parseNaturalDigits : (bytes : ByteArray) -> (remaining : Nat) -> (index : Nat) -> (value : Nat) -> Option (Nat)
  | _bytes, Nat.zero, _index, value => Option.some (value)
  | bytes, Nat.succ rest, index, value => (match (LexLeanRuntime.index (bytes) (index) : Option (UInt8)) with | Option.none => Option.none | Option.some digit => (match byteDigit (digit) with | Option.none => Option.none | Option.some number => parseNaturalDigits (bytes) (rest) ((index + 1)) (((LexLeanRuntime.multiply (value) (10) : Nat) + number))))

@[expose] public def parseNatural (text : String) : Option (Nat) := parseNaturalDigits ((LexLeanRuntime.utf8Encode (text) : ByteArray)) ((LexLeanRuntime.length ((LexLeanRuntime.utf8Encode (text) : ByteArray)) : Nat)) (0) (0)

@[expose] public def editLimitText (s : State) (binding : BoundLimit) (text : String) : NumberEdit := (if (!(Uorc.Uorc.Product.Control.sameRun ((s).control) ((binding).run) && ((Nat.beq ((s).pickerSerial) ((binding).selectionSerial)) && true))) then ({ update := ({ state := s, effects := ([] : List (Effect)) } : Update), accepted := false, message := "The selection or operation changed; this setting was not applied." } : NumberEdit) else (if (!(((s).control).attached && ((!((s).control).closed) && ((!(((s).control).session).active) && ((!((s).control).publicationPending) && true))))) then ({ update := ({ state := s, effects := ([] : List (Effect)) } : Update), accepted := false, message := "Stop the current operation before changing its requested limits." } : NumberEdit) else (if (LexLeanRuntime.equal (text) ("") : Bool) then (if optionalLimit ((binding).key) then ({ update := dispatch (s) (Intent.limits (setLimitValue (((s).draft).limits) ((binding).key) (Option.none))), accepted := true, message := "" } : NumberEdit) else ({ update := requestFocus (s) (fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.reject ((s).control) (Uorc.Uorc.Product.Api.Failure.control (Uorc.Uorc.Product.Api.ControlError.invalidLimit)))) (FocusTarget.error), accepted := false, message := "Enter a nonnegative whole number. Clear only an optional quota to request no additional limit." } : NumberEdit)) else (match parseNatural (text) with | Option.none => ({ update := requestFocus (s) (fromControl (s) ((s).draft) (Uorc.Uorc.Product.Control.reject ((s).control) (Uorc.Uorc.Product.Api.Failure.control (Uorc.Uorc.Product.Api.ControlError.invalidLimit)))) (FocusTarget.error), accepted := false, message := "Enter a nonnegative whole number. Clear only an optional quota to request no additional limit." } : NumberEdit) | Option.some number => ({ update := dispatch (s) (Intent.limits (setLimitValue (((s).draft).limits) ((binding).key) (Option.some (number)))), accepted := true, message := "" } : NumberEdit)))))

@[expose] public def releaseDisposition (s : State) : Uorc.Uorc.Product.Api.ReleaseDisposition := (if (match (s).collectionEdit with | Option.none => false | Option.some _ => true) then Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.resourceLease) else (if ((!(match ((s).draft).input with | Option.none => false | Option.some _ => true)) && ((!(match ((s).draft).archive with | Option.none => false | Option.some _ => true)) && ((!(match ((s).draft).basis with | Option.none => false | Option.some _ => true)) && ((!(match ((s).draft).originals with | Option.none => false | Option.some _ => true)) && ((!(match ((s).draft).checkpoint with | Option.none => false | Option.some _ => true)) && ((!(match ((s).draft).comparison with | Option.none => false | Option.some _ => true)) && true)))))) then Uorc.Uorc.Product.Control.releaseDisposition ((s).control) else Uorc.Uorc.Product.Api.ReleaseDisposition.retain (Uorc.Uorc.Product.Api.CustodyReason.resourceLease)))

end Uorc.Uorc.Product.Workspace
