module
import Uorc.Uorc.Product.InputModel
#print axioms Uorc.Uorc.Product.InputModel.Error
#print axioms Uorc.Uorc.Product.InputModel.Piece
#print axioms Uorc.Uorc.Product.InputModel.State
#print axioms Uorc.Uorc.Product.InputModel.accept
#print axioms Uorc.Uorc.Product.InputModel.boundary
#print axioms Uorc.Uorc.Product.InputModel.initial
