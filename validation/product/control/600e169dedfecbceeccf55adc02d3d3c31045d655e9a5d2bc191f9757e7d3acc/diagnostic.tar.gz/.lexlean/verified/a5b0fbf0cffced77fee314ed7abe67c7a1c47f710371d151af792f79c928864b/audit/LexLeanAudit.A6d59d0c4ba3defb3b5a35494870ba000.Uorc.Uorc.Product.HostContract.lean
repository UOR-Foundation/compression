module
import Uorc.Uorc.Product.HostContract
#print axioms Uorc.Uorc.Product.HostContract.Contract
#print axioms Uorc.Uorc.Product.HostContract.Endpoint
#print axioms Uorc.Uorc.Product.HostContract.EndpointGroup
#print axioms Uorc.Uorc.Product.HostContract.Rule
#print axioms Uorc.Uorc.Product.HostContract.contract
