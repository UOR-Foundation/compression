import Uorc.Uorc.Product.ReadImageScenarios
open Uorc.Uorc.Product

def main : IO Unit := do
  let mut passed : Nat := 0
  let mut total : Nat := 0
  for observation in ReadImageScenarios.observations do
    total := total + 1
    if observation.passed then passed := passed + 1 else IO.println s!"FAIL {observation.id}"
  IO.println s!"{passed}/{total} actual payload-image lifecycle controls passed"
  if total == 0 || passed != total then throw (IO.userError "binding controls failed")
