Diagnostic inputs and generated source, not a production SDK or accepted executable.
Use the recorded LexLean 0.4.0 / language 1.2 semantics and Lean 4.32.1.
In diagnostic-project, run lexlean check then build on src/Uorc/Product/ReadImageScenarios.lex.tex.
Compile the generated Lean import closure and sdk-runtime import closure with Lean, then run RunReadImage.lean with that compiled closure in LEAN_PATH.
The repository scripts/product-image-runtime.mjs requires genuine lexlean verify and does not accept this receipt in its place.
Full verify of this exact historical Core closure fails as recorded; native, Wasm, persistent adapter, closed archive operations and pinned SDK acceptance are unqualified.
