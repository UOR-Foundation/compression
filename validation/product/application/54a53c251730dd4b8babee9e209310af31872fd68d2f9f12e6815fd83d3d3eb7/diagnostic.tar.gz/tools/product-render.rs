use std::{env,fs};
fn main() {
    let input=env::args().nth(1).expect("exact lowered diagnostic program");
    let output=env::args().nth(2).expect("diagnostic Rust source");
    let program:lexlean::calculus::Program=serde_json::from_slice(&fs::read(input).unwrap()).unwrap();
    let rendered=lexlean::calculus::rust::render(&program,lexlean::calculus::rust::Profile::Std).expect("official SDK diagnostic renderer");
    fs::write(output,rendered).unwrap();
}
