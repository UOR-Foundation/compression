use std::{env,fs};
use lexlean::{project::{Project,Selection},production::lower::{roots,linked_modules,lower_root}};
fn main(){
 let path=env::args().nth(1).expect("project");let root_name=env::args().nth(2);
 let project=Project::load(path.as_str().into()).expect("project reads");
 let (lock,packages)=lexlean::lock::read_current_lock(&project).expect("exact diagnostic lock");
 let checked=lexlean::link::check_project(&project,&Selection::Entrypoints,&lock,packages).expect("official SDK check");
 let linked=linked_modules(&checked);
 let types:Vec<_>=linked.iter().map(|(name,module)|{
   let declarations:Vec<_>=module.semantic.declarations.iter().map(|d|serde_json::to_value(d).unwrap()).filter(|d|d["kind"]=="structure"||d["kind"]=="inductive").collect();
   serde_json::json!({"module":name,"declarations":declarations})
 }).collect();
 fs::write("source-types.json",serde_json::to_vec_pretty(&types).unwrap()).unwrap();

 for root in roots(&checked).expect("production roots"){
  if root_name.as_ref().map(|n|n!=&root.report.root).unwrap_or(false){continue}
  let lowered=lower_root(&linked,&root.module,&root.name,root.report,&project.config.limits).expect("official SDK lowering");
  let filename=root.report.root.replace('.',"_");
  fs::write(format!("{filename}.program.json"),serde_json::to_vec_pretty(&lowered.program).unwrap()).unwrap();
  let mut layout=String::new();
  for (i,origin) in lowered.layout.functions.iter().enumerate(){layout.push_str(&format!("f{i}: {origin:?}\n"));}
  for (i,origin) in lowered.layout.adts.iter().enumerate(){layout.push_str(&format!("a{i}: {origin:?}\n"));}
  fs::write(format!("{filename}.layout.txt"),layout).unwrap();
  let adts:Vec<_>=lowered.layout.adts.iter().enumerate().map(|(i,a)|serde_json::json!({"index":i,"origin":a.text,"semantic_type":a.ty,"constructors":lowered.program.adts[i].constructors})).collect();
  let metadata=serde_json::json!({"schema":"uorc/typed-production-closure/1","root":root.report.root,"entry":lowered.entry(),"adts":adts,"function_count":lowered.program.functions.len()});
  fs::write(format!("{filename}.closure.json"),serde_json::to_vec_pretty(&metadata).unwrap()).unwrap();

 }
}
