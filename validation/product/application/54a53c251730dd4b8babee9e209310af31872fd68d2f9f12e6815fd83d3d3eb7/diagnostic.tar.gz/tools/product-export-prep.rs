use std::{env,fs,path::Path};
fn main(){
 let request=env::args().nth(1).expect("request");
 let request:serde_json::Value=serde_json::from_slice(&fs::read(request).unwrap()).unwrap();
 for path in env::args().skip(2){
  let text=fs::read_to_string(&path).unwrap();
  let module_name=text.lines().next().unwrap().strip_prefix("\\begin{lexlean}{").unwrap().strip_suffix('}').unwrap();
  let mut module=lexlean::sdk::read_module(&text).unwrap();
  module["spec"]="lexlean/semantic-module/2".into();
  for decl in module["declarations"].as_array_mut().unwrap(){
   if decl["kind"]!="definition"{continue}
   decl["executable"]=true.into();
   decl.as_object_mut().unwrap().remove("production");
   let full=format!("Uorc.{module_name}.{}",decl["name"].as_str().unwrap());
   if request["roots"].as_array().unwrap().iter().any(|root|root["root"]==full){
    decl["production"]=serde_json::json!({"effects":["allocation","overflow","recursion"],"targets":["rust-std"]});
   }
  }
  let data=lexlean::sdk::write_module(&text,&module).unwrap();let notation=lexlean::sdk::to_notation(&data).unwrap();
  assert_eq!(lexlean::sdk::read_module(&notation).unwrap(),module);
  fs::write(Path::new(&path),notation.replace("lexlean.std.bool@1.1.0","lexlean.std.bool@1.2.0")).unwrap();
 }
}
