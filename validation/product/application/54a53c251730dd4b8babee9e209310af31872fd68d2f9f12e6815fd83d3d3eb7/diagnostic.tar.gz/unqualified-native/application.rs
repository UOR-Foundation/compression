#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(u64),
    C1(Adt1, Adt62),
    C2(Adt1, Adt65),
    C3(Adt1, Adt66),
    C4(Adt1, Adt69, Str),
    C5(Adt1),
    C6(Adt1, Adt53, Adt12),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(Adt2, Adt54, u64, Option<Adt56>, Adt57, List<Adt59>, Option<Adt61>),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u64, Adt3, Adt6, Adt9, Option<Adt10>, Option<Adt23>, Adt41, Option<Adt12>, bool, bool, Option<Adt42>, Option<Adt48>, Option<Adt12>, bool, bool, Adt49, Adt50, bool, Adt51, Option<Adt24>, List<Adt52>),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u64, u64, bool, bool, Adt4, Adt5),
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt5 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt7, bool, u64, bool, Adt8),
}

#[derive(Clone)]
pub enum Adt7 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt8 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt9 {
    C0(u64, bool, bool, u64),
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt11),
    C1(Adt16),
    C2(Adt16),
    C3(Adt17),
    C4(Adt18),
    C5(Adt19),
    C6(Adt20),
    C7(Adt21),
    C8(Adt22),
    C9(Adt22),
}

#[derive(Clone)]
pub enum Adt11 {
    C0(Adt12, Adt13),
}

#[derive(Clone)]
pub enum Adt12 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt13 {
    C0(Adt14, Option<Adt12>),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(u64, u64, u64, u64, Option<u64>, u64, Adt15),
}

#[derive(Clone)]
pub enum Adt15 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt12, Adt13),
}

#[derive(Clone)]
pub enum Adt17 {
    C0(Adt12, Option<Adt12>, Option<Adt12>, Adt13),
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt12, Adt12, Adt13),
}

#[derive(Clone)]
pub enum Adt19 {
    C0(Adt12, Adt13),
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt12, Option<Adt12>, Adt13),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt12, Adt12, Option<Adt12>, Adt13),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt12, Adt13),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(Adt24, Adt29, bool, bool, Adt30, Adt31, Adt33, bool, Option<Adt12>, Option<Adt34>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, Adt25, Option<Adt27>),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(Adt26, Adt26, u64, u64),
}

#[derive(Clone)]
pub enum Adt26 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt27 {
    C0(Option<u64>, Option<u64>, Adt28, u64),
}

#[derive(Clone)]
pub enum Adt28 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt29 {
    C0(bool, bool, bool, bool, bool),
}

#[derive(Clone)]
pub enum Adt30 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt31 {
    C0,
    C1(Adt32),
    C2(Adt32),
    C3(Adt32),
    C4(Adt32),
}

#[derive(Clone)]
pub enum Adt32 {
    C0(Bytes, Adt12, Option<Adt12>, Adt14),
}

#[derive(Clone)]
pub enum Adt33 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt34 {
    C0(Adt35),
    C1(Adt35),
    C2(Adt35),
    C3(u64),
    C4(Adt36),
    C5(Adt37),
    C6(Adt38),
    C7(Adt40),
}

#[derive(Clone)]
pub enum Adt35 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt36 {
    C0(Bytes, u64, u64),
}

#[derive(Clone)]
pub enum Adt37 {
    C0(Adt12, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt38 {
    C0(Adt39, Adt39, bool),
}

#[derive(Clone)]
pub enum Adt39 {
    C0(Adt24, Adt29, bool, Adt31),
}

#[derive(Clone)]
pub enum Adt40 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt41 {
    C0(u64, u64, u64, u64, u64, Str),
}

#[derive(Clone)]
pub enum Adt42 {
    C0(u64, Str),
    C1(u64, Str),
    C2(Bytes),
    C3(Bytes),
    C4,
    C5,
    C6(Adt43, u64),
    C7,
    C8(Str),
    C9(Adt8, Str),
    C10(Adt44),
    C11(Adt45),
    C12,
    C13,
    C14(Str),
    C15(Str),
    C16(Adt46),
}

#[derive(Clone)]
pub enum Adt43 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt44 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
    C12,
    C13,
    C14,
    C15,
    C16,
    C17,
}

#[derive(Clone)]
pub enum Adt45 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt46 {
    C0(u64, u64, u64),
    C1(Adt47, u64, u64, u64),
    C2(Adt47, u64, u64),
    C3(Adt47, u64, u64),
}

#[derive(Clone)]
pub enum Adt47 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt48 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt49 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt50 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt51 {
    C0(Adt25, Option<Adt46>),
}

#[derive(Clone)]
pub enum Adt52 {
    C0(Adt53, Adt15, Adt51, Option<Adt24>),
}

#[derive(Clone)]
pub enum Adt53 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt54 {
    C0(Adt55, Option<Adt12>, Option<Adt12>, Option<Adt12>, Option<Adt12>, Option<Adt12>, Option<Adt12>, Adt14),
}

#[derive(Clone)]
pub enum Adt55 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
}

#[derive(Clone)]
pub enum Adt56 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt57 {
    C0(u64, Adt58),
}

#[derive(Clone)]
pub enum Adt58 {
    C0(Adt56),
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt59 {
    C0(Adt56, List<Adt60>),
}

#[derive(Clone)]
pub enum Adt60 {
    C0(u64, Str, Option<u64>),
}

#[derive(Clone)]
pub enum Adt61 {
    C0(Adt56, Adt53, u64, Adt12, List<Adt60>, List<Adt60>),
}

#[derive(Clone)]
pub enum Adt62 {
    C0(Adt53, u64, Adt63),
}

#[derive(Clone)]
pub enum Adt63 {
    C0(Adt55),
    C1(Adt56),
    C2(Adt56),
    C3(Adt14),
    C4,
    C5(Adt64),
    C6(u64),
    C7(Adt56, u64),
    C8(Adt56, u64, u64),
}

#[derive(Clone)]
pub enum Adt64 {
    C0,
    C1(Adt49),
    C2,
    C3,
    C4,
    C5,
    C6,
    C7(u64),
    C8,
}

#[derive(Clone)]
pub enum Adt65 {
    C0(Adt56, Adt53, u64, Adt12, List<Adt60>),
    C1(Adt53, u64, Adt12, List<Adt60>),
    C2(Adt53, u64, Str),
}

#[derive(Clone)]
pub enum Adt66 {
    C0(u64),
    C1(Adt53),
    C2(Adt53, Adt41),
    C3(Adt53, Adt12),
    C4(Adt53, Adt23),
    C5(Adt53, Adt67),
    C6(Adt53, Adt48),
    C7(Adt53, Adt8),
    C8(Adt53, u64),
    C9(Adt53, Adt68),
    C10(Adt53, Adt68),
    C11(Adt53),
}

#[derive(Clone)]
pub enum Adt67 {
    C0(Adt42, Adt24, Adt8),
}

#[derive(Clone)]
pub enum Adt68 {
    C0(Adt47, u64),
    C1(Adt47, u64, u64),
    C2(Adt47, u64, u64),
    C3(Adt47, u64),
    C4(Adt47, u64),
}

#[derive(Clone)]
pub enum Adt69 {
    C0(Adt53, u64, Adt70),
}

#[derive(Clone)]
pub enum Adt70 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
}

#[derive(Clone)]
pub enum Adt71 {
    C0(Adt1, Adt72, List<Adt80>, Adt84, Str, Str, Adt85, Option<bool>),
}

#[derive(Clone)]
pub enum Adt72 {
    C0(Str, Str, Str, Str, Str, Option<Adt32>, List<Adt73>, List<Adt73>, List<Adt74>, List<Adt76>, Adt57, Adt77, bool, bool, bool, bool, Option<Adt78>, Option<Adt31>, Option<Adt33>, Option<Adt34>, Adt49, List<Adt73>, List<Adt73>, Option<Adt25>, Option<Adt27>, Str, List<Adt79>, Str),
}

#[derive(Clone)]
pub enum Adt73 {
    C0(Str, Str, Adt62, bool, bool),
}

#[derive(Clone)]
pub enum Adt74 {
    C0(Adt56, Str, Adt62, bool, bool, bool, bool, Str, List<Adt75>, bool, bool),
}

#[derive(Clone)]
pub enum Adt75 {
    C0(u64, u64, Str, Option<u64>, bool, Adt62, Adt62, Adt62, bool, bool, bool, u64, Str, Str, Str),
}

#[derive(Clone)]
pub enum Adt76 {
    C0(Str, u64, Str),
}

#[derive(Clone)]
pub enum Adt77 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt78 {
    C0(bool, bool, bool, bool, bool, bool, bool),
}

#[derive(Clone)]
pub enum Adt79 {
    C0(Str, Str, Str, Str, bool, bool, Adt69, Str),
}

#[derive(Clone)]
pub enum Adt80 {
    C0(Adt81),
    C1(Adt56, Adt53, u64),
    C2(Adt61),
    C3(Adt61),
}

#[derive(Clone)]
pub enum Adt81 {
    C0(Adt53, Adt10),
    C1(Adt53, Adt82),
    C2(Adt53, u64),
    C3(Adt53, u64),
    C4(Adt53),
    C5(Adt53),
    C6(Adt12),
    C7(Adt53, Adt12),
    C8(u64),
    C9(Adt53),
}

#[derive(Clone)]
pub enum Adt82 {
    C0(u64),
    C1(Adt83),
    C2(u64),
    C3,
}

#[derive(Clone)]
pub enum Adt83 {
    C0(Adt12, u64, u64),
}

#[derive(Clone)]
pub enum Adt84 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt85 {
    C0(Adt86),
    C1,
}

#[derive(Clone)]
pub enum Adt86 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
}

#[derive(Clone)]
pub enum Adt87 {
    C0(Adt1, List<Adt80>, Adt84, Str, Option<bool>),
}

#[derive(Clone)]
pub enum Adt88 {
    C0(Adt89, Adt90, Str),
}

#[derive(Clone)]
pub enum Adt89 {
    C0(Adt1, List<Adt80>),
}

#[derive(Clone)]
pub enum Adt90 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt91 {
    C0(Adt55),
    C1(Adt56),
    C2(Adt56, Adt53, u64, Adt12, List<Adt60>),
    C3(Adt56),
    C4(Adt14),
    C5,
    C6(Adt64),
    C7(u64),
    C8(Adt56, u64),
    C9(Adt56, u64, u64),
    C10(Adt53, u64, Adt12, List<Adt60>),
    C11(Adt53, u64, Str),
}

#[derive(Clone)]
pub enum Adt92 {
    C0(Adt10),
    C1,
    C2,
    C3(Adt49),
    C4,
    C5,
    C6,
    C7,
    C8(u64),
    C9(Adt53),
    C10(Adt53, Adt82),
    C11(u64),
    C12(Adt53, Adt41),
    C13(Adt53, Adt12),
    C14(u64),
    C15(Adt53, Adt23),
    C16(Adt53, Adt67),
    C17(Adt53, Adt48),
    C18,
    C19(Adt53, Adt8),
    C20,
    C21(Adt53, u64),
    C22(Adt53, Adt68),
    C23(Adt53, Adt68),
    C24(Adt53),
}

#[derive(Clone)]
pub enum Adt93 {
    C0(Adt89, bool, Str),
}

#[derive(Clone)]
pub enum Adt94 {
    C0(Adt2, List<Adt81>),
}

#[derive(Clone)]
pub enum Adt95 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt96 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt97 {
    C0(Adt98, Adt6),
    C1(Adt45),
}

#[derive(Clone)]
pub enum Adt98 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt99 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt100 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

pub fn f0(v0: Adt0) -> R<Adt71> {
    f1(f2(v0)?)
}

pub fn f1(v0: Adt87) -> R<Adt71> {
    f3(match v0.clone() {
        Adt87::C0(h1, _, _, _, _) => {
            h1
        }
    }, match v0.clone() {
        Adt87::C0(_, h2, _, _, _) => {
            h2
        }
    }, match v0.clone() {
        Adt87::C0(_, _, h3, _, _) => {
            h3
        }
    }, match v0.clone() {
        Adt87::C0(_, _, _, h4, _) => {
            h4
        }
    }, match v0 {
        Adt87::C0(_, _, _, _, h5) => {
            h5
        }
    })
}

pub fn f2(v0: Adt0) -> R<Adt87> {
    let m6 = v0;
    match m6 {
        Adt0::C0(v1) => {
            Ok(f4(f5(v1), List::<Adt80>::nil(), Adt84::C3, Str::lit(""), None::<bool>))
        }
        Adt0::C1(v2, v3) => {
            Ok(f6(f7(v2, v3)?))
        }
        Adt0::C2(v4, v5) => {
            Ok(f8(f9(v4, f10(v5))?))
        }
        Adt0::C3(v6, v7) => {
            Ok(f8(f11(v6, v7)?))
        }
        Adt0::C4(v8, v9, v10) => {
            Ok(f12(f13(v8, v9, v10)?))
        }
        Adt0::C5(v11) => {
            Ok(f4(v11, List::<Adt80>::nil(), Adt84::C3, Str::lit(""), None::<bool>))
        }
        Adt0::C6(v12, v13, v14) => {
            Ok(f4(v12.clone(), List::<Adt80>::nil(), Adt84::C6, Str::lit(""), Some(f14(match v12 {
                Adt1::C0(h7, _, _, _, _, _, _) => {
                    h7
                }
            }, v13, v14)?)))
        }
    }
}

pub fn f3(v0: Adt1, v1: List<Adt80>, v2: Adt84, v3: Str, v4: Option<bool>) -> R<Adt71> {
    Ok(Adt71::C0(v0.clone(), f15(v0.clone())?, v1, v2, v3, f16({
        let m10 = match v0.clone() {
            Adt1::C0(_, _, _, _, h9, _, _) => {
                h9
            }
        };
        match m10 {
            Adt57::C0(_, h8) => {
                h8
            }
        }
    }), f17(v0)?, v4))
}

pub fn f4(v0: Adt1, v1: List<Adt80>, v2: Adt84, v3: Str, v4: Option<bool>) -> Adt87 {
    Adt87::C0(v0, v1, v2, v3, v4)
}

pub fn f5(v0: u64) -> Adt1 {
    Adt1::C0(f18(v0), Adt54::C0(Adt55::C0, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, f19()), 0u64, None::<Adt56>, Adt57::C0(0u64, Adt58::C0(Adt56::C0)), List::<Adt59>::nil(), None::<Adt61>)
}

pub fn f6(v0: Adt88) -> Adt87 {
    f4({
        let m13 = match v0.clone() {
            Adt88::C0(h12, _, _) => {
                h12
            }
        };
        match m13 {
            Adt89::C0(h11, _) => {
                h11
            }
        }
    }, {
        let m16 = match v0.clone() {
            Adt88::C0(h15, _, _) => {
                h15
            }
        };
        match m16 {
            Adt89::C0(_, h14) => {
                h14
            }
        }
    }, {
        let m18 = match v0.clone() {
            Adt88::C0(_, h17, _) => {
                h17
            }
        };
        match m18 {
            Adt90::C0 => {
                Adt84::C0
            }
            Adt90::C1 => {
                Adt84::C1
            }
        }
    }, match v0 {
        Adt88::C0(_, _, h19) => {
            h19
        }
    }, None::<bool>)
}

pub fn f7(v0: Adt1, v1: Adt62) -> R<Adt88> {
    if if f20(match v0.clone() {
        Adt1::C0(h20, _, _, _, _, _, _) => {
            h20
        }
    }, match v1.clone() {
        Adt62::C0(h21, _, _) => {
            h21
        }
    }) {
        let a24 = match v0.clone() {
            Adt1::C0(_, _, h22, _, _, _, _) => {
                h22
            }
        };
        let a25 = match v1.clone() {
            Adt62::C0(_, h23, _) => {
                h23
            }
        };
        nat_eq(a24, a25)
    } else {
        false
    } {
        Ok(Adt88::C0(f9(v0, f21(match v1 {
            Adt62::C0(_, _, h26) => {
                h26
            }
        }))?, Adt90::C0, Str::lit("")))
    } else {
        Ok(Adt88::C0(Adt89::C0(v0, List::<Adt80>::nil()), Adt90::C1, Str::lit("The selection or operation changed; this action was not applied.")))
    }
}

pub fn f8(v0: Adt89) -> Adt87 {
    f4(match v0.clone() {
        Adt89::C0(h27, _) => {
            h27
        }
    }, match v0 {
        Adt89::C0(_, h28) => {
            h28
        }
    }, Adt84::C2, Str::lit(""), None::<bool>)
}

pub fn f9(v0: Adt1, v1: Adt91) -> R<Adt89> {
    if f22(v1.clone()) {
        Ok(Adt89::C0({
            let m32 = f23({
                let m31 = f24(v0.clone())?;
                match m31 {
                    Adt89::C0(h30, _) => {
                        h30
                    }
                }
            }, v1.clone())?;
            match m32 {
                Adt89::C0(h29, _) => {
                    h29
                }
            }
        }, f25({
            let m34 = f24(v0.clone())?;
            match m34 {
                Adt89::C0(_, h33) => {
                    h33
                }
            }
        }, {
            let m38 = f23({
                let m37 = f24(v0)?;
                match m37 {
                    Adt89::C0(h36, _) => {
                        h36
                    }
                }
            }, v1)?;
            match m38 {
                Adt89::C0(_, h35) => {
                    h35
                }
            }
        })))
    } else {
        f23(v0, v1)
    }
}

pub fn f10(v0: Adt65) -> Adt91 {
    let m39 = v0;
    match m39 {
        Adt65::C0(v1, v2, v3, v4, v5) => {
            Adt91::C2(v1, v2, v3, v4, v5)
        }
        Adt65::C1(v6, v7, v8, v9) => {
            Adt91::C10(v6, v7, v8, v9)
        }
        Adt65::C2(v10, v11, v12) => {
            Adt91::C11(v10, v11, v12)
        }
    }
}

pub fn f11(v0: Adt1, v1: Adt66) -> R<Adt89> {
    f26(v0.clone(), v1.clone(), {
        let m40 = v1;
        match m40 {
            Adt66::C0(v2) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h41, _, _, _, _, _) => {
                        h41
                    }
                }, f28(match v0 {
                    Adt1::C0(h42, _, _, _, _, _, _) => {
                        h42
                    }
                }, Adt92::C8(v2))?)
            }
            Adt66::C1(v3) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h43, _, _, _, _, _) => {
                        h43
                    }
                }, f28(match v0 {
                    Adt1::C0(h44, _, _, _, _, _, _) => {
                        h44
                    }
                }, Adt92::C9(v3))?)
            }
            Adt66::C2(v4, v5) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h45, _, _, _, _, _) => {
                        h45
                    }
                }, f28(match v0 {
                    Adt1::C0(h46, _, _, _, _, _, _) => {
                        h46
                    }
                }, Adt92::C12(v4, v5))?)
            }
            Adt66::C3(v6, v7) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h47, _, _, _, _, _) => {
                        h47
                    }
                }, f28(match v0 {
                    Adt1::C0(h48, _, _, _, _, _, _) => {
                        h48
                    }
                }, Adt92::C13(v6, v7))?)
            }
            Adt66::C4(v8, v9) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h49, _, _, _, _, _) => {
                        h49
                    }
                }, f28(match v0 {
                    Adt1::C0(h50, _, _, _, _, _, _) => {
                        h50
                    }
                }, Adt92::C15(v8, v9))?)
            }
            Adt66::C5(v10, v11) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h51, _, _, _, _, _) => {
                        h51
                    }
                }, f28(match v0 {
                    Adt1::C0(h52, _, _, _, _, _, _) => {
                        h52
                    }
                }, Adt92::C16(v10, v11))?)
            }
            Adt66::C6(v12, v13) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h53, _, _, _, _, _) => {
                        h53
                    }
                }, f28(match v0 {
                    Adt1::C0(h54, _, _, _, _, _, _) => {
                        h54
                    }
                }, Adt92::C17(v12, v13))?)
            }
            Adt66::C7(v14, v15) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h55, _, _, _, _, _) => {
                        h55
                    }
                }, f28(match v0 {
                    Adt1::C0(h56, _, _, _, _, _, _) => {
                        h56
                    }
                }, Adt92::C19(v14, v15))?)
            }
            Adt66::C8(v16, v17) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h57, _, _, _, _, _) => {
                        h57
                    }
                }, f28(match v0 {
                    Adt1::C0(h58, _, _, _, _, _, _) => {
                        h58
                    }
                }, Adt92::C21(v16, v17))?)
            }
            Adt66::C9(v18, v19) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h59, _, _, _, _, _) => {
                        h59
                    }
                }, f28(match v0 {
                    Adt1::C0(h60, _, _, _, _, _, _) => {
                        h60
                    }
                }, Adt92::C22(v18, v19))?)
            }
            Adt66::C10(v20, v21) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h61, _, _, _, _, _) => {
                        h61
                    }
                }, f28(match v0 {
                    Adt1::C0(h62, _, _, _, _, _, _) => {
                        h62
                    }
                }, Adt92::C23(v20, v21))?)
            }
            Adt66::C11(v22) => {
                f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h63, _, _, _, _, _) => {
                        h63
                    }
                }, f28(match v0 {
                    Adt1::C0(h64, _, _, _, _, _, _) => {
                        h64
                    }
                }, Adt92::C24(v22))?)
            }
        }
    })
}

pub fn f12(v0: Adt93) -> Adt87 {
    f4({
        let m67 = match v0.clone() {
            Adt93::C0(h66, _, _) => {
                h66
            }
        };
        match m67 {
            Adt89::C0(h65, _) => {
                h65
            }
        }
    }, {
        let m70 = match v0.clone() {
            Adt93::C0(h69, _, _) => {
                h69
            }
        };
        match m70 {
            Adt89::C0(_, h68) => {
                h68
            }
        }
    }, if match v0.clone() {
        Adt93::C0(_, h71, _) => {
            h71
        }
    } {
        Adt84::C4
    } else {
        Adt84::C5
    }, match v0 {
        Adt93::C0(_, _, h72) => {
            h72
        }
    }, None::<bool>)
}

pub fn f13(v0: Adt1, v1: Adt69, v2: Str) -> R<Adt93> {
    let a79 = if f20(match v0.clone() {
        Adt1::C0(h73, _, _, _, _, _, _) => {
            h73
        }
    }, match v1.clone() {
        Adt69::C0(h74, _, _) => {
            h74
        }
    }) {
        let a77 = match v0.clone() {
            Adt1::C0(_, _, h75, _, _, _, _) => {
                h75
            }
        };
        let a78 = match v1.clone() {
            Adt69::C0(_, h76, _) => {
                h76
            }
        };
        nat_eq(a77, a78)
    } else {
        false
    };
    if bool_not(a79) {
        Ok(Adt93::C0(Adt89::C0(v0, List::<Adt80>::nil()), false, Str::lit("The selection or operation changed; this setting was not applied.")))
    } else {
        let a97 = {
            let m82 = match v0.clone() {
                Adt1::C0(h81, _, _, _, _, _, _) => {
                    h81
                }
            };
            if match m82 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h80, _, _, _, _, _, _, _) => {
                    h80
                }
            } {
                let a86 = {
                    let m85 = match v0.clone() {
                        Adt1::C0(h84, _, _, _, _, _, _) => {
                            h84
                        }
                    };
                    match m85 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h83, _, _, _, _, _, _) => {
                            h83
                        }
                    }
                };
                if bool_not(a86) {
                    let a92 = {
                        let m91 = {
                            let m90 = match v0.clone() {
                                Adt1::C0(h89, _, _, _, _, _, _) => {
                                    h89
                                }
                            };
                            match m90 {
                                Adt2::C0(_, h88, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h88
                                }
                            }
                        };
                        match m91 {
                            Adt3::C0(_, _, h87, _, _, _) => {
                                h87
                            }
                        }
                    };
                    if bool_not(a92) {
                        let a96 = {
                            let m95 = match v0.clone() {
                                Adt1::C0(h94, _, _, _, _, _, _) => {
                                    h94
                                }
                            };
                            match m95 {
                                Adt2::C0(_, _, _, _, _, _, _, _, h93, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h93
                                }
                            }
                        };
                        bool_not(a96)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        };
        if bool_not(a97) {
            Ok(Adt93::C0(Adt89::C0(v0, List::<Adt80>::nil()), false, Str::lit("Stop the current operation before changing its requested limits.")))
        } else {
            let a98 = v2.clone();
            let a99 = Str::lit("");
            if equal(a98, a99) {
                if f29(match v1.clone() {
                    Adt69::C0(_, _, h100) => {
                        h100
                    }
                }) {
                    Ok(Adt93::C0(f9(v0.clone(), Adt91::C4(f30({
                        let m103 = match v0 {
                            Adt1::C0(_, h102, _, _, _, _, _) => {
                                h102
                            }
                        };
                        match m103 {
                            Adt54::C0(_, _, _, _, _, _, _, h101) => {
                                h101
                            }
                        }
                    }, match v1 {
                        Adt69::C0(_, _, h104) => {
                            h104
                        }
                    }, None::<u64>)))?, true, Str::lit("")))
                } else {
                    Ok(Adt93::C0(f31(v0.clone(), f27(v0.clone(), match v0.clone() {
                        Adt1::C0(_, h105, _, _, _, _, _) => {
                            h105
                        }
                    }, f32(match v0 {
                        Adt1::C0(h106, _, _, _, _, _, _) => {
                            h106
                        }
                    }, Adt42::C10(Adt44::C17))), Adt58::C4)?, false, Str::lit("Enter a nonnegative whole number. Clear only an optional quota to request no additional limit.")))
                }
            } else {
                let m107 = f33(v2)?;
                match m107 {
                    None => {
                        Ok(Adt93::C0(f31(v0.clone(), f27(v0.clone(), match v0.clone() {
                            Adt1::C0(_, h108, _, _, _, _, _) => {
                                h108
                            }
                        }, f32(match v0 {
                            Adt1::C0(h109, _, _, _, _, _, _) => {
                                h109
                            }
                        }, Adt42::C10(Adt44::C17))), Adt58::C4)?, false, Str::lit("Enter a nonnegative whole number. Clear only an optional quota to request no additional limit.")))
                    }
                    Some(v3) => {
                        Ok(Adt93::C0(f9(v0.clone(), Adt91::C4(f30({
                            let m112 = match v0 {
                                Adt1::C0(_, h111, _, _, _, _, _) => {
                                    h111
                                }
                            };
                            match m112 {
                                Adt54::C0(_, _, _, _, _, _, _, h110) => {
                                    h110
                                }
                            }
                        }, match v1 {
                            Adt69::C0(_, _, h113) => {
                                h113
                            }
                        }, Some(v3))))?, true, Str::lit("")))
                    }
                }
            }
        }
    }
}

pub fn f14(v0: Adt2, v1: Adt53, v2: Adt12) -> R<bool> {
    if if f20(v0.clone(), v1) {
        if match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h114, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h114
            }
        } {
            let m117 = match v0.clone() {
                Adt2::C0(_, _, h116, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h116
                }
            };
            if match m117 {
                Adt6::C0(_, _, _, h115, _) => {
                    h115
                }
            } {
                let m121 = {
                    let m120 = match v0.clone() {
                        Adt2::C0(_, _, h119, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h119
                        }
                    };
                    match m120 {
                        Adt6::C0(_, _, _, _, h118) => {
                            h118
                        }
                    }
                };
                if match m121 {
                    Adt8::C0 => {
                        true
                    }
                    Adt8::C1 => {
                        false
                    }
                    Adt8::C2 => {
                        false
                    }
                    Adt8::C3 => {
                        false
                    }
                } {
                    let m123 = match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, h122, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h122
                        }
                    };
                    match m123 {
                        None => {
                            false
                        }
                        Some(v3) => {
                            f34(v3, v2)
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    } {
        let a127 = f35({
            let m126 = match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h125, _, _) => {
                    h125
                }
            };
            match m126 {
                Adt51::C0(h124, _) => {
                    h124
                }
            }
        })?;
        let a128 = 0u64;
        if nat_eq(a127, a128) {
            let m132 = {
                let m131 = match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h130, _, _) => {
                        h130
                    }
                };
                match m131 {
                    Adt51::C0(_, h129) => {
                        h129
                    }
                }
            };
            match m132 {
                None => {
                    Ok(true)
                }
                Some(_) => {
                    Ok(false)
                }
            }
        } else {
            Ok(false)
        }
    } else {
        Ok(false)
    }
}

pub fn f15(v0: Adt1) -> R<Adt72> {
    Ok(Adt72::C0(Str::lit("UORC"), Str::lit("Compress and reconstruct arbitrary bytes"), f36(v0.clone()), {
        let m136 = {
            let m135 = match v0.clone() {
                Adt1::C0(h134, _, _, _, _, _, _) => {
                    h134
                }
            };
            match m135 {
                Adt2::C0(_, _, _, _, _, h133, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h133
                }
            }
        };
        match m136 {
            None => {
                Str::lit("No result evidence")
            }
            Some(v1) => {
                f37({
                    let m140 = {
                        let m139 = match v0.clone() {
                            Adt1::C0(h138, _, _, _, _, _, _) => {
                                h138
                            }
                        };
                        match m139 {
                            Adt2::C0(_, _, _, _, h137, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h137
                            }
                        }
                    };
                    match m140 {
                        None => {
                            let m143 = match v0.clone() {
                                Adt1::C0(_, h142, _, _, _, _, _) => {
                                    h142
                                }
                            };
                            match m143 {
                                Adt54::C0(h141, _, _, _, _, _, _, _) => {
                                    h141
                                }
                            }
                        }
                        Some(v2) => {
                            f38(v2)
                        }
                    }
                }, v1)
            }
        }
    }, {
        let m147 = {
            let m146 = match v0.clone() {
                Adt1::C0(h145, _, _, _, _, _, _) => {
                    h145
                }
            };
            match m146 {
                Adt2::C0(_, _, _, _, _, h144, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h144
                }
            }
        };
        match m147 {
            None => {
                Str::lit("No original-byte comparison")
            }
            Some(v3) => {
                f39({
                    let m151 = {
                        let m150 = match v0.clone() {
                            Adt1::C0(h149, _, _, _, _, _, _) => {
                                h149
                            }
                        };
                        match m150 {
                            Adt2::C0(_, _, _, _, h148, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h148
                            }
                        }
                    };
                    match m151 {
                        None => {
                            let m154 = match v0.clone() {
                                Adt1::C0(_, h153, _, _, _, _, _) => {
                                    h153
                                }
                            };
                            match m154 {
                                Adt54::C0(h152, _, _, _, _, _, _, _) => {
                                    h152
                                }
                            }
                        }
                        Some(v4) => {
                            f38(v4)
                        }
                    }
                }, v3)
            }
        }
    }, {
        let m158 = {
            let m157 = match v0.clone() {
                Adt1::C0(h156, _, _, _, _, _, _) => {
                    h156
                }
            };
            match m157 {
                Adt2::C0(_, _, _, _, _, h155, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h155
                }
            }
        };
        match m158 {
            None => {
                None::<Adt32>
            }
            Some(v5) => {
                f40(v5)
            }
        }
    }, List::cons(Adt73::C0(Str::lit("start"), f41({
        let m161 = match v0.clone() {
            Adt1::C0(_, h160, _, _, _, _, _) => {
                h160
            }
        };
        match m161 {
            Adt54::C0(h159, _, _, _, _, _, _, _) => {
                h159
            }
        }
    }), f42(v0.clone(), Adt63::C4), {
        let m164 = match v0.clone() {
            Adt1::C0(h163, _, _, _, _, _, _) => {
                h163
            }
        };
        if if match m164 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h162, _, _, _, _, _, _, _) => {
                h162
            }
        } {
            let a168 = {
                let m167 = match v0.clone() {
                    Adt1::C0(h166, _, _, _, _, _, _) => {
                        h166
                    }
                };
                match m167 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h165, _, _, _, _, _, _) => {
                        h165
                    }
                }
            };
            bool_not(a168)
        } else {
            false
        } {
            let a174 = {
                let m173 = {
                    let m172 = match v0.clone() {
                        Adt1::C0(h171, _, _, _, _, _, _) => {
                            h171
                        }
                    };
                    match m172 {
                        Adt2::C0(_, h170, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h170
                        }
                    }
                };
                match m173 {
                    Adt3::C0(_, _, h169, _, _, _) => {
                        h169
                    }
                }
            };
            if bool_not(a174) {
                let a178 = {
                    let m177 = match v0.clone() {
                        Adt1::C0(h176, _, _, _, _, _, _) => {
                            h176
                        }
                    };
                    match m177 {
                        Adt2::C0(_, _, _, _, _, _, _, _, h175, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h175
                        }
                    }
                };
                if bool_not(a178) {
                    let m180 = f43(match v0.clone() {
                        Adt1::C0(_, h179, _, _, _, _, _) => {
                            h179
                        }
                    });
                    match m180 {
                        Ok(_) => {
                            true
                        }
                        Err(_) => {
                            false
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("cancel"), Str::lit("Cancel"), f42(v0.clone(), Adt63::C5(Adt64::C0)), {
        let m183 = match v0.clone() {
            Adt1::C0(h182, _, _, _, _, _, _) => {
                h182
            }
        };
        if if match m183 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h181, _, _, _, _, _, _, _) => {
                h181
            }
        } {
            let a187 = {
                let m186 = match v0.clone() {
                    Adt1::C0(h185, _, _, _, _, _, _) => {
                        h185
                    }
                };
                match m186 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h184, _, _, _, _, _, _) => {
                        h184
                    }
                }
            };
            bool_not(a187)
        } else {
            false
        } {
            let m192 = {
                let m191 = match v0.clone() {
                    Adt1::C0(h190, _, _, _, _, _, _) => {
                        h190
                    }
                };
                match m191 {
                    Adt2::C0(_, h189, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h189
                    }
                }
            };
            if match m192 {
                Adt3::C0(_, _, h188, _, _, _) => {
                    h188
                }
            } {
                true
            } else {
                let m195 = match v0.clone() {
                    Adt1::C0(h194, _, _, _, _, _, _) => {
                        h194
                    }
                };
                match m195 {
                    Adt2::C0(_, _, _, _, _, _, _, _, h193, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h193
                    }
                }
            }
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("download"), Str::lit("Download result"), f42(v0.clone(), Adt63::C5(Adt64::C6)), f44(match v0.clone() {
        Adt1::C0(h196, _, _, _, _, _, _) => {
            h196
        }
    }), true), List::cons(Adt73::C0(Str::lit("extend"), Str::lit("Continue search"), f42(v0.clone(), Adt63::C6(1000000u64)), {
        let m199 = match v0.clone() {
            Adt1::C0(h198, _, _, _, _, _, _) => {
                h198
            }
        };
        if if match m199 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h197, _, _, _, _, _, _, _) => {
                h197
            }
        } {
            let a203 = {
                let m202 = match v0.clone() {
                    Adt1::C0(h201, _, _, _, _, _, _) => {
                        h201
                    }
                };
                match m202 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h200, _, _, _, _, _, _) => {
                        h200
                    }
                }
            };
            bool_not(a203)
        } else {
            false
        } {
            let m208 = {
                let m207 = match v0.clone() {
                    Adt1::C0(h206, _, _, _, _, _, _) => {
                        h206
                    }
                };
                match m207 {
                    Adt2::C0(_, h205, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h205
                    }
                }
            };
            if match m208 {
                Adt3::C0(_, _, h204, _, _, _) => {
                    h204
                }
            } {
                true
            } else {
                let m212 = {
                    let m211 = match v0.clone() {
                        Adt1::C0(h210, _, _, _, _, _, _) => {
                            h210
                        }
                    };
                    match m211 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h209, _, _, _, _, _, _, _, _) => {
                            h209
                        }
                    }
                };
                if match m212 {
                    None => {
                        false
                    }
                    Some(_) => {
                        true
                    }
                } {
                    let m216 = {
                        let m215 = match v0.clone() {
                            Adt1::C0(_, h214, _, _, _, _, _) => {
                                h214
                            }
                        };
                        match m215 {
                            Adt54::C0(_, h213, _, _, _, _, _, _) => {
                                h213
                            }
                        }
                    };
                    match m216 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                } else {
                    false
                }
            }
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("back"), Str::lit("Back"), f42(v0.clone(), Adt63::C5(Adt64::C2)), {
        let m219 = match v0.clone() {
            Adt1::C0(h218, _, _, _, _, _, _) => {
                h218
            }
        };
        if match m219 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h217, _, _, _, _, _, _, _) => {
                h217
            }
        } {
            let a223 = {
                let m222 = match v0.clone() {
                    Adt1::C0(h221, _, _, _, _, _, _) => {
                        h221
                    }
                };
                match m222 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h220, _, _, _, _, _, _) => {
                        h220
                    }
                }
            };
            bool_not(a223)
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("advanced"), Str::lit("Advanced"), f42(v0.clone(), Adt63::C5(Adt64::C1(Adt49::C1))), {
        let m226 = match v0.clone() {
            Adt1::C0(h225, _, _, _, _, _, _) => {
                h225
            }
        };
        if match m226 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h224, _, _, _, _, _, _, _) => {
                h224
            }
        } {
            let a230 = {
                let m229 = match v0.clone() {
                    Adt1::C0(h228, _, _, _, _, _, _) => {
                        h228
                    }
                };
                match m229 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h227, _, _, _, _, _, _) => {
                        h227
                    }
                }
            };
            bool_not(a230)
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("evidence"), Str::lit("Evidence"), f42(v0.clone(), Adt63::C5(Adt64::C1(Adt49::C2))), {
        let m233 = match v0.clone() {
            Adt1::C0(h232, _, _, _, _, _, _) => {
                h232
            }
        };
        if match m233 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h231, _, _, _, _, _, _, _) => {
                h231
            }
        } {
            let a237 = {
                let m236 = match v0.clone() {
                    Adt1::C0(h235, _, _, _, _, _, _) => {
                        h235
                    }
                };
                match m236 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h234, _, _, _, _, _, _) => {
                        h234
                    }
                }
            };
            bool_not(a237)
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("close"), Str::lit("Close"), f42(v0.clone(), Adt63::C5(Adt64::C4)), {
        let m240 = match v0.clone() {
            Adt1::C0(h239, _, _, _, _, _, _) => {
                h239
            }
        };
        if match m240 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h238, _, _, _, _, _, _, _) => {
                h238
            }
        } {
            let a244 = {
                let m243 = match v0.clone() {
                    Adt1::C0(h242, _, _, _, _, _, _) => {
                        h242
                    }
                };
                match m243 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h241, _, _, _, _, _, _) => {
                        h241
                    }
                }
            };
            bool_not(a244)
        } else {
            false
        }
    }, true), List::<Adt73>::nil())))))))), List::cons(Adt73::C0(Str::lit("compress"), Str::lit("Compress"), f42(v0.clone(), Adt63::C0(Adt55::C0)), {
        let m247 = match v0.clone() {
            Adt1::C0(h246, _, _, _, _, _, _) => {
                h246
            }
        };
        if match m247 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h245, _, _, _, _, _, _, _) => {
                h245
            }
        } {
            let a251 = {
                let m250 = match v0.clone() {
                    Adt1::C0(h249, _, _, _, _, _, _) => {
                        h249
                    }
                };
                match m250 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h248, _, _, _, _, _, _) => {
                        h248
                    }
                }
            };
            bool_not(a251)
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("decompress"), Str::lit("Decompress"), f42(v0.clone(), Adt63::C0(Adt55::C1)), {
        let m254 = match v0.clone() {
            Adt1::C0(h253, _, _, _, _, _, _) => {
                h253
            }
        };
        if match m254 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h252, _, _, _, _, _, _, _) => {
                h252
            }
        } {
            let a258 = {
                let m257 = match v0.clone() {
                    Adt1::C0(h256, _, _, _, _, _, _) => {
                        h256
                    }
                };
                match m257 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h255, _, _, _, _, _, _) => {
                        h255
                    }
                }
            };
            bool_not(a258)
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("inspect"), Str::lit("Inspect"), f42(v0.clone(), Adt63::C0(Adt55::C2)), {
        let m261 = match v0.clone() {
            Adt1::C0(h260, _, _, _, _, _, _) => {
                h260
            }
        };
        if match m261 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h259, _, _, _, _, _, _, _) => {
                h259
            }
        } {
            let a265 = {
                let m264 = match v0.clone() {
                    Adt1::C0(h263, _, _, _, _, _, _) => {
                        h263
                    }
                };
                match m264 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h262, _, _, _, _, _, _) => {
                        h262
                    }
                }
            };
            bool_not(a265)
        } else {
            false
        }
    }, true), List::cons(Adt73::C0(Str::lit("verify"), Str::lit("Verify"), f42(v0.clone(), Adt63::C0(Adt55::C3)), {
        let m268 = match v0.clone() {
            Adt1::C0(h267, _, _, _, _, _, _) => {
                h267
            }
        };
        if match m268 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h266, _, _, _, _, _, _, _) => {
                h266
            }
        } {
            let a272 = {
                let m271 = match v0.clone() {
                    Adt1::C0(h270, _, _, _, _, _, _) => {
                        h270
                    }
                };
                match m271 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h269, _, _, _, _, _, _) => {
                        h269
                    }
                }
            };
            bool_not(a272)
        } else {
            false
        }
    }, true), List::<Adt73>::nil())))), f45(v0.clone())?, {
        let m276 = {
            let m275 = match v0.clone() {
                Adt1::C0(h274, _, _, _, _, _, _) => {
                    h274
                }
            };
            match m275 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h273, _) => {
                    h273
                }
            }
        };
        match m276 {
            None => {
                let m280 = {
                    let m279 = match v0.clone() {
                        Adt1::C0(h278, _, _, _, _, _, _) => {
                            h278
                        }
                    };
                    match m279 {
                        Adt2::C0(_, _, _, _, _, h277, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h277
                        }
                    }
                };
                match m280 {
                    None => {
                        List::<Adt76>::nil()
                    }
                    Some(v10) => {
                        f46(v10)
                    }
                }
            }
            Some(v11) => {
                f47(v11)
            }
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, h281, _, _) => {
            h281
        }
    }, {
        let m285 = {
            let m284 = match v0.clone() {
                Adt1::C0(h283, _, _, _, _, _, _) => {
                    h283
                }
            };
            match m284 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h282, _, _, _, _, _, _, _, _, _) => {
                    h282
                }
            }
        };
        if match m285 {
            None => {
                let m289 = {
                    let m288 = match v0.clone() {
                        Adt1::C0(h287, _, _, _, _, _, _) => {
                            h287
                        }
                    };
                    match m288 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, h286, _, _, _, _, _, _, _, _, _, _) => {
                            h286
                        }
                    }
                };
                match m289 {
                    None => {
                        false
                    }
                    Some(_) => {
                        true
                    }
                }
            }
            Some(_) => {
                true
            }
        } {
            Adt77::C1
        } else {
            Adt77::C0
        }
    }, {
        let m294 = {
            let m293 = match v0.clone() {
                Adt1::C0(h292, _, _, _, _, _, _) => {
                    h292
                }
            };
            match m293 {
                Adt2::C0(_, h291, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h291
                }
            }
        };
        match m294 {
            Adt3::C0(_, _, h290, _, _, _) => {
                h290
            }
        }
    }, true, false, false, {
        let m298 = {
            let m297 = match v0.clone() {
                Adt1::C0(h296, _, _, _, _, _, _) => {
                    h296
                }
            };
            match m297 {
                Adt2::C0(_, _, _, _, _, h295, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h295
                }
            }
        };
        match m298 {
            None => {
                None::<Adt78>
            }
            Some(v14) => {
                Some(f48({
                    let m302 = {
                        let m301 = match v0.clone() {
                            Adt1::C0(h300, _, _, _, _, _, _) => {
                                h300
                            }
                        };
                        match m301 {
                            Adt2::C0(_, _, _, _, h299, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h299
                            }
                        }
                    };
                    match m302 {
                        None => {
                            let m305 = match v0.clone() {
                                Adt1::C0(_, h304, _, _, _, _, _) => {
                                    h304
                                }
                            };
                            match m305 {
                                Adt54::C0(h303, _, _, _, _, _, _, _) => {
                                    h303
                                }
                            }
                        }
                        Some(v15) => {
                            f38(v15)
                        }
                    }
                }, v14))
            }
        }
    }, {
        let m309 = {
            let m308 = match v0.clone() {
                Adt1::C0(h307, _, _, _, _, _, _) => {
                    h307
                }
            };
            match m308 {
                Adt2::C0(_, _, _, _, _, h306, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h306
                }
            }
        };
        match m309 {
            None => {
                None::<Adt31>
            }
            Some(v16) => {
                Some(match v16 {
                    Adt23::C0(_, _, _, _, _, h310, _, _, _, _) => {
                        h310
                    }
                })
            }
        }
    }, {
        let m314 = {
            let m313 = match v0.clone() {
                Adt1::C0(h312, _, _, _, _, _, _) => {
                    h312
                }
            };
            match m313 {
                Adt2::C0(_, _, _, _, _, h311, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h311
                }
            }
        };
        match m314 {
            None => {
                None::<Adt33>
            }
            Some(v17) => {
                Some(match v17 {
                    Adt23::C0(_, _, _, _, _, _, h315, _, _, _) => {
                        h315
                    }
                })
            }
        }
    }, {
        let m319 = {
            let m318 = match v0.clone() {
                Adt1::C0(h317, _, _, _, _, _, _) => {
                    h317
                }
            };
            match m318 {
                Adt2::C0(_, _, _, _, _, h316, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h316
                }
            }
        };
        match m319 {
            None => {
                None::<Adt34>
            }
            Some(v18) => {
                match v18 {
                    Adt23::C0(_, _, _, _, _, _, _, _, _, h320) => {
                        h320
                    }
                }
            }
        }
    }, {
        let m323 = match v0.clone() {
            Adt1::C0(h322, _, _, _, _, _, _) => {
                h322
            }
        };
        match m323 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h321, _, _, _, _, _) => {
                h321
            }
        }
    }, {
        let m327 = {
            let m326 = match v0.clone() {
                Adt1::C0(h325, _, _, _, _, _, _) => {
                    h325
                }
            };
            match m326 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h324, _, _, _, _, _) => {
                    h324
                }
            }
        };
        if match m327 {
            Adt49::C0 => {
                false
            }
            Adt49::C1 => {
                true
            }
            Adt49::C2 => {
                false
            }
            Adt49::C3 => {
                false
            }
        } {
            List::cons(Adt73::C0(Str::lit("resume"), Str::lit("Resume"), f42(v0.clone(), Adt63::C0(Adt55::C4)), {
                let m330 = match v0.clone() {
                    Adt1::C0(h329, _, _, _, _, _, _) => {
                        h329
                    }
                };
                if match m330 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h328, _, _, _, _, _, _, _) => {
                        h328
                    }
                } {
                    let a334 = {
                        let m333 = match v0.clone() {
                            Adt1::C0(h332, _, _, _, _, _, _) => {
                                h332
                            }
                        };
                        match m333 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h331, _, _, _, _, _, _) => {
                                h331
                            }
                        }
                    };
                    bool_not(a334)
                } else {
                    false
                }
            }, true), List::cons(Adt73::C0(Str::lit("buildBasis"), Str::lit("Build basis"), f42(v0.clone(), Adt63::C0(Adt55::C5)), {
                let m337 = match v0.clone() {
                    Adt1::C0(h336, _, _, _, _, _, _) => {
                        h336
                    }
                };
                if match m337 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h335, _, _, _, _, _, _, _) => {
                        h335
                    }
                } {
                    let a341 = {
                        let m340 = match v0.clone() {
                            Adt1::C0(h339, _, _, _, _, _, _) => {
                                h339
                            }
                        };
                        match m340 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h338, _, _, _, _, _, _) => {
                                h338
                            }
                        }
                    };
                    bool_not(a341)
                } else {
                    false
                }
            }, true), List::cons(Adt73::C0(Str::lit("analyzeFrontier"), Str::lit("Analyze frontier"), f42(v0.clone(), Adt63::C0(Adt55::C6)), {
                let m344 = match v0.clone() {
                    Adt1::C0(h343, _, _, _, _, _, _) => {
                        h343
                    }
                };
                if match m344 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h342, _, _, _, _, _, _, _) => {
                        h342
                    }
                } {
                    let a348 = {
                        let m347 = match v0.clone() {
                            Adt1::C0(h346, _, _, _, _, _, _) => {
                                h346
                            }
                        };
                        match m347 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h345, _, _, _, _, _, _) => {
                                h345
                            }
                        }
                    };
                    bool_not(a348)
                } else {
                    false
                }
            }, true), List::cons(Adt73::C0(Str::lit("compare"), Str::lit("Compare"), f42(v0.clone(), Adt63::C0(Adt55::C7)), {
                let m351 = match v0.clone() {
                    Adt1::C0(h350, _, _, _, _, _, _) => {
                        h350
                    }
                };
                if match m351 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h349, _, _, _, _, _, _, _) => {
                        h349
                    }
                } {
                    let a355 = {
                        let m354 = match v0.clone() {
                            Adt1::C0(h353, _, _, _, _, _, _) => {
                                h353
                            }
                        };
                        match m354 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h352, _, _, _, _, _, _) => {
                                h352
                            }
                        }
                    };
                    bool_not(a355)
                } else {
                    false
                }
            }, true), List::<Adt73>::nil()))))
        } else {
            List::<Adt73>::nil()
        }
    }, f49(v0.clone()), Some({
        let m360 = {
            let m359 = match v0.clone() {
                Adt1::C0(h358, _, _, _, _, _, _) => {
                    h358
                }
            };
            match m359 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h357, _, _) => {
                    h357
                }
            }
        };
        match m360 {
            Adt51::C0(h356, _) => {
                h356
            }
        }
    }), {
        let m364 = {
            let m363 = match v0.clone() {
                Adt1::C0(h362, _, _, _, _, _, _) => {
                    h362
                }
            };
            match m363 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h361, _) => {
                    h361
                }
            }
        };
        match m364 {
            None => {
                None::<Adt27>
            }
            Some(v19) => {
                match v19 {
                    Adt24::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h365) => {
                        h365
                    }
                }
            }
        }
    }, Str::lit("Archive contents preserve ordered bytes and empty-object boundaries. The names shown here are selection labels; filenames, directory paths and filesystem metadata are not restored by this archive model."), f50(v0)?, Str::lit("Requested quotas govern each job. An empty optional quota adds no product limit; actual host capacity and runtime addressability still require admission. Logical arena memory, external storage and physical measurements are separate.")))
}

pub fn f16(v0: Adt58) -> Str {
    let m366 = v0;
    match m366 {
        Adt58::C0(v1) => {
            f51(v1)
        }
        Adt58::C1 => {
            Str::lit("operation")
        }
        Adt58::C2 => {
            Str::lit("status")
        }
        Adt58::C3 => {
            Str::lit("result")
        }
        Adt58::C4 => {
            Str::lit("status")
        }
        Adt58::C5 => {
            Str::lit("heading")
        }
    }
}

pub fn f17(v0: Adt1) -> R<Adt85> {
    let m368 = match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h367) => {
            h367
        }
    };
    if match m368 {
        None => {
            false
        }
        Some(_) => {
            true
        }
    } {
        Ok(Adt85::C0(Adt86::C4))
    } else {
        let a373 = {
            let m372 = {
                let m371 = match v0.clone() {
                    Adt1::C0(_, h370, _, _, _, _, _) => {
                        h370
                    }
                };
                match m371 {
                    Adt54::C0(_, h369, _, _, _, _, _, _) => {
                        h369
                    }
                }
            };
            match m372 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        };
        if if bool_not(a373) {
            let a378 = {
                let m377 = {
                    let m376 = match v0.clone() {
                        Adt1::C0(_, h375, _, _, _, _, _) => {
                            h375
                        }
                    };
                    match m376 {
                        Adt54::C0(_, _, h374, _, _, _, _, _) => {
                            h374
                        }
                    }
                };
                match m377 {
                    None => {
                        false
                    }
                    Some(_) => {
                        true
                    }
                }
            };
            if bool_not(a378) {
                let a383 = {
                    let m382 = {
                        let m381 = match v0.clone() {
                            Adt1::C0(_, h380, _, _, _, _, _) => {
                                h380
                            }
                        };
                        match m381 {
                            Adt54::C0(_, _, _, h379, _, _, _, _) => {
                                h379
                            }
                        }
                    };
                    match m382 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                };
                if bool_not(a383) {
                    let a388 = {
                        let m387 = {
                            let m386 = match v0.clone() {
                                Adt1::C0(_, h385, _, _, _, _, _) => {
                                    h385
                                }
                            };
                            match m386 {
                                Adt54::C0(_, _, _, _, h384, _, _, _) => {
                                    h384
                                }
                            }
                        };
                        match m387 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    };
                    if bool_not(a388) {
                        let a393 = {
                            let m392 = {
                                let m391 = match v0.clone() {
                                    Adt1::C0(_, h390, _, _, _, _, _) => {
                                        h390
                                    }
                                };
                                match m391 {
                                    Adt54::C0(_, _, _, _, _, h389, _, _) => {
                                        h389
                                    }
                                }
                            };
                            match m392 {
                                None => {
                                    false
                                }
                                Some(_) => {
                                    true
                                }
                            }
                        };
                        if bool_not(a393) {
                            let a398 = {
                                let m397 = {
                                    let m396 = match v0.clone() {
                                        Adt1::C0(_, h395, _, _, _, _, _) => {
                                            h395
                                        }
                                    };
                                    match m396 {
                                        Adt54::C0(_, _, _, _, _, _, h394, _) => {
                                            h394
                                        }
                                    }
                                };
                                match m397 {
                                    None => {
                                        false
                                    }
                                    Some(_) => {
                                        true
                                    }
                                }
                            };
                            bool_not(a398)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        } {
            f52(match v0 {
                Adt1::C0(h399, _, _, _, _, _, _) => {
                    h399
                }
            })
        } else {
            Ok(Adt85::C0(Adt86::C4))
        }
    }
}

pub fn f18(v0: u64) -> Adt2 {
    Adt2::C0(v0, f53(), f54(), f55(), None::<Adt10>, None::<Adt23>, Adt41::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt12>, false, false, None::<Adt42>, None::<Adt48>, None::<Adt12>, true, false, Adt49::C0, Adt50::C0, false, f56(), None::<Adt24>, List::<Adt52>::nil())
}

pub fn f19() -> Adt14 {
    Adt14::C0(10000000u64, 10000000u64, 10000000u64, 1000000u64, None::<u64>, 268435456u64, f57())
}

pub fn f20(v0: Adt2, v1: Adt53) -> bool {
    let a402 = match v0.clone() {
        Adt2::C0(h400, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h400
        }
    };
    let a403 = match v1.clone() {
        Adt53::C0(h401, _, _) => {
            h401
        }
    };
    if nat_eq(a402, a403) {
        let a408 = {
            let m406 = match v0.clone() {
                Adt2::C0(_, h405, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h405
                }
            };
            match m406 {
                Adt3::C0(_, h404, _, _, _, _) => {
                    h404
                }
            }
        };
        let a409 = match v1.clone() {
            Adt53::C0(_, h407, _) => {
                h407
            }
        };
        if nat_eq(a408, a409) {
            let a414 = {
                let m412 = match v0.clone() {
                    Adt2::C0(_, h411, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h411
                    }
                };
                match m412 {
                    Adt3::C0(h410, _, _, _, _, _) => {
                        h410
                    }
                }
            };
            let a415 = match v1 {
                Adt53::C0(_, _, h413) => {
                    h413
                }
            };
            if nat_eq(a414, a415) {
                if match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h416, _, _, _, _, _, _, _) => {
                        h416
                    }
                } {
                    let a418 = match v0 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h417, _, _, _, _, _, _) => {
                            h417
                        }
                    };
                    bool_not(a418)
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f21(v0: Adt63) -> Adt91 {
    let m419 = v0;
    match m419 {
        Adt63::C0(v1) => {
            Adt91::C0(v1)
        }
        Adt63::C1(v2) => {
            Adt91::C1(v2)
        }
        Adt63::C2(v3) => {
            Adt91::C3(v3)
        }
        Adt63::C3(v4) => {
            Adt91::C4(v4)
        }
        Adt63::C4 => {
            Adt91::C5
        }
        Adt63::C5(v5) => {
            Adt91::C6(v5)
        }
        Adt63::C6(v6) => {
            Adt91::C7(v6)
        }
        Adt63::C7(v7, v8) => {
            Adt91::C8(v7, v8)
        }
        Adt63::C8(v9, v10, v11) => {
            Adt91::C9(v9, v10, v11)
        }
    }
}

pub fn f22(v0: Adt91) -> bool {
    let m420 = v0;
    match m420 {
        Adt91::C0(_) => {
            true
        }
        Adt91::C1(_) => {
            true
        }
        Adt91::C2(_, _, _, _, _) => {
            false
        }
        Adt91::C3(_) => {
            true
        }
        Adt91::C4(_) => {
            true
        }
        Adt91::C5 => {
            false
        }
        Adt91::C6(v10) => {
            let m421 = v10;
            match m421 {
                Adt64::C0 => {
                    true
                }
                Adt64::C1(_) => {
                    false
                }
                Adt64::C2 => {
                    false
                }
                Adt64::C3 => {
                    false
                }
                Adt64::C4 => {
                    false
                }
                Adt64::C5 => {
                    false
                }
                Adt64::C6 => {
                    false
                }
                Adt64::C7(_) => {
                    false
                }
                Adt64::C8 => {
                    false
                }
            }
        }
        Adt91::C7(_) => {
            false
        }
        Adt91::C8(_, _) => {
            false
        }
        Adt91::C9(_, _, _) => {
            false
        }
        Adt91::C10(_, _, _, _) => {
            false
        }
        Adt91::C11(_, _, _) => {
            false
        }
    }
}

pub fn f23(v0: Adt1, v1: Adt91) -> R<Adt89> {
    f58(v0.clone(), v1.clone(), {
        let m422 = v1;
        match m422 {
            Adt91::C0(v2) => {
                f59(v0.clone(), match v0 {
                    Adt1::C0(_, h423, _, _, _, _, _) => {
                        h423
                    }
                }, v2)?
            }
            Adt91::C1(v3) => {
                f60(v0, v3)?
            }
            Adt91::C2(v4, v5, v6, v7, v8) => {
                if if f61(v0.clone(), v4.clone(), v5, v6, v7.clone()) {
                    f62(v8.clone())
                } else {
                    false
                } {
                    f63(v0, v4, v7, v8)?
                } else {
                    Adt89::C0(v0, List::cons(Adt80::C0(Adt81::C6(v7)), List::<Adt80>::nil()))
                }
            }
            Adt91::C3(v9) => {
                Adt89::C0(Adt1::C0({
                    let m427 = {
                        let m426 = f64(v0.clone(), v9.clone(), None::<Adt12>)?;
                        match m426 {
                            Adt89::C0(h425, _) => {
                                h425
                            }
                        }
                    };
                    match m427 {
                        Adt1::C0(h424, _, _, _, _, _, _) => {
                            h424
                        }
                    }
                }, {
                    let m431 = {
                        let m430 = f64(v0.clone(), v9.clone(), None::<Adt12>)?;
                        match m430 {
                            Adt89::C0(h429, _) => {
                                h429
                            }
                        }
                    };
                    match m431 {
                        Adt1::C0(_, h428, _, _, _, _, _) => {
                            h428
                        }
                    }
                }, {
                    let m435 = {
                        let m434 = f64(v0.clone(), v9.clone(), None::<Adt12>)?;
                        match m434 {
                            Adt89::C0(h433, _) => {
                                h433
                            }
                        }
                    };
                    match m435 {
                        Adt1::C0(_, _, h432, _, _, _, _) => {
                            h432
                        }
                    }
                }, {
                    let m439 = {
                        let m438 = f64(v0.clone(), v9.clone(), None::<Adt12>)?;
                        match m438 {
                            Adt89::C0(h437, _) => {
                                h437
                            }
                        }
                    };
                    match m439 {
                        Adt1::C0(_, _, _, h436, _, _, _) => {
                            h436
                        }
                    }
                }, {
                    let m443 = {
                        let m442 = f64(v0.clone(), v9.clone(), None::<Adt12>)?;
                        match m442 {
                            Adt89::C0(h441, _) => {
                                h441
                            }
                        }
                    };
                    match m443 {
                        Adt1::C0(_, _, _, _, h440, _, _) => {
                            h440
                        }
                    }
                }, f65(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h444, _) => {
                        h444
                    }
                }, v9.clone(), List::<Adt60>::nil()), {
                    let m448 = {
                        let m447 = f64(v0.clone(), v9.clone(), None::<Adt12>)?;
                        match m447 {
                            Adt89::C0(h446, _) => {
                                h446
                            }
                        }
                    };
                    match m448 {
                        Adt1::C0(_, _, _, _, _, _, h445) => {
                            h445
                        }
                    }
                }), {
                    let m450 = f64(v0, v9, None::<Adt12>)?;
                    match m450 {
                        Adt89::C0(_, h449) => {
                            h449
                        }
                    }
                })
            }
            Adt91::C4(v10) => {
                f66(v0.clone(), match v0 {
                    Adt1::C0(_, h451, _, _, _, _, _) => {
                        h451
                    }
                }, v10)?
            }
            Adt91::C5 => {
                let m453 = f43(match v0.clone() {
                    Adt1::C0(_, h452, _, _, _, _, _) => {
                        h452
                    }
                });
                match m453 {
                    Ok(v12) => {
                        f27(v0.clone(), match v0.clone() {
                            Adt1::C0(_, h456, _, _, _, _, _) => {
                                h456
                            }
                        }, f67(match v0 {
                            Adt1::C0(h457, _, _, _, _, _, _) => {
                                h457
                            }
                        }, v12)?)
                    }
                    Err(v11) => {
                        f27(v0.clone(), match v0.clone() {
                            Adt1::C0(_, h454, _, _, _, _, _) => {
                                h454
                            }
                        }, f32(match v0 {
                            Adt1::C0(h455, _, _, _, _, _, _) => {
                                h455
                            }
                        }, Adt42::C10(v11)))
                    }
                }
            }
            Adt91::C6(v13) => {
                f68(v0, v13)?
            }
            Adt91::C7(v14) => {
                f69(v0, v14)?
            }
            Adt91::C8(v15, v16) => {
                f70(v0.clone(), v15.clone(), f71(f72(match v0 {
                    Adt1::C0(_, _, _, _, _, h458, _) => {
                        h458
                    }
                }, v15), v16))?
            }
            Adt91::C9(v17, v18, v19) => {
                f70(v0.clone(), v17.clone(), f73(f72(match v0 {
                    Adt1::C0(_, _, _, _, _, h459, _) => {
                        h459
                    }
                }, v17), v18, v19))?
            }
            Adt91::C10(v20, v21, v22, v23) => {
                f74(v0, v20, v21, v22, v23)?
            }
            Adt91::C11(v24, v25, v26) => {
                f75(v0, v24, v25, v26)?
            }
        }
    })
}

pub fn f24(v0: Adt1) -> R<Adt89> {
    let m461 = match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h460) => {
            h460
        }
    };
    match m461 {
        None => {
            Ok(Adt89::C0(v0, List::<Adt80>::nil()))
        }
        Some(v1) => {
            Ok(Adt89::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h462, _, _, _, _, _, _) => {
                    h462
                }
            }, f76(match v0.clone() {
                Adt1::C0(_, h463, _, _, _, _, _) => {
                    h463
                }
            }, match v1.clone() {
                Adt61::C0(h464, _, _, _, _, _) => {
                    h464
                }
            }, Some(match v1.clone() {
                Adt61::C0(_, _, _, h465, _, _) => {
                    h465
                }
            })), {
                let a467 = match v0.clone() {
                    Adt1::C0(_, _, h466, _, _, _, _) => {
                        h466
                    }
                };
                let a468 = 1u64;
                nat_add(a467, a468)?
            }, match v0.clone() {
                Adt1::C0(_, _, _, h469, _, _, _) => {
                    h469
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h470, _, _) => {
                    h470
                }
            }, f65(match v0 {
                Adt1::C0(_, _, _, _, _, h471, _) => {
                    h471
                }
            }, match v1.clone() {
                Adt61::C0(h472, _, _, _, _, _) => {
                    h472
                }
            }, match v1.clone() {
                Adt61::C0(_, _, _, _, _, h473) => {
                    h473
                }
            }), None::<Adt61>), List::cons(Adt80::C3(v1), List::<Adt80>::nil())))
        }
    }
}

pub fn f25(v0: List<Adt80>, v1: List<Adt80>) -> List<Adt80> {
    let m474 = v0;
    match m474.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f25(v3, v1))
        }
    }
}

pub fn f26(v0: Adt1, v1: Adt66, v2: Adt89) -> R<Adt89> {
    let m475 = v1;
    match m475 {
        Adt66::C0(_) => {
            Ok(v2)
        }
        Adt66::C1(_) => {
            Ok(v2)
        }
        Adt66::C2(_, _) => {
            Ok(v2)
        }
        Adt66::C3(_, _) => {
            Ok(v2)
        }
        Adt66::C4(v9, _) => {
            if f77(match v0.clone() {
                Adt1::C0(h476, _, _, _, _, _, _) => {
                    h476
                }
            }, v9) {
                let m482 = {
                    let m481 = {
                        let m480 = match v2.clone() {
                            Adt89::C0(h479, _) => {
                                h479
                            }
                        };
                        match m480 {
                            Adt1::C0(h478, _, _, _, _, _, _) => {
                                h478
                            }
                        }
                    };
                    match m481 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, h477, _, _, _, _, _, _, _, _, _, _) => {
                            h477
                        }
                    }
                };
                if match m482 {
                    None => {
                        let m488 = {
                            let m487 = {
                                let m486 = match v2.clone() {
                                    Adt89::C0(h485, _) => {
                                        h485
                                    }
                                };
                                match m486 {
                                    Adt1::C0(h484, _, _, _, _, _, _) => {
                                        h484
                                    }
                                }
                            };
                            match m487 {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h483, _, _, _, _, _, _, _, _, _) => {
                                    h483
                                }
                            }
                        };
                        match m488 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    }
                    Some(_) => {
                        true
                    }
                } {
                    f31(v0, v2, Adt58::C4)
                } else {
                    f31(v0, v2, Adt58::C3)
                }
            } else {
                Ok(v2)
            }
        }
        Adt66::C5(v13, _) => {
            if if f20(match v0.clone() {
                Adt1::C0(h489, _, _, _, _, _, _) => {
                    h489
                }
            }, v13) {
                let m492 = match v0.clone() {
                    Adt1::C0(h491, _, _, _, _, _, _) => {
                        h491
                    }
                };
                if match m492 {
                    Adt2::C0(_, _, _, _, _, _, _, _, h490, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h490
                    }
                } {
                    true
                } else {
                    let m497 = {
                        let m496 = match v0.clone() {
                            Adt1::C0(h495, _, _, _, _, _, _) => {
                                h495
                            }
                        };
                        match m496 {
                            Adt2::C0(_, h494, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h494
                            }
                        }
                    };
                    match m497 {
                        Adt3::C0(_, _, h493, _, _, _) => {
                            h493
                        }
                    }
                }
            } else {
                false
            } {
                let m503 = {
                    let m502 = {
                        let m501 = match v2.clone() {
                            Adt89::C0(h500, _) => {
                                h500
                            }
                        };
                        match m501 {
                            Adt1::C0(h499, _, _, _, _, _, _) => {
                                h499
                            }
                        }
                    };
                    match m502 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, h498, _, _, _, _, _, _, _, _, _, _) => {
                            h498
                        }
                    }
                };
                if match m503 {
                    None => {
                        let m509 = {
                            let m508 = {
                                let m507 = match v2.clone() {
                                    Adt89::C0(h506, _) => {
                                        h506
                                    }
                                };
                                match m507 {
                                    Adt1::C0(h505, _, _, _, _, _, _) => {
                                        h505
                                    }
                                }
                            };
                            match m508 {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h504, _, _, _, _, _, _, _, _, _) => {
                                    h504
                                }
                            }
                        };
                        match m509 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    }
                    Some(_) => {
                        true
                    }
                } {
                    f31(v0, v2, Adt58::C4)
                } else {
                    f31(v0, v2, Adt58::C3)
                }
            } else {
                Ok(v2)
            }
        }
        Adt66::C6(v17, _) => {
            if f77(match v0.clone() {
                Adt1::C0(h510, _, _, _, _, _, _) => {
                    h510
                }
            }, v17) {
                let m516 = {
                    let m515 = {
                        let m514 = match v2.clone() {
                            Adt89::C0(h513, _) => {
                                h513
                            }
                        };
                        match m514 {
                            Adt1::C0(h512, _, _, _, _, _, _) => {
                                h512
                            }
                        }
                    };
                    match m515 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, h511, _, _, _, _, _, _, _, _, _, _) => {
                            h511
                        }
                    }
                };
                if match m516 {
                    None => {
                        let m522 = {
                            let m521 = {
                                let m520 = match v2.clone() {
                                    Adt89::C0(h519, _) => {
                                        h519
                                    }
                                };
                                match m520 {
                                    Adt1::C0(h518, _, _, _, _, _, _) => {
                                        h518
                                    }
                                }
                            };
                            match m521 {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h517, _, _, _, _, _, _, _, _, _) => {
                                    h517
                                }
                            }
                        };
                        match m522 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    }
                    Some(_) => {
                        true
                    }
                } {
                    f31(v0, v2, Adt58::C4)
                } else {
                    f31(v0, v2, Adt58::C3)
                }
            } else {
                Ok(v2)
            }
        }
        Adt66::C7(v21, _) => {
            if if f20(match v0.clone() {
                Adt1::C0(h523, _, _, _, _, _, _) => {
                    h523
                }
            }, v21) {
                let m526 = match v0.clone() {
                    Adt1::C0(h525, _, _, _, _, _, _) => {
                        h525
                    }
                };
                match m526 {
                    Adt2::C0(_, _, _, _, _, _, _, _, h524, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h524
                    }
                }
            } else {
                false
            } {
                let m532 = {
                    let m531 = {
                        let m530 = match v2.clone() {
                            Adt89::C0(h529, _) => {
                                h529
                            }
                        };
                        match m530 {
                            Adt1::C0(h528, _, _, _, _, _, _) => {
                                h528
                            }
                        }
                    };
                    match m531 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, h527, _, _, _, _, _, _, _, _, _, _) => {
                            h527
                        }
                    }
                };
                if match m532 {
                    None => {
                        let m538 = {
                            let m537 = {
                                let m536 = match v2.clone() {
                                    Adt89::C0(h535, _) => {
                                        h535
                                    }
                                };
                                match m536 {
                                    Adt1::C0(h534, _, _, _, _, _, _) => {
                                        h534
                                    }
                                }
                            };
                            match m537 {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h533, _, _, _, _, _, _, _, _, _) => {
                                    h533
                                }
                            }
                        };
                        match m538 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    }
                    Some(_) => {
                        true
                    }
                } {
                    f31(v0, v2, Adt58::C4)
                } else {
                    f31(v0, v2, Adt58::C3)
                }
            } else {
                Ok(v2)
            }
        }
        Adt66::C8(_, _) => {
            Ok(v2)
        }
        Adt66::C9(v27, _) => {
            if if f20(match v0.clone() {
                Adt1::C0(h539, _, _, _, _, _, _) => {
                    h539
                }
            }, v27) {
                let m543 = {
                    let m542 = match v0.clone() {
                        Adt1::C0(h541, _, _, _, _, _, _) => {
                            h541
                        }
                    };
                    match m542 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, h540, _, _, _, _, _, _, _, _, _, _) => {
                            h540
                        }
                    }
                };
                if match m543 {
                    None => {
                        true
                    }
                    Some(_) => {
                        false
                    }
                } {
                    let m549 = {
                        let m548 = {
                            let m547 = match v2.clone() {
                                Adt89::C0(h546, _) => {
                                    h546
                                }
                            };
                            match m547 {
                                Adt1::C0(h545, _, _, _, _, _, _) => {
                                    h545
                                }
                            }
                        };
                        match m548 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, h544, _, _, _, _, _, _, _, _, _, _) => {
                                h544
                            }
                        }
                    };
                    match m549 {
                        None => {
                            let m555 = {
                                let m554 = {
                                    let m553 = match v2.clone() {
                                        Adt89::C0(h552, _) => {
                                            h552
                                        }
                                    };
                                    match m553 {
                                        Adt1::C0(h551, _, _, _, _, _, _) => {
                                            h551
                                        }
                                    }
                                };
                                match m554 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h550, _, _, _, _, _, _, _, _, _) => {
                                        h550
                                    }
                                }
                            };
                            match m555 {
                                None => {
                                    false
                                }
                                Some(_) => {
                                    true
                                }
                            }
                        }
                        Some(_) => {
                            true
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f31(v0, v2, Adt58::C4)
            } else {
                Ok(v2)
            }
        }
        Adt66::C10(_, _) => {
            Ok(v2)
        }
        Adt66::C11(_) => {
            Ok(v2)
        }
    }
}

pub fn f27(v0: Adt1, v1: Adt54, v2: Adt94) -> Adt89 {
    Adt89::C0(Adt1::C0(match v2.clone() {
        Adt94::C0(h556, _) => {
            h556
        }
    }, v1, match v0.clone() {
        Adt1::C0(_, _, h557, _, _, _, _) => {
            h557
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, h558, _, _, _) => {
            h558
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, h559, _, _) => {
            h559
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, h560, _) => {
            h560
        }
    }, match v0 {
        Adt1::C0(_, _, _, _, _, _, h561) => {
            h561
        }
    }), f78(match v2 {
        Adt94::C0(_, h562) => {
            h562
        }
    }))
}

pub fn f28(v0: Adt2, v1: Adt92) -> R<Adt94> {
    let m563 = v1;
    match m563 {
        Adt92::C0(v2) => {
            f67(v0, v2)
        }
        Adt92::C1 => {
            f79(v0.clone(), match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h564, _, _, _, _, _, _, _) => {
                    h564
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h565, _, _, _, _, _, _) => {
                    h565
                }
            }, match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h566, _, _, _, _, _) => {
                    h566
                }
            })
        }
        Adt92::C2 => {
            f80(v0)
        }
        Adt92::C3(v3) => {
            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h567, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h567
                }
            }, match v0.clone() {
                Adt2::C0(_, h568, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h568
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h569, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h569
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h570, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h570
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h571, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h571
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h572, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h572
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h573, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h573
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h574, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h574
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h575, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h575
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h576, _, _, _, _, _, _, _, _, _, _, _) => {
                    h576
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, h577, _, _, _, _, _, _, _, _, _, _) => {
                    h577
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h578, _, _, _, _, _, _, _, _, _) => {
                    h578
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h579, _, _, _, _, _, _, _, _) => {
                    h579
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h580, _, _, _, _, _, _, _) => {
                    h580
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h581, _, _, _, _, _, _) => {
                    h581
                }
            }, v3, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h582, _, _, _, _) => {
                    h582
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h583, _, _, _) => {
                    h583
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h584, _, _) => {
                    h584
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h585, _) => {
                    h585
                }
            }, match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h586) => {
                    h586
                }
            }), List::<Adt81>::nil()))
        }
        Adt92::C4 => {
            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h587, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h587
                }
            }, match v0.clone() {
                Adt2::C0(_, h588, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h588
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h589, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h589
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h590, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h590
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h591, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h591
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h592, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h592
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h593, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h593
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h594, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h594
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h595, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h595
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h596, _, _, _, _, _, _, _, _, _, _, _) => {
                    h596
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, h597, _, _, _, _, _, _, _, _, _, _) => {
                    h597
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h598, _, _, _, _, _, _, _, _, _) => {
                    h598
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h599, _, _, _, _, _, _, _, _) => {
                    h599
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h600, _, _, _, _, _, _, _) => {
                    h600
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h601, _, _, _, _, _, _) => {
                    h601
                }
            }, Adt49::C0, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h602, _, _, _, _) => {
                    h602
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h603, _, _, _) => {
                    h603
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h604, _, _) => {
                    h604
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h605, _) => {
                    h605
                }
            }, match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h606) => {
                    h606
                }
            }), List::<Adt81>::nil()))
        }
        Adt92::C5 => {
            if match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h607, _, _, _, _, _, _, _) => {
                    h607
                }
            } {
                f79(v0.clone(), false, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h608, _, _, _, _, _, _) => {
                        h608
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h609, _, _, _, _, _) => {
                        h609
                    }
                })
            } else {
                Ok(Adt94::C0(v0, List::<Adt81>::nil()))
            }
        }
        Adt92::C6 => {
            f81(v0)
        }
        Adt92::C7 => {
            f81(v0)
        }
        Adt92::C8(v4) => {
            let a611 = match v0.clone() {
                Adt2::C0(h610, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h610
                }
            };
            let a612 = v4;
            if nat_eq(a611, a612) {
                Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h613, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h613
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h614, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h614
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h615, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h615
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h616, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h616
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h617, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h617
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h618, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h618
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h619, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h619
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h620, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h620
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h621, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h621
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h622, _, _, _, _, _, _, _, _, _, _, _) => {
                        h622
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, h623, _, _, _, _, _, _, _, _, _, _) => {
                        h623
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h624, _, _, _, _, _, _, _, _, _) => {
                        h624
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h625, _, _, _, _, _, _, _, _) => {
                        h625
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h626, _, _, _, _, _, _, _) => {
                        h626
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h627, _, _, _, _, _, _) => {
                        h627
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h628, _, _, _, _, _) => {
                        h628
                    }
                }, Adt50::C2, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h629, _, _, _) => {
                        h629
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h630, _, _) => {
                        h630
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h631, _) => {
                        h631
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h632) => {
                        h632
                    }
                }), List::<Adt81>::nil()))
            } else {
                Ok(Adt94::C0(v0, List::<Adt81>::nil()))
            }
        }
        Adt92::C9(v5) => {
            Ok(f82(v0, v5))
        }
        Adt92::C10(v6, v7) => {
            f83(v0, v6, v7)
        }
        Adt92::C11(v8) => {
            let m635 = match v0.clone() {
                Adt2::C0(_, h634, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h634
                }
            };
            if match m635 {
                Adt3::C0(_, _, h633, _, _, _) => {
                    h633
                }
            } {
                Ok(Adt94::C0(v0.clone(), List::cons(Adt81::C2(f84(v0), v8), List::<Adt81>::nil())))
            } else {
                Ok(Adt94::C0(v0, List::<Adt81>::nil()))
            }
        }
        Adt92::C12(v9, v10) => {
            if f77(v0.clone(), v9) {
                Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h636, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h636
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h637, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h637
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h638, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h638
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h639, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h639
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h640, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h640
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h641, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h641
                    }
                }, v10, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h642, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h642
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h643, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h643
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h644, _, _, _, _, _, _, _, _, _, _, _) => {
                        h644
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, h645, _, _, _, _, _, _, _, _, _, _) => {
                        h645
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h646, _, _, _, _, _, _, _, _, _) => {
                        h646
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h647, _, _, _, _, _, _, _, _) => {
                        h647
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h648, _, _, _, _, _, _, _) => {
                        h648
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h649, _, _, _, _, _, _) => {
                        h649
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h650, _, _, _, _, _) => {
                        h650
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h651, _, _, _, _) => {
                        h651
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h652, _, _, _) => {
                        h652
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h653, _, _) => {
                        h653
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h654, _) => {
                        h654
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h655) => {
                        h655
                    }
                }), List::<Adt81>::nil()))
            } else {
                Ok(Adt94::C0(v0, List::<Adt81>::nil()))
            }
        }
        Adt92::C13(v11, v12) => {
            if if f77(v0.clone(), v11) {
                let a658 = match v12.clone() {
                    Adt12::C0(h656, _, _) => {
                        h656
                    }
                };
                let a659 = match v0.clone() {
                    Adt2::C0(h657, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h657
                    }
                };
                nat_eq(a658, a659)
            } else {
                false
            } {
                Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h660, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h660
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h661, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h661
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h662, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h662
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h663, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h663
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h664, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h664
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h665, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h665
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h666, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h666
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h667, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h667
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h668, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h668
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h669, _, _, _, _, _, _, _, _, _, _, _) => {
                        h669
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, h670, _, _, _, _, _, _, _, _, _, _) => {
                        h670
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h671, _, _, _, _, _, _, _, _, _) => {
                        h671
                    }
                }, Some(v12), match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h672, _, _, _, _, _, _, _) => {
                        h672
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h673, _, _, _, _, _, _) => {
                        h673
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h674, _, _, _, _, _) => {
                        h674
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h675, _, _, _, _) => {
                        h675
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h676, _, _, _) => {
                        h676
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h677, _, _) => {
                        h677
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h678, _) => {
                        h678
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h679) => {
                        h679
                    }
                }), f85(match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h680, _, _, _, _, _, _, _, _) => {
                        h680
                    }
                })))
            } else {
                Ok(Adt94::C0(v0, List::cons(Adt81::C6(v12), List::<Adt81>::nil())))
            }
        }
        Adt92::C14(v13) => {
            Ok(f86(v0, v13))
        }
        Adt92::C15(v14, v15) => {
            f87(v0, v14, v15)
        }
        Adt92::C16(v16, v17) => {
            Ok(f88(v0, v16, v17))
        }
        Adt92::C17(v18, v19) => {
            if f77(v0.clone(), v18.clone()) {
                Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h681, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h681
                    }
                }, f89(match v0.clone() {
                    Adt2::C0(_, h682, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h682
                    }
                }), f90(match v0.clone() {
                    Adt2::C0(_, _, h683, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h683
                    }
                }, Adt8::C3), match v0.clone() {
                    Adt2::C0(_, _, _, h684, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h684
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h685, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h685
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h686, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h686
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h687, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h687
                    }
                }, None::<Adt12>, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h688, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h688
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h689, _, _, _, _, _, _, _, _, _, _, _) => {
                        h689
                    }
                }, None::<Adt42>, Some(v19), match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h690, _, _, _, _, _, _, _, _) => {
                        h690
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h691, _, _, _, _, _, _, _) => {
                        h691
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h692, _, _, _, _, _, _) => {
                        h692
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h693, _, _, _, _, _) => {
                        h693
                    }
                }, Adt50::C1, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h694, _, _, _) => {
                        h694
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h695, _, _) => {
                        h695
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h696, _) => {
                        h696
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h697) => {
                        h697
                    }
                }), List::cons(Adt81::C4(v18.clone()), List::cons(Adt81::C5(v18), List::<Adt81>::nil()))))
            } else {
                Ok(Adt94::C0(v0, List::<Adt81>::nil()))
            }
        }
        Adt92::C18 => {
            Ok(f91(v0))
        }
        Adt92::C19(v20, v21) => {
            Ok(f92(v0, v20, v21))
        }
        Adt92::C20 => {
            Ok(f91(v0))
        }
        Adt92::C21(v22, v23) => {
            f93(v0, v22, v23)
        }
        Adt92::C22(v24, v25) => {
            f94(v0, v24, v25)
        }
        Adt92::C23(v26, v27) => {
            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h698, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h698
                }
            }, match v0.clone() {
                Adt2::C0(_, h699, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h699
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h700, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h700
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h701, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h701
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h702, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h702
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h703, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h703
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h704, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h704
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h705, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h705
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h706, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h706
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h707, _, _, _, _, _, _, _, _, _, _, _) => {
                    h707
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, h708, _, _, _, _, _, _, _, _, _, _) => {
                    h708
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h709, _, _, _, _, _, _, _, _, _) => {
                    h709
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h710, _, _, _, _, _, _, _, _) => {
                    h710
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h711, _, _, _, _, _, _, _) => {
                    h711
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h712, _, _, _, _, _, _) => {
                    h712
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h713, _, _, _, _, _) => {
                    h713
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h714, _, _, _, _) => {
                    h714
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h715, _, _, _) => {
                    h715
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h716, _, _) => {
                    h716
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h717, _) => {
                    h717
                }
            }, f95(match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h718) => {
                    h718
                }
            }, v26, v27)?), List::<Adt81>::nil()))
        }
        Adt92::C24(v28) => {
            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h719, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h719
                }
            }, match v0.clone() {
                Adt2::C0(_, h720, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h720
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h721, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h721
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h722, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h722
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h723, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h723
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h724, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h724
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h725, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h725
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h726, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h726
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h727, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h727
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h728, _, _, _, _, _, _, _, _, _, _, _) => {
                    h728
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, h729, _, _, _, _, _, _, _, _, _, _) => {
                    h729
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h730, _, _, _, _, _, _, _, _, _) => {
                    h730
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h731, _, _, _, _, _, _, _, _) => {
                    h731
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h732, _, _, _, _, _, _, _) => {
                    h732
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h733, _, _, _, _, _, _) => {
                    h733
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h734, _, _, _, _, _) => {
                    h734
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h735, _, _, _, _) => {
                    h735
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h736, _, _, _) => {
                    h736
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h737, _, _) => {
                    h737
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h738, _) => {
                    h738
                }
            }, f96(match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h739) => {
                    h739
                }
            }, v28)?), List::<Adt81>::nil()))
        }
    }
}

pub fn f29(v0: Adt70) -> bool {
    let m740 = v0;
    match m740 {
        Adt70::C0 => {
            false
        }
        Adt70::C1 => {
            false
        }
        Adt70::C2 => {
            false
        }
        Adt70::C3 => {
            false
        }
        Adt70::C4 => {
            true
        }
        Adt70::C5 => {
            false
        }
        Adt70::C6 => {
            true
        }
        Adt70::C7 => {
            true
        }
        Adt70::C8 => {
            true
        }
        Adt70::C9 => {
            true
        }
        Adt70::C10 => {
            true
        }
    }
}

pub fn f30(v0: Adt14, v1: Adt70, v2: Option<u64>) -> Adt14 {
    let m741 = v1;
    match m741 {
        Adt70::C0 => {
            Adt14::C0({
                let m742 = v2;
                match m742 {
                    None => {
                        0u64
                    }
                    Some(v3) => {
                        v3
                    }
                }
            }, match v0.clone() {
                Adt14::C0(_, h743, _, _, _, _, _) => {
                    h743
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h744, _, _, _, _) => {
                    h744
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h745, _, _, _) => {
                    h745
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h746, _, _) => {
                    h746
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h747, _) => {
                    h747
                }
            }, match v0 {
                Adt14::C0(_, _, _, _, _, _, h748) => {
                    h748
                }
            })
        }
        Adt70::C1 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h749, _, _, _, _, _, _) => {
                    h749
                }
            }, {
                let m750 = v2;
                match m750 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h751, _, _, _, _) => {
                    h751
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h752, _, _, _) => {
                    h752
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h753, _, _) => {
                    h753
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h754, _) => {
                    h754
                }
            }, match v0 {
                Adt14::C0(_, _, _, _, _, _, h755) => {
                    h755
                }
            })
        }
        Adt70::C2 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h756, _, _, _, _, _, _) => {
                    h756
                }
            }, match v0.clone() {
                Adt14::C0(_, h757, _, _, _, _, _) => {
                    h757
                }
            }, {
                let m758 = v2;
                match m758 {
                    None => {
                        0u64
                    }
                    Some(v5) => {
                        v5
                    }
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h759, _, _, _) => {
                    h759
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h760, _, _) => {
                    h760
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h761, _) => {
                    h761
                }
            }, match v0 {
                Adt14::C0(_, _, _, _, _, _, h762) => {
                    h762
                }
            })
        }
        Adt70::C3 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h763, _, _, _, _, _, _) => {
                    h763
                }
            }, match v0.clone() {
                Adt14::C0(_, h764, _, _, _, _, _) => {
                    h764
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h765, _, _, _, _) => {
                    h765
                }
            }, {
                let m766 = v2;
                match m766 {
                    None => {
                        0u64
                    }
                    Some(v6) => {
                        v6
                    }
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h767, _, _) => {
                    h767
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h768, _) => {
                    h768
                }
            }, match v0 {
                Adt14::C0(_, _, _, _, _, _, h769) => {
                    h769
                }
            })
        }
        Adt70::C4 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h770, _, _, _, _, _, _) => {
                    h770
                }
            }, match v0.clone() {
                Adt14::C0(_, h771, _, _, _, _, _) => {
                    h771
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h772, _, _, _, _) => {
                    h772
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h773, _, _, _) => {
                    h773
                }
            }, v2, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h774, _) => {
                    h774
                }
            }, match v0 {
                Adt14::C0(_, _, _, _, _, _, h775) => {
                    h775
                }
            })
        }
        Adt70::C5 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h776, _, _, _, _, _, _) => {
                    h776
                }
            }, match v0.clone() {
                Adt14::C0(_, h777, _, _, _, _, _) => {
                    h777
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h778, _, _, _, _) => {
                    h778
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h779, _, _, _) => {
                    h779
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h780, _, _) => {
                    h780
                }
            }, {
                let m781 = v2;
                match m781 {
                    None => {
                        0u64
                    }
                    Some(v7) => {
                        v7
                    }
                }
            }, match v0 {
                Adt14::C0(_, _, _, _, _, _, h782) => {
                    h782
                }
            })
        }
        Adt70::C6 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h783, _, _, _, _, _, _) => {
                    h783
                }
            }, match v0.clone() {
                Adt14::C0(_, h784, _, _, _, _, _) => {
                    h784
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h785, _, _, _, _) => {
                    h785
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h786, _, _, _) => {
                    h786
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h787, _, _) => {
                    h787
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h788, _) => {
                    h788
                }
            }, Adt15::C0(v2, {
                let m791 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h790) => {
                        h790
                    }
                };
                match m791 {
                    Adt15::C0(_, h789, _, _, _) => {
                        h789
                    }
                }
            }, {
                let m794 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h793) => {
                        h793
                    }
                };
                match m794 {
                    Adt15::C0(_, _, h792, _, _) => {
                        h792
                    }
                }
            }, {
                let m797 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h796) => {
                        h796
                    }
                };
                match m797 {
                    Adt15::C0(_, _, _, h795, _) => {
                        h795
                    }
                }
            }, {
                let m800 = match v0 {
                    Adt14::C0(_, _, _, _, _, _, h799) => {
                        h799
                    }
                };
                match m800 {
                    Adt15::C0(_, _, _, _, h798) => {
                        h798
                    }
                }
            }))
        }
        Adt70::C7 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h801, _, _, _, _, _, _) => {
                    h801
                }
            }, match v0.clone() {
                Adt14::C0(_, h802, _, _, _, _, _) => {
                    h802
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h803, _, _, _, _) => {
                    h803
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h804, _, _, _) => {
                    h804
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h805, _, _) => {
                    h805
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h806, _) => {
                    h806
                }
            }, Adt15::C0({
                let m809 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h808) => {
                        h808
                    }
                };
                match m809 {
                    Adt15::C0(h807, _, _, _, _) => {
                        h807
                    }
                }
            }, v2, {
                let m812 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h811) => {
                        h811
                    }
                };
                match m812 {
                    Adt15::C0(_, _, h810, _, _) => {
                        h810
                    }
                }
            }, {
                let m815 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h814) => {
                        h814
                    }
                };
                match m815 {
                    Adt15::C0(_, _, _, h813, _) => {
                        h813
                    }
                }
            }, {
                let m818 = match v0 {
                    Adt14::C0(_, _, _, _, _, _, h817) => {
                        h817
                    }
                };
                match m818 {
                    Adt15::C0(_, _, _, _, h816) => {
                        h816
                    }
                }
            }))
        }
        Adt70::C8 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h819, _, _, _, _, _, _) => {
                    h819
                }
            }, match v0.clone() {
                Adt14::C0(_, h820, _, _, _, _, _) => {
                    h820
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h821, _, _, _, _) => {
                    h821
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h822, _, _, _) => {
                    h822
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h823, _, _) => {
                    h823
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h824, _) => {
                    h824
                }
            }, Adt15::C0({
                let m827 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h826) => {
                        h826
                    }
                };
                match m827 {
                    Adt15::C0(h825, _, _, _, _) => {
                        h825
                    }
                }
            }, {
                let m830 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h829) => {
                        h829
                    }
                };
                match m830 {
                    Adt15::C0(_, h828, _, _, _) => {
                        h828
                    }
                }
            }, v2, {
                let m833 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h832) => {
                        h832
                    }
                };
                match m833 {
                    Adt15::C0(_, _, _, h831, _) => {
                        h831
                    }
                }
            }, {
                let m836 = match v0 {
                    Adt14::C0(_, _, _, _, _, _, h835) => {
                        h835
                    }
                };
                match m836 {
                    Adt15::C0(_, _, _, _, h834) => {
                        h834
                    }
                }
            }))
        }
        Adt70::C9 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h837, _, _, _, _, _, _) => {
                    h837
                }
            }, match v0.clone() {
                Adt14::C0(_, h838, _, _, _, _, _) => {
                    h838
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h839, _, _, _, _) => {
                    h839
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h840, _, _, _) => {
                    h840
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h841, _, _) => {
                    h841
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h842, _) => {
                    h842
                }
            }, Adt15::C0({
                let m845 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h844) => {
                        h844
                    }
                };
                match m845 {
                    Adt15::C0(h843, _, _, _, _) => {
                        h843
                    }
                }
            }, {
                let m848 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h847) => {
                        h847
                    }
                };
                match m848 {
                    Adt15::C0(_, h846, _, _, _) => {
                        h846
                    }
                }
            }, {
                let m851 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h850) => {
                        h850
                    }
                };
                match m851 {
                    Adt15::C0(_, _, h849, _, _) => {
                        h849
                    }
                }
            }, v2, {
                let m854 = match v0 {
                    Adt14::C0(_, _, _, _, _, _, h853) => {
                        h853
                    }
                };
                match m854 {
                    Adt15::C0(_, _, _, _, h852) => {
                        h852
                    }
                }
            }))
        }
        Adt70::C10 => {
            Adt14::C0(match v0.clone() {
                Adt14::C0(h855, _, _, _, _, _, _) => {
                    h855
                }
            }, match v0.clone() {
                Adt14::C0(_, h856, _, _, _, _, _) => {
                    h856
                }
            }, match v0.clone() {
                Adt14::C0(_, _, h857, _, _, _, _) => {
                    h857
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, h858, _, _, _) => {
                    h858
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, h859, _, _) => {
                    h859
                }
            }, match v0.clone() {
                Adt14::C0(_, _, _, _, _, h860, _) => {
                    h860
                }
            }, Adt15::C0({
                let m863 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h862) => {
                        h862
                    }
                };
                match m863 {
                    Adt15::C0(h861, _, _, _, _) => {
                        h861
                    }
                }
            }, {
                let m866 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h865) => {
                        h865
                    }
                };
                match m866 {
                    Adt15::C0(_, h864, _, _, _) => {
                        h864
                    }
                }
            }, {
                let m869 = match v0.clone() {
                    Adt14::C0(_, _, _, _, _, _, h868) => {
                        h868
                    }
                };
                match m869 {
                    Adt15::C0(_, _, h867, _, _) => {
                        h867
                    }
                }
            }, {
                let m872 = match v0 {
                    Adt14::C0(_, _, _, _, _, _, h871) => {
                        h871
                    }
                };
                match m872 {
                    Adt15::C0(_, _, _, h870, _) => {
                        h870
                    }
                }
            }, v2))
        }
    }
}

pub fn f31(v0: Adt1, v1: Adt89, v2: Adt58) -> R<Adt89> {
    Ok(Adt89::C0(Adt1::C0({
        let m875 = match v1.clone() {
            Adt89::C0(h874, _) => {
                h874
            }
        };
        match m875 {
            Adt1::C0(h873, _, _, _, _, _, _) => {
                h873
            }
        }
    }, {
        let m878 = match v1.clone() {
            Adt89::C0(h877, _) => {
                h877
            }
        };
        match m878 {
            Adt1::C0(_, h876, _, _, _, _, _) => {
                h876
            }
        }
    }, {
        let m881 = match v1.clone() {
            Adt89::C0(h880, _) => {
                h880
            }
        };
        match m881 {
            Adt1::C0(_, _, h879, _, _, _, _) => {
                h879
            }
        }
    }, {
        let m884 = match v1.clone() {
            Adt89::C0(h883, _) => {
                h883
            }
        };
        match m884 {
            Adt1::C0(_, _, _, h882, _, _, _) => {
                h882
            }
        }
    }, Adt57::C0({
        let a888 = {
            let m887 = match v0 {
                Adt1::C0(_, _, _, _, h886, _, _) => {
                    h886
                }
            };
            match m887 {
                Adt57::C0(h885, _) => {
                    h885
                }
            }
        };
        let a889 = 1u64;
        nat_add(a888, a889)?
    }, v2), {
        let m892 = match v1.clone() {
            Adt89::C0(h891, _) => {
                h891
            }
        };
        match m892 {
            Adt1::C0(_, _, _, _, _, h890, _) => {
                h890
            }
        }
    }, {
        let m895 = match v1.clone() {
            Adt89::C0(h894, _) => {
                h894
            }
        };
        match m895 {
            Adt1::C0(_, _, _, _, _, _, h893) => {
                h893
            }
        }
    }), match v1 {
        Adt89::C0(_, h896) => {
            h896
        }
    }))
}

pub fn f32(v0: Adt2, v1: Adt42) -> Adt94 {
    Adt94::C0(Adt2::C0(match v0.clone() {
        Adt2::C0(h897, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h897
        }
    }, match v0.clone() {
        Adt2::C0(_, h898, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h898
        }
    }, match v0.clone() {
        Adt2::C0(_, _, h899, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h899
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, h900, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h900
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, h901, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h901
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, h902, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h902
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, h903, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h903
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, h904, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h904
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, h905, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h905
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, h906, _, _, _, _, _, _, _, _, _, _, _) => {
            h906
        }
    }, Some(v1), match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h907, _, _, _, _, _, _, _, _, _) => {
            h907
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h908, _, _, _, _, _, _, _, _) => {
            h908
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h909, _, _, _, _, _, _, _) => {
            h909
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h910, _, _, _, _, _, _) => {
            h910
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h911, _, _, _, _, _) => {
            h911
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h912, _, _, _, _) => {
            h912
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h913, _, _, _) => {
            h913
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h914, _, _) => {
            h914
        }
    }, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h915, _) => {
            h915
        }
    }, match v0 {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h916) => {
            h916
        }
    }), List::<Adt81>::nil())
}

pub fn f33(v0: Str) -> R<Option<u64>> {
    f97({
        let a917 = v0.clone();
        utf8_encode(a917)
    }, {
        let a919 = {
            let a918 = v0;
            utf8_encode(a918)
        };
        length_bytes(a919)
    }, 0u64, 0u64)
}

pub fn f34(v0: Adt12, v1: Adt12) -> bool {
    let a922 = match v0.clone() {
        Adt12::C0(h920, _, _) => {
            h920
        }
    };
    let a923 = match v1.clone() {
        Adt12::C0(h921, _, _) => {
            h921
        }
    };
    if nat_eq(a922, a923) {
        let a926 = match v0.clone() {
            Adt12::C0(_, h924, _) => {
                h924
            }
        };
        let a927 = match v1.clone() {
            Adt12::C0(_, h925, _) => {
                h925
            }
        };
        if nat_eq(a926, a927) {
            let a930 = match v0 {
                Adt12::C0(_, _, h928) => {
                    h928
                }
            };
            let a931 = match v1 {
                Adt12::C0(_, _, h929) => {
                    h929
                }
            };
            nat_eq(a930, a931)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f35(v0: Adt25) -> R<u64> {
    f98(match v0 {
        Adt25::C0(_, h932, _, _) => {
            h932
        }
    })
}

pub fn f36(v0: Adt1) -> Str {
    let m936 = {
        let m935 = match v0.clone() {
            Adt1::C0(h934, _, _, _, _, _, _) => {
                h934
            }
        };
        match m935 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h933, _, _, _, _, _, _, _, _, _) => {
                h933
            }
        }
    };
    match m936 {
        None => {
            let m940 = {
                let m939 = match v0.clone() {
                    Adt1::C0(h938, _, _, _, _, _, _) => {
                        h938
                    }
                };
                match m939 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, h937, _, _, _, _, _, _, _, _, _, _) => {
                        h937
                    }
                }
            };
            match m940 {
                None => {
                    let m943 = match v0.clone() {
                        Adt1::C0(h942, _, _, _, _, _, _) => {
                            h942
                        }
                    };
                    if match m943 {
                        Adt2::C0(_, _, _, _, _, _, _, _, h941, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h941
                        }
                    } {
                        Str::lit("Downloading")
                    } else {
                        let m946 = match v0.clone() {
                            Adt1::C0(h945, _, _, _, _, _, _) => {
                                h945
                            }
                        };
                        if match m946 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, h944, _, _, _, _, _, _, _, _, _, _, _) => {
                                h944
                            }
                        } {
                            Str::lit("Downloaded; the destination owns the result")
                        } else {
                            let m951 = {
                                let m950 = match v0.clone() {
                                    Adt1::C0(h949, _, _, _, _, _, _) => {
                                        h949
                                    }
                                };
                                match m950 {
                                    Adt2::C0(_, h948, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                        h948
                                    }
                                }
                            };
                            if match m951 {
                                Adt3::C0(_, _, h947, _, _, _) => {
                                    h947
                                }
                            } {
                                let m956 = {
                                    let m955 = match v0 {
                                        Adt1::C0(h954, _, _, _, _, _, _) => {
                                            h954
                                        }
                                    };
                                    match m955 {
                                        Adt2::C0(_, _, _, _, _, _, h953, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                            h953
                                        }
                                    }
                                };
                                match m956 {
                                    Adt41::C0(_, _, _, _, _, h952) => {
                                        h952
                                    }
                                }
                            } else {
                                let m960 = {
                                    let m959 = match v0.clone() {
                                        Adt1::C0(h958, _, _, _, _, _, _) => {
                                            h958
                                        }
                                    };
                                    match m959 {
                                        Adt2::C0(_, _, _, _, _, h957, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                            h957
                                        }
                                    }
                                };
                                match m960 {
                                    None => {
                                        Str::lit("Choose input and start")
                                    }
                                    Some(_) => {
                                        let m964 = {
                                            let m963 = match v0 {
                                                Adt1::C0(h962, _, _, _, _, _, _) => {
                                                    h962
                                                }
                                            };
                                            match m963 {
                                                Adt2::C0(_, _, _, _, h961, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                    h961
                                                }
                                            }
                                        };
                                        match m964 {
                                            None => {
                                                Str::lit("Result ready")
                                            }
                                            Some(v4) => {
                                                f101(f38(v4))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Some(v2) => {
                    f100(v2)
                }
            }
        }
        Some(v1) => {
            f99(v1)
        }
    }
}

pub fn f37(v0: Adt55, v1: Adt23) -> Str {
    let m966 = match v1.clone() {
        Adt23::C0(_, _, _, _, _, h965, _, _, _, _) => {
            h965
        }
    };
    match m966 {
        Adt31::C0 => {
            Str::lit("No certificate requested")
        }
        Adt31::C1(_) => {
            Str::lit("Certificate open")
        }
        Adt31::C2(_) => {
            Str::lit("Certificate failed")
        }
        Adt31::C3(_) => {
            Str::lit("Certificate incomplete")
        }
        Adt31::C4(_) => {
            let m968 = f48(v0, v1);
            if match m968 {
                Adt78::C0(_, _, _, _, h967, _, _) => {
                    h967
                }
            } {
                Str::lit("Scoped minimum certificate checked under the displayed scope")
            } else {
                Str::lit("Certificate supplied; not established for this result")
            }
        }
    }
}

pub fn f38(v0: Adt10) -> Adt55 {
    let m969 = v0;
    match m969 {
        Adt10::C0(_) => {
            Adt55::C0
        }
        Adt10::C1(_) => {
            Adt55::C1
        }
        Adt10::C2(_) => {
            Adt55::C2
        }
        Adt10::C3(_) => {
            Adt55::C3
        }
        Adt10::C4(_) => {
            Adt55::C4
        }
        Adt10::C5(_) => {
            Adt55::C5
        }
        Adt10::C6(_) => {
            Adt55::C6
        }
        Adt10::C7(_) => {
            Adt55::C7
        }
        Adt10::C8(_) => {
            Adt55::C8
        }
        Adt10::C9(_) => {
            Adt55::C9
        }
    }
}

pub fn f39(v0: Adt55, v1: Adt23) -> Str {
    let m971 = f48(v0, v1);
    if match m971 {
        Adt78::C0(_, _, _, h970, _, _, _) => {
            h970
        }
    } {
        Str::lit("Original bytes and ordered boundaries compared equal")
    } else {
        Str::lit("Original-byte equality is not established")
    }
}

pub fn f40(v0: Adt23) -> Option<Adt32> {
    let m973 = match v0 {
        Adt23::C0(_, _, _, _, _, h972, _, _, _, _) => {
            h972
        }
    };
    match m973 {
        Adt31::C0 => {
            None::<Adt32>
        }
        Adt31::C1(v1) => {
            Some(v1)
        }
        Adt31::C2(v2) => {
            Some(v2)
        }
        Adt31::C3(v3) => {
            Some(v3)
        }
        Adt31::C4(v4) => {
            Some(v4)
        }
    }
}

pub fn f41(v0: Adt55) -> Str {
    let m974 = v0;
    match m974 {
        Adt55::C0 => {
            Str::lit("Compress")
        }
        Adt55::C1 => {
            Str::lit("Decompress")
        }
        Adt55::C2 => {
            Str::lit("Inspect")
        }
        Adt55::C3 => {
            Str::lit("Verify")
        }
        Adt55::C4 => {
            Str::lit("Resume")
        }
        Adt55::C5 => {
            Str::lit("Build basis")
        }
        Adt55::C6 => {
            Str::lit("Analyze frontier")
        }
        Adt55::C7 => {
            Str::lit("Compare")
        }
        Adt55::C8 => {
            Str::lit("Run acceptance")
        }
        Adt55::C9 => {
            Str::lit("Run core request")
        }
    }
}

pub fn f42(v0: Adt1, v1: Adt63) -> Adt62 {
    Adt62::C0(f84(match v0.clone() {
        Adt1::C0(h975, _, _, _, _, _, _) => {
            h975
        }
    }), match v0 {
        Adt1::C0(_, _, h976, _, _, _, _) => {
            h976
        }
    }, v1)
}

pub fn f43(v0: Adt54) -> Result<Adt10, Adt44> {
    let m978 = match v0.clone() {
        Adt54::C0(h977, _, _, _, _, _, _, _) => {
            h977
        }
    };
    match m978 {
        Adt55::C0 => {
            let m980 = match v0.clone() {
                Adt54::C0(_, h979, _, _, _, _, _, _) => {
                    h979
                }
            };
            match m980 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C14)
                }
                Some(v1) => {
                    Ok::<Adt10, Adt44>(Adt10::C0(Adt11::C0(v1, Adt13::C0(match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, _, h981) => {
                            h981
                        }
                    }, match v0 {
                        Adt54::C0(_, _, _, h982, _, _, _, _) => {
                            h982
                        }
                    }))))
                }
            }
        }
        Adt55::C1 => {
            let m984 = match v0.clone() {
                Adt54::C0(_, _, h983, _, _, _, _, _) => {
                    h983
                }
            };
            match m984 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C15)
                }
                Some(v2) => {
                    Ok::<Adt10, Adt44>(Adt10::C1(Adt16::C0(v2, Adt13::C0(match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, _, h985) => {
                            h985
                        }
                    }, match v0 {
                        Adt54::C0(_, _, _, h986, _, _, _, _) => {
                            h986
                        }
                    }))))
                }
            }
        }
        Adt55::C2 => {
            let m988 = match v0.clone() {
                Adt54::C0(_, _, h987, _, _, _, _, _) => {
                    h987
                }
            };
            match m988 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C15)
                }
                Some(v3) => {
                    Ok::<Adt10, Adt44>(Adt10::C2(Adt16::C0(v3, Adt13::C0(match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, _, h989) => {
                            h989
                        }
                    }, match v0 {
                        Adt54::C0(_, _, _, h990, _, _, _, _) => {
                            h990
                        }
                    }))))
                }
            }
        }
        Adt55::C3 => {
            let m992 = match v0.clone() {
                Adt54::C0(_, _, h991, _, _, _, _, _) => {
                    h991
                }
            };
            match m992 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C15)
                }
                Some(v4) => {
                    Ok::<Adt10, Adt44>(Adt10::C3(Adt17::C0(v4, match v0.clone() {
                        Adt54::C0(_, _, _, _, h993, _, _, _) => {
                            h993
                        }
                    }, None::<Adt12>, Adt13::C0(match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, _, h994) => {
                            h994
                        }
                    }, match v0 {
                        Adt54::C0(_, _, _, h995, _, _, _, _) => {
                            h995
                        }
                    }))))
                }
            }
        }
        Adt55::C4 => {
            let m997 = match v0.clone() {
                Adt54::C0(_, h996, _, _, _, _, _, _) => {
                    h996
                }
            };
            match m997 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C14)
                }
                Some(v5) => {
                    let m999 = match v0.clone() {
                        Adt54::C0(_, _, _, _, _, h998, _, _) => {
                            h998
                        }
                    };
                    match m999 {
                        None => {
                            Err::<Adt10, Adt44>(Adt44::C4)
                        }
                        Some(v6) => {
                            Ok::<Adt10, Adt44>(Adt10::C4(Adt18::C0(v5, v6, Adt13::C0(match v0.clone() {
                                Adt54::C0(_, _, _, _, _, _, _, h1000) => {
                                    h1000
                                }
                            }, match v0 {
                                Adt54::C0(_, _, _, h1001, _, _, _, _) => {
                                    h1001
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt55::C5 => {
            let m1003 = match v0.clone() {
                Adt54::C0(_, h1002, _, _, _, _, _, _) => {
                    h1002
                }
            };
            match m1003 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C14)
                }
                Some(v7) => {
                    Ok::<Adt10, Adt44>(Adt10::C5(Adt19::C0(v7, Adt13::C0(match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, _, h1004) => {
                            h1004
                        }
                    }, match v0 {
                        Adt54::C0(_, _, _, h1005, _, _, _, _) => {
                            h1005
                        }
                    }))))
                }
            }
        }
        Adt55::C6 => {
            let m1007 = match v0.clone() {
                Adt54::C0(_, h1006, _, _, _, _, _, _) => {
                    h1006
                }
            };
            match m1007 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C14)
                }
                Some(v8) => {
                    Ok::<Adt10, Adt44>(Adt10::C6(Adt20::C0(v8, match v0.clone() {
                        Adt54::C0(_, _, h1008, _, _, _, _, _) => {
                            h1008
                        }
                    }, Adt13::C0(match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, _, h1009) => {
                            h1009
                        }
                    }, match v0 {
                        Adt54::C0(_, _, _, h1010, _, _, _, _) => {
                            h1010
                        }
                    }))))
                }
            }
        }
        Adt55::C7 => {
            let m1012 = match v0.clone() {
                Adt54::C0(_, _, h1011, _, _, _, _, _) => {
                    h1011
                }
            };
            match m1012 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C15)
                }
                Some(v9) => {
                    let m1014 = match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, h1013, _) => {
                            h1013
                        }
                    };
                    match m1014 {
                        None => {
                            Err::<Adt10, Adt44>(Adt44::C16)
                        }
                        Some(v10) => {
                            Ok::<Adt10, Adt44>(Adt10::C7(Adt21::C0(v9, v10, match v0.clone() {
                                Adt54::C0(_, _, _, _, h1015, _, _, _) => {
                                    h1015
                                }
                            }, Adt13::C0(match v0.clone() {
                                Adt54::C0(_, _, _, _, _, _, _, h1016) => {
                                    h1016
                                }
                            }, match v0 {
                                Adt54::C0(_, _, _, h1017, _, _, _, _) => {
                                    h1017
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt55::C8 => {
            let m1019 = match v0.clone() {
                Adt54::C0(_, h1018, _, _, _, _, _, _) => {
                    h1018
                }
            };
            match m1019 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C14)
                }
                Some(v11) => {
                    Ok::<Adt10, Adt44>(Adt10::C8(Adt22::C0(v11, Adt13::C0(match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, _, h1020) => {
                            h1020
                        }
                    }, match v0 {
                        Adt54::C0(_, _, _, h1021, _, _, _, _) => {
                            h1021
                        }
                    }))))
                }
            }
        }
        Adt55::C9 => {
            let m1023 = match v0.clone() {
                Adt54::C0(_, h1022, _, _, _, _, _, _) => {
                    h1022
                }
            };
            match m1023 {
                None => {
                    Err::<Adt10, Adt44>(Adt44::C14)
                }
                Some(v12) => {
                    Ok::<Adt10, Adt44>(Adt10::C9(Adt22::C0(v12, Adt13::C0(match v0.clone() {
                        Adt54::C0(_, _, _, _, _, _, _, h1024) => {
                            h1024
                        }
                    }, match v0 {
                        Adt54::C0(_, _, _, h1025, _, _, _, _) => {
                            h1025
                        }
                    }))))
                }
            }
        }
    }
}

pub fn f44(v0: Adt2) -> bool {
    if match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1026, _, _, _, _, _, _, _) => {
            h1026
        }
    } {
        let a1028 = match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1027, _, _, _, _, _, _) => {
                h1027
            }
        };
        if bool_not(a1028) {
            let a1030 = match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h1029, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1029
                }
            };
            if bool_not(a1030) {
                let m1033 = match v0.clone() {
                    Adt2::C0(_, _, h1032, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1032
                    }
                };
                if match m1033 {
                    Adt6::C0(_, _, _, h1031, _) => {
                        h1031
                    }
                } {
                    let m1035 = match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, h1034, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1034
                        }
                    };
                    if match m1035 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    } {
                        let m1039 = {
                            let m1038 = match v0 {
                                Adt2::C0(_, _, h1037, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1037
                                }
                            };
                            match m1038 {
                                Adt6::C0(_, _, _, _, h1036) => {
                                    h1036
                                }
                            }
                        };
                        match m1039 {
                            Adt8::C0 => {
                                true
                            }
                            Adt8::C1 => {
                                false
                            }
                            Adt8::C2 => {
                                true
                            }
                            Adt8::C3 => {
                                false
                            }
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f45(v0: Adt1) -> R<List<Adt74>> {
    let m1043 = {
        let m1042 = match v0.clone() {
            Adt1::C0(_, h1041, _, _, _, _, _) => {
                h1041
            }
        };
        match m1042 {
            Adt54::C0(h1040, _, _, _, _, _, _, _) => {
                h1040
            }
        }
    };
    match m1043 {
        Adt55::C0 => {
            let m1047 = {
                let m1046 = match v0.clone() {
                    Adt1::C0(h1045, _, _, _, _, _, _) => {
                        h1045
                    }
                };
                match m1046 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1044, _, _, _, _, _) => {
                        h1044
                    }
                }
            };
            if if match m1047 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m1051 = {
                        let m1050 = match v0.clone() {
                            Adt1::C0(_, h1049, _, _, _, _, _) => {
                                h1049
                            }
                        };
                        match m1050 {
                            Adt54::C0(h1048, _, _, _, _, _, _, _) => {
                                h1048
                            }
                        }
                    };
                    match m1051 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m1055 = {
                        let m1054 = match v0.clone() {
                            Adt1::C0(_, h1053, _, _, _, _, _) => {
                                h1053
                            }
                        };
                        match m1054 {
                            Adt54::C0(_, h1052, _, _, _, _, _, _) => {
                                h1052
                            }
                        }
                    };
                    match m1055 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1056, _) => {
                        h1056
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1057, _) => {
                        h1057
                    }
                }, Adt56::C0))?, {
                    let a1061 = {
                        let m1059 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1058) => {
                                h1058
                            }
                        };
                        match m1059 {
                            None => {
                                false
                            }
                            Some(v2) => {
                                f105(match v2 {
                                    Adt61::C0(h1060, _, _, _, _, _) => {
                                        h1060
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1061) {
                        let m1064 = match v0.clone() {
                            Adt1::C0(h1063, _, _, _, _, _, _) => {
                                h1063
                            }
                        };
                        if match m1064 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1062, _, _, _, _, _, _, _) => {
                                h1062
                            }
                        } {
                            let a1068 = {
                                let m1067 = match v0.clone() {
                                    Adt1::C0(h1066, _, _, _, _, _, _) => {
                                        h1066
                                    }
                                };
                                match m1067 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1065, _, _, _, _, _, _) => {
                                        h1065
                                    }
                                }
                            };
                            bool_not(a1068)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1070 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1069) => {
                            h1069
                        }
                    };
                    match m1070 {
                        None => {
                            false
                        }
                        Some(v3) => {
                            f105(match v3 {
                                Adt61::C0(h1071, _, _, _, _, _) => {
                                    h1071
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a1075 = {
                        let m1073 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1072) => {
                                h1072
                            }
                        };
                        match m1073 {
                            None => {
                                false
                            }
                            Some(v4) => {
                                f105(match v4 {
                                    Adt61::C0(h1074, _, _, _, _, _) => {
                                        h1074
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1075) {
                        let m1078 = match v0.clone() {
                            Adt1::C0(h1077, _, _, _, _, _, _) => {
                                h1077
                            }
                        };
                        if match m1078 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1076, _, _, _, _, _, _, _) => {
                                h1076
                            }
                        } {
                            let a1082 = {
                                let m1081 = match v0.clone() {
                                    Adt1::C0(h1080, _, _, _, _, _, _) => {
                                        h1080
                                    }
                                };
                                match m1081 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1079, _, _, _, _, _, _) => {
                                        h1079
                                    }
                                }
                            };
                            bool_not(a1082)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m1086 = {
                        let m1085 = match v0.clone() {
                            Adt1::C0(_, h1084, _, _, _, _, _) => {
                                h1084
                            }
                        };
                        match m1085 {
                            Adt54::C0(h1083, _, _, _, _, _, _, _) => {
                                h1083
                            }
                        }
                    };
                    match m1086 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1090 = {
                        let m1089 = match v0.clone() {
                            Adt1::C0(_, h1088, _, _, _, _, _) => {
                                h1088
                            }
                        };
                        match m1089 {
                            Adt54::C0(_, _, _, h1087, _, _, _, _) => {
                                h1087
                            }
                        }
                    };
                    match m1090 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1091, _) => {
                        h1091
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1092, _) => {
                        h1092
                    }
                }, Adt56::C2))?, {
                    let a1096 = {
                        let m1094 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1093) => {
                                h1093
                            }
                        };
                        match m1094 {
                            None => {
                                false
                            }
                            Some(v6) => {
                                f105(match v6 {
                                    Adt61::C0(h1095, _, _, _, _, _) => {
                                        h1095
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1096) {
                        let m1099 = match v0.clone() {
                            Adt1::C0(h1098, _, _, _, _, _, _) => {
                                h1098
                            }
                        };
                        if match m1099 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1097, _, _, _, _, _, _, _) => {
                                h1097
                            }
                        } {
                            let a1103 = {
                                let m1102 = match v0.clone() {
                                    Adt1::C0(h1101, _, _, _, _, _, _) => {
                                        h1101
                                    }
                                };
                                match m1102 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1100, _, _, _, _, _, _) => {
                                        h1100
                                    }
                                }
                            };
                            bool_not(a1103)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1105 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1104) => {
                            h1104
                        }
                    };
                    match m1105 {
                        None => {
                            false
                        }
                        Some(v7) => {
                            f105(match v7 {
                                Adt61::C0(h1106, _, _, _, _, _) => {
                                    h1106
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a1110 = {
                        let m1108 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1107) => {
                                h1107
                            }
                        };
                        match m1108 {
                            None => {
                                false
                            }
                            Some(v8) => {
                                f105(match v8 {
                                    Adt61::C0(h1109, _, _, _, _, _) => {
                                        h1109
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1110) {
                        let m1113 = match v0.clone() {
                            Adt1::C0(h1112, _, _, _, _, _, _) => {
                                h1112
                            }
                        };
                        if match m1113 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1111, _, _, _, _, _, _, _) => {
                                h1111
                            }
                        } {
                            let a1117 = {
                                let m1116 = match v0 {
                                    Adt1::C0(h1115, _, _, _, _, _, _) => {
                                        h1115
                                    }
                                };
                                match m1116 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1114, _, _, _, _, _, _) => {
                                        h1114
                                    }
                                }
                            };
                            bool_not(a1117)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m1121 = {
                        let m1120 = match v0.clone() {
                            Adt1::C0(_, h1119, _, _, _, _, _) => {
                                h1119
                            }
                        };
                        match m1120 {
                            Adt54::C0(h1118, _, _, _, _, _, _, _) => {
                                h1118
                            }
                        }
                    };
                    match m1121 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m1125 = {
                        let m1124 = match v0.clone() {
                            Adt1::C0(_, h1123, _, _, _, _, _) => {
                                h1123
                            }
                        };
                        match m1124 {
                            Adt54::C0(_, h1122, _, _, _, _, _, _) => {
                                h1122
                            }
                        }
                    };
                    match m1125 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1126, _) => {
                        h1126
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1127, _) => {
                        h1127
                    }
                }, Adt56::C0))?, {
                    let a1131 = {
                        let m1129 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1128) => {
                                h1128
                            }
                        };
                        match m1129 {
                            None => {
                                false
                            }
                            Some(v10) => {
                                f105(match v10 {
                                    Adt61::C0(h1130, _, _, _, _, _) => {
                                        h1130
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1131) {
                        let m1134 = match v0.clone() {
                            Adt1::C0(h1133, _, _, _, _, _, _) => {
                                h1133
                            }
                        };
                        if match m1134 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1132, _, _, _, _, _, _, _) => {
                                h1132
                            }
                        } {
                            let a1138 = {
                                let m1137 = match v0.clone() {
                                    Adt1::C0(h1136, _, _, _, _, _, _) => {
                                        h1136
                                    }
                                };
                                match m1137 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1135, _, _, _, _, _, _) => {
                                        h1135
                                    }
                                }
                            };
                            bool_not(a1138)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1140 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1139) => {
                            h1139
                        }
                    };
                    match m1140 {
                        None => {
                            false
                        }
                        Some(v11) => {
                            f105(match v11 {
                                Adt61::C0(h1141, _, _, _, _, _) => {
                                    h1141
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a1145 = {
                        let m1143 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1142) => {
                                h1142
                            }
                        };
                        match m1143 {
                            None => {
                                false
                            }
                            Some(v12) => {
                                f105(match v12 {
                                    Adt61::C0(h1144, _, _, _, _, _) => {
                                        h1144
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1145) {
                        let m1148 = match v0.clone() {
                            Adt1::C0(h1147, _, _, _, _, _, _) => {
                                h1147
                            }
                        };
                        if match m1148 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1146, _, _, _, _, _, _, _) => {
                                h1146
                            }
                        } {
                            let a1152 = {
                                let m1151 = match v0 {
                                    Adt1::C0(h1150, _, _, _, _, _, _) => {
                                        h1150
                                    }
                                };
                                match m1151 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1149, _, _, _, _, _, _) => {
                                        h1149
                                    }
                                }
                            };
                            bool_not(a1152)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))
            }
        }
        Adt55::C1 => {
            let m1156 = {
                let m1155 = match v0.clone() {
                    Adt1::C0(h1154, _, _, _, _, _, _) => {
                        h1154
                    }
                };
                match m1155 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1153, _, _, _, _, _) => {
                        h1153
                    }
                }
            };
            if if match m1156 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m1160 = {
                        let m1159 = match v0.clone() {
                            Adt1::C0(_, h1158, _, _, _, _, _) => {
                                h1158
                            }
                        };
                        match m1159 {
                            Adt54::C0(h1157, _, _, _, _, _, _, _) => {
                                h1157
                            }
                        }
                    };
                    match m1160 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1164 = {
                        let m1163 = match v0.clone() {
                            Adt1::C0(_, h1162, _, _, _, _, _) => {
                                h1162
                            }
                        };
                        match m1163 {
                            Adt54::C0(_, _, h1161, _, _, _, _, _) => {
                                h1161
                            }
                        }
                    };
                    match m1164 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1165, _) => {
                        h1165
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1166, _) => {
                        h1166
                    }
                }, Adt56::C1))?, {
                    let a1170 = {
                        let m1168 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1167) => {
                                h1167
                            }
                        };
                        match m1168 {
                            None => {
                                false
                            }
                            Some(v14) => {
                                f105(match v14 {
                                    Adt61::C0(h1169, _, _, _, _, _) => {
                                        h1169
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1170) {
                        let m1173 = match v0.clone() {
                            Adt1::C0(h1172, _, _, _, _, _, _) => {
                                h1172
                            }
                        };
                        if match m1173 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1171, _, _, _, _, _, _, _) => {
                                h1171
                            }
                        } {
                            let a1177 = {
                                let m1176 = match v0.clone() {
                                    Adt1::C0(h1175, _, _, _, _, _, _) => {
                                        h1175
                                    }
                                };
                                match m1176 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1174, _, _, _, _, _, _) => {
                                        h1174
                                    }
                                }
                            };
                            bool_not(a1177)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1179 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1178) => {
                            h1178
                        }
                    };
                    match m1179 {
                        None => {
                            false
                        }
                        Some(v15) => {
                            f105(match v15 {
                                Adt61::C0(h1180, _, _, _, _, _) => {
                                    h1180
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a1184 = {
                        let m1182 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1181) => {
                                h1181
                            }
                        };
                        match m1182 {
                            None => {
                                false
                            }
                            Some(v16) => {
                                f105(match v16 {
                                    Adt61::C0(h1183, _, _, _, _, _) => {
                                        h1183
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1184) {
                        let m1187 = match v0.clone() {
                            Adt1::C0(h1186, _, _, _, _, _, _) => {
                                h1186
                            }
                        };
                        if match m1187 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1185, _, _, _, _, _, _, _) => {
                                h1185
                            }
                        } {
                            let a1191 = {
                                let m1190 = match v0.clone() {
                                    Adt1::C0(h1189, _, _, _, _, _, _) => {
                                        h1189
                                    }
                                };
                                match m1190 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1188, _, _, _, _, _, _) => {
                                        h1188
                                    }
                                }
                            };
                            bool_not(a1191)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m1195 = {
                        let m1194 = match v0.clone() {
                            Adt1::C0(_, h1193, _, _, _, _, _) => {
                                h1193
                            }
                        };
                        match m1194 {
                            Adt54::C0(h1192, _, _, _, _, _, _, _) => {
                                h1192
                            }
                        }
                    };
                    match m1195 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1199 = {
                        let m1198 = match v0.clone() {
                            Adt1::C0(_, h1197, _, _, _, _, _) => {
                                h1197
                            }
                        };
                        match m1198 {
                            Adt54::C0(_, _, _, h1196, _, _, _, _) => {
                                h1196
                            }
                        }
                    };
                    match m1199 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1200, _) => {
                        h1200
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1201, _) => {
                        h1201
                    }
                }, Adt56::C2))?, {
                    let a1205 = {
                        let m1203 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1202) => {
                                h1202
                            }
                        };
                        match m1203 {
                            None => {
                                false
                            }
                            Some(v18) => {
                                f105(match v18 {
                                    Adt61::C0(h1204, _, _, _, _, _) => {
                                        h1204
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1205) {
                        let m1208 = match v0.clone() {
                            Adt1::C0(h1207, _, _, _, _, _, _) => {
                                h1207
                            }
                        };
                        if match m1208 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1206, _, _, _, _, _, _, _) => {
                                h1206
                            }
                        } {
                            let a1212 = {
                                let m1211 = match v0.clone() {
                                    Adt1::C0(h1210, _, _, _, _, _, _) => {
                                        h1210
                                    }
                                };
                                match m1211 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1209, _, _, _, _, _, _) => {
                                        h1209
                                    }
                                }
                            };
                            bool_not(a1212)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1214 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1213) => {
                            h1213
                        }
                    };
                    match m1214 {
                        None => {
                            false
                        }
                        Some(v19) => {
                            f105(match v19 {
                                Adt61::C0(h1215, _, _, _, _, _) => {
                                    h1215
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a1219 = {
                        let m1217 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1216) => {
                                h1216
                            }
                        };
                        match m1217 {
                            None => {
                                false
                            }
                            Some(v20) => {
                                f105(match v20 {
                                    Adt61::C0(h1218, _, _, _, _, _) => {
                                        h1218
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1219) {
                        let m1222 = match v0.clone() {
                            Adt1::C0(h1221, _, _, _, _, _, _) => {
                                h1221
                            }
                        };
                        if match m1222 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1220, _, _, _, _, _, _, _) => {
                                h1220
                            }
                        } {
                            let a1226 = {
                                let m1225 = match v0 {
                                    Adt1::C0(h1224, _, _, _, _, _, _) => {
                                        h1224
                                    }
                                };
                                match m1225 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1223, _, _, _, _, _, _) => {
                                        h1223
                                    }
                                }
                            };
                            bool_not(a1226)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m1230 = {
                        let m1229 = match v0.clone() {
                            Adt1::C0(_, h1228, _, _, _, _, _) => {
                                h1228
                            }
                        };
                        match m1229 {
                            Adt54::C0(h1227, _, _, _, _, _, _, _) => {
                                h1227
                            }
                        }
                    };
                    match m1230 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1234 = {
                        let m1233 = match v0.clone() {
                            Adt1::C0(_, h1232, _, _, _, _, _) => {
                                h1232
                            }
                        };
                        match m1233 {
                            Adt54::C0(_, _, h1231, _, _, _, _, _) => {
                                h1231
                            }
                        }
                    };
                    match m1234 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1235, _) => {
                        h1235
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1236, _) => {
                        h1236
                    }
                }, Adt56::C1))?, {
                    let a1240 = {
                        let m1238 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1237) => {
                                h1237
                            }
                        };
                        match m1238 {
                            None => {
                                false
                            }
                            Some(v22) => {
                                f105(match v22 {
                                    Adt61::C0(h1239, _, _, _, _, _) => {
                                        h1239
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1240) {
                        let m1243 = match v0.clone() {
                            Adt1::C0(h1242, _, _, _, _, _, _) => {
                                h1242
                            }
                        };
                        if match m1243 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1241, _, _, _, _, _, _, _) => {
                                h1241
                            }
                        } {
                            let a1247 = {
                                let m1246 = match v0.clone() {
                                    Adt1::C0(h1245, _, _, _, _, _, _) => {
                                        h1245
                                    }
                                };
                                match m1246 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1244, _, _, _, _, _, _) => {
                                        h1244
                                    }
                                }
                            };
                            bool_not(a1247)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1249 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1248) => {
                            h1248
                        }
                    };
                    match m1249 {
                        None => {
                            false
                        }
                        Some(v23) => {
                            f105(match v23 {
                                Adt61::C0(h1250, _, _, _, _, _) => {
                                    h1250
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a1254 = {
                        let m1252 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1251) => {
                                h1251
                            }
                        };
                        match m1252 {
                            None => {
                                false
                            }
                            Some(v24) => {
                                f105(match v24 {
                                    Adt61::C0(h1253, _, _, _, _, _) => {
                                        h1253
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1254) {
                        let m1257 = match v0.clone() {
                            Adt1::C0(h1256, _, _, _, _, _, _) => {
                                h1256
                            }
                        };
                        if match m1257 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1255, _, _, _, _, _, _, _) => {
                                h1255
                            }
                        } {
                            let a1261 = {
                                let m1260 = match v0 {
                                    Adt1::C0(h1259, _, _, _, _, _, _) => {
                                        h1259
                                    }
                                };
                                match m1260 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1258, _, _, _, _, _, _) => {
                                        h1258
                                    }
                                }
                            };
                            bool_not(a1261)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))
            }
        }
        Adt55::C2 => {
            let m1265 = {
                let m1264 = match v0.clone() {
                    Adt1::C0(h1263, _, _, _, _, _, _) => {
                        h1263
                    }
                };
                match m1264 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1262, _, _, _, _, _) => {
                        h1262
                    }
                }
            };
            if if match m1265 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m1269 = {
                        let m1268 = match v0.clone() {
                            Adt1::C0(_, h1267, _, _, _, _, _) => {
                                h1267
                            }
                        };
                        match m1268 {
                            Adt54::C0(h1266, _, _, _, _, _, _, _) => {
                                h1266
                            }
                        }
                    };
                    match m1269 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1273 = {
                        let m1272 = match v0.clone() {
                            Adt1::C0(_, h1271, _, _, _, _, _) => {
                                h1271
                            }
                        };
                        match m1272 {
                            Adt54::C0(_, _, h1270, _, _, _, _, _) => {
                                h1270
                            }
                        }
                    };
                    match m1273 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1274, _) => {
                        h1274
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1275, _) => {
                        h1275
                    }
                }, Adt56::C1))?, {
                    let a1279 = {
                        let m1277 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1276) => {
                                h1276
                            }
                        };
                        match m1277 {
                            None => {
                                false
                            }
                            Some(v26) => {
                                f105(match v26 {
                                    Adt61::C0(h1278, _, _, _, _, _) => {
                                        h1278
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1279) {
                        let m1282 = match v0.clone() {
                            Adt1::C0(h1281, _, _, _, _, _, _) => {
                                h1281
                            }
                        };
                        if match m1282 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1280, _, _, _, _, _, _, _) => {
                                h1280
                            }
                        } {
                            let a1286 = {
                                let m1285 = match v0.clone() {
                                    Adt1::C0(h1284, _, _, _, _, _, _) => {
                                        h1284
                                    }
                                };
                                match m1285 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1283, _, _, _, _, _, _) => {
                                        h1283
                                    }
                                }
                            };
                            bool_not(a1286)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1288 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1287) => {
                            h1287
                        }
                    };
                    match m1288 {
                        None => {
                            false
                        }
                        Some(v27) => {
                            f105(match v27 {
                                Adt61::C0(h1289, _, _, _, _, _) => {
                                    h1289
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a1293 = {
                        let m1291 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1290) => {
                                h1290
                            }
                        };
                        match m1291 {
                            None => {
                                false
                            }
                            Some(v28) => {
                                f105(match v28 {
                                    Adt61::C0(h1292, _, _, _, _, _) => {
                                        h1292
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1293) {
                        let m1296 = match v0.clone() {
                            Adt1::C0(h1295, _, _, _, _, _, _) => {
                                h1295
                            }
                        };
                        if match m1296 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1294, _, _, _, _, _, _, _) => {
                                h1294
                            }
                        } {
                            let a1300 = {
                                let m1299 = match v0.clone() {
                                    Adt1::C0(h1298, _, _, _, _, _, _) => {
                                        h1298
                                    }
                                };
                                match m1299 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1297, _, _, _, _, _, _) => {
                                        h1297
                                    }
                                }
                            };
                            bool_not(a1300)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m1304 = {
                        let m1303 = match v0.clone() {
                            Adt1::C0(_, h1302, _, _, _, _, _) => {
                                h1302
                            }
                        };
                        match m1303 {
                            Adt54::C0(h1301, _, _, _, _, _, _, _) => {
                                h1301
                            }
                        }
                    };
                    match m1304 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1308 = {
                        let m1307 = match v0.clone() {
                            Adt1::C0(_, h1306, _, _, _, _, _) => {
                                h1306
                            }
                        };
                        match m1307 {
                            Adt54::C0(_, _, _, h1305, _, _, _, _) => {
                                h1305
                            }
                        }
                    };
                    match m1308 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1309, _) => {
                        h1309
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1310, _) => {
                        h1310
                    }
                }, Adt56::C2))?, {
                    let a1314 = {
                        let m1312 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1311) => {
                                h1311
                            }
                        };
                        match m1312 {
                            None => {
                                false
                            }
                            Some(v30) => {
                                f105(match v30 {
                                    Adt61::C0(h1313, _, _, _, _, _) => {
                                        h1313
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1314) {
                        let m1317 = match v0.clone() {
                            Adt1::C0(h1316, _, _, _, _, _, _) => {
                                h1316
                            }
                        };
                        if match m1317 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1315, _, _, _, _, _, _, _) => {
                                h1315
                            }
                        } {
                            let a1321 = {
                                let m1320 = match v0.clone() {
                                    Adt1::C0(h1319, _, _, _, _, _, _) => {
                                        h1319
                                    }
                                };
                                match m1320 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1318, _, _, _, _, _, _) => {
                                        h1318
                                    }
                                }
                            };
                            bool_not(a1321)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1323 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1322) => {
                            h1322
                        }
                    };
                    match m1323 {
                        None => {
                            false
                        }
                        Some(v31) => {
                            f105(match v31 {
                                Adt61::C0(h1324, _, _, _, _, _) => {
                                    h1324
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a1328 = {
                        let m1326 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1325) => {
                                h1325
                            }
                        };
                        match m1326 {
                            None => {
                                false
                            }
                            Some(v32) => {
                                f105(match v32 {
                                    Adt61::C0(h1327, _, _, _, _, _) => {
                                        h1327
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1328) {
                        let m1331 = match v0.clone() {
                            Adt1::C0(h1330, _, _, _, _, _, _) => {
                                h1330
                            }
                        };
                        if match m1331 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1329, _, _, _, _, _, _, _) => {
                                h1329
                            }
                        } {
                            let a1335 = {
                                let m1334 = match v0 {
                                    Adt1::C0(h1333, _, _, _, _, _, _) => {
                                        h1333
                                    }
                                };
                                match m1334 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1332, _, _, _, _, _, _) => {
                                        h1332
                                    }
                                }
                            };
                            bool_not(a1335)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m1339 = {
                        let m1338 = match v0.clone() {
                            Adt1::C0(_, h1337, _, _, _, _, _) => {
                                h1337
                            }
                        };
                        match m1338 {
                            Adt54::C0(h1336, _, _, _, _, _, _, _) => {
                                h1336
                            }
                        }
                    };
                    match m1339 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1343 = {
                        let m1342 = match v0.clone() {
                            Adt1::C0(_, h1341, _, _, _, _, _) => {
                                h1341
                            }
                        };
                        match m1342 {
                            Adt54::C0(_, _, h1340, _, _, _, _, _) => {
                                h1340
                            }
                        }
                    };
                    match m1343 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1344, _) => {
                        h1344
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1345, _) => {
                        h1345
                    }
                }, Adt56::C1))?, {
                    let a1349 = {
                        let m1347 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1346) => {
                                h1346
                            }
                        };
                        match m1347 {
                            None => {
                                false
                            }
                            Some(v34) => {
                                f105(match v34 {
                                    Adt61::C0(h1348, _, _, _, _, _) => {
                                        h1348
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1349) {
                        let m1352 = match v0.clone() {
                            Adt1::C0(h1351, _, _, _, _, _, _) => {
                                h1351
                            }
                        };
                        if match m1352 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1350, _, _, _, _, _, _, _) => {
                                h1350
                            }
                        } {
                            let a1356 = {
                                let m1355 = match v0.clone() {
                                    Adt1::C0(h1354, _, _, _, _, _, _) => {
                                        h1354
                                    }
                                };
                                match m1355 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1353, _, _, _, _, _, _) => {
                                        h1353
                                    }
                                }
                            };
                            bool_not(a1356)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1358 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1357) => {
                            h1357
                        }
                    };
                    match m1358 {
                        None => {
                            false
                        }
                        Some(v35) => {
                            f105(match v35 {
                                Adt61::C0(h1359, _, _, _, _, _) => {
                                    h1359
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a1363 = {
                        let m1361 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1360) => {
                                h1360
                            }
                        };
                        match m1361 {
                            None => {
                                false
                            }
                            Some(v36) => {
                                f105(match v36 {
                                    Adt61::C0(h1362, _, _, _, _, _) => {
                                        h1362
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1363) {
                        let m1366 = match v0.clone() {
                            Adt1::C0(h1365, _, _, _, _, _, _) => {
                                h1365
                            }
                        };
                        if match m1366 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1364, _, _, _, _, _, _, _) => {
                                h1364
                            }
                        } {
                            let a1370 = {
                                let m1369 = match v0 {
                                    Adt1::C0(h1368, _, _, _, _, _, _) => {
                                        h1368
                                    }
                                };
                                match m1369 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1367, _, _, _, _, _, _) => {
                                        h1367
                                    }
                                }
                            };
                            bool_not(a1370)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))
            }
        }
        Adt55::C3 => {
            let m1374 = {
                let m1373 = match v0.clone() {
                    Adt1::C0(h1372, _, _, _, _, _, _) => {
                        h1372
                    }
                };
                match m1373 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1371, _, _, _, _, _) => {
                        h1371
                    }
                }
            };
            if if match m1374 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m1378 = {
                        let m1377 = match v0.clone() {
                            Adt1::C0(_, h1376, _, _, _, _, _) => {
                                h1376
                            }
                        };
                        match m1377 {
                            Adt54::C0(h1375, _, _, _, _, _, _, _) => {
                                h1375
                            }
                        }
                    };
                    match m1378 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1382 = {
                        let m1381 = match v0.clone() {
                            Adt1::C0(_, h1380, _, _, _, _, _) => {
                                h1380
                            }
                        };
                        match m1381 {
                            Adt54::C0(_, _, h1379, _, _, _, _, _) => {
                                h1379
                            }
                        }
                    };
                    match m1382 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1383, _) => {
                        h1383
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1384, _) => {
                        h1384
                    }
                }, Adt56::C1))?, {
                    let a1388 = {
                        let m1386 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1385) => {
                                h1385
                            }
                        };
                        match m1386 {
                            None => {
                                false
                            }
                            Some(v38) => {
                                f105(match v38 {
                                    Adt61::C0(h1387, _, _, _, _, _) => {
                                        h1387
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1388) {
                        let m1391 = match v0.clone() {
                            Adt1::C0(h1390, _, _, _, _, _, _) => {
                                h1390
                            }
                        };
                        if match m1391 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1389, _, _, _, _, _, _, _) => {
                                h1389
                            }
                        } {
                            let a1395 = {
                                let m1394 = match v0.clone() {
                                    Adt1::C0(h1393, _, _, _, _, _, _) => {
                                        h1393
                                    }
                                };
                                match m1394 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1392, _, _, _, _, _, _) => {
                                        h1392
                                    }
                                }
                            };
                            bool_not(a1395)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1397 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1396) => {
                            h1396
                        }
                    };
                    match m1397 {
                        None => {
                            false
                        }
                        Some(v39) => {
                            f105(match v39 {
                                Adt61::C0(h1398, _, _, _, _, _) => {
                                    h1398
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a1402 = {
                        let m1400 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1399) => {
                                h1399
                            }
                        };
                        match m1400 {
                            None => {
                                false
                            }
                            Some(v40) => {
                                f105(match v40 {
                                    Adt61::C0(h1401, _, _, _, _, _) => {
                                        h1401
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1402) {
                        let m1405 = match v0.clone() {
                            Adt1::C0(h1404, _, _, _, _, _, _) => {
                                h1404
                            }
                        };
                        if match m1405 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1403, _, _, _, _, _, _, _) => {
                                h1403
                            }
                        } {
                            let a1409 = {
                                let m1408 = match v0.clone() {
                                    Adt1::C0(h1407, _, _, _, _, _, _) => {
                                        h1407
                                    }
                                };
                                match m1408 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1406, _, _, _, _, _, _) => {
                                        h1406
                                    }
                                }
                            };
                            bool_not(a1409)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C3, Str::lit("Original objects for byte comparison (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C3)), true, {
                    let m1413 = {
                        let m1412 = match v0.clone() {
                            Adt1::C0(_, h1411, _, _, _, _, _) => {
                                h1411
                            }
                        };
                        match m1412 {
                            Adt54::C0(h1410, _, _, _, _, _, _, _) => {
                                h1410
                            }
                        }
                    };
                    match m1413 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1417 = {
                        let m1416 = match v0.clone() {
                            Adt1::C0(_, h1415, _, _, _, _, _) => {
                                h1415
                            }
                        };
                        match m1416 {
                            Adt54::C0(_, _, _, _, h1414, _, _, _) => {
                                h1414
                            }
                        }
                    };
                    match m1417 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C3), f103(v0.clone(), Adt56::C3, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1418, _) => {
                        h1418
                    }
                }, Adt56::C3), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1419, _) => {
                        h1419
                    }
                }, Adt56::C3))?, {
                    let a1423 = {
                        let m1421 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1420) => {
                                h1420
                            }
                        };
                        match m1421 {
                            None => {
                                false
                            }
                            Some(v42) => {
                                f105(match v42 {
                                    Adt61::C0(h1422, _, _, _, _, _) => {
                                        h1422
                                    }
                                }, Adt56::C3)
                            }
                        }
                    };
                    if bool_not(a1423) {
                        let m1426 = match v0.clone() {
                            Adt1::C0(h1425, _, _, _, _, _, _) => {
                                h1425
                            }
                        };
                        if match m1426 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1424, _, _, _, _, _, _, _) => {
                                h1424
                            }
                        } {
                            let a1430 = {
                                let m1429 = match v0.clone() {
                                    Adt1::C0(h1428, _, _, _, _, _, _) => {
                                        h1428
                                    }
                                };
                                match m1429 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1427, _, _, _, _, _, _) => {
                                        h1427
                                    }
                                }
                            };
                            bool_not(a1430)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1432 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1431) => {
                            h1431
                        }
                    };
                    match m1432 {
                        None => {
                            false
                        }
                        Some(v43) => {
                            f105(match v43 {
                                Adt61::C0(h1433, _, _, _, _, _) => {
                                    h1433
                                }
                            }, Adt56::C3)
                        }
                    }
                }, {
                    let a1437 = {
                        let m1435 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1434) => {
                                h1434
                            }
                        };
                        match m1435 {
                            None => {
                                false
                            }
                            Some(v44) => {
                                f105(match v44 {
                                    Adt61::C0(h1436, _, _, _, _, _) => {
                                        h1436
                                    }
                                }, Adt56::C3)
                            }
                        }
                    };
                    if bool_not(a1437) {
                        let m1440 = match v0.clone() {
                            Adt1::C0(h1439, _, _, _, _, _, _) => {
                                h1439
                            }
                        };
                        if match m1440 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1438, _, _, _, _, _, _, _) => {
                                h1438
                            }
                        } {
                            let a1444 = {
                                let m1443 = match v0.clone() {
                                    Adt1::C0(h1442, _, _, _, _, _, _) => {
                                        h1442
                                    }
                                };
                                match m1443 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1441, _, _, _, _, _, _) => {
                                        h1441
                                    }
                                }
                            };
                            bool_not(a1444)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m1448 = {
                        let m1447 = match v0.clone() {
                            Adt1::C0(_, h1446, _, _, _, _, _) => {
                                h1446
                            }
                        };
                        match m1447 {
                            Adt54::C0(h1445, _, _, _, _, _, _, _) => {
                                h1445
                            }
                        }
                    };
                    match m1448 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1452 = {
                        let m1451 = match v0.clone() {
                            Adt1::C0(_, h1450, _, _, _, _, _) => {
                                h1450
                            }
                        };
                        match m1451 {
                            Adt54::C0(_, _, _, h1449, _, _, _, _) => {
                                h1449
                            }
                        }
                    };
                    match m1452 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1453, _) => {
                        h1453
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1454, _) => {
                        h1454
                    }
                }, Adt56::C2))?, {
                    let a1458 = {
                        let m1456 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1455) => {
                                h1455
                            }
                        };
                        match m1456 {
                            None => {
                                false
                            }
                            Some(v46) => {
                                f105(match v46 {
                                    Adt61::C0(h1457, _, _, _, _, _) => {
                                        h1457
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1458) {
                        let m1461 = match v0.clone() {
                            Adt1::C0(h1460, _, _, _, _, _, _) => {
                                h1460
                            }
                        };
                        if match m1461 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1459, _, _, _, _, _, _, _) => {
                                h1459
                            }
                        } {
                            let a1465 = {
                                let m1464 = match v0.clone() {
                                    Adt1::C0(h1463, _, _, _, _, _, _) => {
                                        h1463
                                    }
                                };
                                match m1464 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1462, _, _, _, _, _, _) => {
                                        h1462
                                    }
                                }
                            };
                            bool_not(a1465)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1467 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1466) => {
                            h1466
                        }
                    };
                    match m1467 {
                        None => {
                            false
                        }
                        Some(v47) => {
                            f105(match v47 {
                                Adt61::C0(h1468, _, _, _, _, _) => {
                                    h1468
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a1472 = {
                        let m1470 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1469) => {
                                h1469
                            }
                        };
                        match m1470 {
                            None => {
                                false
                            }
                            Some(v48) => {
                                f105(match v48 {
                                    Adt61::C0(h1471, _, _, _, _, _) => {
                                        h1471
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1472) {
                        let m1475 = match v0.clone() {
                            Adt1::C0(h1474, _, _, _, _, _, _) => {
                                h1474
                            }
                        };
                        if match m1475 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1473, _, _, _, _, _, _, _) => {
                                h1473
                            }
                        } {
                            let a1479 = {
                                let m1478 = match v0 {
                                    Adt1::C0(h1477, _, _, _, _, _, _) => {
                                        h1477
                                    }
                                };
                                match m1478 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1476, _, _, _, _, _, _) => {
                                        h1476
                                    }
                                }
                            };
                            bool_not(a1479)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m1483 = {
                        let m1482 = match v0.clone() {
                            Adt1::C0(_, h1481, _, _, _, _, _) => {
                                h1481
                            }
                        };
                        match m1482 {
                            Adt54::C0(h1480, _, _, _, _, _, _, _) => {
                                h1480
                            }
                        }
                    };
                    match m1483 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1487 = {
                        let m1486 = match v0.clone() {
                            Adt1::C0(_, h1485, _, _, _, _, _) => {
                                h1485
                            }
                        };
                        match m1486 {
                            Adt54::C0(_, _, h1484, _, _, _, _, _) => {
                                h1484
                            }
                        }
                    };
                    match m1487 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1488, _) => {
                        h1488
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1489, _) => {
                        h1489
                    }
                }, Adt56::C1))?, {
                    let a1493 = {
                        let m1491 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1490) => {
                                h1490
                            }
                        };
                        match m1491 {
                            None => {
                                false
                            }
                            Some(v50) => {
                                f105(match v50 {
                                    Adt61::C0(h1492, _, _, _, _, _) => {
                                        h1492
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1493) {
                        let m1496 = match v0.clone() {
                            Adt1::C0(h1495, _, _, _, _, _, _) => {
                                h1495
                            }
                        };
                        if match m1496 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1494, _, _, _, _, _, _, _) => {
                                h1494
                            }
                        } {
                            let a1500 = {
                                let m1499 = match v0.clone() {
                                    Adt1::C0(h1498, _, _, _, _, _, _) => {
                                        h1498
                                    }
                                };
                                match m1499 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1497, _, _, _, _, _, _) => {
                                        h1497
                                    }
                                }
                            };
                            bool_not(a1500)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1502 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1501) => {
                            h1501
                        }
                    };
                    match m1502 {
                        None => {
                            false
                        }
                        Some(v51) => {
                            f105(match v51 {
                                Adt61::C0(h1503, _, _, _, _, _) => {
                                    h1503
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a1507 = {
                        let m1505 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1504) => {
                                h1504
                            }
                        };
                        match m1505 {
                            None => {
                                false
                            }
                            Some(v52) => {
                                f105(match v52 {
                                    Adt61::C0(h1506, _, _, _, _, _) => {
                                        h1506
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1507) {
                        let m1510 = match v0.clone() {
                            Adt1::C0(h1509, _, _, _, _, _, _) => {
                                h1509
                            }
                        };
                        if match m1510 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1508, _, _, _, _, _, _, _) => {
                                h1508
                            }
                        } {
                            let a1514 = {
                                let m1513 = match v0.clone() {
                                    Adt1::C0(h1512, _, _, _, _, _, _) => {
                                        h1512
                                    }
                                };
                                match m1513 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1511, _, _, _, _, _, _) => {
                                        h1511
                                    }
                                }
                            };
                            bool_not(a1514)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C3, Str::lit("Original objects for byte comparison (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C3)), true, {
                    let m1518 = {
                        let m1517 = match v0.clone() {
                            Adt1::C0(_, h1516, _, _, _, _, _) => {
                                h1516
                            }
                        };
                        match m1517 {
                            Adt54::C0(h1515, _, _, _, _, _, _, _) => {
                                h1515
                            }
                        }
                    };
                    match m1518 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1522 = {
                        let m1521 = match v0.clone() {
                            Adt1::C0(_, h1520, _, _, _, _, _) => {
                                h1520
                            }
                        };
                        match m1521 {
                            Adt54::C0(_, _, _, _, h1519, _, _, _) => {
                                h1519
                            }
                        }
                    };
                    match m1522 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C3), f103(v0.clone(), Adt56::C3, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1523, _) => {
                        h1523
                    }
                }, Adt56::C3), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1524, _) => {
                        h1524
                    }
                }, Adt56::C3))?, {
                    let a1528 = {
                        let m1526 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1525) => {
                                h1525
                            }
                        };
                        match m1526 {
                            None => {
                                false
                            }
                            Some(v54) => {
                                f105(match v54 {
                                    Adt61::C0(h1527, _, _, _, _, _) => {
                                        h1527
                                    }
                                }, Adt56::C3)
                            }
                        }
                    };
                    if bool_not(a1528) {
                        let m1531 = match v0.clone() {
                            Adt1::C0(h1530, _, _, _, _, _, _) => {
                                h1530
                            }
                        };
                        if match m1531 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1529, _, _, _, _, _, _, _) => {
                                h1529
                            }
                        } {
                            let a1535 = {
                                let m1534 = match v0.clone() {
                                    Adt1::C0(h1533, _, _, _, _, _, _) => {
                                        h1533
                                    }
                                };
                                match m1534 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1532, _, _, _, _, _, _) => {
                                        h1532
                                    }
                                }
                            };
                            bool_not(a1535)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1537 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1536) => {
                            h1536
                        }
                    };
                    match m1537 {
                        None => {
                            false
                        }
                        Some(v55) => {
                            f105(match v55 {
                                Adt61::C0(h1538, _, _, _, _, _) => {
                                    h1538
                                }
                            }, Adt56::C3)
                        }
                    }
                }, {
                    let a1542 = {
                        let m1540 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1539) => {
                                h1539
                            }
                        };
                        match m1540 {
                            None => {
                                false
                            }
                            Some(v56) => {
                                f105(match v56 {
                                    Adt61::C0(h1541, _, _, _, _, _) => {
                                        h1541
                                    }
                                }, Adt56::C3)
                            }
                        }
                    };
                    if bool_not(a1542) {
                        let m1545 = match v0.clone() {
                            Adt1::C0(h1544, _, _, _, _, _, _) => {
                                h1544
                            }
                        };
                        if match m1545 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1543, _, _, _, _, _, _, _) => {
                                h1543
                            }
                        } {
                            let a1549 = {
                                let m1548 = match v0 {
                                    Adt1::C0(h1547, _, _, _, _, _, _) => {
                                        h1547
                                    }
                                };
                                match m1548 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1546, _, _, _, _, _, _) => {
                                        h1546
                                    }
                                }
                            };
                            bool_not(a1549)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            }
        }
        Adt55::C4 => {
            let m1553 = {
                let m1552 = match v0.clone() {
                    Adt1::C0(h1551, _, _, _, _, _, _) => {
                        h1551
                    }
                };
                match m1552 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1550, _, _, _, _, _) => {
                        h1550
                    }
                }
            };
            if if match m1553 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m1557 = {
                        let m1556 = match v0.clone() {
                            Adt1::C0(_, h1555, _, _, _, _, _) => {
                                h1555
                            }
                        };
                        match m1556 {
                            Adt54::C0(h1554, _, _, _, _, _, _, _) => {
                                h1554
                            }
                        }
                    };
                    match m1557 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m1561 = {
                        let m1560 = match v0.clone() {
                            Adt1::C0(_, h1559, _, _, _, _, _) => {
                                h1559
                            }
                        };
                        match m1560 {
                            Adt54::C0(_, h1558, _, _, _, _, _, _) => {
                                h1558
                            }
                        }
                    };
                    match m1561 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1562, _) => {
                        h1562
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1563, _) => {
                        h1563
                    }
                }, Adt56::C0))?, {
                    let a1567 = {
                        let m1565 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1564) => {
                                h1564
                            }
                        };
                        match m1565 {
                            None => {
                                false
                            }
                            Some(v58) => {
                                f105(match v58 {
                                    Adt61::C0(h1566, _, _, _, _, _) => {
                                        h1566
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1567) {
                        let m1570 = match v0.clone() {
                            Adt1::C0(h1569, _, _, _, _, _, _) => {
                                h1569
                            }
                        };
                        if match m1570 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1568, _, _, _, _, _, _, _) => {
                                h1568
                            }
                        } {
                            let a1574 = {
                                let m1573 = match v0.clone() {
                                    Adt1::C0(h1572, _, _, _, _, _, _) => {
                                        h1572
                                    }
                                };
                                match m1573 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1571, _, _, _, _, _, _) => {
                                        h1571
                                    }
                                }
                            };
                            bool_not(a1574)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1576 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1575) => {
                            h1575
                        }
                    };
                    match m1576 {
                        None => {
                            false
                        }
                        Some(v59) => {
                            f105(match v59 {
                                Adt61::C0(h1577, _, _, _, _, _) => {
                                    h1577
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a1581 = {
                        let m1579 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1578) => {
                                h1578
                            }
                        };
                        match m1579 {
                            None => {
                                false
                            }
                            Some(v60) => {
                                f105(match v60 {
                                    Adt61::C0(h1580, _, _, _, _, _) => {
                                        h1580
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1581) {
                        let m1584 = match v0.clone() {
                            Adt1::C0(h1583, _, _, _, _, _, _) => {
                                h1583
                            }
                        };
                        if match m1584 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1582, _, _, _, _, _, _, _) => {
                                h1582
                            }
                        } {
                            let a1588 = {
                                let m1587 = match v0.clone() {
                                    Adt1::C0(h1586, _, _, _, _, _, _) => {
                                        h1586
                                    }
                                };
                                match m1587 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1585, _, _, _, _, _, _) => {
                                        h1585
                                    }
                                }
                            };
                            bool_not(a1588)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C4, Str::lit("Checkpoint"), f42(v0.clone(), Adt63::C1(Adt56::C4)), false, {
                    let m1592 = {
                        let m1591 = match v0.clone() {
                            Adt1::C0(_, h1590, _, _, _, _, _) => {
                                h1590
                            }
                        };
                        match m1591 {
                            Adt54::C0(h1589, _, _, _, _, _, _, _) => {
                                h1589
                            }
                        }
                    };
                    match m1592 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1596 = {
                        let m1595 = match v0.clone() {
                            Adt1::C0(_, h1594, _, _, _, _, _) => {
                                h1594
                            }
                        };
                        match m1595 {
                            Adt54::C0(_, _, _, _, _, h1593, _, _) => {
                                h1593
                            }
                        }
                    };
                    match m1596 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C4), f103(v0.clone(), Adt56::C4, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1597, _) => {
                        h1597
                    }
                }, Adt56::C4), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1598, _) => {
                        h1598
                    }
                }, Adt56::C4))?, {
                    let a1602 = {
                        let m1600 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1599) => {
                                h1599
                            }
                        };
                        match m1600 {
                            None => {
                                false
                            }
                            Some(v62) => {
                                f105(match v62 {
                                    Adt61::C0(h1601, _, _, _, _, _) => {
                                        h1601
                                    }
                                }, Adt56::C4)
                            }
                        }
                    };
                    if bool_not(a1602) {
                        let m1605 = match v0.clone() {
                            Adt1::C0(h1604, _, _, _, _, _, _) => {
                                h1604
                            }
                        };
                        if match m1605 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1603, _, _, _, _, _, _, _) => {
                                h1603
                            }
                        } {
                            let a1609 = {
                                let m1608 = match v0.clone() {
                                    Adt1::C0(h1607, _, _, _, _, _, _) => {
                                        h1607
                                    }
                                };
                                match m1608 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1606, _, _, _, _, _, _) => {
                                        h1606
                                    }
                                }
                            };
                            bool_not(a1609)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1611 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1610) => {
                            h1610
                        }
                    };
                    match m1611 {
                        None => {
                            false
                        }
                        Some(v63) => {
                            f105(match v63 {
                                Adt61::C0(h1612, _, _, _, _, _) => {
                                    h1612
                                }
                            }, Adt56::C4)
                        }
                    }
                }, {
                    let a1616 = {
                        let m1614 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1613) => {
                                h1613
                            }
                        };
                        match m1614 {
                            None => {
                                false
                            }
                            Some(v64) => {
                                f105(match v64 {
                                    Adt61::C0(h1615, _, _, _, _, _) => {
                                        h1615
                                    }
                                }, Adt56::C4)
                            }
                        }
                    };
                    if bool_not(a1616) {
                        let m1619 = match v0.clone() {
                            Adt1::C0(h1618, _, _, _, _, _, _) => {
                                h1618
                            }
                        };
                        if match m1619 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1617, _, _, _, _, _, _, _) => {
                                h1617
                            }
                        } {
                            let a1623 = {
                                let m1622 = match v0.clone() {
                                    Adt1::C0(h1621, _, _, _, _, _, _) => {
                                        h1621
                                    }
                                };
                                match m1622 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1620, _, _, _, _, _, _) => {
                                        h1620
                                    }
                                }
                            };
                            bool_not(a1623)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m1627 = {
                        let m1626 = match v0.clone() {
                            Adt1::C0(_, h1625, _, _, _, _, _) => {
                                h1625
                            }
                        };
                        match m1626 {
                            Adt54::C0(h1624, _, _, _, _, _, _, _) => {
                                h1624
                            }
                        }
                    };
                    match m1627 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1631 = {
                        let m1630 = match v0.clone() {
                            Adt1::C0(_, h1629, _, _, _, _, _) => {
                                h1629
                            }
                        };
                        match m1630 {
                            Adt54::C0(_, _, _, h1628, _, _, _, _) => {
                                h1628
                            }
                        }
                    };
                    match m1631 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1632, _) => {
                        h1632
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1633, _) => {
                        h1633
                    }
                }, Adt56::C2))?, {
                    let a1637 = {
                        let m1635 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1634) => {
                                h1634
                            }
                        };
                        match m1635 {
                            None => {
                                false
                            }
                            Some(v66) => {
                                f105(match v66 {
                                    Adt61::C0(h1636, _, _, _, _, _) => {
                                        h1636
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1637) {
                        let m1640 = match v0.clone() {
                            Adt1::C0(h1639, _, _, _, _, _, _) => {
                                h1639
                            }
                        };
                        if match m1640 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1638, _, _, _, _, _, _, _) => {
                                h1638
                            }
                        } {
                            let a1644 = {
                                let m1643 = match v0.clone() {
                                    Adt1::C0(h1642, _, _, _, _, _, _) => {
                                        h1642
                                    }
                                };
                                match m1643 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1641, _, _, _, _, _, _) => {
                                        h1641
                                    }
                                }
                            };
                            bool_not(a1644)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1646 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1645) => {
                            h1645
                        }
                    };
                    match m1646 {
                        None => {
                            false
                        }
                        Some(v67) => {
                            f105(match v67 {
                                Adt61::C0(h1647, _, _, _, _, _) => {
                                    h1647
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a1651 = {
                        let m1649 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1648) => {
                                h1648
                            }
                        };
                        match m1649 {
                            None => {
                                false
                            }
                            Some(v68) => {
                                f105(match v68 {
                                    Adt61::C0(h1650, _, _, _, _, _) => {
                                        h1650
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1651) {
                        let m1654 = match v0.clone() {
                            Adt1::C0(h1653, _, _, _, _, _, _) => {
                                h1653
                            }
                        };
                        if match m1654 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1652, _, _, _, _, _, _, _) => {
                                h1652
                            }
                        } {
                            let a1658 = {
                                let m1657 = match v0 {
                                    Adt1::C0(h1656, _, _, _, _, _, _) => {
                                        h1656
                                    }
                                };
                                match m1657 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1655, _, _, _, _, _, _) => {
                                        h1655
                                    }
                                }
                            };
                            bool_not(a1658)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m1662 = {
                        let m1661 = match v0.clone() {
                            Adt1::C0(_, h1660, _, _, _, _, _) => {
                                h1660
                            }
                        };
                        match m1661 {
                            Adt54::C0(h1659, _, _, _, _, _, _, _) => {
                                h1659
                            }
                        }
                    };
                    match m1662 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m1666 = {
                        let m1665 = match v0.clone() {
                            Adt1::C0(_, h1664, _, _, _, _, _) => {
                                h1664
                            }
                        };
                        match m1665 {
                            Adt54::C0(_, h1663, _, _, _, _, _, _) => {
                                h1663
                            }
                        }
                    };
                    match m1666 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1667, _) => {
                        h1667
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1668, _) => {
                        h1668
                    }
                }, Adt56::C0))?, {
                    let a1672 = {
                        let m1670 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1669) => {
                                h1669
                            }
                        };
                        match m1670 {
                            None => {
                                false
                            }
                            Some(v70) => {
                                f105(match v70 {
                                    Adt61::C0(h1671, _, _, _, _, _) => {
                                        h1671
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1672) {
                        let m1675 = match v0.clone() {
                            Adt1::C0(h1674, _, _, _, _, _, _) => {
                                h1674
                            }
                        };
                        if match m1675 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1673, _, _, _, _, _, _, _) => {
                                h1673
                            }
                        } {
                            let a1679 = {
                                let m1678 = match v0.clone() {
                                    Adt1::C0(h1677, _, _, _, _, _, _) => {
                                        h1677
                                    }
                                };
                                match m1678 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1676, _, _, _, _, _, _) => {
                                        h1676
                                    }
                                }
                            };
                            bool_not(a1679)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1681 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1680) => {
                            h1680
                        }
                    };
                    match m1681 {
                        None => {
                            false
                        }
                        Some(v71) => {
                            f105(match v71 {
                                Adt61::C0(h1682, _, _, _, _, _) => {
                                    h1682
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a1686 = {
                        let m1684 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1683) => {
                                h1683
                            }
                        };
                        match m1684 {
                            None => {
                                false
                            }
                            Some(v72) => {
                                f105(match v72 {
                                    Adt61::C0(h1685, _, _, _, _, _) => {
                                        h1685
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1686) {
                        let m1689 = match v0.clone() {
                            Adt1::C0(h1688, _, _, _, _, _, _) => {
                                h1688
                            }
                        };
                        if match m1689 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1687, _, _, _, _, _, _, _) => {
                                h1687
                            }
                        } {
                            let a1693 = {
                                let m1692 = match v0.clone() {
                                    Adt1::C0(h1691, _, _, _, _, _, _) => {
                                        h1691
                                    }
                                };
                                match m1692 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1690, _, _, _, _, _, _) => {
                                        h1690
                                    }
                                }
                            };
                            bool_not(a1693)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C4, Str::lit("Checkpoint"), f42(v0.clone(), Adt63::C1(Adt56::C4)), false, {
                    let m1697 = {
                        let m1696 = match v0.clone() {
                            Adt1::C0(_, h1695, _, _, _, _, _) => {
                                h1695
                            }
                        };
                        match m1696 {
                            Adt54::C0(h1694, _, _, _, _, _, _, _) => {
                                h1694
                            }
                        }
                    };
                    match m1697 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1701 = {
                        let m1700 = match v0.clone() {
                            Adt1::C0(_, h1699, _, _, _, _, _) => {
                                h1699
                            }
                        };
                        match m1700 {
                            Adt54::C0(_, _, _, _, _, h1698, _, _) => {
                                h1698
                            }
                        }
                    };
                    match m1701 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C4), f103(v0.clone(), Adt56::C4, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1702, _) => {
                        h1702
                    }
                }, Adt56::C4), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1703, _) => {
                        h1703
                    }
                }, Adt56::C4))?, {
                    let a1707 = {
                        let m1705 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1704) => {
                                h1704
                            }
                        };
                        match m1705 {
                            None => {
                                false
                            }
                            Some(v74) => {
                                f105(match v74 {
                                    Adt61::C0(h1706, _, _, _, _, _) => {
                                        h1706
                                    }
                                }, Adt56::C4)
                            }
                        }
                    };
                    if bool_not(a1707) {
                        let m1710 = match v0.clone() {
                            Adt1::C0(h1709, _, _, _, _, _, _) => {
                                h1709
                            }
                        };
                        if match m1710 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1708, _, _, _, _, _, _, _) => {
                                h1708
                            }
                        } {
                            let a1714 = {
                                let m1713 = match v0.clone() {
                                    Adt1::C0(h1712, _, _, _, _, _, _) => {
                                        h1712
                                    }
                                };
                                match m1713 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1711, _, _, _, _, _, _) => {
                                        h1711
                                    }
                                }
                            };
                            bool_not(a1714)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1716 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1715) => {
                            h1715
                        }
                    };
                    match m1716 {
                        None => {
                            false
                        }
                        Some(v75) => {
                            f105(match v75 {
                                Adt61::C0(h1717, _, _, _, _, _) => {
                                    h1717
                                }
                            }, Adt56::C4)
                        }
                    }
                }, {
                    let a1721 = {
                        let m1719 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1718) => {
                                h1718
                            }
                        };
                        match m1719 {
                            None => {
                                false
                            }
                            Some(v76) => {
                                f105(match v76 {
                                    Adt61::C0(h1720, _, _, _, _, _) => {
                                        h1720
                                    }
                                }, Adt56::C4)
                            }
                        }
                    };
                    if bool_not(a1721) {
                        let m1724 = match v0.clone() {
                            Adt1::C0(h1723, _, _, _, _, _, _) => {
                                h1723
                            }
                        };
                        if match m1724 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1722, _, _, _, _, _, _, _) => {
                                h1722
                            }
                        } {
                            let a1728 = {
                                let m1727 = match v0 {
                                    Adt1::C0(h1726, _, _, _, _, _, _) => {
                                        h1726
                                    }
                                };
                                match m1727 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1725, _, _, _, _, _, _) => {
                                        h1725
                                    }
                                }
                            };
                            bool_not(a1728)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            }
        }
        Adt55::C5 => {
            let m1732 = {
                let m1731 = match v0.clone() {
                    Adt1::C0(h1730, _, _, _, _, _, _) => {
                        h1730
                    }
                };
                match m1731 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1729, _, _, _, _, _) => {
                        h1729
                    }
                }
            };
            if if match m1732 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m1736 = {
                        let m1735 = match v0.clone() {
                            Adt1::C0(_, h1734, _, _, _, _, _) => {
                                h1734
                            }
                        };
                        match m1735 {
                            Adt54::C0(h1733, _, _, _, _, _, _, _) => {
                                h1733
                            }
                        }
                    };
                    match m1736 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m1740 = {
                        let m1739 = match v0.clone() {
                            Adt1::C0(_, h1738, _, _, _, _, _) => {
                                h1738
                            }
                        };
                        match m1739 {
                            Adt54::C0(_, h1737, _, _, _, _, _, _) => {
                                h1737
                            }
                        }
                    };
                    match m1740 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1741, _) => {
                        h1741
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1742, _) => {
                        h1742
                    }
                }, Adt56::C0))?, {
                    let a1746 = {
                        let m1744 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1743) => {
                                h1743
                            }
                        };
                        match m1744 {
                            None => {
                                false
                            }
                            Some(v78) => {
                                f105(match v78 {
                                    Adt61::C0(h1745, _, _, _, _, _) => {
                                        h1745
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1746) {
                        let m1749 = match v0.clone() {
                            Adt1::C0(h1748, _, _, _, _, _, _) => {
                                h1748
                            }
                        };
                        if match m1749 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1747, _, _, _, _, _, _, _) => {
                                h1747
                            }
                        } {
                            let a1753 = {
                                let m1752 = match v0.clone() {
                                    Adt1::C0(h1751, _, _, _, _, _, _) => {
                                        h1751
                                    }
                                };
                                match m1752 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1750, _, _, _, _, _, _) => {
                                        h1750
                                    }
                                }
                            };
                            bool_not(a1753)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1755 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1754) => {
                            h1754
                        }
                    };
                    match m1755 {
                        None => {
                            false
                        }
                        Some(v79) => {
                            f105(match v79 {
                                Adt61::C0(h1756, _, _, _, _, _) => {
                                    h1756
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a1760 = {
                        let m1758 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1757) => {
                                h1757
                            }
                        };
                        match m1758 {
                            None => {
                                false
                            }
                            Some(v80) => {
                                f105(match v80 {
                                    Adt61::C0(h1759, _, _, _, _, _) => {
                                        h1759
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1760) {
                        let m1763 = match v0.clone() {
                            Adt1::C0(h1762, _, _, _, _, _, _) => {
                                h1762
                            }
                        };
                        if match m1763 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1761, _, _, _, _, _, _, _) => {
                                h1761
                            }
                        } {
                            let a1767 = {
                                let m1766 = match v0.clone() {
                                    Adt1::C0(h1765, _, _, _, _, _, _) => {
                                        h1765
                                    }
                                };
                                match m1766 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1764, _, _, _, _, _, _) => {
                                        h1764
                                    }
                                }
                            };
                            bool_not(a1767)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m1771 = {
                        let m1770 = match v0.clone() {
                            Adt1::C0(_, h1769, _, _, _, _, _) => {
                                h1769
                            }
                        };
                        match m1770 {
                            Adt54::C0(h1768, _, _, _, _, _, _, _) => {
                                h1768
                            }
                        }
                    };
                    match m1771 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1775 = {
                        let m1774 = match v0.clone() {
                            Adt1::C0(_, h1773, _, _, _, _, _) => {
                                h1773
                            }
                        };
                        match m1774 {
                            Adt54::C0(_, _, _, h1772, _, _, _, _) => {
                                h1772
                            }
                        }
                    };
                    match m1775 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1776, _) => {
                        h1776
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1777, _) => {
                        h1777
                    }
                }, Adt56::C2))?, {
                    let a1781 = {
                        let m1779 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1778) => {
                                h1778
                            }
                        };
                        match m1779 {
                            None => {
                                false
                            }
                            Some(v82) => {
                                f105(match v82 {
                                    Adt61::C0(h1780, _, _, _, _, _) => {
                                        h1780
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1781) {
                        let m1784 = match v0.clone() {
                            Adt1::C0(h1783, _, _, _, _, _, _) => {
                                h1783
                            }
                        };
                        if match m1784 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1782, _, _, _, _, _, _, _) => {
                                h1782
                            }
                        } {
                            let a1788 = {
                                let m1787 = match v0.clone() {
                                    Adt1::C0(h1786, _, _, _, _, _, _) => {
                                        h1786
                                    }
                                };
                                match m1787 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1785, _, _, _, _, _, _) => {
                                        h1785
                                    }
                                }
                            };
                            bool_not(a1788)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1790 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1789) => {
                            h1789
                        }
                    };
                    match m1790 {
                        None => {
                            false
                        }
                        Some(v83) => {
                            f105(match v83 {
                                Adt61::C0(h1791, _, _, _, _, _) => {
                                    h1791
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a1795 = {
                        let m1793 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1792) => {
                                h1792
                            }
                        };
                        match m1793 {
                            None => {
                                false
                            }
                            Some(v84) => {
                                f105(match v84 {
                                    Adt61::C0(h1794, _, _, _, _, _) => {
                                        h1794
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1795) {
                        let m1798 = match v0.clone() {
                            Adt1::C0(h1797, _, _, _, _, _, _) => {
                                h1797
                            }
                        };
                        if match m1798 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1796, _, _, _, _, _, _, _) => {
                                h1796
                            }
                        } {
                            let a1802 = {
                                let m1801 = match v0 {
                                    Adt1::C0(h1800, _, _, _, _, _, _) => {
                                        h1800
                                    }
                                };
                                match m1801 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1799, _, _, _, _, _, _) => {
                                        h1799
                                    }
                                }
                            };
                            bool_not(a1802)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m1806 = {
                        let m1805 = match v0.clone() {
                            Adt1::C0(_, h1804, _, _, _, _, _) => {
                                h1804
                            }
                        };
                        match m1805 {
                            Adt54::C0(h1803, _, _, _, _, _, _, _) => {
                                h1803
                            }
                        }
                    };
                    match m1806 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m1810 = {
                        let m1809 = match v0.clone() {
                            Adt1::C0(_, h1808, _, _, _, _, _) => {
                                h1808
                            }
                        };
                        match m1809 {
                            Adt54::C0(_, h1807, _, _, _, _, _, _) => {
                                h1807
                            }
                        }
                    };
                    match m1810 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1811, _) => {
                        h1811
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1812, _) => {
                        h1812
                    }
                }, Adt56::C0))?, {
                    let a1816 = {
                        let m1814 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1813) => {
                                h1813
                            }
                        };
                        match m1814 {
                            None => {
                                false
                            }
                            Some(v86) => {
                                f105(match v86 {
                                    Adt61::C0(h1815, _, _, _, _, _) => {
                                        h1815
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1816) {
                        let m1819 = match v0.clone() {
                            Adt1::C0(h1818, _, _, _, _, _, _) => {
                                h1818
                            }
                        };
                        if match m1819 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1817, _, _, _, _, _, _, _) => {
                                h1817
                            }
                        } {
                            let a1823 = {
                                let m1822 = match v0.clone() {
                                    Adt1::C0(h1821, _, _, _, _, _, _) => {
                                        h1821
                                    }
                                };
                                match m1822 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1820, _, _, _, _, _, _) => {
                                        h1820
                                    }
                                }
                            };
                            bool_not(a1823)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1825 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1824) => {
                            h1824
                        }
                    };
                    match m1825 {
                        None => {
                            false
                        }
                        Some(v87) => {
                            f105(match v87 {
                                Adt61::C0(h1826, _, _, _, _, _) => {
                                    h1826
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a1830 = {
                        let m1828 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1827) => {
                                h1827
                            }
                        };
                        match m1828 {
                            None => {
                                false
                            }
                            Some(v88) => {
                                f105(match v88 {
                                    Adt61::C0(h1829, _, _, _, _, _) => {
                                        h1829
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1830) {
                        let m1833 = match v0.clone() {
                            Adt1::C0(h1832, _, _, _, _, _, _) => {
                                h1832
                            }
                        };
                        if match m1833 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1831, _, _, _, _, _, _, _) => {
                                h1831
                            }
                        } {
                            let a1837 = {
                                let m1836 = match v0 {
                                    Adt1::C0(h1835, _, _, _, _, _, _) => {
                                        h1835
                                    }
                                };
                                match m1836 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1834, _, _, _, _, _, _) => {
                                        h1834
                                    }
                                }
                            };
                            bool_not(a1837)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))
            }
        }
        Adt55::C6 => {
            let m1841 = {
                let m1840 = match v0.clone() {
                    Adt1::C0(h1839, _, _, _, _, _, _) => {
                        h1839
                    }
                };
                match m1840 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1838, _, _, _, _, _) => {
                        h1838
                    }
                }
            };
            if if match m1841 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m1845 = {
                        let m1844 = match v0.clone() {
                            Adt1::C0(_, h1843, _, _, _, _, _) => {
                                h1843
                            }
                        };
                        match m1844 {
                            Adt54::C0(h1842, _, _, _, _, _, _, _) => {
                                h1842
                            }
                        }
                    };
                    match m1845 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m1849 = {
                        let m1848 = match v0.clone() {
                            Adt1::C0(_, h1847, _, _, _, _, _) => {
                                h1847
                            }
                        };
                        match m1848 {
                            Adt54::C0(_, h1846, _, _, _, _, _, _) => {
                                h1846
                            }
                        }
                    };
                    match m1849 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1850, _) => {
                        h1850
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1851, _) => {
                        h1851
                    }
                }, Adt56::C0))?, {
                    let a1855 = {
                        let m1853 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1852) => {
                                h1852
                            }
                        };
                        match m1853 {
                            None => {
                                false
                            }
                            Some(v90) => {
                                f105(match v90 {
                                    Adt61::C0(h1854, _, _, _, _, _) => {
                                        h1854
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1855) {
                        let m1858 = match v0.clone() {
                            Adt1::C0(h1857, _, _, _, _, _, _) => {
                                h1857
                            }
                        };
                        if match m1858 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1856, _, _, _, _, _, _, _) => {
                                h1856
                            }
                        } {
                            let a1862 = {
                                let m1861 = match v0.clone() {
                                    Adt1::C0(h1860, _, _, _, _, _, _) => {
                                        h1860
                                    }
                                };
                                match m1861 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1859, _, _, _, _, _, _) => {
                                        h1859
                                    }
                                }
                            };
                            bool_not(a1862)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1864 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1863) => {
                            h1863
                        }
                    };
                    match m1864 {
                        None => {
                            false
                        }
                        Some(v91) => {
                            f105(match v91 {
                                Adt61::C0(h1865, _, _, _, _, _) => {
                                    h1865
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a1869 = {
                        let m1867 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1866) => {
                                h1866
                            }
                        };
                        match m1867 {
                            None => {
                                false
                            }
                            Some(v92) => {
                                f105(match v92 {
                                    Adt61::C0(h1868, _, _, _, _, _) => {
                                        h1868
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1869) {
                        let m1872 = match v0.clone() {
                            Adt1::C0(h1871, _, _, _, _, _, _) => {
                                h1871
                            }
                        };
                        if match m1872 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1870, _, _, _, _, _, _, _) => {
                                h1870
                            }
                        } {
                            let a1876 = {
                                let m1875 = match v0.clone() {
                                    Adt1::C0(h1874, _, _, _, _, _, _) => {
                                        h1874
                                    }
                                };
                                match m1875 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1873, _, _, _, _, _, _) => {
                                        h1873
                                    }
                                }
                            };
                            bool_not(a1876)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m1880 = {
                        let m1879 = match v0.clone() {
                            Adt1::C0(_, h1878, _, _, _, _, _) => {
                                h1878
                            }
                        };
                        match m1879 {
                            Adt54::C0(h1877, _, _, _, _, _, _, _) => {
                                h1877
                            }
                        }
                    };
                    match m1880 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1884 = {
                        let m1883 = match v0.clone() {
                            Adt1::C0(_, h1882, _, _, _, _, _) => {
                                h1882
                            }
                        };
                        match m1883 {
                            Adt54::C0(_, _, h1881, _, _, _, _, _) => {
                                h1881
                            }
                        }
                    };
                    match m1884 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1885, _) => {
                        h1885
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1886, _) => {
                        h1886
                    }
                }, Adt56::C1))?, {
                    let a1890 = {
                        let m1888 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1887) => {
                                h1887
                            }
                        };
                        match m1888 {
                            None => {
                                false
                            }
                            Some(v94) => {
                                f105(match v94 {
                                    Adt61::C0(h1889, _, _, _, _, _) => {
                                        h1889
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1890) {
                        let m1893 = match v0.clone() {
                            Adt1::C0(h1892, _, _, _, _, _, _) => {
                                h1892
                            }
                        };
                        if match m1893 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1891, _, _, _, _, _, _, _) => {
                                h1891
                            }
                        } {
                            let a1897 = {
                                let m1896 = match v0.clone() {
                                    Adt1::C0(h1895, _, _, _, _, _, _) => {
                                        h1895
                                    }
                                };
                                match m1896 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1894, _, _, _, _, _, _) => {
                                        h1894
                                    }
                                }
                            };
                            bool_not(a1897)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1899 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1898) => {
                            h1898
                        }
                    };
                    match m1899 {
                        None => {
                            false
                        }
                        Some(v95) => {
                            f105(match v95 {
                                Adt61::C0(h1900, _, _, _, _, _) => {
                                    h1900
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a1904 = {
                        let m1902 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1901) => {
                                h1901
                            }
                        };
                        match m1902 {
                            None => {
                                false
                            }
                            Some(v96) => {
                                f105(match v96 {
                                    Adt61::C0(h1903, _, _, _, _, _) => {
                                        h1903
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1904) {
                        let m1907 = match v0.clone() {
                            Adt1::C0(h1906, _, _, _, _, _, _) => {
                                h1906
                            }
                        };
                        if match m1907 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1905, _, _, _, _, _, _, _) => {
                                h1905
                            }
                        } {
                            let a1911 = {
                                let m1910 = match v0.clone() {
                                    Adt1::C0(h1909, _, _, _, _, _, _) => {
                                        h1909
                                    }
                                };
                                match m1910 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1908, _, _, _, _, _, _) => {
                                        h1908
                                    }
                                }
                            };
                            bool_not(a1911)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m1915 = {
                        let m1914 = match v0.clone() {
                            Adt1::C0(_, h1913, _, _, _, _, _) => {
                                h1913
                            }
                        };
                        match m1914 {
                            Adt54::C0(h1912, _, _, _, _, _, _, _) => {
                                h1912
                            }
                        }
                    };
                    match m1915 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1919 = {
                        let m1918 = match v0.clone() {
                            Adt1::C0(_, h1917, _, _, _, _, _) => {
                                h1917
                            }
                        };
                        match m1918 {
                            Adt54::C0(_, _, _, h1916, _, _, _, _) => {
                                h1916
                            }
                        }
                    };
                    match m1919 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1920, _) => {
                        h1920
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1921, _) => {
                        h1921
                    }
                }, Adt56::C2))?, {
                    let a1925 = {
                        let m1923 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1922) => {
                                h1922
                            }
                        };
                        match m1923 {
                            None => {
                                false
                            }
                            Some(v98) => {
                                f105(match v98 {
                                    Adt61::C0(h1924, _, _, _, _, _) => {
                                        h1924
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1925) {
                        let m1928 = match v0.clone() {
                            Adt1::C0(h1927, _, _, _, _, _, _) => {
                                h1927
                            }
                        };
                        if match m1928 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1926, _, _, _, _, _, _, _) => {
                                h1926
                            }
                        } {
                            let a1932 = {
                                let m1931 = match v0.clone() {
                                    Adt1::C0(h1930, _, _, _, _, _, _) => {
                                        h1930
                                    }
                                };
                                match m1931 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1929, _, _, _, _, _, _) => {
                                        h1929
                                    }
                                }
                            };
                            bool_not(a1932)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1934 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1933) => {
                            h1933
                        }
                    };
                    match m1934 {
                        None => {
                            false
                        }
                        Some(v99) => {
                            f105(match v99 {
                                Adt61::C0(h1935, _, _, _, _, _) => {
                                    h1935
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a1939 = {
                        let m1937 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1936) => {
                                h1936
                            }
                        };
                        match m1937 {
                            None => {
                                false
                            }
                            Some(v100) => {
                                f105(match v100 {
                                    Adt61::C0(h1938, _, _, _, _, _) => {
                                        h1938
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a1939) {
                        let m1942 = match v0.clone() {
                            Adt1::C0(h1941, _, _, _, _, _, _) => {
                                h1941
                            }
                        };
                        if match m1942 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1940, _, _, _, _, _, _, _) => {
                                h1940
                            }
                        } {
                            let a1946 = {
                                let m1945 = match v0 {
                                    Adt1::C0(h1944, _, _, _, _, _, _) => {
                                        h1944
                                    }
                                };
                                match m1945 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1943, _, _, _, _, _, _) => {
                                        h1943
                                    }
                                }
                            };
                            bool_not(a1946)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m1950 = {
                        let m1949 = match v0.clone() {
                            Adt1::C0(_, h1948, _, _, _, _, _) => {
                                h1948
                            }
                        };
                        match m1949 {
                            Adt54::C0(h1947, _, _, _, _, _, _, _) => {
                                h1947
                            }
                        }
                    };
                    match m1950 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m1954 = {
                        let m1953 = match v0.clone() {
                            Adt1::C0(_, h1952, _, _, _, _, _) => {
                                h1952
                            }
                        };
                        match m1953 {
                            Adt54::C0(_, h1951, _, _, _, _, _, _) => {
                                h1951
                            }
                        }
                    };
                    match m1954 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1955, _) => {
                        h1955
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1956, _) => {
                        h1956
                    }
                }, Adt56::C0))?, {
                    let a1960 = {
                        let m1958 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1957) => {
                                h1957
                            }
                        };
                        match m1958 {
                            None => {
                                false
                            }
                            Some(v102) => {
                                f105(match v102 {
                                    Adt61::C0(h1959, _, _, _, _, _) => {
                                        h1959
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1960) {
                        let m1963 = match v0.clone() {
                            Adt1::C0(h1962, _, _, _, _, _, _) => {
                                h1962
                            }
                        };
                        if match m1963 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1961, _, _, _, _, _, _, _) => {
                                h1961
                            }
                        } {
                            let a1967 = {
                                let m1966 = match v0.clone() {
                                    Adt1::C0(h1965, _, _, _, _, _, _) => {
                                        h1965
                                    }
                                };
                                match m1966 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1964, _, _, _, _, _, _) => {
                                        h1964
                                    }
                                }
                            };
                            bool_not(a1967)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1969 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1968) => {
                            h1968
                        }
                    };
                    match m1969 {
                        None => {
                            false
                        }
                        Some(v103) => {
                            f105(match v103 {
                                Adt61::C0(h1970, _, _, _, _, _) => {
                                    h1970
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a1974 = {
                        let m1972 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1971) => {
                                h1971
                            }
                        };
                        match m1972 {
                            None => {
                                false
                            }
                            Some(v104) => {
                                f105(match v104 {
                                    Adt61::C0(h1973, _, _, _, _, _) => {
                                        h1973
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a1974) {
                        let m1977 = match v0.clone() {
                            Adt1::C0(h1976, _, _, _, _, _, _) => {
                                h1976
                            }
                        };
                        if match m1977 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1975, _, _, _, _, _, _, _) => {
                                h1975
                            }
                        } {
                            let a1981 = {
                                let m1980 = match v0.clone() {
                                    Adt1::C0(h1979, _, _, _, _, _, _) => {
                                        h1979
                                    }
                                };
                                match m1980 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1978, _, _, _, _, _, _) => {
                                        h1978
                                    }
                                }
                            };
                            bool_not(a1981)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m1985 = {
                        let m1984 = match v0.clone() {
                            Adt1::C0(_, h1983, _, _, _, _, _) => {
                                h1983
                            }
                        };
                        match m1984 {
                            Adt54::C0(h1982, _, _, _, _, _, _, _) => {
                                h1982
                            }
                        }
                    };
                    match m1985 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m1989 = {
                        let m1988 = match v0.clone() {
                            Adt1::C0(_, h1987, _, _, _, _, _) => {
                                h1987
                            }
                        };
                        match m1988 {
                            Adt54::C0(_, _, h1986, _, _, _, _, _) => {
                                h1986
                            }
                        }
                    };
                    match m1989 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1990, _) => {
                        h1990
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1991, _) => {
                        h1991
                    }
                }, Adt56::C1))?, {
                    let a1995 = {
                        let m1993 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1992) => {
                                h1992
                            }
                        };
                        match m1993 {
                            None => {
                                false
                            }
                            Some(v106) => {
                                f105(match v106 {
                                    Adt61::C0(h1994, _, _, _, _, _) => {
                                        h1994
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a1995) {
                        let m1998 = match v0.clone() {
                            Adt1::C0(h1997, _, _, _, _, _, _) => {
                                h1997
                            }
                        };
                        if match m1998 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1996, _, _, _, _, _, _, _) => {
                                h1996
                            }
                        } {
                            let a2002 = {
                                let m2001 = match v0.clone() {
                                    Adt1::C0(h2000, _, _, _, _, _, _) => {
                                        h2000
                                    }
                                };
                                match m2001 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1999, _, _, _, _, _, _) => {
                                        h1999
                                    }
                                }
                            };
                            bool_not(a2002)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2004 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2003) => {
                            h2003
                        }
                    };
                    match m2004 {
                        None => {
                            false
                        }
                        Some(v107) => {
                            f105(match v107 {
                                Adt61::C0(h2005, _, _, _, _, _) => {
                                    h2005
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a2009 = {
                        let m2007 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2006) => {
                                h2006
                            }
                        };
                        match m2007 {
                            None => {
                                false
                            }
                            Some(v108) => {
                                f105(match v108 {
                                    Adt61::C0(h2008, _, _, _, _, _) => {
                                        h2008
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a2009) {
                        let m2012 = match v0.clone() {
                            Adt1::C0(h2011, _, _, _, _, _, _) => {
                                h2011
                            }
                        };
                        if match m2012 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2010, _, _, _, _, _, _, _) => {
                                h2010
                            }
                        } {
                            let a2016 = {
                                let m2015 = match v0 {
                                    Adt1::C0(h2014, _, _, _, _, _, _) => {
                                        h2014
                                    }
                                };
                                match m2015 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2013, _, _, _, _, _, _) => {
                                        h2013
                                    }
                                }
                            };
                            bool_not(a2016)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            }
        }
        Adt55::C7 => {
            let m2020 = {
                let m2019 = match v0.clone() {
                    Adt1::C0(h2018, _, _, _, _, _, _) => {
                        h2018
                    }
                };
                match m2019 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2017, _, _, _, _, _) => {
                        h2017
                    }
                }
            };
            if if match m2020 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m2024 = {
                        let m2023 = match v0.clone() {
                            Adt1::C0(_, h2022, _, _, _, _, _) => {
                                h2022
                            }
                        };
                        match m2023 {
                            Adt54::C0(h2021, _, _, _, _, _, _, _) => {
                                h2021
                            }
                        }
                    };
                    match m2024 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2028 = {
                        let m2027 = match v0.clone() {
                            Adt1::C0(_, h2026, _, _, _, _, _) => {
                                h2026
                            }
                        };
                        match m2027 {
                            Adt54::C0(_, _, h2025, _, _, _, _, _) => {
                                h2025
                            }
                        }
                    };
                    match m2028 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2029, _) => {
                        h2029
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2030, _) => {
                        h2030
                    }
                }, Adt56::C1))?, {
                    let a2034 = {
                        let m2032 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2031) => {
                                h2031
                            }
                        };
                        match m2032 {
                            None => {
                                false
                            }
                            Some(v110) => {
                                f105(match v110 {
                                    Adt61::C0(h2033, _, _, _, _, _) => {
                                        h2033
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a2034) {
                        let m2037 = match v0.clone() {
                            Adt1::C0(h2036, _, _, _, _, _, _) => {
                                h2036
                            }
                        };
                        if match m2037 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2035, _, _, _, _, _, _, _) => {
                                h2035
                            }
                        } {
                            let a2041 = {
                                let m2040 = match v0.clone() {
                                    Adt1::C0(h2039, _, _, _, _, _, _) => {
                                        h2039
                                    }
                                };
                                match m2040 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2038, _, _, _, _, _, _) => {
                                        h2038
                                    }
                                }
                            };
                            bool_not(a2041)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2043 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2042) => {
                            h2042
                        }
                    };
                    match m2043 {
                        None => {
                            false
                        }
                        Some(v111) => {
                            f105(match v111 {
                                Adt61::C0(h2044, _, _, _, _, _) => {
                                    h2044
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a2048 = {
                        let m2046 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2045) => {
                                h2045
                            }
                        };
                        match m2046 {
                            None => {
                                false
                            }
                            Some(v112) => {
                                f105(match v112 {
                                    Adt61::C0(h2047, _, _, _, _, _) => {
                                        h2047
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a2048) {
                        let m2051 = match v0.clone() {
                            Adt1::C0(h2050, _, _, _, _, _, _) => {
                                h2050
                            }
                        };
                        if match m2051 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2049, _, _, _, _, _, _, _) => {
                                h2049
                            }
                        } {
                            let a2055 = {
                                let m2054 = match v0.clone() {
                                    Adt1::C0(h2053, _, _, _, _, _, _) => {
                                        h2053
                                    }
                                };
                                match m2054 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2052, _, _, _, _, _, _) => {
                                        h2052
                                    }
                                }
                            };
                            bool_not(a2055)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C5, Str::lit("Second archive"), f42(v0.clone(), Adt63::C1(Adt56::C5)), false, {
                    let m2059 = {
                        let m2058 = match v0.clone() {
                            Adt1::C0(_, h2057, _, _, _, _, _) => {
                                h2057
                            }
                        };
                        match m2058 {
                            Adt54::C0(h2056, _, _, _, _, _, _, _) => {
                                h2056
                            }
                        }
                    };
                    match m2059 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2063 = {
                        let m2062 = match v0.clone() {
                            Adt1::C0(_, h2061, _, _, _, _, _) => {
                                h2061
                            }
                        };
                        match m2062 {
                            Adt54::C0(_, _, _, _, _, _, h2060, _) => {
                                h2060
                            }
                        }
                    };
                    match m2063 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C5), f103(v0.clone(), Adt56::C5, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2064, _) => {
                        h2064
                    }
                }, Adt56::C5), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2065, _) => {
                        h2065
                    }
                }, Adt56::C5))?, {
                    let a2069 = {
                        let m2067 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2066) => {
                                h2066
                            }
                        };
                        match m2067 {
                            None => {
                                false
                            }
                            Some(v114) => {
                                f105(match v114 {
                                    Adt61::C0(h2068, _, _, _, _, _) => {
                                        h2068
                                    }
                                }, Adt56::C5)
                            }
                        }
                    };
                    if bool_not(a2069) {
                        let m2072 = match v0.clone() {
                            Adt1::C0(h2071, _, _, _, _, _, _) => {
                                h2071
                            }
                        };
                        if match m2072 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2070, _, _, _, _, _, _, _) => {
                                h2070
                            }
                        } {
                            let a2076 = {
                                let m2075 = match v0.clone() {
                                    Adt1::C0(h2074, _, _, _, _, _, _) => {
                                        h2074
                                    }
                                };
                                match m2075 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2073, _, _, _, _, _, _) => {
                                        h2073
                                    }
                                }
                            };
                            bool_not(a2076)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2078 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2077) => {
                            h2077
                        }
                    };
                    match m2078 {
                        None => {
                            false
                        }
                        Some(v115) => {
                            f105(match v115 {
                                Adt61::C0(h2079, _, _, _, _, _) => {
                                    h2079
                                }
                            }, Adt56::C5)
                        }
                    }
                }, {
                    let a2083 = {
                        let m2081 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2080) => {
                                h2080
                            }
                        };
                        match m2081 {
                            None => {
                                false
                            }
                            Some(v116) => {
                                f105(match v116 {
                                    Adt61::C0(h2082, _, _, _, _, _) => {
                                        h2082
                                    }
                                }, Adt56::C5)
                            }
                        }
                    };
                    if bool_not(a2083) {
                        let m2086 = match v0.clone() {
                            Adt1::C0(h2085, _, _, _, _, _, _) => {
                                h2085
                            }
                        };
                        if match m2086 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2084, _, _, _, _, _, _, _) => {
                                h2084
                            }
                        } {
                            let a2090 = {
                                let m2089 = match v0.clone() {
                                    Adt1::C0(h2088, _, _, _, _, _, _) => {
                                        h2088
                                    }
                                };
                                match m2089 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2087, _, _, _, _, _, _) => {
                                        h2087
                                    }
                                }
                            };
                            bool_not(a2090)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C3, Str::lit("Original objects for byte comparison (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C3)), true, {
                    let m2094 = {
                        let m2093 = match v0.clone() {
                            Adt1::C0(_, h2092, _, _, _, _, _) => {
                                h2092
                            }
                        };
                        match m2093 {
                            Adt54::C0(h2091, _, _, _, _, _, _, _) => {
                                h2091
                            }
                        }
                    };
                    match m2094 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2098 = {
                        let m2097 = match v0.clone() {
                            Adt1::C0(_, h2096, _, _, _, _, _) => {
                                h2096
                            }
                        };
                        match m2097 {
                            Adt54::C0(_, _, _, _, h2095, _, _, _) => {
                                h2095
                            }
                        }
                    };
                    match m2098 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C3), f103(v0.clone(), Adt56::C3, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2099, _) => {
                        h2099
                    }
                }, Adt56::C3), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2100, _) => {
                        h2100
                    }
                }, Adt56::C3))?, {
                    let a2104 = {
                        let m2102 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2101) => {
                                h2101
                            }
                        };
                        match m2102 {
                            None => {
                                false
                            }
                            Some(v118) => {
                                f105(match v118 {
                                    Adt61::C0(h2103, _, _, _, _, _) => {
                                        h2103
                                    }
                                }, Adt56::C3)
                            }
                        }
                    };
                    if bool_not(a2104) {
                        let m2107 = match v0.clone() {
                            Adt1::C0(h2106, _, _, _, _, _, _) => {
                                h2106
                            }
                        };
                        if match m2107 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2105, _, _, _, _, _, _, _) => {
                                h2105
                            }
                        } {
                            let a2111 = {
                                let m2110 = match v0.clone() {
                                    Adt1::C0(h2109, _, _, _, _, _, _) => {
                                        h2109
                                    }
                                };
                                match m2110 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2108, _, _, _, _, _, _) => {
                                        h2108
                                    }
                                }
                            };
                            bool_not(a2111)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2113 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2112) => {
                            h2112
                        }
                    };
                    match m2113 {
                        None => {
                            false
                        }
                        Some(v119) => {
                            f105(match v119 {
                                Adt61::C0(h2114, _, _, _, _, _) => {
                                    h2114
                                }
                            }, Adt56::C3)
                        }
                    }
                }, {
                    let a2118 = {
                        let m2116 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2115) => {
                                h2115
                            }
                        };
                        match m2116 {
                            None => {
                                false
                            }
                            Some(v120) => {
                                f105(match v120 {
                                    Adt61::C0(h2117, _, _, _, _, _) => {
                                        h2117
                                    }
                                }, Adt56::C3)
                            }
                        }
                    };
                    if bool_not(a2118) {
                        let m2121 = match v0.clone() {
                            Adt1::C0(h2120, _, _, _, _, _, _) => {
                                h2120
                            }
                        };
                        if match m2121 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2119, _, _, _, _, _, _, _) => {
                                h2119
                            }
                        } {
                            let a2125 = {
                                let m2124 = match v0.clone() {
                                    Adt1::C0(h2123, _, _, _, _, _, _) => {
                                        h2123
                                    }
                                };
                                match m2124 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2122, _, _, _, _, _, _) => {
                                        h2122
                                    }
                                }
                            };
                            bool_not(a2125)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m2129 = {
                        let m2128 = match v0.clone() {
                            Adt1::C0(_, h2127, _, _, _, _, _) => {
                                h2127
                            }
                        };
                        match m2128 {
                            Adt54::C0(h2126, _, _, _, _, _, _, _) => {
                                h2126
                            }
                        }
                    };
                    match m2129 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2133 = {
                        let m2132 = match v0.clone() {
                            Adt1::C0(_, h2131, _, _, _, _, _) => {
                                h2131
                            }
                        };
                        match m2132 {
                            Adt54::C0(_, _, _, h2130, _, _, _, _) => {
                                h2130
                            }
                        }
                    };
                    match m2133 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2134, _) => {
                        h2134
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2135, _) => {
                        h2135
                    }
                }, Adt56::C2))?, {
                    let a2139 = {
                        let m2137 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2136) => {
                                h2136
                            }
                        };
                        match m2137 {
                            None => {
                                false
                            }
                            Some(v122) => {
                                f105(match v122 {
                                    Adt61::C0(h2138, _, _, _, _, _) => {
                                        h2138
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a2139) {
                        let m2142 = match v0.clone() {
                            Adt1::C0(h2141, _, _, _, _, _, _) => {
                                h2141
                            }
                        };
                        if match m2142 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2140, _, _, _, _, _, _, _) => {
                                h2140
                            }
                        } {
                            let a2146 = {
                                let m2145 = match v0.clone() {
                                    Adt1::C0(h2144, _, _, _, _, _, _) => {
                                        h2144
                                    }
                                };
                                match m2145 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2143, _, _, _, _, _, _) => {
                                        h2143
                                    }
                                }
                            };
                            bool_not(a2146)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2148 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2147) => {
                            h2147
                        }
                    };
                    match m2148 {
                        None => {
                            false
                        }
                        Some(v123) => {
                            f105(match v123 {
                                Adt61::C0(h2149, _, _, _, _, _) => {
                                    h2149
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a2153 = {
                        let m2151 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2150) => {
                                h2150
                            }
                        };
                        match m2151 {
                            None => {
                                false
                            }
                            Some(v124) => {
                                f105(match v124 {
                                    Adt61::C0(h2152, _, _, _, _, _) => {
                                        h2152
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a2153) {
                        let m2156 = match v0.clone() {
                            Adt1::C0(h2155, _, _, _, _, _, _) => {
                                h2155
                            }
                        };
                        if match m2156 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2154, _, _, _, _, _, _, _) => {
                                h2154
                            }
                        } {
                            let a2160 = {
                                let m2159 = match v0 {
                                    Adt1::C0(h2158, _, _, _, _, _, _) => {
                                        h2158
                                    }
                                };
                                match m2159 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2157, _, _, _, _, _, _) => {
                                        h2157
                                    }
                                }
                            };
                            bool_not(a2160)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C1, Str::lit("Archive"), f42(v0.clone(), Adt63::C1(Adt56::C1)), false, {
                    let m2164 = {
                        let m2163 = match v0.clone() {
                            Adt1::C0(_, h2162, _, _, _, _, _) => {
                                h2162
                            }
                        };
                        match m2163 {
                            Adt54::C0(h2161, _, _, _, _, _, _, _) => {
                                h2161
                            }
                        }
                    };
                    match m2164 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            true
                        }
                        Adt55::C3 => {
                            true
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2168 = {
                        let m2167 = match v0.clone() {
                            Adt1::C0(_, h2166, _, _, _, _, _) => {
                                h2166
                            }
                        };
                        match m2167 {
                            Adt54::C0(_, _, h2165, _, _, _, _, _) => {
                                h2165
                            }
                        }
                    };
                    match m2168 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C1), f103(v0.clone(), Adt56::C1, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2169, _) => {
                        h2169
                    }
                }, Adt56::C1), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2170, _) => {
                        h2170
                    }
                }, Adt56::C1))?, {
                    let a2174 = {
                        let m2172 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2171) => {
                                h2171
                            }
                        };
                        match m2172 {
                            None => {
                                false
                            }
                            Some(v126) => {
                                f105(match v126 {
                                    Adt61::C0(h2173, _, _, _, _, _) => {
                                        h2173
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a2174) {
                        let m2177 = match v0.clone() {
                            Adt1::C0(h2176, _, _, _, _, _, _) => {
                                h2176
                            }
                        };
                        if match m2177 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2175, _, _, _, _, _, _, _) => {
                                h2175
                            }
                        } {
                            let a2181 = {
                                let m2180 = match v0.clone() {
                                    Adt1::C0(h2179, _, _, _, _, _, _) => {
                                        h2179
                                    }
                                };
                                match m2180 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2178, _, _, _, _, _, _) => {
                                        h2178
                                    }
                                }
                            };
                            bool_not(a2181)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2183 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2182) => {
                            h2182
                        }
                    };
                    match m2183 {
                        None => {
                            false
                        }
                        Some(v127) => {
                            f105(match v127 {
                                Adt61::C0(h2184, _, _, _, _, _) => {
                                    h2184
                                }
                            }, Adt56::C1)
                        }
                    }
                }, {
                    let a2188 = {
                        let m2186 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2185) => {
                                h2185
                            }
                        };
                        match m2186 {
                            None => {
                                false
                            }
                            Some(v128) => {
                                f105(match v128 {
                                    Adt61::C0(h2187, _, _, _, _, _) => {
                                        h2187
                                    }
                                }, Adt56::C1)
                            }
                        }
                    };
                    if bool_not(a2188) {
                        let m2191 = match v0.clone() {
                            Adt1::C0(h2190, _, _, _, _, _, _) => {
                                h2190
                            }
                        };
                        if match m2191 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2189, _, _, _, _, _, _, _) => {
                                h2189
                            }
                        } {
                            let a2195 = {
                                let m2194 = match v0.clone() {
                                    Adt1::C0(h2193, _, _, _, _, _, _) => {
                                        h2193
                                    }
                                };
                                match m2194 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2192, _, _, _, _, _, _) => {
                                        h2192
                                    }
                                }
                            };
                            bool_not(a2195)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C5, Str::lit("Second archive"), f42(v0.clone(), Adt63::C1(Adt56::C5)), false, {
                    let m2199 = {
                        let m2198 = match v0.clone() {
                            Adt1::C0(_, h2197, _, _, _, _, _) => {
                                h2197
                            }
                        };
                        match m2198 {
                            Adt54::C0(h2196, _, _, _, _, _, _, _) => {
                                h2196
                            }
                        }
                    };
                    match m2199 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            true
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2203 = {
                        let m2202 = match v0.clone() {
                            Adt1::C0(_, h2201, _, _, _, _, _) => {
                                h2201
                            }
                        };
                        match m2202 {
                            Adt54::C0(_, _, _, _, _, _, h2200, _) => {
                                h2200
                            }
                        }
                    };
                    match m2203 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C5), f103(v0.clone(), Adt56::C5, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2204, _) => {
                        h2204
                    }
                }, Adt56::C5), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2205, _) => {
                        h2205
                    }
                }, Adt56::C5))?, {
                    let a2209 = {
                        let m2207 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2206) => {
                                h2206
                            }
                        };
                        match m2207 {
                            None => {
                                false
                            }
                            Some(v130) => {
                                f105(match v130 {
                                    Adt61::C0(h2208, _, _, _, _, _) => {
                                        h2208
                                    }
                                }, Adt56::C5)
                            }
                        }
                    };
                    if bool_not(a2209) {
                        let m2212 = match v0.clone() {
                            Adt1::C0(h2211, _, _, _, _, _, _) => {
                                h2211
                            }
                        };
                        if match m2212 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2210, _, _, _, _, _, _, _) => {
                                h2210
                            }
                        } {
                            let a2216 = {
                                let m2215 = match v0.clone() {
                                    Adt1::C0(h2214, _, _, _, _, _, _) => {
                                        h2214
                                    }
                                };
                                match m2215 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2213, _, _, _, _, _, _) => {
                                        h2213
                                    }
                                }
                            };
                            bool_not(a2216)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2218 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2217) => {
                            h2217
                        }
                    };
                    match m2218 {
                        None => {
                            false
                        }
                        Some(v131) => {
                            f105(match v131 {
                                Adt61::C0(h2219, _, _, _, _, _) => {
                                    h2219
                                }
                            }, Adt56::C5)
                        }
                    }
                }, {
                    let a2223 = {
                        let m2221 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2220) => {
                                h2220
                            }
                        };
                        match m2221 {
                            None => {
                                false
                            }
                            Some(v132) => {
                                f105(match v132 {
                                    Adt61::C0(h2222, _, _, _, _, _) => {
                                        h2222
                                    }
                                }, Adt56::C5)
                            }
                        }
                    };
                    if bool_not(a2223) {
                        let m2226 = match v0.clone() {
                            Adt1::C0(h2225, _, _, _, _, _, _) => {
                                h2225
                            }
                        };
                        if match m2226 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2224, _, _, _, _, _, _, _) => {
                                h2224
                            }
                        } {
                            let a2230 = {
                                let m2229 = match v0.clone() {
                                    Adt1::C0(h2228, _, _, _, _, _, _) => {
                                        h2228
                                    }
                                };
                                match m2229 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2227, _, _, _, _, _, _) => {
                                        h2227
                                    }
                                }
                            };
                            bool_not(a2230)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C3, Str::lit("Original objects for byte comparison (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C3)), true, {
                    let m2234 = {
                        let m2233 = match v0.clone() {
                            Adt1::C0(_, h2232, _, _, _, _, _) => {
                                h2232
                            }
                        };
                        match m2233 {
                            Adt54::C0(h2231, _, _, _, _, _, _, _) => {
                                h2231
                            }
                        }
                    };
                    match m2234 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2238 = {
                        let m2237 = match v0.clone() {
                            Adt1::C0(_, h2236, _, _, _, _, _) => {
                                h2236
                            }
                        };
                        match m2237 {
                            Adt54::C0(_, _, _, _, h2235, _, _, _) => {
                                h2235
                            }
                        }
                    };
                    match m2238 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C3), f103(v0.clone(), Adt56::C3, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2239, _) => {
                        h2239
                    }
                }, Adt56::C3), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2240, _) => {
                        h2240
                    }
                }, Adt56::C3))?, {
                    let a2244 = {
                        let m2242 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2241) => {
                                h2241
                            }
                        };
                        match m2242 {
                            None => {
                                false
                            }
                            Some(v134) => {
                                f105(match v134 {
                                    Adt61::C0(h2243, _, _, _, _, _) => {
                                        h2243
                                    }
                                }, Adt56::C3)
                            }
                        }
                    };
                    if bool_not(a2244) {
                        let m2247 = match v0.clone() {
                            Adt1::C0(h2246, _, _, _, _, _, _) => {
                                h2246
                            }
                        };
                        if match m2247 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2245, _, _, _, _, _, _, _) => {
                                h2245
                            }
                        } {
                            let a2251 = {
                                let m2250 = match v0.clone() {
                                    Adt1::C0(h2249, _, _, _, _, _, _) => {
                                        h2249
                                    }
                                };
                                match m2250 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2248, _, _, _, _, _, _) => {
                                        h2248
                                    }
                                }
                            };
                            bool_not(a2251)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2253 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2252) => {
                            h2252
                        }
                    };
                    match m2253 {
                        None => {
                            false
                        }
                        Some(v135) => {
                            f105(match v135 {
                                Adt61::C0(h2254, _, _, _, _, _) => {
                                    h2254
                                }
                            }, Adt56::C3)
                        }
                    }
                }, {
                    let a2258 = {
                        let m2256 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2255) => {
                                h2255
                            }
                        };
                        match m2256 {
                            None => {
                                false
                            }
                            Some(v136) => {
                                f105(match v136 {
                                    Adt61::C0(h2257, _, _, _, _, _) => {
                                        h2257
                                    }
                                }, Adt56::C3)
                            }
                        }
                    };
                    if bool_not(a2258) {
                        let m2261 = match v0.clone() {
                            Adt1::C0(h2260, _, _, _, _, _, _) => {
                                h2260
                            }
                        };
                        if match m2261 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2259, _, _, _, _, _, _, _) => {
                                h2259
                            }
                        } {
                            let a2265 = {
                                let m2264 = match v0 {
                                    Adt1::C0(h2263, _, _, _, _, _, _) => {
                                        h2263
                                    }
                                };
                                match m2264 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2262, _, _, _, _, _, _) => {
                                        h2262
                                    }
                                }
                            };
                            bool_not(a2265)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))))
            }
        }
        Adt55::C8 => {
            let m2269 = {
                let m2268 = match v0.clone() {
                    Adt1::C0(h2267, _, _, _, _, _, _) => {
                        h2267
                    }
                };
                match m2268 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2266, _, _, _, _, _) => {
                        h2266
                    }
                }
            };
            if if match m2269 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m2273 = {
                        let m2272 = match v0.clone() {
                            Adt1::C0(_, h2271, _, _, _, _, _) => {
                                h2271
                            }
                        };
                        match m2272 {
                            Adt54::C0(h2270, _, _, _, _, _, _, _) => {
                                h2270
                            }
                        }
                    };
                    match m2273 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m2277 = {
                        let m2276 = match v0.clone() {
                            Adt1::C0(_, h2275, _, _, _, _, _) => {
                                h2275
                            }
                        };
                        match m2276 {
                            Adt54::C0(_, h2274, _, _, _, _, _, _) => {
                                h2274
                            }
                        }
                    };
                    match m2277 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2278, _) => {
                        h2278
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2279, _) => {
                        h2279
                    }
                }, Adt56::C0))?, {
                    let a2283 = {
                        let m2281 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2280) => {
                                h2280
                            }
                        };
                        match m2281 {
                            None => {
                                false
                            }
                            Some(v138) => {
                                f105(match v138 {
                                    Adt61::C0(h2282, _, _, _, _, _) => {
                                        h2282
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a2283) {
                        let m2286 = match v0.clone() {
                            Adt1::C0(h2285, _, _, _, _, _, _) => {
                                h2285
                            }
                        };
                        if match m2286 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2284, _, _, _, _, _, _, _) => {
                                h2284
                            }
                        } {
                            let a2290 = {
                                let m2289 = match v0.clone() {
                                    Adt1::C0(h2288, _, _, _, _, _, _) => {
                                        h2288
                                    }
                                };
                                match m2289 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2287, _, _, _, _, _, _) => {
                                        h2287
                                    }
                                }
                            };
                            bool_not(a2290)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2292 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2291) => {
                            h2291
                        }
                    };
                    match m2292 {
                        None => {
                            false
                        }
                        Some(v139) => {
                            f105(match v139 {
                                Adt61::C0(h2293, _, _, _, _, _) => {
                                    h2293
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a2297 = {
                        let m2295 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2294) => {
                                h2294
                            }
                        };
                        match m2295 {
                            None => {
                                false
                            }
                            Some(v140) => {
                                f105(match v140 {
                                    Adt61::C0(h2296, _, _, _, _, _) => {
                                        h2296
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a2297) {
                        let m2300 = match v0.clone() {
                            Adt1::C0(h2299, _, _, _, _, _, _) => {
                                h2299
                            }
                        };
                        if match m2300 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2298, _, _, _, _, _, _, _) => {
                                h2298
                            }
                        } {
                            let a2304 = {
                                let m2303 = match v0.clone() {
                                    Adt1::C0(h2302, _, _, _, _, _, _) => {
                                        h2302
                                    }
                                };
                                match m2303 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2301, _, _, _, _, _, _) => {
                                        h2301
                                    }
                                }
                            };
                            bool_not(a2304)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m2308 = {
                        let m2307 = match v0.clone() {
                            Adt1::C0(_, h2306, _, _, _, _, _) => {
                                h2306
                            }
                        };
                        match m2307 {
                            Adt54::C0(h2305, _, _, _, _, _, _, _) => {
                                h2305
                            }
                        }
                    };
                    match m2308 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2312 = {
                        let m2311 = match v0.clone() {
                            Adt1::C0(_, h2310, _, _, _, _, _) => {
                                h2310
                            }
                        };
                        match m2311 {
                            Adt54::C0(_, _, _, h2309, _, _, _, _) => {
                                h2309
                            }
                        }
                    };
                    match m2312 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2313, _) => {
                        h2313
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2314, _) => {
                        h2314
                    }
                }, Adt56::C2))?, {
                    let a2318 = {
                        let m2316 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2315) => {
                                h2315
                            }
                        };
                        match m2316 {
                            None => {
                                false
                            }
                            Some(v142) => {
                                f105(match v142 {
                                    Adt61::C0(h2317, _, _, _, _, _) => {
                                        h2317
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a2318) {
                        let m2321 = match v0.clone() {
                            Adt1::C0(h2320, _, _, _, _, _, _) => {
                                h2320
                            }
                        };
                        if match m2321 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2319, _, _, _, _, _, _, _) => {
                                h2319
                            }
                        } {
                            let a2325 = {
                                let m2324 = match v0.clone() {
                                    Adt1::C0(h2323, _, _, _, _, _, _) => {
                                        h2323
                                    }
                                };
                                match m2324 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2322, _, _, _, _, _, _) => {
                                        h2322
                                    }
                                }
                            };
                            bool_not(a2325)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2327 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2326) => {
                            h2326
                        }
                    };
                    match m2327 {
                        None => {
                            false
                        }
                        Some(v143) => {
                            f105(match v143 {
                                Adt61::C0(h2328, _, _, _, _, _) => {
                                    h2328
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a2332 = {
                        let m2330 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2329) => {
                                h2329
                            }
                        };
                        match m2330 {
                            None => {
                                false
                            }
                            Some(v144) => {
                                f105(match v144 {
                                    Adt61::C0(h2331, _, _, _, _, _) => {
                                        h2331
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a2332) {
                        let m2335 = match v0.clone() {
                            Adt1::C0(h2334, _, _, _, _, _, _) => {
                                h2334
                            }
                        };
                        if match m2335 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2333, _, _, _, _, _, _, _) => {
                                h2333
                            }
                        } {
                            let a2339 = {
                                let m2338 = match v0 {
                                    Adt1::C0(h2337, _, _, _, _, _, _) => {
                                        h2337
                                    }
                                };
                                match m2338 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2336, _, _, _, _, _, _) => {
                                        h2336
                                    }
                                }
                            };
                            bool_not(a2339)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m2343 = {
                        let m2342 = match v0.clone() {
                            Adt1::C0(_, h2341, _, _, _, _, _) => {
                                h2341
                            }
                        };
                        match m2342 {
                            Adt54::C0(h2340, _, _, _, _, _, _, _) => {
                                h2340
                            }
                        }
                    };
                    match m2343 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m2347 = {
                        let m2346 = match v0.clone() {
                            Adt1::C0(_, h2345, _, _, _, _, _) => {
                                h2345
                            }
                        };
                        match m2346 {
                            Adt54::C0(_, h2344, _, _, _, _, _, _) => {
                                h2344
                            }
                        }
                    };
                    match m2347 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2348, _) => {
                        h2348
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2349, _) => {
                        h2349
                    }
                }, Adt56::C0))?, {
                    let a2353 = {
                        let m2351 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2350) => {
                                h2350
                            }
                        };
                        match m2351 {
                            None => {
                                false
                            }
                            Some(v146) => {
                                f105(match v146 {
                                    Adt61::C0(h2352, _, _, _, _, _) => {
                                        h2352
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a2353) {
                        let m2356 = match v0.clone() {
                            Adt1::C0(h2355, _, _, _, _, _, _) => {
                                h2355
                            }
                        };
                        if match m2356 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2354, _, _, _, _, _, _, _) => {
                                h2354
                            }
                        } {
                            let a2360 = {
                                let m2359 = match v0.clone() {
                                    Adt1::C0(h2358, _, _, _, _, _, _) => {
                                        h2358
                                    }
                                };
                                match m2359 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2357, _, _, _, _, _, _) => {
                                        h2357
                                    }
                                }
                            };
                            bool_not(a2360)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2362 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2361) => {
                            h2361
                        }
                    };
                    match m2362 {
                        None => {
                            false
                        }
                        Some(v147) => {
                            f105(match v147 {
                                Adt61::C0(h2363, _, _, _, _, _) => {
                                    h2363
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a2367 = {
                        let m2365 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2364) => {
                                h2364
                            }
                        };
                        match m2365 {
                            None => {
                                false
                            }
                            Some(v148) => {
                                f105(match v148 {
                                    Adt61::C0(h2366, _, _, _, _, _) => {
                                        h2366
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a2367) {
                        let m2370 = match v0.clone() {
                            Adt1::C0(h2369, _, _, _, _, _, _) => {
                                h2369
                            }
                        };
                        if match m2370 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2368, _, _, _, _, _, _, _) => {
                                h2368
                            }
                        } {
                            let a2374 = {
                                let m2373 = match v0 {
                                    Adt1::C0(h2372, _, _, _, _, _, _) => {
                                        h2372
                                    }
                                };
                                match m2373 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2371, _, _, _, _, _, _) => {
                                        h2371
                                    }
                                }
                            };
                            bool_not(a2374)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))
            }
        }
        Adt55::C9 => {
            let m2378 = {
                let m2377 = match v0.clone() {
                    Adt1::C0(h2376, _, _, _, _, _, _) => {
                        h2376
                    }
                };
                match m2377 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2375, _, _, _, _, _) => {
                        h2375
                    }
                }
            };
            if if match m2378 {
                Adt49::C0 => {
                    false
                }
                Adt49::C1 => {
                    true
                }
                Adt49::C2 => {
                    false
                }
                Adt49::C3 => {
                    false
                }
            } {
                true
            } else {
                f102(v0.clone())
            } {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m2382 = {
                        let m2381 = match v0.clone() {
                            Adt1::C0(_, h2380, _, _, _, _, _) => {
                                h2380
                            }
                        };
                        match m2381 {
                            Adt54::C0(h2379, _, _, _, _, _, _, _) => {
                                h2379
                            }
                        }
                    };
                    match m2382 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m2386 = {
                        let m2385 = match v0.clone() {
                            Adt1::C0(_, h2384, _, _, _, _, _) => {
                                h2384
                            }
                        };
                        match m2385 {
                            Adt54::C0(_, h2383, _, _, _, _, _, _) => {
                                h2383
                            }
                        }
                    };
                    match m2386 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2387, _) => {
                        h2387
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2388, _) => {
                        h2388
                    }
                }, Adt56::C0))?, {
                    let a2392 = {
                        let m2390 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2389) => {
                                h2389
                            }
                        };
                        match m2390 {
                            None => {
                                false
                            }
                            Some(v150) => {
                                f105(match v150 {
                                    Adt61::C0(h2391, _, _, _, _, _) => {
                                        h2391
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a2392) {
                        let m2395 = match v0.clone() {
                            Adt1::C0(h2394, _, _, _, _, _, _) => {
                                h2394
                            }
                        };
                        if match m2395 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2393, _, _, _, _, _, _, _) => {
                                h2393
                            }
                        } {
                            let a2399 = {
                                let m2398 = match v0.clone() {
                                    Adt1::C0(h2397, _, _, _, _, _, _) => {
                                        h2397
                                    }
                                };
                                match m2398 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2396, _, _, _, _, _, _) => {
                                        h2396
                                    }
                                }
                            };
                            bool_not(a2399)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2401 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2400) => {
                            h2400
                        }
                    };
                    match m2401 {
                        None => {
                            false
                        }
                        Some(v151) => {
                            f105(match v151 {
                                Adt61::C0(h2402, _, _, _, _, _) => {
                                    h2402
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a2406 = {
                        let m2404 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2403) => {
                                h2403
                            }
                        };
                        match m2404 {
                            None => {
                                false
                            }
                            Some(v152) => {
                                f105(match v152 {
                                    Adt61::C0(h2405, _, _, _, _, _) => {
                                        h2405
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a2406) {
                        let m2409 = match v0.clone() {
                            Adt1::C0(h2408, _, _, _, _, _, _) => {
                                h2408
                            }
                        };
                        if match m2409 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2407, _, _, _, _, _, _, _) => {
                                h2407
                            }
                        } {
                            let a2413 = {
                                let m2412 = match v0.clone() {
                                    Adt1::C0(h2411, _, _, _, _, _, _) => {
                                        h2411
                                    }
                                };
                                match m2412 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2410, _, _, _, _, _, _) => {
                                        h2410
                                    }
                                }
                            };
                            bool_not(a2413)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt74::C0(Adt56::C2, Str::lit("External basis bytes (optional)"), f42(v0.clone(), Adt63::C1(Adt56::C2)), false, {
                    let m2417 = {
                        let m2416 = match v0.clone() {
                            Adt1::C0(_, h2415, _, _, _, _, _) => {
                                h2415
                            }
                        };
                        match m2416 {
                            Adt54::C0(h2414, _, _, _, _, _, _, _) => {
                                h2414
                            }
                        }
                    };
                    match m2417 {
                        Adt55::C0 => {
                            false
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            false
                        }
                        Adt55::C5 => {
                            false
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                }, {
                    let m2421 = {
                        let m2420 = match v0.clone() {
                            Adt1::C0(_, h2419, _, _, _, _, _) => {
                                h2419
                            }
                        };
                        match m2420 {
                            Adt54::C0(_, _, _, h2418, _, _, _, _) => {
                                h2418
                            }
                        }
                    };
                    match m2421 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C2), f103(v0.clone(), Adt56::C2, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2422, _) => {
                        h2422
                    }
                }, Adt56::C2), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2423, _) => {
                        h2423
                    }
                }, Adt56::C2))?, {
                    let a2427 = {
                        let m2425 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2424) => {
                                h2424
                            }
                        };
                        match m2425 {
                            None => {
                                false
                            }
                            Some(v154) => {
                                f105(match v154 {
                                    Adt61::C0(h2426, _, _, _, _, _) => {
                                        h2426
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a2427) {
                        let m2430 = match v0.clone() {
                            Adt1::C0(h2429, _, _, _, _, _, _) => {
                                h2429
                            }
                        };
                        if match m2430 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2428, _, _, _, _, _, _, _) => {
                                h2428
                            }
                        } {
                            let a2434 = {
                                let m2433 = match v0.clone() {
                                    Adt1::C0(h2432, _, _, _, _, _, _) => {
                                        h2432
                                    }
                                };
                                match m2433 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2431, _, _, _, _, _, _) => {
                                        h2431
                                    }
                                }
                            };
                            bool_not(a2434)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2436 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2435) => {
                            h2435
                        }
                    };
                    match m2436 {
                        None => {
                            false
                        }
                        Some(v155) => {
                            f105(match v155 {
                                Adt61::C0(h2437, _, _, _, _, _) => {
                                    h2437
                                }
                            }, Adt56::C2)
                        }
                    }
                }, {
                    let a2441 = {
                        let m2439 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2438) => {
                                h2438
                            }
                        };
                        match m2439 {
                            None => {
                                false
                            }
                            Some(v156) => {
                                f105(match v156 {
                                    Adt61::C0(h2440, _, _, _, _, _) => {
                                        h2440
                                    }
                                }, Adt56::C2)
                            }
                        }
                    };
                    if bool_not(a2441) {
                        let m2444 = match v0.clone() {
                            Adt1::C0(h2443, _, _, _, _, _, _) => {
                                h2443
                            }
                        };
                        if match m2444 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2442, _, _, _, _, _, _, _) => {
                                h2442
                            }
                        } {
                            let a2448 = {
                                let m2447 = match v0 {
                                    Adt1::C0(h2446, _, _, _, _, _, _) => {
                                        h2446
                                    }
                                };
                                match m2447 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2445, _, _, _, _, _, _) => {
                                        h2445
                                    }
                                }
                            };
                            bool_not(a2448)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil())))
            } else {
                Ok(List::cons(Adt74::C0(Adt56::C0, Str::lit("Input objects in order"), f42(v0.clone(), Adt63::C1(Adt56::C0)), true, {
                    let m2452 = {
                        let m2451 = match v0.clone() {
                            Adt1::C0(_, h2450, _, _, _, _, _) => {
                                h2450
                            }
                        };
                        match m2451 {
                            Adt54::C0(h2449, _, _, _, _, _, _, _) => {
                                h2449
                            }
                        }
                    };
                    match m2452 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            false
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            true
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            true
                        }
                        Adt55::C9 => {
                            true
                        }
                    }
                }, {
                    let m2456 = {
                        let m2455 = match v0.clone() {
                            Adt1::C0(_, h2454, _, _, _, _, _) => {
                                h2454
                            }
                        };
                        match m2455 {
                            Adt54::C0(_, h2453, _, _, _, _, _, _) => {
                                h2453
                            }
                        }
                    };
                    match m2456 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f51(Adt56::C0), f103(v0.clone(), Adt56::C0, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2457, _) => {
                        h2457
                    }
                }, Adt56::C0), 0u64, f104(f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2458, _) => {
                        h2458
                    }
                }, Adt56::C0))?, {
                    let a2462 = {
                        let m2460 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2459) => {
                                h2459
                            }
                        };
                        match m2460 {
                            None => {
                                false
                            }
                            Some(v158) => {
                                f105(match v158 {
                                    Adt61::C0(h2461, _, _, _, _, _) => {
                                        h2461
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a2462) {
                        let m2465 = match v0.clone() {
                            Adt1::C0(h2464, _, _, _, _, _, _) => {
                                h2464
                            }
                        };
                        if match m2465 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2463, _, _, _, _, _, _, _) => {
                                h2463
                            }
                        } {
                            let a2469 = {
                                let m2468 = match v0.clone() {
                                    Adt1::C0(h2467, _, _, _, _, _, _) => {
                                        h2467
                                    }
                                };
                                match m2468 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2466, _, _, _, _, _, _) => {
                                        h2466
                                    }
                                }
                            };
                            bool_not(a2469)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m2471 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h2470) => {
                            h2470
                        }
                    };
                    match m2471 {
                        None => {
                            false
                        }
                        Some(v159) => {
                            f105(match v159 {
                                Adt61::C0(h2472, _, _, _, _, _) => {
                                    h2472
                                }
                            }, Adt56::C0)
                        }
                    }
                }, {
                    let a2476 = {
                        let m2474 = match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2473) => {
                                h2473
                            }
                        };
                        match m2474 {
                            None => {
                                false
                            }
                            Some(v160) => {
                                f105(match v160 {
                                    Adt61::C0(h2475, _, _, _, _, _) => {
                                        h2475
                                    }
                                }, Adt56::C0)
                            }
                        }
                    };
                    if bool_not(a2476) {
                        let m2479 = match v0.clone() {
                            Adt1::C0(h2478, _, _, _, _, _, _) => {
                                h2478
                            }
                        };
                        if match m2479 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2477, _, _, _, _, _, _, _) => {
                                h2477
                            }
                        } {
                            let a2483 = {
                                let m2482 = match v0 {
                                    Adt1::C0(h2481, _, _, _, _, _, _) => {
                                        h2481
                                    }
                                };
                                match m2482 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2480, _, _, _, _, _, _) => {
                                        h2480
                                    }
                                }
                            };
                            bool_not(a2483)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt74>::nil()))
            }
        }
    }
}

pub fn f46(v0: Adt23) -> List<Adt76> {
    List::cons(Adt76::C0(Str::lit("Input bytes"), {
        let m2486 = match v0.clone() {
            Adt23::C0(h2485, _, _, _, _, _, _, _, _, _) => {
                h2485
            }
        };
        match m2486 {
            Adt24::C0(h2484, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2484
            }
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Exact archive bytes"), {
        let m2489 = match v0.clone() {
            Adt23::C0(h2488, _, _, _, _, _, _, _, _, _) => {
                h2488
            }
        };
        match m2489 {
            Adt24::C0(_, h2487, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2487
            }
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Transport bytes"), {
        let m2492 = match v0.clone() {
            Adt23::C0(h2491, _, _, _, _, _, _, _, _, _) => {
                h2491
            }
        };
        match m2492 {
            Adt24::C0(_, _, h2490, _, _, _, _, _, _, _, _, _, _, _) => {
                h2490
            }
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("External basis bytes"), {
        let m2495 = match v0.clone() {
            Adt23::C0(h2494, _, _, _, _, _, _, _, _, _) => {
                h2494
            }
        };
        match m2495 {
            Adt24::C0(_, _, _, h2493, _, _, _, _, _, _, _, _, _, _) => {
                h2493
            }
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Basis transfer bytes"), {
        let m2498 = match v0.clone() {
            Adt23::C0(h2497, _, _, _, _, _, _, _, _, _) => {
                h2497
            }
        };
        match m2498 {
            Adt24::C0(_, _, _, _, h2496, _, _, _, _, _, _, _, _, _) => {
                h2496
            }
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Output bytes"), {
        let m2501 = match v0.clone() {
            Adt23::C0(h2500, _, _, _, _, _, _, _, _, _) => {
                h2500
            }
        };
        match m2501 {
            Adt24::C0(_, _, _, _, _, _, _, _, _, _, _, h2499, _, _) => {
                h2499
            }
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Ordered objects"), {
        let m2504 = match v0.clone() {
            Adt23::C0(h2503, _, _, _, _, _, _, _, _, _) => {
                h2503
            }
        };
        match m2504 {
            Adt24::C0(_, _, _, _, _, _, _, _, _, _, h2502, _, _, _) => {
                h2502
            }
        }
    }, Str::lit("objects")), List::cons(Adt76::C0(Str::lit("Decode work"), {
        let m2507 = match v0.clone() {
            Adt23::C0(h2506, _, _, _, _, _, _, _, _, _) => {
                h2506
            }
        };
        match m2507 {
            Adt24::C0(_, _, _, _, _, h2505, _, _, _, _, _, _, _, _) => {
                h2505
            }
        }
    }, Str::lit("work units")), List::cons(Adt76::C0(Str::lit("Checker work"), {
        let m2510 = match v0.clone() {
            Adt23::C0(h2509, _, _, _, _, _, _, _, _, _) => {
                h2509
            }
        };
        match m2510 {
            Adt24::C0(_, _, _, _, _, _, h2508, _, _, _, _, _, _, _) => {
                h2508
            }
        }
    }, Str::lit("work units")), List::cons(Adt76::C0(Str::lit("Replay work"), {
        let m2513 = match v0.clone() {
            Adt23::C0(h2512, _, _, _, _, _, _, _, _, _) => {
                h2512
            }
        };
        match m2513 {
            Adt24::C0(_, _, _, _, _, _, _, h2511, _, _, _, _, _, _) => {
                h2511
            }
        }
    }, Str::lit("work units")), List::cons(Adt76::C0(Str::lit("Search work"), {
        let m2516 = match v0.clone() {
            Adt23::C0(h2515, _, _, _, _, _, _, _, _, _) => {
                h2515
            }
        };
        match m2516 {
            Adt24::C0(_, _, _, _, _, _, _, _, h2514, _, _, _, _, _) => {
                h2514
            }
        }
    }, Str::lit("work units")), List::cons(Adt76::C0(Str::lit("Peak logical arena bytes"), {
        let m2519 = match v0 {
            Adt23::C0(h2518, _, _, _, _, _, _, _, _, _) => {
                h2518
            }
        };
        match m2519 {
            Adt24::C0(_, _, _, _, _, _, _, _, _, h2517, _, _, _, _) => {
                h2517
            }
        }
    }, Str::lit("bytes")), List::<Adt76>::nil()))))))))))))
}

pub fn f47(v0: Adt24) -> List<Adt76> {
    List::cons(Adt76::C0(Str::lit("Input bytes"), match v0.clone() {
        Adt24::C0(h2520, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h2520
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Exact archive bytes"), match v0.clone() {
        Adt24::C0(_, h2521, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h2521
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Transport bytes"), match v0.clone() {
        Adt24::C0(_, _, h2522, _, _, _, _, _, _, _, _, _, _, _) => {
            h2522
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("External basis bytes"), match v0.clone() {
        Adt24::C0(_, _, _, h2523, _, _, _, _, _, _, _, _, _, _) => {
            h2523
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Basis transfer bytes"), match v0.clone() {
        Adt24::C0(_, _, _, _, h2524, _, _, _, _, _, _, _, _, _) => {
            h2524
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Output bytes"), match v0.clone() {
        Adt24::C0(_, _, _, _, _, _, _, _, _, _, _, h2525, _, _) => {
            h2525
        }
    }, Str::lit("bytes")), List::cons(Adt76::C0(Str::lit("Ordered objects"), match v0.clone() {
        Adt24::C0(_, _, _, _, _, _, _, _, _, _, h2526, _, _, _) => {
            h2526
        }
    }, Str::lit("objects")), List::cons(Adt76::C0(Str::lit("Decode work"), match v0.clone() {
        Adt24::C0(_, _, _, _, _, h2527, _, _, _, _, _, _, _, _) => {
            h2527
        }
    }, Str::lit("work units")), List::cons(Adt76::C0(Str::lit("Checker work"), match v0.clone() {
        Adt24::C0(_, _, _, _, _, _, h2528, _, _, _, _, _, _, _) => {
            h2528
        }
    }, Str::lit("work units")), List::cons(Adt76::C0(Str::lit("Replay work"), match v0.clone() {
        Adt24::C0(_, _, _, _, _, _, _, h2529, _, _, _, _, _, _) => {
            h2529
        }
    }, Str::lit("work units")), List::cons(Adt76::C0(Str::lit("Search work"), match v0.clone() {
        Adt24::C0(_, _, _, _, _, _, _, _, h2530, _, _, _, _, _) => {
            h2530
        }
    }, Str::lit("work units")), List::cons(Adt76::C0(Str::lit("Peak modeled owned bytes"), match v0 {
        Adt24::C0(_, _, _, _, _, _, _, _, _, h2531, _, _, _, _) => {
            h2531
        }
    }, Str::lit("bytes")), List::<Adt76>::nil()))))))))))))
}

pub fn f48(v0: Adt55, v1: Adt23) -> Adt78 {
    f106(v0, match v1.clone() {
        Adt23::C0(_, _, _, h2532, _, _, _, _, _, _) => {
            h2532
        }
    }, Adt29::C0({
        let m2535 = match v1.clone() {
            Adt23::C0(_, h2534, _, _, _, _, _, _, _, _) => {
                h2534
            }
        };
        match m2535 {
            Adt29::C0(h2533, _, _, _, _) => {
                h2533
            }
        }
    }, {
        let m2538 = match v1.clone() {
            Adt23::C0(_, h2537, _, _, _, _, _, _, _, _) => {
                h2537
            }
        };
        match m2538 {
            Adt29::C0(_, h2536, _, _, _) => {
                h2536
            }
        }
    }, {
        let m2541 = match v1.clone() {
            Adt23::C0(_, h2540, _, _, _, _, _, _, _, _) => {
                h2540
            }
        };
        if match m2541 {
            Adt29::C0(_, _, h2539, _, _) => {
                h2539
            }
        } {
            match v1.clone() {
                Adt23::C0(_, _, h2542, _, _, _, _, _, _, _) => {
                    h2542
                }
            }
        } else {
            false
        }
    }, {
        let m2545 = match v1.clone() {
            Adt23::C0(_, h2544, _, _, _, _, _, _, _, _) => {
                h2544
            }
        };
        if match m2545 {
            Adt29::C0(_, _, _, h2543, _) => {
                h2543
            }
        } {
            let m2547 = match v1.clone() {
                Adt23::C0(_, _, _, _, h2546, _, _, _, _, _) => {
                    h2546
                }
            };
            match m2547 {
                Adt30::C0 => {
                    true
                }
                Adt30::C1 => {
                    false
                }
                Adt30::C2 => {
                    false
                }
                Adt30::C3 => {
                    false
                }
            }
        } else {
            false
        }
    }, {
        let m2550 = match v1.clone() {
            Adt23::C0(_, h2549, _, _, _, _, _, _, _, _) => {
                h2549
            }
        };
        if match m2550 {
            Adt29::C0(_, _, _, _, h2548) => {
                h2548
            }
        } {
            let m2552 = f107(match v1 {
                Adt23::C0(_, _, _, _, _, h2551, _, _, _, _) => {
                    h2551
                }
            });
            match m2552 {
                Adt95::C0 => {
                    false
                }
                Adt95::C1 => {
                    true
                }
                Adt95::C2 => {
                    false
                }
                Adt95::C3 => {
                    false
                }
            }
        } else {
            false
        }
    }))
}

pub fn f49(v0: Adt1) -> List<Adt73> {
    let m2556 = {
        let m2555 = match v0.clone() {
            Adt1::C0(h2554, _, _, _, _, _, _) => {
                h2554
            }
        };
        match m2555 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2553, _, _, _, _, _) => {
                h2553
            }
        }
    };
    match m2556 {
        Adt49::C0 => {
            List::<Adt73>::nil()
        }
        Adt49::C1 => {
            List::<Adt73>::nil()
        }
        Adt49::C2 => {
            List::<Adt73>::nil()
        }
        Adt49::C3 => {
            List::cons(Adt73::C0(Str::lit("runAcceptance"), Str::lit("Run acceptance"), f42(v0.clone(), Adt63::C0(Adt55::C8)), {
                let m2559 = match v0.clone() {
                    Adt1::C0(h2558, _, _, _, _, _, _) => {
                        h2558
                    }
                };
                if match m2559 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2557, _, _, _, _, _, _, _) => {
                        h2557
                    }
                } {
                    let a2563 = {
                        let m2562 = match v0.clone() {
                            Adt1::C0(h2561, _, _, _, _, _, _) => {
                                h2561
                            }
                        };
                        match m2562 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2560, _, _, _, _, _, _) => {
                                h2560
                            }
                        }
                    };
                    bool_not(a2563)
                } else {
                    false
                }
            }, true), List::cons(Adt73::C0(Str::lit("runCoreRequest"), Str::lit("Run core request"), f42(v0.clone(), Adt63::C0(Adt55::C9)), {
                let m2566 = match v0.clone() {
                    Adt1::C0(h2565, _, _, _, _, _, _) => {
                        h2565
                    }
                };
                if match m2566 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2564, _, _, _, _, _, _, _) => {
                        h2564
                    }
                } {
                    let a2570 = {
                        let m2569 = match v0 {
                            Adt1::C0(h2568, _, _, _, _, _, _) => {
                                h2568
                            }
                        };
                        match m2569 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2567, _, _, _, _, _, _) => {
                                h2567
                            }
                        }
                    };
                    bool_not(a2570)
                } else {
                    false
                }
            }, true), List::<Adt73>::nil()))
        }
    }
}

pub fn f50(v0: Adt1) -> R<List<Adt79>> {
    let m2574 = {
        let m2573 = match v0.clone() {
            Adt1::C0(h2572, _, _, _, _, _, _) => {
                h2572
            }
        };
        match m2573 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2571, _, _, _, _, _) => {
                h2571
            }
        }
    };
    match m2574 {
        Adt49::C0 => {
            Ok(List::<Adt79>::nil())
        }
        Adt49::C1 => {
            Ok(List::cons(Adt79::C0(Str::lit("limit-decodeWork"), Str::lit("Decode work quota"), f108(Some({
                let m2579 = {
                    let m2578 = match v0.clone() {
                        Adt1::C0(_, h2577, _, _, _, _, _) => {
                            h2577
                        }
                    };
                    match m2578 {
                        Adt54::C0(_, _, _, _, _, _, _, h2576) => {
                            h2576
                        }
                    }
                };
                match m2579 {
                    Adt14::C0(h2575, _, _, _, _, _, _) => {
                        h2575
                    }
                }
            }))?, Str::lit("work units"), false, {
                let a2598 = {
                    let a2597 = {
                        let m2582 = match v0.clone() {
                            Adt1::C0(h2581, _, _, _, _, _, _) => {
                                h2581
                            }
                        };
                        if match m2582 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2580, _, _, _, _, _, _, _) => {
                                h2580
                            }
                        } {
                            let a2586 = {
                                let m2585 = match v0.clone() {
                                    Adt1::C0(h2584, _, _, _, _, _, _) => {
                                        h2584
                                    }
                                };
                                match m2585 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2583, _, _, _, _, _, _) => {
                                        h2583
                                    }
                                }
                            };
                            if bool_not(a2586) {
                                let a2592 = {
                                    let m2591 = {
                                        let m2590 = match v0.clone() {
                                            Adt1::C0(h2589, _, _, _, _, _, _) => {
                                                h2589
                                            }
                                        };
                                        match m2590 {
                                            Adt2::C0(_, h2588, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2588
                                            }
                                        }
                                    };
                                    match m2591 {
                                        Adt3::C0(_, _, h2587, _, _, _) => {
                                            h2587
                                        }
                                    }
                                };
                                if bool_not(a2592) {
                                    let a2596 = {
                                        let m2595 = match v0.clone() {
                                            Adt1::C0(h2594, _, _, _, _, _, _) => {
                                                h2594
                                            }
                                        };
                                        match m2595 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2593, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2593
                                            }
                                        }
                                    };
                                    bool_not(a2596)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2597)
                };
                bool_not(a2598)
            }, f109(v0.clone(), Adt70::C0), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-checkerWork"), Str::lit("Verification work quota"), f108(Some({
                let m2603 = {
                    let m2602 = match v0.clone() {
                        Adt1::C0(_, h2601, _, _, _, _, _) => {
                            h2601
                        }
                    };
                    match m2602 {
                        Adt54::C0(_, _, _, _, _, _, _, h2600) => {
                            h2600
                        }
                    }
                };
                match m2603 {
                    Adt14::C0(_, h2599, _, _, _, _, _) => {
                        h2599
                    }
                }
            }))?, Str::lit("work units"), false, {
                let a2622 = {
                    let a2621 = {
                        let m2606 = match v0.clone() {
                            Adt1::C0(h2605, _, _, _, _, _, _) => {
                                h2605
                            }
                        };
                        if match m2606 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2604, _, _, _, _, _, _, _) => {
                                h2604
                            }
                        } {
                            let a2610 = {
                                let m2609 = match v0.clone() {
                                    Adt1::C0(h2608, _, _, _, _, _, _) => {
                                        h2608
                                    }
                                };
                                match m2609 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2607, _, _, _, _, _, _) => {
                                        h2607
                                    }
                                }
                            };
                            if bool_not(a2610) {
                                let a2616 = {
                                    let m2615 = {
                                        let m2614 = match v0.clone() {
                                            Adt1::C0(h2613, _, _, _, _, _, _) => {
                                                h2613
                                            }
                                        };
                                        match m2614 {
                                            Adt2::C0(_, h2612, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2612
                                            }
                                        }
                                    };
                                    match m2615 {
                                        Adt3::C0(_, _, h2611, _, _, _) => {
                                            h2611
                                        }
                                    }
                                };
                                if bool_not(a2616) {
                                    let a2620 = {
                                        let m2619 = match v0.clone() {
                                            Adt1::C0(h2618, _, _, _, _, _, _) => {
                                                h2618
                                            }
                                        };
                                        match m2619 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2617, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2617
                                            }
                                        }
                                    };
                                    bool_not(a2620)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2621)
                };
                bool_not(a2622)
            }, f109(v0.clone(), Adt70::C1), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-replayWork"), Str::lit("Replay work quota"), f108(Some({
                let m2627 = {
                    let m2626 = match v0.clone() {
                        Adt1::C0(_, h2625, _, _, _, _, _) => {
                            h2625
                        }
                    };
                    match m2626 {
                        Adt54::C0(_, _, _, _, _, _, _, h2624) => {
                            h2624
                        }
                    }
                };
                match m2627 {
                    Adt14::C0(_, _, h2623, _, _, _, _) => {
                        h2623
                    }
                }
            }))?, Str::lit("work units"), false, {
                let a2646 = {
                    let a2645 = {
                        let m2630 = match v0.clone() {
                            Adt1::C0(h2629, _, _, _, _, _, _) => {
                                h2629
                            }
                        };
                        if match m2630 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2628, _, _, _, _, _, _, _) => {
                                h2628
                            }
                        } {
                            let a2634 = {
                                let m2633 = match v0.clone() {
                                    Adt1::C0(h2632, _, _, _, _, _, _) => {
                                        h2632
                                    }
                                };
                                match m2633 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2631, _, _, _, _, _, _) => {
                                        h2631
                                    }
                                }
                            };
                            if bool_not(a2634) {
                                let a2640 = {
                                    let m2639 = {
                                        let m2638 = match v0.clone() {
                                            Adt1::C0(h2637, _, _, _, _, _, _) => {
                                                h2637
                                            }
                                        };
                                        match m2638 {
                                            Adt2::C0(_, h2636, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2636
                                            }
                                        }
                                    };
                                    match m2639 {
                                        Adt3::C0(_, _, h2635, _, _, _) => {
                                            h2635
                                        }
                                    }
                                };
                                if bool_not(a2640) {
                                    let a2644 = {
                                        let m2643 = match v0.clone() {
                                            Adt1::C0(h2642, _, _, _, _, _, _) => {
                                                h2642
                                            }
                                        };
                                        match m2643 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2641, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2641
                                            }
                                        }
                                    };
                                    bool_not(a2644)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2645)
                };
                bool_not(a2646)
            }, f109(v0.clone(), Adt70::C2), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-searchWork"), Str::lit("Search effort"), f108(Some({
                let m2651 = {
                    let m2650 = match v0.clone() {
                        Adt1::C0(_, h2649, _, _, _, _, _) => {
                            h2649
                        }
                    };
                    match m2650 {
                        Adt54::C0(_, _, _, _, _, _, _, h2648) => {
                            h2648
                        }
                    }
                };
                match m2651 {
                    Adt14::C0(_, _, _, h2647, _, _, _) => {
                        h2647
                    }
                }
            }))?, Str::lit("work units"), false, {
                let a2670 = {
                    let a2669 = {
                        let m2654 = match v0.clone() {
                            Adt1::C0(h2653, _, _, _, _, _, _) => {
                                h2653
                            }
                        };
                        if match m2654 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2652, _, _, _, _, _, _, _) => {
                                h2652
                            }
                        } {
                            let a2658 = {
                                let m2657 = match v0.clone() {
                                    Adt1::C0(h2656, _, _, _, _, _, _) => {
                                        h2656
                                    }
                                };
                                match m2657 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2655, _, _, _, _, _, _) => {
                                        h2655
                                    }
                                }
                            };
                            if bool_not(a2658) {
                                let a2664 = {
                                    let m2663 = {
                                        let m2662 = match v0.clone() {
                                            Adt1::C0(h2661, _, _, _, _, _, _) => {
                                                h2661
                                            }
                                        };
                                        match m2662 {
                                            Adt2::C0(_, h2660, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2660
                                            }
                                        }
                                    };
                                    match m2663 {
                                        Adt3::C0(_, _, h2659, _, _, _) => {
                                            h2659
                                        }
                                    }
                                };
                                if bool_not(a2664) {
                                    let a2668 = {
                                        let m2667 = match v0.clone() {
                                            Adt1::C0(h2666, _, _, _, _, _, _) => {
                                                h2666
                                            }
                                        };
                                        match m2667 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2665, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2665
                                            }
                                        }
                                    };
                                    bool_not(a2668)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2669)
                };
                bool_not(a2670)
            }, f109(v0.clone(), Adt70::C3), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-outputBytes"), Str::lit("Output bytes quota"), f108({
                let m2675 = {
                    let m2674 = match v0.clone() {
                        Adt1::C0(_, h2673, _, _, _, _, _) => {
                            h2673
                        }
                    };
                    match m2674 {
                        Adt54::C0(_, _, _, _, _, _, _, h2672) => {
                            h2672
                        }
                    }
                };
                match m2675 {
                    Adt14::C0(_, _, _, _, h2671, _, _) => {
                        h2671
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2694 = {
                    let a2693 = {
                        let m2678 = match v0.clone() {
                            Adt1::C0(h2677, _, _, _, _, _, _) => {
                                h2677
                            }
                        };
                        if match m2678 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2676, _, _, _, _, _, _, _) => {
                                h2676
                            }
                        } {
                            let a2682 = {
                                let m2681 = match v0.clone() {
                                    Adt1::C0(h2680, _, _, _, _, _, _) => {
                                        h2680
                                    }
                                };
                                match m2681 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2679, _, _, _, _, _, _) => {
                                        h2679
                                    }
                                }
                            };
                            if bool_not(a2682) {
                                let a2688 = {
                                    let m2687 = {
                                        let m2686 = match v0.clone() {
                                            Adt1::C0(h2685, _, _, _, _, _, _) => {
                                                h2685
                                            }
                                        };
                                        match m2686 {
                                            Adt2::C0(_, h2684, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2684
                                            }
                                        }
                                    };
                                    match m2687 {
                                        Adt3::C0(_, _, h2683, _, _, _) => {
                                            h2683
                                        }
                                    }
                                };
                                if bool_not(a2688) {
                                    let a2692 = {
                                        let m2691 = match v0.clone() {
                                            Adt1::C0(h2690, _, _, _, _, _, _) => {
                                                h2690
                                            }
                                        };
                                        match m2691 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2689, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2689
                                            }
                                        }
                                    };
                                    bool_not(a2692)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2693)
                };
                bool_not(a2694)
            }, f109(v0.clone(), Adt70::C4), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-ownedBytes"), Str::lit("Logical retained arena bytes quota"), f108(Some({
                let m2699 = {
                    let m2698 = match v0.clone() {
                        Adt1::C0(_, h2697, _, _, _, _, _) => {
                            h2697
                        }
                    };
                    match m2698 {
                        Adt54::C0(_, _, _, _, _, _, _, h2696) => {
                            h2696
                        }
                    }
                };
                match m2699 {
                    Adt14::C0(_, _, _, _, _, h2695, _) => {
                        h2695
                    }
                }
            }))?, Str::lit("bytes"), false, {
                let a2718 = {
                    let a2717 = {
                        let m2702 = match v0.clone() {
                            Adt1::C0(h2701, _, _, _, _, _, _) => {
                                h2701
                            }
                        };
                        if match m2702 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2700, _, _, _, _, _, _, _) => {
                                h2700
                            }
                        } {
                            let a2706 = {
                                let m2705 = match v0.clone() {
                                    Adt1::C0(h2704, _, _, _, _, _, _) => {
                                        h2704
                                    }
                                };
                                match m2705 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2703, _, _, _, _, _, _) => {
                                        h2703
                                    }
                                }
                            };
                            if bool_not(a2706) {
                                let a2712 = {
                                    let m2711 = {
                                        let m2710 = match v0.clone() {
                                            Adt1::C0(h2709, _, _, _, _, _, _) => {
                                                h2709
                                            }
                                        };
                                        match m2710 {
                                            Adt2::C0(_, h2708, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2708
                                            }
                                        }
                                    };
                                    match m2711 {
                                        Adt3::C0(_, _, h2707, _, _, _) => {
                                            h2707
                                        }
                                    }
                                };
                                if bool_not(a2712) {
                                    let a2716 = {
                                        let m2715 = match v0.clone() {
                                            Adt1::C0(h2714, _, _, _, _, _, _) => {
                                                h2714
                                            }
                                        };
                                        match m2715 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2713, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2713
                                            }
                                        }
                                    };
                                    bool_not(a2716)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2717)
                };
                bool_not(a2718)
            }, f109(v0.clone(), Adt70::C5), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-storageTotal"), Str::lit("Total job storage quota"), f108({
                let m2725 = {
                    let m2724 = {
                        let m2723 = match v0.clone() {
                            Adt1::C0(_, h2722, _, _, _, _, _) => {
                                h2722
                            }
                        };
                        match m2723 {
                            Adt54::C0(_, _, _, _, _, _, _, h2721) => {
                                h2721
                            }
                        }
                    };
                    match m2724 {
                        Adt14::C0(_, _, _, _, _, _, h2720) => {
                            h2720
                        }
                    }
                };
                match m2725 {
                    Adt15::C0(h2719, _, _, _, _) => {
                        h2719
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2744 = {
                    let a2743 = {
                        let m2728 = match v0.clone() {
                            Adt1::C0(h2727, _, _, _, _, _, _) => {
                                h2727
                            }
                        };
                        if match m2728 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2726, _, _, _, _, _, _, _) => {
                                h2726
                            }
                        } {
                            let a2732 = {
                                let m2731 = match v0.clone() {
                                    Adt1::C0(h2730, _, _, _, _, _, _) => {
                                        h2730
                                    }
                                };
                                match m2731 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2729, _, _, _, _, _, _) => {
                                        h2729
                                    }
                                }
                            };
                            if bool_not(a2732) {
                                let a2738 = {
                                    let m2737 = {
                                        let m2736 = match v0.clone() {
                                            Adt1::C0(h2735, _, _, _, _, _, _) => {
                                                h2735
                                            }
                                        };
                                        match m2736 {
                                            Adt2::C0(_, h2734, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2734
                                            }
                                        }
                                    };
                                    match m2737 {
                                        Adt3::C0(_, _, h2733, _, _, _) => {
                                            h2733
                                        }
                                    }
                                };
                                if bool_not(a2738) {
                                    let a2742 = {
                                        let m2741 = match v0.clone() {
                                            Adt1::C0(h2740, _, _, _, _, _, _) => {
                                                h2740
                                            }
                                        };
                                        match m2741 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2739, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2739
                                            }
                                        }
                                    };
                                    bool_not(a2742)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2743)
                };
                bool_not(a2744)
            }, f109(v0.clone(), Adt70::C6), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-stagedOutput"), Str::lit("Staged output storage quota"), f108({
                let m2751 = {
                    let m2750 = {
                        let m2749 = match v0.clone() {
                            Adt1::C0(_, h2748, _, _, _, _, _) => {
                                h2748
                            }
                        };
                        match m2749 {
                            Adt54::C0(_, _, _, _, _, _, _, h2747) => {
                                h2747
                            }
                        }
                    };
                    match m2750 {
                        Adt14::C0(_, _, _, _, _, _, h2746) => {
                            h2746
                        }
                    }
                };
                match m2751 {
                    Adt15::C0(_, h2745, _, _, _) => {
                        h2745
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2770 = {
                    let a2769 = {
                        let m2754 = match v0.clone() {
                            Adt1::C0(h2753, _, _, _, _, _, _) => {
                                h2753
                            }
                        };
                        if match m2754 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2752, _, _, _, _, _, _, _) => {
                                h2752
                            }
                        } {
                            let a2758 = {
                                let m2757 = match v0.clone() {
                                    Adt1::C0(h2756, _, _, _, _, _, _) => {
                                        h2756
                                    }
                                };
                                match m2757 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2755, _, _, _, _, _, _) => {
                                        h2755
                                    }
                                }
                            };
                            if bool_not(a2758) {
                                let a2764 = {
                                    let m2763 = {
                                        let m2762 = match v0.clone() {
                                            Adt1::C0(h2761, _, _, _, _, _, _) => {
                                                h2761
                                            }
                                        };
                                        match m2762 {
                                            Adt2::C0(_, h2760, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2760
                                            }
                                        }
                                    };
                                    match m2763 {
                                        Adt3::C0(_, _, h2759, _, _, _) => {
                                            h2759
                                        }
                                    }
                                };
                                if bool_not(a2764) {
                                    let a2768 = {
                                        let m2767 = match v0.clone() {
                                            Adt1::C0(h2766, _, _, _, _, _, _) => {
                                                h2766
                                            }
                                        };
                                        match m2767 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2765, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2765
                                            }
                                        }
                                    };
                                    bool_not(a2768)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2769)
                };
                bool_not(a2770)
            }, f109(v0.clone(), Adt70::C7), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-inputSpool"), Str::lit("Input spool storage quota"), f108({
                let m2777 = {
                    let m2776 = {
                        let m2775 = match v0.clone() {
                            Adt1::C0(_, h2774, _, _, _, _, _) => {
                                h2774
                            }
                        };
                        match m2775 {
                            Adt54::C0(_, _, _, _, _, _, _, h2773) => {
                                h2773
                            }
                        }
                    };
                    match m2776 {
                        Adt14::C0(_, _, _, _, _, _, h2772) => {
                            h2772
                        }
                    }
                };
                match m2777 {
                    Adt15::C0(_, _, h2771, _, _) => {
                        h2771
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2796 = {
                    let a2795 = {
                        let m2780 = match v0.clone() {
                            Adt1::C0(h2779, _, _, _, _, _, _) => {
                                h2779
                            }
                        };
                        if match m2780 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2778, _, _, _, _, _, _, _) => {
                                h2778
                            }
                        } {
                            let a2784 = {
                                let m2783 = match v0.clone() {
                                    Adt1::C0(h2782, _, _, _, _, _, _) => {
                                        h2782
                                    }
                                };
                                match m2783 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2781, _, _, _, _, _, _) => {
                                        h2781
                                    }
                                }
                            };
                            if bool_not(a2784) {
                                let a2790 = {
                                    let m2789 = {
                                        let m2788 = match v0.clone() {
                                            Adt1::C0(h2787, _, _, _, _, _, _) => {
                                                h2787
                                            }
                                        };
                                        match m2788 {
                                            Adt2::C0(_, h2786, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2786
                                            }
                                        }
                                    };
                                    match m2789 {
                                        Adt3::C0(_, _, h2785, _, _, _) => {
                                            h2785
                                        }
                                    }
                                };
                                if bool_not(a2790) {
                                    let a2794 = {
                                        let m2793 = match v0.clone() {
                                            Adt1::C0(h2792, _, _, _, _, _, _) => {
                                                h2792
                                            }
                                        };
                                        match m2793 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2791, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2791
                                            }
                                        }
                                    };
                                    bool_not(a2794)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2795)
                };
                bool_not(a2796)
            }, f109(v0.clone(), Adt70::C8), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-spill"), Str::lit("Spill storage quota"), f108({
                let m2803 = {
                    let m2802 = {
                        let m2801 = match v0.clone() {
                            Adt1::C0(_, h2800, _, _, _, _, _) => {
                                h2800
                            }
                        };
                        match m2801 {
                            Adt54::C0(_, _, _, _, _, _, _, h2799) => {
                                h2799
                            }
                        }
                    };
                    match m2802 {
                        Adt14::C0(_, _, _, _, _, _, h2798) => {
                            h2798
                        }
                    }
                };
                match m2803 {
                    Adt15::C0(_, _, _, h2797, _) => {
                        h2797
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2822 = {
                    let a2821 = {
                        let m2806 = match v0.clone() {
                            Adt1::C0(h2805, _, _, _, _, _, _) => {
                                h2805
                            }
                        };
                        if match m2806 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2804, _, _, _, _, _, _, _) => {
                                h2804
                            }
                        } {
                            let a2810 = {
                                let m2809 = match v0.clone() {
                                    Adt1::C0(h2808, _, _, _, _, _, _) => {
                                        h2808
                                    }
                                };
                                match m2809 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2807, _, _, _, _, _, _) => {
                                        h2807
                                    }
                                }
                            };
                            if bool_not(a2810) {
                                let a2816 = {
                                    let m2815 = {
                                        let m2814 = match v0.clone() {
                                            Adt1::C0(h2813, _, _, _, _, _, _) => {
                                                h2813
                                            }
                                        };
                                        match m2814 {
                                            Adt2::C0(_, h2812, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2812
                                            }
                                        }
                                    };
                                    match m2815 {
                                        Adt3::C0(_, _, h2811, _, _, _) => {
                                            h2811
                                        }
                                    }
                                };
                                if bool_not(a2816) {
                                    let a2820 = {
                                        let m2819 = match v0.clone() {
                                            Adt1::C0(h2818, _, _, _, _, _, _) => {
                                                h2818
                                            }
                                        };
                                        match m2819 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2817, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2817
                                            }
                                        }
                                    };
                                    bool_not(a2820)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2821)
                };
                bool_not(a2822)
            }, f109(v0.clone(), Adt70::C9), Str::lit("decimal")), List::cons(Adt79::C0(Str::lit("limit-publicationCopy"), Str::lit("Publication copy storage quota"), f108({
                let m2829 = {
                    let m2828 = {
                        let m2827 = match v0.clone() {
                            Adt1::C0(_, h2826, _, _, _, _, _) => {
                                h2826
                            }
                        };
                        match m2827 {
                            Adt54::C0(_, _, _, _, _, _, _, h2825) => {
                                h2825
                            }
                        }
                    };
                    match m2828 {
                        Adt14::C0(_, _, _, _, _, _, h2824) => {
                            h2824
                        }
                    }
                };
                match m2829 {
                    Adt15::C0(_, _, _, _, h2823) => {
                        h2823
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2848 = {
                    let a2847 = {
                        let m2832 = match v0.clone() {
                            Adt1::C0(h2831, _, _, _, _, _, _) => {
                                h2831
                            }
                        };
                        if match m2832 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2830, _, _, _, _, _, _, _) => {
                                h2830
                            }
                        } {
                            let a2836 = {
                                let m2835 = match v0.clone() {
                                    Adt1::C0(h2834, _, _, _, _, _, _) => {
                                        h2834
                                    }
                                };
                                match m2835 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2833, _, _, _, _, _, _) => {
                                        h2833
                                    }
                                }
                            };
                            if bool_not(a2836) {
                                let a2842 = {
                                    let m2841 = {
                                        let m2840 = match v0.clone() {
                                            Adt1::C0(h2839, _, _, _, _, _, _) => {
                                                h2839
                                            }
                                        };
                                        match m2840 {
                                            Adt2::C0(_, h2838, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2838
                                            }
                                        }
                                    };
                                    match m2841 {
                                        Adt3::C0(_, _, h2837, _, _, _) => {
                                            h2837
                                        }
                                    }
                                };
                                if bool_not(a2842) {
                                    let a2846 = {
                                        let m2845 = match v0.clone() {
                                            Adt1::C0(h2844, _, _, _, _, _, _) => {
                                                h2844
                                            }
                                        };
                                        match m2845 {
                                            Adt2::C0(_, _, _, _, _, _, _, _, h2843, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2843
                                            }
                                        }
                                    };
                                    bool_not(a2846)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2847)
                };
                bool_not(a2848)
            }, f109(v0, Adt70::C10), Str::lit("decimal")), List::<Adt79>::nil()))))))))))))
        }
        Adt49::C2 => {
            Ok(List::<Adt79>::nil())
        }
        Adt49::C3 => {
            Ok(List::<Adt79>::nil())
        }
    }
}

pub fn f51(v0: Adt56) -> Str {
    let m2849 = v0;
    match m2849 {
        Adt56::C0 => {
            Str::lit("file-input")
        }
        Adt56::C1 => {
            Str::lit("file-archive")
        }
        Adt56::C2 => {
            Str::lit("file-basis")
        }
        Adt56::C3 => {
            Str::lit("file-originals")
        }
        Adt56::C4 => {
            Str::lit("file-checkpoint")
        }
        Adt56::C5 => {
            Str::lit("file-comparison")
        }
    }
}

pub fn f52(v0: Adt2) -> R<Adt85> {
    let a2851 = match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2850, _, _, _, _, _, _) => {
            h2850
        }
    };
    if bool_not(a2851) {
        Ok(Adt85::C0(Adt86::C0))
    } else {
        if match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h2852, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2852
            }
        } {
            Ok(Adt85::C0(Adt86::C1))
        } else {
            if if match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2853, _, _, _) => {
                    h2853
                }
            } {
                true
            } else {
                let m2855 = match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2854) => {
                        h2854
                    }
                };
                match m2855.uncons() {
                    None => {
                        false
                    }
                    Some((_, _)) => {
                        true
                    }
                }
            } {
                Ok(Adt85::C0(Adt86::C5))
            } else {
                let m2857 = match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h2856, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2856
                    }
                };
                if if match m2857 {
                    None => {
                        false
                    }
                    Some(_) => {
                        true
                    }
                } {
                    true
                } else {
                    let m2859 = match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2858, _, _, _, _, _, _, _, _) => {
                            h2858
                        }
                    };
                    match m2859 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                } {
                    Ok(Adt85::C0(Adt86::C4))
                } else {
                    let a2865 = {
                        let a2863 = f110({
                            let m2862 = match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2861, _, _) => {
                                    h2861
                                }
                            };
                            match m2862 {
                                Adt51::C0(h2860, _) => {
                                    h2860
                                }
                            }
                        })?;
                        let a2864 = 0u64;
                        nat_eq(a2863, a2864)
                    };
                    if if bool_not(a2865) {
                        true
                    } else {
                        let a2871 = {
                            let a2869 = f35({
                                let m2868 = match v0 {
                                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2867, _, _) => {
                                        h2867
                                    }
                                };
                                match m2868 {
                                    Adt51::C0(h2866, _) => {
                                        h2866
                                    }
                                }
                            })?;
                            let a2870 = 0u64;
                            nat_eq(a2869, a2870)
                        };
                        bool_not(a2871)
                    } {
                        Ok(Adt85::C0(Adt86::C3))
                    } else {
                        Ok(Adt85::C1)
                    }
                }
            }
        }
    }
}

pub fn f53() -> Adt3 {
    Adt3::C0(0u64, 0u64, false, false, Adt4::C0, Adt5::C0)
}

pub fn f54() -> Adt6 {
    Adt6::C0(Adt7::C0, false, 0u64, false, Adt8::C0)
}

pub fn f55() -> Adt9 {
    Adt9::C0(0u64, false, false, 0u64)
}

pub fn f56() -> Adt51 {
    Adt51::C0(f111(), None::<Adt46>)
}

pub fn f57() -> Adt15 {
    Adt15::C0(None::<u64>, None::<u64>, None::<u64>, None::<u64>, None::<u64>)
}

pub fn f58(v0: Adt1, v1: Adt91, v2: Adt89) -> R<Adt89> {
    let m2877 = {
        let m2876 = {
            let m2875 = match v2.clone() {
                Adt89::C0(h2874, _) => {
                    h2874
                }
            };
            match m2875 {
                Adt1::C0(h2873, _, _, _, _, _, _) => {
                    h2873
                }
            }
        };
        match m2876 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, h2872, _, _, _, _, _, _, _, _, _, _) => {
                h2872
            }
        }
    };
    if match m2877 {
        None => {
            let m2883 = {
                let m2882 = {
                    let m2881 = match v2.clone() {
                        Adt89::C0(h2880, _) => {
                            h2880
                        }
                    };
                    match m2881 {
                        Adt1::C0(h2879, _, _, _, _, _, _) => {
                            h2879
                        }
                    }
                };
                match m2882 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h2878, _, _, _, _, _, _, _, _, _) => {
                        h2878
                    }
                }
            };
            match m2883 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Some(_) => {
            true
        }
    } {
        f31(v0, v2, Adt58::C4)
    } else {
        let m2884 = v1;
        match m2884 {
            Adt91::C0(_) => {
                f31(v0, v2, Adt58::C1)
            }
            Adt91::C1(_) => {
                Ok(v2)
            }
            Adt91::C2(v7, _, _, _, _) => {
                f31(v0, v2, Adt58::C0(v7))
            }
            Adt91::C3(v12) => {
                f31(v0, v2, Adt58::C0(v12))
            }
            Adt91::C4(_) => {
                Ok(v2)
            }
            Adt91::C5 => {
                f31(v0, v2, Adt58::C2)
            }
            Adt91::C6(v14) => {
                let m2885 = v14;
                match m2885 {
                    Adt64::C0 => {
                        f31(v0, v2, Adt58::C2)
                    }
                    Adt64::C1(_) => {
                        f31(v0, v2, Adt58::C5)
                    }
                    Adt64::C2 => {
                        f31(v0, v2, Adt58::C5)
                    }
                    Adt64::C3 => {
                        Ok(v2)
                    }
                    Adt64::C4 => {
                        Ok(v2)
                    }
                    Adt64::C5 => {
                        Ok(v2)
                    }
                    Adt64::C6 => {
                        f31(v0, v2, Adt58::C2)
                    }
                    Adt64::C7(_) => {
                        f31(v0, v2, Adt58::C2)
                    }
                    Adt64::C8 => {
                        f31(v0, v2, Adt58::C2)
                    }
                }
            }
            Adt91::C7(_) => {
                f31(v0, v2, Adt58::C2)
            }
            Adt91::C8(v18, _) => {
                f31(v0, v2, Adt58::C0(v18))
            }
            Adt91::C9(v20, _, _) => {
                f31(v0, v2, Adt58::C0(v20))
            }
            Adt91::C10(_, _, _, _) => {
                Ok(v2)
            }
            Adt91::C11(_, _, _) => {
                Ok(v2)
            }
        }
    }
}

pub fn f59(v0: Adt1, v1: Adt54, v2: Adt55) -> R<Adt89> {
    f112(v0, Adt54::C0(v2, match v1.clone() {
        Adt54::C0(_, h2886, _, _, _, _, _, _) => {
            h2886
        }
    }, match v1.clone() {
        Adt54::C0(_, _, h2887, _, _, _, _, _) => {
            h2887
        }
    }, match v1.clone() {
        Adt54::C0(_, _, _, h2888, _, _, _, _) => {
            h2888
        }
    }, match v1.clone() {
        Adt54::C0(_, _, _, _, h2889, _, _, _) => {
            h2889
        }
    }, match v1.clone() {
        Adt54::C0(_, _, _, _, _, h2890, _, _) => {
            h2890
        }
    }, match v1.clone() {
        Adt54::C0(_, _, _, _, _, _, h2891, _) => {
            h2891
        }
    }, match v1 {
        Adt54::C0(_, _, _, _, _, _, _, h2892) => {
            h2892
        }
    }))
}

pub fn f60(v0: Adt1, v1: Adt56) -> R<Adt89> {
    let m2895 = match v0.clone() {
        Adt1::C0(h2894, _, _, _, _, _, _) => {
            h2894
        }
    };
    if if match m2895 {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2893, _, _, _, _, _, _, _) => {
            h2893
        }
    } {
        let a2899 = {
            let m2898 = match v0.clone() {
                Adt1::C0(h2897, _, _, _, _, _, _) => {
                    h2897
                }
            };
            match m2898 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2896, _, _, _, _, _, _) => {
                    h2896
                }
            }
        };
        bool_not(a2899)
    } else {
        false
    } {
        Ok(Adt89::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h2900, _, _, _, _, _, _) => {
                h2900
            }
        }, match v0.clone() {
            Adt1::C0(_, h2901, _, _, _, _, _) => {
                h2901
            }
        }, {
            let a2903 = match v0.clone() {
                Adt1::C0(_, _, h2902, _, _, _, _) => {
                    h2902
                }
            };
            let a2904 = 1u64;
            nat_add(a2903, a2904)?
        }, Some(v1.clone()), match v0.clone() {
            Adt1::C0(_, _, _, _, h2905, _, _) => {
                h2905
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h2906, _) => {
                h2906
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h2907) => {
                h2907
            }
        }), List::cons(Adt80::C1(v1, f84(match v0.clone() {
            Adt1::C0(h2908, _, _, _, _, _, _) => {
                h2908
            }
        }), {
            let a2910 = match v0 {
                Adt1::C0(_, _, h2909, _, _, _, _) => {
                    h2909
                }
            };
            let a2911 = 1u64;
            nat_add(a2910, a2911)?
        }), List::<Adt80>::nil())))
    } else {
        Ok(Adt89::C0(v0, List::<Adt80>::nil()))
    }
}

pub fn f61(v0: Adt1, v1: Adt56, v2: Adt53, v3: u64, v4: Adt12) -> bool {
    if f20(match v0.clone() {
        Adt1::C0(h2912, _, _, _, _, _, _) => {
            h2912
        }
    }, v2) {
        let a2914 = match v0.clone() {
            Adt1::C0(_, _, h2913, _, _, _, _) => {
                h2913
            }
        };
        let a2915 = v3;
        if nat_eq(a2914, a2915) {
            let a2920 = match v4 {
                Adt12::C0(h2916, _, _) => {
                    h2916
                }
            };
            let a2921 = {
                let m2919 = match v0.clone() {
                    Adt1::C0(h2918, _, _, _, _, _, _) => {
                        h2918
                    }
                };
                match m2919 {
                    Adt2::C0(h2917, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2917
                    }
                }
            };
            if nat_eq(a2920, a2921) {
                let m2923 = match v0 {
                    Adt1::C0(_, _, _, h2922, _, _, _) => {
                        h2922
                    }
                };
                match m2923 {
                    None => {
                        false
                    }
                    Some(v5) => {
                        f105(v5, v1)
                    }
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f62(p2927: List<Adt60>) -> bool {
    let m2926 = p2927;
    {
        let mut m2926 = m2926;
        loop {
            let step = {
                let v0 = m2926;
                let m2924 = v0;
                match m2924.uncons() {
                    None => {
                        Err::<List<Adt60>, bool>(true)
                    }
                    Some((v1, v2)) => {
                        if f113(v2.clone(), match v1 {
                            Adt60::C0(h2925, _, _) => {
                                h2925
                            }
                        }) {
                            Err::<List<Adt60>, bool>(false)
                        } else {
                            Ok::<List<Adt60>, bool>(v2)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m2926 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f63(v0: Adt1, v1: Adt56, v2: Adt12, v3: List<Adt60>) -> R<Adt89> {
    Ok(Adt89::C0(Adt1::C0({
        let m2931 = {
            let m2930 = f64(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m2930 {
                Adt89::C0(h2929, _) => {
                    h2929
                }
            }
        };
        match m2931 {
            Adt1::C0(h2928, _, _, _, _, _, _) => {
                h2928
            }
        }
    }, {
        let m2935 = {
            let m2934 = f64(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m2934 {
                Adt89::C0(h2933, _) => {
                    h2933
                }
            }
        };
        match m2935 {
            Adt1::C0(_, h2932, _, _, _, _, _) => {
                h2932
            }
        }
    }, {
        let m2939 = {
            let m2938 = f64(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m2938 {
                Adt89::C0(h2937, _) => {
                    h2937
                }
            }
        };
        match m2939 {
            Adt1::C0(_, _, h2936, _, _, _, _) => {
                h2936
            }
        }
    }, {
        let m2943 = {
            let m2942 = f64(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m2942 {
                Adt89::C0(h2941, _) => {
                    h2941
                }
            }
        };
        match m2943 {
            Adt1::C0(_, _, _, h2940, _, _, _) => {
                h2940
            }
        }
    }, {
        let m2947 = {
            let m2946 = f64(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m2946 {
                Adt89::C0(h2945, _) => {
                    h2945
                }
            }
        };
        match m2947 {
            Adt1::C0(_, _, _, _, h2944, _, _) => {
                h2944
            }
        }
    }, f65(match v0.clone() {
        Adt1::C0(_, _, _, _, _, h2948, _) => {
            h2948
        }
    }, v1.clone(), v3), {
        let m2952 = {
            let m2951 = f64(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m2951 {
                Adt89::C0(h2950, _) => {
                    h2950
                }
            }
        };
        match m2952 {
            Adt1::C0(_, _, _, _, _, _, h2949) => {
                h2949
            }
        }
    }), {
        let m2954 = f64(v0, v1, Some(v2))?;
        match m2954 {
            Adt89::C0(_, h2953) => {
                h2953
            }
        }
    }))
}

pub fn f64(v0: Adt1, v1: Adt56, v2: Option<Adt12>) -> R<Adt89> {
    Ok(Adt89::C0({
        let m2957 = f112(v0.clone(), f76(match v0.clone() {
            Adt1::C0(_, h2956, _, _, _, _, _) => {
                h2956
            }
        }, v1.clone(), v2.clone()))?;
        match m2957 {
            Adt89::C0(h2955, _) => {
                h2955
            }
        }
    }, f78(f114(f115(f116(match v0.clone() {
        Adt1::C0(_, h2958, _, _, _, _, _) => {
            h2958
        }
    }, v1), v2), {
        let m2961 = f28(match v0 {
            Adt1::C0(h2960, _, _, _, _, _, _) => {
                h2960
            }
        }, Adt92::C1)?;
        match m2961 {
            Adt94::C0(_, h2959) => {
                h2959
            }
        }
    }))))
}

pub fn f65(v0: List<Adt59>, v1: Adt56, v2: List<Adt60>) -> List<Adt59> {
    let m2962 = v0;
    match m2962.uncons() {
        None => {
            List::cons(Adt59::C0(v1, v2), List::<Adt59>::nil())
        }
        Some((v3, v4)) => {
            if f105(match v3.clone() {
                Adt59::C0(h2963, _) => {
                    h2963
                }
            }, v1.clone()) {
                List::cons(Adt59::C0(v1, v2), v4)
            } else {
                List::cons(v3, f65(v4, v1, v2))
            }
        }
    }
}

pub fn f66(v0: Adt1, v1: Adt54, v2: Adt14) -> R<Adt89> {
    f112(v0, Adt54::C0(match v1.clone() {
        Adt54::C0(h2964, _, _, _, _, _, _, _) => {
            h2964
        }
    }, match v1.clone() {
        Adt54::C0(_, h2965, _, _, _, _, _, _) => {
            h2965
        }
    }, match v1.clone() {
        Adt54::C0(_, _, h2966, _, _, _, _, _) => {
            h2966
        }
    }, match v1.clone() {
        Adt54::C0(_, _, _, h2967, _, _, _, _) => {
            h2967
        }
    }, match v1.clone() {
        Adt54::C0(_, _, _, _, h2968, _, _, _) => {
            h2968
        }
    }, match v1.clone() {
        Adt54::C0(_, _, _, _, _, h2969, _, _) => {
            h2969
        }
    }, match v1 {
        Adt54::C0(_, _, _, _, _, _, h2970, _) => {
            h2970
        }
    }, v2))
}

pub fn f67(v0: Adt2, v1: Adt10) -> R<Adt94> {
    if match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2971, _, _, _, _, _, _) => {
            h2971
        }
    } {
        Ok(Adt94::C0(Adt2::C0(match v0.clone() {
            Adt2::C0(h2972, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2972
            }
        }, match v0.clone() {
            Adt2::C0(_, h2973, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2973
            }
        }, match v0.clone() {
            Adt2::C0(_, _, h2974, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2974
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, h2975, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2975
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, h2976, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2976
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, h2977, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2977
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, h2978, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2978
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, h2979, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2979
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h2980, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2980
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, h2981, _, _, _, _, _, _, _, _, _, _, _) => {
                h2981
            }
        }, Some(Adt42::C10(Adt44::C1)), match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h2982, _, _, _, _, _, _, _, _, _) => {
                h2982
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2983, _, _, _, _, _, _, _, _) => {
                h2983
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2984, _, _, _, _, _, _, _) => {
                h2984
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2985, _, _, _, _, _, _) => {
                h2985
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2986, _, _, _, _, _) => {
                h2986
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2987, _, _, _, _) => {
                h2987
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2988, _, _, _) => {
                h2988
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2989, _, _) => {
                h2989
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2990, _) => {
                h2990
            }
        }, match v0 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2991) => {
                h2991
            }
        }), List::<Adt81>::nil()))
    } else {
        let a2993 = match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2992, _, _, _, _, _, _, _) => {
                h2992
            }
        };
        if bool_not(a2993) {
            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h2994, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2994
                }
            }, match v0.clone() {
                Adt2::C0(_, h2995, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2995
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h2996, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2996
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h2997, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2997
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h2998, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2998
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h2999, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2999
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h3000, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3000
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h3001, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3001
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h3002, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3002
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h3003, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3003
                }
            }, Some(Adt42::C10(Adt44::C2)), match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3004, _, _, _, _, _, _, _, _, _) => {
                    h3004
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3005, _, _, _, _, _, _, _, _) => {
                    h3005
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3006, _, _, _, _, _, _, _) => {
                    h3006
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3007, _, _, _, _, _, _) => {
                    h3007
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3008, _, _, _, _, _) => {
                    h3008
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3009, _, _, _, _) => {
                    h3009
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3010, _, _, _) => {
                    h3010
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3011, _, _) => {
                    h3011
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3012, _) => {
                    h3012
                }
            }, match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3013) => {
                    h3013
                }
            }), List::<Adt81>::nil()))
        } else {
            let m3016 = match v0.clone() {
                Adt2::C0(_, h3015, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3015
                }
            };
            if match m3016 {
                Adt3::C0(_, _, h3014, _, _, _) => {
                    h3014
                }
            } {
                Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h3017, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3017
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h3018, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3018
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h3019, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3019
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h3020, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3020
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h3021, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3021
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h3022, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3022
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h3023, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3023
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h3024, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3024
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h3025, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3025
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h3026, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3026
                    }
                }, Some(Adt42::C10(Adt44::C0)), match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3027, _, _, _, _, _, _, _, _, _) => {
                        h3027
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3028, _, _, _, _, _, _, _, _) => {
                        h3028
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3029, _, _, _, _, _, _, _) => {
                        h3029
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3030, _, _, _, _, _, _) => {
                        h3030
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3031, _, _, _, _, _) => {
                        h3031
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3032, _, _, _, _) => {
                        h3032
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3033, _, _, _) => {
                        h3033
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3034, _, _) => {
                        h3034
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3035, _) => {
                        h3035
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3036) => {
                        h3036
                    }
                }), List::<Adt81>::nil()))
            } else {
                if match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h3037, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3037
                    }
                } {
                    Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                        Adt2::C0(h3038, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3038
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, h3039, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3039
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, h3040, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3040
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, h3041, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3041
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, h3042, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3042
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, h3043, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3043
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, h3044, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3044
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, h3045, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3045
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, h3046, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3046
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, h3047, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3047
                        }
                    }, Some(Adt42::C10(Adt44::C6)), match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3048, _, _, _, _, _, _, _, _, _) => {
                            h3048
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3049, _, _, _, _, _, _, _, _) => {
                            h3049
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3050, _, _, _, _, _, _, _) => {
                            h3050
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3051, _, _, _, _, _, _) => {
                            h3051
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3052, _, _, _, _, _) => {
                            h3052
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3053, _, _, _, _) => {
                            h3053
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3054, _, _, _) => {
                            h3054
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3055, _, _) => {
                            h3055
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3056, _) => {
                            h3056
                        }
                    }, match v0 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3057) => {
                            h3057
                        }
                    }), List::<Adt81>::nil()))
                } else {
                    Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                        Adt2::C0(h3058, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3058
                        }
                    }, f117(match v0.clone() {
                        Adt2::C0(_, h3059, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3059
                        }
                    })?, f54(), f55(), Some(v1.clone()), None::<Adt23>, Adt41::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt12>, false, false, None::<Adt42>, None::<Adt48>, None::<Adt12>, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3060, _, _, _, _, _, _, _) => {
                            h3060
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3061, _, _, _, _, _, _) => {
                            h3061
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3062, _, _, _, _, _) => {
                            h3062
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3063, _, _, _, _) => {
                            h3063
                        }
                    }, true, f56(), None::<Adt24>, f118(v0.clone())), f114(List::cons(Adt81::C0(f84(Adt2::C0(match v0.clone() {
                        Adt2::C0(h3064, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3064
                        }
                    }, f117(match v0.clone() {
                        Adt2::C0(_, h3065, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3065
                        }
                    })?, f54(), f55(), Some(v1.clone()), None::<Adt23>, Adt41::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt12>, false, false, None::<Adt42>, None::<Adt48>, None::<Adt12>, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3066, _, _, _, _, _, _, _) => {
                            h3066
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3067, _, _, _, _, _, _) => {
                            h3067
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3068, _, _, _, _, _) => {
                            h3068
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3069, _, _, _, _) => {
                            h3069
                        }
                    }, true, f56(), None::<Adt24>, f118(v0.clone()))), v1), List::<Adt81>::nil()), f119(v0))))
                }
            }
        }
    }
}

pub fn f68(v0: Adt1, v1: Adt64) -> R<Adt89> {
    let m3070 = v1;
    match m3070 {
        Adt64::C0 => {
            Ok(f27(v0.clone(), match v0.clone() {
                Adt1::C0(_, h3071, _, _, _, _, _) => {
                    h3071
                }
            }, f28(match v0 {
                Adt1::C0(h3072, _, _, _, _, _, _) => {
                    h3072
                }
            }, Adt92::C2)?))
        }
        Adt64::C1(v2) => {
            Ok(f27(v0.clone(), match v0.clone() {
                Adt1::C0(_, h3073, _, _, _, _, _) => {
                    h3073
                }
            }, f28(match v0 {
                Adt1::C0(h3074, _, _, _, _, _, _) => {
                    h3074
                }
            }, Adt92::C3(v2))?))
        }
        Adt64::C2 => {
            Ok(f27(v0.clone(), match v0.clone() {
                Adt1::C0(_, h3075, _, _, _, _, _) => {
                    h3075
                }
            }, f28(match v0 {
                Adt1::C0(h3076, _, _, _, _, _, _) => {
                    h3076
                }
            }, Adt92::C4)?))
        }
        Adt64::C3 => {
            f120(v0)
        }
        Adt64::C4 => {
            f120(v0)
        }
        Adt64::C5 => {
            f120(v0)
        }
        Adt64::C6 => {
            Ok(f27(v0.clone(), match v0.clone() {
                Adt1::C0(_, h3077, _, _, _, _, _) => {
                    h3077
                }
            }, f28(match v0 {
                Adt1::C0(h3078, _, _, _, _, _, _) => {
                    h3078
                }
            }, Adt92::C18)?))
        }
        Adt64::C7(v3) => {
            Ok(f27(v0.clone(), match v0.clone() {
                Adt1::C0(_, h3079, _, _, _, _, _) => {
                    h3079
                }
            }, f28(match v0 {
                Adt1::C0(h3080, _, _, _, _, _, _) => {
                    h3080
                }
            }, Adt92::C14(v3))?))
        }
        Adt64::C8 => {
            Ok(f27(v0.clone(), match v0.clone() {
                Adt1::C0(_, h3081, _, _, _, _, _) => {
                    h3081
                }
            }, f28(match v0 {
                Adt1::C0(h3082, _, _, _, _, _, _) => {
                    h3082
                }
            }, Adt92::C20)?))
        }
    }
}

pub fn f69(v0: Adt1, v1: u64) -> R<Adt89> {
    let m3087 = {
        let m3086 = match v0.clone() {
            Adt1::C0(h3085, _, _, _, _, _, _) => {
                h3085
            }
        };
        match m3086 {
            Adt2::C0(_, h3084, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3084
            }
        }
    };
    if match m3087 {
        Adt3::C0(_, _, h3083, _, _, _) => {
            h3083
        }
    } {
        Ok(f27(v0.clone(), match v0.clone() {
            Adt1::C0(_, h3088, _, _, _, _, _) => {
                h3088
            }
        }, f86(match v0 {
            Adt1::C0(h3089, _, _, _, _, _, _) => {
                h3089
            }
        }, v1)))
    } else {
        let m3093 = {
            let m3092 = match v0.clone() {
                Adt1::C0(h3091, _, _, _, _, _, _) => {
                    h3091
                }
            };
            match m3092 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3090, _, _, _, _, _, _, _, _) => {
                    h3090
                }
            }
        };
        match m3093 {
            None => {
                Ok(f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h3094, _, _, _, _, _) => {
                        h3094
                    }
                }, f32(match v0 {
                    Adt1::C0(h3095, _, _, _, _, _, _) => {
                        h3095
                    }
                }, Adt42::C10(Adt44::C4))))
            }
            Some(v2) => {
                let m3099 = {
                    let m3098 = match v0.clone() {
                        Adt1::C0(_, h3097, _, _, _, _, _) => {
                            h3097
                        }
                    };
                    match m3098 {
                        Adt54::C0(_, h3096, _, _, _, _, _, _) => {
                            h3096
                        }
                    }
                };
                match m3099 {
                    None => {
                        Ok(f27(v0.clone(), match v0.clone() {
                            Adt1::C0(_, h3100, _, _, _, _, _) => {
                                h3100
                            }
                        }, f32(match v0 {
                            Adt1::C0(h3101, _, _, _, _, _, _) => {
                                h3101
                            }
                        }, Adt42::C10(Adt44::C14))))
                    }
                    Some(v3) => {
                        Ok(f27(v0.clone(), match v0.clone() {
                            Adt1::C0(_, h3102, _, _, _, _, _) => {
                                h3102
                            }
                        }, f121(match v0.clone() {
                            Adt1::C0(h3103, _, _, _, _, _, _) => {
                                h3103
                            }
                        }, Adt18::C0(v3, v2, Adt13::C0(Adt14::C0({
                            let m3108 = {
                                let m3107 = match v0.clone() {
                                    Adt1::C0(_, h3106, _, _, _, _, _) => {
                                        h3106
                                    }
                                };
                                match m3107 {
                                    Adt54::C0(_, _, _, _, _, _, _, h3105) => {
                                        h3105
                                    }
                                }
                            };
                            match m3108 {
                                Adt14::C0(h3104, _, _, _, _, _, _) => {
                                    h3104
                                }
                            }
                        }, {
                            let m3113 = {
                                let m3112 = match v0.clone() {
                                    Adt1::C0(_, h3111, _, _, _, _, _) => {
                                        h3111
                                    }
                                };
                                match m3112 {
                                    Adt54::C0(_, _, _, _, _, _, _, h3110) => {
                                        h3110
                                    }
                                }
                            };
                            match m3113 {
                                Adt14::C0(_, h3109, _, _, _, _, _) => {
                                    h3109
                                }
                            }
                        }, {
                            let m3118 = {
                                let m3117 = match v0.clone() {
                                    Adt1::C0(_, h3116, _, _, _, _, _) => {
                                        h3116
                                    }
                                };
                                match m3117 {
                                    Adt54::C0(_, _, _, _, _, _, _, h3115) => {
                                        h3115
                                    }
                                }
                            };
                            match m3118 {
                                Adt14::C0(_, _, h3114, _, _, _, _) => {
                                    h3114
                                }
                            }
                        }, {
                            let a3124 = {
                                let m3123 = {
                                    let m3122 = match v0.clone() {
                                        Adt1::C0(_, h3121, _, _, _, _, _) => {
                                            h3121
                                        }
                                    };
                                    match m3122 {
                                        Adt54::C0(_, _, _, _, _, _, _, h3120) => {
                                            h3120
                                        }
                                    }
                                };
                                match m3123 {
                                    Adt14::C0(_, _, _, h3119, _, _, _) => {
                                        h3119
                                    }
                                }
                            };
                            let a3125 = v1;
                            nat_add(a3124, a3125)?
                        }, {
                            let m3130 = {
                                let m3129 = match v0.clone() {
                                    Adt1::C0(_, h3128, _, _, _, _, _) => {
                                        h3128
                                    }
                                };
                                match m3129 {
                                    Adt54::C0(_, _, _, _, _, _, _, h3127) => {
                                        h3127
                                    }
                                }
                            };
                            match m3130 {
                                Adt14::C0(_, _, _, _, h3126, _, _) => {
                                    h3126
                                }
                            }
                        }, {
                            let m3135 = {
                                let m3134 = match v0.clone() {
                                    Adt1::C0(_, h3133, _, _, _, _, _) => {
                                        h3133
                                    }
                                };
                                match m3134 {
                                    Adt54::C0(_, _, _, _, _, _, _, h3132) => {
                                        h3132
                                    }
                                }
                            };
                            match m3135 {
                                Adt14::C0(_, _, _, _, _, h3131, _) => {
                                    h3131
                                }
                            }
                        }, {
                            let m3140 = {
                                let m3139 = match v0.clone() {
                                    Adt1::C0(_, h3138, _, _, _, _, _) => {
                                        h3138
                                    }
                                };
                                match m3139 {
                                    Adt54::C0(_, _, _, _, _, _, _, h3137) => {
                                        h3137
                                    }
                                }
                            };
                            match m3140 {
                                Adt14::C0(_, _, _, _, _, _, h3136) => {
                                    h3136
                                }
                            }
                        }), {
                            let m3143 = match v0 {
                                Adt1::C0(_, h3142, _, _, _, _, _) => {
                                    h3142
                                }
                            };
                            match m3143 {
                                Adt54::C0(_, _, _, h3141, _, _, _, _) => {
                                    h3141
                                }
                            }
                        })))?))
                    }
                }
            }
        }
    }
}

pub fn f70(v0: Adt1, v1: Adt56, v2: List<Adt60>) -> R<Adt89> {
    let m3145 = match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h3144) => {
            h3144
        }
    };
    match m3145 {
        None => {
            let m3147 = f116(match v0.clone() {
                Adt1::C0(_, h3146, _, _, _, _, _) => {
                    h3146
                }
            }, v1.clone());
            match m3147 {
                None => {
                    Ok(Adt89::C0(v0, List::<Adt80>::nil()))
                }
                Some(v4) => {
                    Ok(Adt89::C0(Adt1::C0({
                        let m3150 = f28(match v0.clone() {
                            Adt1::C0(h3149, _, _, _, _, _, _) => {
                                h3149
                            }
                        }, Adt92::C1)?;
                        match m3150 {
                            Adt94::C0(h3148, _) => {
                                h3148
                            }
                        }
                    }, f76(match v0.clone() {
                        Adt1::C0(_, h3151, _, _, _, _, _) => {
                            h3151
                        }
                    }, v1.clone(), None::<Adt12>), {
                        let a3153 = match v0.clone() {
                            Adt1::C0(_, _, h3152, _, _, _, _) => {
                                h3152
                            }
                        };
                        let a3154 = 1u64;
                        nat_add(a3153, a3154)?
                    }, None::<Adt56>, match v0.clone() {
                        Adt1::C0(_, _, _, _, h3155, _, _) => {
                            h3155
                        }
                    }, f65(match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h3156, _) => {
                            h3156
                        }
                    }, v1.clone(), v2.clone()), Some(Adt61::C0(v1.clone(), f84({
                        let m3159 = f28(match v0.clone() {
                            Adt1::C0(h3158, _, _, _, _, _, _) => {
                                h3158
                            }
                        }, Adt92::C1)?;
                        match m3159 {
                            Adt94::C0(h3157, _) => {
                                h3157
                            }
                        }
                    }), {
                        let a3161 = match v0.clone() {
                            Adt1::C0(_, _, h3160, _, _, _, _) => {
                                h3160
                            }
                        };
                        let a3162 = 1u64;
                        nat_add(a3161, a3162)?
                    }, v4.clone(), v2.clone(), f72(match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h3163, _) => {
                            h3163
                        }
                    }, v1.clone())))), List::cons(Adt80::C2(Adt61::C0(v1.clone(), f84({
                        let m3166 = f28(match v0.clone() {
                            Adt1::C0(h3165, _, _, _, _, _, _) => {
                                h3165
                            }
                        }, Adt92::C1)?;
                        match m3166 {
                            Adt94::C0(h3164, _) => {
                                h3164
                            }
                        }
                    }), {
                        let a3168 = match v0.clone() {
                            Adt1::C0(_, _, h3167, _, _, _, _) => {
                                h3167
                            }
                        };
                        let a3169 = 1u64;
                        nat_add(a3168, a3169)?
                    }, v4, v2, f72(match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h3170, _) => {
                            h3170
                        }
                    }, v1))), f78({
                        let m3173 = f28(match v0 {
                            Adt1::C0(h3172, _, _, _, _, _, _) => {
                                h3172
                            }
                        }, Adt92::C1)?;
                        match m3173 {
                            Adt94::C0(_, h3171) => {
                                h3171
                            }
                        }
                    }))))
                }
            }
        }
        Some(_) => {
            Ok(Adt89::C0(v0, List::<Adt80>::nil()))
        }
    }
}

pub fn f71(v0: List<Adt60>, v1: u64) -> List<Adt60> {
    let m3174 = v0;
    match m3174.uncons() {
        None => {
            List::<Adt60>::nil()
        }
        Some((v2, v3)) => {
            let a3176 = match v2.clone() {
                Adt60::C0(h3175, _, _) => {
                    h3175
                }
            };
            let a3177 = v1;
            if nat_eq(a3176, a3177) {
                v3
            } else {
                List::cons(v2, f71(v3, v1))
            }
        }
    }
}

pub fn f72(p3182: List<Adt59>, v1: Adt56) -> List<Adt60> {
    let m3181 = p3182;
    {
        let mut m3181 = m3181;
        loop {
            let step = {
                let v0 = m3181;
                let m3178 = v0;
                match m3178.uncons() {
                    None => {
                        Err::<List<Adt59>, List<Adt60>>(List::<Adt60>::nil())
                    }
                    Some((v2, v3)) => {
                        if f105(match v2.clone() {
                            Adt59::C0(h3179, _) => {
                                h3179
                            }
                        }, v1.clone()) {
                            match v2 {
                                Adt59::C0(_, h3180) => {
                                    Err::<List<Adt59>, List<Adt60>>(h3180)
                                }
                            }
                        } else {
                            Ok::<List<Adt59>, List<Adt60>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m3181 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f73(v0: List<Adt60>, v1: u64, v2: u64) -> List<Adt60> {
    let m3183 = f122(v0.clone(), v1);
    match m3183 {
        None => {
            v0
        }
        Some(v3) => {
            f123(f71(v0, v1), v2, v3)
        }
    }
}

pub fn f74(v0: Adt1, v1: Adt53, v2: u64, v3: Adt12, v4: List<Adt60>) -> R<Adt89> {
    let m3185 = match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h3184) => {
            h3184
        }
    };
    match m3185 {
        None => {
            Ok(Adt89::C0(v0, List::cons(Adt80::C0(Adt81::C6(v3)), List::<Adt80>::nil())))
        }
        Some(v5) => {
            if if f20(match v0.clone() {
                Adt1::C0(h3186, _, _, _, _, _, _) => {
                    h3186
                }
            }, v1) {
                let a3188 = match v5.clone() {
                    Adt61::C0(_, _, h3187, _, _, _) => {
                        h3187
                    }
                };
                let a3189 = v2;
                if nat_eq(a3188, a3189) {
                    let a3194 = match v3.clone() {
                        Adt12::C0(h3190, _, _) => {
                            h3190
                        }
                    };
                    let a3195 = {
                        let m3193 = match v0.clone() {
                            Adt1::C0(h3192, _, _, _, _, _, _) => {
                                h3192
                            }
                        };
                        match m3193 {
                            Adt2::C0(h3191, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3191
                            }
                        }
                    };
                    if nat_eq(a3194, a3195) {
                        if f62(v4.clone()) {
                            f124(match v5.clone() {
                                Adt61::C0(_, _, _, _, h3196, _) => {
                                    h3196
                                }
                            }, v4.clone())
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(Adt89::C0(Adt1::C0({
                    let m3201 = {
                        let m3200 = f63(v0.clone(), match v5.clone() {
                            Adt61::C0(h3199, _, _, _, _, _) => {
                                h3199
                            }
                        }, v3.clone(), v4.clone())?;
                        match m3200 {
                            Adt89::C0(h3198, _) => {
                                h3198
                            }
                        }
                    };
                    match m3201 {
                        Adt1::C0(h3197, _, _, _, _, _, _) => {
                            h3197
                        }
                    }
                }, {
                    let m3206 = {
                        let m3205 = f63(v0.clone(), match v5.clone() {
                            Adt61::C0(h3204, _, _, _, _, _) => {
                                h3204
                            }
                        }, v3.clone(), v4.clone())?;
                        match m3205 {
                            Adt89::C0(h3203, _) => {
                                h3203
                            }
                        }
                    };
                    match m3206 {
                        Adt1::C0(_, h3202, _, _, _, _, _) => {
                            h3202
                        }
                    }
                }, {
                    let m3211 = {
                        let m3210 = f63(v0.clone(), match v5.clone() {
                            Adt61::C0(h3209, _, _, _, _, _) => {
                                h3209
                            }
                        }, v3.clone(), v4.clone())?;
                        match m3210 {
                            Adt89::C0(h3208, _) => {
                                h3208
                            }
                        }
                    };
                    match m3211 {
                        Adt1::C0(_, _, h3207, _, _, _, _) => {
                            h3207
                        }
                    }
                }, {
                    let m3216 = {
                        let m3215 = f63(v0.clone(), match v5.clone() {
                            Adt61::C0(h3214, _, _, _, _, _) => {
                                h3214
                            }
                        }, v3.clone(), v4.clone())?;
                        match m3215 {
                            Adt89::C0(h3213, _) => {
                                h3213
                            }
                        }
                    };
                    match m3216 {
                        Adt1::C0(_, _, _, h3212, _, _, _) => {
                            h3212
                        }
                    }
                }, {
                    let m3221 = {
                        let m3220 = f63(v0.clone(), match v5.clone() {
                            Adt61::C0(h3219, _, _, _, _, _) => {
                                h3219
                            }
                        }, v3.clone(), v4.clone())?;
                        match m3220 {
                            Adt89::C0(h3218, _) => {
                                h3218
                            }
                        }
                    };
                    match m3221 {
                        Adt1::C0(_, _, _, _, h3217, _, _) => {
                            h3217
                        }
                    }
                }, {
                    let m3226 = {
                        let m3225 = f63(v0.clone(), match v5.clone() {
                            Adt61::C0(h3224, _, _, _, _, _) => {
                                h3224
                            }
                        }, v3.clone(), v4.clone())?;
                        match m3225 {
                            Adt89::C0(h3223, _) => {
                                h3223
                            }
                        }
                    };
                    match m3226 {
                        Adt1::C0(_, _, _, _, _, h3222, _) => {
                            h3222
                        }
                    }
                }, None::<Adt61>), List::cons(Adt80::C0(Adt81::C6(match v5.clone() {
                    Adt61::C0(_, _, _, h3227, _, _) => {
                        h3227
                    }
                })), {
                    let m3230 = f63(v0, match v5 {
                        Adt61::C0(h3229, _, _, _, _, _) => {
                            h3229
                        }
                    }, v3, v4)?;
                    match m3230 {
                        Adt89::C0(_, h3228) => {
                            h3228
                        }
                    }
                })))
            } else {
                Ok(Adt89::C0(v0, List::cons(Adt80::C0(Adt81::C6(v3)), List::<Adt80>::nil())))
            }
        }
    }
}

pub fn f75(v0: Adt1, v1: Adt53, v2: u64, v3: Str) -> R<Adt89> {
    let m3232 = match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h3231) => {
            h3231
        }
    };
    match m3232 {
        None => {
            Ok(Adt89::C0(v0, List::<Adt80>::nil()))
        }
        Some(v4) => {
            if if f20(match v0.clone() {
                Adt1::C0(h3233, _, _, _, _, _, _) => {
                    h3233
                }
            }, v1) {
                let a3235 = match v4.clone() {
                    Adt61::C0(_, _, h3234, _, _, _) => {
                        h3234
                    }
                };
                let a3236 = v2;
                nat_eq(a3235, a3236)
            } else {
                false
            } {
                Ok(Adt89::C0(Adt1::C0({
                    let m3239 = f32(match v0.clone() {
                        Adt1::C0(h3238, _, _, _, _, _, _) => {
                            h3238
                        }
                    }, Adt42::C8(v3));
                    match m3239 {
                        Adt94::C0(h3237, _) => {
                            h3237
                        }
                    }
                }, {
                    let m3253 = Adt1::C0(match v0.clone() {
                        Adt1::C0(h3241, _, _, _, _, _, _) => {
                            h3241
                        }
                    }, f76(match v0.clone() {
                        Adt1::C0(_, h3242, _, _, _, _, _) => {
                            h3242
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3243, _, _, _, _, _) => {
                            h3243
                        }
                    }, Some(match v4.clone() {
                        Adt61::C0(_, _, _, h3244, _, _) => {
                            h3244
                        }
                    })), {
                        let a3246 = match v0.clone() {
                            Adt1::C0(_, _, h3245, _, _, _, _) => {
                                h3245
                            }
                        };
                        let a3247 = 1u64;
                        nat_add(a3246, a3247)?
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h3248, _, _, _) => {
                            h3248
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h3249, _, _) => {
                            h3249
                        }
                    }, f65(match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h3250, _) => {
                            h3250
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3251, _, _, _, _, _) => {
                            h3251
                        }
                    }, match v4.clone() {
                        Adt61::C0(_, _, _, _, _, h3252) => {
                            h3252
                        }
                    }), None::<Adt61>);
                    match m3253 {
                        Adt1::C0(_, h3240, _, _, _, _, _) => {
                            h3240
                        }
                    }
                }, {
                    let m3267 = Adt1::C0(match v0.clone() {
                        Adt1::C0(h3255, _, _, _, _, _, _) => {
                            h3255
                        }
                    }, f76(match v0.clone() {
                        Adt1::C0(_, h3256, _, _, _, _, _) => {
                            h3256
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3257, _, _, _, _, _) => {
                            h3257
                        }
                    }, Some(match v4.clone() {
                        Adt61::C0(_, _, _, h3258, _, _) => {
                            h3258
                        }
                    })), {
                        let a3260 = match v0.clone() {
                            Adt1::C0(_, _, h3259, _, _, _, _) => {
                                h3259
                            }
                        };
                        let a3261 = 1u64;
                        nat_add(a3260, a3261)?
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h3262, _, _, _) => {
                            h3262
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h3263, _, _) => {
                            h3263
                        }
                    }, f65(match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h3264, _) => {
                            h3264
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3265, _, _, _, _, _) => {
                            h3265
                        }
                    }, match v4.clone() {
                        Adt61::C0(_, _, _, _, _, h3266) => {
                            h3266
                        }
                    }), None::<Adt61>);
                    match m3267 {
                        Adt1::C0(_, _, h3254, _, _, _, _) => {
                            h3254
                        }
                    }
                }, {
                    let m3281 = Adt1::C0(match v0.clone() {
                        Adt1::C0(h3269, _, _, _, _, _, _) => {
                            h3269
                        }
                    }, f76(match v0.clone() {
                        Adt1::C0(_, h3270, _, _, _, _, _) => {
                            h3270
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3271, _, _, _, _, _) => {
                            h3271
                        }
                    }, Some(match v4.clone() {
                        Adt61::C0(_, _, _, h3272, _, _) => {
                            h3272
                        }
                    })), {
                        let a3274 = match v0.clone() {
                            Adt1::C0(_, _, h3273, _, _, _, _) => {
                                h3273
                            }
                        };
                        let a3275 = 1u64;
                        nat_add(a3274, a3275)?
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h3276, _, _, _) => {
                            h3276
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h3277, _, _) => {
                            h3277
                        }
                    }, f65(match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h3278, _) => {
                            h3278
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3279, _, _, _, _, _) => {
                            h3279
                        }
                    }, match v4.clone() {
                        Adt61::C0(_, _, _, _, _, h3280) => {
                            h3280
                        }
                    }), None::<Adt61>);
                    match m3281 {
                        Adt1::C0(_, _, _, h3268, _, _, _) => {
                            h3268
                        }
                    }
                }, {
                    let m3295 = Adt1::C0(match v0.clone() {
                        Adt1::C0(h3283, _, _, _, _, _, _) => {
                            h3283
                        }
                    }, f76(match v0.clone() {
                        Adt1::C0(_, h3284, _, _, _, _, _) => {
                            h3284
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3285, _, _, _, _, _) => {
                            h3285
                        }
                    }, Some(match v4.clone() {
                        Adt61::C0(_, _, _, h3286, _, _) => {
                            h3286
                        }
                    })), {
                        let a3288 = match v0.clone() {
                            Adt1::C0(_, _, h3287, _, _, _, _) => {
                                h3287
                            }
                        };
                        let a3289 = 1u64;
                        nat_add(a3288, a3289)?
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h3290, _, _, _) => {
                            h3290
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h3291, _, _) => {
                            h3291
                        }
                    }, f65(match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h3292, _) => {
                            h3292
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3293, _, _, _, _, _) => {
                            h3293
                        }
                    }, match v4.clone() {
                        Adt61::C0(_, _, _, _, _, h3294) => {
                            h3294
                        }
                    }), None::<Adt61>);
                    match m3295 {
                        Adt1::C0(_, _, _, _, h3282, _, _) => {
                            h3282
                        }
                    }
                }, {
                    let m3309 = Adt1::C0(match v0.clone() {
                        Adt1::C0(h3297, _, _, _, _, _, _) => {
                            h3297
                        }
                    }, f76(match v0.clone() {
                        Adt1::C0(_, h3298, _, _, _, _, _) => {
                            h3298
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3299, _, _, _, _, _) => {
                            h3299
                        }
                    }, Some(match v4.clone() {
                        Adt61::C0(_, _, _, h3300, _, _) => {
                            h3300
                        }
                    })), {
                        let a3302 = match v0.clone() {
                            Adt1::C0(_, _, h3301, _, _, _, _) => {
                                h3301
                            }
                        };
                        let a3303 = 1u64;
                        nat_add(a3302, a3303)?
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h3304, _, _, _) => {
                            h3304
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h3305, _, _) => {
                            h3305
                        }
                    }, f65(match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h3306, _) => {
                            h3306
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3307, _, _, _, _, _) => {
                            h3307
                        }
                    }, match v4.clone() {
                        Adt61::C0(_, _, _, _, _, h3308) => {
                            h3308
                        }
                    }), None::<Adt61>);
                    match m3309 {
                        Adt1::C0(_, _, _, _, _, h3296, _) => {
                            h3296
                        }
                    }
                }, {
                    let m3323 = Adt1::C0(match v0.clone() {
                        Adt1::C0(h3311, _, _, _, _, _, _) => {
                            h3311
                        }
                    }, f76(match v0.clone() {
                        Adt1::C0(_, h3312, _, _, _, _, _) => {
                            h3312
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3313, _, _, _, _, _) => {
                            h3313
                        }
                    }, Some(match v4.clone() {
                        Adt61::C0(_, _, _, h3314, _, _) => {
                            h3314
                        }
                    })), {
                        let a3316 = match v0.clone() {
                            Adt1::C0(_, _, h3315, _, _, _, _) => {
                                h3315
                            }
                        };
                        let a3317 = 1u64;
                        nat_add(a3316, a3317)?
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h3318, _, _, _) => {
                            h3318
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h3319, _, _) => {
                            h3319
                        }
                    }, f65(match v0 {
                        Adt1::C0(_, _, _, _, _, h3320, _) => {
                            h3320
                        }
                    }, match v4.clone() {
                        Adt61::C0(h3321, _, _, _, _, _) => {
                            h3321
                        }
                    }, match v4 {
                        Adt61::C0(_, _, _, _, _, h3322) => {
                            h3322
                        }
                    }), None::<Adt61>);
                    match m3323 {
                        Adt1::C0(_, _, _, _, _, _, h3310) => {
                            h3310
                        }
                    }
                }), List::<Adt80>::nil()))
            } else {
                Ok(Adt89::C0(v0, List::<Adt80>::nil()))
            }
        }
    }
}

pub fn f76(v0: Adt54, v1: Adt56, v2: Option<Adt12>) -> Adt54 {
    let m3324 = v1;
    match m3324 {
        Adt56::C0 => {
            Adt54::C0(match v0.clone() {
                Adt54::C0(h3325, _, _, _, _, _, _, _) => {
                    h3325
                }
            }, v2, match v0.clone() {
                Adt54::C0(_, _, h3326, _, _, _, _, _) => {
                    h3326
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, h3327, _, _, _, _) => {
                    h3327
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, h3328, _, _, _) => {
                    h3328
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, _, h3329, _, _) => {
                    h3329
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, _, _, h3330, _) => {
                    h3330
                }
            }, match v0 {
                Adt54::C0(_, _, _, _, _, _, _, h3331) => {
                    h3331
                }
            })
        }
        Adt56::C1 => {
            Adt54::C0(match v0.clone() {
                Adt54::C0(h3332, _, _, _, _, _, _, _) => {
                    h3332
                }
            }, match v0.clone() {
                Adt54::C0(_, h3333, _, _, _, _, _, _) => {
                    h3333
                }
            }, v2, match v0.clone() {
                Adt54::C0(_, _, _, h3334, _, _, _, _) => {
                    h3334
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, h3335, _, _, _) => {
                    h3335
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, _, h3336, _, _) => {
                    h3336
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, _, _, h3337, _) => {
                    h3337
                }
            }, match v0 {
                Adt54::C0(_, _, _, _, _, _, _, h3338) => {
                    h3338
                }
            })
        }
        Adt56::C2 => {
            Adt54::C0(match v0.clone() {
                Adt54::C0(h3339, _, _, _, _, _, _, _) => {
                    h3339
                }
            }, match v0.clone() {
                Adt54::C0(_, h3340, _, _, _, _, _, _) => {
                    h3340
                }
            }, match v0.clone() {
                Adt54::C0(_, _, h3341, _, _, _, _, _) => {
                    h3341
                }
            }, v2, match v0.clone() {
                Adt54::C0(_, _, _, _, h3342, _, _, _) => {
                    h3342
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, _, h3343, _, _) => {
                    h3343
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, _, _, h3344, _) => {
                    h3344
                }
            }, match v0 {
                Adt54::C0(_, _, _, _, _, _, _, h3345) => {
                    h3345
                }
            })
        }
        Adt56::C3 => {
            Adt54::C0(match v0.clone() {
                Adt54::C0(h3346, _, _, _, _, _, _, _) => {
                    h3346
                }
            }, match v0.clone() {
                Adt54::C0(_, h3347, _, _, _, _, _, _) => {
                    h3347
                }
            }, match v0.clone() {
                Adt54::C0(_, _, h3348, _, _, _, _, _) => {
                    h3348
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, h3349, _, _, _, _) => {
                    h3349
                }
            }, v2, match v0.clone() {
                Adt54::C0(_, _, _, _, _, h3350, _, _) => {
                    h3350
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, _, _, h3351, _) => {
                    h3351
                }
            }, match v0 {
                Adt54::C0(_, _, _, _, _, _, _, h3352) => {
                    h3352
                }
            })
        }
        Adt56::C4 => {
            Adt54::C0(match v0.clone() {
                Adt54::C0(h3353, _, _, _, _, _, _, _) => {
                    h3353
                }
            }, match v0.clone() {
                Adt54::C0(_, h3354, _, _, _, _, _, _) => {
                    h3354
                }
            }, match v0.clone() {
                Adt54::C0(_, _, h3355, _, _, _, _, _) => {
                    h3355
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, h3356, _, _, _, _) => {
                    h3356
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, h3357, _, _, _) => {
                    h3357
                }
            }, v2, match v0.clone() {
                Adt54::C0(_, _, _, _, _, _, h3358, _) => {
                    h3358
                }
            }, match v0 {
                Adt54::C0(_, _, _, _, _, _, _, h3359) => {
                    h3359
                }
            })
        }
        Adt56::C5 => {
            Adt54::C0(match v0.clone() {
                Adt54::C0(h3360, _, _, _, _, _, _, _) => {
                    h3360
                }
            }, match v0.clone() {
                Adt54::C0(_, h3361, _, _, _, _, _, _) => {
                    h3361
                }
            }, match v0.clone() {
                Adt54::C0(_, _, h3362, _, _, _, _, _) => {
                    h3362
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, h3363, _, _, _, _) => {
                    h3363
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, h3364, _, _, _) => {
                    h3364
                }
            }, match v0.clone() {
                Adt54::C0(_, _, _, _, _, h3365, _, _) => {
                    h3365
                }
            }, v2, match v0 {
                Adt54::C0(_, _, _, _, _, _, _, h3366) => {
                    h3366
                }
            })
        }
    }
}

pub fn f77(v0: Adt2, v1: Adt53) -> bool {
    let a3369 = match v0.clone() {
        Adt2::C0(h3367, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h3367
        }
    };
    let a3370 = match v1.clone() {
        Adt53::C0(h3368, _, _) => {
            h3368
        }
    };
    if nat_eq(a3369, a3370) {
        if match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3371, _, _, _, _, _, _, _) => {
                h3371
            }
        } {
            let a3373 = match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3372, _, _, _, _, _, _) => {
                    h3372
                }
            };
            if bool_not(a3373) {
                f125(match v0 {
                    Adt2::C0(_, h3374, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3374
                    }
                }, match v1.clone() {
                    Adt53::C0(_, h3375, _) => {
                        h3375
                    }
                }, match v1 {
                    Adt53::C0(_, _, h3376) => {
                        h3376
                    }
                })
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f78(v0: List<Adt81>) -> List<Adt80> {
    let m3377 = v0;
    match m3377.uncons() {
        None => {
            List::<Adt80>::nil()
        }
        Some((v1, v2)) => {
            List::cons(Adt80::C0(v1), f78(v2))
        }
    }
}

pub fn f79(v0: Adt2, v1: bool, v2: bool, v3: Adt49) -> R<Adt94> {
    Ok(Adt94::C0(Adt2::C0(match v0.clone() {
        Adt2::C0(h3378, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h3378
        }
    }, f126(match v0.clone() {
        Adt2::C0(_, h3379, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h3379
        }
    })?, f54(), f55(), None::<Adt10>, None::<Adt23>, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, h3380, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h3380
        }
    }, None::<Adt12>, false, false, None::<Adt42>, None::<Adt48>, None::<Adt12>, v1, v2, v3, Adt50::C1, false, match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3381, _, _) => {
            h3381
        }
    }, None::<Adt24>, f118(v0.clone())), f119(v0)))
}

pub fn f80(v0: Adt2) -> R<Adt94> {
    let m3384 = match v0.clone() {
        Adt2::C0(_, h3383, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h3383
        }
    };
    if match m3384 {
        Adt3::C0(_, _, h3382, _, _, _) => {
            h3382
        }
    } {
        Ok(Adt94::C0(Adt2::C0(match v0.clone() {
            Adt2::C0(h3385, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3385
            }
        }, f89(match v0.clone() {
            Adt2::C0(_, h3386, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3386
            }
        }), f90(match v0.clone() {
            Adt2::C0(_, _, h3387, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3387
            }
        }, Adt8::C2), match v0.clone() {
            Adt2::C0(_, _, _, h3388, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3388
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, h3389, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3389
            }
        }, None::<Adt23>, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, h3390, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3390
            }
        }, None::<Adt12>, false, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, h3391, _, _, _, _, _, _, _, _, _, _, _) => {
                h3391
            }
        }, Some(Adt42::C7), match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3392, _, _, _, _, _, _, _, _, _) => {
                h3392
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3393, _, _, _, _, _, _, _, _) => {
                h3393
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3394, _, _, _, _, _, _, _) => {
                h3394
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3395, _, _, _, _, _, _) => {
                h3395
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3396, _, _, _, _, _) => {
                h3396
            }
        }, Adt50::C1, false, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3397, _, _) => {
                h3397
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3398, _) => {
                h3398
            }
        }, f118(v0.clone())), List::cons(Adt81::C4(f84(v0.clone())), List::cons(Adt81::C5(f84(v0)), List::<Adt81>::nil()))))
    } else {
        if match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h3399, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3399
            }
        } {
            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h3400, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3400
                }
            }, f126(match v0.clone() {
                Adt2::C0(_, h3401, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3401
                }
            })?, f90(match v0.clone() {
                Adt2::C0(_, _, h3402, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3402
                }
            }, Adt8::C3), match v0.clone() {
                Adt2::C0(_, _, _, h3403, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3403
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h3404, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3404
                }
            }, None::<Adt23>, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h3405, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3405
                }
            }, None::<Adt12>, false, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h3406, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3406
                }
            }, Some(Adt42::C7), match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3407, _, _, _, _, _, _, _, _, _) => {
                    h3407
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3408, _, _, _, _, _, _, _, _) => {
                    h3408
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3409, _, _, _, _, _, _, _) => {
                    h3409
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3410, _, _, _, _, _, _) => {
                    h3410
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3411, _, _, _, _, _) => {
                    h3411
                }
            }, Adt50::C1, false, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3412, _, _) => {
                    h3412
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3413, _) => {
                    h3413
                }
            }, f118(v0.clone())), f119(v0)))
        } else {
            Ok(Adt94::C0(v0, List::<Adt81>::nil()))
        }
    }
}

pub fn f81(v0: Adt2) -> R<Adt94> {
    if match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3414, _, _, _, _, _, _) => {
            h3414
        }
    } {
        Ok(Adt94::C0(v0, List::<Adt81>::nil()))
    } else {
        Ok(Adt94::C0({
            let m3417 = f79(v0.clone(), false, true, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3416, _, _, _, _, _) => {
                    h3416
                }
            })?;
            match m3417 {
                Adt94::C0(h3415, _) => {
                    h3415
                }
            }
        }, f114(f119(v0.clone()), List::cons(Adt81::C8(match v0 {
            Adt2::C0(h3418, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3418
            }
        }), List::<Adt81>::nil()))))
    }
}

pub fn f82(v0: Adt2, v1: Adt53) -> Adt94 {
    if f77(v0.clone(), v1) {
        let m3420 = f127(match v0.clone() {
            Adt2::C0(_, _, h3419, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3419
            }
        });
        match m3420 {
            Ok(v3) => {
                Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h3441, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3441
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h3442, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3442
                    }
                }, v3, match v0.clone() {
                    Adt2::C0(_, _, _, h3443, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3443
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h3444, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3444
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h3445, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3445
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h3446, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3446
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h3447, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3447
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h3448, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3448
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h3449, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3449
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, h3450, _, _, _, _, _, _, _, _, _, _) => {
                        h3450
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3451, _, _, _, _, _, _, _, _, _) => {
                        h3451
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3452, _, _, _, _, _, _, _, _) => {
                        h3452
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3453, _, _, _, _, _, _, _) => {
                        h3453
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3454, _, _, _, _, _, _) => {
                        h3454
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3455, _, _, _, _, _) => {
                        h3455
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3456, _, _, _, _) => {
                        h3456
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3457, _, _, _) => {
                        h3457
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3458, _, _) => {
                        h3458
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3459, _) => {
                        h3459
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3460) => {
                        h3460
                    }
                }), List::<Adt81>::nil())
            }
            Err(v2) => {
                Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h3421, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3421
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h3422, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3422
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h3423, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3423
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h3424, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3424
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h3425, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3425
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h3426, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3426
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h3427, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3427
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h3428, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3428
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h3429, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3429
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h3430, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3430
                    }
                }, Some(Adt42::C11(v2)), match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3431, _, _, _, _, _, _, _, _, _) => {
                        h3431
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3432, _, _, _, _, _, _, _, _) => {
                        h3432
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3433, _, _, _, _, _, _, _) => {
                        h3433
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3434, _, _, _, _, _, _) => {
                        h3434
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3435, _, _, _, _, _) => {
                        h3435
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3436, _, _, _, _) => {
                        h3436
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3437, _, _, _) => {
                        h3437
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3438, _, _) => {
                        h3438
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3439, _) => {
                        h3439
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3440) => {
                        h3440
                    }
                }), List::<Adt81>::nil())
            }
        }
    } else {
        Adt94::C0(v0, List::<Adt81>::nil())
    }
}

pub fn f83(v0: Adt2, v1: Adt53, v2: Adt82) -> R<Adt94> {
    if f77(v0.clone(), v1.clone()) {
        if f128(v0.clone(), v2.clone()) {
            let m3462 = f129(match v0.clone() {
                Adt2::C0(_, _, h3461, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3461
                }
            }, f130(v2.clone()));
            match m3462 {
                Adt97::C0(_, v5) => {
                    let m3484 = f131(match v0.clone() {
                        Adt2::C0(_, _, _, h3483, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3483
                        }
                    }, v2.clone())?;
                    match m3484 {
                        Ok(v7) => {
                            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                                Adt2::C0(h3505, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3505
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, h3506, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3506
                                }
                            }, v5, v7, match v0.clone() {
                                Adt2::C0(_, _, _, _, h3507, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3507
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, h3508, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3508
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, h3509, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3509
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, h3510, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3510
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, h3511, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3511
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, h3512, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3512
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, h3513, _, _, _, _, _, _, _, _, _, _) => {
                                    h3513
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3514, _, _, _, _, _, _, _, _, _) => {
                                    h3514
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3515, _, _, _, _, _, _, _, _) => {
                                    h3515
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3516, _, _, _, _, _, _, _) => {
                                    h3516
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3517, _, _, _, _, _, _) => {
                                    h3517
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3518, _, _, _, _, _) => {
                                    h3518
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3519, _, _, _, _) => {
                                    h3519
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3520, _, _, _) => {
                                    h3520
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3521, _, _) => {
                                    h3521
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3522, _) => {
                                    h3522
                                }
                            }, match v0 {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3523) => {
                                    h3523
                                }
                            }), List::cons(Adt81::C1(v1, v2), List::<Adt81>::nil())))
                        }
                        Err(_) => {
                            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                                Adt2::C0(h3485, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3485
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, h3486, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3486
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, h3487, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3487
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, h3488, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3488
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, h3489, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3489
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, h3490, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3490
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, h3491, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3491
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, h3492, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3492
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, h3493, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3493
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, h3494, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h3494
                                }
                            }, Some(Adt42::C10(Adt44::C8)), match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3495, _, _, _, _, _, _, _, _, _) => {
                                    h3495
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3496, _, _, _, _, _, _, _, _) => {
                                    h3496
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3497, _, _, _, _, _, _, _) => {
                                    h3497
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3498, _, _, _, _, _, _) => {
                                    h3498
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3499, _, _, _, _, _) => {
                                    h3499
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3500, _, _, _, _) => {
                                    h3500
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3501, _, _, _) => {
                                    h3501
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3502, _, _) => {
                                    h3502
                                }
                            }, match v0.clone() {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3503, _) => {
                                    h3503
                                }
                            }, match v0 {
                                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3504) => {
                                    h3504
                                }
                            }), List::<Adt81>::nil()))
                        }
                    }
                }
                Adt97::C1(v3) => {
                    Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                        Adt2::C0(h3463, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3463
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, h3464, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3464
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, h3465, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3465
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, h3466, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3466
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, h3467, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3467
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, h3468, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3468
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, h3469, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3469
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, h3470, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3470
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, h3471, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3471
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, h3472, _, _, _, _, _, _, _, _, _, _, _) => {
                            h3472
                        }
                    }, Some(Adt42::C11(v3)), match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3473, _, _, _, _, _, _, _, _, _) => {
                            h3473
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3474, _, _, _, _, _, _, _, _) => {
                            h3474
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3475, _, _, _, _, _, _, _) => {
                            h3475
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3476, _, _, _, _, _, _) => {
                            h3476
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3477, _, _, _, _, _) => {
                            h3477
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3478, _, _, _, _) => {
                            h3478
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3479, _, _, _) => {
                            h3479
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3480, _, _) => {
                            h3480
                        }
                    }, match v0.clone() {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3481, _) => {
                            h3481
                        }
                    }, match v0 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3482) => {
                            h3482
                        }
                    }), List::<Adt81>::nil()))
                }
            }
        } else {
            Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h3524, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3524
                }
            }, match v0.clone() {
                Adt2::C0(_, h3525, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3525
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h3526, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3526
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h3527, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3527
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h3528, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3528
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h3529, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3529
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h3530, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3530
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h3531, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3531
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h3532, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3532
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h3533, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3533
                }
            }, Some(Adt42::C10(Adt44::C11)), match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3534, _, _, _, _, _, _, _, _, _) => {
                    h3534
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3535, _, _, _, _, _, _, _, _) => {
                    h3535
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3536, _, _, _, _, _, _, _) => {
                    h3536
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3537, _, _, _, _, _, _) => {
                    h3537
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3538, _, _, _, _, _) => {
                    h3538
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3539, _, _, _, _) => {
                    h3539
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3540, _, _, _) => {
                    h3540
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3541, _, _) => {
                    h3541
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3542, _) => {
                    h3542
                }
            }, match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3543) => {
                    h3543
                }
            }), List::<Adt81>::nil()))
        }
    } else {
        Ok(Adt94::C0(v0, List::<Adt81>::nil()))
    }
}

pub fn f84(v0: Adt2) -> Adt53 {
    Adt53::C0(match v0.clone() {
        Adt2::C0(h3544, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h3544
        }
    }, {
        let m3547 = match v0.clone() {
            Adt2::C0(_, h3546, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3546
            }
        };
        match m3547 {
            Adt3::C0(_, h3545, _, _, _, _) => {
                h3545
            }
        }
    }, {
        let m3550 = match v0 {
            Adt2::C0(_, h3549, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3549
            }
        };
        match m3550 {
            Adt3::C0(h3548, _, _, _, _, _) => {
                h3548
            }
        }
    })
}

pub fn f85(v0: Option<Adt12>) -> List<Adt81> {
    let m3551 = v0;
    match m3551 {
        None => {
            List::<Adt81>::nil()
        }
        Some(v1) => {
            List::cons(Adt81::C6(v1), List::<Adt81>::nil())
        }
    }
}

pub fn f86(v0: Adt2, v1: u64) -> Adt94 {
    let a3552 = v1;
    let a3553 = 0u64;
    if nat_eq(a3552, a3553) {
        Adt94::C0(Adt2::C0(match v0.clone() {
            Adt2::C0(h3554, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3554
            }
        }, match v0.clone() {
            Adt2::C0(_, h3555, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3555
            }
        }, match v0.clone() {
            Adt2::C0(_, _, h3556, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3556
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, h3557, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3557
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, h3558, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3558
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, h3559, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3559
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, h3560, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3560
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, h3561, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3561
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h3562, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3562
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, h3563, _, _, _, _, _, _, _, _, _, _, _) => {
                h3563
            }
        }, Some(Adt42::C10(Adt44::C12)), match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3564, _, _, _, _, _, _, _, _, _) => {
                h3564
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3565, _, _, _, _, _, _, _, _) => {
                h3565
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3566, _, _, _, _, _, _, _) => {
                h3566
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3567, _, _, _, _, _, _) => {
                h3567
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3568, _, _, _, _, _) => {
                h3568
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3569, _, _, _, _) => {
                h3569
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3570, _, _, _) => {
                h3570
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3571, _, _) => {
                h3571
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3572, _) => {
                h3572
            }
        }, match v0 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3573) => {
                h3573
            }
        }), List::<Adt81>::nil())
    } else {
        let m3576 = match v0.clone() {
            Adt2::C0(_, h3575, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3575
            }
        };
        if match m3576 {
            Adt3::C0(_, _, h3574, _, _, _) => {
                h3574
            }
        } {
            Adt94::C0(v0.clone(), List::cons(Adt81::C3(f84(v0), v1), List::<Adt81>::nil()))
        } else {
            Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h3577, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3577
                }
            }, match v0.clone() {
                Adt2::C0(_, h3578, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3578
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h3579, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3579
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h3580, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3580
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h3581, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3581
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h3582, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3582
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h3583, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3583
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h3584, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3584
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h3585, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3585
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h3586, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3586
                }
            }, Some(Adt42::C10(Adt44::C3)), match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3587, _, _, _, _, _, _, _, _, _) => {
                    h3587
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3588, _, _, _, _, _, _, _, _) => {
                    h3588
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3589, _, _, _, _, _, _, _) => {
                    h3589
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3590, _, _, _, _, _, _) => {
                    h3590
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3591, _, _, _, _, _) => {
                    h3591
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3592, _, _, _, _) => {
                    h3592
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3593, _, _, _) => {
                    h3593
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3594, _, _) => {
                    h3594
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3595, _) => {
                    h3595
                }
            }, match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3596) => {
                    h3596
                }
            }), List::<Adt81>::nil())
        }
    }
}

pub fn f87(v0: Adt2, v1: Adt53, v2: Adt23) -> R<Adt94> {
    f132(v0.clone(), v1.clone(), v2, f77(v0, v1))
}

pub fn f88(v0: Adt2, v1: Adt53, v2: Adt67) -> Adt94 {
    if if f20(v0.clone(), v1.clone()) {
        match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h3597, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3597
            }
        }
    } else {
        false
    } {
        Adt94::C0(Adt2::C0({
            let m3602 = {
                let m3601 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3600) => {
                        h3600
                    }
                });
                match m3601 {
                    Adt94::C0(h3599, _) => {
                        h3599
                    }
                }
            };
            match m3602 {
                Adt2::C0(h3598, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3598
                }
            }
        }, {
            let m3607 = {
                let m3606 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3605) => {
                        h3605
                    }
                });
                match m3606 {
                    Adt94::C0(h3604, _) => {
                        h3604
                    }
                }
            };
            match m3607 {
                Adt2::C0(_, h3603, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3603
                }
            }
        }, {
            let m3612 = {
                let m3611 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3610) => {
                        h3610
                    }
                });
                match m3611 {
                    Adt94::C0(h3609, _) => {
                        h3609
                    }
                }
            };
            match m3612 {
                Adt2::C0(_, _, h3608, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3608
                }
            }
        }, {
            let m3617 = {
                let m3616 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3615) => {
                        h3615
                    }
                });
                match m3616 {
                    Adt94::C0(h3614, _) => {
                        h3614
                    }
                }
            };
            match m3617 {
                Adt2::C0(_, _, _, h3613, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3613
                }
            }
        }, {
            let m3622 = {
                let m3621 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3620) => {
                        h3620
                    }
                });
                match m3621 {
                    Adt94::C0(h3619, _) => {
                        h3619
                    }
                }
            };
            match m3622 {
                Adt2::C0(_, _, _, _, h3618, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3618
                }
            }
        }, {
            let m3627 = {
                let m3626 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3625) => {
                        h3625
                    }
                });
                match m3626 {
                    Adt94::C0(h3624, _) => {
                        h3624
                    }
                }
            };
            match m3627 {
                Adt2::C0(_, _, _, _, _, h3623, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3623
                }
            }
        }, {
            let m3632 = {
                let m3631 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3630) => {
                        h3630
                    }
                });
                match m3631 {
                    Adt94::C0(h3629, _) => {
                        h3629
                    }
                }
            };
            match m3632 {
                Adt2::C0(_, _, _, _, _, _, h3628, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3628
                }
            }
        }, {
            let m3637 = {
                let m3636 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3635) => {
                        h3635
                    }
                });
                match m3636 {
                    Adt94::C0(h3634, _) => {
                        h3634
                    }
                }
            };
            match m3637 {
                Adt2::C0(_, _, _, _, _, _, _, h3633, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3633
                }
            }
        }, {
            let m3642 = {
                let m3641 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3640) => {
                        h3640
                    }
                });
                match m3641 {
                    Adt94::C0(h3639, _) => {
                        h3639
                    }
                }
            };
            match m3642 {
                Adt2::C0(_, _, _, _, _, _, _, _, h3638, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3638
                }
            }
        }, {
            let m3647 = {
                let m3646 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3645) => {
                        h3645
                    }
                });
                match m3646 {
                    Adt94::C0(h3644, _) => {
                        h3644
                    }
                }
            };
            match m3647 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h3643, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3643
                }
            }
        }, Some(match v2.clone() {
            Adt67::C0(h3648, _, _) => {
                h3648
            }
        }), {
            let m3653 = {
                let m3652 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3651) => {
                        h3651
                    }
                });
                match m3652 {
                    Adt94::C0(h3650, _) => {
                        h3650
                    }
                }
            };
            match m3653 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3649, _, _, _, _, _, _, _, _, _) => {
                    h3649
                }
            }
        }, {
            let m3658 = {
                let m3657 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3656) => {
                        h3656
                    }
                });
                match m3657 {
                    Adt94::C0(h3655, _) => {
                        h3655
                    }
                }
            };
            match m3658 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3654, _, _, _, _, _, _, _, _) => {
                    h3654
                }
            }
        }, {
            let m3663 = {
                let m3662 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3661) => {
                        h3661
                    }
                });
                match m3662 {
                    Adt94::C0(h3660, _) => {
                        h3660
                    }
                }
            };
            match m3663 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3659, _, _, _, _, _, _, _) => {
                    h3659
                }
            }
        }, {
            let m3668 = {
                let m3667 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3666) => {
                        h3666
                    }
                });
                match m3667 {
                    Adt94::C0(h3665, _) => {
                        h3665
                    }
                }
            };
            match m3668 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3664, _, _, _, _, _, _) => {
                    h3664
                }
            }
        }, {
            let m3673 = {
                let m3672 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3671) => {
                        h3671
                    }
                });
                match m3672 {
                    Adt94::C0(h3670, _) => {
                        h3670
                    }
                }
            };
            match m3673 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3669, _, _, _, _, _) => {
                    h3669
                }
            }
        }, {
            let m3678 = {
                let m3677 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3676) => {
                        h3676
                    }
                });
                match m3677 {
                    Adt94::C0(h3675, _) => {
                        h3675
                    }
                }
            };
            match m3678 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3674, _, _, _, _) => {
                    h3674
                }
            }
        }, {
            let m3683 = {
                let m3682 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3681) => {
                        h3681
                    }
                });
                match m3682 {
                    Adt94::C0(h3680, _) => {
                        h3680
                    }
                }
            };
            match m3683 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3679, _, _, _) => {
                    h3679
                }
            }
        }, {
            let m3688 = {
                let m3687 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3686) => {
                        h3686
                    }
                });
                match m3687 {
                    Adt94::C0(h3685, _) => {
                        h3685
                    }
                }
            };
            match m3688 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3684, _, _) => {
                    h3684
                }
            }
        }, Some(match v2.clone() {
            Adt67::C0(_, h3689, _) => {
                h3689
            }
        }), {
            let m3694 = {
                let m3693 = f92(v0.clone(), v1.clone(), match v2.clone() {
                    Adt67::C0(_, _, h3692) => {
                        h3692
                    }
                });
                match m3693 {
                    Adt94::C0(h3691, _) => {
                        h3691
                    }
                }
            };
            match m3694 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3690) => {
                    h3690
                }
            }
        }), {
            let m3697 = f92(v0, v1, match v2 {
                Adt67::C0(_, _, h3696) => {
                    h3696
                }
            });
            match m3697 {
                Adt94::C0(_, h3695) => {
                    h3695
                }
            }
        })
    } else {
        if f77(v0.clone(), v1.clone()) {
            Adt94::C0(Adt2::C0({
                let m3702 = {
                    let m3701 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3700, _, _) => {
                            h3700
                        }
                    });
                    match m3701 {
                        Adt94::C0(h3699, _) => {
                            h3699
                        }
                    }
                };
                match m3702 {
                    Adt2::C0(h3698, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3698
                    }
                }
            }, {
                let m3707 = {
                    let m3706 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3705, _, _) => {
                            h3705
                        }
                    });
                    match m3706 {
                        Adt94::C0(h3704, _) => {
                            h3704
                        }
                    }
                };
                match m3707 {
                    Adt2::C0(_, h3703, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3703
                    }
                }
            }, f90(match v0.clone() {
                Adt2::C0(_, _, h3708, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h3708
                }
            }, match v2.clone() {
                Adt67::C0(_, _, h3709) => {
                    h3709
                }
            }), {
                let m3714 = {
                    let m3713 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3712, _, _) => {
                            h3712
                        }
                    });
                    match m3713 {
                        Adt94::C0(h3711, _) => {
                            h3711
                        }
                    }
                };
                match m3714 {
                    Adt2::C0(_, _, _, h3710, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3710
                    }
                }
            }, {
                let m3719 = {
                    let m3718 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3717, _, _) => {
                            h3717
                        }
                    });
                    match m3718 {
                        Adt94::C0(h3716, _) => {
                            h3716
                        }
                    }
                };
                match m3719 {
                    Adt2::C0(_, _, _, _, h3715, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3715
                    }
                }
            }, {
                let m3724 = {
                    let m3723 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3722, _, _) => {
                            h3722
                        }
                    });
                    match m3723 {
                        Adt94::C0(h3721, _) => {
                            h3721
                        }
                    }
                };
                match m3724 {
                    Adt2::C0(_, _, _, _, _, h3720, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3720
                    }
                }
            }, {
                let m3729 = {
                    let m3728 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3727, _, _) => {
                            h3727
                        }
                    });
                    match m3728 {
                        Adt94::C0(h3726, _) => {
                            h3726
                        }
                    }
                };
                match m3729 {
                    Adt2::C0(_, _, _, _, _, _, h3725, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3725
                    }
                }
            }, {
                let m3734 = {
                    let m3733 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3732, _, _) => {
                            h3732
                        }
                    });
                    match m3733 {
                        Adt94::C0(h3731, _) => {
                            h3731
                        }
                    }
                };
                match m3734 {
                    Adt2::C0(_, _, _, _, _, _, _, h3730, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3730
                    }
                }
            }, {
                let m3739 = {
                    let m3738 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3737, _, _) => {
                            h3737
                        }
                    });
                    match m3738 {
                        Adt94::C0(h3736, _) => {
                            h3736
                        }
                    }
                };
                match m3739 {
                    Adt2::C0(_, _, _, _, _, _, _, _, h3735, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3735
                    }
                }
            }, {
                let m3744 = {
                    let m3743 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3742, _, _) => {
                            h3742
                        }
                    });
                    match m3743 {
                        Adt94::C0(h3741, _) => {
                            h3741
                        }
                    }
                };
                match m3744 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h3740, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3740
                    }
                }
            }, {
                let m3749 = {
                    let m3748 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3747, _, _) => {
                            h3747
                        }
                    });
                    match m3748 {
                        Adt94::C0(h3746, _) => {
                            h3746
                        }
                    }
                };
                match m3749 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, h3745, _, _, _, _, _, _, _, _, _, _) => {
                        h3745
                    }
                }
            }, {
                let m3754 = {
                    let m3753 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3752, _, _) => {
                            h3752
                        }
                    });
                    match m3753 {
                        Adt94::C0(h3751, _) => {
                            h3751
                        }
                    }
                };
                match m3754 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3750, _, _, _, _, _, _, _, _, _) => {
                        h3750
                    }
                }
            }, {
                let m3759 = {
                    let m3758 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3757, _, _) => {
                            h3757
                        }
                    });
                    match m3758 {
                        Adt94::C0(h3756, _) => {
                            h3756
                        }
                    }
                };
                match m3759 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3755, _, _, _, _, _, _, _, _) => {
                        h3755
                    }
                }
            }, {
                let m3764 = {
                    let m3763 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3762, _, _) => {
                            h3762
                        }
                    });
                    match m3763 {
                        Adt94::C0(h3761, _) => {
                            h3761
                        }
                    }
                };
                match m3764 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3760, _, _, _, _, _, _, _) => {
                        h3760
                    }
                }
            }, {
                let m3769 = {
                    let m3768 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3767, _, _) => {
                            h3767
                        }
                    });
                    match m3768 {
                        Adt94::C0(h3766, _) => {
                            h3766
                        }
                    }
                };
                match m3769 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3765, _, _, _, _, _, _) => {
                        h3765
                    }
                }
            }, {
                let m3774 = {
                    let m3773 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3772, _, _) => {
                            h3772
                        }
                    });
                    match m3773 {
                        Adt94::C0(h3771, _) => {
                            h3771
                        }
                    }
                };
                match m3774 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3770, _, _, _, _, _) => {
                        h3770
                    }
                }
            }, {
                let m3779 = {
                    let m3778 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3777, _, _) => {
                            h3777
                        }
                    });
                    match m3778 {
                        Adt94::C0(h3776, _) => {
                            h3776
                        }
                    }
                };
                match m3779 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3775, _, _, _, _) => {
                        h3775
                    }
                }
            }, {
                let m3784 = {
                    let m3783 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3782, _, _) => {
                            h3782
                        }
                    });
                    match m3783 {
                        Adt94::C0(h3781, _) => {
                            h3781
                        }
                    }
                };
                match m3784 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3780, _, _, _) => {
                        h3780
                    }
                }
            }, {
                let m3789 = {
                    let m3788 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3787, _, _) => {
                            h3787
                        }
                    });
                    match m3788 {
                        Adt94::C0(h3786, _) => {
                            h3786
                        }
                    }
                };
                match m3789 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3785, _, _) => {
                        h3785
                    }
                }
            }, Some(match v2.clone() {
                Adt67::C0(_, h3790, _) => {
                    h3790
                }
            }), {
                let m3795 = {
                    let m3794 = f133(v0.clone(), v1.clone(), match v2.clone() {
                        Adt67::C0(h3793, _, _) => {
                            h3793
                        }
                    });
                    match m3794 {
                        Adt94::C0(h3792, _) => {
                            h3792
                        }
                    }
                };
                match m3795 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3791) => {
                        h3791
                    }
                }
            }), {
                let m3798 = f133(v0, v1, match v2 {
                    Adt67::C0(h3797, _, _) => {
                        h3797
                    }
                });
                match m3798 {
                    Adt94::C0(_, h3796) => {
                        h3796
                    }
                }
            })
        } else {
            Adt94::C0(v0, List::<Adt81>::nil())
        }
    }
}

pub fn f89(v0: Adt3) -> Adt3 {
    if match v0.clone() {
        Adt3::C0(_, _, h3799, _, _, _) => {
            h3799
        }
    } {
        Adt3::C0(match v0.clone() {
            Adt3::C0(h3800, _, _, _, _, _) => {
                h3800
            }
        }, match v0 {
            Adt3::C0(_, h3801, _, _, _, _) => {
                h3801
            }
        }, false, false, Adt4::C5, Adt5::C0)
    } else {
        v0
    }
}

pub fn f90(v0: Adt6, v1: Adt8) -> Adt6 {
    Adt6::C0(Adt7::C4, match v0.clone() {
        Adt6::C0(_, h3802, _, _, _) => {
            h3802
        }
    }, match v0 {
        Adt6::C0(_, _, h3803, _, _) => {
            h3803
        }
    }, false, v1)
}

pub fn f91(v0: Adt2) -> Adt94 {
    if f44(v0.clone()) {
        let m3805 = match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, h3804, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3804
            }
        };
        match m3805 {
            None => {
                Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h3806, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3806
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h3807, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3807
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h3808, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3808
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h3809, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3809
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h3810, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3810
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h3811, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3811
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h3812, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3812
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h3813, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3813
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h3814, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3814
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h3815, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3815
                    }
                }, Some(Adt42::C10(Adt44::C5)), match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3816, _, _, _, _, _, _, _, _, _) => {
                        h3816
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3817, _, _, _, _, _, _, _, _) => {
                        h3817
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3818, _, _, _, _, _, _, _) => {
                        h3818
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3819, _, _, _, _, _, _) => {
                        h3819
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3820, _, _, _, _, _) => {
                        h3820
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3821, _, _, _, _) => {
                        h3821
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3822, _, _, _) => {
                        h3822
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3823, _, _) => {
                        h3823
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3824, _) => {
                        h3824
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3825) => {
                        h3825
                    }
                }), List::<Adt81>::nil())
            }
            Some(v1) => {
                Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h3826, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3826
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h3827, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3827
                    }
                }, f134(match v0.clone() {
                    Adt2::C0(_, _, h3828, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3828
                    }
                }), match v0.clone() {
                    Adt2::C0(_, _, _, h3829, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3829
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h3830, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3830
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h3831, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3831
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h3832, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3832
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h3833, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3833
                    }
                }, true, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h3834, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3834
                    }
                }, None::<Adt42>, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3835, _, _, _, _, _, _, _, _, _) => {
                        h3835
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3836, _, _, _, _, _, _, _, _) => {
                        h3836
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3837, _, _, _, _, _, _, _) => {
                        h3837
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3838, _, _, _, _, _, _) => {
                        h3838
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3839, _, _, _, _, _) => {
                        h3839
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3840, _, _, _, _) => {
                        h3840
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3841, _, _, _) => {
                        h3841
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3842, _, _) => {
                        h3842
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3843, _) => {
                        h3843
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3844) => {
                        h3844
                    }
                }), List::cons(Adt81::C7(f84(v0), v1), List::<Adt81>::nil()))
            }
        }
    } else {
        Adt94::C0(Adt2::C0(match v0.clone() {
            Adt2::C0(h3845, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3845
            }
        }, match v0.clone() {
            Adt2::C0(_, h3846, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3846
            }
        }, match v0.clone() {
            Adt2::C0(_, _, h3847, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3847
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, h3848, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3848
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, h3849, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3849
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, h3850, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3850
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, h3851, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3851
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, h3852, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3852
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h3853, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3853
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, h3854, _, _, _, _, _, _, _, _, _, _, _) => {
                h3854
            }
        }, Some(Adt42::C10(Adt44::C5)), match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3855, _, _, _, _, _, _, _, _, _) => {
                h3855
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3856, _, _, _, _, _, _, _, _) => {
                h3856
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3857, _, _, _, _, _, _, _) => {
                h3857
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3858, _, _, _, _, _, _) => {
                h3858
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3859, _, _, _, _, _) => {
                h3859
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3860, _, _, _, _) => {
                h3860
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3861, _, _, _) => {
                h3861
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3862, _, _) => {
                h3862
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3863, _) => {
                h3863
            }
        }, match v0 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3864) => {
                h3864
            }
        }), List::<Adt81>::nil())
    }
}

pub fn f92(v0: Adt2, v1: Adt53, v2: Adt8) -> Adt94 {
    if if f20(v0.clone(), v1) {
        match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h3865, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3865
            }
        }
    } else {
        false
    } {
        let m3867 = f135(match v0.clone() {
            Adt2::C0(_, _, h3866, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3866
            }
        }, v2.clone());
        match m3867 {
            Ok(v4) => {
                let m3888 = v2.clone();
                match m3888 {
                    Adt8::C0 => {
                        Adt94::C0(Adt2::C0(match v0.clone() {
                            Adt2::C0(h3889, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3889
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, h3890, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3890
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, h3891, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3891
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, h3892, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3892
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, h3893, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3893
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, h3894, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3894
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, h3895, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3895
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, h3896, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3896
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, h3897, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3897
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, h3898, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3898
                            }
                        }, Some(Adt42::C10(Adt44::C13)), match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3899, _, _, _, _, _, _, _, _, _) => {
                                h3899
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3900, _, _, _, _, _, _, _, _) => {
                                h3900
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3901, _, _, _, _, _, _, _) => {
                                h3901
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3902, _, _, _, _, _, _) => {
                                h3902
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3903, _, _, _, _, _) => {
                                h3903
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3904, _, _, _, _) => {
                                h3904
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3905, _, _, _) => {
                                h3905
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3906, _, _) => {
                                h3906
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3907, _) => {
                                h3907
                            }
                        }, match v0 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3908) => {
                                h3908
                            }
                        }), List::<Adt81>::nil())
                    }
                    Adt8::C1 => {
                        Adt94::C0(Adt2::C0(match v0.clone() {
                            Adt2::C0(h3909, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3909
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, h3910, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3910
                            }
                        }, v4, match v0.clone() {
                            Adt2::C0(_, _, _, h3911, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3911
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, h3912, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3912
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, h3913, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3913
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, h3914, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3914
                            }
                        }, None::<Adt12>, false, true, None::<Adt42>, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3915, _, _, _, _, _, _, _, _, _) => {
                                h3915
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3916, _, _, _, _, _, _, _, _) => {
                                h3916
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3917, _, _, _, _, _, _, _) => {
                                h3917
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3918, _, _, _, _, _, _) => {
                                h3918
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3919, _, _, _, _, _) => {
                                h3919
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3920, _, _, _, _) => {
                                h3920
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3921, _, _, _) => {
                                h3921
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3922, _, _) => {
                                h3922
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3923, _) => {
                                h3923
                            }
                        }, match v0 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3924) => {
                                h3924
                            }
                        }), List::<Adt81>::nil())
                    }
                    Adt8::C2 => {
                        Adt94::C0(Adt2::C0(match v0.clone() {
                            Adt2::C0(h3925, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3925
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, h3926, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3926
                            }
                        }, v4, match v0.clone() {
                            Adt2::C0(_, _, _, h3927, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3927
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, h3928, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3928
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, h3929, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3929
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, h3930, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3930
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, h3931, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3931
                            }
                        }, false, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, h3932, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3932
                            }
                        }, Some(Adt42::C9(v2, Str::lit("Output was not published; the staged result is retained."))), match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3933, _, _, _, _, _, _, _, _, _) => {
                                h3933
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3934, _, _, _, _, _, _, _, _) => {
                                h3934
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3935, _, _, _, _, _, _, _) => {
                                h3935
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3936, _, _, _, _, _, _) => {
                                h3936
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3937, _, _, _, _, _) => {
                                h3937
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3938, _, _, _, _) => {
                                h3938
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3939, _, _, _) => {
                                h3939
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3940, _, _) => {
                                h3940
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3941, _) => {
                                h3941
                            }
                        }, match v0 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3942) => {
                                h3942
                            }
                        }), List::<Adt81>::nil())
                    }
                    Adt8::C3 => {
                        Adt94::C0(Adt2::C0(match v0.clone() {
                            Adt2::C0(h3943, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3943
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, h3944, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3944
                            }
                        }, v4, match v0.clone() {
                            Adt2::C0(_, _, _, h3945, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3945
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, h3946, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3946
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, h3947, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3947
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, h3948, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3948
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, h3949, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3949
                            }
                        }, false, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, h3950, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3950
                            }
                        }, Some(Adt42::C9(v2, Str::lit("Publication outcome is unknown; reconcile with the destination before retrying."))), match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3951, _, _, _, _, _, _, _, _, _) => {
                                h3951
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3952, _, _, _, _, _, _, _, _) => {
                                h3952
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3953, _, _, _, _, _, _, _) => {
                                h3953
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3954, _, _, _, _, _, _) => {
                                h3954
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3955, _, _, _, _, _) => {
                                h3955
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3956, _, _, _, _) => {
                                h3956
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3957, _, _, _) => {
                                h3957
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3958, _, _) => {
                                h3958
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3959, _) => {
                                h3959
                            }
                        }, match v0 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3960) => {
                                h3960
                            }
                        }), List::<Adt81>::nil())
                    }
                }
            }
            Err(v3) => {
                Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h3868, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3868
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h3869, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3869
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h3870, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3870
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h3871, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3871
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h3872, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3872
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h3873, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3873
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h3874, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3874
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h3875, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3875
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h3876, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3876
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h3877, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3877
                    }
                }, Some(Adt42::C11(v3)), match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3878, _, _, _, _, _, _, _, _, _) => {
                        h3878
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3879, _, _, _, _, _, _, _, _) => {
                        h3879
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3880, _, _, _, _, _, _, _) => {
                        h3880
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3881, _, _, _, _, _, _) => {
                        h3881
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3882, _, _, _, _, _) => {
                        h3882
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3883, _, _, _, _) => {
                        h3883
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3884, _, _, _) => {
                        h3884
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3885, _, _) => {
                        h3885
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3886, _) => {
                        h3886
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3887) => {
                        h3887
                    }
                }), List::<Adt81>::nil())
            }
        }
    } else {
        Adt94::C0(v0, List::<Adt81>::nil())
    }
}

pub fn f93(v0: Adt2, v1: Adt53, v2: u64) -> R<Adt94> {
    if f77(v0.clone(), v1.clone()) {
        let m3962 = match v0.clone() {
            Adt2::C0(_, _, _, _, h3961, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h3961
            }
        };
        match m3962 {
            None => {
                Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                    Adt2::C0(h3963, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3963
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h3964, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3964
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h3965, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3965
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h3966, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3966
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h3967, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3967
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h3968, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3968
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h3969, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3969
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h3970, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3970
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h3971, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3971
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h3972, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3972
                    }
                }, Some(Adt42::C10(Adt44::C3)), match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h3973, _, _, _, _, _, _, _, _, _) => {
                        h3973
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h3974, _, _, _, _, _, _, _, _) => {
                        h3974
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h3975, _, _, _, _, _, _, _) => {
                        h3975
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h3976, _, _, _, _, _, _) => {
                        h3976
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3977, _, _, _, _, _) => {
                        h3977
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3978, _, _, _, _) => {
                        h3978
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3979, _, _, _) => {
                        h3979
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3980, _, _) => {
                        h3980
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3981, _) => {
                        h3981
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h3982) => {
                        h3982
                    }
                }), List::<Adt81>::nil()))
            }
            Some(v3) => {
                let m3994 = f136(match v0.clone() {
                    Adt2::C0(_, _, h3983, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h3983
                    }
                }, v2, {
                    let m3988 = {
                        let m3987 = {
                            let m3986 = f137(v3);
                            match m3986 {
                                Adt13::C0(h3985, _) => {
                                    h3985
                                }
                            }
                        };
                        match m3987 {
                            Adt14::C0(_, _, _, _, h3984, _, _) => {
                                h3984
                            }
                        }
                    };
                    match m3988 {
                        None => {
                            let a3992 = {
                                let m3991 = match v0.clone() {
                                    Adt2::C0(_, _, h3990, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                        h3990
                                    }
                                };
                                match m3991 {
                                    Adt6::C0(_, _, h3989, _, _) => {
                                        h3989
                                    }
                                }
                            };
                            let a3993 = v2;
                            nat_add(a3992, a3993)?
                        }
                        Some(v4) => {
                            v4
                        }
                    }
                })?;
                match m3994 {
                    Ok(v6) => {
                        Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                            Adt2::C0(h3995, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3995
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, h3996, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3996
                            }
                        }, v6, match v0.clone() {
                            Adt2::C0(_, _, _, h3997, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3997
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, h3998, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3998
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, h3999, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h3999
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, h4000, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4000
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, h4001, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4001
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, h4002, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4002
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, h4003, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4003
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, h4004, _, _, _, _, _, _, _, _, _, _) => {
                                h4004
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h4005, _, _, _, _, _, _, _, _, _) => {
                                h4005
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4006, _, _, _, _, _, _, _, _) => {
                                h4006
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h4007, _, _, _, _, _, _, _) => {
                                h4007
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4008, _, _, _, _, _, _) => {
                                h4008
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4009, _, _, _, _, _) => {
                                h4009
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4010, _, _, _, _) => {
                                h4010
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4011, _, _, _) => {
                                h4011
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4012, _, _) => {
                                h4012
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4013, _) => {
                                h4013
                            }
                        }, match v0 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4014) => {
                                h4014
                            }
                        }), List::<Adt81>::nil()))
                    }
                    Err(v5) => {
                        Ok(f133(v0, v1, Adt42::C11(v5)))
                    }
                }
            }
        }
    } else {
        Ok(Adt94::C0(v0, List::<Adt81>::nil()))
    }
}

pub fn f94(v0: Adt2, v1: Adt53, v2: Adt68) -> R<Adt94> {
    if f20(v0.clone(), v1.clone()) {
        let m4016 = match v0.clone() {
            Adt2::C0(_, _, _, _, h4015, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4015
            }
        };
        match m4016 {
            None => {
                Ok(Adt94::C0(v0, List::<Adt81>::nil()))
            }
            Some(v3) => {
                Ok(f138(Adt2::C0(match v0.clone() {
                    Adt2::C0(h4017, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4017
                    }
                }, match v0.clone() {
                    Adt2::C0(_, h4018, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4018
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, h4019, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4019
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, h4020, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4020
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, h4021, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4021
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, h4022, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4022
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, h4023, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4023
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, h4024, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4024
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, h4025, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4025
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, h4026, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4026
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, h4027, _, _, _, _, _, _, _, _, _, _) => {
                        h4027
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h4028, _, _, _, _, _, _, _, _, _) => {
                        h4028
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4029, _, _, _, _, _, _, _, _) => {
                        h4029
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h4030, _, _, _, _, _, _, _) => {
                        h4030
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4031, _, _, _, _, _, _) => {
                        h4031
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4032, _, _, _, _, _) => {
                        h4032
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4033, _, _, _, _) => {
                        h4033
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4034, _, _, _) => {
                        h4034
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4035, _, _) => {
                        h4035
                    }
                }, match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4036, _) => {
                        h4036
                    }
                }, f95(match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4037) => {
                        h4037
                    }
                }, v1, v2.clone())?), f139({
                    let m4041 = {
                        let m4040 = f137(v3);
                        match m4040 {
                            Adt13::C0(h4039, _) => {
                                h4039
                            }
                        }
                    };
                    match m4041 {
                        Adt14::C0(_, _, _, _, _, _, h4038) => {
                            h4038
                        }
                    }
                }, match v0 {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4042, _, _) => {
                        h4042
                    }
                }, v2)?))
            }
        }
    } else {
        Ok(Adt94::C0(Adt2::C0(match v0.clone() {
            Adt2::C0(h4043, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4043
            }
        }, match v0.clone() {
            Adt2::C0(_, h4044, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4044
            }
        }, match v0.clone() {
            Adt2::C0(_, _, h4045, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4045
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, h4046, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4046
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, h4047, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4047
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, h4048, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4048
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, h4049, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4049
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, h4050, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4050
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, h4051, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4051
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, h4052, _, _, _, _, _, _, _, _, _, _, _) => {
                h4052
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, h4053, _, _, _, _, _, _, _, _, _, _) => {
                h4053
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h4054, _, _, _, _, _, _, _, _, _) => {
                h4054
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4055, _, _, _, _, _, _, _, _) => {
                h4055
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h4056, _, _, _, _, _, _, _) => {
                h4056
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4057, _, _, _, _, _, _) => {
                h4057
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4058, _, _, _, _, _) => {
                h4058
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4059, _, _, _, _) => {
                h4059
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4060, _, _, _) => {
                h4060
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4061, _, _) => {
                h4061
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4062, _) => {
                h4062
            }
        }, f95(match v0 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4063) => {
                h4063
            }
        }, v1, v2)?), List::<Adt81>::nil()))
    }
}

pub fn f95(v0: List<Adt52>, v1: Adt53, v2: Adt68) -> R<List<Adt52>> {
    let m4064 = v0;
    match m4064.uncons() {
        None => {
            Ok(List::<Adt52>::nil())
        }
        Some((v3, v4)) => {
            Ok(List::cons(if f140(match v3.clone() {
                Adt52::C0(h4065, _, _, _) => {
                    h4065
                }
            }, v1.clone()) {
                Adt52::C0(match v3.clone() {
                    Adt52::C0(h4066, _, _, _) => {
                        h4066
                    }
                }, match v3.clone() {
                    Adt52::C0(_, h4067, _, _) => {
                        h4067
                    }
                }, f139(match v3.clone() {
                    Adt52::C0(_, h4068, _, _) => {
                        h4068
                    }
                }, match v3.clone() {
                    Adt52::C0(_, _, h4069, _) => {
                        h4069
                    }
                }, v2.clone())?, match v3 {
                    Adt52::C0(_, _, _, h4070) => {
                        h4070
                    }
                })
            } else {
                v3
            }, f95(v4, v1, v2)?))
        }
    }
}

pub fn f96(v0: List<Adt52>, v1: Adt53) -> R<List<Adt52>> {
    let m4071 = v0;
    match m4071.uncons() {
        None => {
            Ok(List::<Adt52>::nil())
        }
        Some((v2, v3)) => {
            if if f140(match v2.clone() {
                Adt52::C0(h4072, _, _, _) => {
                    h4072
                }
            }, v1.clone()) {
                let a4076 = f110({
                    let m4075 = match v2.clone() {
                        Adt52::C0(_, _, h4074, _) => {
                            h4074
                        }
                    };
                    match m4075 {
                        Adt51::C0(h4073, _) => {
                            h4073
                        }
                    }
                })?;
                let a4077 = 0u64;
                if nat_eq(a4076, a4077) {
                    let a4081 = f35({
                        let m4080 = match v2.clone() {
                            Adt52::C0(_, _, h4079, _) => {
                                h4079
                            }
                        };
                        match m4080 {
                            Adt51::C0(h4078, _) => {
                                h4078
                            }
                        }
                    })?;
                    let a4082 = 0u64;
                    nat_eq(a4081, a4082)
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(v3)
            } else {
                Ok(List::cons(v2, f96(v3, v1)?))
            }
        }
    }
}

pub fn f97(v0: Bytes, p4095: u64, p4096: u64, p4097: u64) -> R<Option<u64>> {
    let m4094 = (p4095, (p4096, p4097));
    {
        let mut m4094 = m4094;
        loop {
            let step = {
                let (v1, (v2, v3)) = m4094;
                let m4083 = v1;
                if m4083 == 0 {
                    Err::<(u64, (u64, u64)), R<Option<u64>>>(Ok(Some(v3)))
                } else {
                    let v4 = m4083 - 1;
                    let m4086 = {
                        let a4084 = v0.clone();
                        let a4085 = v2;
                        index_bytes(a4084, a4085)
                    };
                    match m4086 {
                        None => {
                            Err::<(u64, (u64, u64)), R<Option<u64>>>(Ok(None::<u64>))
                        }
                        Some(v5) => {
                            let m4087 = f141(v5);
                            match m4087 {
                                None => {
                                    Err::<(u64, (u64, u64)), R<Option<u64>>>(Ok(None::<u64>))
                                }
                                Some(v6) => {
                                    Ok::<(u64, (u64, u64)), R<Option<u64>>>((v4, ({
                                        let a4088 = v2;
                                        let a4089 = 1u64;
                                        nat_add(a4088, a4089)?
                                    }, {
                                        let a4092 = {
                                            let a4090 = v3;
                                            let a4091 = 10u64;
                                            nat_mul(a4090, a4091)?
                                        };
                                        let a4093 = v6;
                                        nat_add(a4092, a4093)?
                                    })))
                                }
                            }
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m4094 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f98(v0: Adt26) -> R<u64> {
    let a4108 = {
        let a4105 = {
            let a4102 = {
                let a4099 = 0u64;
                let a4100 = match v0.clone() {
                    Adt26::C0(h4098, _, _, _) => {
                        h4098
                    }
                };
                nat_add(a4099, a4100)?
            };
            let a4103 = match v0.clone() {
                Adt26::C0(_, h4101, _, _) => {
                    h4101
                }
            };
            nat_add(a4102, a4103)?
        };
        let a4106 = match v0.clone() {
            Adt26::C0(_, _, h4104, _) => {
                h4104
            }
        };
        nat_add(a4105, a4106)?
    };
    let a4109 = match v0 {
        Adt26::C0(_, _, _, h4107) => {
            h4107
        }
    };
    nat_add(a4108, a4109)
}

pub fn f99(v0: Adt48) -> Str {
    let m4110 = v0;
    match m4110 {
        Adt48::C0 => {
            Str::lit("The generated SDK returned a ComputeError.")
        }
        Adt48::C1 => {
            Str::lit("The execution instance terminated. Its output disposition must be reconciled.")
        }
        Adt48::C2 => {
            Str::lit("The host outcome is unknown. Reconcile retained resources before retrying.")
        }
    }
}

pub fn f100(v0: Adt42) -> Str {
    let m4111 = v0;
    match m4111 {
        Adt42::C0(_, _) => {
            Str::lit("The archive syntax is malformed.")
        }
        Adt42::C1(_, _) => {
            Str::lit("The archive parsed but its program could not be decoded or executed.")
        }
        Adt42::C2(_) => {
            Str::lit("Choose the actual external basis bytes required by this archive.")
        }
        Adt42::C3(_) => {
            Str::lit("The supplied basis does not match the archive requirement.")
        }
        Adt42::C4 => {
            Str::lit("Search is incomplete. A checked incumbent remains usable when one is available.")
        }
        Adt42::C5 => {
            Str::lit("Certificate verification is incomplete.")
        }
        Adt42::C6(_, _) => {
            Str::lit("The operation reached a resource budget. Adjust the budget or resume from a checkpoint.")
        }
        Adt42::C7 => {
            Str::lit("Cancelled.")
        }
        Adt42::C8(_) => {
            Str::lit("Input could not be read.")
        }
        Adt42::C9(v10, _) => {
            let m4112 = v10;
            match m4112 {
                Adt8::C0 => {
                    Str::lit("Output remains staged.")
                }
                Adt8::C1 => {
                    Str::lit("The destination reports published output.")
                }
                Adt8::C2 => {
                    Str::lit("Download failed. The checked staged result is retained for retry.")
                }
                Adt8::C3 => {
                    Str::lit("Publication outcome is unknown. Reconcile with the destination before retrying.")
                }
            }
        }
        Adt42::C10(v12) => {
            f142(v12)
        }
        Adt42::C11(_) => {
            Str::lit("The streaming request is out of sequence.")
        }
        Adt42::C12 => {
            Str::lit("Independent reconstruction differs from the original input.")
        }
        Adt42::C13 => {
            Str::lit("Independent verification is incomplete.")
        }
        Adt42::C14(_) => {
            Str::lit("The checkpoint could not be replayed for this input and basis.")
        }
        Adt42::C15(_) => {
            Str::lit("The execution report does not match staged output ownership.")
        }
        Adt42::C16(_) => {
            Str::lit("Storage admission failed. Achieved staging, spool and spill usage is retained in the report.")
        }
    }
}

pub fn f101(v0: Adt55) -> Str {
    let m4113 = v0;
    match m4113 {
        Adt55::C0 => {
            Str::lit("Checked archive ready")
        }
        Adt55::C1 => {
            Str::lit("Checked reconstruction ready")
        }
        Adt55::C2 => {
            Str::lit("Archive inspected")
        }
        Adt55::C3 => {
            Str::lit("Verification complete")
        }
        Adt55::C4 => {
            Str::lit("Checked archive ready")
        }
        Adt55::C5 => {
            Str::lit("Checked basis ready")
        }
        Adt55::C6 => {
            Str::lit("Frontier analysis complete; inspect its search and evidence status")
        }
        Adt55::C7 => {
            Str::lit("Comparison complete; inspect the observations for each archive")
        }
        Adt55::C8 => {
            Str::lit("Acceptance report ready")
        }
        Adt55::C9 => {
            Str::lit("Core request report ready")
        }
    }
}

pub fn f102(v0: Adt1) -> bool {
    let m4117 = {
        let m4116 = match v0 {
            Adt1::C0(h4115, _, _, _, _, _, _) => {
                h4115
            }
        };
        match m4116 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, h4114, _, _, _, _, _, _, _, _, _, _) => {
                h4114
            }
        }
    };
    match m4117 {
        None => {
            false
        }
        Some(v1) => {
            let m4118 = v1;
            match m4118 {
                Adt42::C0(_, _) => {
                    false
                }
                Adt42::C1(_, _) => {
                    false
                }
                Adt42::C2(_) => {
                    true
                }
                Adt42::C3(_) => {
                    true
                }
                Adt42::C4 => {
                    false
                }
                Adt42::C5 => {
                    false
                }
                Adt42::C6(_, _) => {
                    false
                }
                Adt42::C7 => {
                    false
                }
                Adt42::C8(_) => {
                    false
                }
                Adt42::C9(_, _) => {
                    false
                }
                Adt42::C10(_) => {
                    false
                }
                Adt42::C11(_) => {
                    false
                }
                Adt42::C12 => {
                    false
                }
                Adt42::C13 => {
                    false
                }
                Adt42::C14(_) => {
                    false
                }
                Adt42::C15(_) => {
                    false
                }
                Adt42::C16(_) => {
                    false
                }
            }
        }
    }
}

pub fn f103(v0: Adt1, v1: Adt56, v2: List<Adt60>, v3: u64, v4: u64, v5: bool) -> R<List<Adt75>> {
    let m4119 = v2;
    match m4119.uncons() {
        None => {
            Ok(List::<Adt75>::nil())
        }
        Some((v6, v7)) => {
            Ok(List::cons(Adt75::C0(match v6.clone() {
                Adt60::C0(h4120, _, _) => {
                    h4120
                }
            }, v3, match v6.clone() {
                Adt60::C0(_, h4121, _) => {
                    h4121
                }
            }, match v6.clone() {
                Adt60::C0(_, _, h4122) => {
                    h4122
                }
            }, {
                let m4124 = match v6.clone() {
                    Adt60::C0(_, _, h4123) => {
                        h4123
                    }
                };
                match m4124 {
                    None => {
                        false
                    }
                    Some(v8) => {
                        let a4125 = v8;
                        let a4126 = 0u64;
                        nat_eq(a4125, a4126)
                    }
                }
            }, f42(v0.clone(), Adt63::C7(v1.clone(), match v6.clone() {
                Adt60::C0(h4127, _, _) => {
                    h4127
                }
            })), f42(v0.clone(), Adt63::C8(v1.clone(), match v6.clone() {
                Adt60::C0(h4128, _, _) => {
                    h4128
                }
            }, {
                let a4129 = v3;
                let a4130 = 1u64;
                nat_sub(a4129, a4130)
            })), f42(v0.clone(), Adt63::C8(v1.clone(), match v6 {
                Adt60::C0(h4131, _, _) => {
                    h4131
                }
            }, {
                let a4132 = v3;
                let a4133 = 1u64;
                nat_add(a4132, a4133)?
            })), v5, if v5 {
                let a4136 = {
                    let a4134 = v3;
                    let a4135 = 0u64;
                    nat_eq(a4134, a4135)
                };
                bool_not(a4136)
            } else {
                false
            }, if v5 {
                let a4139 = {
                    let a4137 = v3;
                    let a4138 = 1u64;
                    nat_add(a4137, a4138)?
                };
                let a4140 = v4;
                nat_lt(a4139, a4140)
            } else {
                false
            }, {
                let a4141 = v3;
                let a4142 = 1u64;
                nat_add(a4141, a4142)?
            }, Str::lit("Remove object"), Str::lit("Move object earlier"), Str::lit("Move object later")), f103(v0, v1, v7, {
                let a4143 = v3;
                let a4144 = 1u64;
                nat_add(a4143, a4144)?
            }, v4, v5)?))
        }
    }
}

pub fn f104(v0: List<Adt60>) -> R<u64> {
    let m4145 = v0;
    match m4145.uncons() {
        None => {
            Ok(0u64)
        }
        Some((_, v2)) => {
            let a4146 = 1u64;
            let a4147 = f104(v2)?;
            nat_add(a4146, a4147)
        }
    }
}

pub fn f105(v0: Adt56, v1: Adt56) -> bool {
    let m4148 = v0;
    match m4148 {
        Adt56::C0 => {
            let m4149 = v1;
            match m4149 {
                Adt56::C0 => {
                    true
                }
                Adt56::C1 => {
                    false
                }
                Adt56::C2 => {
                    false
                }
                Adt56::C3 => {
                    false
                }
                Adt56::C4 => {
                    false
                }
                Adt56::C5 => {
                    false
                }
            }
        }
        Adt56::C1 => {
            let m4150 = v1;
            match m4150 {
                Adt56::C0 => {
                    false
                }
                Adt56::C1 => {
                    true
                }
                Adt56::C2 => {
                    false
                }
                Adt56::C3 => {
                    false
                }
                Adt56::C4 => {
                    false
                }
                Adt56::C5 => {
                    false
                }
            }
        }
        Adt56::C2 => {
            let m4151 = v1;
            match m4151 {
                Adt56::C0 => {
                    false
                }
                Adt56::C1 => {
                    false
                }
                Adt56::C2 => {
                    true
                }
                Adt56::C3 => {
                    false
                }
                Adt56::C4 => {
                    false
                }
                Adt56::C5 => {
                    false
                }
            }
        }
        Adt56::C3 => {
            let m4152 = v1;
            match m4152 {
                Adt56::C0 => {
                    false
                }
                Adt56::C1 => {
                    false
                }
                Adt56::C2 => {
                    false
                }
                Adt56::C3 => {
                    true
                }
                Adt56::C4 => {
                    false
                }
                Adt56::C5 => {
                    false
                }
            }
        }
        Adt56::C4 => {
            let m4153 = v1;
            match m4153 {
                Adt56::C0 => {
                    false
                }
                Adt56::C1 => {
                    false
                }
                Adt56::C2 => {
                    false
                }
                Adt56::C3 => {
                    false
                }
                Adt56::C4 => {
                    true
                }
                Adt56::C5 => {
                    false
                }
            }
        }
        Adt56::C5 => {
            let m4154 = v1;
            match m4154 {
                Adt56::C0 => {
                    false
                }
                Adt56::C1 => {
                    false
                }
                Adt56::C2 => {
                    false
                }
                Adt56::C3 => {
                    false
                }
                Adt56::C4 => {
                    false
                }
                Adt56::C5 => {
                    true
                }
            }
        }
    }
}

pub fn f106(v0: Adt55, v1: bool, v2: Adt29) -> Adt78 {
    let m4155 = v0;
    match m4155 {
        Adt55::C0 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4156, _, _, _, _) => {
                    h4156
                }
            }, if match v2.clone() {
                Adt29::C0(h4157, _, _, _, _) => {
                    h4157
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4158, _, _, _) => {
                        h4158
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4159, _, _, _, _) => {
                    h4159
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4160, _, _, _) => {
                        h4160
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4161, _, _) => {
                        h4161
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4162, _, _, _, _) => {
                    h4162
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4163, _, _, _) => {
                        h4163
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4164, _, _) => {
                        h4164
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4165, _) => {
                            h4165
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4166, _, _, _, _) => {
                    h4166
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4167, _, _, _) => {
                        h4167
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4168, _, _) => {
                        h4168
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4169) => {
                        h4169
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt55::C1 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4170, _, _, _, _) => {
                    h4170
                }
            }, if match v2.clone() {
                Adt29::C0(h4171, _, _, _, _) => {
                    h4171
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4172, _, _, _) => {
                        h4172
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4173, _, _, _, _) => {
                    h4173
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4174, _, _, _) => {
                        h4174
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4175, _, _) => {
                        h4175
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4176, _, _, _, _) => {
                    h4176
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4177, _, _, _) => {
                        h4177
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4178, _, _) => {
                        h4178
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4179, _) => {
                            h4179
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4180, _, _, _, _) => {
                    h4180
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4181, _, _, _) => {
                        h4181
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4182, _, _) => {
                        h4182
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4183) => {
                        h4183
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt55::C2 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4184, _, _, _, _) => {
                    h4184
                }
            }, if match v2.clone() {
                Adt29::C0(h4185, _, _, _, _) => {
                    h4185
                }
            } {
                match v2 {
                    Adt29::C0(_, h4186, _, _, _) => {
                        h4186
                    }
                }
            } else {
                false
            }, false, false, false, false, false)
        }
        Adt55::C3 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4187, _, _, _, _) => {
                    h4187
                }
            }, if match v2.clone() {
                Adt29::C0(h4188, _, _, _, _) => {
                    h4188
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4189, _, _, _) => {
                        h4189
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4190, _, _, _, _) => {
                    h4190
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4191, _, _, _) => {
                        h4191
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4192, _, _) => {
                        h4192
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4193, _, _, _, _) => {
                    h4193
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4194, _, _, _) => {
                        h4194
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4195, _, _) => {
                        h4195
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4196, _) => {
                            h4196
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4197, _, _, _, _) => {
                    h4197
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4198, _, _, _) => {
                        h4198
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4199, _, _) => {
                        h4199
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4200) => {
                        h4200
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt55::C4 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4201, _, _, _, _) => {
                    h4201
                }
            }, if match v2.clone() {
                Adt29::C0(h4202, _, _, _, _) => {
                    h4202
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4203, _, _, _) => {
                        h4203
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4204, _, _, _, _) => {
                    h4204
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4205, _, _, _) => {
                        h4205
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4206, _, _) => {
                        h4206
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4207, _, _, _, _) => {
                    h4207
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4208, _, _, _) => {
                        h4208
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4209, _, _) => {
                        h4209
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4210, _) => {
                            h4210
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4211, _, _, _, _) => {
                    h4211
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4212, _, _, _) => {
                        h4212
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4213, _, _) => {
                        h4213
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4214) => {
                        h4214
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt55::C5 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4215, _, _, _, _) => {
                    h4215
                }
            }, if match v2.clone() {
                Adt29::C0(h4216, _, _, _, _) => {
                    h4216
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4217, _, _, _) => {
                        h4217
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4218, _, _, _, _) => {
                    h4218
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4219, _, _, _) => {
                        h4219
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4220, _, _) => {
                        h4220
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4221, _, _, _, _) => {
                    h4221
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4222, _, _, _) => {
                        h4222
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4223, _, _) => {
                        h4223
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4224, _) => {
                            h4224
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4225, _, _, _, _) => {
                    h4225
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4226, _, _, _) => {
                        h4226
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4227, _, _) => {
                        h4227
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4228) => {
                        h4228
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt55::C6 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4229, _, _, _, _) => {
                    h4229
                }
            }, if match v2.clone() {
                Adt29::C0(h4230, _, _, _, _) => {
                    h4230
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4231, _, _, _) => {
                        h4231
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4232, _, _, _, _) => {
                    h4232
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4233, _, _, _) => {
                        h4233
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4234, _, _) => {
                        h4234
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4235, _, _, _, _) => {
                    h4235
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4236, _, _, _) => {
                        h4236
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4237, _, _) => {
                        h4237
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4238, _) => {
                            h4238
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4239, _, _, _, _) => {
                    h4239
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4240, _, _, _) => {
                        h4240
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4241, _, _) => {
                        h4241
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4242) => {
                        h4242
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt55::C7 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4243, _, _, _, _) => {
                    h4243
                }
            }, if match v2.clone() {
                Adt29::C0(h4244, _, _, _, _) => {
                    h4244
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4245, _, _, _) => {
                        h4245
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4246, _, _, _, _) => {
                    h4246
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4247, _, _, _) => {
                        h4247
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4248, _, _) => {
                        h4248
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4249, _, _, _, _) => {
                    h4249
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4250, _, _, _) => {
                        h4250
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4251, _, _) => {
                        h4251
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4252, _) => {
                            h4252
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4253, _, _, _, _) => {
                    h4253
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4254, _, _, _) => {
                        h4254
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4255, _, _) => {
                        h4255
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4256) => {
                        h4256
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt55::C8 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4257, _, _, _, _) => {
                    h4257
                }
            }, if match v2.clone() {
                Adt29::C0(h4258, _, _, _, _) => {
                    h4258
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4259, _, _, _) => {
                        h4259
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4260, _, _, _, _) => {
                    h4260
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4261, _, _, _) => {
                        h4261
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4262, _, _) => {
                        h4262
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4263, _, _, _, _) => {
                    h4263
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4264, _, _, _) => {
                        h4264
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4265, _, _) => {
                        h4265
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4266, _) => {
                            h4266
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4267, _, _, _, _) => {
                    h4267
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4268, _, _, _) => {
                        h4268
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4269, _, _) => {
                        h4269
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4270) => {
                        h4270
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt55::C9 => {
            Adt78::C0(match v2.clone() {
                Adt29::C0(h4271, _, _, _, _) => {
                    h4271
                }
            }, if match v2.clone() {
                Adt29::C0(h4272, _, _, _, _) => {
                    h4272
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4273, _, _, _) => {
                        h4273
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt29::C0(h4274, _, _, _, _) => {
                    h4274
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4275, _, _, _) => {
                        h4275
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4276, _, _) => {
                        h4276
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4277, _, _, _, _) => {
                    h4277
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4278, _, _, _) => {
                        h4278
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4279, _, _) => {
                        h4279
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt29::C0(_, _, _, h4280, _) => {
                            h4280
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt29::C0(h4281, _, _, _, _) => {
                    h4281
                }
            } {
                match v2.clone() {
                    Adt29::C0(_, h4282, _, _, _) => {
                        h4282
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt29::C0(_, _, h4283, _, _) => {
                        h4283
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt29::C0(_, _, _, _, h4284) => {
                        h4284
                    }
                }
            } else {
                false
            }, false, false)
        }
    }
}

pub fn f107(v0: Adt31) -> Adt95 {
    let m4285 = v0;
    match m4285 {
        Adt31::C0 => {
            Adt95::C0
        }
        Adt31::C1(_) => {
            Adt95::C3
        }
        Adt31::C2(_) => {
            Adt95::C2
        }
        Adt31::C3(_) => {
            Adt95::C3
        }
        Adt31::C4(_) => {
            Adt95::C1
        }
    }
}

pub fn f108(v0: Option<u64>) -> R<Str> {
    let m4286 = v0;
    match m4286 {
        None => {
            Ok(Str::lit(""))
        }
        Some(v1) => {
            f143(v1)
        }
    }
}

pub fn f109(v0: Adt1, v1: Adt70) -> Adt69 {
    Adt69::C0(f84(match v0.clone() {
        Adt1::C0(h4287, _, _, _, _, _, _) => {
            h4287
        }
    }), match v0 {
        Adt1::C0(_, _, h4288, _, _, _, _) => {
            h4288
        }
    }, v1)
}

pub fn f110(v0: Adt25) -> R<u64> {
    f98(match v0 {
        Adt25::C0(h4289, _, _, _) => {
            h4289
        }
    })
}

pub fn f111() -> Adt25 {
    Adt25::C0(f144(), f144(), 0u64, 0u64)
}

pub fn f112(v0: Adt1, v1: Adt54) -> R<Adt89> {
    Ok(f27(v0.clone(), v1, f28(match v0 {
        Adt1::C0(h4290, _, _, _, _, _, _) => {
            h4290
        }
    }, Adt92::C1)?))
}

pub fn f113(p4296: List<Adt60>, v1: u64) -> bool {
    let m4295 = p4296;
    {
        let mut m4295 = m4295;
        loop {
            let step = {
                let v0 = m4295;
                let m4291 = v0;
                match m4291.uncons() {
                    None => {
                        Err::<List<Adt60>, bool>(false)
                    }
                    Some((v2, v3)) => {
                        let a4293 = match v2 {
                            Adt60::C0(h4292, _, _) => {
                                h4292
                            }
                        };
                        let a4294 = v1;
                        if nat_eq(a4293, a4294) {
                            Err::<List<Adt60>, bool>(true)
                        } else {
                            Ok::<List<Adt60>, bool>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m4295 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f114(v0: List<Adt81>, v1: List<Adt81>) -> List<Adt81> {
    let m4297 = v0;
    match m4297.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f114(v3, v1))
        }
    }
}

pub fn f115(v0: Option<Adt12>, v1: Option<Adt12>) -> List<Adt81> {
    let m4298 = v0;
    match m4298 {
        None => {
            List::<Adt81>::nil()
        }
        Some(v2) => {
            let m4299 = v1;
            match m4299 {
                None => {
                    List::cons(Adt81::C6(v2), List::<Adt81>::nil())
                }
                Some(v3) => {
                    if f34(v2.clone(), v3) {
                        List::<Adt81>::nil()
                    } else {
                        List::cons(Adt81::C6(v2), List::<Adt81>::nil())
                    }
                }
            }
        }
    }
}

pub fn f116(v0: Adt54, v1: Adt56) -> Option<Adt12> {
    let m4300 = v1;
    match m4300 {
        Adt56::C0 => {
            match v0 {
                Adt54::C0(_, h4301, _, _, _, _, _, _) => {
                    h4301
                }
            }
        }
        Adt56::C1 => {
            match v0 {
                Adt54::C0(_, _, h4302, _, _, _, _, _) => {
                    h4302
                }
            }
        }
        Adt56::C2 => {
            match v0 {
                Adt54::C0(_, _, _, h4303, _, _, _, _) => {
                    h4303
                }
            }
        }
        Adt56::C3 => {
            match v0 {
                Adt54::C0(_, _, _, _, h4304, _, _, _) => {
                    h4304
                }
            }
        }
        Adt56::C4 => {
            match v0 {
                Adt54::C0(_, _, _, _, _, h4305, _, _) => {
                    h4305
                }
            }
        }
        Adt56::C5 => {
            match v0 {
                Adt54::C0(_, _, _, _, _, _, h4306, _) => {
                    h4306
                }
            }
        }
    }
}

pub fn f117(v0: Adt3) -> R<Adt3> {
    Ok(Adt3::C0(match v0.clone() {
        Adt3::C0(h4307, _, _, _, _, _) => {
            h4307
        }
    }, {
        let a4309 = match v0 {
            Adt3::C0(_, h4308, _, _, _, _) => {
                h4308
            }
        };
        let a4310 = 1u64;
        nat_add(a4309, a4310)?
    }, true, false, Adt4::C1, Adt5::C0))
}

pub fn f118(v0: Adt2) -> List<Adt52> {
    if match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4311, _, _, _) => {
            h4311
        }
    } {
        List::cons(Adt52::C0(f84(v0.clone()), {
            let m4313 = match v0.clone() {
                Adt2::C0(_, _, _, _, h4312, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4312
                }
            };
            match m4313 {
                None => {
                    f57()
                }
                Some(v1) => {
                    let m4317 = {
                        let m4316 = f137(v1);
                        match m4316 {
                            Adt13::C0(h4315, _) => {
                                h4315
                            }
                        }
                    };
                    match m4317 {
                        Adt14::C0(_, _, _, _, _, _, h4314) => {
                            h4314
                        }
                    }
                }
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4318, _, _) => {
                h4318
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4319, _) => {
                h4319
            }
        }), match v0 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4320) => {
                h4320
            }
        })
    } else {
        match v0 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4321) => {
                h4321
            }
        }
    }
}

pub fn f119(v0: Adt2) -> List<Adt81> {
    f114(if match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, h4322, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h4322
        }
    } {
        List::cons(Adt81::C9(f84(v0.clone())), List::<Adt81>::nil())
    } else {
        List::<Adt81>::nil()
    }, f114(if match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4323, _, _, _) => {
            h4323
        }
    } {
        let m4326 = match v0.clone() {
            Adt2::C0(_, h4325, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4325
            }
        };
        if match m4326 {
            Adt3::C0(_, _, h4324, _, _, _) => {
                h4324
            }
        } {
            List::cons(Adt81::C4(f84(v0.clone())), List::cons(Adt81::C5(f84(v0.clone())), List::<Adt81>::nil()))
        } else {
            List::cons(Adt81::C5(f84(v0.clone())), List::<Adt81>::nil())
        }
    } else {
        List::<Adt81>::nil()
    }, f114(f85(match v0.clone() {
        Adt2::C0(_, _, _, _, _, _, _, h4327, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h4327
        }
    }), f85(match v0 {
        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4328, _, _, _, _, _, _, _, _) => {
            h4328
        }
    }))))
}

pub fn f120(v0: Adt1) -> R<Adt89> {
    let m4330 = match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h4329) => {
            h4329
        }
    };
    match m4330 {
        None => {
            let m4333 = match v0.clone() {
                Adt1::C0(h4332, _, _, _, _, _, _) => {
                    h4332
                }
            };
            if match m4333 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4331, _, _, _, _, _, _) => {
                    h4331
                }
            } {
                Ok(f27(v0.clone(), match v0.clone() {
                    Adt1::C0(_, h4334, _, _, _, _, _) => {
                        h4334
                    }
                }, f81(match v0 {
                    Adt1::C0(h4335, _, _, _, _, _, _) => {
                        h4335
                    }
                })?))
            } else {
                Ok(Adt89::C0(Adt1::C0({
                    let m4338 = f81(match v0.clone() {
                        Adt1::C0(h4337, _, _, _, _, _, _) => {
                            h4337
                        }
                    })?;
                    match m4338 {
                        Adt94::C0(h4336, _) => {
                            h4336
                        }
                    }
                }, Adt54::C0({
                    let m4341 = match v0.clone() {
                        Adt1::C0(_, h4340, _, _, _, _, _) => {
                            h4340
                        }
                    };
                    match m4341 {
                        Adt54::C0(h4339, _, _, _, _, _, _, _) => {
                            h4339
                        }
                    }
                }, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, {
                    let m4344 = match v0.clone() {
                        Adt1::C0(_, h4343, _, _, _, _, _) => {
                            h4343
                        }
                    };
                    match m4344 {
                        Adt54::C0(_, _, _, _, _, _, _, h4342) => {
                            h4342
                        }
                    }
                }), match v0.clone() {
                    Adt1::C0(_, _, h4345, _, _, _, _) => {
                        h4345
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h4346, _, _, _) => {
                        h4346
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h4347, _, _) => {
                        h4347
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h4348, _) => {
                        h4348
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h4349) => {
                        h4349
                    }
                }), f78(f114(f145(match v0.clone() {
                    Adt1::C0(_, h4350, _, _, _, _, _) => {
                        h4350
                    }
                }), {
                    let m4353 = f81(match v0 {
                        Adt1::C0(h4352, _, _, _, _, _, _) => {
                            h4352
                        }
                    })?;
                    match m4353 {
                        Adt94::C0(_, h4351) => {
                            h4351
                        }
                    }
                }))))
            }
        }
        Some(v1) => {
            Ok(Adt89::C0(Adt1::C0({
                let m4380 = {
                    let m4379 = {
                        let m4358 = match v0.clone() {
                            Adt1::C0(h4357, _, _, _, _, _, _) => {
                                h4357
                            }
                        };
                        if match m4358 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4356, _, _, _, _, _, _) => {
                                h4356
                            }
                        } {
                            f27(v0.clone(), match v0.clone() {
                                Adt1::C0(_, h4359, _, _, _, _, _) => {
                                    h4359
                                }
                            }, f81(match v0.clone() {
                                Adt1::C0(h4360, _, _, _, _, _, _) => {
                                    h4360
                                }
                            })?)
                        } else {
                            Adt89::C0(Adt1::C0({
                                let m4363 = f81(match v0.clone() {
                                    Adt1::C0(h4362, _, _, _, _, _, _) => {
                                        h4362
                                    }
                                })?;
                                match m4363 {
                                    Adt94::C0(h4361, _) => {
                                        h4361
                                    }
                                }
                            }, Adt54::C0({
                                let m4366 = match v0.clone() {
                                    Adt1::C0(_, h4365, _, _, _, _, _) => {
                                        h4365
                                    }
                                };
                                match m4366 {
                                    Adt54::C0(h4364, _, _, _, _, _, _, _) => {
                                        h4364
                                    }
                                }
                            }, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, {
                                let m4369 = match v0.clone() {
                                    Adt1::C0(_, h4368, _, _, _, _, _) => {
                                        h4368
                                    }
                                };
                                match m4369 {
                                    Adt54::C0(_, _, _, _, _, _, _, h4367) => {
                                        h4367
                                    }
                                }
                            }), match v0.clone() {
                                Adt1::C0(_, _, h4370, _, _, _, _) => {
                                    h4370
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h4371, _, _, _) => {
                                    h4371
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h4372, _, _) => {
                                    h4372
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h4373, _) => {
                                    h4373
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h4374) => {
                                    h4374
                                }
                            }), f78(f114(f145(match v0.clone() {
                                Adt1::C0(_, h4375, _, _, _, _, _) => {
                                    h4375
                                }
                            }), {
                                let m4378 = f81(match v0.clone() {
                                    Adt1::C0(h4377, _, _, _, _, _, _) => {
                                        h4377
                                    }
                                })?;
                                match m4378 {
                                    Adt94::C0(_, h4376) => {
                                        h4376
                                    }
                                }
                            })))
                        }
                    };
                    match m4379 {
                        Adt89::C0(h4355, _) => {
                            h4355
                        }
                    }
                };
                match m4380 {
                    Adt1::C0(h4354, _, _, _, _, _, _) => {
                        h4354
                    }
                }
            }, {
                let m4407 = {
                    let m4406 = {
                        let m4385 = match v0.clone() {
                            Adt1::C0(h4384, _, _, _, _, _, _) => {
                                h4384
                            }
                        };
                        if match m4385 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4383, _, _, _, _, _, _) => {
                                h4383
                            }
                        } {
                            f27(v0.clone(), match v0.clone() {
                                Adt1::C0(_, h4386, _, _, _, _, _) => {
                                    h4386
                                }
                            }, f81(match v0.clone() {
                                Adt1::C0(h4387, _, _, _, _, _, _) => {
                                    h4387
                                }
                            })?)
                        } else {
                            Adt89::C0(Adt1::C0({
                                let m4390 = f81(match v0.clone() {
                                    Adt1::C0(h4389, _, _, _, _, _, _) => {
                                        h4389
                                    }
                                })?;
                                match m4390 {
                                    Adt94::C0(h4388, _) => {
                                        h4388
                                    }
                                }
                            }, Adt54::C0({
                                let m4393 = match v0.clone() {
                                    Adt1::C0(_, h4392, _, _, _, _, _) => {
                                        h4392
                                    }
                                };
                                match m4393 {
                                    Adt54::C0(h4391, _, _, _, _, _, _, _) => {
                                        h4391
                                    }
                                }
                            }, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, {
                                let m4396 = match v0.clone() {
                                    Adt1::C0(_, h4395, _, _, _, _, _) => {
                                        h4395
                                    }
                                };
                                match m4396 {
                                    Adt54::C0(_, _, _, _, _, _, _, h4394) => {
                                        h4394
                                    }
                                }
                            }), match v0.clone() {
                                Adt1::C0(_, _, h4397, _, _, _, _) => {
                                    h4397
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h4398, _, _, _) => {
                                    h4398
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h4399, _, _) => {
                                    h4399
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h4400, _) => {
                                    h4400
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h4401) => {
                                    h4401
                                }
                            }), f78(f114(f145(match v0.clone() {
                                Adt1::C0(_, h4402, _, _, _, _, _) => {
                                    h4402
                                }
                            }), {
                                let m4405 = f81(match v0.clone() {
                                    Adt1::C0(h4404, _, _, _, _, _, _) => {
                                        h4404
                                    }
                                })?;
                                match m4405 {
                                    Adt94::C0(_, h4403) => {
                                        h4403
                                    }
                                }
                            })))
                        }
                    };
                    match m4406 {
                        Adt89::C0(h4382, _) => {
                            h4382
                        }
                    }
                };
                match m4407 {
                    Adt1::C0(_, h4381, _, _, _, _, _) => {
                        h4381
                    }
                }
            }, {
                let m4434 = {
                    let m4433 = {
                        let m4412 = match v0.clone() {
                            Adt1::C0(h4411, _, _, _, _, _, _) => {
                                h4411
                            }
                        };
                        if match m4412 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4410, _, _, _, _, _, _) => {
                                h4410
                            }
                        } {
                            f27(v0.clone(), match v0.clone() {
                                Adt1::C0(_, h4413, _, _, _, _, _) => {
                                    h4413
                                }
                            }, f81(match v0.clone() {
                                Adt1::C0(h4414, _, _, _, _, _, _) => {
                                    h4414
                                }
                            })?)
                        } else {
                            Adt89::C0(Adt1::C0({
                                let m4417 = f81(match v0.clone() {
                                    Adt1::C0(h4416, _, _, _, _, _, _) => {
                                        h4416
                                    }
                                })?;
                                match m4417 {
                                    Adt94::C0(h4415, _) => {
                                        h4415
                                    }
                                }
                            }, Adt54::C0({
                                let m4420 = match v0.clone() {
                                    Adt1::C0(_, h4419, _, _, _, _, _) => {
                                        h4419
                                    }
                                };
                                match m4420 {
                                    Adt54::C0(h4418, _, _, _, _, _, _, _) => {
                                        h4418
                                    }
                                }
                            }, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, {
                                let m4423 = match v0.clone() {
                                    Adt1::C0(_, h4422, _, _, _, _, _) => {
                                        h4422
                                    }
                                };
                                match m4423 {
                                    Adt54::C0(_, _, _, _, _, _, _, h4421) => {
                                        h4421
                                    }
                                }
                            }), match v0.clone() {
                                Adt1::C0(_, _, h4424, _, _, _, _) => {
                                    h4424
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h4425, _, _, _) => {
                                    h4425
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h4426, _, _) => {
                                    h4426
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h4427, _) => {
                                    h4427
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h4428) => {
                                    h4428
                                }
                            }), f78(f114(f145(match v0.clone() {
                                Adt1::C0(_, h4429, _, _, _, _, _) => {
                                    h4429
                                }
                            }), {
                                let m4432 = f81(match v0.clone() {
                                    Adt1::C0(h4431, _, _, _, _, _, _) => {
                                        h4431
                                    }
                                })?;
                                match m4432 {
                                    Adt94::C0(_, h4430) => {
                                        h4430
                                    }
                                }
                            })))
                        }
                    };
                    match m4433 {
                        Adt89::C0(h4409, _) => {
                            h4409
                        }
                    }
                };
                match m4434 {
                    Adt1::C0(_, _, h4408, _, _, _, _) => {
                        h4408
                    }
                }
            }, {
                let m4461 = {
                    let m4460 = {
                        let m4439 = match v0.clone() {
                            Adt1::C0(h4438, _, _, _, _, _, _) => {
                                h4438
                            }
                        };
                        if match m4439 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4437, _, _, _, _, _, _) => {
                                h4437
                            }
                        } {
                            f27(v0.clone(), match v0.clone() {
                                Adt1::C0(_, h4440, _, _, _, _, _) => {
                                    h4440
                                }
                            }, f81(match v0.clone() {
                                Adt1::C0(h4441, _, _, _, _, _, _) => {
                                    h4441
                                }
                            })?)
                        } else {
                            Adt89::C0(Adt1::C0({
                                let m4444 = f81(match v0.clone() {
                                    Adt1::C0(h4443, _, _, _, _, _, _) => {
                                        h4443
                                    }
                                })?;
                                match m4444 {
                                    Adt94::C0(h4442, _) => {
                                        h4442
                                    }
                                }
                            }, Adt54::C0({
                                let m4447 = match v0.clone() {
                                    Adt1::C0(_, h4446, _, _, _, _, _) => {
                                        h4446
                                    }
                                };
                                match m4447 {
                                    Adt54::C0(h4445, _, _, _, _, _, _, _) => {
                                        h4445
                                    }
                                }
                            }, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, {
                                let m4450 = match v0.clone() {
                                    Adt1::C0(_, h4449, _, _, _, _, _) => {
                                        h4449
                                    }
                                };
                                match m4450 {
                                    Adt54::C0(_, _, _, _, _, _, _, h4448) => {
                                        h4448
                                    }
                                }
                            }), match v0.clone() {
                                Adt1::C0(_, _, h4451, _, _, _, _) => {
                                    h4451
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h4452, _, _, _) => {
                                    h4452
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h4453, _, _) => {
                                    h4453
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h4454, _) => {
                                    h4454
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h4455) => {
                                    h4455
                                }
                            }), f78(f114(f145(match v0.clone() {
                                Adt1::C0(_, h4456, _, _, _, _, _) => {
                                    h4456
                                }
                            }), {
                                let m4459 = f81(match v0.clone() {
                                    Adt1::C0(h4458, _, _, _, _, _, _) => {
                                        h4458
                                    }
                                })?;
                                match m4459 {
                                    Adt94::C0(_, h4457) => {
                                        h4457
                                    }
                                }
                            })))
                        }
                    };
                    match m4460 {
                        Adt89::C0(h4436, _) => {
                            h4436
                        }
                    }
                };
                match m4461 {
                    Adt1::C0(_, _, _, h4435, _, _, _) => {
                        h4435
                    }
                }
            }, {
                let m4488 = {
                    let m4487 = {
                        let m4466 = match v0.clone() {
                            Adt1::C0(h4465, _, _, _, _, _, _) => {
                                h4465
                            }
                        };
                        if match m4466 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4464, _, _, _, _, _, _) => {
                                h4464
                            }
                        } {
                            f27(v0.clone(), match v0.clone() {
                                Adt1::C0(_, h4467, _, _, _, _, _) => {
                                    h4467
                                }
                            }, f81(match v0.clone() {
                                Adt1::C0(h4468, _, _, _, _, _, _) => {
                                    h4468
                                }
                            })?)
                        } else {
                            Adt89::C0(Adt1::C0({
                                let m4471 = f81(match v0.clone() {
                                    Adt1::C0(h4470, _, _, _, _, _, _) => {
                                        h4470
                                    }
                                })?;
                                match m4471 {
                                    Adt94::C0(h4469, _) => {
                                        h4469
                                    }
                                }
                            }, Adt54::C0({
                                let m4474 = match v0.clone() {
                                    Adt1::C0(_, h4473, _, _, _, _, _) => {
                                        h4473
                                    }
                                };
                                match m4474 {
                                    Adt54::C0(h4472, _, _, _, _, _, _, _) => {
                                        h4472
                                    }
                                }
                            }, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, {
                                let m4477 = match v0.clone() {
                                    Adt1::C0(_, h4476, _, _, _, _, _) => {
                                        h4476
                                    }
                                };
                                match m4477 {
                                    Adt54::C0(_, _, _, _, _, _, _, h4475) => {
                                        h4475
                                    }
                                }
                            }), match v0.clone() {
                                Adt1::C0(_, _, h4478, _, _, _, _) => {
                                    h4478
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h4479, _, _, _) => {
                                    h4479
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h4480, _, _) => {
                                    h4480
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h4481, _) => {
                                    h4481
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h4482) => {
                                    h4482
                                }
                            }), f78(f114(f145(match v0.clone() {
                                Adt1::C0(_, h4483, _, _, _, _, _) => {
                                    h4483
                                }
                            }), {
                                let m4486 = f81(match v0.clone() {
                                    Adt1::C0(h4485, _, _, _, _, _, _) => {
                                        h4485
                                    }
                                })?;
                                match m4486 {
                                    Adt94::C0(_, h4484) => {
                                        h4484
                                    }
                                }
                            })))
                        }
                    };
                    match m4487 {
                        Adt89::C0(h4463, _) => {
                            h4463
                        }
                    }
                };
                match m4488 {
                    Adt1::C0(_, _, _, _, h4462, _, _) => {
                        h4462
                    }
                }
            }, {
                let m4515 = {
                    let m4514 = {
                        let m4493 = match v0.clone() {
                            Adt1::C0(h4492, _, _, _, _, _, _) => {
                                h4492
                            }
                        };
                        if match m4493 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4491, _, _, _, _, _, _) => {
                                h4491
                            }
                        } {
                            f27(v0.clone(), match v0.clone() {
                                Adt1::C0(_, h4494, _, _, _, _, _) => {
                                    h4494
                                }
                            }, f81(match v0.clone() {
                                Adt1::C0(h4495, _, _, _, _, _, _) => {
                                    h4495
                                }
                            })?)
                        } else {
                            Adt89::C0(Adt1::C0({
                                let m4498 = f81(match v0.clone() {
                                    Adt1::C0(h4497, _, _, _, _, _, _) => {
                                        h4497
                                    }
                                })?;
                                match m4498 {
                                    Adt94::C0(h4496, _) => {
                                        h4496
                                    }
                                }
                            }, Adt54::C0({
                                let m4501 = match v0.clone() {
                                    Adt1::C0(_, h4500, _, _, _, _, _) => {
                                        h4500
                                    }
                                };
                                match m4501 {
                                    Adt54::C0(h4499, _, _, _, _, _, _, _) => {
                                        h4499
                                    }
                                }
                            }, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, {
                                let m4504 = match v0.clone() {
                                    Adt1::C0(_, h4503, _, _, _, _, _) => {
                                        h4503
                                    }
                                };
                                match m4504 {
                                    Adt54::C0(_, _, _, _, _, _, _, h4502) => {
                                        h4502
                                    }
                                }
                            }), match v0.clone() {
                                Adt1::C0(_, _, h4505, _, _, _, _) => {
                                    h4505
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h4506, _, _, _) => {
                                    h4506
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h4507, _, _) => {
                                    h4507
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h4508, _) => {
                                    h4508
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h4509) => {
                                    h4509
                                }
                            }), f78(f114(f145(match v0.clone() {
                                Adt1::C0(_, h4510, _, _, _, _, _) => {
                                    h4510
                                }
                            }), {
                                let m4513 = f81(match v0.clone() {
                                    Adt1::C0(h4512, _, _, _, _, _, _) => {
                                        h4512
                                    }
                                })?;
                                match m4513 {
                                    Adt94::C0(_, h4511) => {
                                        h4511
                                    }
                                }
                            })))
                        }
                    };
                    match m4514 {
                        Adt89::C0(h4490, _) => {
                            h4490
                        }
                    }
                };
                match m4515 {
                    Adt1::C0(_, _, _, _, _, h4489, _) => {
                        h4489
                    }
                }
            }, None::<Adt61>), List::cons(Adt80::C3(v1.clone()), List::cons(Adt80::C0(Adt81::C6(match v1 {
                Adt61::C0(_, _, _, h4516, _, _) => {
                    h4516
                }
            })), {
                let m4541 = {
                    let m4520 = match v0.clone() {
                        Adt1::C0(h4519, _, _, _, _, _, _) => {
                            h4519
                        }
                    };
                    if match m4520 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4518, _, _, _, _, _, _) => {
                            h4518
                        }
                    } {
                        f27(v0.clone(), match v0.clone() {
                            Adt1::C0(_, h4521, _, _, _, _, _) => {
                                h4521
                            }
                        }, f81(match v0 {
                            Adt1::C0(h4522, _, _, _, _, _, _) => {
                                h4522
                            }
                        })?)
                    } else {
                        Adt89::C0(Adt1::C0({
                            let m4525 = f81(match v0.clone() {
                                Adt1::C0(h4524, _, _, _, _, _, _) => {
                                    h4524
                                }
                            })?;
                            match m4525 {
                                Adt94::C0(h4523, _) => {
                                    h4523
                                }
                            }
                        }, Adt54::C0({
                            let m4528 = match v0.clone() {
                                Adt1::C0(_, h4527, _, _, _, _, _) => {
                                    h4527
                                }
                            };
                            match m4528 {
                                Adt54::C0(h4526, _, _, _, _, _, _, _) => {
                                    h4526
                                }
                            }
                        }, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, None::<Adt12>, {
                            let m4531 = match v0.clone() {
                                Adt1::C0(_, h4530, _, _, _, _, _) => {
                                    h4530
                                }
                            };
                            match m4531 {
                                Adt54::C0(_, _, _, _, _, _, _, h4529) => {
                                    h4529
                                }
                            }
                        }), match v0.clone() {
                            Adt1::C0(_, _, h4532, _, _, _, _) => {
                                h4532
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, h4533, _, _, _) => {
                                h4533
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h4534, _, _) => {
                                h4534
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h4535, _) => {
                                h4535
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h4536) => {
                                h4536
                            }
                        }), f78(f114(f145(match v0.clone() {
                            Adt1::C0(_, h4537, _, _, _, _, _) => {
                                h4537
                            }
                        }), {
                            let m4540 = f81(match v0 {
                                Adt1::C0(h4539, _, _, _, _, _, _) => {
                                    h4539
                                }
                            })?;
                            match m4540 {
                                Adt94::C0(_, h4538) => {
                                    h4538
                                }
                            }
                        })))
                    }
                };
                match m4541 {
                    Adt89::C0(_, h4517) => {
                        h4517
                    }
                }
            }))))
        }
    }
}

pub fn f121(v0: Adt2, v1: Adt18) -> R<Adt94> {
    f67(v0, Adt10::C4(v1))
}

pub fn f122(p4547: List<Adt60>, v1: u64) -> Option<Adt60> {
    let m4546 = p4547;
    {
        let mut m4546 = m4546;
        loop {
            let step = {
                let v0 = m4546;
                let m4542 = v0;
                match m4542.uncons() {
                    None => {
                        Err::<List<Adt60>, Option<Adt60>>(None::<Adt60>)
                    }
                    Some((v2, v3)) => {
                        let a4544 = match v2.clone() {
                            Adt60::C0(h4543, _, _) => {
                                h4543
                            }
                        };
                        let a4545 = v1;
                        if nat_eq(a4544, a4545) {
                            Err::<List<Adt60>, Option<Adt60>>(Some(v2))
                        } else {
                            Ok::<List<Adt60>, Option<Adt60>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m4546 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f123(v0: List<Adt60>, v1: u64, v2: Adt60) -> List<Adt60> {
    let m4548 = v0;
    match m4548.uncons() {
        None => {
            List::cons(v2, List::<Adt60>::nil())
        }
        Some((v3, v4)) => {
            let a4549 = v1;
            let a4550 = 0u64;
            if nat_eq(a4549, a4550) {
                List::cons(v2, List::cons(v3, v4))
            } else {
                List::cons(v3, f123(v4, {
                    let a4551 = v1;
                    let a4552 = 1u64;
                    nat_sub(a4551, a4552)
                }, v2))
            }
        }
    }
}

pub fn f124(p4561: List<Adt60>, p4562: List<Adt60>) -> bool {
    let m4560 = (p4561, p4562);
    {
        let mut m4560 = m4560;
        loop {
            let step = {
                let (v0, v1) = m4560;
                let m4553 = v0;
                match m4553.uncons() {
                    None => {
                        let m4554 = v1;
                        match m4554.uncons() {
                            None => {
                                Err::<(List<Adt60>, List<Adt60>), bool>(true)
                            }
                            Some((_, _)) => {
                                Err::<(List<Adt60>, List<Adt60>), bool>(false)
                            }
                        }
                    }
                    Some((v4, v5)) => {
                        let m4555 = v1;
                        match m4555.uncons() {
                            None => {
                                Err::<(List<Adt60>, List<Adt60>), bool>(false)
                            }
                            Some((v6, v7)) => {
                                let a4558 = match v4 {
                                    Adt60::C0(h4556, _, _) => {
                                        h4556
                                    }
                                };
                                let a4559 = match v6 {
                                    Adt60::C0(h4557, _, _) => {
                                        h4557
                                    }
                                };
                                if nat_eq(a4558, a4559) {
                                    Ok::<(List<Adt60>, List<Adt60>), bool>((v5, v7))
                                } else {
                                    Err::<(List<Adt60>, List<Adt60>), bool>(false)
                                }
                            }
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m4560 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f125(v0: Adt3, v1: u64, v2: u64) -> bool {
    if match v0.clone() {
        Adt3::C0(_, _, h4563, _, _, _) => {
            h4563
        }
    } {
        let a4565 = match v0.clone() {
            Adt3::C0(_, h4564, _, _, _, _) => {
                h4564
            }
        };
        let a4566 = v1;
        if nat_eq(a4565, a4566) {
            let a4568 = match v0 {
                Adt3::C0(h4567, _, _, _, _, _) => {
                    h4567
                }
            };
            let a4569 = v2;
            nat_eq(a4568, a4569)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f126(v0: Adt3) -> R<Adt3> {
    Ok(Adt3::C0({
        let a4571 = match v0.clone() {
            Adt3::C0(h4570, _, _, _, _, _) => {
                h4570
            }
        };
        let a4572 = 1u64;
        nat_add(a4571, a4572)?
    }, match v0 {
        Adt3::C0(_, h4573, _, _, _, _) => {
            h4573
        }
    }, false, false, Adt4::C0, Adt5::C0))
}

pub fn f127(v0: Adt6) -> Result<Adt6, Adt45> {
    let m4575 = match v0.clone() {
        Adt6::C0(h4574, _, _, _, _) => {
            h4574
        }
    };
    match m4575 {
        Adt7::C0 => {
            if match v0.clone() {
                Adt6::C0(_, h4576, _, _, _) => {
                    h4576
                }
            } {
                Err::<Adt6, Adt45>(Adt45::C1)
            } else {
                Ok::<Adt6, Adt45>(Adt6::C0(Adt7::C1, match v0.clone() {
                    Adt6::C0(_, h4577, _, _, _) => {
                        h4577
                    }
                }, match v0.clone() {
                    Adt6::C0(_, _, h4578, _, _) => {
                        h4578
                    }
                }, match v0.clone() {
                    Adt6::C0(_, _, _, h4579, _) => {
                        h4579
                    }
                }, match v0 {
                    Adt6::C0(_, _, _, _, h4580) => {
                        h4580
                    }
                }))
            }
        }
        Adt7::C1 => {
            Err::<Adt6, Adt45>(Adt45::C2)
        }
        Adt7::C2 => {
            Err::<Adt6, Adt45>(Adt45::C2)
        }
        Adt7::C3 => {
            Err::<Adt6, Adt45>(Adt45::C2)
        }
        Adt7::C4 => {
            Err::<Adt6, Adt45>(Adt45::C2)
        }
    }
}

pub fn f128(v0: Adt2, v1: Adt82) -> bool {
    let m4581 = v1;
    match m4581 {
        Adt82::C0(_) => {
            true
        }
        Adt82::C1(v3) => {
            let a4586 = {
                let m4584 = match v3 {
                    Adt83::C0(h4583, _, _) => {
                        h4583
                    }
                };
                match m4584 {
                    Adt12::C0(h4582, _, _) => {
                        h4582
                    }
                }
            };
            let a4587 = match v0 {
                Adt2::C0(h4585, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4585
                }
            };
            nat_eq(a4586, a4587)
        }
        Adt82::C2(_) => {
            true
        }
        Adt82::C3 => {
            true
        }
    }
}

pub fn f129(v0: Adt6, v1: Adt96) -> Adt97 {
    let m4588 = v1;
    match m4588 {
        Adt96::C0 => {
            let m4590 = match v0.clone() {
                Adt6::C0(h4589, _, _, _, _) => {
                    h4589
                }
            };
            match m4590 {
                Adt7::C0 => {
                    Adt97::C0(Adt98::C0, v0)
                }
                Adt7::C1 => {
                    Adt97::C1(Adt45::C2)
                }
                Adt7::C2 => {
                    Adt97::C1(Adt45::C2)
                }
                Adt7::C3 => {
                    Adt97::C1(Adt45::C2)
                }
                Adt7::C4 => {
                    Adt97::C1(Adt45::C2)
                }
            }
        }
        Adt96::C1 => {
            let m4592 = match v0.clone() {
                Adt6::C0(h4591, _, _, _, _) => {
                    h4591
                }
            };
            match m4592 {
                Adt7::C0 => {
                    Adt97::C1(Adt45::C0)
                }
                Adt7::C1 => {
                    if match v0.clone() {
                        Adt6::C0(_, h4593, _, _, _) => {
                            h4593
                        }
                    } {
                        Adt97::C1(Adt45::C1)
                    } else {
                        Adt97::C0(Adt98::C1, Adt6::C0(Adt7::C0, match v0.clone() {
                            Adt6::C0(_, h4594, _, _, _) => {
                                h4594
                            }
                        }, match v0.clone() {
                            Adt6::C0(_, _, h4595, _, _) => {
                                h4595
                            }
                        }, match v0.clone() {
                            Adt6::C0(_, _, _, h4596, _) => {
                                h4596
                            }
                        }, match v0 {
                            Adt6::C0(_, _, _, _, h4597) => {
                                h4597
                            }
                        }))
                    }
                }
                Adt7::C2 => {
                    Adt97::C1(Adt45::C0)
                }
                Adt7::C3 => {
                    Adt97::C1(Adt45::C0)
                }
                Adt7::C4 => {
                    Adt97::C1(Adt45::C0)
                }
            }
        }
        Adt96::C2 => {
            let m4599 = match v0.clone() {
                Adt6::C0(h4598, _, _, _, _) => {
                    h4598
                }
            };
            match m4599 {
                Adt7::C0 => {
                    Adt97::C1(Adt45::C0)
                }
                Adt7::C1 => {
                    if match v0.clone() {
                        Adt6::C0(_, h4600, _, _, _) => {
                            h4600
                        }
                    } {
                        Adt97::C1(Adt45::C1)
                    } else {
                        Adt97::C0(Adt98::C2, Adt6::C0(Adt7::C0, true, match v0.clone() {
                            Adt6::C0(_, _, h4601, _, _) => {
                                h4601
                            }
                        }, match v0.clone() {
                            Adt6::C0(_, _, _, h4602, _) => {
                                h4602
                            }
                        }, match v0 {
                            Adt6::C0(_, _, _, _, h4603) => {
                                h4603
                            }
                        }))
                    }
                }
                Adt7::C2 => {
                    Adt97::C1(Adt45::C0)
                }
                Adt7::C3 => {
                    Adt97::C1(Adt45::C0)
                }
                Adt7::C4 => {
                    Adt97::C1(Adt45::C0)
                }
            }
        }
        Adt96::C3 => {
            let m4605 = match v0.clone() {
                Adt6::C0(h4604, _, _, _, _) => {
                    h4604
                }
            };
            match m4605 {
                Adt7::C0 => {
                    Adt97::C0(Adt98::C3, Adt6::C0(Adt7::C3, match v0.clone() {
                        Adt6::C0(_, h4606, _, _, _) => {
                            h4606
                        }
                    }, match v0 {
                        Adt6::C0(_, _, h4607, _, _) => {
                            h4607
                        }
                    }, false, Adt8::C2))
                }
                Adt7::C1 => {
                    Adt97::C0(Adt98::C3, Adt6::C0(Adt7::C3, match v0.clone() {
                        Adt6::C0(_, h4608, _, _, _) => {
                            h4608
                        }
                    }, match v0 {
                        Adt6::C0(_, _, h4609, _, _) => {
                            h4609
                        }
                    }, false, Adt8::C2))
                }
                Adt7::C2 => {
                    Adt97::C0(Adt98::C4, v0)
                }
                Adt7::C3 => {
                    Adt97::C0(Adt98::C4, v0)
                }
                Adt7::C4 => {
                    Adt97::C0(Adt98::C4, v0)
                }
            }
        }
    }
}

pub fn f130(v0: Adt82) -> Adt96 {
    let m4610 = v0;
    match m4610 {
        Adt82::C0(_) => {
            Adt96::C1
        }
        Adt82::C1(_) => {
            Adt96::C1
        }
        Adt82::C2(_) => {
            Adt96::C1
        }
        Adt82::C3 => {
            Adt96::C2
        }
    }
}

pub fn f131(v0: Adt9, v1: Adt82) -> R<Result<Adt9, Adt99>> {
    if match v0.clone() {
        Adt9::C0(_, _, h4611, _) => {
            h4611
        }
    } {
        Ok(Err::<Adt9, Adt99>(Adt99::C0))
    } else {
        let m4612 = v1;
        match m4612 {
            Adt82::C0(v2) => {
                if match v0.clone() {
                    Adt9::C0(_, h4613, _, _) => {
                        h4613
                    }
                } {
                    Ok(Err::<Adt9, Adt99>(Adt99::C1))
                } else {
                    let a4615 = v2;
                    let a4616 = match v0.clone() {
                        Adt9::C0(h4614, _, _, _) => {
                            h4614
                        }
                    };
                    if nat_eq(a4615, a4616) {
                        Ok(Ok::<Adt9, Adt99>(Adt9::C0(match v0.clone() {
                            Adt9::C0(h4617, _, _, _) => {
                                h4617
                            }
                        }, true, match v0.clone() {
                            Adt9::C0(_, _, h4618, _) => {
                                h4618
                            }
                        }, match v0 {
                            Adt9::C0(_, _, _, h4619) => {
                                h4619
                            }
                        })))
                    } else {
                        Ok(Err::<Adt9, Adt99>(Adt99::C3))
                    }
                }
            }
            Adt82::C1(v3) => {
                if match v0.clone() {
                    Adt9::C0(_, h4620, _, _) => {
                        h4620
                    }
                } {
                    Ok(Ok::<Adt9, Adt99>(Adt9::C0(match v0.clone() {
                        Adt9::C0(h4621, _, _, _) => {
                            h4621
                        }
                    }, match v0.clone() {
                        Adt9::C0(_, h4622, _, _) => {
                            h4622
                        }
                    }, match v0.clone() {
                        Adt9::C0(_, _, h4623, _) => {
                            h4623
                        }
                    }, {
                        let a4626 = match v0 {
                            Adt9::C0(_, _, _, h4624) => {
                                h4624
                            }
                        };
                        let a4627 = match v3 {
                            Adt83::C0(_, _, h4625) => {
                                h4625
                            }
                        };
                        nat_add(a4626, a4627)?
                    })))
                } else {
                    Ok(Err::<Adt9, Adt99>(Adt99::C2))
                }
            }
            Adt82::C2(v4) => {
                if match v0.clone() {
                    Adt9::C0(_, h4628, _, _) => {
                        h4628
                    }
                } {
                    let a4630 = v4;
                    let a4631 = match v0.clone() {
                        Adt9::C0(h4629, _, _, _) => {
                            h4629
                        }
                    };
                    if nat_eq(a4630, a4631) {
                        Ok(Ok::<Adt9, Adt99>(Adt9::C0({
                            let a4633 = match v0.clone() {
                                Adt9::C0(h4632, _, _, _) => {
                                    h4632
                                }
                            };
                            let a4634 = 1u64;
                            nat_add(a4633, a4634)?
                        }, false, match v0.clone() {
                            Adt9::C0(_, _, h4635, _) => {
                                h4635
                            }
                        }, match v0 {
                            Adt9::C0(_, _, _, h4636) => {
                                h4636
                            }
                        })))
                    } else {
                        Ok(Err::<Adt9, Adt99>(Adt99::C3))
                    }
                } else {
                    Ok(Err::<Adt9, Adt99>(Adt99::C2))
                }
            }
            Adt82::C3 => {
                if match v0.clone() {
                    Adt9::C0(_, h4637, _, _) => {
                        h4637
                    }
                } {
                    Ok(Err::<Adt9, Adt99>(Adt99::C4))
                } else {
                    Ok(Ok::<Adt9, Adt99>(Adt9::C0(match v0.clone() {
                        Adt9::C0(h4638, _, _, _) => {
                            h4638
                        }
                    }, match v0.clone() {
                        Adt9::C0(_, h4639, _, _) => {
                            h4639
                        }
                    }, true, match v0 {
                        Adt9::C0(_, _, _, h4640) => {
                            h4640
                        }
                    })))
                }
            }
        }
    }
}

pub fn f132(v0: Adt2, v1: Adt53, v2: Adt23, v3: bool) -> R<Adt94> {
    if v3 {
        let m4642 = match v0.clone() {
            Adt2::C0(_, _, _, _, h4641, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4641
            }
        };
        match m4642 {
            None => {
                Ok(f146(v0, v2))
            }
            Some(v4) => {
                f147(v0, v1, f38(v4.clone()), f148(v4, v2))
            }
        }
    } else {
        Ok(f146(v0, v2))
    }
}

pub fn f133(v0: Adt2, v1: Adt53, v2: Adt42) -> Adt94 {
    if f77(v0.clone(), v1.clone()) {
        Adt94::C0(Adt2::C0(match v0.clone() {
            Adt2::C0(h4643, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4643
            }
        }, f149(match v0.clone() {
            Adt2::C0(_, h4644, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4644
            }
        }, match v1.clone() {
            Adt53::C0(_, h4645, _) => {
                h4645
            }
        }, match v1.clone() {
            Adt53::C0(_, _, h4646) => {
                h4646
            }
        }, Adt5::C5), f90(match v0.clone() {
            Adt2::C0(_, _, h4647, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4647
            }
        }, Adt8::C2), match v0.clone() {
            Adt2::C0(_, _, _, h4648, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4648
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, h4649, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4649
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, h4650, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4650
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, h4651, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4651
            }
        }, None::<Adt12>, false, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, h4652, _, _, _, _, _, _, _, _, _, _, _) => {
                h4652
            }
        }, Some(v2), match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h4653, _, _, _, _, _, _, _, _, _) => {
                h4653
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4654, _, _, _, _, _, _, _, _) => {
                h4654
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h4655, _, _, _, _, _, _, _) => {
                h4655
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4656, _, _, _, _, _, _) => {
                h4656
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4657, _, _, _, _, _) => {
                h4657
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4658, _, _, _, _) => {
                h4658
            }
        }, false, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4659, _, _) => {
                h4659
            }
        }, match v0.clone() {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4660, _) => {
                h4660
            }
        }, match v0 {
            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4661) => {
                h4661
            }
        }), List::cons(Adt81::C5(v1), List::<Adt81>::nil()))
    } else {
        Adt94::C0(v0, List::<Adt81>::nil())
    }
}

pub fn f134(v0: Adt6) -> Adt6 {
    Adt6::C0(match v0.clone() {
        Adt6::C0(h4662, _, _, _, _) => {
            h4662
        }
    }, match v0.clone() {
        Adt6::C0(_, h4663, _, _, _) => {
            h4663
        }
    }, match v0.clone() {
        Adt6::C0(_, _, h4664, _, _) => {
            h4664
        }
    }, match v0 {
        Adt6::C0(_, _, _, h4665, _) => {
            h4665
        }
    }, Adt8::C0)
}

pub fn f135(v0: Adt6, v1: Adt8) -> Result<Adt6, Adt45> {
    if f150(v0.clone()) {
        let m4666 = v1;
        match m4666 {
            Adt8::C0 => {
                Err::<Adt6, Adt45>(Adt45::C3)
            }
            Adt8::C1 => {
                Ok::<Adt6, Adt45>(Adt6::C0(match v0.clone() {
                    Adt6::C0(h4667, _, _, _, _) => {
                        h4667
                    }
                }, match v0.clone() {
                    Adt6::C0(_, h4668, _, _, _) => {
                        h4668
                    }
                }, match v0.clone() {
                    Adt6::C0(_, _, h4669, _, _) => {
                        h4669
                    }
                }, match v0 {
                    Adt6::C0(_, _, _, h4670, _) => {
                        h4670
                    }
                }, Adt8::C1))
            }
            Adt8::C2 => {
                Ok::<Adt6, Adt45>(Adt6::C0(match v0.clone() {
                    Adt6::C0(h4671, _, _, _, _) => {
                        h4671
                    }
                }, match v0.clone() {
                    Adt6::C0(_, h4672, _, _, _) => {
                        h4672
                    }
                }, match v0.clone() {
                    Adt6::C0(_, _, h4673, _, _) => {
                        h4673
                    }
                }, match v0 {
                    Adt6::C0(_, _, _, h4674, _) => {
                        h4674
                    }
                }, Adt8::C2))
            }
            Adt8::C3 => {
                Ok::<Adt6, Adt45>(Adt6::C0(match v0.clone() {
                    Adt6::C0(h4675, _, _, _, _) => {
                        h4675
                    }
                }, match v0.clone() {
                    Adt6::C0(_, h4676, _, _, _) => {
                        h4676
                    }
                }, match v0.clone() {
                    Adt6::C0(_, _, h4677, _, _) => {
                        h4677
                    }
                }, match v0 {
                    Adt6::C0(_, _, _, h4678, _) => {
                        h4678
                    }
                }, Adt8::C3))
            }
        }
    } else {
        Err::<Adt6, Adt45>(Adt45::C3)
    }
}

pub fn f136(v0: Adt6, v1: u64, v2: u64) -> R<Result<Adt6, Adt45>> {
    let m4680 = match v0.clone() {
        Adt6::C0(h4679, _, _, _, _) => {
            h4679
        }
    };
    match m4680 {
        Adt7::C0 => {
            let a4682 = match v0.clone() {
                Adt6::C0(_, _, h4681, _, _) => {
                    h4681
                }
            };
            let a4683 = v2;
            if if nat_le(a4682, a4683) {
                let a4687 = v1;
                let a4688 = {
                    let a4685 = v2;
                    let a4686 = match v0.clone() {
                        Adt6::C0(_, _, h4684, _, _) => {
                            h4684
                        }
                    };
                    nat_sub(a4685, a4686)
                };
                nat_le(a4687, a4688)
            } else {
                false
            } {
                Ok(Ok::<Adt6, Adt45>(Adt6::C0(match v0.clone() {
                    Adt6::C0(h4689, _, _, _, _) => {
                        h4689
                    }
                }, match v0.clone() {
                    Adt6::C0(_, h4690, _, _, _) => {
                        h4690
                    }
                }, {
                    let a4692 = match v0.clone() {
                        Adt6::C0(_, _, h4691, _, _) => {
                            h4691
                        }
                    };
                    let a4693 = v1;
                    nat_add(a4692, a4693)?
                }, match v0.clone() {
                    Adt6::C0(_, _, _, h4694, _) => {
                        h4694
                    }
                }, match v0 {
                    Adt6::C0(_, _, _, _, h4695) => {
                        h4695
                    }
                })))
            } else {
                Ok(Err::<Adt6, Adt45>(Adt45::C4))
            }
        }
        Adt7::C1 => {
            Ok(Err::<Adt6, Adt45>(Adt45::C2))
        }
        Adt7::C2 => {
            Ok(Err::<Adt6, Adt45>(Adt45::C2))
        }
        Adt7::C3 => {
            Ok(Err::<Adt6, Adt45>(Adt45::C2))
        }
        Adt7::C4 => {
            Ok(Err::<Adt6, Adt45>(Adt45::C2))
        }
    }
}

pub fn f137(v0: Adt10) -> Adt13 {
    let m4696 = v0;
    match m4696 {
        Adt10::C0(v1) => {
            match v1 {
                Adt11::C0(_, h4697) => {
                    h4697
                }
            }
        }
        Adt10::C1(v2) => {
            match v2 {
                Adt16::C0(_, h4698) => {
                    h4698
                }
            }
        }
        Adt10::C2(v3) => {
            match v3 {
                Adt16::C0(_, h4699) => {
                    h4699
                }
            }
        }
        Adt10::C3(v4) => {
            match v4 {
                Adt17::C0(_, _, _, h4700) => {
                    h4700
                }
            }
        }
        Adt10::C4(v5) => {
            match v5 {
                Adt18::C0(_, _, h4701) => {
                    h4701
                }
            }
        }
        Adt10::C5(v6) => {
            match v6 {
                Adt19::C0(_, h4702) => {
                    h4702
                }
            }
        }
        Adt10::C6(v7) => {
            match v7 {
                Adt20::C0(_, _, h4703) => {
                    h4703
                }
            }
        }
        Adt10::C7(v8) => {
            match v8 {
                Adt21::C0(_, _, _, h4704) => {
                    h4704
                }
            }
        }
        Adt10::C8(v9) => {
            match v9 {
                Adt22::C0(_, h4705) => {
                    h4705
                }
            }
        }
        Adt10::C9(v10) => {
            match v10 {
                Adt22::C0(_, h4706) => {
                    h4706
                }
            }
        }
    }
}

pub fn f138(v0: Adt2, v1: Adt51) -> Adt94 {
    let m4708 = match v1.clone() {
        Adt51::C0(_, h4707) => {
            h4707
        }
    };
    match m4708 {
        None => {
            Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h4709, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4709
                }
            }, match v0.clone() {
                Adt2::C0(_, h4710, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4710
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h4711, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4711
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h4712, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4712
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h4713, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4713
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h4714, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4714
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h4715, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4715
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h4716, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4716
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h4717, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4717
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h4718, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4718
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, h4719, _, _, _, _, _, _, _, _, _, _) => {
                    h4719
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h4720, _, _, _, _, _, _, _, _, _) => {
                    h4720
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4721, _, _, _, _, _, _, _, _) => {
                    h4721
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h4722, _, _, _, _, _, _, _) => {
                    h4722
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4723, _, _, _, _, _, _) => {
                    h4723
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4724, _, _, _, _, _) => {
                    h4724
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4725, _, _, _, _) => {
                    h4725
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4726, _, _, _) => {
                    h4726
                }
            }, v1, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4727, _) => {
                    h4727
                }
            }, match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4728) => {
                    h4728
                }
            }), List::<Adt81>::nil())
        }
        Some(v2) => {
            Adt94::C0(Adt2::C0(match v0.clone() {
                Adt2::C0(h4729, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4729
                }
            }, match v0.clone() {
                Adt2::C0(_, h4730, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4730
                }
            }, match v0.clone() {
                Adt2::C0(_, _, h4731, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4731
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, h4732, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4732
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, h4733, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4733
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, h4734, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4734
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, h4735, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4735
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h4736, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4736
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, h4737, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4737
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, h4738, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4738
                }
            }, Some(Adt42::C16(v2)), match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h4739, _, _, _, _, _, _, _, _, _) => {
                    h4739
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4740, _, _, _, _, _, _, _, _) => {
                    h4740
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h4741, _, _, _, _, _, _, _) => {
                    h4741
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4742, _, _, _, _, _, _) => {
                    h4742
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4743, _, _, _, _, _) => {
                    h4743
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4744, _, _, _, _) => {
                    h4744
                }
            }, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4745, _, _, _) => {
                    h4745
                }
            }, v1, match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4746, _) => {
                    h4746
                }
            }, match v0 {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4747) => {
                    h4747
                }
            }), List::<Adt81>::nil())
        }
    }
}

pub fn f139(v0: Adt15, v1: Adt51, v2: Adt68) -> R<Adt51> {
    let m4748 = v2;
    match m4748 {
        Adt68::C0(v3, v4) => {
            let m4750 = f151(v0, match v1.clone() {
                Adt51::C0(h4749, _) => {
                    h4749
                }
            }, v3, v4)?;
            match m4750 {
                Ok(v6) => {
                    Ok(Adt51::C0(v6, None::<Adt46>))
                }
                Err(v5) => {
                    Ok(Adt51::C0(match v1 {
                        Adt51::C0(h4751, _) => {
                            h4751
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt68::C1(v7, v8, v9) => {
            let m4753 = f152(match v1.clone() {
                Adt51::C0(h4752, _) => {
                    h4752
                }
            }, v7, v8, v9)?;
            match m4753 {
                Ok(v11) => {
                    Ok(Adt51::C0(v11, None::<Adt46>))
                }
                Err(v10) => {
                    Ok(Adt51::C0(match v1 {
                        Adt51::C0(h4754, _) => {
                            h4754
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt68::C2(v12, v13, v14) => {
            let m4756 = f152(match v1.clone() {
                Adt51::C0(h4755, _) => {
                    h4755
                }
            }, v12, v13, v14)?;
            match m4756 {
                Ok(v16) => {
                    Ok(Adt51::C0(v16, None::<Adt46>))
                }
                Err(v15) => {
                    Ok(Adt51::C0(match v1 {
                        Adt51::C0(h4757, _) => {
                            h4757
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt68::C3(v17, v18) => {
            let m4759 = f153(match v1.clone() {
                Adt51::C0(h4758, _) => {
                    h4758
                }
            }, v17, v18)?;
            match m4759 {
                Ok(v20) => {
                    Ok(Adt51::C0(v20, None::<Adt46>))
                }
                Err(v19) => {
                    Ok(Adt51::C0(match v1 {
                        Adt51::C0(h4760, _) => {
                            h4760
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt68::C4(v21, v22) => {
            let m4762 = f153(match v1.clone() {
                Adt51::C0(h4761, _) => {
                    h4761
                }
            }, v21, v22)?;
            match m4762 {
                Ok(v24) => {
                    Ok(Adt51::C0(v24, None::<Adt46>))
                }
                Err(v23) => {
                    Ok(Adt51::C0(match v1 {
                        Adt51::C0(h4763, _) => {
                            h4763
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f140(v0: Adt53, v1: Adt53) -> bool {
    let a4766 = match v0.clone() {
        Adt53::C0(h4764, _, _) => {
            h4764
        }
    };
    let a4767 = match v1.clone() {
        Adt53::C0(h4765, _, _) => {
            h4765
        }
    };
    if nat_eq(a4766, a4767) {
        let a4770 = match v0.clone() {
            Adt53::C0(_, h4768, _) => {
                h4768
            }
        };
        let a4771 = match v1.clone() {
            Adt53::C0(_, h4769, _) => {
                h4769
            }
        };
        if nat_eq(a4770, a4771) {
            let a4774 = match v0 {
                Adt53::C0(_, _, h4772) => {
                    h4772
                }
            };
            let a4775 = match v1 {
                Adt53::C0(_, _, h4773) => {
                    h4773
                }
            };
            nat_eq(a4774, a4775)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f141(v0: u8) -> Option<u64> {
    let a4776 = v0;
    let a4777 = 48u8;
    if equal(a4776, a4777) {
        Some(0u64)
    } else {
        let a4778 = v0;
        let a4779 = 49u8;
        if equal(a4778, a4779) {
            Some(1u64)
        } else {
            let a4780 = v0;
            let a4781 = 50u8;
            if equal(a4780, a4781) {
                Some(2u64)
            } else {
                let a4782 = v0;
                let a4783 = 51u8;
                if equal(a4782, a4783) {
                    Some(3u64)
                } else {
                    let a4784 = v0;
                    let a4785 = 52u8;
                    if equal(a4784, a4785) {
                        Some(4u64)
                    } else {
                        let a4786 = v0;
                        let a4787 = 53u8;
                        if equal(a4786, a4787) {
                            Some(5u64)
                        } else {
                            let a4788 = v0;
                            let a4789 = 54u8;
                            if equal(a4788, a4789) {
                                Some(6u64)
                            } else {
                                let a4790 = v0;
                                let a4791 = 55u8;
                                if equal(a4790, a4791) {
                                    Some(7u64)
                                } else {
                                    let a4792 = v0;
                                    let a4793 = 56u8;
                                    if equal(a4792, a4793) {
                                        Some(8u64)
                                    } else {
                                        let a4794 = v0;
                                        let a4795 = 57u8;
                                        if equal(a4794, a4795) {
                                            Some(9u64)
                                        } else {
                                            None::<u64>
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f142(v0: Adt44) -> Str {
    let m4796 = v0;
    match m4796 {
        Adt44::C0 => {
            Str::lit("An operation is already running.")
        }
        Adt44::C1 => {
            Str::lit("This session is closed.")
        }
        Adt44::C2 => {
            Str::lit("This view is detached.")
        }
        Adt44::C3 => {
            Str::lit("Start an operation first.")
        }
        Adt44::C4 => {
            Str::lit("Choose a checkpoint and its original input.")
        }
        Adt44::C5 => {
            Str::lit("No checked staged result is ready to download.")
        }
        Adt44::C6 => {
            Str::lit("The download is awaiting its destination receipt.")
        }
        Adt44::C7 => {
            Str::lit("Reconcile the unknown publication outcome with the destination.")
        }
        Adt44::C8 => {
            Str::lit("Input objects or boundaries arrived out of order.")
        }
        Adt44::C9 => {
            Str::lit("Input has already ended.")
        }
        Adt44::C10 => {
            Str::lit("The operation has not requested more input.")
        }
        Adt44::C11 => {
            Str::lit("The resource belongs to another instance.")
        }
        Adt44::C12 => {
            Str::lit("Add a positive amount of effort.")
        }
        Adt44::C13 => {
            Str::lit("No publication is awaiting a receipt.")
        }
        Adt44::C14 => {
            Str::lit("Choose input objects.")
        }
        Adt44::C15 => {
            Str::lit("Choose an archive.")
        }
        Adt44::C16 => {
            Str::lit("Choose the second archive.")
        }
        Adt44::C17 => {
            Str::lit("Enter a nonnegative whole number. Clear only an optional quota to request no additional limit.")
        }
    }
}

pub fn f143(v0: u64) -> R<Str> {
    Ok(f154({
        let a4797 = v0;
        let a4798 = 1u64;
        nat_add(a4797, a4798)?
    }, v0))
}

pub fn f144() -> Adt26 {
    Adt26::C0(0u64, 0u64, 0u64, 0u64)
}

pub fn f145(v0: Adt54) -> List<Adt81> {
    f114(f85(match v0.clone() {
        Adt54::C0(_, h4799, _, _, _, _, _, _) => {
            h4799
        }
    }), f114(f85(match v0.clone() {
        Adt54::C0(_, _, h4800, _, _, _, _, _) => {
            h4800
        }
    }), f114(f85(match v0.clone() {
        Adt54::C0(_, _, _, h4801, _, _, _, _) => {
            h4801
        }
    }), f114(f85(match v0.clone() {
        Adt54::C0(_, _, _, _, h4802, _, _, _) => {
            h4802
        }
    }), f114(f85(match v0.clone() {
        Adt54::C0(_, _, _, _, _, h4803, _, _) => {
            h4803
        }
    }), f114(f85(match v0 {
        Adt54::C0(_, _, _, _, _, _, h4804, _) => {
            h4804
        }
    }), List::<Adt81>::nil()))))))
}

pub fn f146(v0: Adt2, v1: Adt23) -> Adt94 {
    Adt94::C0(v0.clone(), {
        let m4811 = {
            let m4807 = match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, h4806, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h4806
                }
            };
            match m4807 {
                None => {
                    Adt94::C0(v0, f85(match v1 {
                        Adt23::C0(_, _, _, _, _, _, _, _, h4808, _) => {
                            h4808
                        }
                    }))
                }
                Some(v2) => {
                    let m4810 = match v1 {
                        Adt23::C0(_, _, _, _, _, _, _, _, h4809, _) => {
                            h4809
                        }
                    };
                    match m4810 {
                        None => {
                            Adt94::C0(v0, List::<Adt81>::nil())
                        }
                        Some(v3) => {
                            if f34(v2, v3.clone()) {
                                Adt94::C0(v0, List::<Adt81>::nil())
                            } else {
                                Adt94::C0(v0, List::cons(Adt81::C6(v3), List::<Adt81>::nil()))
                            }
                        }
                    }
                }
            }
        };
        match m4811 {
            Adt94::C0(_, h4805) => {
                h4805
            }
        }
    })
}

pub fn f147(v0: Adt2, v1: Adt53, v2: Adt55, v3: Adt23) -> R<Adt94> {
    if f155(v0.clone(), v2.clone(), v3.clone())? {
        let m4812 = f156(v2.clone(), v3.clone());
        match m4812 {
            Adt100::C0 => {
                let m4814 = f157(match v0.clone() {
                    Adt2::C0(_, _, h4813, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4813
                    }
                });
                match m4814 {
                    Ok(v5) => {
                        Ok(Adt94::C0(Adt2::C0(match v0.clone() {
                            Adt2::C0(h4815, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4815
                            }
                        }, f149(match v0.clone() {
                            Adt2::C0(_, h4816, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4816
                            }
                        }, match v1.clone() {
                            Adt53::C0(_, h4817, _) => {
                                h4817
                            }
                        }, match v1 {
                            Adt53::C0(_, _, h4818) => {
                                h4818
                            }
                        }, {
                            let m4819 = v2;
                            match m4819 {
                                Adt55::C0 => {
                                    Adt5::C2
                                }
                                Adt55::C1 => {
                                    Adt5::C3
                                }
                                Adt55::C2 => {
                                    Adt5::C1
                                }
                                Adt55::C3 => {
                                    Adt5::C1
                                }
                                Adt55::C4 => {
                                    Adt5::C2
                                }
                                Adt55::C5 => {
                                    Adt5::C2
                                }
                                Adt55::C6 => {
                                    Adt5::C1
                                }
                                Adt55::C7 => {
                                    Adt5::C1
                                }
                                Adt55::C8 => {
                                    Adt5::C1
                                }
                                Adt55::C9 => {
                                    Adt5::C1
                                }
                            }
                        }), v5, match v0.clone() {
                            Adt2::C0(_, _, _, h4820, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4820
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, h4821, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4821
                            }
                        }, Some(v3.clone()), match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, h4822, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4822
                            }
                        }, match v3.clone() {
                            Adt23::C0(_, _, _, _, _, _, _, _, h4823, _) => {
                                h4823
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, h4824, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4824
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, h4825, _, _, _, _, _, _, _, _, _, _, _) => {
                                h4825
                            }
                        }, None::<Adt42>, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, h4826, _, _, _, _, _, _, _, _, _) => {
                                h4826
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4827, _, _, _, _, _, _, _, _) => {
                                h4827
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h4828, _, _, _, _, _, _, _) => {
                                h4828
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h4829, _, _, _, _, _, _) => {
                                h4829
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4830, _, _, _, _, _) => {
                                h4830
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4831, _, _, _, _) => {
                                h4831
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4832, _, _, _) => {
                                h4832
                            }
                        }, match v0.clone() {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4833, _, _) => {
                                h4833
                            }
                        }, Some(match v3 {
                            Adt23::C0(h4834, _, _, _, _, _, _, _, _, _) => {
                                h4834
                            }
                        }), match v0 {
                            Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4835) => {
                                h4835
                            }
                        }), List::<Adt81>::nil()))
                    }
                    Err(v4) => {
                        Ok(f133(v0, v1, Adt42::C11(v4)))
                    }
                }
            }
            Adt100::C1 => {
                Ok(f133(v0, v1, Adt42::C12))
            }
            Adt100::C2 => {
                Ok(f133(v0, v1, Adt42::C13))
            }
            Adt100::C3 => {
                Ok(f133(v0, v1, Adt42::C7))
            }
            Adt100::C4 => {
                Ok(f133(v0, v1, Adt42::C5))
            }
        }
    } else {
        Ok(f133(v0, v1, Adt42::C15(Str::lit("Staged output ownership or byte count does not match the operation."))))
    }
}

pub fn f148(v0: Adt10, v1: Adt23) -> Adt23 {
    Adt23::C0(match v1.clone() {
        Adt23::C0(h4836, _, _, _, _, _, _, _, _, _) => {
            h4836
        }
    }, match v1.clone() {
        Adt23::C0(_, h4837, _, _, _, _, _, _, _, _) => {
            h4837
        }
    }, match v1.clone() {
        Adt23::C0(_, _, h4838, _, _, _, _, _, _, _) => {
            h4838
        }
    }, f158(v0), match v1.clone() {
        Adt23::C0(_, _, _, _, h4839, _, _, _, _, _) => {
            h4839
        }
    }, match v1.clone() {
        Adt23::C0(_, _, _, _, _, h4840, _, _, _, _) => {
            h4840
        }
    }, match v1.clone() {
        Adt23::C0(_, _, _, _, _, _, h4841, _, _, _) => {
            h4841
        }
    }, match v1.clone() {
        Adt23::C0(_, _, _, _, _, _, _, h4842, _, _) => {
            h4842
        }
    }, match v1.clone() {
        Adt23::C0(_, _, _, _, _, _, _, _, h4843, _) => {
            h4843
        }
    }, match v1 {
        Adt23::C0(_, _, _, _, _, _, _, _, _, h4844) => {
            h4844
        }
    })
}

pub fn f149(v0: Adt3, v1: u64, v2: u64, v3: Adt5) -> Adt3 {
    if f125(v0.clone(), v1, v2) {
        Adt3::C0(match v0.clone() {
            Adt3::C0(h4845, _, _, _, _, _) => {
                h4845
            }
        }, match v0 {
            Adt3::C0(_, h4846, _, _, _, _) => {
                h4846
            }
        }, false, true, {
            let m4847 = v3.clone();
            match m4847 {
                Adt5::C0 => {
                    Adt4::C6
                }
                Adt5::C1 => {
                    Adt4::C4
                }
                Adt5::C2 => {
                    Adt4::C4
                }
                Adt5::C3 => {
                    Adt4::C4
                }
                Adt5::C4 => {
                    Adt4::C4
                }
                Adt5::C5 => {
                    Adt4::C6
                }
            }
        }, v3)
    } else {
        v0
    }
}

pub fn f150(v0: Adt6) -> bool {
    let m4849 = match v0.clone() {
        Adt6::C0(h4848, _, _, _, _) => {
            h4848
        }
    };
    match m4849 {
        Adt7::C0 => {
            false
        }
        Adt7::C1 => {
            false
        }
        Adt7::C2 => {
            if match v0.clone() {
                Adt6::C0(_, _, _, h4850, _) => {
                    h4850
                }
            } {
                let m4852 = match v0 {
                    Adt6::C0(_, _, _, _, h4851) => {
                        h4851
                    }
                };
                match m4852 {
                    Adt8::C0 => {
                        true
                    }
                    Adt8::C1 => {
                        false
                    }
                    Adt8::C2 => {
                        false
                    }
                    Adt8::C3 => {
                        false
                    }
                }
            } else {
                false
            }
        }
        Adt7::C3 => {
            false
        }
        Adt7::C4 => {
            false
        }
    }
}

pub fn f151(v0: Adt15, v1: Adt25, v2: Adt47, v3: u64) -> R<Result<Adt25, Adt46>> {
    if f159(match v0.clone() {
        Adt15::C0(h4853, _, _, _, _) => {
            h4853
        }
    }, f160(v1.clone())?, v3)? {
        if f159(f161(v0.clone(), v2.clone()), {
            let a4856 = f162(match v1.clone() {
                Adt25::C0(h4854, _, _, _) => {
                    h4854
                }
            }, v2.clone());
            let a4857 = f162(match v1.clone() {
                Adt25::C0(_, h4855, _, _) => {
                    h4855
                }
            }, v2.clone());
            nat_add(a4856, a4857)?
        }, v3)? {
            Ok(Ok::<Adt25, Adt46>(Adt25::C0(match v1.clone() {
                Adt25::C0(h4858, _, _, _) => {
                    h4858
                }
            }, f163(match v1.clone() {
                Adt25::C0(_, h4859, _, _) => {
                    h4859
                }
            }, v2.clone(), {
                let a4861 = f162(match v1.clone() {
                    Adt25::C0(_, h4860, _, _) => {
                        h4860
                    }
                }, v2.clone());
                let a4862 = v3;
                nat_add(a4861, a4862)?
            }), f164(match v1.clone() {
                Adt25::C0(_, _, h4863, _) => {
                    h4863
                }
            }, f98(match v1.clone() {
                Adt25::C0(h4864, _, _, _) => {
                    h4864
                }
            })?), f164(match v1.clone() {
                Adt25::C0(_, _, _, h4865) => {
                    h4865
                }
            }, {
                let a4871 = f98(match v1.clone() {
                    Adt25::C0(h4866, _, _, _) => {
                        h4866
                    }
                })?;
                let a4872 = f98(f163(match v1.clone() {
                    Adt25::C0(_, h4867, _, _) => {
                        h4867
                    }
                }, v2.clone(), {
                    let a4869 = f162(match v1 {
                        Adt25::C0(_, h4868, _, _) => {
                            h4868
                        }
                    }, v2);
                    let a4870 = v3;
                    nat_add(a4869, a4870)?
                }))?;
                nat_add(a4871, a4872)?
            }))))
        } else {
            Ok(Err::<Adt25, Adt46>(Adt46::C1(v2.clone(), {
                let a4875 = f162(match v1.clone() {
                    Adt25::C0(h4873, _, _, _) => {
                        h4873
                    }
                }, v2.clone());
                let a4876 = f162(match v1 {
                    Adt25::C0(_, h4874, _, _) => {
                        h4874
                    }
                }, v2.clone());
                nat_add(a4875, a4876)?
            }, v3, {
                let m4877 = f161(v0, v2);
                match m4877 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt25, Adt46>(Adt46::C0(f160(v1)?, v3, {
            let m4879 = match v0 {
                Adt15::C0(h4878, _, _, _, _) => {
                    h4878
                }
            };
            match m4879 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f152(v0: Adt25, v1: Adt47, v2: u64, v3: u64) -> R<Result<Adt25, Adt46>> {
    let a4883 = {
        let a4881 = f162(match v0.clone() {
            Adt25::C0(_, h4880, _, _) => {
                h4880
            }
        }, v1.clone());
        let a4882 = v2;
        nat_lt(a4881, a4882)
    };
    if if bool_not(a4883) {
        let a4886 = {
            let a4884 = v2;
            let a4885 = v3;
            nat_lt(a4884, a4885)
        };
        bool_not(a4886)
    } else {
        false
    } {
        Ok(Ok::<Adt25, Adt46>(Adt25::C0(f163(match v0.clone() {
            Adt25::C0(h4887, _, _, _) => {
                h4887
            }
        }, v1.clone(), {
            let a4889 = f162(match v0.clone() {
                Adt25::C0(h4888, _, _, _) => {
                    h4888
                }
            }, v1.clone());
            let a4890 = v3;
            nat_add(a4889, a4890)?
        }), f163(match v0.clone() {
            Adt25::C0(_, h4891, _, _) => {
                h4891
            }
        }, v1.clone(), {
            let a4893 = f162(match v0.clone() {
                Adt25::C0(_, h4892, _, _) => {
                    h4892
                }
            }, v1.clone());
            let a4894 = v2;
            nat_sub(a4893, a4894)
        }), f164(match v0.clone() {
            Adt25::C0(_, _, h4895, _) => {
                h4895
            }
        }, f98(f163(match v0.clone() {
            Adt25::C0(h4896, _, _, _) => {
                h4896
            }
        }, v1.clone(), {
            let a4898 = f162(match v0.clone() {
                Adt25::C0(h4897, _, _, _) => {
                    h4897
                }
            }, v1.clone());
            let a4899 = v3;
            nat_add(a4898, a4899)?
        }))?), f164(match v0.clone() {
            Adt25::C0(_, _, _, h4900) => {
                h4900
            }
        }, {
            let a4909 = f98(f163(match v0.clone() {
                Adt25::C0(h4901, _, _, _) => {
                    h4901
                }
            }, v1.clone(), {
                let a4903 = f162(match v0.clone() {
                    Adt25::C0(h4902, _, _, _) => {
                        h4902
                    }
                }, v1.clone());
                let a4904 = v3;
                nat_add(a4903, a4904)?
            }))?;
            let a4910 = f98(f163(match v0.clone() {
                Adt25::C0(_, h4905, _, _) => {
                    h4905
                }
            }, v1.clone(), {
                let a4907 = f162(match v0 {
                    Adt25::C0(_, h4906, _, _) => {
                        h4906
                    }
                }, v1);
                let a4908 = v2;
                nat_sub(a4907, a4908)
            }))?;
            nat_add(a4909, a4910)?
        }))))
    } else {
        Ok(Err::<Adt25, Adt46>(Adt46::C2(v1, v2, v3)))
    }
}

pub fn f153(v0: Adt25, v1: Adt47, v2: u64) -> R<Result<Adt25, Adt46>> {
    let a4914 = {
        let a4912 = f162(match v0.clone() {
            Adt25::C0(h4911, _, _, _) => {
                h4911
            }
        }, v1.clone());
        let a4913 = v2;
        nat_lt(a4912, a4913)
    };
    if bool_not(a4914) {
        Ok(Ok::<Adt25, Adt46>(Adt25::C0(f163(match v0.clone() {
            Adt25::C0(h4915, _, _, _) => {
                h4915
            }
        }, v1.clone(), {
            let a4917 = f162(match v0.clone() {
                Adt25::C0(h4916, _, _, _) => {
                    h4916
                }
            }, v1.clone());
            let a4918 = v2;
            nat_sub(a4917, a4918)
        }), match v0.clone() {
            Adt25::C0(_, h4919, _, _) => {
                h4919
            }
        }, f164(match v0.clone() {
            Adt25::C0(_, _, h4920, _) => {
                h4920
            }
        }, f98(f163(match v0.clone() {
            Adt25::C0(h4921, _, _, _) => {
                h4921
            }
        }, v1.clone(), {
            let a4923 = f162(match v0.clone() {
                Adt25::C0(h4922, _, _, _) => {
                    h4922
                }
            }, v1.clone());
            let a4924 = v2;
            nat_sub(a4923, a4924)
        }))?), f164(match v0.clone() {
            Adt25::C0(_, _, _, h4925) => {
                h4925
            }
        }, {
            let a4931 = f98(f163(match v0.clone() {
                Adt25::C0(h4926, _, _, _) => {
                    h4926
                }
            }, v1.clone(), {
                let a4928 = f162(match v0.clone() {
                    Adt25::C0(h4927, _, _, _) => {
                        h4927
                    }
                }, v1);
                let a4929 = v2;
                nat_sub(a4928, a4929)
            }))?;
            let a4932 = f98(match v0 {
                Adt25::C0(_, h4930, _, _) => {
                    h4930
                }
            })?;
            nat_add(a4931, a4932)?
        }))))
    } else {
        Ok(Err::<Adt25, Adt46>(Adt46::C3(v1.clone(), f162(match v0 {
            Adt25::C0(h4933, _, _, _) => {
                h4933
            }
        }, v1), v2)))
    }
}

pub fn f154(v0: u64, v1: u64) -> Str {
    let m4934 = v0;
    if m4934 == 0 {
        Str::lit("")
    } else {
        let v2 = m4934 - 1;
        let a4935 = v1;
        let a4936 = 10u64;
        if nat_lt(a4935, a4936) {
            f165(v1)
        } else {
            let a4943 = List::cons(f154(v2, {
                let a4937 = v1;
                let a4938 = 10u64;
                let a4939 = 0u64;
                nat_quot(a4937, a4938, a4939)
            }), List::cons(f165({
                let a4940 = v1;
                let a4941 = 10u64;
                let a4942 = 0u64;
                nat_rem(a4940, a4941, a4942)
            }), List::<Str>::nil()));
            let a4944 = Str::lit("");
            join(a4943, a4944)
        }
    }
}

pub fn f155(v0: Adt2, v1: Adt55, v2: Adt23) -> R<bool> {
    let a4951 = {
        let m4947 = match v2.clone() {
            Adt23::C0(h4946, _, _, _, _, _, _, _, _, _) => {
                h4946
            }
        };
        match m4947 {
            Adt24::C0(_, _, _, _, _, _, _, _, _, _, _, h4945, _, _) => {
                h4945
            }
        }
    };
    let a4952 = {
        let m4950 = match v0.clone() {
            Adt2::C0(_, _, h4949, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h4949
            }
        };
        match m4950 {
            Adt6::C0(_, _, h4948, _, _) => {
                h4948
            }
        }
    };
    if if nat_eq(a4951, a4952) {
        let m4954 = match v2.clone() {
            Adt23::C0(_, _, _, _, _, _, _, _, h4953, _) => {
                h4953
            }
        };
        match m4954 {
            None => {
                let m4955 = v1;
                match m4955 {
                    Adt55::C0 => {
                        false
                    }
                    Adt55::C1 => {
                        false
                    }
                    Adt55::C2 => {
                        true
                    }
                    Adt55::C3 => {
                        true
                    }
                    Adt55::C4 => {
                        false
                    }
                    Adt55::C5 => {
                        false
                    }
                    Adt55::C6 => {
                        true
                    }
                    Adt55::C7 => {
                        true
                    }
                    Adt55::C8 => {
                        true
                    }
                    Adt55::C9 => {
                        true
                    }
                }
            }
            Some(v3) => {
                let a4958 = match v3 {
                    Adt12::C0(h4956, _, _) => {
                        h4956
                    }
                };
                let a4959 = match v0.clone() {
                    Adt2::C0(h4957, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h4957
                    }
                };
                if nat_eq(a4958, a4959) {
                    let m4960 = v1;
                    match m4960 {
                        Adt55::C0 => {
                            true
                        }
                        Adt55::C1 => {
                            true
                        }
                        Adt55::C2 => {
                            false
                        }
                        Adt55::C3 => {
                            false
                        }
                        Adt55::C4 => {
                            true
                        }
                        Adt55::C5 => {
                            true
                        }
                        Adt55::C6 => {
                            false
                        }
                        Adt55::C7 => {
                            false
                        }
                        Adt55::C8 => {
                            false
                        }
                        Adt55::C9 => {
                            false
                        }
                    }
                } else {
                    false
                }
            }
        }
    } else {
        false
    } {
        if f166({
            let m4963 = match v2 {
                Adt23::C0(h4962, _, _, _, _, _, _, _, _, _) => {
                    h4962
                }
            };
            match m4963 {
                Adt24::C0(_, _, _, _, _, _, _, _, _, _, _, _, h4961, _) => {
                    h4961
                }
            }
        }, {
            let m4966 = match v0.clone() {
                Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4965, _, _) => {
                    h4965
                }
            };
            match m4966 {
                Adt51::C0(h4964, _) => {
                    h4964
                }
            }
        }) {
            let a4970 = f35({
                let m4969 = match v0.clone() {
                    Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4968, _, _) => {
                        h4968
                    }
                };
                match m4969 {
                    Adt51::C0(h4967, _) => {
                        h4967
                    }
                }
            })?;
            let a4971 = 0u64;
            if nat_eq(a4970, a4971) {
                let m4975 = {
                    let m4974 = match v0 {
                        Adt2::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h4973, _, _) => {
                            h4973
                        }
                    };
                    match m4974 {
                        Adt51::C0(_, h4972) => {
                            h4972
                        }
                    }
                };
                match m4975 {
                    None => {
                        Ok(true)
                    }
                    Some(_) => {
                        Ok(false)
                    }
                }
            } else {
                Ok(false)
            }
        } else {
            Ok(false)
        }
    } else {
        Ok(false)
    }
}

pub fn f156(v0: Adt55, v1: Adt23) -> Adt100 {
    let m4976 = v0;
    match m4976 {
        Adt55::C0 => {
            let m4979 = match v1.clone() {
                Adt23::C0(_, h4978, _, _, _, _, _, _, _, _) => {
                    h4978
                }
            };
            if if match m4979 {
                Adt29::C0(h4977, _, _, _, _) => {
                    h4977
                }
            } {
                let m4982 = match v1.clone() {
                    Adt23::C0(_, h4981, _, _, _, _, _, _, _, _) => {
                        h4981
                    }
                };
                if match m4982 {
                    Adt29::C0(_, h4980, _, _, _) => {
                        h4980
                    }
                } {
                    let m4985 = match v1.clone() {
                        Adt23::C0(_, h4984, _, _, _, _, _, _, _, _) => {
                            h4984
                        }
                    };
                    if match m4985 {
                        Adt29::C0(_, _, h4983, _, _) => {
                            h4983
                        }
                    } {
                        if match v1.clone() {
                            Adt23::C0(_, _, h4986, _, _, _, _, _, _, _) => {
                                h4986
                            }
                        } {
                            if match v1.clone() {
                                Adt23::C0(_, _, _, h4987, _, _, _, _, _, _) => {
                                    h4987
                                }
                            } {
                                let m4990 = match v1.clone() {
                                    Adt23::C0(_, h4989, _, _, _, _, _, _, _, _) => {
                                        h4989
                                    }
                                };
                                match m4990 {
                                    Adt29::C0(_, _, _, h4988, _) => {
                                        h4988
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f167(match v1.clone() {
                    Adt23::C0(_, _, _, _, h4991, _, _, _, _, _) => {
                        h4991
                    }
                }, false, f107(match v1 {
                    Adt23::C0(_, _, _, _, _, h4992, _, _, _, _) => {
                        h4992
                    }
                }))
            } else {
                Adt100::C2
            }
        }
        Adt55::C1 => {
            f168({
                let m4995 = match v1.clone() {
                    Adt23::C0(_, h4994, _, _, _, _, _, _, _, _) => {
                        h4994
                    }
                };
                match m4995 {
                    Adt29::C0(h4993, _, _, _, _) => {
                        h4993
                    }
                }
            }, {
                let m4998 = match v1.clone() {
                    Adt23::C0(_, h4997, _, _, _, _, _, _, _, _) => {
                        h4997
                    }
                };
                match m4998 {
                    Adt29::C0(_, h4996, _, _, _) => {
                        h4996
                    }
                }
            }, {
                let m5001 = match v1.clone() {
                    Adt23::C0(_, h5000, _, _, _, _, _, _, _, _) => {
                        h5000
                    }
                };
                match m5001 {
                    Adt29::C0(_, _, h4999, _, _) => {
                        h4999
                    }
                }
            }, match v1 {
                Adt23::C0(_, _, h5002, _, _, _, _, _, _, _) => {
                    h5002
                }
            }, false)
        }
        Adt55::C2 => {
            let m5005 = match v1 {
                Adt23::C0(_, h5004, _, _, _, _, _, _, _, _) => {
                    h5004
                }
            };
            if match m5005 {
                Adt29::C0(h5003, _, _, _, _) => {
                    h5003
                }
            } {
                Adt100::C0
            } else {
                Adt100::C2
            }
        }
        Adt55::C3 => {
            if match v1.clone() {
                Adt23::C0(_, _, _, h5006, _, _, _, _, _, _) => {
                    h5006
                }
            } {
                let m5009 = match v1.clone() {
                    Adt23::C0(_, h5008, _, _, _, _, _, _, _, _) => {
                        h5008
                    }
                };
                if if match m5009 {
                    Adt29::C0(h5007, _, _, _, _) => {
                        h5007
                    }
                } {
                    let m5012 = match v1.clone() {
                        Adt23::C0(_, h5011, _, _, _, _, _, _, _, _) => {
                            h5011
                        }
                    };
                    if match m5012 {
                        Adt29::C0(_, h5010, _, _, _) => {
                            h5010
                        }
                    } {
                        let m5015 = match v1.clone() {
                            Adt23::C0(_, h5014, _, _, _, _, _, _, _, _) => {
                                h5014
                            }
                        };
                        if match m5015 {
                            Adt29::C0(_, _, h5013, _, _) => {
                                h5013
                            }
                        } {
                            let m5018 = match v1.clone() {
                                Adt23::C0(_, h5017, _, _, _, _, _, _, _, _) => {
                                    h5017
                                }
                            };
                            if match m5018 {
                                Adt29::C0(_, _, _, h5016, _) => {
                                    h5016
                                }
                            } {
                                match v1.clone() {
                                    Adt23::C0(_, _, h5019, _, _, _, _, _, _, _) => {
                                        h5019
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                } {
                    f167(match v1.clone() {
                        Adt23::C0(_, _, _, _, h5020, _, _, _, _, _) => {
                            h5020
                        }
                    }, false, f107(match v1 {
                        Adt23::C0(_, _, _, _, _, h5021, _, _, _, _) => {
                            h5021
                        }
                    }))
                } else {
                    Adt100::C2
                }
            } else {
                f168({
                    let m5024 = match v1.clone() {
                        Adt23::C0(_, h5023, _, _, _, _, _, _, _, _) => {
                            h5023
                        }
                    };
                    match m5024 {
                        Adt29::C0(h5022, _, _, _, _) => {
                            h5022
                        }
                    }
                }, {
                    let m5027 = match v1.clone() {
                        Adt23::C0(_, h5026, _, _, _, _, _, _, _, _) => {
                            h5026
                        }
                    };
                    match m5027 {
                        Adt29::C0(_, h5025, _, _, _) => {
                            h5025
                        }
                    }
                }, {
                    let m5030 = match v1.clone() {
                        Adt23::C0(_, h5029, _, _, _, _, _, _, _, _) => {
                            h5029
                        }
                    };
                    match m5030 {
                        Adt29::C0(_, _, h5028, _, _) => {
                            h5028
                        }
                    }
                }, match v1 {
                    Adt23::C0(_, _, h5031, _, _, _, _, _, _, _) => {
                        h5031
                    }
                }, false)
            }
        }
        Adt55::C4 => {
            let m5034 = match v1.clone() {
                Adt23::C0(_, h5033, _, _, _, _, _, _, _, _) => {
                    h5033
                }
            };
            if if match m5034 {
                Adt29::C0(h5032, _, _, _, _) => {
                    h5032
                }
            } {
                let m5037 = match v1.clone() {
                    Adt23::C0(_, h5036, _, _, _, _, _, _, _, _) => {
                        h5036
                    }
                };
                if match m5037 {
                    Adt29::C0(_, h5035, _, _, _) => {
                        h5035
                    }
                } {
                    let m5040 = match v1.clone() {
                        Adt23::C0(_, h5039, _, _, _, _, _, _, _, _) => {
                            h5039
                        }
                    };
                    if match m5040 {
                        Adt29::C0(_, _, h5038, _, _) => {
                            h5038
                        }
                    } {
                        if match v1.clone() {
                            Adt23::C0(_, _, h5041, _, _, _, _, _, _, _) => {
                                h5041
                            }
                        } {
                            if match v1.clone() {
                                Adt23::C0(_, _, _, h5042, _, _, _, _, _, _) => {
                                    h5042
                                }
                            } {
                                let m5045 = match v1.clone() {
                                    Adt23::C0(_, h5044, _, _, _, _, _, _, _, _) => {
                                        h5044
                                    }
                                };
                                match m5045 {
                                    Adt29::C0(_, _, _, h5043, _) => {
                                        h5043
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f167(match v1.clone() {
                    Adt23::C0(_, _, _, _, h5046, _, _, _, _, _) => {
                        h5046
                    }
                }, false, f107(match v1 {
                    Adt23::C0(_, _, _, _, _, h5047, _, _, _, _) => {
                        h5047
                    }
                }))
            } else {
                Adt100::C2
            }
        }
        Adt55::C5 => {
            if match v1 {
                Adt23::C0(_, _, _, _, _, _, _, h5048, _, _) => {
                    h5048
                }
            } {
                Adt100::C0
            } else {
                Adt100::C2
            }
        }
        Adt55::C6 => {
            Adt100::C0
        }
        Adt55::C7 => {
            Adt100::C0
        }
        Adt55::C8 => {
            Adt100::C0
        }
        Adt55::C9 => {
            Adt100::C0
        }
    }
}

pub fn f157(v0: Adt6) -> Result<Adt6, Adt45> {
    let m5050 = match v0.clone() {
        Adt6::C0(h5049, _, _, _, _) => {
            h5049
        }
    };
    match m5050 {
        Adt7::C0 => {
            if match v0.clone() {
                Adt6::C0(_, h5051, _, _, _) => {
                    h5051
                }
            } {
                Ok::<Adt6, Adt45>(Adt6::C0(Adt7::C2, match v0.clone() {
                    Adt6::C0(_, h5052, _, _, _) => {
                        h5052
                    }
                }, match v0.clone() {
                    Adt6::C0(_, _, h5053, _, _) => {
                        h5053
                    }
                }, true, match v0 {
                    Adt6::C0(_, _, _, _, h5054) => {
                        h5054
                    }
                }))
            } else {
                Err::<Adt6, Adt45>(Adt45::C3)
            }
        }
        Adt7::C1 => {
            Err::<Adt6, Adt45>(Adt45::C2)
        }
        Adt7::C2 => {
            Err::<Adt6, Adt45>(Adt45::C2)
        }
        Adt7::C3 => {
            Err::<Adt6, Adt45>(Adt45::C2)
        }
        Adt7::C4 => {
            Err::<Adt6, Adt45>(Adt45::C2)
        }
    }
}

pub fn f158(v0: Adt10) -> bool {
    let m5055 = v0;
    match m5055 {
        Adt10::C0(_) => {
            true
        }
        Adt10::C1(_) => {
            false
        }
        Adt10::C2(_) => {
            false
        }
        Adt10::C3(v4) => {
            let m5057 = match v4 {
                Adt17::C0(_, h5056, _, _) => {
                    h5056
                }
            };
            match m5057 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt10::C4(_) => {
            true
        }
        Adt10::C5(_) => {
            false
        }
        Adt10::C6(_) => {
            false
        }
        Adt10::C7(v9) => {
            let m5059 = match v9 {
                Adt21::C0(_, _, h5058, _) => {
                    h5058
                }
            };
            match m5059 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt10::C8(_) => {
            false
        }
        Adt10::C9(_) => {
            false
        }
    }
}

pub fn f159(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m5060 = v0;
    match m5060 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a5065 = {
                let a5063 = v3;
                let a5064 = {
                    let a5061 = v1;
                    let a5062 = v2;
                    nat_add(a5061, a5062)?
                };
                nat_lt(a5063, a5064)
            };
            Ok(bool_not(a5065))
        }
    }
}

pub fn f160(v0: Adt25) -> R<u64> {
    let a5066 = f110(v0.clone())?;
    let a5067 = f35(v0)?;
    nat_add(a5066, a5067)
}

pub fn f161(v0: Adt15, v1: Adt47) -> Option<u64> {
    let m5068 = v1;
    match m5068 {
        Adt47::C0 => {
            match v0 {
                Adt15::C0(_, h5069, _, _, _) => {
                    h5069
                }
            }
        }
        Adt47::C1 => {
            match v0 {
                Adt15::C0(_, _, h5070, _, _) => {
                    h5070
                }
            }
        }
        Adt47::C2 => {
            match v0 {
                Adt15::C0(_, _, _, h5071, _) => {
                    h5071
                }
            }
        }
        Adt47::C3 => {
            match v0 {
                Adt15::C0(_, _, _, _, h5072) => {
                    h5072
                }
            }
        }
    }
}

pub fn f162(v0: Adt26, v1: Adt47) -> u64 {
    let m5073 = v1;
    match m5073 {
        Adt47::C0 => {
            match v0 {
                Adt26::C0(h5074, _, _, _) => {
                    h5074
                }
            }
        }
        Adt47::C1 => {
            match v0 {
                Adt26::C0(_, h5075, _, _) => {
                    h5075
                }
            }
        }
        Adt47::C2 => {
            match v0 {
                Adt26::C0(_, _, h5076, _) => {
                    h5076
                }
            }
        }
        Adt47::C3 => {
            match v0 {
                Adt26::C0(_, _, _, h5077) => {
                    h5077
                }
            }
        }
    }
}

pub fn f163(v0: Adt26, v1: Adt47, v2: u64) -> Adt26 {
    let m5078 = v1;
    match m5078 {
        Adt47::C0 => {
            Adt26::C0(v2, match v0.clone() {
                Adt26::C0(_, h5079, _, _) => {
                    h5079
                }
            }, match v0.clone() {
                Adt26::C0(_, _, h5080, _) => {
                    h5080
                }
            }, match v0 {
                Adt26::C0(_, _, _, h5081) => {
                    h5081
                }
            })
        }
        Adt47::C1 => {
            Adt26::C0(match v0.clone() {
                Adt26::C0(h5082, _, _, _) => {
                    h5082
                }
            }, v2, match v0.clone() {
                Adt26::C0(_, _, h5083, _) => {
                    h5083
                }
            }, match v0 {
                Adt26::C0(_, _, _, h5084) => {
                    h5084
                }
            })
        }
        Adt47::C2 => {
            Adt26::C0(match v0.clone() {
                Adt26::C0(h5085, _, _, _) => {
                    h5085
                }
            }, match v0.clone() {
                Adt26::C0(_, h5086, _, _) => {
                    h5086
                }
            }, v2, match v0 {
                Adt26::C0(_, _, _, h5087) => {
                    h5087
                }
            })
        }
        Adt47::C3 => {
            Adt26::C0(match v0.clone() {
                Adt26::C0(h5088, _, _, _) => {
                    h5088
                }
            }, match v0.clone() {
                Adt26::C0(_, h5089, _, _) => {
                    h5089
                }
            }, match v0 {
                Adt26::C0(_, _, h5090, _) => {
                    h5090
                }
            }, v2)
        }
    }
}

pub fn f164(v0: u64, v1: u64) -> u64 {
    let a5091 = v0;
    let a5092 = v1;
    if nat_lt(a5091, a5092) {
        v1
    } else {
        v0
    }
}

pub fn f165(v0: u64) -> Str {
    let a5093 = v0;
    let a5094 = 0u64;
    if nat_eq(a5093, a5094) {
        Str::lit("0")
    } else {
        let a5095 = v0;
        let a5096 = 1u64;
        if nat_eq(a5095, a5096) {
            Str::lit("1")
        } else {
            let a5097 = v0;
            let a5098 = 2u64;
            if nat_eq(a5097, a5098) {
                Str::lit("2")
            } else {
                let a5099 = v0;
                let a5100 = 3u64;
                if nat_eq(a5099, a5100) {
                    Str::lit("3")
                } else {
                    let a5101 = v0;
                    let a5102 = 4u64;
                    if nat_eq(a5101, a5102) {
                        Str::lit("4")
                    } else {
                        let a5103 = v0;
                        let a5104 = 5u64;
                        if nat_eq(a5103, a5104) {
                            Str::lit("5")
                        } else {
                            let a5105 = v0;
                            let a5106 = 6u64;
                            if nat_eq(a5105, a5106) {
                                Str::lit("6")
                            } else {
                                let a5107 = v0;
                                let a5108 = 7u64;
                                if nat_eq(a5107, a5108) {
                                    Str::lit("7")
                                } else {
                                    let a5109 = v0;
                                    let a5110 = 8u64;
                                    if nat_eq(a5109, a5110) {
                                        Str::lit("8")
                                    } else {
                                        Str::lit("9")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f166(v0: Adt25, v1: Adt25) -> bool {
    let a5117 = {
        let m5113 = match v0.clone() {
            Adt25::C0(h5112, _, _, _) => {
                h5112
            }
        };
        match m5113 {
            Adt26::C0(h5111, _, _, _) => {
                h5111
            }
        }
    };
    let a5118 = {
        let m5116 = match v1.clone() {
            Adt25::C0(h5115, _, _, _) => {
                h5115
            }
        };
        match m5116 {
            Adt26::C0(h5114, _, _, _) => {
                h5114
            }
        }
    };
    if nat_eq(a5117, a5118) {
        let a5125 = {
            let m5121 = match v0.clone() {
                Adt25::C0(h5120, _, _, _) => {
                    h5120
                }
            };
            match m5121 {
                Adt26::C0(_, h5119, _, _) => {
                    h5119
                }
            }
        };
        let a5126 = {
            let m5124 = match v1.clone() {
                Adt25::C0(h5123, _, _, _) => {
                    h5123
                }
            };
            match m5124 {
                Adt26::C0(_, h5122, _, _) => {
                    h5122
                }
            }
        };
        if nat_eq(a5125, a5126) {
            let a5133 = {
                let m5129 = match v0.clone() {
                    Adt25::C0(h5128, _, _, _) => {
                        h5128
                    }
                };
                match m5129 {
                    Adt26::C0(_, _, h5127, _) => {
                        h5127
                    }
                }
            };
            let a5134 = {
                let m5132 = match v1.clone() {
                    Adt25::C0(h5131, _, _, _) => {
                        h5131
                    }
                };
                match m5132 {
                    Adt26::C0(_, _, h5130, _) => {
                        h5130
                    }
                }
            };
            if nat_eq(a5133, a5134) {
                let a5141 = {
                    let m5137 = match v0.clone() {
                        Adt25::C0(h5136, _, _, _) => {
                            h5136
                        }
                    };
                    match m5137 {
                        Adt26::C0(_, _, _, h5135) => {
                            h5135
                        }
                    }
                };
                let a5142 = {
                    let m5140 = match v1.clone() {
                        Adt25::C0(h5139, _, _, _) => {
                            h5139
                        }
                    };
                    match m5140 {
                        Adt26::C0(_, _, _, h5138) => {
                            h5138
                        }
                    }
                };
                if nat_eq(a5141, a5142) {
                    let a5149 = {
                        let m5145 = match v0.clone() {
                            Adt25::C0(_, h5144, _, _) => {
                                h5144
                            }
                        };
                        match m5145 {
                            Adt26::C0(h5143, _, _, _) => {
                                h5143
                            }
                        }
                    };
                    let a5150 = {
                        let m5148 = match v1.clone() {
                            Adt25::C0(_, h5147, _, _) => {
                                h5147
                            }
                        };
                        match m5148 {
                            Adt26::C0(h5146, _, _, _) => {
                                h5146
                            }
                        }
                    };
                    if nat_eq(a5149, a5150) {
                        let a5157 = {
                            let m5153 = match v0.clone() {
                                Adt25::C0(_, h5152, _, _) => {
                                    h5152
                                }
                            };
                            match m5153 {
                                Adt26::C0(_, h5151, _, _) => {
                                    h5151
                                }
                            }
                        };
                        let a5158 = {
                            let m5156 = match v1.clone() {
                                Adt25::C0(_, h5155, _, _) => {
                                    h5155
                                }
                            };
                            match m5156 {
                                Adt26::C0(_, h5154, _, _) => {
                                    h5154
                                }
                            }
                        };
                        if nat_eq(a5157, a5158) {
                            let a5165 = {
                                let m5161 = match v0.clone() {
                                    Adt25::C0(_, h5160, _, _) => {
                                        h5160
                                    }
                                };
                                match m5161 {
                                    Adt26::C0(_, _, h5159, _) => {
                                        h5159
                                    }
                                }
                            };
                            let a5166 = {
                                let m5164 = match v1.clone() {
                                    Adt25::C0(_, h5163, _, _) => {
                                        h5163
                                    }
                                };
                                match m5164 {
                                    Adt26::C0(_, _, h5162, _) => {
                                        h5162
                                    }
                                }
                            };
                            if nat_eq(a5165, a5166) {
                                let a5173 = {
                                    let m5169 = match v0.clone() {
                                        Adt25::C0(_, h5168, _, _) => {
                                            h5168
                                        }
                                    };
                                    match m5169 {
                                        Adt26::C0(_, _, _, h5167) => {
                                            h5167
                                        }
                                    }
                                };
                                let a5174 = {
                                    let m5172 = match v1.clone() {
                                        Adt25::C0(_, h5171, _, _) => {
                                            h5171
                                        }
                                    };
                                    match m5172 {
                                        Adt26::C0(_, _, _, h5170) => {
                                            h5170
                                        }
                                    }
                                };
                                if nat_eq(a5173, a5174) {
                                    let a5177 = match v0.clone() {
                                        Adt25::C0(_, _, h5175, _) => {
                                            h5175
                                        }
                                    };
                                    let a5178 = match v1.clone() {
                                        Adt25::C0(_, _, h5176, _) => {
                                            h5176
                                        }
                                    };
                                    if nat_eq(a5177, a5178) {
                                        let a5181 = match v0 {
                                            Adt25::C0(_, _, _, h5179) => {
                                                h5179
                                            }
                                        };
                                        let a5182 = match v1 {
                                            Adt25::C0(_, _, _, h5180) => {
                                                h5180
                                            }
                                        };
                                        nat_eq(a5181, a5182)
                                    } else {
                                        false
                                    }
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f167(v0: Adt30, v1: bool, v2: Adt95) -> Adt100 {
    let m5183 = v0;
    match m5183 {
        Adt30::C0 => {
            if v1 {
                let m5184 = v2;
                if match m5184 {
                    Adt95::C0 => {
                        false
                    }
                    Adt95::C1 => {
                        true
                    }
                    Adt95::C2 => {
                        false
                    }
                    Adt95::C3 => {
                        false
                    }
                } {
                    Adt100::C0
                } else {
                    Adt100::C4
                }
            } else {
                Adt100::C0
            }
        }
        Adt30::C1 => {
            Adt100::C1
        }
        Adt30::C2 => {
            Adt100::C2
        }
        Adt30::C3 => {
            Adt100::C3
        }
    }
}

pub fn f168(v0: bool, v1: bool, v2: bool, v3: bool, v4: bool) -> Adt100 {
    if v4 {
        Adt100::C3
    } else {
        if if v0 {
            if v1 {
                if v2 {
                    if v3 {
                        let a5185 = v4;
                        bool_not(a5185)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        } {
            Adt100::C0
        } else {
            Adt100::C2
        }
    }
}
