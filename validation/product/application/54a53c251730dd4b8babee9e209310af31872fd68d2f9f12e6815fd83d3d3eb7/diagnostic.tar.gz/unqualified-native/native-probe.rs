#[path="application.rs"] mod generated;
#[path="controls.rs"] mod controls;
fn main() {
    let mut frame=generated::f0(generated::Adt0::C0(1)).expect("actual generated create");
    for _ in 0..64 {
        let generated::Adt71::C0(state,_,_,_,_,focus,_,_)=frame;
        assert_eq!(focus.text(),"file-input");
        frame=generated::f0(generated::Adt0::C5(state)).expect("same-package actual state/view call");
    }
    assert!(controls::f0().expect("actual generated source control suite"));
    println!("65 same-package create/present calls and 15 source control flows passed");
    let generated::Adt71::C0(state,_,_,_,_,_,_,_)=frame;
    let bound=generated::f109(state.clone(),generated::Adt70::C0);
    let overflow=generated::f0(generated::Adt0::C4(state,bound,generated::Str::lit("18446744073709551616")));
    assert!(overflow.is_err());
    println!("wide numeric edit observed outer Overflow without a Frame; ABI retention remains unqualified");
}
