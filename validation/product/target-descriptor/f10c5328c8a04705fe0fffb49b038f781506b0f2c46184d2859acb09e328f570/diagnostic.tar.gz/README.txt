TargetDescriptor diagnostic checkpoint

Exact selected source/configuration/lock, all declared generated outputs, official SDK runtime inputs, actual kernel/VM/axiom/mutant evidence, missing-owner red and source API extraction are retained. Annotation-only generated equality binds the preannotation mutant execution to the final computational source. Registered gate sources are supplemental registration evidence; the whole pinned gate is unrun. This is not an accepted production export or native operational ABI qualification.
