import Uorc.Uorc.Product.TargetDescriptorScenarios
open Uorc.Uorc.Product

def main : IO Unit := do
  let mut passed : Nat := 0
  let mut total : Nat := 0
  for observation in TargetDescriptorScenarios.observations do
    total := total + 1
    if observation.passed then passed := passed + 1 else IO.println s!"FAIL {observation.id}"
  IO.println s!"{passed}/{total} actual charged target descriptor controls passed"
  if total == 0 || passed != total then throw (IO.userError "binding controls failed")
