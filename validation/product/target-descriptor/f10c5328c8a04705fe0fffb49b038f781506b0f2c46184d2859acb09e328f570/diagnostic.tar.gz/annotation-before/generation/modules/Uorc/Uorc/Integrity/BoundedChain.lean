module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Integrity.Sha256
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Integrity.BoundedChain

public inductive Error where
  | sha256 (_ : Uorc.Uorc.Integrity.Sha256.Error)
  | invalidState
  | workPending
  | updateAfterFinalize
  | notFinalized
  | fuelExhausted

public inductive Stage where
  | idle
  | updating (_ : Uorc.Uorc.Integrity.Sha256.Update)
  | finalizing (_ : Uorc.Uorc.Integrity.Sha256.State)
  | finished

public structure State where
  chain : ByteArray
  buffer : ByteArray
  stage : Stage
  closing : Bool

public structure Update where
  state : State
  input : ByteArray
  offset : Nat

public inductive UpdateEvent where
  | advanced (_ : Update)
  | done (_ : State)

@[expose] public def domain : ByteArray := _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 45)), (_root_.UInt8.ofNat (nat_lit 83)), (_root_.UInt8.ofNat (nat_lit 72)), (_root_.UInt8.ofNat (nat_lit 65)), (_root_.UInt8.ofNat (nat_lit 50)), (_root_.UInt8.ofNat (nat_lit 53)), (_root_.UInt8.ofNat (nat_lit 54)), (_root_.UInt8.ofNat (nat_lit 45)), (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 72)), (_root_.UInt8.ofNat (nat_lit 65)), (_root_.UInt8.ofNat (nat_lit 73)), (_root_.UInt8.ofNat (nat_lit 78)), (_root_.UInt8.ofNat (nat_lit 45)), (_root_.UInt8.ofNat (nat_lit 118)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 0))]

@[expose] public def constructionName : String := "UORC-SHA256-CHAIN-v1"

@[expose] public def initialFrame : ByteArray := (LexLeanRuntime.append (domain) (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))]) : ByteArray)

@[expose] public def init : Except (Error) (State) := (match Uorc.Uorc.Integrity.Sha256.hash (initialFrame) with | Except.error cause => Except.error (Error.sha256 (cause)) | Except.ok initial => Except.ok (({ chain := initial, buffer := _root_.ByteArray.mk #[], stage := Stage.idle, closing := false } : State)))

@[expose] public def phaseValid (state : State) : Bool := (match (state).stage with | Stage.idle => (if (state).closing then false else true) | Stage.updating _ => (Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (0)) | Stage.finalizing _ => (Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (0)) | Stage.finished => ((state).closing && (Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (0))))

@[expose] public def valid (state : State) : Bool := ((Nat.beq ((LexLeanRuntime.length ((state).chain) : Nat)) (32)) && ((Nat.ble ((LexLeanRuntime.length ((state).buffer) : Nat)) (63)) && phaseValid (state)))

@[expose] public def dataFrame (state : State) (lastByte : UInt8) : ByteArray := (LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append (domain) (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1))]) : ByteArray)) ((state).chain) : ByteArray)) ((state).buffer) : ByteArray)) (Uorc.Uorc.Integrity.Sha256.byteBytes (lastByte)) : ByteArray)

@[expose] public def terminalLength (state : State) : ByteArray := (match (LexLeanRuntime.slice (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 2)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 4)), (_root_.UInt8.ofNat (nat_lit 5)), (_root_.UInt8.ofNat (nat_lit 6)), (_root_.UInt8.ofNat (nat_lit 7)), (_root_.UInt8.ofNat (nat_lit 8)), (_root_.UInt8.ofNat (nat_lit 9)), (_root_.UInt8.ofNat (nat_lit 10)), (_root_.UInt8.ofNat (nat_lit 11)), (_root_.UInt8.ofNat (nat_lit 12)), (_root_.UInt8.ofNat (nat_lit 13)), (_root_.UInt8.ofNat (nat_lit 14)), (_root_.UInt8.ofNat (nat_lit 15)), (_root_.UInt8.ofNat (nat_lit 16)), (_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 18)), (_root_.UInt8.ofNat (nat_lit 19)), (_root_.UInt8.ofNat (nat_lit 20)), (_root_.UInt8.ofNat (nat_lit 21)), (_root_.UInt8.ofNat (nat_lit 22)), (_root_.UInt8.ofNat (nat_lit 23)), (_root_.UInt8.ofNat (nat_lit 24)), (_root_.UInt8.ofNat (nat_lit 25)), (_root_.UInt8.ofNat (nat_lit 26)), (_root_.UInt8.ofNat (nat_lit 27)), (_root_.UInt8.ofNat (nat_lit 28)), (_root_.UInt8.ofNat (nat_lit 29)), (_root_.UInt8.ofNat (nat_lit 30)), (_root_.UInt8.ofNat (nat_lit 31)), (_root_.UInt8.ofNat (nat_lit 32)), (_root_.UInt8.ofNat (nat_lit 33)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 35)), (_root_.UInt8.ofNat (nat_lit 36)), (_root_.UInt8.ofNat (nat_lit 37)), (_root_.UInt8.ofNat (nat_lit 38)), (_root_.UInt8.ofNat (nat_lit 39)), (_root_.UInt8.ofNat (nat_lit 40)), (_root_.UInt8.ofNat (nat_lit 41)), (_root_.UInt8.ofNat (nat_lit 42)), (_root_.UInt8.ofNat (nat_lit 43)), (_root_.UInt8.ofNat (nat_lit 44)), (_root_.UInt8.ofNat (nat_lit 45)), (_root_.UInt8.ofNat (nat_lit 46)), (_root_.UInt8.ofNat (nat_lit 47)), (_root_.UInt8.ofNat (nat_lit 48)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 50)), (_root_.UInt8.ofNat (nat_lit 51)), (_root_.UInt8.ofNat (nat_lit 52)), (_root_.UInt8.ofNat (nat_lit 53)), (_root_.UInt8.ofNat (nat_lit 54)), (_root_.UInt8.ofNat (nat_lit 55)), (_root_.UInt8.ofNat (nat_lit 56)), (_root_.UInt8.ofNat (nat_lit 57)), (_root_.UInt8.ofNat (nat_lit 58)), (_root_.UInt8.ofNat (nat_lit 59)), (_root_.UInt8.ofNat (nat_lit 60)), (_root_.UInt8.ofNat (nat_lit 61)), (_root_.UInt8.ofNat (nat_lit 62)), (_root_.UInt8.ofNat (nat_lit 63))]) ((LexLeanRuntime.length ((state).buffer) : Nat)) (1) : Option (ByteArray)) with | Option.none => _root_.ByteArray.mk #[] | Option.some unwrapped => unwrapped)

@[expose] public def terminalFrame (state : State) : ByteArray := (LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append (domain) (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 2))]) : ByteArray)) ((state).chain) : ByteArray)) (terminalLength (state)) : ByteArray)) ((state).buffer) : ByteArray)

@[expose] public def startFrame (state : State) (frame : ByteArray) (closing : Bool) : Except (Error) (State) := (match Uorc.Uorc.Integrity.Sha256.beginUpdate (Uorc.Uorc.Integrity.Sha256.init) (frame) with | Except.error cause => Except.error (Error.sha256 (cause)) | Except.ok job => Except.ok (({ chain := (state).chain, buffer := _root_.ByteArray.mk #[], stage := Stage.updating (job), closing := closing } : State)))

@[expose] public def absorbByte (state : State) (byte : UInt8) : Except (Error) (State) := (if valid (state) then (if (state).closing then Except.error (Error.updateAfterFinalize) else (match (state).stage with | Stage.idle => (if (Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (63)) then startFrame (state) (dataFrame (state) (byte)) (false) else Except.ok (({ chain := (state).chain, buffer := (LexLeanRuntime.append ((state).buffer) (Uorc.Uorc.Integrity.Sha256.byteBytes (byte)) : ByteArray), stage := (state).stage, closing := (state).closing } : State))) | Stage.updating _ => Except.error (Error.workPending) | Stage.finalizing _ => Except.error (Error.workPending) | Stage.finished => Except.error (Error.updateAfterFinalize))) else Except.error (Error.invalidState))

@[expose] public def step (state : State) : Except (Error) (State) := (if valid (state) then (match (state).stage with | Stage.idle => Except.error (Error.workPending) | Stage.updating job => (match Uorc.Uorc.Integrity.Sha256.updateStep (job) with | Except.error cause => Except.error (Error.sha256 (cause)) | Except.ok event => (match event with | Uorc.Uorc.Integrity.Sha256.UpdateEvent.advanced nextJob => Except.ok (({ chain := (state).chain, buffer := (state).buffer, stage := Stage.updating (nextJob), closing := (state).closing } : State)) | Uorc.Uorc.Integrity.Sha256.UpdateEvent.done hashState => (match Uorc.Uorc.Integrity.Sha256.finalize (hashState) with | Except.error cause => Except.error (Error.sha256 (cause)) | Except.ok started => Except.ok (({ chain := (state).chain, buffer := (state).buffer, stage := Stage.finalizing (started), closing := (state).closing } : State))))) | Stage.finalizing hashState => (match (hashState).phase with | Uorc.Uorc.Integrity.Sha256.Phase.absorbing => Except.error (Error.invalidState) | Uorc.Uorc.Integrity.Sha256.Phase.finishing _ => (match Uorc.Uorc.Integrity.Sha256.finalizeStep (hashState) with | Except.error cause => Except.error (Error.sha256 (cause)) | Except.ok nextState => Except.ok (({ chain := (state).chain, buffer := (state).buffer, stage := Stage.finalizing (nextState), closing := (state).closing } : State))) | Uorc.Uorc.Integrity.Sha256.Phase.finished => (match Uorc.Uorc.Integrity.Sha256.digest (hashState) with | Except.error cause => Except.error (Error.sha256 (cause)) | Except.ok localDigest => Except.ok (({ chain := localDigest, buffer := (state).buffer, stage := (if (state).closing then Stage.finished else Stage.idle), closing := (state).closing } : State)))) | Stage.finished => Except.ok (state)) else Except.error (Error.invalidState))

@[expose] public def finalize (state : State) : Except (Error) (State) := (if valid (state) then (if (state).closing then Except.ok (state) else (match (state).stage with | Stage.idle => startFrame (state) (terminalFrame (state)) (true) | Stage.updating _ => Except.error (Error.workPending) | Stage.finalizing _ => Except.error (Error.workPending) | Stage.finished => Except.ok (state))) else Except.error (Error.invalidState))

@[expose] public def digest (state : State) : Except (Error) (ByteArray) := (if valid (state) then (match (state).stage with | Stage.idle => Except.error (Error.notFinalized) | Stage.updating _ => Except.error (Error.notFinalized) | Stage.finalizing _ => Except.error (Error.notFinalized) | Stage.finished => (if (state).closing then Except.ok ((state).chain) else Except.error (Error.invalidState))) else Except.error (Error.invalidState))

@[expose] public def beginUpdate (state : State) (input : ByteArray) : Except (Error) (Update) := (if valid (state) then (if (state).closing then Except.error (Error.updateAfterFinalize) else Except.ok (({ state := state, input := input, offset := 0 } : Update))) else Except.error (Error.invalidState))

@[expose] public def updateStep (localUpdate : Update) : Except (Error) (UpdateEvent) := (if valid ((localUpdate).state) then (if ((localUpdate).state).closing then Except.error (Error.updateAfterFinalize) else (if (Nat.ble ((localUpdate).offset) ((LexLeanRuntime.length ((localUpdate).input) : Nat))) then (match ((localUpdate).state).stage with | Stage.idle => (if (Nat.beq ((localUpdate).offset) ((LexLeanRuntime.length ((localUpdate).input) : Nat))) then Except.ok (UpdateEvent.done ((localUpdate).state)) else (match absorbByte ((localUpdate).state) ((match (LexLeanRuntime.index ((localUpdate).input) ((localUpdate).offset) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped)) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (localUpdate).input, offset := ((localUpdate).offset + 1) } : Update))))) | Stage.updating _ => (match step ((localUpdate).state) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (localUpdate).input, offset := (localUpdate).offset } : Update)))) | Stage.finalizing _ => (match step ((localUpdate).state) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (localUpdate).input, offset := (localUpdate).offset } : Update)))) | Stage.finished => Except.error (Error.updateAfterFinalize)) else Except.error (Error.invalidState))) else Except.error (Error.invalidState))

@[expose] public def runUpdate : (fuel : Nat) -> (localUpdate : Update) -> Except (Error) (State)
  | Nat.zero, _localUpdate => Except.error (Error.fuelExhausted)
  | Nat.succ rest, localUpdate => (match updateStep (localUpdate) with | Except.error failure => Except.error (failure) | Except.ok event => (match event with | UpdateEvent.advanced nextUpdate => runUpdate (rest) (nextUpdate) | UpdateEvent.done state => Except.ok (state)))

@[expose] public def update (state : State) (input : ByteArray) : Except (Error) (State) := (match beginUpdate (state) (input) with | Except.error failure => Except.error (failure) | Except.ok job => runUpdate (((LexLeanRuntime.multiply (12) ((LexLeanRuntime.length (input) : Nat)) : Nat) + 600)) (job))

@[expose] public def runFinalize : (fuel : Nat) -> (state : State) -> Except (Error) (ByteArray)
  | Nat.zero, _state => Except.error (Error.fuelExhausted)
  | Nat.succ rest, state => (match (state).stage with | Stage.idle => Except.error (Error.notFinalized) | Stage.updating _ => (match step (state) with | Except.error failure => Except.error (failure) | Except.ok nextState => runFinalize (rest) (nextState)) | Stage.finalizing _ => (match step (state) with | Except.error failure => Except.error (failure) | Except.ok nextState => runFinalize (rest) (nextState)) | Stage.finished => digest (state))

@[expose] public def hash (input : ByteArray) : Except (Error) (ByteArray) := (match init with | Except.error failure => Except.error (failure) | Except.ok initial => (match update (initial) (input) with | Except.error failure => Except.error (failure) | Except.ok updated => (match finalize (updated) with | Except.error failure => Except.error (failure) | Except.ok closing => runFinalize (600) (closing))))

end Uorc.Uorc.Integrity.BoundedChain
