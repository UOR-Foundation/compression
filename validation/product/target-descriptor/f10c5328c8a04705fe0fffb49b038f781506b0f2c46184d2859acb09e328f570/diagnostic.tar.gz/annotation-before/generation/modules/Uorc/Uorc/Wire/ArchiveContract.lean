module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Wire.ArchiveContract

public structure Scenario where
  id : String
  given : String
  when : String
  «then» : String
  owner : String

@[expose] public def uc_archive_parse_01 : Scenario := ({ id := "UC-ARCHIVE-PARSE-01", given := "format2/format3 raw and program archives with charged images", when := "parse every compact split, empty chunks and exact EOF", «then» := "canonical bounded frame events preserve body/integrity separation and charged length acknowledgments", owner := "Uorc.Wire.ArchiveParseScenarios.run" } : Scenario)

@[expose] public def uc_archive_parse_02 : Scenario := ({ id := "UC-ARCHIVE-PARSE-02", given := "malformed header, nonminimal/overflow, truncation and trailing bytes", when := "resume after acknowledged prefixes or cancel with a pending span", «then» := "typed sticky failure retains ownership, usage and resumable cleanup", owner := "Uorc.Wire.ArchiveParseScenarios.runNegatives" } : Scenario)

@[expose] public def uc_object_demux_01 : Scenario := ({ id := "UC-OBJECT-DEMUX-01", given := "ordered lengths in charged metadata including empty objects", when := "consume reconstruction spans across every boundary and split", «then» := "each begin/end boundary is preserved, every byte is compared and exact EOF seals", owner := "Uorc.Wire.ObjectDemuxScenarios.run" } : Scenario)

@[expose] public def uc_archive_compose_01 : Scenario := ({ id := "UC-ARCHIVE-COMPOSE-01", given := "one owned archive snapshot and existing source-owned format integrity", when := "compose frame, program events, hashing and ordered reconstruction", «then» := "one achieved arena is moved between controls, no AST fallback, no ready token before validation", owner := "Uorc.Wire.ArchiveSyntaxScenarios.run" } : Scenario)

@[expose] public def uc_wire_length_cancel_01 : Scenario := ({ id := "UC-WIRE-LENGTH-CANCEL-01", given := "a reserved Core table mutation at every prefix through publication", when := "cancel and drive the actual returned cursor and Arena to cleanup", «then» := "all owners are released, including a table completed by an in-flight final drain", owner := "Uorc.Wire.LengthStoreScenarios.run" } : Scenario)

@[expose] public def uc_table_cancel_repro_01 : Scenario := ({ id := "UC-TABLE-CANCEL-REPRO-01", given := "133 reserved put steps reach draining with null control and a live subtree", when := "invoke actual RuntimeTable.cancel and step through its cancelled outcome", «then» := "HeapAudit must reject an empty terminal inventory if the subtree ticket is still live; known shared Core regression", owner := "Uorc.Wire.TableCancelRepro.run" } : Scenario)

@[expose] public def uc_frame_nat_domain_01 : Scenario := ({ id := "UC-FRAME-NAT-DOMAIN-01", given := "compact format2 header prefixes with natural values 2^64", when := "read count, individual length, aggregate sum and body length through independent FrameParse", «then» := "the Nat field is observed without allocating a huge body; no format3 or full-archive acceptance claimed", owner := "Uorc.Wire.FrameDomainScenarios.run" } : Scenario)

@[expose] public def uc_wire_borrow_01 : Scenario := ({ id := "UC-WIRE-BORROW-01", given := "a pending literal over an external charged wire owner", when := "read bytes, acknowledge synchronous copy, pause, cancel or supply a wrong owner", «then» := "pending ticket stays live, no additional input ticket is retained and cleanup preserves external ownership", owner := "Uorc.Wire.BorrowedInputScenarios.run" } : Scenario)

@[expose] public def uc_wire_admission_01 : Scenario := ({ id := "UC-WIRE-ADMISSION-01", given := "bounded parser controls and actual Core credit/boundary objects", when := "move one Arena through event offer, credit, acknowledgment and detach/reattach", «then» := "only actual admission Ready is returned; independent archive verification and dependency qualification remain open", owner := "Uorc.Wire.ProgramAdmissionScenarios.run" } : Scenario)

@[expose] public def uc_frame_ownership_01 : Scenario := ({ id := "UC-FRAME-OWNERSHIP-01", given := "a pending archive body span with charged length metadata and one live input owner", when := "pause, transfer a retained span ticket, or cancel while it is pending", «then» := "the exact arena, usage and pending owner survive; every transferred ticket is explicitly released and cleanup audits", owner := "Uorc.Wire.FrameOwnershipScenarios.run" } : Scenario)

end Uorc.Uorc.Wire.ArchiveContract
