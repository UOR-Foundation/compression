module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Integrity.BoundedChain
public import Uorc.Uorc.Integrity.StreamEngine
public import Uorc.Uorc.Integrity.StreamMax
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Integrity.Profile

public inductive Kind where
  | format2Chain
  | format3Stream

public inductive Purpose where
  | archivePreimage
  | inputBytes
  | basisObjects
  | checkpointBytes

public inductive Error where
  | unsupportedFormat
  | unsupportedMachine
  | chain (_ : Uorc.Uorc.Integrity.BoundedChain.Error)
  | stream (_ : Uorc.Uorc.Integrity.StreamEngine.Error)
  | canceled
  | fuelExhausted

public inductive State where
  | chain (_ : Uorc.Uorc.Integrity.BoundedChain.State)
  | stream (_ : Uorc.Uorc.Integrity.StreamMax.State)
  | canceled (_ : Kind)

public inductive Update where
  | chain (_ : Uorc.Uorc.Integrity.BoundedChain.Update)
  | stream (_ : Uorc.Uorc.Integrity.StreamMax.Update)

public inductive Event where
  | advanced (_ : Update)
  | done (_ : State)

@[expose] public def select (localFormat : Nat) (localMachine : Nat) : Except (Error) (Kind) := (if (Nat.beq (localFormat) (2)) then (if (Nat.beq (localMachine) (1)) then Except.ok (Kind.format2Chain) else Except.error (Error.unsupportedMachine)) else (if (Nat.beq (localFormat) (3)) then (if (Nat.beq (localMachine) (1)) then Except.ok (Kind.format3Stream) else Except.error (Error.unsupportedMachine)) else Except.error (Error.unsupportedFormat)))

@[expose] public def format (kind : Kind) : Nat := (match kind with | Kind.format2Chain => 2 | Kind.format3Stream => 3)

@[expose] public def machine (_kind : Kind) : Nat := 1

@[expose] public def hashIdentity (kind : Kind) : String := (match kind with | Kind.format2Chain => "UORC-SHA256-CHAIN-v1" | Kind.format3Stream => "UORC-SHA256-STREAM-MAX-v1")

@[expose] public def «prefix» (kind : Kind) (purpose : Purpose) : ByteArray := (match purpose with | Purpose.archivePreimage => _root_.ByteArray.mk #[] | Purpose.inputBytes => (match kind with | Kind.format2Chain => (let __byte45 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 45); _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), __byte45, (_root_.UInt8.ofNat (nat_lit 73)), (_root_.UInt8.ofNat (nat_lit 78)), (_root_.UInt8.ofNat (nat_lit 80)), (_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 84)), __byte45, (_root_.UInt8.ofNat (nat_lit 66)), (_root_.UInt8.ofNat (nat_lit 89)), (_root_.UInt8.ofNat (nat_lit 84)), (_root_.UInt8.ofNat (nat_lit 69)), (_root_.UInt8.ofNat (nat_lit 83)), __byte45, (_root_.UInt8.ofNat (nat_lit 70)), (_root_.UInt8.ofNat (nat_lit 50)), __byte45, (_root_.UInt8.ofNat (nat_lit 77)), (_root_.UInt8.ofNat (nat_lit 49)), __byte45, (_root_.UInt8.ofNat (nat_lit 118)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 0))]) | Kind.format3Stream => (let __byte45 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 45); _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), __byte45, (_root_.UInt8.ofNat (nat_lit 73)), (_root_.UInt8.ofNat (nat_lit 78)), (_root_.UInt8.ofNat (nat_lit 80)), (_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 84)), __byte45, (_root_.UInt8.ofNat (nat_lit 66)), (_root_.UInt8.ofNat (nat_lit 89)), (_root_.UInt8.ofNat (nat_lit 84)), (_root_.UInt8.ofNat (nat_lit 69)), (_root_.UInt8.ofNat (nat_lit 83)), __byte45, (_root_.UInt8.ofNat (nat_lit 70)), (_root_.UInt8.ofNat (nat_lit 51)), __byte45, (_root_.UInt8.ofNat (nat_lit 77)), (_root_.UInt8.ofNat (nat_lit 49)), __byte45, (_root_.UInt8.ofNat (nat_lit 118)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 0))])) | Purpose.basisObjects => (match kind with | Kind.format2Chain => _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 45)), (_root_.UInt8.ofNat (nat_lit 66)), (_root_.UInt8.ofNat (nat_lit 65)), (_root_.UInt8.ofNat (nat_lit 83)), (_root_.UInt8.ofNat (nat_lit 73)), (_root_.UInt8.ofNat (nat_lit 83)), (_root_.UInt8.ofNat (nat_lit 45)), (_root_.UInt8.ofNat (nat_lit 86)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 0))] | Kind.format3Stream => (let __byte45 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 45); _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), __byte45, (_root_.UInt8.ofNat (nat_lit 66)), (_root_.UInt8.ofNat (nat_lit 65)), (_root_.UInt8.ofNat (nat_lit 83)), (_root_.UInt8.ofNat (nat_lit 73)), (_root_.UInt8.ofNat (nat_lit 83)), __byte45, (_root_.UInt8.ofNat (nat_lit 70)), (_root_.UInt8.ofNat (nat_lit 51)), __byte45, (_root_.UInt8.ofNat (nat_lit 77)), (_root_.UInt8.ofNat (nat_lit 49)), __byte45, (_root_.UInt8.ofNat (nat_lit 118)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 0))])) | Purpose.checkpointBytes => (match kind with | Kind.format2Chain => (let __byte45 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 45); _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), __byte45, (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 72)), (_root_.UInt8.ofNat (nat_lit 69)), (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 75)), (_root_.UInt8.ofNat (nat_lit 80)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 73)), (_root_.UInt8.ofNat (nat_lit 78)), (_root_.UInt8.ofNat (nat_lit 84)), __byte45, (_root_.UInt8.ofNat (nat_lit 70)), (_root_.UInt8.ofNat (nat_lit 50)), __byte45, (_root_.UInt8.ofNat (nat_lit 77)), (_root_.UInt8.ofNat (nat_lit 49)), __byte45, (_root_.UInt8.ofNat (nat_lit 118)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 0))]) | Kind.format3Stream => (let __byte45 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 45); _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), __byte45, (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 72)), (_root_.UInt8.ofNat (nat_lit 69)), (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 75)), (_root_.UInt8.ofNat (nat_lit 80)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 73)), (_root_.UInt8.ofNat (nat_lit 78)), (_root_.UInt8.ofNat (nat_lit 84)), __byte45, (_root_.UInt8.ofNat (nat_lit 70)), (_root_.UInt8.ofNat (nat_lit 51)), __byte45, (_root_.UInt8.ofNat (nat_lit 77)), (_root_.UInt8.ofNat (nat_lit 49)), __byte45, (_root_.UInt8.ofNat (nat_lit 118)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 0))])))

@[expose] public def archivePrefix (kind : Kind) : ByteArray := (match kind with | Kind.format2Chain => _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 2)), (_root_.UInt8.ofNat (nat_lit 1))] | Kind.format3Stream => _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 1))])

@[expose] public def requiresArchivePrefix (purpose : Purpose) : Bool := (match purpose with | Purpose.archivePreimage => true | Purpose.inputBytes => false | Purpose.basisObjects => false | Purpose.checkpointBytes => false)

@[expose] public def stateKind (state : State) : Kind := (match state with | State.chain _ => Kind.format2Chain | State.stream _ => Kind.format3Stream | State.canceled profile => profile)

@[expose] public def updateKind (job : Update) : Kind := (match job with | Update.chain _ => Kind.format2Chain | Update.stream _ => Kind.format3Stream)

@[expose] public def init (kind : Kind) : Except (Error) (State) := (match kind with | Kind.format2Chain => (match Uorc.Uorc.Integrity.BoundedChain.init with | Except.error cause => Except.error (Error.chain (cause)) | Except.ok hashState => Except.ok (State.chain (hashState))) | Kind.format3Stream => (match Uorc.Uorc.Integrity.StreamMax.init with | Except.error cause => Except.error (Error.stream (cause)) | Except.ok hashState => Except.ok (State.stream (hashState))))

@[expose] public def step (state : State) : Except (Error) (State) := (match state with | State.chain hashState => (match Uorc.Uorc.Integrity.BoundedChain.step (hashState) with | Except.error cause => Except.error (Error.chain (cause)) | Except.ok nextHash => Except.ok (State.chain (nextHash))) | State.stream hashState => (match Uorc.Uorc.Integrity.StreamMax.step (hashState) with | Except.error cause => Except.error (Error.stream (cause)) | Except.ok nextHash => Except.ok (State.stream (nextHash))) | State.canceled _ => Except.error (Error.canceled))

@[expose] public def finalize (state : State) : Except (Error) (State) := (match state with | State.chain hashState => (match Uorc.Uorc.Integrity.BoundedChain.finalize (hashState) with | Except.error cause => Except.error (Error.chain (cause)) | Except.ok nextHash => Except.ok (State.chain (nextHash))) | State.stream hashState => (match Uorc.Uorc.Integrity.StreamMax.finalize (hashState) with | Except.error cause => Except.error (Error.stream (cause)) | Except.ok nextHash => Except.ok (State.stream (nextHash))) | State.canceled _ => Except.error (Error.canceled))

@[expose] public def digest (state : State) : Except (Error) (ByteArray) := (match state with | State.chain hashState => (match Uorc.Uorc.Integrity.BoundedChain.digest (hashState) with | Except.error cause => Except.error (Error.chain (cause)) | Except.ok output => Except.ok (output)) | State.stream hashState => (match Uorc.Uorc.Integrity.StreamMax.digest (hashState) with | Except.error cause => Except.error (Error.stream (cause)) | Except.ok output => Except.ok (output)) | State.canceled _ => Except.error (Error.canceled))

@[expose] public def isFinished (state : State) : Bool := (match state with | State.chain hashState => (match (hashState).stage with | Uorc.Uorc.Integrity.BoundedChain.Stage.idle => false | Uorc.Uorc.Integrity.BoundedChain.Stage.updating _ => false | Uorc.Uorc.Integrity.BoundedChain.Stage.finalizing _ => false | Uorc.Uorc.Integrity.BoundedChain.Stage.finished => true) | State.stream hashState => (match ((hashState).engine).stage with | Uorc.Uorc.Integrity.StreamEngine.Stage.initializing _ => false | Uorc.Uorc.Integrity.StreamEngine.Stage.ready _ => false | Uorc.Uorc.Integrity.StreamEngine.Stage.suffix _ _ => false | Uorc.Uorc.Integrity.StreamEngine.Stage.finalizing _ _ => false | Uorc.Uorc.Integrity.StreamEngine.Stage.finished _ => true | Uorc.Uorc.Integrity.StreamEngine.Stage.canceled => false) | State.canceled _ => false)

@[expose] public def beginUpdate (state : State) (input : ByteArray) : Except (Error) (Update) := (match state with | State.chain hashState => (match Uorc.Uorc.Integrity.BoundedChain.beginUpdate (hashState) (input) with | Except.error cause => Except.error (Error.chain (cause)) | Except.ok hashJob => Except.ok (Update.chain (hashJob))) | State.stream hashState => (match Uorc.Uorc.Integrity.StreamMax.beginUpdate (hashState) (input) with | Except.error cause => Except.error (Error.stream (cause)) | Except.ok hashJob => Except.ok (Update.stream (hashJob))) | State.canceled _ => Except.error (Error.canceled))

@[expose] public def updateStep (job : Update) : Except (Error) (Event) := (match job with | Update.chain hashJob => (match Uorc.Uorc.Integrity.BoundedChain.updateStep (hashJob) with | Except.error cause => Except.error (Error.chain (cause)) | Except.ok hashEvent => (match hashEvent with | Uorc.Uorc.Integrity.BoundedChain.UpdateEvent.advanced nextJob => Except.ok (Event.advanced (Update.chain (nextJob))) | Uorc.Uorc.Integrity.BoundedChain.UpdateEvent.done hashState => Except.ok (Event.done (State.chain (hashState))))) | Update.stream hashJob => (match Uorc.Uorc.Integrity.StreamMax.updateStep (hashJob) with | Except.error cause => Except.error (Error.stream (cause)) | Except.ok hashEvent => (match hashEvent with | Uorc.Uorc.Integrity.StreamMax.UpdateEvent.advanced nextJob => Except.ok (Event.advanced (Update.stream (nextJob))) | Uorc.Uorc.Integrity.StreamMax.UpdateEvent.done hashState => Except.ok (Event.done (State.stream (hashState))))))

@[expose] public def cancel (state : State) : State := State.canceled (stateKind (state))

@[expose] public def cancelUpdate (job : Update) : State := State.canceled (updateKind (job))

@[expose] public def runUpdate : (fuel : Nat) -> (job : Update) -> Except (Error) (State)
  | Nat.zero, _job => Except.error (Error.fuelExhausted)
  | Nat.succ rest, job => (match updateStep (job) with | Except.error failure => Except.error (failure) | Except.ok event => (match event with | Event.advanced nextJob => runUpdate (rest) (nextJob) | Event.done state => Except.ok (state)))

@[expose] public def update (state : State) (input : ByteArray) : Except (Error) (State) := (match beginUpdate (state) (input) with | Except.error failure => Except.error (failure) | Except.ok job => runUpdate (((LexLeanRuntime.multiply (600) ((LexLeanRuntime.length (input) : Nat)) : Nat) + 1200)) (job))

@[expose] public def runFinalize : (fuel : Nat) -> (state : State) -> Except (Error) (ByteArray)
  | Nat.zero, _state => Except.error (Error.fuelExhausted)
  | Nat.succ rest, state => (match digest (state) with | Except.ok output => Except.ok (output) | Except.error _ => (match step (state) with | Except.error failure => Except.error (failure) | Except.ok nextState => runFinalize (rest) (nextState)))

@[expose] public def hash (kind : Kind) (purpose : Purpose) (input : ByteArray) : Except (Error) (ByteArray) := (match init (kind) with | Except.error failure => Except.error (failure) | Except.ok initial => (match update (initial) («prefix» (kind) (purpose)) with | Except.error failure => Except.error (failure) | Except.ok prefixed => (match update (prefixed) (input) with | Except.error failure => Except.error (failure) | Except.ok updated => (match finalize (updated) with | Except.error failure => Except.error (failure) | Except.ok closing => runFinalize (1200) (closing)))))

public theorem format2_is_legacy : (select (2) (1) = Except.ok (Kind.format2Chain)) := by
  rfl

public theorem format3_is_stream_max : (select (3) (1) = Except.ok (Kind.format3Stream)) := by
  rfl

public theorem unknown_machine_rejected : (select (3) (2) = Except.error (Error.unsupportedMachine)) := by
  rfl

public theorem unknown_format_rejected : (select (4) (1) = Except.error (Error.unsupportedFormat)) := by
  rfl

public theorem archive_has_no_extra_domain : («prefix» (Kind.format3Stream) (Purpose.archivePreimage) = _root_.ByteArray.mk #[]) := by
  rfl

end Uorc.Uorc.Integrity.Profile
