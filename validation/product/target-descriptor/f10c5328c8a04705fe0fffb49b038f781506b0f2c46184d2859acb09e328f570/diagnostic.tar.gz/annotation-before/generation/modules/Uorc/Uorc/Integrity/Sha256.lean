module
public import Init
public import LexLeanRuntime.Portable
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Integrity.Sha256

public inductive Error where
  | invalidState
  | lengthDomainExceeded
  | workPending
  | updateAfterFinalize
  | notFinalized
  | fuelExhausted
  | invalidOffset

public structure Words where
  a : UInt32
  b : UInt32
  c : UInt32
  d : UInt32
  e : UInt32
  f : UInt32
  g : UInt32
  h : UInt32

public structure Compression where
  base : Words
  registers : Words
  schedule : List (UInt32)
  round : Nat

public inductive Phase where
  | absorbing
  | finishing (_ : ByteArray)
  | finished

public structure State where
  chain : Words
  buffer : ByteArray
  count : UInt64
  work : Option (Compression)
  phase : Phase

public structure Update where
  state : State
  input : ByteArray
  offset : Nat

public inductive UpdateEvent where
  | advanced (_ : Update)
  | done (_ : State)

@[expose] public def u32Add (x : UInt32) (y : UInt32) : UInt32 := (match (LexLeanRuntime.checkedAdd (x) (y) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)

@[expose] public def u32Sub (x : UInt32) (y : UInt32) : UInt32 := (match (LexLeanRuntime.checkedSubtract (x) (y) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)

@[expose] public def u64Add (x : UInt64) (y : UInt64) : UInt64 := (match (LexLeanRuntime.checkedAdd (x) (y) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)

@[expose] public def u64Sub (x : UInt64) (y : UInt64) : UInt64 := (match (LexLeanRuntime.checkedSubtract (x) (y) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)

@[expose] public def wrappingAdd (x : UInt32) (y : UInt32) : UInt32 := (match (LexLeanRuntime.checkedAdd (x) (y) : Option (UInt32)) with | Option.none => u32Sub (u32Sub (x) ((LexLeanRuntime.bitNot (y) : UInt32))) ((1 : UInt32)) | Option.some unwrapped => unwrapped)

@[expose] public def bigSigma0 (x : UInt32) : UInt32 := (LexLeanRuntime.bitXor ((LexLeanRuntime.bitXor ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((2 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((30 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((13 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((19 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) : UInt32)) ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((22 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((10 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) : UInt32)

@[expose] public def bigSigma1 (x : UInt32) : UInt32 := (LexLeanRuntime.bitXor ((LexLeanRuntime.bitXor ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((6 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((26 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((11 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((21 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) : UInt32)) ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((25 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((7 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) : UInt32)

@[expose] public def smallSigma0 (x : UInt32) : UInt32 := (LexLeanRuntime.bitXor ((LexLeanRuntime.bitXor ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((7 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((25 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((18 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((14 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) : UInt32)) ((match (LexLeanRuntime.shiftRight (x) ((3 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)

@[expose] public def smallSigma1 (x : UInt32) : UInt32 := (LexLeanRuntime.bitXor ((LexLeanRuntime.bitXor ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((17 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((15 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftRight (x) ((19 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (x) ((13 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) : UInt32)) ((match (LexLeanRuntime.shiftRight (x) ((10 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)

@[expose] public def choose (x : UInt32) (y : UInt32) (z : UInt32) : UInt32 := (LexLeanRuntime.bitXor ((LexLeanRuntime.bitAnd (x) (y) : UInt32)) ((LexLeanRuntime.bitAnd ((LexLeanRuntime.bitNot (x) : UInt32)) (z) : UInt32)) : UInt32)

@[expose] public def majority (x : UInt32) (y : UInt32) (z : UInt32) : UInt32 := (LexLeanRuntime.bitXor ((LexLeanRuntime.bitXor ((LexLeanRuntime.bitAnd (x) (y) : UInt32)) ((LexLeanRuntime.bitAnd (x) (z) : UInt32)) : UInt32)) ((LexLeanRuntime.bitAnd (y) (z) : UInt32)) : UInt32)

@[expose] public def constants : List (UInt32) := ((1116352408 : UInt32) :: ((1899447441 : UInt32) :: ((3049323471 : UInt32) :: ((3921009573 : UInt32) :: ((961987163 : UInt32) :: ((1508970993 : UInt32) :: ((2453635748 : UInt32) :: ((2870763221 : UInt32) :: ((3624381080 : UInt32) :: ((310598401 : UInt32) :: ((607225278 : UInt32) :: ((1426881987 : UInt32) :: ((1925078388 : UInt32) :: ((2162078206 : UInt32) :: ((2614888103 : UInt32) :: ((3248222580 : UInt32) :: ((3835390401 : UInt32) :: ((4022224774 : UInt32) :: ((264347078 : UInt32) :: ((604807628 : UInt32) :: ((770255983 : UInt32) :: ((1249150122 : UInt32) :: ((1555081692 : UInt32) :: ((1996064986 : UInt32) :: ((2554220882 : UInt32) :: ((2821834349 : UInt32) :: ((2952996808 : UInt32) :: ((3210313671 : UInt32) :: ((3336571891 : UInt32) :: ((3584528711 : UInt32) :: ((113926993 : UInt32) :: ((338241895 : UInt32) :: ((666307205 : UInt32) :: ((773529912 : UInt32) :: ((1294757372 : UInt32) :: ((1396182291 : UInt32) :: ((1695183700 : UInt32) :: ((1986661051 : UInt32) :: ((2177026350 : UInt32) :: ((2456956037 : UInt32) :: ((2730485921 : UInt32) :: ((2820302411 : UInt32) :: ((3259730800 : UInt32) :: ((3345764771 : UInt32) :: ((3516065817 : UInt32) :: ((3600352804 : UInt32) :: ((4094571909 : UInt32) :: ((275423344 : UInt32) :: ((430227734 : UInt32) :: ((506948616 : UInt32) :: ((659060556 : UInt32) :: ((883997877 : UInt32) :: ((958139571 : UInt32) :: ((1322822218 : UInt32) :: ((1537002063 : UInt32) :: ((1747873779 : UInt32) :: ((1955562222 : UInt32) :: ((2024104815 : UInt32) :: ((2227730452 : UInt32) :: ((2361852424 : UInt32) :: ((2428436474 : UInt32) :: ((2756734187 : UInt32) :: ((3204031479 : UInt32) :: ((3329325298 : UInt32) :: ([] : List (UInt32))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

@[expose] public def roundConstant (roundNumber : Nat) : UInt32 := (if (Nat.blt (roundNumber) (64)) then (if (Nat.blt (roundNumber) (32)) then (if (Nat.blt (roundNumber) (16)) then (if (Nat.blt (roundNumber) (8)) then (if (Nat.blt (roundNumber) (4)) then (if (Nat.blt (roundNumber) (2)) then (if (Nat.blt (roundNumber) (1)) then (1116352408 : UInt32) else (1899447441 : UInt32)) else (if (Nat.blt (roundNumber) (3)) then (3049323471 : UInt32) else (3921009573 : UInt32))) else (if (Nat.blt (roundNumber) (6)) then (if (Nat.blt (roundNumber) (5)) then (961987163 : UInt32) else (1508970993 : UInt32)) else (if (Nat.blt (roundNumber) (7)) then (2453635748 : UInt32) else (2870763221 : UInt32)))) else (if (Nat.blt (roundNumber) (12)) then (if (Nat.blt (roundNumber) (10)) then (if (Nat.blt (roundNumber) (9)) then (3624381080 : UInt32) else (310598401 : UInt32)) else (if (Nat.blt (roundNumber) (11)) then (607225278 : UInt32) else (1426881987 : UInt32))) else (if (Nat.blt (roundNumber) (14)) then (if (Nat.blt (roundNumber) (13)) then (1925078388 : UInt32) else (2162078206 : UInt32)) else (if (Nat.blt (roundNumber) (15)) then (2614888103 : UInt32) else (3248222580 : UInt32))))) else (if (Nat.blt (roundNumber) (24)) then (if (Nat.blt (roundNumber) (20)) then (if (Nat.blt (roundNumber) (18)) then (if (Nat.blt (roundNumber) (17)) then (3835390401 : UInt32) else (4022224774 : UInt32)) else (if (Nat.blt (roundNumber) (19)) then (264347078 : UInt32) else (604807628 : UInt32))) else (if (Nat.blt (roundNumber) (22)) then (if (Nat.blt (roundNumber) (21)) then (770255983 : UInt32) else (1249150122 : UInt32)) else (if (Nat.blt (roundNumber) (23)) then (1555081692 : UInt32) else (1996064986 : UInt32)))) else (if (Nat.blt (roundNumber) (28)) then (if (Nat.blt (roundNumber) (26)) then (if (Nat.blt (roundNumber) (25)) then (2554220882 : UInt32) else (2821834349 : UInt32)) else (if (Nat.blt (roundNumber) (27)) then (2952996808 : UInt32) else (3210313671 : UInt32))) else (if (Nat.blt (roundNumber) (30)) then (if (Nat.blt (roundNumber) (29)) then (3336571891 : UInt32) else (3584528711 : UInt32)) else (if (Nat.blt (roundNumber) (31)) then (113926993 : UInt32) else (338241895 : UInt32)))))) else (if (Nat.blt (roundNumber) (48)) then (if (Nat.blt (roundNumber) (40)) then (if (Nat.blt (roundNumber) (36)) then (if (Nat.blt (roundNumber) (34)) then (if (Nat.blt (roundNumber) (33)) then (666307205 : UInt32) else (773529912 : UInt32)) else (if (Nat.blt (roundNumber) (35)) then (1294757372 : UInt32) else (1396182291 : UInt32))) else (if (Nat.blt (roundNumber) (38)) then (if (Nat.blt (roundNumber) (37)) then (1695183700 : UInt32) else (1986661051 : UInt32)) else (if (Nat.blt (roundNumber) (39)) then (2177026350 : UInt32) else (2456956037 : UInt32)))) else (if (Nat.blt (roundNumber) (44)) then (if (Nat.blt (roundNumber) (42)) then (if (Nat.blt (roundNumber) (41)) then (2730485921 : UInt32) else (2820302411 : UInt32)) else (if (Nat.blt (roundNumber) (43)) then (3259730800 : UInt32) else (3345764771 : UInt32))) else (if (Nat.blt (roundNumber) (46)) then (if (Nat.blt (roundNumber) (45)) then (3516065817 : UInt32) else (3600352804 : UInt32)) else (if (Nat.blt (roundNumber) (47)) then (4094571909 : UInt32) else (275423344 : UInt32))))) else (if (Nat.blt (roundNumber) (56)) then (if (Nat.blt (roundNumber) (52)) then (if (Nat.blt (roundNumber) (50)) then (if (Nat.blt (roundNumber) (49)) then (430227734 : UInt32) else (506948616 : UInt32)) else (if (Nat.blt (roundNumber) (51)) then (659060556 : UInt32) else (883997877 : UInt32))) else (if (Nat.blt (roundNumber) (54)) then (if (Nat.blt (roundNumber) (53)) then (958139571 : UInt32) else (1322822218 : UInt32)) else (if (Nat.blt (roundNumber) (55)) then (1537002063 : UInt32) else (1747873779 : UInt32)))) else (if (Nat.blt (roundNumber) (60)) then (if (Nat.blt (roundNumber) (58)) then (if (Nat.blt (roundNumber) (57)) then (1955562222 : UInt32) else (2024104815 : UInt32)) else (if (Nat.blt (roundNumber) (59)) then (2227730452 : UInt32) else (2361852424 : UInt32))) else (if (Nat.blt (roundNumber) (62)) then (if (Nat.blt (roundNumber) (61)) then (2428436474 : UInt32) else (2756734187 : UInt32)) else (if (Nat.blt (roundNumber) (63)) then (3204031479 : UInt32) else (3329325298 : UInt32))))))) else (0 : UInt32))

public theorem round_constant_00 : (roundConstant (0) = (match (LexLeanRuntime.index (constants) (0) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_01 : (roundConstant (1) = (match (LexLeanRuntime.index (constants) (1) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_02 : (roundConstant (2) = (match (LexLeanRuntime.index (constants) (2) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_03 : (roundConstant (3) = (match (LexLeanRuntime.index (constants) (3) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_04 : (roundConstant (4) = (match (LexLeanRuntime.index (constants) (4) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_05 : (roundConstant (5) = (match (LexLeanRuntime.index (constants) (5) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_06 : (roundConstant (6) = (match (LexLeanRuntime.index (constants) (6) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_07 : (roundConstant (7) = (match (LexLeanRuntime.index (constants) (7) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_08 : (roundConstant (8) = (match (LexLeanRuntime.index (constants) (8) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_09 : (roundConstant (9) = (match (LexLeanRuntime.index (constants) (9) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_10 : (roundConstant (10) = (match (LexLeanRuntime.index (constants) (10) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_11 : (roundConstant (11) = (match (LexLeanRuntime.index (constants) (11) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_12 : (roundConstant (12) = (match (LexLeanRuntime.index (constants) (12) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_13 : (roundConstant (13) = (match (LexLeanRuntime.index (constants) (13) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_14 : (roundConstant (14) = (match (LexLeanRuntime.index (constants) (14) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_15 : (roundConstant (15) = (match (LexLeanRuntime.index (constants) (15) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_16 : (roundConstant (16) = (match (LexLeanRuntime.index (constants) (16) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_17 : (roundConstant (17) = (match (LexLeanRuntime.index (constants) (17) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_18 : (roundConstant (18) = (match (LexLeanRuntime.index (constants) (18) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_19 : (roundConstant (19) = (match (LexLeanRuntime.index (constants) (19) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_20 : (roundConstant (20) = (match (LexLeanRuntime.index (constants) (20) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_21 : (roundConstant (21) = (match (LexLeanRuntime.index (constants) (21) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_22 : (roundConstant (22) = (match (LexLeanRuntime.index (constants) (22) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_23 : (roundConstant (23) = (match (LexLeanRuntime.index (constants) (23) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_24 : (roundConstant (24) = (match (LexLeanRuntime.index (constants) (24) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_25 : (roundConstant (25) = (match (LexLeanRuntime.index (constants) (25) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_26 : (roundConstant (26) = (match (LexLeanRuntime.index (constants) (26) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_27 : (roundConstant (27) = (match (LexLeanRuntime.index (constants) (27) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_28 : (roundConstant (28) = (match (LexLeanRuntime.index (constants) (28) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_29 : (roundConstant (29) = (match (LexLeanRuntime.index (constants) (29) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_30 : (roundConstant (30) = (match (LexLeanRuntime.index (constants) (30) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_31 : (roundConstant (31) = (match (LexLeanRuntime.index (constants) (31) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_32 : (roundConstant (32) = (match (LexLeanRuntime.index (constants) (32) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_33 : (roundConstant (33) = (match (LexLeanRuntime.index (constants) (33) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_34 : (roundConstant (34) = (match (LexLeanRuntime.index (constants) (34) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_35 : (roundConstant (35) = (match (LexLeanRuntime.index (constants) (35) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_36 : (roundConstant (36) = (match (LexLeanRuntime.index (constants) (36) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_37 : (roundConstant (37) = (match (LexLeanRuntime.index (constants) (37) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_38 : (roundConstant (38) = (match (LexLeanRuntime.index (constants) (38) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_39 : (roundConstant (39) = (match (LexLeanRuntime.index (constants) (39) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_40 : (roundConstant (40) = (match (LexLeanRuntime.index (constants) (40) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_41 : (roundConstant (41) = (match (LexLeanRuntime.index (constants) (41) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_42 : (roundConstant (42) = (match (LexLeanRuntime.index (constants) (42) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_43 : (roundConstant (43) = (match (LexLeanRuntime.index (constants) (43) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_44 : (roundConstant (44) = (match (LexLeanRuntime.index (constants) (44) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_45 : (roundConstant (45) = (match (LexLeanRuntime.index (constants) (45) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_46 : (roundConstant (46) = (match (LexLeanRuntime.index (constants) (46) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_47 : (roundConstant (47) = (match (LexLeanRuntime.index (constants) (47) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_48 : (roundConstant (48) = (match (LexLeanRuntime.index (constants) (48) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_49 : (roundConstant (49) = (match (LexLeanRuntime.index (constants) (49) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_50 : (roundConstant (50) = (match (LexLeanRuntime.index (constants) (50) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_51 : (roundConstant (51) = (match (LexLeanRuntime.index (constants) (51) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_52 : (roundConstant (52) = (match (LexLeanRuntime.index (constants) (52) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_53 : (roundConstant (53) = (match (LexLeanRuntime.index (constants) (53) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_54 : (roundConstant (54) = (match (LexLeanRuntime.index (constants) (54) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_55 : (roundConstant (55) = (match (LexLeanRuntime.index (constants) (55) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_56 : (roundConstant (56) = (match (LexLeanRuntime.index (constants) (56) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_57 : (roundConstant (57) = (match (LexLeanRuntime.index (constants) (57) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_58 : (roundConstant (58) = (match (LexLeanRuntime.index (constants) (58) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_59 : (roundConstant (59) = (match (LexLeanRuntime.index (constants) (59) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_60 : (roundConstant (60) = (match (LexLeanRuntime.index (constants) (60) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_61 : (roundConstant (61) = (match (LexLeanRuntime.index (constants) (61) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_62 : (roundConstant (62) = (match (LexLeanRuntime.index (constants) (62) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_63 : (roundConstant (63) = (match (LexLeanRuntime.index (constants) (63) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

public theorem round_constant_64 : (roundConstant (64) = (match (LexLeanRuntime.index (constants) (64) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) := by
  rfl

@[expose] public def initialWords : Words := ({ a := (1779033703 : UInt32), b := (3144134277 : UInt32), c := (1013904242 : UInt32), d := (2773480762 : UInt32), e := (1359893119 : UInt32), f := (2600822924 : UInt32), g := (528734635 : UInt32), h := (1541459225 : UInt32) } : Words)

@[expose] public def init : State := ({ chain := initialWords, buffer := _root_.ByteArray.mk #[], count := (0 : UInt64), work := Option.none, phase := Phase.absorbing } : State)

@[expose] public def byteIndexAux : (fuel : Nat) -> (byte : UInt8) -> Nat
  | Nat.zero, _byte => 0
  | Nat.succ rest, byte => ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (byte) ((1 : UInt8)) : UInt8)) ((0 : UInt8)) : Bool) then 0 else 1) + (LexLeanRuntime.multiply (2) (byteIndexAux (rest) ((match (LexLeanRuntime.shiftRight (byte) ((1 : UInt32)) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped))) : Nat))

@[expose] public def byteBytes (byte : UInt8) : ByteArray := (match (LexLeanRuntime.slice (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 1)), (_root_.UInt8.ofNat (nat_lit 2)), (_root_.UInt8.ofNat (nat_lit 3)), (_root_.UInt8.ofNat (nat_lit 4)), (_root_.UInt8.ofNat (nat_lit 5)), (_root_.UInt8.ofNat (nat_lit 6)), (_root_.UInt8.ofNat (nat_lit 7)), (_root_.UInt8.ofNat (nat_lit 8)), (_root_.UInt8.ofNat (nat_lit 9)), (_root_.UInt8.ofNat (nat_lit 10)), (_root_.UInt8.ofNat (nat_lit 11)), (_root_.UInt8.ofNat (nat_lit 12)), (_root_.UInt8.ofNat (nat_lit 13)), (_root_.UInt8.ofNat (nat_lit 14)), (_root_.UInt8.ofNat (nat_lit 15)), (_root_.UInt8.ofNat (nat_lit 16)), (_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 18)), (_root_.UInt8.ofNat (nat_lit 19)), (_root_.UInt8.ofNat (nat_lit 20)), (_root_.UInt8.ofNat (nat_lit 21)), (_root_.UInt8.ofNat (nat_lit 22)), (_root_.UInt8.ofNat (nat_lit 23)), (_root_.UInt8.ofNat (nat_lit 24)), (_root_.UInt8.ofNat (nat_lit 25)), (_root_.UInt8.ofNat (nat_lit 26)), (_root_.UInt8.ofNat (nat_lit 27)), (_root_.UInt8.ofNat (nat_lit 28)), (_root_.UInt8.ofNat (nat_lit 29)), (_root_.UInt8.ofNat (nat_lit 30)), (_root_.UInt8.ofNat (nat_lit 31)), (_root_.UInt8.ofNat (nat_lit 32)), (_root_.UInt8.ofNat (nat_lit 33)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 35)), (_root_.UInt8.ofNat (nat_lit 36)), (_root_.UInt8.ofNat (nat_lit 37)), (_root_.UInt8.ofNat (nat_lit 38)), (_root_.UInt8.ofNat (nat_lit 39)), (_root_.UInt8.ofNat (nat_lit 40)), (_root_.UInt8.ofNat (nat_lit 41)), (_root_.UInt8.ofNat (nat_lit 42)), (_root_.UInt8.ofNat (nat_lit 43)), (_root_.UInt8.ofNat (nat_lit 44)), (_root_.UInt8.ofNat (nat_lit 45)), (_root_.UInt8.ofNat (nat_lit 46)), (_root_.UInt8.ofNat (nat_lit 47)), (_root_.UInt8.ofNat (nat_lit 48)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 50)), (_root_.UInt8.ofNat (nat_lit 51)), (_root_.UInt8.ofNat (nat_lit 52)), (_root_.UInt8.ofNat (nat_lit 53)), (_root_.UInt8.ofNat (nat_lit 54)), (_root_.UInt8.ofNat (nat_lit 55)), (_root_.UInt8.ofNat (nat_lit 56)), (_root_.UInt8.ofNat (nat_lit 57)), (_root_.UInt8.ofNat (nat_lit 58)), (_root_.UInt8.ofNat (nat_lit 59)), (_root_.UInt8.ofNat (nat_lit 60)), (_root_.UInt8.ofNat (nat_lit 61)), (_root_.UInt8.ofNat (nat_lit 62)), (_root_.UInt8.ofNat (nat_lit 63)), (_root_.UInt8.ofNat (nat_lit 64)), (_root_.UInt8.ofNat (nat_lit 65)), (_root_.UInt8.ofNat (nat_lit 66)), (_root_.UInt8.ofNat (nat_lit 67)), (_root_.UInt8.ofNat (nat_lit 68)), (_root_.UInt8.ofNat (nat_lit 69)), (_root_.UInt8.ofNat (nat_lit 70)), (_root_.UInt8.ofNat (nat_lit 71)), (_root_.UInt8.ofNat (nat_lit 72)), (_root_.UInt8.ofNat (nat_lit 73)), (_root_.UInt8.ofNat (nat_lit 74)), (_root_.UInt8.ofNat (nat_lit 75)), (_root_.UInt8.ofNat (nat_lit 76)), (_root_.UInt8.ofNat (nat_lit 77)), (_root_.UInt8.ofNat (nat_lit 78)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 80)), (_root_.UInt8.ofNat (nat_lit 81)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 83)), (_root_.UInt8.ofNat (nat_lit 84)), (_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 86)), (_root_.UInt8.ofNat (nat_lit 87)), (_root_.UInt8.ofNat (nat_lit 88)), (_root_.UInt8.ofNat (nat_lit 89)), (_root_.UInt8.ofNat (nat_lit 90)), (_root_.UInt8.ofNat (nat_lit 91)), (_root_.UInt8.ofNat (nat_lit 92)), (_root_.UInt8.ofNat (nat_lit 93)), (_root_.UInt8.ofNat (nat_lit 94)), (_root_.UInt8.ofNat (nat_lit 95)), (_root_.UInt8.ofNat (nat_lit 96)), (_root_.UInt8.ofNat (nat_lit 97)), (_root_.UInt8.ofNat (nat_lit 98)), (_root_.UInt8.ofNat (nat_lit 99)), (_root_.UInt8.ofNat (nat_lit 100)), (_root_.UInt8.ofNat (nat_lit 101)), (_root_.UInt8.ofNat (nat_lit 102)), (_root_.UInt8.ofNat (nat_lit 103)), (_root_.UInt8.ofNat (nat_lit 104)), (_root_.UInt8.ofNat (nat_lit 105)), (_root_.UInt8.ofNat (nat_lit 106)), (_root_.UInt8.ofNat (nat_lit 107)), (_root_.UInt8.ofNat (nat_lit 108)), (_root_.UInt8.ofNat (nat_lit 109)), (_root_.UInt8.ofNat (nat_lit 110)), (_root_.UInt8.ofNat (nat_lit 111)), (_root_.UInt8.ofNat (nat_lit 112)), (_root_.UInt8.ofNat (nat_lit 113)), (_root_.UInt8.ofNat (nat_lit 114)), (_root_.UInt8.ofNat (nat_lit 115)), (_root_.UInt8.ofNat (nat_lit 116)), (_root_.UInt8.ofNat (nat_lit 117)), (_root_.UInt8.ofNat (nat_lit 118)), (_root_.UInt8.ofNat (nat_lit 119)), (_root_.UInt8.ofNat (nat_lit 120)), (_root_.UInt8.ofNat (nat_lit 121)), (_root_.UInt8.ofNat (nat_lit 122)), (_root_.UInt8.ofNat (nat_lit 123)), (_root_.UInt8.ofNat (nat_lit 124)), (_root_.UInt8.ofNat (nat_lit 125)), (_root_.UInt8.ofNat (nat_lit 126)), (_root_.UInt8.ofNat (nat_lit 127)), (_root_.UInt8.ofNat (nat_lit 128)), (_root_.UInt8.ofNat (nat_lit 129)), (_root_.UInt8.ofNat (nat_lit 130)), (_root_.UInt8.ofNat (nat_lit 131)), (_root_.UInt8.ofNat (nat_lit 132)), (_root_.UInt8.ofNat (nat_lit 133)), (_root_.UInt8.ofNat (nat_lit 134)), (_root_.UInt8.ofNat (nat_lit 135)), (_root_.UInt8.ofNat (nat_lit 136)), (_root_.UInt8.ofNat (nat_lit 137)), (_root_.UInt8.ofNat (nat_lit 138)), (_root_.UInt8.ofNat (nat_lit 139)), (_root_.UInt8.ofNat (nat_lit 140)), (_root_.UInt8.ofNat (nat_lit 141)), (_root_.UInt8.ofNat (nat_lit 142)), (_root_.UInt8.ofNat (nat_lit 143)), (_root_.UInt8.ofNat (nat_lit 144)), (_root_.UInt8.ofNat (nat_lit 145)), (_root_.UInt8.ofNat (nat_lit 146)), (_root_.UInt8.ofNat (nat_lit 147)), (_root_.UInt8.ofNat (nat_lit 148)), (_root_.UInt8.ofNat (nat_lit 149)), (_root_.UInt8.ofNat (nat_lit 150)), (_root_.UInt8.ofNat (nat_lit 151)), (_root_.UInt8.ofNat (nat_lit 152)), (_root_.UInt8.ofNat (nat_lit 153)), (_root_.UInt8.ofNat (nat_lit 154)), (_root_.UInt8.ofNat (nat_lit 155)), (_root_.UInt8.ofNat (nat_lit 156)), (_root_.UInt8.ofNat (nat_lit 157)), (_root_.UInt8.ofNat (nat_lit 158)), (_root_.UInt8.ofNat (nat_lit 159)), (_root_.UInt8.ofNat (nat_lit 160)), (_root_.UInt8.ofNat (nat_lit 161)), (_root_.UInt8.ofNat (nat_lit 162)), (_root_.UInt8.ofNat (nat_lit 163)), (_root_.UInt8.ofNat (nat_lit 164)), (_root_.UInt8.ofNat (nat_lit 165)), (_root_.UInt8.ofNat (nat_lit 166)), (_root_.UInt8.ofNat (nat_lit 167)), (_root_.UInt8.ofNat (nat_lit 168)), (_root_.UInt8.ofNat (nat_lit 169)), (_root_.UInt8.ofNat (nat_lit 170)), (_root_.UInt8.ofNat (nat_lit 171)), (_root_.UInt8.ofNat (nat_lit 172)), (_root_.UInt8.ofNat (nat_lit 173)), (_root_.UInt8.ofNat (nat_lit 174)), (_root_.UInt8.ofNat (nat_lit 175)), (_root_.UInt8.ofNat (nat_lit 176)), (_root_.UInt8.ofNat (nat_lit 177)), (_root_.UInt8.ofNat (nat_lit 178)), (_root_.UInt8.ofNat (nat_lit 179)), (_root_.UInt8.ofNat (nat_lit 180)), (_root_.UInt8.ofNat (nat_lit 181)), (_root_.UInt8.ofNat (nat_lit 182)), (_root_.UInt8.ofNat (nat_lit 183)), (_root_.UInt8.ofNat (nat_lit 184)), (_root_.UInt8.ofNat (nat_lit 185)), (_root_.UInt8.ofNat (nat_lit 186)), (_root_.UInt8.ofNat (nat_lit 187)), (_root_.UInt8.ofNat (nat_lit 188)), (_root_.UInt8.ofNat (nat_lit 189)), (_root_.UInt8.ofNat (nat_lit 190)), (_root_.UInt8.ofNat (nat_lit 191)), (_root_.UInt8.ofNat (nat_lit 192)), (_root_.UInt8.ofNat (nat_lit 193)), (_root_.UInt8.ofNat (nat_lit 194)), (_root_.UInt8.ofNat (nat_lit 195)), (_root_.UInt8.ofNat (nat_lit 196)), (_root_.UInt8.ofNat (nat_lit 197)), (_root_.UInt8.ofNat (nat_lit 198)), (_root_.UInt8.ofNat (nat_lit 199)), (_root_.UInt8.ofNat (nat_lit 200)), (_root_.UInt8.ofNat (nat_lit 201)), (_root_.UInt8.ofNat (nat_lit 202)), (_root_.UInt8.ofNat (nat_lit 203)), (_root_.UInt8.ofNat (nat_lit 204)), (_root_.UInt8.ofNat (nat_lit 205)), (_root_.UInt8.ofNat (nat_lit 206)), (_root_.UInt8.ofNat (nat_lit 207)), (_root_.UInt8.ofNat (nat_lit 208)), (_root_.UInt8.ofNat (nat_lit 209)), (_root_.UInt8.ofNat (nat_lit 210)), (_root_.UInt8.ofNat (nat_lit 211)), (_root_.UInt8.ofNat (nat_lit 212)), (_root_.UInt8.ofNat (nat_lit 213)), (_root_.UInt8.ofNat (nat_lit 214)), (_root_.UInt8.ofNat (nat_lit 215)), (_root_.UInt8.ofNat (nat_lit 216)), (_root_.UInt8.ofNat (nat_lit 217)), (_root_.UInt8.ofNat (nat_lit 218)), (_root_.UInt8.ofNat (nat_lit 219)), (_root_.UInt8.ofNat (nat_lit 220)), (_root_.UInt8.ofNat (nat_lit 221)), (_root_.UInt8.ofNat (nat_lit 222)), (_root_.UInt8.ofNat (nat_lit 223)), (_root_.UInt8.ofNat (nat_lit 224)), (_root_.UInt8.ofNat (nat_lit 225)), (_root_.UInt8.ofNat (nat_lit 226)), (_root_.UInt8.ofNat (nat_lit 227)), (_root_.UInt8.ofNat (nat_lit 228)), (_root_.UInt8.ofNat (nat_lit 229)), (_root_.UInt8.ofNat (nat_lit 230)), (_root_.UInt8.ofNat (nat_lit 231)), (_root_.UInt8.ofNat (nat_lit 232)), (_root_.UInt8.ofNat (nat_lit 233)), (_root_.UInt8.ofNat (nat_lit 234)), (_root_.UInt8.ofNat (nat_lit 235)), (_root_.UInt8.ofNat (nat_lit 236)), (_root_.UInt8.ofNat (nat_lit 237)), (_root_.UInt8.ofNat (nat_lit 238)), (_root_.UInt8.ofNat (nat_lit 239)), (_root_.UInt8.ofNat (nat_lit 240)), (_root_.UInt8.ofNat (nat_lit 241)), (_root_.UInt8.ofNat (nat_lit 242)), (_root_.UInt8.ofNat (nat_lit 243)), (_root_.UInt8.ofNat (nat_lit 244)), (_root_.UInt8.ofNat (nat_lit 245)), (_root_.UInt8.ofNat (nat_lit 246)), (_root_.UInt8.ofNat (nat_lit 247)), (_root_.UInt8.ofNat (nat_lit 248)), (_root_.UInt8.ofNat (nat_lit 249)), (_root_.UInt8.ofNat (nat_lit 250)), (_root_.UInt8.ofNat (nat_lit 251)), (_root_.UInt8.ofNat (nat_lit 252)), (_root_.UInt8.ofNat (nat_lit 253)), (_root_.UInt8.ofNat (nat_lit 254)), (_root_.UInt8.ofNat (nat_lit 255))]) (byteIndexAux (8) (byte)) (1) : Option (ByteArray)) with | Option.none => _root_.ByteArray.mk #[] | Option.some unwrapped => unwrapped)

@[expose] public def asByte32 (word : UInt32) : UInt8 := (match (LexLeanRuntime.checkedConvert ((LexLeanRuntime.bitAnd (word) ((255 : UInt32)) : UInt32)) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped)

@[expose] public def asByte64 (word : UInt64) : UInt8 := (match (LexLeanRuntime.checkedConvert ((LexLeanRuntime.bitAnd (word) ((255 : UInt64)) : UInt64)) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped)

@[expose] public def widenByte (byte : UInt8) : UInt32 := (match (LexLeanRuntime.checkedConvert (byte) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)

@[expose] public def wordBytes (word : UInt32) : ByteArray := (LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append (_root_.ByteArray.mk #[]) (byteBytes (asByte32 ((match (LexLeanRuntime.shiftRight (word) ((24 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte32 ((match (LexLeanRuntime.shiftRight (word) ((16 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte32 ((match (LexLeanRuntime.shiftRight (word) ((8 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte32 ((match (LexLeanRuntime.shiftRight (word) ((0 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)))) : ByteArray)

@[expose] public def bitLengthBytes (count : UInt64) : ByteArray := (LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append (_root_.ByteArray.mk #[]) (byteBytes (asByte64 ((match (LexLeanRuntime.shiftRight ((match (LexLeanRuntime.shiftLeft (count) ((3 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)) ((56 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte64 ((match (LexLeanRuntime.shiftRight ((match (LexLeanRuntime.shiftLeft (count) ((3 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)) ((48 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte64 ((match (LexLeanRuntime.shiftRight ((match (LexLeanRuntime.shiftLeft (count) ((3 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)) ((40 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte64 ((match (LexLeanRuntime.shiftRight ((match (LexLeanRuntime.shiftLeft (count) ((3 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)) ((32 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte64 ((match (LexLeanRuntime.shiftRight ((match (LexLeanRuntime.shiftLeft (count) ((3 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)) ((24 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte64 ((match (LexLeanRuntime.shiftRight ((match (LexLeanRuntime.shiftLeft (count) ((3 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)) ((16 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte64 ((match (LexLeanRuntime.shiftRight ((match (LexLeanRuntime.shiftLeft (count) ((3 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)) ((8 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (byteBytes (asByte64 ((match (LexLeanRuntime.shiftRight ((match (LexLeanRuntime.shiftLeft (count) ((3 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)) ((0 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)

@[expose] public def wordsBytes (words : Words) : ByteArray := (LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append (_root_.ByteArray.mk #[]) (wordBytes ((words).a)) : ByteArray)) (wordBytes ((words).b)) : ByteArray)) (wordBytes ((words).c)) : ByteArray)) (wordBytes ((words).d)) : ByteArray)) (wordBytes ((words).e)) : ByteArray)) (wordBytes ((words).f)) : ByteArray)) (wordBytes ((words).g)) : ByteArray)) (wordBytes ((words).h)) : ByteArray)

@[expose] public def loadWord (block : ByteArray) (offset : Nat) : UInt32 := (LexLeanRuntime.bitOr ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftLeft (widenByte ((match (LexLeanRuntime.index (block) (offset) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped))) ((24 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) ((match (LexLeanRuntime.shiftLeft (widenByte ((match (LexLeanRuntime.index (block) ((offset + 1)) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped))) ((16 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) : UInt32)) ((LexLeanRuntime.bitOr ((match (LexLeanRuntime.shiftLeft (widenByte ((match (LexLeanRuntime.index (block) ((offset + 2)) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped))) ((8 : UInt32)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) (widenByte ((match (LexLeanRuntime.index (block) ((offset + 3)) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped))) : UInt32)) : UInt32)

@[expose] public def startCompression (base : Words) (block : ByteArray) : Compression := ({ base := base, registers := base, schedule := (loadWord (block) (0) :: (loadWord (block) (4) :: (loadWord (block) (8) :: (loadWord (block) (12) :: (loadWord (block) (16) :: (loadWord (block) (20) :: (loadWord (block) (24) :: (loadWord (block) (28) :: (loadWord (block) (32) :: (loadWord (block) (36) :: (loadWord (block) (40) :: (loadWord (block) (44) :: (loadWord (block) (48) :: (loadWord (block) (52) :: (loadWord (block) (56) :: (loadWord (block) (60) :: ([] : List (UInt32)))))))))))))))))), round := 0 } : Compression)

@[expose] public def replaceWord : (words : List (UInt32)) -> (index : Nat) -> (word : UInt32) -> List (UInt32)
  | List.nil, _index, _word => ([] : List (UInt32))
  | List.cons head tail, index, word => ((if (Nat.beq (index) (0)) then word else head) :: (if (Nat.beq (index) (0)) then tail else replaceWord (tail) ((LexLeanRuntime.subtract (index) (1) : Nat)) (word)))

@[expose] public def scheduleWord (work : Compression) : UInt32 := (if (Nat.blt ((work).round) (16)) then (match (LexLeanRuntime.index ((work).schedule) ((work).round) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped) else wrappingAdd (wrappingAdd (wrappingAdd ((match (LexLeanRuntime.index ((work).schedule) ((LexLeanRuntime.remainder ((work).round) (16) (0) : Nat)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)) (smallSigma0 ((match (LexLeanRuntime.index ((work).schedule) ((LexLeanRuntime.remainder (((work).round + 1)) (16) (0) : Nat)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped)))) ((match (LexLeanRuntime.index ((work).schedule) ((LexLeanRuntime.remainder (((work).round + 9)) (16) (0) : Nat)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped))) (smallSigma1 ((match (LexLeanRuntime.index ((work).schedule) ((LexLeanRuntime.remainder (((work).round + 14)) (16) (0) : Nat)) : Option (UInt32)) with | Option.none => (0 : UInt32) | Option.some unwrapped => unwrapped))))

@[expose] public def roundT1 (r : Words) (word : UInt32) (constant : UInt32) : UInt32 := wrappingAdd (wrappingAdd (wrappingAdd (wrappingAdd ((r).h) (bigSigma1 ((r).e))) (choose ((r).e) ((r).f) ((r).g))) (constant)) (word)

@[expose] public def roundT2 (r : Words) : UInt32 := wrappingAdd (bigSigma0 ((r).a)) (majority ((r).a) ((r).b) ((r).c))

@[expose] public def roundRegisters (r : Words) (word : UInt32) (constant : UInt32) : Words := ({ a := wrappingAdd (roundT1 (r) (word) (constant)) (roundT2 (r)), b := (r).a, c := (r).b, d := (r).c, e := wrappingAdd ((r).d) (roundT1 (r) (word) (constant)), f := (r).e, g := (r).f, h := (r).g } : Words)

@[expose] public def compressionRound (work : Compression) : Compression := ({ base := (work).base, registers := roundRegisters ((work).registers) (scheduleWord (work)) (roundConstant ((work).round)), schedule := replaceWord ((work).schedule) ((LexLeanRuntime.remainder ((work).round) (16) (0) : Nat)) (scheduleWord (work)), round := ((work).round + 1) } : Compression)

@[expose] public def feedForward (work : Compression) : Words := ({ a := wrappingAdd (((work).base).a) (((work).registers).a), b := wrappingAdd (((work).base).b) (((work).registers).b), c := wrappingAdd (((work).base).c) (((work).registers).c), d := wrappingAdd (((work).base).d) (((work).registers).d), e := wrappingAdd (((work).base).e) (((work).registers).e), f := wrappingAdd (((work).base).f) (((work).registers).f), g := wrappingAdd (((work).base).g) (((work).registers).g), h := wrappingAdd (((work).base).h) (((work).registers).h) } : Words)

@[expose] public def countValid (count : UInt64) : Bool := (match (LexLeanRuntime.checkedSubtract ((2305843009213693951 : UInt64)) (count) : Option (UInt64)) with | Option.none => false | Option.some _ => true)

@[expose] public def checkedSchedule : (fuel : Nat) -> (words : List (UInt32)) -> Bool
  | Nat.zero, words => (match words with | List.nil => true | List.cons _ _ => false)
  | Nat.succ rest, words => (match words with | List.nil => false | List.cons _ tail => checkedSchedule (rest) (tail))

@[expose] public def workValid (work : Option (Compression)) : Bool := (match work with | Option.none => true | Option.some compression => (checkedSchedule (16) ((compression).schedule) && (Nat.ble ((compression).round) (64))))

@[expose] public def hasWork (state : State) : Bool := (match (state).work with | Option.none => false | Option.some _ => true)

@[expose] public def countRemainder (count : UInt64) : Nat := byteIndexAux (8) (asByte64 ((LexLeanRuntime.bitAnd (count) ((63 : UInt64)) : UInt64)))

@[expose] public def phaseValid (state : State) : Bool := (match (state).phase with | Phase.absorbing => (Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (countRemainder ((state).count))) | Phase.finishing pendingPadding => ((Nat.ble ((LexLeanRuntime.length (pendingPadding) : Nat)) (72)) && (Nat.beq ((LexLeanRuntime.remainder (((LexLeanRuntime.length ((state).buffer) : Nat) + (LexLeanRuntime.length (pendingPadding) : Nat))) (64) (0) : Nat)) (0))) | Phase.finished => ((Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (0)) && (if hasWork (state) then false else true)))

@[expose] public def valid (state : State) : Bool := (countValid ((state).count) && ((Nat.ble ((LexLeanRuntime.length ((state).buffer) : Nat)) (63)) && (workValid ((state).work) && ((if hasWork (state) then (Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (0)) else true) && phaseValid (state)))))

@[expose] public def advanceWork (state : State) : Except (Error) (State) := (if valid (state) then (match (state).work with | Option.none => Except.error (Error.invalidState) | Option.some compression => Except.ok ((if (Nat.beq ((compression).round) (64)) then ({ chain := feedForward (compression), buffer := (state).buffer, count := (state).count, work := Option.none, phase := (state).phase } : State) else ({ chain := (state).chain, buffer := (state).buffer, count := (state).count, work := Option.some (compressionRound (compression)), phase := (state).phase } : State)))) else Except.error (Error.invalidState))

@[expose] public def appendRaw (state : State) (byte : UInt8) : State := (if (Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (63)) then ({ chain := (state).chain, buffer := _root_.ByteArray.mk #[], count := (state).count, work := Option.some (startCompression ((state).chain) ((LexLeanRuntime.append ((state).buffer) (byteBytes (byte)) : ByteArray))), phase := (state).phase } : State) else ({ chain := (state).chain, buffer := (LexLeanRuntime.append ((state).buffer) (byteBytes (byte)) : ByteArray), count := (state).count, work := (state).work, phase := (state).phase } : State))

@[expose] public def absorbByte (state : State) (byte : UInt8) : Except (Error) (State) := (if valid (state) then (match (state).phase with | Phase.absorbing => (if hasWork (state) then Except.error (Error.workPending) else (if (LexLeanRuntime.equal ((state).count) ((2305843009213693951 : UInt64)) : Bool) then Except.error (Error.lengthDomainExceeded) else Except.ok (appendRaw (({ chain := (state).chain, buffer := (state).buffer, count := u64Add ((state).count) ((1 : UInt64)), work := (state).work, phase := (state).phase } : State)) (byte)))) | Phase.finishing _ => Except.error (Error.updateAfterFinalize) | Phase.finished => Except.error (Error.updateAfterFinalize)) else Except.error (Error.invalidState))

@[expose] public def beginUpdate (state : State) (input : ByteArray) : Except (Error) (Update) := (if valid (state) then (match (state).phase with | Phase.absorbing => Except.ok (({ state := state, input := input, offset := 0 } : Update)) | Phase.finishing _ => Except.error (Error.updateAfterFinalize) | Phase.finished => Except.error (Error.updateAfterFinalize)) else Except.error (Error.invalidState))

@[expose] public def isAbsorbing (state : State) : Bool := (match (state).phase with | Phase.absorbing => true | Phase.finishing _ => false | Phase.finished => false)

@[expose] public def updateStep (localUpdate : Update) : Except (Error) (UpdateEvent) := (if valid ((localUpdate).state) then (if isAbsorbing ((localUpdate).state) then (if (Nat.ble ((localUpdate).offset) ((LexLeanRuntime.length ((localUpdate).input) : Nat))) then (if hasWork ((localUpdate).state) then (match advanceWork ((localUpdate).state) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (localUpdate).input, offset := (localUpdate).offset } : Update)))) else (if (Nat.beq ((localUpdate).offset) ((LexLeanRuntime.length ((localUpdate).input) : Nat))) then (if valid ((localUpdate).state) then Except.ok (UpdateEvent.done ((localUpdate).state)) else Except.error (Error.invalidState)) else (match absorbByte ((localUpdate).state) ((match (LexLeanRuntime.index ((localUpdate).input) ((localUpdate).offset) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped)) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (localUpdate).input, offset := ((localUpdate).offset + 1) } : Update)))))) else Except.error (Error.invalidOffset)) else Except.error (Error.updateAfterFinalize)) else Except.error (Error.invalidState))

@[expose] public def zeroBytes : (count : Nat) -> ByteArray
  | Nat.zero => _root_.ByteArray.mk #[]
  | Nat.succ rest => (LexLeanRuntime.append (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))]) (zeroBytes (rest)) : ByteArray)

@[expose] public def padding (state : State) : ByteArray := (LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append (_root_.ByteArray.mk #[]) (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 128))]) : ByteArray)) (zeroBytes ((LexLeanRuntime.subtract ((if (Nat.blt ((LexLeanRuntime.length ((state).buffer) : Nat)) (56)) then 55 else 119)) ((LexLeanRuntime.length ((state).buffer) : Nat)) : Nat))) : ByteArray)) (bitLengthBytes ((state).count)) : ByteArray)

@[expose] public def finalize (state : State) : Except (Error) (State) := (if valid (state) then (match (state).phase with | Phase.absorbing => Except.ok (({ chain := (state).chain, buffer := (state).buffer, count := (state).count, work := (state).work, phase := Phase.finishing (padding (state)) } : State)) | Phase.finishing _ => Except.ok (state) | Phase.finished => Except.ok (state)) else Except.error (Error.invalidState))

@[expose] public def tailBytes (input : ByteArray) : ByteArray := (match (LexLeanRuntime.slice (input) (1) ((LexLeanRuntime.subtract ((LexLeanRuntime.length (input) : Nat)) (1) : Nat)) : Option (ByteArray)) with | Option.none => _root_.ByteArray.mk #[] | Option.some unwrapped => unwrapped)

@[expose] public def finalizeStep (state : State) : Except (Error) (State) := (if valid (state) then (match (state).phase with | Phase.absorbing => Except.error (Error.notFinalized) | Phase.finishing pendingPadding => (if hasWork (state) then advanceWork (state) else (if (Nat.beq ((LexLeanRuntime.length (pendingPadding) : Nat)) (0)) then (if (Nat.beq ((LexLeanRuntime.length ((state).buffer) : Nat)) (0)) then Except.ok (({ chain := (state).chain, buffer := (state).buffer, count := (state).count, work := (state).work, phase := Phase.finished } : State)) else Except.error (Error.invalidState)) else Except.ok (appendRaw (({ chain := (state).chain, buffer := (state).buffer, count := (state).count, work := (state).work, phase := Phase.finishing (tailBytes (pendingPadding)) } : State)) ((match (LexLeanRuntime.index (pendingPadding) (0) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped))))) | Phase.finished => Except.ok (state)) else Except.error (Error.invalidState))

@[expose] public def digest (state : State) : Except (Error) (ByteArray) := (if valid (state) then (match (state).phase with | Phase.absorbing => Except.error (Error.notFinalized) | Phase.finishing _ => Except.error (Error.notFinalized) | Phase.finished => Except.ok (wordsBytes ((state).chain))) else Except.error (Error.invalidState))

@[expose] public def runUpdate : (fuel : Nat) -> (localUpdate : Update) -> Except (Error) (State)
  | Nat.zero, _localUpdate => Except.error (Error.fuelExhausted)
  | Nat.succ rest, localUpdate => (match updateStep (localUpdate) with | Except.error failure => Except.error (failure) | Except.ok event => (match event with | UpdateEvent.advanced nextUpdate => runUpdate (rest) (nextUpdate) | UpdateEvent.done state => Except.ok (state)))

@[expose] public def runFinalize : (fuel : Nat) -> (state : State) -> Except (Error) (ByteArray)
  | Nat.zero, _state => Except.error (Error.fuelExhausted)
  | Nat.succ rest, state => (match (state).phase with | Phase.absorbing => Except.error (Error.notFinalized) | Phase.finishing _ => (match finalizeStep (state) with | Except.error failure => Except.error (failure) | Except.ok nextState => runFinalize (rest) (nextState)) | Phase.finished => (if valid (state) then Except.ok (wordsBytes ((state).chain)) else Except.error (Error.invalidState)))

@[expose] public def update (state : State) (input : ByteArray) : Except (Error) (State) := (match beginUpdate (state) (input) with | Except.error failure => Except.error (failure) | Except.ok job => runUpdate (((LexLeanRuntime.multiply (3) ((LexLeanRuntime.length (input) : Nat)) : Nat) + 132)) (job))

@[expose] public def hash (input : ByteArray) : Except (Error) (ByteArray) := (match update (init) (input) with | Except.error failure => Except.error (failure) | Except.ok updated => (match finalize (updated) with | Except.error failure => Except.error (failure) | Except.ok finalizing => runFinalize (300) (finalizing)))

public theorem wrapping_overflow : (wrappingAdd ((4294967295 : UInt32)) ((1 : UInt32)) = (0 : UInt32)) := by
  rfl

public theorem wrapping_double_max : (wrappingAdd ((4294967295 : UInt32)) ((4294967295 : UInt32)) = (4294967294 : UInt32)) := by
  rfl

public theorem length_bytes_max : (bitLengthBytes ((2305843009213693951 : UInt64)) = (let __byte255 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 255); _root_.ByteArray.mk #[__byte255, __byte255, __byte255, __byte255, __byte255, __byte255, __byte255, (_root_.UInt8.ofNat (nat_lit 248))])) := by
  rfl

public theorem unfinished_digest : (digest (init) = Except.error (Error.notFinalized)) := by
  rfl

public theorem finalize_step_requires_start : (finalizeStep (init) = Except.error (Error.notFinalized)) := by
  rfl

public theorem zero_update_fuel : (runUpdate (0) (({ state := init, input := _root_.ByteArray.mk #[], offset := 0 } : Update)) = Except.error (Error.fuelExhausted)) := by
  rfl

public theorem invalid_offset : (updateStep (({ state := init, input := _root_.ByteArray.mk #[], offset := 1 } : Update)) = Except.error (Error.invalidOffset)) := by
  rfl

public theorem oversized_buffer : (digest (({ chain := (init).chain, buffer := (let __byte0 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 0); _root_.ByteArray.mk #[__byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0]), count := (init).count, work := (init).work, phase := (init).phase } : State)) = Except.error (Error.invalidState)) := by
  rfl

public theorem standard_length_domain : (absorbByte (({ chain := (init).chain, buffer := (let __byte0 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 0); _root_.ByteArray.mk #[__byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0]), count := (2305843009213693951 : UInt64), work := (init).work, phase := (init).phase } : State)) ((0 : UInt8)) = Except.error (Error.lengthDomainExceeded)) := by
  rfl

public theorem invalid_length_domain : (finalize (({ chain := (init).chain, buffer := (init).buffer, count := (2305843009213693952 : UInt64), work := (init).work, phase := (init).phase } : State)) = Except.error (Error.invalidState)) := by
  rfl

public theorem completed_finalize_refines_digest (remainingFuel : Nat) (stateValue : State) : (runFinalize (Nat.succ (remainingFuel)) (({ chain := (stateValue).chain, buffer := (stateValue).buffer, count := (stateValue).count, work := (stateValue).work, phase := Phase.finished } : State)) = digest (({ chain := (stateValue).chain, buffer := (stateValue).buffer, count := (stateValue).count, work := (stateValue).work, phase := Phase.finished } : State))) := by
  rfl

end Uorc.Uorc.Integrity.Sha256
