module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Integrity.Sha256
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Integrity.StreamEngine

public inductive Error where
  | sha256 (_ : Uorc.Uorc.Integrity.Sha256.Error)
  | invalidState
  | invalidFrameLimit
  | invalidOffset
  | workPending
  | updateAfterFinalize
  | notFinalized
  | fuelExhausted
  | canceled

public inductive Stage where
  | initializing (_ : Uorc.Uorc.Integrity.Sha256.Update)
  | ready (_ : Uorc.Uorc.Integrity.Sha256.State)
  | suffix (_ : Uorc.Uorc.Integrity.Sha256.Update) (_ : Bool)
  | finalizing (_ : Uorc.Uorc.Integrity.Sha256.State) (_ : Bool)
  | finished (_ : ByteArray)
  | canceled

public structure State where
  first : Bool
  stage : Stage
  closing : Bool

public structure Update where
  state : State
  input : ByteArray
  offset : Nat

public inductive UpdateEvent where
  | advanced (_ : Update)
  | done (_ : State)

@[expose] public def domain : ByteArray := (let __byte45 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 45); _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 85)), (_root_.UInt8.ofNat (nat_lit 79)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 67)), __byte45, (_root_.UInt8.ofNat (nat_lit 83)), (_root_.UInt8.ofNat (nat_lit 72)), (_root_.UInt8.ofNat (nat_lit 65)), (_root_.UInt8.ofNat (nat_lit 50)), (_root_.UInt8.ofNat (nat_lit 53)), (_root_.UInt8.ofNat (nat_lit 54)), __byte45, (_root_.UInt8.ofNat (nat_lit 83)), (_root_.UInt8.ofNat (nat_lit 84)), (_root_.UInt8.ofNat (nat_lit 82)), (_root_.UInt8.ofNat (nat_lit 69)), (_root_.UInt8.ofNat (nat_lit 65)), (_root_.UInt8.ofNat (nat_lit 77)), __byte45, (_root_.UInt8.ofNat (nat_lit 77)), (_root_.UInt8.ofNat (nat_lit 65)), (_root_.UInt8.ofNat (nat_lit 88)), __byte45, (_root_.UInt8.ofNat (nat_lit 118)), (_root_.UInt8.ofNat (nat_lit 49)), (_root_.UInt8.ofNat (nat_lit 0))])

@[expose] public def productionLimit : UInt64 := (2305843009213693942 : UInt64)

@[expose] public def prefixSize (first : Bool) : UInt64 := (if first then (27 : UInt64) else (59 : UInt64))

@[expose] public def limitValid (limit : UInt64) : Bool := ((match (LexLeanRuntime.checkedSubtract (limit) ((60 : UInt64)) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && ((match (LexLeanRuntime.checkedSubtract (productionLimit) (limit) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && true))

@[expose] public def «prefix» (first : Bool) (previous : ByteArray) : ByteArray := (if first then (LexLeanRuntime.append (domain) (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))]) : ByteArray) else (LexLeanRuntime.append ((LexLeanRuntime.append (domain) (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1))]) : ByteArray)) (previous) : ByteArray))

@[expose] public def byteLengthBytes (count : UInt64) : ByteArray := (LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append ((LexLeanRuntime.append (_root_.ByteArray.mk #[]) (Uorc.Uorc.Integrity.Sha256.byteBytes (Uorc.Uorc.Integrity.Sha256.asByte64 ((match (LexLeanRuntime.shiftRight (count) ((56 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (Uorc.Uorc.Integrity.Sha256.byteBytes (Uorc.Uorc.Integrity.Sha256.asByte64 ((match (LexLeanRuntime.shiftRight (count) ((48 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (Uorc.Uorc.Integrity.Sha256.byteBytes (Uorc.Uorc.Integrity.Sha256.asByte64 ((match (LexLeanRuntime.shiftRight (count) ((40 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (Uorc.Uorc.Integrity.Sha256.byteBytes (Uorc.Uorc.Integrity.Sha256.asByte64 ((match (LexLeanRuntime.shiftRight (count) ((32 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (Uorc.Uorc.Integrity.Sha256.byteBytes (Uorc.Uorc.Integrity.Sha256.asByte64 ((match (LexLeanRuntime.shiftRight (count) ((24 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (Uorc.Uorc.Integrity.Sha256.byteBytes (Uorc.Uorc.Integrity.Sha256.asByte64 ((match (LexLeanRuntime.shiftRight (count) ((16 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (Uorc.Uorc.Integrity.Sha256.byteBytes (Uorc.Uorc.Integrity.Sha256.asByte64 ((match (LexLeanRuntime.shiftRight (count) ((8 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)) (Uorc.Uorc.Integrity.Sha256.byteBytes (Uorc.Uorc.Integrity.Sha256.asByte64 ((match (LexLeanRuntime.shiftRight (count) ((0 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some unwrapped => unwrapped)))) : ByteArray)

@[expose] public def footer (first : Bool) (count : UInt64) (terminal : Bool) : ByteArray := (LexLeanRuntime.append ((if terminal then _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 1))] else _root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))])) (byteLengthBytes (Uorc.Uorc.Integrity.Sha256.u64Sub (count) (prefixSize (first)))) : ByteArray)

@[expose] public def readyValid (limit : UInt64) (first : Bool) (hashState : Uorc.Uorc.Integrity.Sha256.State) : Bool := (Uorc.Uorc.Integrity.Sha256.valid (hashState) && (Uorc.Uorc.Integrity.Sha256.isAbsorbing (hashState) && ((match (LexLeanRuntime.checkedSubtract ((hashState).count) (prefixSize (first)) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && ((match (LexLeanRuntime.checkedSubtract (limit) ((hashState).count) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && true))))

@[expose] public def prefixValid (first : Bool) (job : Uorc.Uorc.Integrity.Sha256.Update) : Bool := (Uorc.Uorc.Integrity.Sha256.valid ((job).state) && (Uorc.Uorc.Integrity.Sha256.isAbsorbing ((job).state) && ((Nat.beq ((LexLeanRuntime.length ((job).input) : Nat)) ((if first then 27 else 59))) && ((Nat.ble ((job).offset) ((LexLeanRuntime.length ((job).input) : Nat))) && ((match (LexLeanRuntime.checkedSubtract (prefixSize (first)) (((job).state).count) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && ((Nat.beq (Uorc.Uorc.Integrity.Sha256.countRemainder (((job).state).count)) ((job).offset)) && true))))))

@[expose] public def suffixValid (limit : UInt64) (first : Bool) (job : Uorc.Uorc.Integrity.Sha256.Update) (terminal : Bool) (closing : Bool) : Bool := (Uorc.Uorc.Integrity.Sha256.valid ((job).state) && (Uorc.Uorc.Integrity.Sha256.isAbsorbing ((job).state) && ((Nat.beq ((LexLeanRuntime.length ((job).input) : Nat)) (9)) && ((Nat.ble ((job).offset) (9)) && ((match (LexLeanRuntime.checkedSubtract (((job).state).count) (prefixSize (first)) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && ((match (LexLeanRuntime.checkedSubtract (Uorc.Uorc.Integrity.Sha256.u64Add (limit) ((9 : UInt64))) (((job).state).count) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && ((if terminal then closing else true) && true)))))))

@[expose] public def finalizingValid (limit : UInt64) (first : Bool) (hashState : Uorc.Uorc.Integrity.Sha256.State) (terminal : Bool) (closing : Bool) : Bool := (Uorc.Uorc.Integrity.Sha256.valid (hashState) && ((match (LexLeanRuntime.checkedSubtract ((hashState).count) (Uorc.Uorc.Integrity.Sha256.u64Add (prefixSize (first)) ((9 : UInt64))) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && ((match (LexLeanRuntime.checkedSubtract (Uorc.Uorc.Integrity.Sha256.u64Add (limit) ((9 : UInt64))) ((hashState).count) : Option (UInt64)) with | Option.none => false | Option.some _ => true) && ((if terminal then closing else (LexLeanRuntime.equal ((hashState).count) (Uorc.Uorc.Integrity.Sha256.u64Add (limit) ((9 : UInt64))) : Bool)) && ((if Uorc.Uorc.Integrity.Sha256.isAbsorbing (hashState) then false else true) && true)))))

@[expose] public def validAt (limit : UInt64) (state : State) : Bool := (limitValid (limit) && (match (state).stage with | Stage.initializing job => prefixValid ((state).first) (job) | Stage.ready hashState => readyValid (limit) ((state).first) (hashState) | Stage.suffix job terminal => suffixValid (limit) ((state).first) (job) (terminal) ((state).closing) | Stage.finalizing hashState terminal => finalizingValid (limit) ((state).first) (hashState) (terminal) ((state).closing) | Stage.finished output => ((state).closing && (Nat.beq ((LexLeanRuntime.length (output) : Nat)) (32))) | Stage.canceled => (if (state).closing then false else true)))

@[expose] public def startPrefix (first : Bool) (previous : ByteArray) (closing : Bool) : Except (Error) (State) := (if (if first then true else (Nat.beq ((LexLeanRuntime.length (previous) : Nat)) (32))) then (match Uorc.Uorc.Integrity.Sha256.beginUpdate (Uorc.Uorc.Integrity.Sha256.init) («prefix» (first) (previous)) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok prefixJob => Except.ok (({ first := first, stage := Stage.initializing (prefixJob), closing := closing } : State))) else Except.error (Error.invalidState))

@[expose] public def initAt (limit : UInt64) : Except (Error) (State) := (if limitValid (limit) then startPrefix (true) (_root_.ByteArray.mk #[]) (false) else Except.error (Error.invalidFrameLimit))

@[expose] public def startSuffix (state : State) (hashState : Uorc.Uorc.Integrity.Sha256.State) (terminal : Bool) : Except (Error) (State) := (match Uorc.Uorc.Integrity.Sha256.beginUpdate (hashState) (footer ((state).first) ((hashState).count) (terminal)) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok suffixJob => Except.ok (({ first := (state).first, stage := Stage.suffix (suffixJob) (terminal), closing := (state).closing } : State)))

@[expose] public def stepAt (limit : UInt64) (state : State) : Except (Error) (State) := (if validAt (limit) (state) then (match (state).stage with | Stage.initializing job => (match Uorc.Uorc.Integrity.Sha256.updateStep (job) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok prefixEvent => (match prefixEvent with | Uorc.Uorc.Integrity.Sha256.UpdateEvent.advanced nextJob => Except.ok (({ first := (state).first, stage := Stage.initializing (nextJob), closing := (state).closing } : State)) | Uorc.Uorc.Integrity.Sha256.UpdateEvent.done hashState => Except.ok (({ first := (state).first, stage := Stage.ready (hashState), closing := (state).closing } : State)))) | Stage.ready hashState => (if Uorc.Uorc.Integrity.Sha256.hasWork (hashState) then (match Uorc.Uorc.Integrity.Sha256.advanceWork (hashState) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok nextHash => Except.ok (({ first := (state).first, stage := Stage.ready (nextHash), closing := (state).closing } : State))) else (if (LexLeanRuntime.equal ((hashState).count) (limit) : Bool) then startSuffix (state) (hashState) (false) else (if (state).closing then startSuffix (state) (hashState) (true) else Except.error (Error.workPending)))) | Stage.suffix job terminal => (match Uorc.Uorc.Integrity.Sha256.updateStep (job) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok suffixEvent => (match suffixEvent with | Uorc.Uorc.Integrity.Sha256.UpdateEvent.advanced nextJob => Except.ok (({ first := (state).first, stage := Stage.suffix (nextJob) (terminal), closing := (state).closing } : State)) | Uorc.Uorc.Integrity.Sha256.UpdateEvent.done hashState => (match Uorc.Uorc.Integrity.Sha256.finalize (hashState) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok closingHash => Except.ok (({ first := (state).first, stage := Stage.finalizing (closingHash) (terminal), closing := (state).closing } : State))))) | Stage.finalizing hashState terminal => (match (hashState).phase with | Uorc.Uorc.Integrity.Sha256.Phase.absorbing => Except.error (Error.invalidState) | Uorc.Uorc.Integrity.Sha256.Phase.finishing _ => (match Uorc.Uorc.Integrity.Sha256.finalizeStep (hashState) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok nextHash => Except.ok (({ first := (state).first, stage := Stage.finalizing (nextHash) (terminal), closing := (state).closing } : State))) | Uorc.Uorc.Integrity.Sha256.Phase.finished => (match Uorc.Uorc.Integrity.Sha256.digest (hashState) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok output => (if terminal then Except.ok (({ first := (state).first, stage := Stage.finished (output), closing := (state).closing } : State)) else startPrefix (false) (output) ((state).closing)))) | Stage.finished _ => Except.ok (state) | Stage.canceled => Except.error (Error.canceled)) else Except.error (Error.invalidState))

@[expose] public def finalizeAt (limit : UInt64) (state : State) : Except (Error) (State) := (if validAt (limit) (state) then (match (state).stage with | Stage.canceled => Except.error (Error.canceled) | Stage.finished _ => Except.ok (state) | Stage.initializing _ => Except.ok (({ first := (state).first, stage := (state).stage, closing := true } : State)) | Stage.ready _ => Except.ok (({ first := (state).first, stage := (state).stage, closing := true } : State)) | Stage.suffix _ _ => (if (state).closing then Except.ok (state) else Except.error (Error.workPending)) | Stage.finalizing _ _ => (if (state).closing then Except.ok (state) else Except.error (Error.workPending))) else Except.error (Error.invalidState))

@[expose] public def digestAt (limit : UInt64) (state : State) : Except (Error) (ByteArray) := (if validAt (limit) (state) then (match (state).stage with | Stage.finished output => Except.ok (output) | Stage.canceled => Except.error (Error.canceled) | Stage.initializing _ => Except.error (Error.notFinalized) | Stage.ready _ => Except.error (Error.notFinalized) | Stage.suffix _ _ => Except.error (Error.notFinalized) | Stage.finalizing _ _ => Except.error (Error.notFinalized)) else Except.error (Error.invalidState))

@[expose] public def cancel (_state : State) : State := ({ first := true, stage := Stage.canceled, closing := false } : State)

@[expose] public def beginUpdateAt (limit : UInt64) (state : State) (input : ByteArray) : Except (Error) (Update) := (if validAt (limit) (state) then (match (state).stage with | Stage.canceled => Except.error (Error.canceled) | Stage.finished _ => Except.error (Error.updateAfterFinalize) | Stage.initializing _ => (if (state).closing then Except.error (Error.updateAfterFinalize) else Except.ok (({ state := state, input := input, offset := 0 } : Update))) | Stage.ready _ => (if (state).closing then Except.error (Error.updateAfterFinalize) else Except.ok (({ state := state, input := input, offset := 0 } : Update))) | Stage.suffix _ _ => Except.error (Error.workPending) | Stage.finalizing _ _ => Except.error (Error.workPending)) else Except.error (Error.invalidState))

@[expose] public def updateStepAt (limit : UInt64) (job : Update) : Except (Error) (UpdateEvent) := (if validAt (limit) ((job).state) then (if (Nat.ble ((job).offset) ((LexLeanRuntime.length ((job).input) : Nat))) then (match ((job).state).stage with | Stage.canceled => Except.error (Error.canceled) | Stage.finished _ => Except.error (Error.updateAfterFinalize) | Stage.initializing _ => (if ((job).state).closing then Except.error (Error.updateAfterFinalize) else (match stepAt (limit) ((job).state) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (job).input, offset := (job).offset } : Update))))) | Stage.ready hashState => (if ((job).state).closing then Except.error (Error.updateAfterFinalize) else (if Uorc.Uorc.Integrity.Sha256.hasWork (hashState) then (match stepAt (limit) ((job).state) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (job).input, offset := (job).offset } : Update)))) else (if (LexLeanRuntime.equal ((hashState).count) (limit) : Bool) then (match stepAt (limit) ((job).state) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (job).input, offset := (job).offset } : Update)))) else (if (Nat.beq ((job).offset) ((LexLeanRuntime.length ((job).input) : Nat))) then Except.ok (UpdateEvent.done ((job).state)) else (match Uorc.Uorc.Integrity.Sha256.absorbByte (hashState) ((match (LexLeanRuntime.index ((job).input) ((job).offset) : Option (UInt8)) with | Option.none => (0 : UInt8) | Option.some unwrapped => unwrapped)) with | Except.error shaCause => Except.error (Error.sha256 (shaCause)) | Except.ok nextHash => Except.ok (UpdateEvent.advanced (({ state := ({ first := ((job).state).first, stage := Stage.ready (nextHash), closing := ((job).state).closing } : State), input := (job).input, offset := ((job).offset + 1) } : Update)))))))) | Stage.suffix _ _ => (if ((job).state).closing then Except.error (Error.updateAfterFinalize) else (match stepAt (limit) ((job).state) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (job).input, offset := (job).offset } : Update))))) | Stage.finalizing _ _ => (if ((job).state).closing then Except.error (Error.updateAfterFinalize) else (match stepAt (limit) ((job).state) with | Except.error failure => Except.error (failure) | Except.ok nextState => Except.ok (UpdateEvent.advanced (({ state := nextState, input := (job).input, offset := (job).offset } : Update)))))) else Except.error (Error.invalidOffset)) else Except.error (Error.invalidState))

@[expose] public def runUpdateAt : (fuel : Nat) -> (limit : UInt64) -> (job : Update) -> Except (Error) (State)
  | Nat.zero, _limit, _job => Except.error (Error.fuelExhausted)
  | Nat.succ rest, limit, job => (match updateStepAt (limit) (job) with | Except.error failure => Except.error (failure) | Except.ok updateEvent => (match updateEvent with | UpdateEvent.advanced nextJob => runUpdateAt (rest) (limit) (nextJob) | UpdateEvent.done completed => Except.ok (completed)))

@[expose] public def updateAt (limit : UInt64) (state : State) (input : ByteArray) : Except (Error) (State) := (match beginUpdateAt (limit) (state) (input) with | Except.error failure => Except.error (failure) | Except.ok updateJob => runUpdateAt (((LexLeanRuntime.multiply (600) ((LexLeanRuntime.length (input) : Nat)) : Nat) + 600)) (limit) (updateJob))

@[expose] public def runFinalizeAt : (fuel : Nat) -> (limit : UInt64) -> (state : State) -> Except (Error) (ByteArray)
  | Nat.zero, _limit, _state => Except.error (Error.fuelExhausted)
  | Nat.succ rest, limit, state => (match (state).stage with | Stage.finished output => (if validAt (limit) (state) then Except.ok (output) else Except.error (Error.invalidState)) | Stage.canceled => Except.error (Error.canceled) | Stage.initializing _ => (match stepAt (limit) (state) with | Except.error failure => Except.error (failure) | Except.ok nextState => runFinalizeAt (rest) (limit) (nextState)) | Stage.ready _ => (if (state).closing then (match stepAt (limit) (state) with | Except.error failure => Except.error (failure) | Except.ok nextState => runFinalizeAt (rest) (limit) (nextState)) else Except.error (Error.notFinalized)) | Stage.suffix _ _ => (match stepAt (limit) (state) with | Except.error failure => Except.error (failure) | Except.ok nextState => runFinalizeAt (rest) (limit) (nextState)) | Stage.finalizing _ _ => (match stepAt (limit) (state) with | Except.error failure => Except.error (failure) | Except.ok nextState => runFinalizeAt (rest) (limit) (nextState)))

@[expose] public def hashAt (limit : UInt64) (input : ByteArray) : Except (Error) (ByteArray) := (match initAt (limit) with | Except.error failure => Except.error (failure) | Except.ok initial => (match updateAt (limit) (initial) (input) with | Except.error failure => Except.error (failure) | Except.ok updated => (match finalizeAt (limit) (updated) with | Except.error failure => Except.error (failure) | Except.ok closingState => runFinalizeAt (1200) (limit) (closingState))))

@[expose] public def feedForwardPending (hashState : Uorc.Uorc.Integrity.Sha256.State) : Bool := (match (hashState).work with | Option.none => false | Option.some compression => (Nat.beq ((compression).round) (64)))

@[expose] public def compressionPending (state : State) : Bool := (match (state).stage with | Stage.initializing job => feedForwardPending ((job).state) | Stage.ready hashState => feedForwardPending (hashState) | Stage.suffix job _ => feedForwardPending ((job).state) | Stage.finalizing hashState _ => feedForwardPending (hashState) | Stage.finished _ => false | Stage.canceled => false)

public theorem production_limit_exact : (productionLimit = (2305843009213693942 : UInt64)) := by
  rfl

public theorem domain_26_bytes : ((LexLeanRuntime.length (domain) : Nat) = 26) := by
  rfl

public theorem first_prefix_27_bytes : ((LexLeanRuntime.length («prefix» (true) (_root_.ByteArray.mk #[])) : Nat) = 27) := by
  rfl

public theorem continuation_prefix_59_bytes : ((LexLeanRuntime.length («prefix» (false) ((let __byte0 : _root_.UInt8 := _root_.UInt8.ofNat (nat_lit 0); _root_.ByteArray.mk #[__byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0, __byte0]))) : Nat) = 59) := by
  rfl

public theorem cancellation_is_idempotent (arbitraryState : State) : (cancel (cancel (arbitraryState)) = cancel (arbitraryState)) := by
  rfl

public theorem cancellation_has_no_retained_work (arbitraryState : State) : ((cancel (arbitraryState)).stage = Stage.canceled) := by
  rfl

@[expose] public def standardDomainBytes : Nat := 2305843009213693951

@[expose] public def firstCapacityBytes : Nat := 2305843009213693915

@[expose] public def continuationCapacityBytes : Nat := 2305843009213693883

public theorem first_full_frame_standard_bound : ((firstCapacityBytes + 36) = standardDomainBytes) := by
  rfl

public theorem continuation_full_frame_standard_bound : ((continuationCapacityBytes + 68) = standardDomainBytes) := by
  rfl

@[expose] public def framedSize (payloadBytes : Nat) (prefixBytes : Nat) : Nat := ((payloadBytes + prefixBytes) + 9)

public theorem first_frame_size_for_every_payload (payloadBytes : Nat) : (framedSize (payloadBytes) (27) = (payloadBytes + 36)) := by
  rfl

public theorem continuation_frame_size_for_every_payload (payloadBytes : Nat) : (framedSize (payloadBytes) (59) = (payloadBytes + 68)) := by
  rfl

public theorem ready_count_reflection : (forall (p : Bool), (forall (q : Bool), (forall (r : Bool), (forall (s : Bool), (forall (t : Bool), ((((p && (q && (r && (s && (t && true))))) = true) /\ (t = true)) <-> ((p && (q && (r && (s && (t && true))))) = true))))))) := by
  decide

public theorem finalizing_count_reflection : (forall (p : Bool), (forall (q : Bool), (forall (r : Bool), (forall (s : Bool), (forall (t : Bool), (forall (u : Bool), ((((p && (q && (r && (s && (t && (u && true)))))) = true) /\ (s = true)) <-> ((p && (q && (r && (s && (t && (u && true)))))) = true)))))))) := by
  decide

public theorem ready_validation_contains_count_bound (limit : UInt64) (first : Bool) (hashState : Uorc.Uorc.Integrity.Sha256.State) (closing : Bool) : (((validAt (limit) (({ first := first, stage := Stage.ready (hashState), closing := closing } : State)) = true) /\ ((match (LexLeanRuntime.checkedSubtract (limit) ((hashState).count) : Option (UInt64)) with | Option.none => false | Option.some _ => true) = true)) <-> (validAt (limit) (({ first := first, stage := Stage.ready (hashState), closing := closing } : State)) = true)) := by
  simp only [readyValid, ready_count_reflection, validAt]

public theorem finalizing_validation_contains_count_bound (limit : UInt64) (first : Bool) (hashState : Uorc.Uorc.Integrity.Sha256.State) (closing : Bool) (terminal : Bool) : (((validAt (limit) (({ first := first, stage := Stage.finalizing (hashState) (terminal), closing := closing } : State)) = true) /\ ((match (LexLeanRuntime.checkedSubtract (Uorc.Uorc.Integrity.Sha256.u64Add (limit) ((9 : UInt64))) ((hashState).count) : Option (UInt64)) with | Option.none => false | Option.some _ => true) = true)) <-> (validAt (limit) (({ first := first, stage := Stage.finalizing (hashState) (terminal), closing := closing } : State)) = true)) := by
  simp only [finalizingValid, finalizing_count_reflection, validAt]

end Uorc.Uorc.Integrity.StreamEngine
