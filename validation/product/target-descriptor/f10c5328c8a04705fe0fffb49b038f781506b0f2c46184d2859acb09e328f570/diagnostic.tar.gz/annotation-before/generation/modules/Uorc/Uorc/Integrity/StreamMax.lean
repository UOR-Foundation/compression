module
public import Init
public import Uorc.Uorc.Integrity.StreamEngine
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Integrity.StreamMax

public structure State where
  engine : Uorc.Uorc.Integrity.StreamEngine.State

public structure Update where
  engine : Uorc.Uorc.Integrity.StreamEngine.Update

public inductive UpdateEvent where
  | advanced (_ : Update)
  | done (_ : State)

@[expose] public def init : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (State) := (match Uorc.Uorc.Integrity.StreamEngine.initAt (Uorc.Uorc.Integrity.StreamEngine.productionLimit) with | Except.error engineCause => Except.error (engineCause) | Except.ok initialEngine => Except.ok (({ engine := initialEngine } : State)))

@[expose] public def step (state : State) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (State) := (match Uorc.Uorc.Integrity.StreamEngine.stepAt (Uorc.Uorc.Integrity.StreamEngine.productionLimit) ((state).engine) with | Except.error engineCause => Except.error (engineCause) | Except.ok nextEngine => Except.ok (({ engine := nextEngine } : State)))

@[expose] public def finalize (state : State) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (State) := (match Uorc.Uorc.Integrity.StreamEngine.finalizeAt (Uorc.Uorc.Integrity.StreamEngine.productionLimit) ((state).engine) with | Except.error engineCause => Except.error (engineCause) | Except.ok nextEngine => Except.ok (({ engine := nextEngine } : State)))

@[expose] public def finalizeStep (state : State) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (State) := step (state)

@[expose] public def digest (state : State) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (ByteArray) := Uorc.Uorc.Integrity.StreamEngine.digestAt (Uorc.Uorc.Integrity.StreamEngine.productionLimit) ((state).engine)

@[expose] public def cancel (state : State) : State := ({ engine := Uorc.Uorc.Integrity.StreamEngine.cancel ((state).engine) } : State)

@[expose] public def cancelUpdate (job : Update) : State := ({ engine := Uorc.Uorc.Integrity.StreamEngine.cancel (((job).engine).state) } : State)

@[expose] public def beginUpdate (state : State) (input : ByteArray) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (Update) := (match Uorc.Uorc.Integrity.StreamEngine.beginUpdateAt (Uorc.Uorc.Integrity.StreamEngine.productionLimit) ((state).engine) (input) with | Except.error engineCause => Except.error (engineCause) | Except.ok nextEngine => Except.ok (({ engine := nextEngine } : Update)))

@[expose] public def updateStep (job : Update) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (UpdateEvent) := (match Uorc.Uorc.Integrity.StreamEngine.updateStepAt (Uorc.Uorc.Integrity.StreamEngine.productionLimit) ((job).engine) with | Except.error engineCause => Except.error (engineCause) | Except.ok engineEvent => (match engineEvent with | Uorc.Uorc.Integrity.StreamEngine.UpdateEvent.advanced nextEngine => Except.ok (UpdateEvent.advanced (({ engine := nextEngine } : Update))) | Uorc.Uorc.Integrity.StreamEngine.UpdateEvent.done nextEngine => Except.ok (UpdateEvent.done (({ engine := nextEngine } : State)))))

@[expose] public def update (state : State) (input : ByteArray) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (State) := (match Uorc.Uorc.Integrity.StreamEngine.updateAt (Uorc.Uorc.Integrity.StreamEngine.productionLimit) ((state).engine) (input) with | Except.error engineCause => Except.error (engineCause) | Except.ok nextEngine => Except.ok (({ engine := nextEngine } : State)))

@[expose] public def runFinalize (fuel : Nat) (state : State) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (ByteArray) := Uorc.Uorc.Integrity.StreamEngine.runFinalizeAt (fuel) (Uorc.Uorc.Integrity.StreamEngine.productionLimit) ((state).engine)

@[expose] public def hash (input : ByteArray) : Except (Uorc.Uorc.Integrity.StreamEngine.Error) (ByteArray) := Uorc.Uorc.Integrity.StreamEngine.hashAt (Uorc.Uorc.Integrity.StreamEngine.productionLimit) (input)

@[expose] public def compressionPending (state : State) : Bool := Uorc.Uorc.Integrity.StreamEngine.compressionPending ((state).engine)

@[expose] public def updateCompressionPending (job : Update) : Bool := Uorc.Uorc.Integrity.StreamEngine.compressionPending (((job).engine).state)

end Uorc.Uorc.Integrity.StreamMax
