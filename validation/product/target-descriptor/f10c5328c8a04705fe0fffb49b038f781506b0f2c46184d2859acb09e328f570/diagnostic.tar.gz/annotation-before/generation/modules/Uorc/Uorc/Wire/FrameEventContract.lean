module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeMetadata
public import Uorc.Uorc.Core.RuntimeProgram
public import Uorc.Uorc.Core.RuntimeTable
public import Uorc.Uorc.Core.RuntimeValue
public import Uorc.Uorc.Integrity.Profile
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Wire.FrameEventContract

public inductive FormatDisposition where
  | diagnosticReference
  | awaitingIntegrityBinding
  | unsupported
  | selected (_ : Uorc.Uorc.Integrity.Profile.Kind)

public inductive Representation where
  | raw
  | program

public inductive Scope where
  | selfContained
  | conditional

public inductive Event where
  | beginArchive (_ : UInt8) (_ : UInt8) (_ : Scope) (_ : Representation)
  | beginObjects (_ : UInt64)
  | objectLength (_ : UInt64) (_ : UInt64)
  | beginBody (_ : UInt64)
  | basisIdentitySpan (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : UInt64) (_ : UInt64)
  | bodySpan (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : UInt64) (_ : UInt64)
  | integritySpan (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : UInt64) (_ : UInt64)
  | endArchive

public structure OwnedLengths where
  table : Uorc.Uorc.Core.RuntimeTable.Table
  count : UInt64
  totalOutputBytes : UInt64

public structure ObjectCursor where
  lengths : OwnedLengths
  index : UInt64
  offset : UInt64
  remaining : UInt64
  opened : Bool

public inductive ObjectEvent where
  | beginObject (_ : UInt64) (_ : UInt64)
  | bytes (_ : UInt64) (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : UInt64) (_ : UInt64)
  | endObject (_ : UInt64)
  | «seal» (_ : UInt64)

public inductive Failure where
  | unsupportedFormat
  | integrityBindingUnavailable
  | invalidHeaderOrder
  | lengthIndexMismatch
  | lengthCountMismatch
  | outputLengthOverflow
  | bodyLengthMismatch
  | unexpectedEOF
  | duplicateEOF
  | trailingBytes
  | cancelled
  | ticketNotTransferred
  | addressSpaceExhausted

@[expose] public def diagnosticFormat : UInt8 := (2 : UInt8)

@[expose] public def streamingFormat : UInt8 := (3 : UInt8)

@[expose] public def machineProfile : UInt8 := (1 : UInt8)

@[expose] public def dispatch (format : UInt8) : FormatDisposition := (match Uorc.Uorc.Integrity.Profile.select ((let __widen0 : UInt8 := format; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen0) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) ((let __widen1 : UInt8 := machineProfile; ((((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((128 : UInt8)) : UInt8)) ((128 : UInt8)) : Bool) then 128 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((64 : UInt8)) : UInt8)) ((64 : UInt8)) : Bool) then 64 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((32 : UInt8)) : UInt8)) ((32 : UInt8)) : Bool) then 32 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((16 : UInt8)) : UInt8)) ((16 : UInt8)) : Bool) then 16 else 0))) + (((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((8 : UInt8)) : UInt8)) ((8 : UInt8)) : Bool) then 8 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((4 : UInt8)) : UInt8)) ((4 : UInt8)) : Bool) then 4 else 0)) + ((if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((2 : UInt8)) : UInt8)) ((2 : UInt8)) : Bool) then 2 else 0) + (if (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (__widen1) ((1 : UInt8)) : UInt8)) ((1 : UInt8)) : Bool) then 1 else 0)))))) with | Except.error _ => FormatDisposition.unsupported | Except.ok kindLocal2 => FormatDisposition.selected (kindLocal2))

@[expose] public def lengthsMetadataKind : UInt64 := (1464422981 : UInt64)

@[expose] public def protocol : String := "ArchiveParse is the bounded production frame syntax owner; FrameParse remains the independent format2 diagnostic reference. Profile.select is the sole format/machine integrity authority. dispatch returns selected(Profile.Kind) data for implemented format2/CHAIN and format3/STREAM-MAX, never an archive-acceptance token. Exact EOF, source-owned integrity, admission, execution and ordered reconstruction remain separate checks. Each objectLength requires an acknowledged actual charged indexed write, including zeros; OwnedLengths never stores a length List. Operational U64 refusal does not narrow finite mathematical archives."

@[expose] public def ownership : String := "All span events refer to charged immutable image handles with checked offset/length. Each pending span owns a retained ticket before exposure; acknowledgement moves that ticket to its next owner, or the recipient first retains a charged edge before the sender releases its ticket. ProgramParse.feed returns with a charged wire owner edge before the frame owner may acknowledge and release its span ticket. Cleanup retains sender ownership after cancellation/failure. No feed is inferred from a pure immutable state replacement. A bounded driver owns the frame, program, admission and integrity sessions and all pending tickets, carries their exact arenas/usages across work pauses, and never releases a ticket still referenced by another stage. The frame body length gates the program parser stream: program EOF occurs exactly at the body boundary and cannot consume integrity bytes. The parser seal remains provisional until admission, integrity, execution and ordered-object verification finish."

@[expose] public def objects : String := "ObjectCursor reads each next length by index from the charged OwnedLengths table through the runtime owner; no new table cursor is implemented here. Emit beginObject(index,length), exactly length bytes in retained span events, then endObject(index), including distinct begin/end events for every empty object. Advance the index only after acknowledgement of endObject. A source-free demultiplexer cannot replace the table with an uncharged List Nat. EOF after precisely count objects permits ObjectEvent.seal; premature/trailing bytes and index/count/aggregate mismatches are retained typed failures. Every emitted boundary, lookup, span handoff and failed/pending prefix is prepaid; cleanup roots and achieved usage survive cancellation and budget pauses."

@[expose] public def lengthAt (arena : Uorc.Uorc.Core.Heap.Arena) (table : Uorc.Uorc.Core.RuntimeTable.Table) (index : UInt64) : Except (Uorc.Uorc.Core.RuntimeProgram.Failure) (UInt64) := (match (table).kind with | Uorc.Uorc.Core.RuntimeTable.TableKind.slots roleLocal3 => (if (LexLeanRuntime.equal (Uorc.Uorc.Core.RuntimeValue.roleTag (roleLocal3)) (Uorc.Uorc.Core.RuntimeValue.roleTag (Uorc.Uorc.Core.RuntimeValue.RootRole.wire)) : Bool) then Uorc.Uorc.Core.RuntimeProgram.referenceAt (arena) (table) (index) else Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.metadata (Uorc.Uorc.Core.RuntimeMetadata.Error.invalidRecord))) | Uorc.Uorc.Core.RuntimeTable.TableKind.metadata kindLocal4 => (if (LexLeanRuntime.equal (kindLocal4) (lengthsMetadataKind) : Bool) then (match Uorc.Uorc.Core.RuntimeProgram.indexTarget (arena) (table) (lengthsMetadataKind) (index) with | Except.error causeLocal5 => Except.error (causeLocal5) | Except.ok recordLocal6 => (match Uorc.Uorc.Core.RuntimeMetadata.wordAt (arena) (recordLocal6) (lengthsMetadataKind) ((0 : UInt64)) with | Except.error causeLocal7 => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.metadata (causeLocal7)) | Except.ok lengthLocal8 => Except.ok (lengthLocal8))) else Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.metadata (Uorc.Uorc.Core.RuntimeMetadata.Error.invalidRecord))))

@[expose] public def emptyLengthsTable : Uorc.Uorc.Core.RuntimeTable.Table := ({ kind := Uorc.Uorc.Core.RuntimeTable.TableKind.slots (Uorc.Uorc.Core.RuntimeValue.RootRole.wire), root := Uorc.Uorc.Core.RuntimeValue.nullHandle } : Uorc.Uorc.Core.RuntimeTable.Table)

@[expose] public def lengthCarrierContract : String := "OwnedLengths uses an explicitly tagged RuntimeTable. The production LengthStore writes TableKind.slots(wire) with natural-value leaves through the Core reserved cursor. lengthAt also reads the earlier TableKind.metadata(lengthsMetadataKind) carrier with indexed links to canonical word-at-key0 records. This is declared internal metadata representation dispatch, not a wire parser fallback; both emit the same ordered shortest-natural lengths, including zeros. No writer/traversal is duplicated from Core and no uncharged metadata WriteCursor List is retained by the wire length store."

end Uorc.Uorc.Wire.FrameEventContract
