import Uorc.Uorc.Product.OutputDeliveryScenarios
open Uorc.Uorc.Product

def main : IO Unit := do
 let mut passed : Nat := 0
 let mut total : Nat := 0
 let mut names : List String := []
 for observation in OutputDeliveryScenarios.observations do
  if names.contains observation.id then throw (IO.userError "duplicate observation")
  names := observation.id :: names
  total := total + 1
  if observation.passed then passed := passed + 1 else IO.println s!"FAIL {observation.id}"
 IO.println s!"{passed}/{total} actual output delivery reporting controls passed"
 if total == 0 || passed != total then throw (IO.userError "output delivery controls failed")
