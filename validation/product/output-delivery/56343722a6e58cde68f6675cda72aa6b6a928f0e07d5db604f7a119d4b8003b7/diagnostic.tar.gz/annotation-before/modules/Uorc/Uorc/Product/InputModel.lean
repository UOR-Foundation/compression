module
public import Init
public import Uorc.Uorc.Product.Api
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Product.InputModel

public structure State where
  nextObject : Nat
  inObject : Bool
  ended : Bool
  totalBytes : Nat

public inductive Piece where
  | beginObject (_ : Nat)
  | chunk (_ : Uorc.Uorc.Product.Api.Span)
  | endObject (_ : Nat)
  | endInput

public inductive Error where
  | afterEnd
  | objectAlreadyOpen
  | noObject
  | wrongObject
  | objectStillOpen

@[expose] public def initial : State := ({ nextObject := 0, inObject := false, ended := false, totalBytes := 0 } : State)

@[expose] public def accept (s : State) (piece : Piece) : Except (Error) (State) := (if (s).ended then Except.error (Error.afterEnd) else (match piece with | Piece.beginObject index => (if (s).inObject then Except.error (Error.objectAlreadyOpen) else (if (Nat.beq (index) ((s).nextObject)) then Except.ok (({ nextObject := (s).nextObject, inObject := true, ended := (s).ended, totalBytes := (s).totalBytes } : State)) else Except.error (Error.wrongObject))) | Piece.chunk span => (if (s).inObject then Except.ok (({ nextObject := (s).nextObject, inObject := (s).inObject, ended := (s).ended, totalBytes := ((s).totalBytes + (span).length) } : State)) else Except.error (Error.noObject)) | Piece.endObject index => (if (s).inObject then (if (Nat.beq (index) ((s).nextObject)) then Except.ok (({ nextObject := ((s).nextObject + 1), inObject := false, ended := (s).ended, totalBytes := (s).totalBytes } : State)) else Except.error (Error.wrongObject)) else Except.error (Error.noObject)) | Piece.endInput => (if (s).inObject then Except.error (Error.objectStillOpen) else Except.ok (({ nextObject := (s).nextObject, inObject := (s).inObject, ended := true, totalBytes := (s).totalBytes } : State)))))

@[expose] public def boundary : String := "The adapter validates each charged span against the resource instance and backing extent before admission. InputModel checks ordered object boundaries, including empties, and explicit end-of-input. Lengths and identities are control metadata and do not prove any byte equality. No aggregate input-size or media-type limit is imposed here."

end Uorc.Uorc.Product.InputModel
