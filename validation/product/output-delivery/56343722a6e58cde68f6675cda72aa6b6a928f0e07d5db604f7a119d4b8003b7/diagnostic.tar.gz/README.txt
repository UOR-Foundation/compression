output-delivery frozen diagnostic checkpoint

Extract project inputs under project/, exact generated Lean under generation/modules/, and the three official SDK runtime modules under sdk-runtime/modules/. The actual VM harness and axiom query script are under runtime/. Results and five owning mutants are retained.

Use a matching LexLean/Lean toolchain from toolchain/identity.json. This archive does not ship tool binaries or claim pinned-SDK/native/Wasm/closed-archive acceptance. No qualification was rerun while packaging. Before-annotation inputs are accompanied by every prior generated Lean module to inspect byte equality.

Build 56343722a6e58cde68f6675cda72aa6b6a928f0e07d5db604f7a119d4b8003b7
Source a9ac2f995c506a3de3cd3207de3a6d5cac5320b646e3fb5277ce327c38c01675
Semantic 6674ea92b4e518c2be4965202e654f806a1f82635d7678c898ff343a0c9f704b

The embedded build manifests may inventory compiler outputs beyond the Lean subset archived here; they are provenance records, not accepted-export receipts.
