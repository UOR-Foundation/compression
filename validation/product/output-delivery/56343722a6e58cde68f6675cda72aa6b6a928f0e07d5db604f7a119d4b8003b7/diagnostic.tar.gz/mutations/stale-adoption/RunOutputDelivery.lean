import Uorc.Uorc.Product.OutputDeliveryScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !OutputDeliveryScenarios.staleSettlementRetainsActualOwnerControl then throw (IO.userError "FAIL staleSettlementRetainsActualOwnerControl")
 IO.println "PASS staleSettlementRetainsActualOwnerControl"
