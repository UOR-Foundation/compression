import Uorc.Uorc.Product.OutputDeliveryScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !OutputDeliveryScenarios.checkedWorkAdditionControl then throw (IO.userError "FAIL checkedWorkAdditionControl")
 IO.println "PASS checkedWorkAdditionControl"
