import Uorc.Uorc.Product.OutputDeliveryScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !OutputDeliveryScenarios.successfulSettlementIsNotArchiveProofControl then throw (IO.userError "FAIL successfulSettlementIsNotArchiveProofControl")
 IO.println "PASS successfulSettlementIsNotArchiveProofControl"
