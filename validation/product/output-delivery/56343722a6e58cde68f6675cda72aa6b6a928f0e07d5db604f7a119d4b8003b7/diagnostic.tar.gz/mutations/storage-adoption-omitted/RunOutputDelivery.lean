import Uorc.Uorc.Product.OutputDeliveryScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !OutputDeliveryScenarios.liveStorageAdoptedControl then throw (IO.userError "FAIL liveStorageAdoptedControl")
 IO.println "PASS liveStorageAdoptedControl"
