import Uorc.Uorc.Product.OutputDeliveryScenarios
open Uorc.Uorc.Product
def main : IO Unit := do
 if !OutputDeliveryScenarios.failureDoesNotInventNotPublishedControl then throw (IO.userError "FAIL failureDoesNotInventNotPublishedControl")
 IO.println "PASS failureDoesNotInventNotPublishedControl"
