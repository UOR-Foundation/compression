#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt2, u64, Adt5, Adt6, Adt11, Option<Adt16>, Adt19, Option<Adt2>, bool, bool),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt3, Option<u64>, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt7, Option<Adt9>),
}

#[derive(Clone)]
pub enum Adt7 {
    C0(Adt8, Adt8, u64, u64),
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(u64, u64, u64),
    C1(Adt10, u64, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64, u64),
}

#[derive(Clone)]
pub enum Adt10 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt11 {
    C0(Adt1, Adt2, u64, u64, u64, Adt12, Option<Adt13>, Option<Adt14>, bool, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt12 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt13 {
    C0(Adt1, Adt3, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Adt3, u64, u64),
}

#[derive(Clone)]
pub enum Adt15 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt1, Adt3, Adt10, Adt5, Adt6, u64, u64, Adt17, Option<Adt18>, Option<Adt14>, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt17 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt1, Adt3, u64, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt19 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt1, Adt3, u64, u64, Option<Adt14>, bool, bool),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt0, List<Adt22>),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt1),
    C1(Adt13),
    C2(Adt18),
    C3(Adt3, u64),
    C4(Adt3),
    C5(Adt1),
    C6(Adt1, Adt3, u64),
    C7(Adt13),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(Adt11, Option<Adt13>, Option<Adt3>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(Adt16, Option<Adt18>, Option<Adt3>),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(Adt10, u64),
    C1(Adt10, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64),
    C4(Adt10, u64),
}

pub fn f0(v0: Adt0, v1: Adt20) -> R<Adt21> {
    Ok(Adt21::C0({
        let m3 = f1(v0.clone(), f2(match v0.clone() {
            Adt0::C0(_, _, _, _, _, h2, _, _, _, _, _) => {
                h2
            }
        }, v1.clone())?)?;
        match m3 {
            Adt21::C0(h1, _) => {
                h1
            }
        }
    }, f3({
        let m7 = {
            let m6 = f2(match v0.clone() {
                Adt0::C0(_, _, _, _, _, h5, _, _, _, _, _) => {
                    h5
                }
            }, v1.clone())?;
            match m6 {
                Adt23::C0(_, _, h4) => {
                    h4
                }
            }
        };
        match m7 {
            None => {
                List::<Adt22>::nil()
            }
            Some(v2) => {
                List::cons(Adt22::C4(v2), List::<Adt22>::nil())
            }
        }
    }, {
        let m10 = f1(v0.clone(), f2(match v0 {
            Adt0::C0(_, _, _, _, _, h9, _, _, _, _, _) => {
                h9
            }
        }, v1)?)?;
        match m10 {
            Adt21::C0(_, h8) => {
                h8
            }
        }
    })))
}

pub fn f1(v0: Adt0, v1: Adt23) -> R<Adt21> {
    let m12 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, h11, _, _, _) => {
            h11
        }
    };
    match m12 {
        Adt19::C0 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C1 => {
            let m14 = match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h13, _, _, _, _) => {
                    h13
                }
            };
            match m14 {
                None => {
                    Ok(Adt21::C0(v0, List::<Adt22>::nil()))
                }
                Some(v2) => {
                    f4(v0, v2, v1)
                }
            }
        }
        Adt19::C2 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C3 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C4 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C5 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C6 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C7 => {
            Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h15, _, _, _, _, _, _, _, _, _, _) => {
                    h15
                }
            }, match v0.clone() {
                Adt0::C0(_, h16, _, _, _, _, _, _, _, _, _) => {
                    h16
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h17, _, _, _, _, _, _, _, _) => {
                    h17
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h18, _, _, _, _, _, _, _) => {
                    h18
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h19, _, _, _, _, _, _) => {
                    h19
                }
            }, match v1 {
                Adt23::C0(h20, _, _) => {
                    h20
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h21, _, _, _, _) => {
                    h21
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, h22, _, _, _) => {
                    h22
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h23, _, _) => {
                    h23
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h24, _) => {
                    h24
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h25) => {
                    h25
                }
            }), List::<Adt22>::nil()))
        }
        Adt19::C8 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
    }
}

pub fn f2(v0: Adt11, v1: Adt20) -> R<Adt23> {
    let m27 = match v0.clone() {
        Adt11::C0(_, _, _, _, _, h26, _, _, _, _) => {
            h26
        }
    };
    match m27 {
        Adt12::C0 => {
            if f5(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt20::C0(_, _, _, _, _, _, h28) => {
                        h28
                    }
                } {
                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                        Adt11::C0(h29, _, _, _, _, _, _, _, _, _) => {
                            h29
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, h30, _, _, _, _, _, _, _, _) => {
                            h30
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, h31, _, _, _, _, _, _, _) => {
                            h31
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, h32, _, _, _, _, _, _) => {
                            h32
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, _, h33, _, _, _, _, _) => {
                            h33
                        }
                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                        Adt11::C0(_, _, _, _, _, _, _, _, h34, _) => {
                            h34
                        }
                    }, Some(Adt15::C7)), None::<Adt13>, f6(v0, v1)))
                } else {
                    let a45 = {
                        let m36 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h35, _, _) => {
                                h35
                            }
                        };
                        match m36 {
                            None => {
                                true
                            }
                            Some(v2) => {
                                let a43 = {
                                    let m39 = match v2 {
                                        Adt14::C0(h38, _, _) => {
                                            h38
                                        }
                                    };
                                    match m39 {
                                        Adt3::C0(h37, _, _) => {
                                            h37
                                        }
                                    }
                                };
                                let a44 = {
                                    let m42 = match v0.clone() {
                                        Adt11::C0(h41, _, _, _, _, _, _, _, _, _) => {
                                            h41
                                        }
                                    };
                                    match m42 {
                                        Adt1::C0(h40, _, _) => {
                                            h40
                                        }
                                    }
                                };
                                nat_eq(a43, a44)
                            }
                        }
                    };
                    if bool_not(a45) {
                        Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                            Adt11::C0(h46, _, _, _, _, _, _, _, _, _) => {
                                h46
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, h47, _, _, _, _, _, _, _, _) => {
                                h47
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, h48, _, _, _, _, _, _, _) => {
                                h48
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, h49, _, _, _, _, _, _) => {
                                h49
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, _, h50, _, _, _, _, _) => {
                                h50
                            }
                        }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                            Adt11::C0(_, _, _, _, _, _, _, _, h51, _) => {
                                h51
                            }
                        }, Some(Adt15::C1)), None::<Adt13>, f6(v0, v1)))
                    } else {
                        let a52 = f7(v0.clone());
                        let a53 = f8(v1.clone());
                        if nat_lt(a52, a53) {
                            Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                Adt11::C0(h54, _, _, _, _, _, _, _, _, _) => {
                                    h54
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, h55, _, _, _, _, _, _, _, _) => {
                                    h55
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, h56, _, _, _, _, _, _, _) => {
                                    h56
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, h57, _, _, _, _, _, _) => {
                                    h57
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, _, h58, _, _, _, _, _) => {
                                    h58
                                }
                            }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                Adt11::C0(_, _, _, _, _, _, _, _, h59, _) => {
                                    h59
                                }
                            }, Some(Adt15::C4)), None::<Adt13>, f6(v0, v1)))
                        } else {
                            let a60 = f9(v0.clone(), v1.clone())?;
                            if bool_not(a60) {
                                Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                    Adt11::C0(h61, _, _, _, _, _, _, _, _, _) => {
                                        h61
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, h62, _, _, _, _, _, _, _, _) => {
                                        h62
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, h63, _, _, _, _, _, _, _) => {
                                        h63
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, h64, _, _, _, _, _, _) => {
                                        h64
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, _, h65, _, _, _, _, _) => {
                                        h65
                                    }
                                }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                    Adt11::C0(_, _, _, _, _, _, _, _, h66, _) => {
                                        h66
                                    }
                                }, Some(Adt15::C5)), None::<Adt13>, f6(v0, v1)))
                            } else {
                                let a67 = f8(v1.clone());
                                let a68 = 0u64;
                                if if nat_eq(a67, a68) {
                                    let a70 = match v1.clone() {
                                        Adt20::C0(_, _, _, _, _, h69, _) => {
                                            h69
                                        }
                                    };
                                    bool_not(a70)
                                } else {
                                    false
                                } {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h71, _, _, _, _, _, _, _, _, _) => {
                                            h71
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h72, _, _, _, _, _, _, _, _) => {
                                            h72
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h73, _, _, _, _, _, _, _) => {
                                            h73
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, h74, _, _, _, _, _, _) => {
                                            h74
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, _, h75, _, _, _, _, _) => {
                                            h75
                                        }
                                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                        Adt11::C0(_, _, _, _, _, _, _, _, h76, _) => {
                                            h76
                                        }
                                    }, Some(Adt15::C6)), None::<Adt13>, f6(v0, v1)))
                                } else {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h77, _, _, _, _, _, _, _, _, _) => {
                                            h77
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h78, _, _, _, _, _, _, _, _) => {
                                            h78
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h79, _, _, _, _, _, _, _) => {
                                            h79
                                        }
                                    }, {
                                        let a81 = match v0.clone() {
                                            Adt11::C0(_, _, _, h80, _, _, _, _, _, _) => {
                                                h80
                                            }
                                        };
                                        let a82 = f8(v1.clone());
                                        nat_add(a81, a82)?
                                    }, match v0 {
                                        Adt11::C0(_, _, _, _, h83, _, _, _, _, _) => {
                                            h83
                                        }
                                    }, {
                                        let a84 = f8(v1.clone());
                                        let a85 = 0u64;
                                        if nat_eq(a84, a85) {
                                            Adt12::C4
                                        } else {
                                            Adt12::C3
                                        }
                                    }, None::<Adt13>, {
                                        let a86 = f8(v1.clone());
                                        let a87 = 0u64;
                                        if nat_eq(a86, a87) {
                                            None::<Adt14>
                                        } else {
                                            match v1.clone() {
                                                Adt20::C0(_, _, _, _, h88, _, _) => {
                                                    h88
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt20::C0(_, _, _, _, _, h89, _) => {
                                            h89
                                        }
                                    }, None::<Adt15>), None::<Adt13>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt23::C0(v0.clone(), None::<Adt13>, f6(v0, v1)))
            }
        }
        Adt12::C1 => {
            if f5(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt20::C0(_, _, _, _, _, _, h90) => {
                        h90
                    }
                } {
                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                        Adt11::C0(h91, _, _, _, _, _, _, _, _, _) => {
                            h91
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, h92, _, _, _, _, _, _, _, _) => {
                            h92
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, h93, _, _, _, _, _, _, _) => {
                            h93
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, h94, _, _, _, _, _, _) => {
                            h94
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, _, h95, _, _, _, _, _) => {
                            h95
                        }
                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                        Adt11::C0(_, _, _, _, _, _, _, _, h96, _) => {
                            h96
                        }
                    }, Some(Adt15::C7)), None::<Adt13>, f6(v0, v1)))
                } else {
                    let a107 = {
                        let m98 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h97, _, _) => {
                                h97
                            }
                        };
                        match m98 {
                            None => {
                                true
                            }
                            Some(v3) => {
                                let a105 = {
                                    let m101 = match v3 {
                                        Adt14::C0(h100, _, _) => {
                                            h100
                                        }
                                    };
                                    match m101 {
                                        Adt3::C0(h99, _, _) => {
                                            h99
                                        }
                                    }
                                };
                                let a106 = {
                                    let m104 = match v0.clone() {
                                        Adt11::C0(h103, _, _, _, _, _, _, _, _, _) => {
                                            h103
                                        }
                                    };
                                    match m104 {
                                        Adt1::C0(h102, _, _) => {
                                            h102
                                        }
                                    }
                                };
                                nat_eq(a105, a106)
                            }
                        }
                    };
                    if bool_not(a107) {
                        Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                            Adt11::C0(h108, _, _, _, _, _, _, _, _, _) => {
                                h108
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, h109, _, _, _, _, _, _, _, _) => {
                                h109
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, h110, _, _, _, _, _, _, _) => {
                                h110
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, h111, _, _, _, _, _, _) => {
                                h111
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, _, h112, _, _, _, _, _) => {
                                h112
                            }
                        }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                            Adt11::C0(_, _, _, _, _, _, _, _, h113, _) => {
                                h113
                            }
                        }, Some(Adt15::C1)), None::<Adt13>, f6(v0, v1)))
                    } else {
                        let a114 = f7(v0.clone());
                        let a115 = f8(v1.clone());
                        if nat_lt(a114, a115) {
                            Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                Adt11::C0(h116, _, _, _, _, _, _, _, _, _) => {
                                    h116
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, h117, _, _, _, _, _, _, _, _) => {
                                    h117
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, h118, _, _, _, _, _, _, _) => {
                                    h118
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, h119, _, _, _, _, _, _) => {
                                    h119
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, _, h120, _, _, _, _, _) => {
                                    h120
                                }
                            }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                Adt11::C0(_, _, _, _, _, _, _, _, h121, _) => {
                                    h121
                                }
                            }, Some(Adt15::C4)), None::<Adt13>, f6(v0, v1)))
                        } else {
                            let a122 = f9(v0.clone(), v1.clone())?;
                            if bool_not(a122) {
                                Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                    Adt11::C0(h123, _, _, _, _, _, _, _, _, _) => {
                                        h123
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, h124, _, _, _, _, _, _, _, _) => {
                                        h124
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, h125, _, _, _, _, _, _, _) => {
                                        h125
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, h126, _, _, _, _, _, _) => {
                                        h126
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, _, h127, _, _, _, _, _) => {
                                        h127
                                    }
                                }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                    Adt11::C0(_, _, _, _, _, _, _, _, h128, _) => {
                                        h128
                                    }
                                }, Some(Adt15::C5)), None::<Adt13>, f6(v0, v1)))
                            } else {
                                let a129 = f8(v1.clone());
                                let a130 = 0u64;
                                if if nat_eq(a129, a130) {
                                    let a132 = match v1.clone() {
                                        Adt20::C0(_, _, _, _, _, h131, _) => {
                                            h131
                                        }
                                    };
                                    bool_not(a132)
                                } else {
                                    false
                                } {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h133, _, _, _, _, _, _, _, _, _) => {
                                            h133
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h134, _, _, _, _, _, _, _, _) => {
                                            h134
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h135, _, _, _, _, _, _, _) => {
                                            h135
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, h136, _, _, _, _, _, _) => {
                                            h136
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, _, h137, _, _, _, _, _) => {
                                            h137
                                        }
                                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                        Adt11::C0(_, _, _, _, _, _, _, _, h138, _) => {
                                            h138
                                        }
                                    }, Some(Adt15::C6)), None::<Adt13>, f6(v0, v1)))
                                } else {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h139, _, _, _, _, _, _, _, _, _) => {
                                            h139
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h140, _, _, _, _, _, _, _, _) => {
                                            h140
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h141, _, _, _, _, _, _, _) => {
                                            h141
                                        }
                                    }, {
                                        let a143 = match v0.clone() {
                                            Adt11::C0(_, _, _, h142, _, _, _, _, _, _) => {
                                                h142
                                            }
                                        };
                                        let a144 = f8(v1.clone());
                                        nat_add(a143, a144)?
                                    }, match v0 {
                                        Adt11::C0(_, _, _, _, h145, _, _, _, _, _) => {
                                            h145
                                        }
                                    }, {
                                        let a146 = f8(v1.clone());
                                        let a147 = 0u64;
                                        if nat_eq(a146, a147) {
                                            Adt12::C4
                                        } else {
                                            Adt12::C3
                                        }
                                    }, None::<Adt13>, {
                                        let a148 = f8(v1.clone());
                                        let a149 = 0u64;
                                        if nat_eq(a148, a149) {
                                            None::<Adt14>
                                        } else {
                                            match v1.clone() {
                                                Adt20::C0(_, _, _, _, h150, _, _) => {
                                                    h150
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt20::C0(_, _, _, _, _, h151, _) => {
                                            h151
                                        }
                                    }, None::<Adt15>), None::<Adt13>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt23::C0(v0.clone(), None::<Adt13>, f6(v0, v1)))
            }
        }
        Adt12::C2 => {
            if f5(v0.clone(), v1.clone()) {
                Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                    Adt11::C0(h152, _, _, _, _, _, _, _, _, _) => {
                        h152
                    }
                }, match v0.clone() {
                    Adt11::C0(_, h153, _, _, _, _, _, _, _, _) => {
                        h153
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, h154, _, _, _, _, _, _, _) => {
                        h154
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, h155, _, _, _, _, _, _) => {
                        h155
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, _, h156, _, _, _, _, _) => {
                        h156
                    }
                }, Adt12::C5, None::<Adt13>, None::<Adt14>, match v0.clone() {
                    Adt11::C0(_, _, _, _, _, _, _, _, h157, _) => {
                        h157
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, _, _, _, _, _, _, h158) => {
                        h158
                    }
                }), None::<Adt13>, f6(v0, v1)))
            } else {
                Ok(Adt23::C0(v0.clone(), None::<Adt13>, f6(v0, v1)))
            }
        }
        Adt12::C3 => {
            if f5(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt20::C0(_, _, _, _, _, _, h159) => {
                        h159
                    }
                } {
                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                        Adt11::C0(h160, _, _, _, _, _, _, _, _, _) => {
                            h160
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, h161, _, _, _, _, _, _, _, _) => {
                            h161
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, h162, _, _, _, _, _, _, _) => {
                            h162
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, h163, _, _, _, _, _, _) => {
                            h163
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, _, h164, _, _, _, _, _) => {
                            h164
                        }
                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                        Adt11::C0(_, _, _, _, _, _, _, _, h165, _) => {
                            h165
                        }
                    }, Some(Adt15::C7)), None::<Adt13>, f6(v0, v1)))
                } else {
                    let a176 = {
                        let m167 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h166, _, _) => {
                                h166
                            }
                        };
                        match m167 {
                            None => {
                                true
                            }
                            Some(v4) => {
                                let a174 = {
                                    let m170 = match v4 {
                                        Adt14::C0(h169, _, _) => {
                                            h169
                                        }
                                    };
                                    match m170 {
                                        Adt3::C0(h168, _, _) => {
                                            h168
                                        }
                                    }
                                };
                                let a175 = {
                                    let m173 = match v0.clone() {
                                        Adt11::C0(h172, _, _, _, _, _, _, _, _, _) => {
                                            h172
                                        }
                                    };
                                    match m173 {
                                        Adt1::C0(h171, _, _) => {
                                            h171
                                        }
                                    }
                                };
                                nat_eq(a174, a175)
                            }
                        }
                    };
                    if bool_not(a176) {
                        Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                            Adt11::C0(h177, _, _, _, _, _, _, _, _, _) => {
                                h177
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, h178, _, _, _, _, _, _, _, _) => {
                                h178
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, h179, _, _, _, _, _, _, _) => {
                                h179
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, h180, _, _, _, _, _, _) => {
                                h180
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, _, h181, _, _, _, _, _) => {
                                h181
                            }
                        }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                            Adt11::C0(_, _, _, _, _, _, _, _, h182, _) => {
                                h182
                            }
                        }, Some(Adt15::C1)), None::<Adt13>, f6(v0, v1)))
                    } else {
                        let a183 = f7(v0.clone());
                        let a184 = f8(v1.clone());
                        if nat_lt(a183, a184) {
                            Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                Adt11::C0(h185, _, _, _, _, _, _, _, _, _) => {
                                    h185
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, h186, _, _, _, _, _, _, _, _) => {
                                    h186
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, h187, _, _, _, _, _, _, _) => {
                                    h187
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, h188, _, _, _, _, _, _) => {
                                    h188
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, _, h189, _, _, _, _, _) => {
                                    h189
                                }
                            }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                Adt11::C0(_, _, _, _, _, _, _, _, h190, _) => {
                                    h190
                                }
                            }, Some(Adt15::C4)), None::<Adt13>, f6(v0, v1)))
                        } else {
                            let a191 = f9(v0.clone(), v1.clone())?;
                            if bool_not(a191) {
                                Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                    Adt11::C0(h192, _, _, _, _, _, _, _, _, _) => {
                                        h192
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, h193, _, _, _, _, _, _, _, _) => {
                                        h193
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, h194, _, _, _, _, _, _, _) => {
                                        h194
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, h195, _, _, _, _, _, _) => {
                                        h195
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, _, h196, _, _, _, _, _) => {
                                        h196
                                    }
                                }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                    Adt11::C0(_, _, _, _, _, _, _, _, h197, _) => {
                                        h197
                                    }
                                }, Some(Adt15::C5)), None::<Adt13>, f6(v0, v1)))
                            } else {
                                let a198 = f8(v1.clone());
                                let a199 = 0u64;
                                if if nat_eq(a198, a199) {
                                    let a201 = match v1.clone() {
                                        Adt20::C0(_, _, _, _, _, h200, _) => {
                                            h200
                                        }
                                    };
                                    bool_not(a201)
                                } else {
                                    false
                                } {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h202, _, _, _, _, _, _, _, _, _) => {
                                            h202
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h203, _, _, _, _, _, _, _, _) => {
                                            h203
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h204, _, _, _, _, _, _, _) => {
                                            h204
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, h205, _, _, _, _, _, _) => {
                                            h205
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, _, h206, _, _, _, _, _) => {
                                            h206
                                        }
                                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                        Adt11::C0(_, _, _, _, _, _, _, _, h207, _) => {
                                            h207
                                        }
                                    }, Some(Adt15::C6)), None::<Adt13>, f6(v0, v1)))
                                } else {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h208, _, _, _, _, _, _, _, _, _) => {
                                            h208
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h209, _, _, _, _, _, _, _, _) => {
                                            h209
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h210, _, _, _, _, _, _, _) => {
                                            h210
                                        }
                                    }, {
                                        let a212 = match v0.clone() {
                                            Adt11::C0(_, _, _, h211, _, _, _, _, _, _) => {
                                                h211
                                            }
                                        };
                                        let a213 = f8(v1.clone());
                                        nat_add(a212, a213)?
                                    }, match v0 {
                                        Adt11::C0(_, _, _, _, h214, _, _, _, _, _) => {
                                            h214
                                        }
                                    }, {
                                        let a215 = f8(v1.clone());
                                        let a216 = 0u64;
                                        if nat_eq(a215, a216) {
                                            Adt12::C4
                                        } else {
                                            Adt12::C3
                                        }
                                    }, None::<Adt13>, {
                                        let a217 = f8(v1.clone());
                                        let a218 = 0u64;
                                        if nat_eq(a217, a218) {
                                            None::<Adt14>
                                        } else {
                                            match v1.clone() {
                                                Adt20::C0(_, _, _, _, h219, _, _) => {
                                                    h219
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt20::C0(_, _, _, _, _, h220, _) => {
                                            h220
                                        }
                                    }, None::<Adt15>), None::<Adt13>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt23::C0(v0.clone(), None::<Adt13>, f6(v0, v1)))
            }
        }
        Adt12::C4 => {
            if f5(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt20::C0(_, _, _, _, _, _, h221) => {
                        h221
                    }
                } {
                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                        Adt11::C0(h222, _, _, _, _, _, _, _, _, _) => {
                            h222
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, h223, _, _, _, _, _, _, _, _) => {
                            h223
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, h224, _, _, _, _, _, _, _) => {
                            h224
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, h225, _, _, _, _, _, _) => {
                            h225
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, _, h226, _, _, _, _, _) => {
                            h226
                        }
                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                        Adt11::C0(_, _, _, _, _, _, _, _, h227, _) => {
                            h227
                        }
                    }, Some(Adt15::C7)), None::<Adt13>, f6(v0, v1)))
                } else {
                    let a238 = {
                        let m229 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h228, _, _) => {
                                h228
                            }
                        };
                        match m229 {
                            None => {
                                true
                            }
                            Some(v5) => {
                                let a236 = {
                                    let m232 = match v5 {
                                        Adt14::C0(h231, _, _) => {
                                            h231
                                        }
                                    };
                                    match m232 {
                                        Adt3::C0(h230, _, _) => {
                                            h230
                                        }
                                    }
                                };
                                let a237 = {
                                    let m235 = match v0.clone() {
                                        Adt11::C0(h234, _, _, _, _, _, _, _, _, _) => {
                                            h234
                                        }
                                    };
                                    match m235 {
                                        Adt1::C0(h233, _, _) => {
                                            h233
                                        }
                                    }
                                };
                                nat_eq(a236, a237)
                            }
                        }
                    };
                    if bool_not(a238) {
                        Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                            Adt11::C0(h239, _, _, _, _, _, _, _, _, _) => {
                                h239
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, h240, _, _, _, _, _, _, _, _) => {
                                h240
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, h241, _, _, _, _, _, _, _) => {
                                h241
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, h242, _, _, _, _, _, _) => {
                                h242
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, _, h243, _, _, _, _, _) => {
                                h243
                            }
                        }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                            Adt11::C0(_, _, _, _, _, _, _, _, h244, _) => {
                                h244
                            }
                        }, Some(Adt15::C1)), None::<Adt13>, f6(v0, v1)))
                    } else {
                        let a245 = f7(v0.clone());
                        let a246 = f8(v1.clone());
                        if nat_lt(a245, a246) {
                            Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                Adt11::C0(h247, _, _, _, _, _, _, _, _, _) => {
                                    h247
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, h248, _, _, _, _, _, _, _, _) => {
                                    h248
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, h249, _, _, _, _, _, _, _) => {
                                    h249
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, h250, _, _, _, _, _, _) => {
                                    h250
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, _, h251, _, _, _, _, _) => {
                                    h251
                                }
                            }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                Adt11::C0(_, _, _, _, _, _, _, _, h252, _) => {
                                    h252
                                }
                            }, Some(Adt15::C4)), None::<Adt13>, f6(v0, v1)))
                        } else {
                            let a253 = f9(v0.clone(), v1.clone())?;
                            if bool_not(a253) {
                                Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                    Adt11::C0(h254, _, _, _, _, _, _, _, _, _) => {
                                        h254
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, h255, _, _, _, _, _, _, _, _) => {
                                        h255
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, h256, _, _, _, _, _, _, _) => {
                                        h256
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, h257, _, _, _, _, _, _) => {
                                        h257
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, _, h258, _, _, _, _, _) => {
                                        h258
                                    }
                                }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                    Adt11::C0(_, _, _, _, _, _, _, _, h259, _) => {
                                        h259
                                    }
                                }, Some(Adt15::C5)), None::<Adt13>, f6(v0, v1)))
                            } else {
                                let a260 = f8(v1.clone());
                                let a261 = 0u64;
                                if if nat_eq(a260, a261) {
                                    let a263 = match v1.clone() {
                                        Adt20::C0(_, _, _, _, _, h262, _) => {
                                            h262
                                        }
                                    };
                                    bool_not(a263)
                                } else {
                                    false
                                } {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h264, _, _, _, _, _, _, _, _, _) => {
                                            h264
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h265, _, _, _, _, _, _, _, _) => {
                                            h265
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h266, _, _, _, _, _, _, _) => {
                                            h266
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, h267, _, _, _, _, _, _) => {
                                            h267
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, _, h268, _, _, _, _, _) => {
                                            h268
                                        }
                                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                        Adt11::C0(_, _, _, _, _, _, _, _, h269, _) => {
                                            h269
                                        }
                                    }, Some(Adt15::C6)), None::<Adt13>, f6(v0, v1)))
                                } else {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h270, _, _, _, _, _, _, _, _, _) => {
                                            h270
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h271, _, _, _, _, _, _, _, _) => {
                                            h271
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h272, _, _, _, _, _, _, _) => {
                                            h272
                                        }
                                    }, {
                                        let a274 = match v0.clone() {
                                            Adt11::C0(_, _, _, h273, _, _, _, _, _, _) => {
                                                h273
                                            }
                                        };
                                        let a275 = f8(v1.clone());
                                        nat_add(a274, a275)?
                                    }, match v0 {
                                        Adt11::C0(_, _, _, _, h276, _, _, _, _, _) => {
                                            h276
                                        }
                                    }, {
                                        let a277 = f8(v1.clone());
                                        let a278 = 0u64;
                                        if nat_eq(a277, a278) {
                                            Adt12::C4
                                        } else {
                                            Adt12::C3
                                        }
                                    }, None::<Adt13>, {
                                        let a279 = f8(v1.clone());
                                        let a280 = 0u64;
                                        if nat_eq(a279, a280) {
                                            None::<Adt14>
                                        } else {
                                            match v1.clone() {
                                                Adt20::C0(_, _, _, _, h281, _, _) => {
                                                    h281
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt20::C0(_, _, _, _, _, h282, _) => {
                                            h282
                                        }
                                    }, None::<Adt15>), None::<Adt13>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt23::C0(v0.clone(), None::<Adt13>, f6(v0, v1)))
            }
        }
        Adt12::C5 => {
            if f5(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt20::C0(_, _, _, _, _, _, h283) => {
                        h283
                    }
                } {
                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                        Adt11::C0(h284, _, _, _, _, _, _, _, _, _) => {
                            h284
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, h285, _, _, _, _, _, _, _, _) => {
                            h285
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, h286, _, _, _, _, _, _, _) => {
                            h286
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, h287, _, _, _, _, _, _) => {
                            h287
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, _, h288, _, _, _, _, _) => {
                            h288
                        }
                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                        Adt11::C0(_, _, _, _, _, _, _, _, h289, _) => {
                            h289
                        }
                    }, Some(Adt15::C7)), None::<Adt13>, f6(v0, v1)))
                } else {
                    let a300 = {
                        let m291 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h290, _, _) => {
                                h290
                            }
                        };
                        match m291 {
                            None => {
                                true
                            }
                            Some(v6) => {
                                let a298 = {
                                    let m294 = match v6 {
                                        Adt14::C0(h293, _, _) => {
                                            h293
                                        }
                                    };
                                    match m294 {
                                        Adt3::C0(h292, _, _) => {
                                            h292
                                        }
                                    }
                                };
                                let a299 = {
                                    let m297 = match v0.clone() {
                                        Adt11::C0(h296, _, _, _, _, _, _, _, _, _) => {
                                            h296
                                        }
                                    };
                                    match m297 {
                                        Adt1::C0(h295, _, _) => {
                                            h295
                                        }
                                    }
                                };
                                nat_eq(a298, a299)
                            }
                        }
                    };
                    if bool_not(a300) {
                        Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                            Adt11::C0(h301, _, _, _, _, _, _, _, _, _) => {
                                h301
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, h302, _, _, _, _, _, _, _, _) => {
                                h302
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, h303, _, _, _, _, _, _, _) => {
                                h303
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, h304, _, _, _, _, _, _) => {
                                h304
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, _, h305, _, _, _, _, _) => {
                                h305
                            }
                        }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                            Adt11::C0(_, _, _, _, _, _, _, _, h306, _) => {
                                h306
                            }
                        }, Some(Adt15::C1)), None::<Adt13>, f6(v0, v1)))
                    } else {
                        let a307 = f7(v0.clone());
                        let a308 = f8(v1.clone());
                        if nat_lt(a307, a308) {
                            Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                Adt11::C0(h309, _, _, _, _, _, _, _, _, _) => {
                                    h309
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, h310, _, _, _, _, _, _, _, _) => {
                                    h310
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, h311, _, _, _, _, _, _, _) => {
                                    h311
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, h312, _, _, _, _, _, _) => {
                                    h312
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, _, h313, _, _, _, _, _) => {
                                    h313
                                }
                            }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                Adt11::C0(_, _, _, _, _, _, _, _, h314, _) => {
                                    h314
                                }
                            }, Some(Adt15::C4)), None::<Adt13>, f6(v0, v1)))
                        } else {
                            let a315 = f9(v0.clone(), v1.clone())?;
                            if bool_not(a315) {
                                Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                    Adt11::C0(h316, _, _, _, _, _, _, _, _, _) => {
                                        h316
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, h317, _, _, _, _, _, _, _, _) => {
                                        h317
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, h318, _, _, _, _, _, _, _) => {
                                        h318
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, h319, _, _, _, _, _, _) => {
                                        h319
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, _, h320, _, _, _, _, _) => {
                                        h320
                                    }
                                }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                    Adt11::C0(_, _, _, _, _, _, _, _, h321, _) => {
                                        h321
                                    }
                                }, Some(Adt15::C5)), None::<Adt13>, f6(v0, v1)))
                            } else {
                                let a322 = f8(v1.clone());
                                let a323 = 0u64;
                                if if nat_eq(a322, a323) {
                                    let a325 = match v1.clone() {
                                        Adt20::C0(_, _, _, _, _, h324, _) => {
                                            h324
                                        }
                                    };
                                    bool_not(a325)
                                } else {
                                    false
                                } {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h326, _, _, _, _, _, _, _, _, _) => {
                                            h326
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h327, _, _, _, _, _, _, _, _) => {
                                            h327
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h328, _, _, _, _, _, _, _) => {
                                            h328
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, h329, _, _, _, _, _, _) => {
                                            h329
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, _, h330, _, _, _, _, _) => {
                                            h330
                                        }
                                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                        Adt11::C0(_, _, _, _, _, _, _, _, h331, _) => {
                                            h331
                                        }
                                    }, Some(Adt15::C6)), None::<Adt13>, f6(v0, v1)))
                                } else {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h332, _, _, _, _, _, _, _, _, _) => {
                                            h332
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h333, _, _, _, _, _, _, _, _) => {
                                            h333
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h334, _, _, _, _, _, _, _) => {
                                            h334
                                        }
                                    }, {
                                        let a336 = match v0.clone() {
                                            Adt11::C0(_, _, _, h335, _, _, _, _, _, _) => {
                                                h335
                                            }
                                        };
                                        let a337 = f8(v1.clone());
                                        nat_add(a336, a337)?
                                    }, match v0 {
                                        Adt11::C0(_, _, _, _, h338, _, _, _, _, _) => {
                                            h338
                                        }
                                    }, {
                                        let a339 = f8(v1.clone());
                                        let a340 = 0u64;
                                        if nat_eq(a339, a340) {
                                            Adt12::C4
                                        } else {
                                            Adt12::C3
                                        }
                                    }, None::<Adt13>, {
                                        let a341 = f8(v1.clone());
                                        let a342 = 0u64;
                                        if nat_eq(a341, a342) {
                                            None::<Adt14>
                                        } else {
                                            match v1.clone() {
                                                Adt20::C0(_, _, _, _, h343, _, _) => {
                                                    h343
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt20::C0(_, _, _, _, _, h344, _) => {
                                            h344
                                        }
                                    }, None::<Adt15>), None::<Adt13>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt23::C0(v0.clone(), None::<Adt13>, f6(v0, v1)))
            }
        }
        Adt12::C6 => {
            if f5(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt20::C0(_, _, _, _, _, _, h345) => {
                        h345
                    }
                } {
                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                        Adt11::C0(h346, _, _, _, _, _, _, _, _, _) => {
                            h346
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, h347, _, _, _, _, _, _, _, _) => {
                            h347
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, h348, _, _, _, _, _, _, _) => {
                            h348
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, h349, _, _, _, _, _, _) => {
                            h349
                        }
                    }, match v0.clone() {
                        Adt11::C0(_, _, _, _, h350, _, _, _, _, _) => {
                            h350
                        }
                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                        Adt11::C0(_, _, _, _, _, _, _, _, h351, _) => {
                            h351
                        }
                    }, Some(Adt15::C7)), None::<Adt13>, f6(v0, v1)))
                } else {
                    let a362 = {
                        let m353 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h352, _, _) => {
                                h352
                            }
                        };
                        match m353 {
                            None => {
                                true
                            }
                            Some(v7) => {
                                let a360 = {
                                    let m356 = match v7 {
                                        Adt14::C0(h355, _, _) => {
                                            h355
                                        }
                                    };
                                    match m356 {
                                        Adt3::C0(h354, _, _) => {
                                            h354
                                        }
                                    }
                                };
                                let a361 = {
                                    let m359 = match v0.clone() {
                                        Adt11::C0(h358, _, _, _, _, _, _, _, _, _) => {
                                            h358
                                        }
                                    };
                                    match m359 {
                                        Adt1::C0(h357, _, _) => {
                                            h357
                                        }
                                    }
                                };
                                nat_eq(a360, a361)
                            }
                        }
                    };
                    if bool_not(a362) {
                        Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                            Adt11::C0(h363, _, _, _, _, _, _, _, _, _) => {
                                h363
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, h364, _, _, _, _, _, _, _, _) => {
                                h364
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, h365, _, _, _, _, _, _, _) => {
                                h365
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, h366, _, _, _, _, _, _) => {
                                h366
                            }
                        }, match v0.clone() {
                            Adt11::C0(_, _, _, _, h367, _, _, _, _, _) => {
                                h367
                            }
                        }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                            Adt11::C0(_, _, _, _, _, _, _, _, h368, _) => {
                                h368
                            }
                        }, Some(Adt15::C1)), None::<Adt13>, f6(v0, v1)))
                    } else {
                        let a369 = f7(v0.clone());
                        let a370 = f8(v1.clone());
                        if nat_lt(a369, a370) {
                            Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                Adt11::C0(h371, _, _, _, _, _, _, _, _, _) => {
                                    h371
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, h372, _, _, _, _, _, _, _, _) => {
                                    h372
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, h373, _, _, _, _, _, _, _) => {
                                    h373
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, h374, _, _, _, _, _, _) => {
                                    h374
                                }
                            }, match v0.clone() {
                                Adt11::C0(_, _, _, _, h375, _, _, _, _, _) => {
                                    h375
                                }
                            }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                Adt11::C0(_, _, _, _, _, _, _, _, h376, _) => {
                                    h376
                                }
                            }, Some(Adt15::C4)), None::<Adt13>, f6(v0, v1)))
                        } else {
                            let a377 = f9(v0.clone(), v1.clone())?;
                            if bool_not(a377) {
                                Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                    Adt11::C0(h378, _, _, _, _, _, _, _, _, _) => {
                                        h378
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, h379, _, _, _, _, _, _, _, _) => {
                                        h379
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, h380, _, _, _, _, _, _, _) => {
                                        h380
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, h381, _, _, _, _, _, _) => {
                                        h381
                                    }
                                }, match v0.clone() {
                                    Adt11::C0(_, _, _, _, h382, _, _, _, _, _) => {
                                        h382
                                    }
                                }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                    Adt11::C0(_, _, _, _, _, _, _, _, h383, _) => {
                                        h383
                                    }
                                }, Some(Adt15::C5)), None::<Adt13>, f6(v0, v1)))
                            } else {
                                let a384 = f8(v1.clone());
                                let a385 = 0u64;
                                if if nat_eq(a384, a385) {
                                    let a387 = match v1.clone() {
                                        Adt20::C0(_, _, _, _, _, h386, _) => {
                                            h386
                                        }
                                    };
                                    bool_not(a387)
                                } else {
                                    false
                                } {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h388, _, _, _, _, _, _, _, _, _) => {
                                            h388
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h389, _, _, _, _, _, _, _, _) => {
                                            h389
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h390, _, _, _, _, _, _, _) => {
                                            h390
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, h391, _, _, _, _, _, _) => {
                                            h391
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, _, _, h392, _, _, _, _, _) => {
                                            h392
                                        }
                                    }, Adt12::C6, None::<Adt13>, None::<Adt14>, match v0.clone() {
                                        Adt11::C0(_, _, _, _, _, _, _, _, h393, _) => {
                                            h393
                                        }
                                    }, Some(Adt15::C6)), None::<Adt13>, f6(v0, v1)))
                                } else {
                                    Ok(Adt23::C0(Adt11::C0(match v0.clone() {
                                        Adt11::C0(h394, _, _, _, _, _, _, _, _, _) => {
                                            h394
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, h395, _, _, _, _, _, _, _, _) => {
                                            h395
                                        }
                                    }, match v0.clone() {
                                        Adt11::C0(_, _, h396, _, _, _, _, _, _, _) => {
                                            h396
                                        }
                                    }, {
                                        let a398 = match v0.clone() {
                                            Adt11::C0(_, _, _, h397, _, _, _, _, _, _) => {
                                                h397
                                            }
                                        };
                                        let a399 = f8(v1.clone());
                                        nat_add(a398, a399)?
                                    }, match v0 {
                                        Adt11::C0(_, _, _, _, h400, _, _, _, _, _) => {
                                            h400
                                        }
                                    }, {
                                        let a401 = f8(v1.clone());
                                        let a402 = 0u64;
                                        if nat_eq(a401, a402) {
                                            Adt12::C4
                                        } else {
                                            Adt12::C3
                                        }
                                    }, None::<Adt13>, {
                                        let a403 = f8(v1.clone());
                                        let a404 = 0u64;
                                        if nat_eq(a403, a404) {
                                            None::<Adt14>
                                        } else {
                                            match v1.clone() {
                                                Adt20::C0(_, _, _, _, h405, _, _) => {
                                                    h405
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt20::C0(_, _, _, _, _, h406, _) => {
                                            h406
                                        }
                                    }, None::<Adt15>), None::<Adt13>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt23::C0(v0.clone(), None::<Adt13>, f6(v0, v1)))
            }
        }
    }
}

pub fn f3(v0: List<Adt22>, v1: List<Adt22>) -> List<Adt22> {
    let m407 = v0;
    match m407.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f3(v3, v1))
        }
    }
}

pub fn f4(v0: Adt0, v1: Adt16, v2: Adt23) -> R<Adt21> {
    let m411 = {
        let m410 = match v2.clone() {
            Adt23::C0(h409, _, _) => {
                h409
            }
        };
        match m410 {
            Adt11::C0(_, _, _, _, _, _, _, h408, _, _) => {
                h408
            }
        }
    };
    match m411 {
        None => {
            let m415 = {
                let m414 = match v2.clone() {
                    Adt23::C0(h413, _, _) => {
                        h413
                    }
                };
                match m414 {
                    Adt11::C0(_, _, _, _, _, h412, _, _, _, _) => {
                        h412
                    }
                }
            };
            match m415 {
                Adt12::C0 => {
                    Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h416, _, _, _, _, _, _, _, _, _, _) => {
                            h416
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h417, _, _, _, _, _, _, _, _, _) => {
                            h417
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h418, _, _, _, _, _, _, _, _) => {
                            h418
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h419, _, _, _, _, _, _, _) => {
                            h419
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h420, _, _, _, _, _, _) => {
                            h420
                        }
                    }, match v2 {
                        Adt23::C0(h421, _, _) => {
                            h421
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h422, _, _, _, _) => {
                            h422
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, h423, _, _, _) => {
                            h423
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h424, _, _) => {
                            h424
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, h425, _) => {
                            h425
                        }
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, _, h426) => {
                            h426
                        }
                    }), List::<Adt22>::nil()))
                }
                Adt12::C1 => {
                    Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h427, _, _, _, _, _, _, _, _, _, _) => {
                            h427
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h428, _, _, _, _, _, _, _, _, _) => {
                            h428
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h429, _, _, _, _, _, _, _, _) => {
                            h429
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h430, _, _, _, _, _, _, _) => {
                            h430
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h431, _, _, _, _, _, _) => {
                            h431
                        }
                    }, match v2 {
                        Adt23::C0(h432, _, _) => {
                            h432
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h433, _, _, _, _) => {
                            h433
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, h434, _, _, _) => {
                            h434
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h435, _, _) => {
                            h435
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, h436, _) => {
                            h436
                        }
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, _, h437) => {
                            h437
                        }
                    }), List::<Adt22>::nil()))
                }
                Adt12::C2 => {
                    Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h481, _, _, _, _, _, _, _, _, _, _) => {
                            h481
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h482, _, _, _, _, _, _, _, _, _) => {
                            h482
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h483, _, _, _, _, _, _, _, _) => {
                            h483
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h484, _, _, _, _, _, _, _) => {
                            h484
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h485, _, _, _, _, _, _) => {
                            h485
                        }
                    }, match v2 {
                        Adt23::C0(h486, _, _) => {
                            h486
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h487, _, _, _, _) => {
                            h487
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, h488, _, _, _) => {
                            h488
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h489, _, _) => {
                            h489
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, h490, _) => {
                            h490
                        }
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, _, h491) => {
                            h491
                        }
                    }), List::<Adt22>::nil()))
                }
                Adt12::C3 => {
                    Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h438, _, _, _, _, _, _, _, _, _, _) => {
                            h438
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h439, _, _, _, _, _, _, _, _, _) => {
                            h439
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h440, _, _, _, _, _, _, _, _) => {
                            h440
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h441, _, _, _, _, _, _, _) => {
                            h441
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h442, _, _, _, _, _, _) => {
                            h442
                        }
                    }, match v2 {
                        Adt23::C0(h443, _, _) => {
                            h443
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h444, _, _, _, _) => {
                            h444
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, h445, _, _, _) => {
                            h445
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h446, _, _) => {
                            h446
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, h447, _) => {
                            h447
                        }
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, _, h448) => {
                            h448
                        }
                    }), List::<Adt22>::nil()))
                }
                Adt12::C4 => {
                    Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h449, _, _, _, _, _, _, _, _, _, _) => {
                            h449
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h450, _, _, _, _, _, _, _, _, _) => {
                            h450
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h451, _, _, _, _, _, _, _, _) => {
                            h451
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h452, _, _, _, _, _, _, _) => {
                            h452
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h453, _, _, _, _, _, _) => {
                            h453
                        }
                    }, match v2 {
                        Adt23::C0(h454, _, _) => {
                            h454
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h455, _, _, _, _) => {
                            h455
                        }
                    }, Adt19::C3, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h456, _, _) => {
                            h456
                        }
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, h457, _) => {
                            h457
                        }
                    }, true), List::cons(Adt22::C3(match v1.clone() {
                        Adt16::C0(_, h458, _, _, _, _, _, _, _, _, _) => {
                            h458
                        }
                    }, match v1 {
                        Adt16::C0(_, _, _, _, _, h459, _, _, _, _, _) => {
                            h459
                        }
                    }), List::<Adt22>::nil())))
                }
                Adt12::C5 => {
                    Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h460, _, _, _, _, _, _, _, _, _, _) => {
                            h460
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h461, _, _, _, _, _, _, _, _, _) => {
                            h461
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h462, _, _, _, _, _, _, _, _) => {
                            h462
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h463, _, _, _, _, _, _, _) => {
                            h463
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h464, _, _, _, _, _, _) => {
                            h464
                        }
                    }, match v2 {
                        Adt23::C0(h465, _, _) => {
                            h465
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h466, _, _, _, _) => {
                            h466
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, h467, _, _, _) => {
                            h467
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h468, _, _) => {
                            h468
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, h469, _) => {
                            h469
                        }
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, _, h470) => {
                            h470
                        }
                    }), List::<Adt22>::nil()))
                }
                Adt12::C6 => {
                    Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h471, _, _, _, _, _, _, _, _, _, _) => {
                            h471
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h472, _, _, _, _, _, _, _, _, _) => {
                            h472
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h473, _, _, _, _, _, _, _, _) => {
                            h473
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h474, _, _, _, _, _, _, _) => {
                            h474
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h475, _, _, _, _, _, _) => {
                            h475
                        }
                    }, match v2 {
                        Adt23::C0(h476, _, _) => {
                            h476
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h477, _, _, _, _) => {
                            h477
                        }
                    }, Adt19::C8, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h478, _, _) => {
                            h478
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, h479, _) => {
                            h479
                        }
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, _, h480) => {
                            h480
                        }
                    }), List::<Adt22>::nil()))
                }
            }
        }
        Some(v3) => {
            Ok(f10(Adt0::C0(match v0.clone() {
                Adt0::C0(h492, _, _, _, _, _, _, _, _, _, _) => {
                    h492
                }
            }, match v0.clone() {
                Adt0::C0(_, h493, _, _, _, _, _, _, _, _, _) => {
                    h493
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h494, _, _, _, _, _, _, _, _) => {
                    h494
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h495, _, _, _, _, _, _, _) => {
                    h495
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h496, _, _, _, _, _, _) => {
                    h496
                }
            }, match v2 {
                Adt23::C0(h497, _, _) => {
                    h497
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h498, _, _, _, _) => {
                    h498
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, h499, _, _, _) => {
                    h499
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h500, _, _) => {
                    h500
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h501, _) => {
                    h501
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h502) => {
                    h502
                }
            }), f11(v1, v3)?))
        }
    }
}

pub fn f5(v0: Adt11, v1: Adt20) -> bool {
    let m504 = match v0 {
        Adt11::C0(_, _, _, _, _, _, h503, _, _, _) => {
            h503
        }
    };
    match m504 {
        None => {
            false
        }
        Some(v2) => {
            if f12(match v2.clone() {
                Adt13::C0(h505, _, _, _, _) => {
                    h505
                }
            }, match v1.clone() {
                Adt20::C0(h506, _, _, _, _, _, _) => {
                    h506
                }
            }) {
                if f13(match v2.clone() {
                    Adt13::C0(_, h507, _, _, _) => {
                        h507
                    }
                }, match v1.clone() {
                    Adt20::C0(_, h508, _, _, _, _, _) => {
                        h508
                    }
                }) {
                    let a511 = match v2.clone() {
                        Adt13::C0(_, _, h509, _, _) => {
                            h509
                        }
                    };
                    let a512 = match v1.clone() {
                        Adt20::C0(_, _, h510, _, _, _, _) => {
                            h510
                        }
                    };
                    if nat_eq(a511, a512) {
                        let a515 = match v2 {
                            Adt13::C0(_, _, _, h513, _) => {
                                h513
                            }
                        };
                        let a516 = match v1 {
                            Adt20::C0(_, _, _, h514, _, _, _) => {
                                h514
                            }
                        };
                        nat_eq(a515, a516)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        }
    }
}

pub fn f6(v0: Adt11, v1: Adt20) -> Option<Adt3> {
    let m518 = match v1 {
        Adt20::C0(_, _, _, _, h517, _, _) => {
            h517
        }
    };
    match m518 {
        None => {
            None::<Adt3>
        }
        Some(v2) => {
            let m520 = match v0 {
                Adt11::C0(_, _, _, _, _, _, _, h519, _, _) => {
                    h519
                }
            };
            match m520 {
                None => {
                    f14(v2)
                }
                Some(v3) => {
                    if f13(match v3 {
                        Adt14::C0(h521, _, _) => {
                            h521
                        }
                    }, match v2.clone() {
                        Adt14::C0(h522, _, _) => {
                            h522
                        }
                    }) {
                        None::<Adt3>
                    } else {
                        f14(v2)
                    }
                }
            }
        }
    }
}

pub fn f7(v0: Adt11) -> u64 {
    let m526 = {
        let m525 = match v0.clone() {
            Adt11::C0(_, h524, _, _, _, _, _, _, _, _) => {
                h524
            }
        };
        match m525 {
            Adt2::C0(_, h523, _) => {
                h523
            }
        }
    };
    match m526 {
        None => {
            match v0 {
                Adt11::C0(_, _, h527, _, _, _, _, _, _, _) => {
                    h527
                }
            }
        }
        Some(v1) => {
            let a529 = v1;
            let a530 = match v0.clone() {
                Adt11::C0(_, _, _, h528, _, _, _, _, _, _) => {
                    h528
                }
            };
            if nat_eq(a529, a530) {
                1u64
            } else {
                let a535 = match v0.clone() {
                    Adt11::C0(_, _, h531, _, _, _, _, _, _, _) => {
                        h531
                    }
                };
                let a536 = {
                    let a533 = v1;
                    let a534 = match v0.clone() {
                        Adt11::C0(_, _, _, h532, _, _, _, _, _, _) => {
                            h532
                        }
                    };
                    nat_sub(a533, a534)
                };
                if nat_lt(a535, a536) {
                    match v0 {
                        Adt11::C0(_, _, h537, _, _, _, _, _, _, _) => {
                            h537
                        }
                    }
                } else {
                    let a539 = v1;
                    let a540 = match v0 {
                        Adt11::C0(_, _, _, h538, _, _, _, _, _, _) => {
                            h538
                        }
                    };
                    nat_sub(a539, a540)
                }
            }
        }
    }
}

pub fn f8(v0: Adt20) -> u64 {
    let m542 = match v0 {
        Adt20::C0(_, _, _, _, h541, _, _) => {
            h541
        }
    };
    match m542 {
        None => {
            0u64
        }
        Some(v1) => {
            match v1 {
                Adt14::C0(_, _, h543) => {
                    h543
                }
            }
        }
    }
}

pub fn f9(v0: Adt11, v1: Adt20) -> R<bool> {
    let m547 = {
        let m546 = match v0.clone() {
            Adt11::C0(_, h545, _, _, _, _, _, _, _, _) => {
                h545
            }
        };
        match m546 {
            Adt2::C0(_, h544, _) => {
                h544
            }
        }
    };
    match m547 {
        None => {
            Ok(true)
        }
        Some(v2) => {
            let a553 = {
                let a551 = v2;
                let a552 = {
                    let a549 = match v0.clone() {
                        Adt11::C0(_, _, _, h548, _, _, _, _, _, _) => {
                            h548
                        }
                    };
                    let a550 = f8(v1.clone());
                    nat_add(a549, a550)?
                };
                nat_lt(a551, a552)
            };
            if bool_not(a553) {
                if match v1.clone() {
                    Adt20::C0(_, _, _, _, _, h554, _) => {
                        h554
                    }
                } {
                    let a558 = v2;
                    let a559 = {
                        let a556 = match v0 {
                            Adt11::C0(_, _, _, h555, _, _, _, _, _, _) => {
                                h555
                            }
                        };
                        let a557 = f8(v1);
                        nat_add(a556, a557)?
                    };
                    Ok(nat_eq(a558, a559))
                } else {
                    Ok(true)
                }
            } else {
                Ok(false)
            }
        }
    }
}

pub fn f10(v0: Adt0, v1: Adt24) -> Adt21 {
    let m563 = {
        let m562 = match v1.clone() {
            Adt24::C0(h561, _, _) => {
                h561
            }
        };
        match m562 {
            Adt16::C0(_, _, _, _, _, _, _, h560, _, _, _) => {
                h560
            }
        }
    };
    match m563 {
        Adt17::C0 => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h564, _, _, _, _, _, _, _, _, _, _) => {
                    h564
                }
            }, match v0.clone() {
                Adt0::C0(_, h565, _, _, _, _, _, _, _, _, _) => {
                    h565
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h566, _, _, _, _, _, _, _, _) => {
                    h566
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h567, _, _, _, _, _, _, _) => {
                    h567
                }
            }, {
                let m570 = match v1.clone() {
                    Adt24::C0(h569, _, _) => {
                        h569
                    }
                };
                match m570 {
                    Adt16::C0(_, _, _, _, h568, _, _, _, _, _, _) => {
                        h568
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h571, _, _, _, _, _) => {
                    h571
                }
            }, Some(match v1.clone() {
                Adt24::C0(h572, _, _) => {
                    h572
                }
            }), {
                let m576 = {
                    let m575 = match v1.clone() {
                        Adt24::C0(h574, _, _) => {
                            h574
                        }
                    };
                    match m575 {
                        Adt16::C0(_, _, _, _, _, _, _, h573, _, _, _) => {
                            h573
                        }
                    }
                };
                match m576 {
                    Adt17::C0 => {
                        Adt19::C8
                    }
                    Adt17::C1 => {
                        Adt19::C2
                    }
                    Adt17::C2 => {
                        Adt19::C8
                    }
                    Adt17::C3 => {
                        Adt19::C8
                    }
                    Adt17::C4 => {
                        Adt19::C8
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h577, _, _) => {
                    h577
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h578, _) => {
                    h578
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h579) => {
                    h579
                }
            }), {
                let m581 = match v1 {
                    Adt24::C0(_, h580, _) => {
                        h580
                    }
                };
                match m581 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v2) => {
                        List::cons(Adt22::C2(v2), List::<Adt22>::nil())
                    }
                }
            })
        }
        Adt17::C1 => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h582, _, _, _, _, _, _, _, _, _, _) => {
                    h582
                }
            }, match v0.clone() {
                Adt0::C0(_, h583, _, _, _, _, _, _, _, _, _) => {
                    h583
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h584, _, _, _, _, _, _, _, _) => {
                    h584
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h585, _, _, _, _, _, _, _) => {
                    h585
                }
            }, {
                let m588 = match v1.clone() {
                    Adt24::C0(h587, _, _) => {
                        h587
                    }
                };
                match m588 {
                    Adt16::C0(_, _, _, _, h586, _, _, _, _, _, _) => {
                        h586
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h589, _, _, _, _, _) => {
                    h589
                }
            }, Some(match v1.clone() {
                Adt24::C0(h590, _, _) => {
                    h590
                }
            }), {
                let m594 = {
                    let m593 = match v1.clone() {
                        Adt24::C0(h592, _, _) => {
                            h592
                        }
                    };
                    match m593 {
                        Adt16::C0(_, _, _, _, _, _, _, h591, _, _, _) => {
                            h591
                        }
                    }
                };
                match m594 {
                    Adt17::C0 => {
                        Adt19::C8
                    }
                    Adt17::C1 => {
                        Adt19::C2
                    }
                    Adt17::C2 => {
                        Adt19::C8
                    }
                    Adt17::C3 => {
                        Adt19::C8
                    }
                    Adt17::C4 => {
                        Adt19::C8
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h595, _, _) => {
                    h595
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h596, _) => {
                    h596
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h597) => {
                    h597
                }
            }), {
                let m599 = match v1 {
                    Adt24::C0(_, h598, _) => {
                        h598
                    }
                };
                match m599 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v3) => {
                        List::cons(Adt22::C2(v3), List::<Adt22>::nil())
                    }
                }
            })
        }
        Adt17::C2 => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h600, _, _, _, _, _, _, _, _, _, _) => {
                    h600
                }
            }, match v0.clone() {
                Adt0::C0(_, h601, _, _, _, _, _, _, _, _, _) => {
                    h601
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h602, _, _, _, _, _, _, _, _) => {
                    h602
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h603, _, _, _, _, _, _, _) => {
                    h603
                }
            }, {
                let m606 = match v1.clone() {
                    Adt24::C0(h605, _, _) => {
                        h605
                    }
                };
                match m606 {
                    Adt16::C0(_, _, _, _, h604, _, _, _, _, _, _) => {
                        h604
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h607, _, _, _, _, _) => {
                    h607
                }
            }, Some(match v1.clone() {
                Adt24::C0(h608, _, _) => {
                    h608
                }
            }), {
                let m612 = {
                    let m611 = match v1.clone() {
                        Adt24::C0(h610, _, _) => {
                            h610
                        }
                    };
                    match m611 {
                        Adt16::C0(_, _, _, _, _, _, _, h609, _, _, _) => {
                            h609
                        }
                    }
                };
                match m612 {
                    Adt17::C0 => {
                        Adt19::C8
                    }
                    Adt17::C1 => {
                        Adt19::C2
                    }
                    Adt17::C2 => {
                        Adt19::C8
                    }
                    Adt17::C3 => {
                        Adt19::C8
                    }
                    Adt17::C4 => {
                        Adt19::C8
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h613, _, _) => {
                    h613
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h614, _) => {
                    h614
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h615) => {
                    h615
                }
            }), {
                let m617 = match v1 {
                    Adt24::C0(_, h616, _) => {
                        h616
                    }
                };
                match m617 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v4) => {
                        List::cons(Adt22::C2(v4), List::<Adt22>::nil())
                    }
                }
            })
        }
        Adt17::C3 => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h618, _, _, _, _, _, _, _, _, _, _) => {
                    h618
                }
            }, match v0.clone() {
                Adt0::C0(_, h619, _, _, _, _, _, _, _, _, _) => {
                    h619
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h620, _, _, _, _, _, _, _, _) => {
                    h620
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h621, _, _, _, _, _, _, _) => {
                    h621
                }
            }, {
                let m624 = match v1.clone() {
                    Adt24::C0(h623, _, _) => {
                        h623
                    }
                };
                match m624 {
                    Adt16::C0(_, _, _, _, h622, _, _, _, _, _, _) => {
                        h622
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h625, _, _, _, _, _) => {
                    h625
                }
            }, Some(match v1.clone() {
                Adt24::C0(h626, _, _) => {
                    h626
                }
            }), {
                let m630 = {
                    let m629 = match v1.clone() {
                        Adt24::C0(h628, _, _) => {
                            h628
                        }
                    };
                    match m629 {
                        Adt16::C0(_, _, _, _, _, _, _, h627, _, _, _) => {
                            h627
                        }
                    }
                };
                match m630 {
                    Adt17::C0 => {
                        Adt19::C8
                    }
                    Adt17::C1 => {
                        Adt19::C2
                    }
                    Adt17::C2 => {
                        Adt19::C8
                    }
                    Adt17::C3 => {
                        Adt19::C8
                    }
                    Adt17::C4 => {
                        Adt19::C8
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h631, _, _) => {
                    h631
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h632, _) => {
                    h632
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h633) => {
                    h633
                }
            }), {
                let m635 = match v1 {
                    Adt24::C0(_, h634, _) => {
                        h634
                    }
                };
                match m635 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v5) => {
                        List::cons(Adt22::C2(v5), List::<Adt22>::nil())
                    }
                }
            })
        }
        Adt17::C4 => {
            f15(v0, match v1 {
                Adt24::C0(h636, _, _) => {
                    h636
                }
            })
        }
    }
}

pub fn f11(v0: Adt16, v1: Adt14) -> R<Adt24> {
    let m638 = match v0.clone() {
        Adt16::C0(_, _, _, _, _, _, _, h637, _, _, _) => {
            h637
        }
    };
    match m638 {
        Adt17::C0 => {
            f16(v0.clone(), v1.clone(), f17(match v0.clone() {
                Adt16::C0(_, _, _, h639, _, _, _, _, _, _, _) => {
                    h639
                }
            }, match v0.clone() {
                Adt16::C0(_, _, _, _, h640, _, _, _, _, _, _) => {
                    h640
                }
            }, Adt25::C0(match v0 {
                Adt16::C0(_, _, h641, _, _, _, _, _, _, _, _) => {
                    h641
                }
            }, match v1 {
                Adt14::C0(_, _, h642) => {
                    h642
                }
            }))?)
        }
        Adt17::C1 => {
            Ok(Adt24::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Adt17::C2 => {
            Ok(Adt24::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Adt17::C3 => {
            Ok(Adt24::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Adt17::C4 => {
            Ok(Adt24::C0(v0, None::<Adt18>, None::<Adt3>))
        }
    }
}

pub fn f12(v0: Adt1, v1: Adt1) -> bool {
    let a645 = match v0.clone() {
        Adt1::C0(h643, _, _) => {
            h643
        }
    };
    let a646 = match v1.clone() {
        Adt1::C0(h644, _, _) => {
            h644
        }
    };
    if nat_eq(a645, a646) {
        let a649 = match v0.clone() {
            Adt1::C0(_, h647, _) => {
                h647
            }
        };
        let a650 = match v1.clone() {
            Adt1::C0(_, h648, _) => {
                h648
            }
        };
        if nat_eq(a649, a650) {
            let a653 = match v0 {
                Adt1::C0(_, _, h651) => {
                    h651
                }
            };
            let a654 = match v1 {
                Adt1::C0(_, _, h652) => {
                    h652
                }
            };
            nat_eq(a653, a654)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f13(v0: Adt3, v1: Adt3) -> bool {
    let a657 = match v0.clone() {
        Adt3::C0(h655, _, _) => {
            h655
        }
    };
    let a658 = match v1.clone() {
        Adt3::C0(h656, _, _) => {
            h656
        }
    };
    if nat_eq(a657, a658) {
        let a661 = match v0.clone() {
            Adt3::C0(_, h659, _) => {
                h659
            }
        };
        let a662 = match v1.clone() {
            Adt3::C0(_, h660, _) => {
                h660
            }
        };
        if nat_eq(a661, a662) {
            let a665 = match v0 {
                Adt3::C0(_, _, h663) => {
                    h663
                }
            };
            let a666 = match v1 {
                Adt3::C0(_, _, h664) => {
                    h664
                }
            };
            nat_eq(a665, a666)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f14(v0: Adt14) -> Option<Adt3> {
    let a668 = match v0.clone() {
        Adt14::C0(_, _, h667) => {
            h667
        }
    };
    let a669 = 0u64;
    if nat_eq(a668, a669) {
        None::<Adt3>
    } else {
        Some(match v0 {
            Adt14::C0(h670, _, _) => {
                h670
            }
        })
    }
}

pub fn f15(v0: Adt0, v1: Adt16) -> Adt21 {
    Adt21::C0(Adt0::C0(match v0.clone() {
        Adt0::C0(h671, _, _, _, _, _, _, _, _, _, _) => {
            h671
        }
    }, match v0.clone() {
        Adt0::C0(_, h672, _, _, _, _, _, _, _, _, _) => {
            h672
        }
    }, match v0.clone() {
        Adt0::C0(_, _, h673, _, _, _, _, _, _, _, _) => {
            h673
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, h674, _, _, _, _, _, _, _) => {
            h674
        }
    }, match v1.clone() {
        Adt16::C0(_, _, _, _, h675, _, _, _, _, _, _) => {
            h675
        }
    }, {
        let m678 = f18(match v0.clone() {
            Adt0::C0(_, _, _, _, _, h677, _, _, _, _, _) => {
                h677
            }
        });
        match m678 {
            Adt23::C0(h676, _, _) => {
                h676
            }
        }
    }, Some(v1), Adt19::C8, match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, _, h679, _, _) => {
            h679
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, _, _, h680, _) => {
            h680
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, _, _, _, h681) => {
            h681
        }
    }), {
        let m685 = {
            let m684 = f18(match v0 {
                Adt0::C0(_, _, _, _, _, h683, _, _, _, _, _) => {
                    h683
                }
            });
            match m684 {
                Adt23::C0(_, _, h682) => {
                    h682
                }
            }
        };
        match m685 {
            None => {
                List::<Adt22>::nil()
            }
            Some(v2) => {
                List::cons(Adt22::C4(v2), List::<Adt22>::nil())
            }
        }
    })
}

pub fn f16(v0: Adt16, v1: Adt14, v2: Adt6) -> R<Adt24> {
    let m687 = match v2.clone() {
        Adt6::C0(_, h686) => {
            h686
        }
    };
    match m687 {
        None => {
            Ok(Adt24::C0(Adt16::C0(match v0.clone() {
                Adt16::C0(h696, _, _, _, _, _, _, _, _, _, _) => {
                    h696
                }
            }, match v0.clone() {
                Adt16::C0(_, h697, _, _, _, _, _, _, _, _, _) => {
                    h697
                }
            }, match v0.clone() {
                Adt16::C0(_, _, h698, _, _, _, _, _, _, _, _) => {
                    h698
                }
            }, match v0.clone() {
                Adt16::C0(_, _, _, h699, _, _, _, _, _, _, _) => {
                    h699
                }
            }, v2, match v0.clone() {
                Adt16::C0(_, _, _, _, _, h700, _, _, _, _, _) => {
                    h700
                }
            }, {
                let a702 = match v0.clone() {
                    Adt16::C0(_, _, _, _, _, _, h701, _, _, _, _) => {
                        h701
                    }
                };
                let a703 = 1u64;
                nat_add(a702, a703)?
            }, Adt17::C1, Some(Adt18::C0(match v0.clone() {
                Adt16::C0(h704, _, _, _, _, _, _, _, _, _, _) => {
                    h704
                }
            }, match v0.clone() {
                Adt16::C0(_, h705, _, _, _, _, _, _, _, _, _) => {
                    h705
                }
            }, {
                let a707 = match v0.clone() {
                    Adt16::C0(_, _, _, _, _, _, h706, _, _, _, _) => {
                        h706
                    }
                };
                let a708 = 1u64;
                nat_add(a707, a708)?
            }, match v0.clone() {
                Adt16::C0(_, _, _, _, _, h709, _, _, _, _, _) => {
                    h709
                }
            }, v1.clone())), Some(v1.clone()), match v0.clone() {
                Adt16::C0(_, _, _, _, _, _, _, _, _, _, h710) => {
                    h710
                }
            }), Some(Adt18::C0(match v0.clone() {
                Adt16::C0(h711, _, _, _, _, _, _, _, _, _, _) => {
                    h711
                }
            }, match v0.clone() {
                Adt16::C0(_, h712, _, _, _, _, _, _, _, _, _) => {
                    h712
                }
            }, {
                let a714 = match v0.clone() {
                    Adt16::C0(_, _, _, _, _, _, h713, _, _, _, _) => {
                        h713
                    }
                };
                let a715 = 1u64;
                nat_add(a714, a715)?
            }, match v0 {
                Adt16::C0(_, _, _, _, _, h716, _, _, _, _, _) => {
                    h716
                }
            }, v1)), None::<Adt3>))
        }
        Some(_) => {
            Ok(Adt24::C0(Adt16::C0(match v0.clone() {
                Adt16::C0(h688, _, _, _, _, _, _, _, _, _, _) => {
                    h688
                }
            }, match v0.clone() {
                Adt16::C0(_, h689, _, _, _, _, _, _, _, _, _) => {
                    h689
                }
            }, match v0.clone() {
                Adt16::C0(_, _, h690, _, _, _, _, _, _, _, _) => {
                    h690
                }
            }, match v0.clone() {
                Adt16::C0(_, _, _, h691, _, _, _, _, _, _, _) => {
                    h691
                }
            }, v2, match v0.clone() {
                Adt16::C0(_, _, _, _, _, h692, _, _, _, _, _) => {
                    h692
                }
            }, match v0.clone() {
                Adt16::C0(_, _, _, _, _, _, h693, _, _, _, _) => {
                    h693
                }
            }, Adt17::C4, match v0.clone() {
                Adt16::C0(_, _, _, _, _, _, _, _, h694, _, _) => {
                    h694
                }
            }, Some(v1), match v0 {
                Adt16::C0(_, _, _, _, _, _, _, _, _, _, h695) => {
                    h695
                }
            }), None::<Adt18>, None::<Adt3>))
        }
    }
}

pub fn f17(v0: Adt5, v1: Adt6, v2: Adt25) -> R<Adt6> {
    let m717 = v2;
    match m717 {
        Adt25::C0(v3, v4) => {
            let m719 = f19(v0, match v1.clone() {
                Adt6::C0(h718, _) => {
                    h718
                }
            }, v3, v4)?;
            match m719 {
                Ok(v6) => {
                    Ok(Adt6::C0(v6, None::<Adt9>))
                }
                Err(v5) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h720, _) => {
                            h720
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt25::C1(v7, v8, v9) => {
            let m722 = f20(match v1.clone() {
                Adt6::C0(h721, _) => {
                    h721
                }
            }, v7, v8, v9)?;
            match m722 {
                Ok(v11) => {
                    Ok(Adt6::C0(v11, None::<Adt9>))
                }
                Err(v10) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h723, _) => {
                            h723
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt25::C2(v12, v13, v14) => {
            let m725 = f20(match v1.clone() {
                Adt6::C0(h724, _) => {
                    h724
                }
            }, v12, v13, v14)?;
            match m725 {
                Ok(v16) => {
                    Ok(Adt6::C0(v16, None::<Adt9>))
                }
                Err(v15) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h726, _) => {
                            h726
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt25::C3(v17, v18) => {
            let m728 = f21(match v1.clone() {
                Adt6::C0(h727, _) => {
                    h727
                }
            }, v17, v18)?;
            match m728 {
                Ok(v20) => {
                    Ok(Adt6::C0(v20, None::<Adt9>))
                }
                Err(v19) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h729, _) => {
                            h729
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt25::C4(v21, v22) => {
            let m731 = f21(match v1.clone() {
                Adt6::C0(h730, _) => {
                    h730
                }
            }, v21, v22)?;
            match m731 {
                Ok(v24) => {
                    Ok(Adt6::C0(v24, None::<Adt9>))
                }
                Err(v23) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h732, _) => {
                            h732
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f18(v0: Adt11) -> Adt23 {
    Adt23::C0(Adt11::C0(match v0.clone() {
        Adt11::C0(h733, _, _, _, _, _, _, _, _, _) => {
            h733
        }
    }, match v0.clone() {
        Adt11::C0(_, h734, _, _, _, _, _, _, _, _) => {
            h734
        }
    }, match v0.clone() {
        Adt11::C0(_, _, h735, _, _, _, _, _, _, _) => {
            h735
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, h736, _, _, _, _, _, _) => {
            h736
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, _, h737, _, _, _, _, _) => {
            h737
        }
    }, {
        let m739 = match v0.clone() {
            Adt11::C0(_, _, _, _, _, _, h738, _, _, _) => {
                h738
            }
        };
        if match m739 {
            None => {
                false
            }
            Some(_) => {
                true
            }
        } {
            Adt12::C2
        } else {
            Adt12::C5
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, _, _, _, h740, _, _, _) => {
            h740
        }
    }, None::<Adt14>, match v0.clone() {
        Adt11::C0(_, _, _, _, _, _, _, _, h741, _) => {
            h741
        }
    }, Some(Adt15::C11)), None::<Adt13>, {
        let m743 = match v0 {
            Adt11::C0(_, _, _, _, _, _, _, h742, _, _) => {
                h742
            }
        };
        match m743 {
            None => {
                None::<Adt3>
            }
            Some(v2) => {
                f14(v2)
            }
        }
    })
}

pub fn f19(v0: Adt5, v1: Adt7, v2: Adt10, v3: u64) -> R<Result<Adt7, Adt9>> {
    if f22(match v0.clone() {
        Adt5::C0(h744, _, _, _, _) => {
            h744
        }
    }, f23(v1.clone())?, v3)? {
        if f22(f24(v0.clone(), v2.clone()), {
            let a747 = f25(match v1.clone() {
                Adt7::C0(h745, _, _, _) => {
                    h745
                }
            }, v2.clone());
            let a748 = f25(match v1.clone() {
                Adt7::C0(_, h746, _, _) => {
                    h746
                }
            }, v2.clone());
            nat_add(a747, a748)?
        }, v3)? {
            Ok(Ok::<Adt7, Adt9>(Adt7::C0(match v1.clone() {
                Adt7::C0(h749, _, _, _) => {
                    h749
                }
            }, f26(match v1.clone() {
                Adt7::C0(_, h750, _, _) => {
                    h750
                }
            }, v2.clone(), {
                let a752 = f25(match v1.clone() {
                    Adt7::C0(_, h751, _, _) => {
                        h751
                    }
                }, v2.clone());
                let a753 = v3;
                nat_add(a752, a753)?
            }), f27(match v1.clone() {
                Adt7::C0(_, _, h754, _) => {
                    h754
                }
            }, f28(match v1.clone() {
                Adt7::C0(h755, _, _, _) => {
                    h755
                }
            })?), f27(match v1.clone() {
                Adt7::C0(_, _, _, h756) => {
                    h756
                }
            }, {
                let a762 = f28(match v1.clone() {
                    Adt7::C0(h757, _, _, _) => {
                        h757
                    }
                })?;
                let a763 = f28(f26(match v1.clone() {
                    Adt7::C0(_, h758, _, _) => {
                        h758
                    }
                }, v2.clone(), {
                    let a760 = f25(match v1 {
                        Adt7::C0(_, h759, _, _) => {
                            h759
                        }
                    }, v2);
                    let a761 = v3;
                    nat_add(a760, a761)?
                }))?;
                nat_add(a762, a763)?
            }))))
        } else {
            Ok(Err::<Adt7, Adt9>(Adt9::C1(v2.clone(), {
                let a766 = f25(match v1.clone() {
                    Adt7::C0(h764, _, _, _) => {
                        h764
                    }
                }, v2.clone());
                let a767 = f25(match v1 {
                    Adt7::C0(_, h765, _, _) => {
                        h765
                    }
                }, v2.clone());
                nat_add(a766, a767)?
            }, v3, {
                let m768 = f24(v0, v2);
                match m768 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C0(f23(v1)?, v3, {
            let m770 = match v0 {
                Adt5::C0(h769, _, _, _, _) => {
                    h769
                }
            };
            match m770 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f20(v0: Adt7, v1: Adt10, v2: u64, v3: u64) -> R<Result<Adt7, Adt9>> {
    let a774 = {
        let a772 = f25(match v0.clone() {
            Adt7::C0(_, h771, _, _) => {
                h771
            }
        }, v1.clone());
        let a773 = v2;
        nat_lt(a772, a773)
    };
    if if bool_not(a774) {
        let a777 = {
            let a775 = v2;
            let a776 = v3;
            nat_lt(a775, a776)
        };
        bool_not(a777)
    } else {
        false
    } {
        Ok(Ok::<Adt7, Adt9>(Adt7::C0(f26(match v0.clone() {
            Adt7::C0(h778, _, _, _) => {
                h778
            }
        }, v1.clone(), {
            let a780 = f25(match v0.clone() {
                Adt7::C0(h779, _, _, _) => {
                    h779
                }
            }, v1.clone());
            let a781 = v3;
            nat_add(a780, a781)?
        }), f26(match v0.clone() {
            Adt7::C0(_, h782, _, _) => {
                h782
            }
        }, v1.clone(), {
            let a784 = f25(match v0.clone() {
                Adt7::C0(_, h783, _, _) => {
                    h783
                }
            }, v1.clone());
            let a785 = v2;
            nat_sub(a784, a785)
        }), f27(match v0.clone() {
            Adt7::C0(_, _, h786, _) => {
                h786
            }
        }, f28(f26(match v0.clone() {
            Adt7::C0(h787, _, _, _) => {
                h787
            }
        }, v1.clone(), {
            let a789 = f25(match v0.clone() {
                Adt7::C0(h788, _, _, _) => {
                    h788
                }
            }, v1.clone());
            let a790 = v3;
            nat_add(a789, a790)?
        }))?), f27(match v0.clone() {
            Adt7::C0(_, _, _, h791) => {
                h791
            }
        }, {
            let a800 = f28(f26(match v0.clone() {
                Adt7::C0(h792, _, _, _) => {
                    h792
                }
            }, v1.clone(), {
                let a794 = f25(match v0.clone() {
                    Adt7::C0(h793, _, _, _) => {
                        h793
                    }
                }, v1.clone());
                let a795 = v3;
                nat_add(a794, a795)?
            }))?;
            let a801 = f28(f26(match v0.clone() {
                Adt7::C0(_, h796, _, _) => {
                    h796
                }
            }, v1.clone(), {
                let a798 = f25(match v0 {
                    Adt7::C0(_, h797, _, _) => {
                        h797
                    }
                }, v1);
                let a799 = v2;
                nat_sub(a798, a799)
            }))?;
            nat_add(a800, a801)?
        }))))
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C2(v1, v2, v3)))
    }
}

pub fn f21(v0: Adt7, v1: Adt10, v2: u64) -> R<Result<Adt7, Adt9>> {
    let a805 = {
        let a803 = f25(match v0.clone() {
            Adt7::C0(h802, _, _, _) => {
                h802
            }
        }, v1.clone());
        let a804 = v2;
        nat_lt(a803, a804)
    };
    if bool_not(a805) {
        Ok(Ok::<Adt7, Adt9>(Adt7::C0(f26(match v0.clone() {
            Adt7::C0(h806, _, _, _) => {
                h806
            }
        }, v1.clone(), {
            let a808 = f25(match v0.clone() {
                Adt7::C0(h807, _, _, _) => {
                    h807
                }
            }, v1.clone());
            let a809 = v2;
            nat_sub(a808, a809)
        }), match v0.clone() {
            Adt7::C0(_, h810, _, _) => {
                h810
            }
        }, f27(match v0.clone() {
            Adt7::C0(_, _, h811, _) => {
                h811
            }
        }, f28(f26(match v0.clone() {
            Adt7::C0(h812, _, _, _) => {
                h812
            }
        }, v1.clone(), {
            let a814 = f25(match v0.clone() {
                Adt7::C0(h813, _, _, _) => {
                    h813
                }
            }, v1.clone());
            let a815 = v2;
            nat_sub(a814, a815)
        }))?), f27(match v0.clone() {
            Adt7::C0(_, _, _, h816) => {
                h816
            }
        }, {
            let a822 = f28(f26(match v0.clone() {
                Adt7::C0(h817, _, _, _) => {
                    h817
                }
            }, v1.clone(), {
                let a819 = f25(match v0.clone() {
                    Adt7::C0(h818, _, _, _) => {
                        h818
                    }
                }, v1);
                let a820 = v2;
                nat_sub(a819, a820)
            }))?;
            let a823 = f28(match v0 {
                Adt7::C0(_, h821, _, _) => {
                    h821
                }
            })?;
            nat_add(a822, a823)?
        }))))
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C3(v1.clone(), f25(match v0 {
            Adt7::C0(h824, _, _, _) => {
                h824
            }
        }, v1), v2)))
    }
}

pub fn f22(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m825 = v0;
    match m825 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a830 = {
                let a828 = v3;
                let a829 = {
                    let a826 = v1;
                    let a827 = v2;
                    nat_add(a826, a827)?
                };
                nat_lt(a828, a829)
            };
            Ok(bool_not(a830))
        }
    }
}

pub fn f23(v0: Adt7) -> R<u64> {
    let a831 = f29(v0.clone())?;
    let a832 = f30(v0)?;
    nat_add(a831, a832)
}

pub fn f24(v0: Adt5, v1: Adt10) -> Option<u64> {
    let m833 = v1;
    match m833 {
        Adt10::C0 => {
            match v0 {
                Adt5::C0(_, h834, _, _, _) => {
                    h834
                }
            }
        }
        Adt10::C1 => {
            match v0 {
                Adt5::C0(_, _, h835, _, _) => {
                    h835
                }
            }
        }
        Adt10::C2 => {
            match v0 {
                Adt5::C0(_, _, _, h836, _) => {
                    h836
                }
            }
        }
        Adt10::C3 => {
            match v0 {
                Adt5::C0(_, _, _, _, h837) => {
                    h837
                }
            }
        }
    }
}

pub fn f25(v0: Adt8, v1: Adt10) -> u64 {
    let m838 = v1;
    match m838 {
        Adt10::C0 => {
            match v0 {
                Adt8::C0(h839, _, _, _) => {
                    h839
                }
            }
        }
        Adt10::C1 => {
            match v0 {
                Adt8::C0(_, h840, _, _) => {
                    h840
                }
            }
        }
        Adt10::C2 => {
            match v0 {
                Adt8::C0(_, _, h841, _) => {
                    h841
                }
            }
        }
        Adt10::C3 => {
            match v0 {
                Adt8::C0(_, _, _, h842) => {
                    h842
                }
            }
        }
    }
}

pub fn f26(v0: Adt8, v1: Adt10, v2: u64) -> Adt8 {
    let m843 = v1;
    match m843 {
        Adt10::C0 => {
            Adt8::C0(v2, match v0.clone() {
                Adt8::C0(_, h844, _, _) => {
                    h844
                }
            }, match v0.clone() {
                Adt8::C0(_, _, h845, _) => {
                    h845
                }
            }, match v0 {
                Adt8::C0(_, _, _, h846) => {
                    h846
                }
            })
        }
        Adt10::C1 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h847, _, _, _) => {
                    h847
                }
            }, v2, match v0.clone() {
                Adt8::C0(_, _, h848, _) => {
                    h848
                }
            }, match v0 {
                Adt8::C0(_, _, _, h849) => {
                    h849
                }
            })
        }
        Adt10::C2 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h850, _, _, _) => {
                    h850
                }
            }, match v0.clone() {
                Adt8::C0(_, h851, _, _) => {
                    h851
                }
            }, v2, match v0 {
                Adt8::C0(_, _, _, h852) => {
                    h852
                }
            })
        }
        Adt10::C3 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h853, _, _, _) => {
                    h853
                }
            }, match v0.clone() {
                Adt8::C0(_, h854, _, _) => {
                    h854
                }
            }, match v0 {
                Adt8::C0(_, _, h855, _) => {
                    h855
                }
            }, v2)
        }
    }
}

pub fn f27(v0: u64, v1: u64) -> u64 {
    let a856 = v0;
    let a857 = v1;
    if nat_lt(a856, a857) {
        v1
    } else {
        v0
    }
}

pub fn f28(v0: Adt8) -> R<u64> {
    let a868 = {
        let a865 = {
            let a862 = {
                let a859 = 0u64;
                let a860 = match v0.clone() {
                    Adt8::C0(h858, _, _, _) => {
                        h858
                    }
                };
                nat_add(a859, a860)?
            };
            let a863 = match v0.clone() {
                Adt8::C0(_, h861, _, _) => {
                    h861
                }
            };
            nat_add(a862, a863)?
        };
        let a866 = match v0.clone() {
            Adt8::C0(_, _, h864, _) => {
                h864
            }
        };
        nat_add(a865, a866)?
    };
    let a869 = match v0 {
        Adt8::C0(_, _, _, h867) => {
            h867
        }
    };
    nat_add(a868, a869)
}

pub fn f29(v0: Adt7) -> R<u64> {
    f28(match v0 {
        Adt7::C0(h870, _, _, _) => {
            h870
        }
    })
}

pub fn f30(v0: Adt7) -> R<u64> {
    f28(match v0 {
        Adt7::C0(_, h871, _, _) => {
            h871
        }
    })
}
