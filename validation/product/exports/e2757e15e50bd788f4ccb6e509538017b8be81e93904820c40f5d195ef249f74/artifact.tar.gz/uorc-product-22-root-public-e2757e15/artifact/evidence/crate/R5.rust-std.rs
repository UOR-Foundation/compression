#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt2, u64, u64, u64, Adt5, Option<Adt6>, Option<Adt7>, bool, Option<Adt8>),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt3, Option<u64>, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt5 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt1, Adt3, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt7 {
    C0(Adt3, u64, u64),
}

#[derive(Clone)]
pub enum Adt8 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
}

#[derive(Clone)]
pub enum Adt9 {
    C0(Adt1, Adt3, u64, u64, Option<Adt7>, bool, bool),
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt0, Option<Adt6>, Option<Adt3>),
}

pub fn f0(v0: Adt0, v1: Adt9) -> R<Adt10> {
    let m2 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, h1, _, _, _, _) => {
            h1
        }
    };
    match m2 {
        Adt5::C0 => {
            if f1(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt9::C0(_, _, _, _, _, _, h3) => {
                        h3
                    }
                } {
                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h4, _, _, _, _, _, _, _, _, _) => {
                            h4
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h5, _, _, _, _, _, _, _, _) => {
                            h5
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h6, _, _, _, _, _, _, _) => {
                            h6
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h7, _, _, _, _, _, _) => {
                            h7
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h8, _, _, _, _, _) => {
                            h8
                        }
                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h9, _) => {
                            h9
                        }
                    }, Some(Adt8::C7)), None::<Adt6>, f2(v0, v1)))
                } else {
                    let a20 = {
                        let m11 = match v1.clone() {
                            Adt9::C0(_, _, _, _, h10, _, _) => {
                                h10
                            }
                        };
                        match m11 {
                            None => {
                                true
                            }
                            Some(v2) => {
                                let a18 = {
                                    let m14 = match v2 {
                                        Adt7::C0(h13, _, _) => {
                                            h13
                                        }
                                    };
                                    match m14 {
                                        Adt3::C0(h12, _, _) => {
                                            h12
                                        }
                                    }
                                };
                                let a19 = {
                                    let m17 = match v0.clone() {
                                        Adt0::C0(h16, _, _, _, _, _, _, _, _, _) => {
                                            h16
                                        }
                                    };
                                    match m17 {
                                        Adt1::C0(h15, _, _) => {
                                            h15
                                        }
                                    }
                                };
                                nat_eq(a18, a19)
                            }
                        }
                    };
                    if bool_not(a20) {
                        Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h21, _, _, _, _, _, _, _, _, _) => {
                                h21
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h22, _, _, _, _, _, _, _, _) => {
                                h22
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h23, _, _, _, _, _, _, _) => {
                                h23
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h24, _, _, _, _, _, _) => {
                                h24
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h25, _, _, _, _, _) => {
                                h25
                            }
                        }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, h26, _) => {
                                h26
                            }
                        }, Some(Adt8::C1)), None::<Adt6>, f2(v0, v1)))
                    } else {
                        let a27 = f3(v0.clone());
                        let a28 = f4(v1.clone());
                        if nat_lt(a27, a28) {
                            Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                Adt0::C0(h29, _, _, _, _, _, _, _, _, _) => {
                                    h29
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, h30, _, _, _, _, _, _, _, _) => {
                                    h30
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, h31, _, _, _, _, _, _, _) => {
                                    h31
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h32, _, _, _, _, _, _) => {
                                    h32
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h33, _, _, _, _, _) => {
                                    h33
                                }
                            }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, _, _, h34, _) => {
                                    h34
                                }
                            }, Some(Adt8::C4)), None::<Adt6>, f2(v0, v1)))
                        } else {
                            let a35 = f5(v0.clone(), v1.clone())?;
                            if bool_not(a35) {
                                Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                    Adt0::C0(h36, _, _, _, _, _, _, _, _, _) => {
                                        h36
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, h37, _, _, _, _, _, _, _, _) => {
                                        h37
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, h38, _, _, _, _, _, _, _) => {
                                        h38
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, h39, _, _, _, _, _, _) => {
                                        h39
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, _, h40, _, _, _, _, _) => {
                                        h40
                                    }
                                }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                    Adt0::C0(_, _, _, _, _, _, _, _, h41, _) => {
                                        h41
                                    }
                                }, Some(Adt8::C5)), None::<Adt6>, f2(v0, v1)))
                            } else {
                                let a42 = f4(v1.clone());
                                let a43 = 0u64;
                                if if nat_eq(a42, a43) {
                                    let a45 = match v1.clone() {
                                        Adt9::C0(_, _, _, _, _, h44, _) => {
                                            h44
                                        }
                                    };
                                    bool_not(a45)
                                } else {
                                    false
                                } {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h46, _, _, _, _, _, _, _, _, _) => {
                                            h46
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h47, _, _, _, _, _, _, _, _) => {
                                            h47
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h48, _, _, _, _, _, _, _) => {
                                            h48
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, h49, _, _, _, _, _, _) => {
                                            h49
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, _, h50, _, _, _, _, _) => {
                                            h50
                                        }
                                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                        Adt0::C0(_, _, _, _, _, _, _, _, h51, _) => {
                                            h51
                                        }
                                    }, Some(Adt8::C6)), None::<Adt6>, f2(v0, v1)))
                                } else {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h52, _, _, _, _, _, _, _, _, _) => {
                                            h52
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h53, _, _, _, _, _, _, _, _) => {
                                            h53
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h54, _, _, _, _, _, _, _) => {
                                            h54
                                        }
                                    }, {
                                        let a56 = match v0.clone() {
                                            Adt0::C0(_, _, _, h55, _, _, _, _, _, _) => {
                                                h55
                                            }
                                        };
                                        let a57 = f4(v1.clone());
                                        nat_add(a56, a57)?
                                    }, match v0 {
                                        Adt0::C0(_, _, _, _, h58, _, _, _, _, _) => {
                                            h58
                                        }
                                    }, {
                                        let a59 = f4(v1.clone());
                                        let a60 = 0u64;
                                        if nat_eq(a59, a60) {
                                            Adt5::C4
                                        } else {
                                            Adt5::C3
                                        }
                                    }, None::<Adt6>, {
                                        let a61 = f4(v1.clone());
                                        let a62 = 0u64;
                                        if nat_eq(a61, a62) {
                                            None::<Adt7>
                                        } else {
                                            match v1.clone() {
                                                Adt9::C0(_, _, _, _, h63, _, _) => {
                                                    h63
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt9::C0(_, _, _, _, _, h64, _) => {
                                            h64
                                        }
                                    }, None::<Adt8>), None::<Adt6>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt10::C0(v0.clone(), None::<Adt6>, f2(v0, v1)))
            }
        }
        Adt5::C1 => {
            if f1(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt9::C0(_, _, _, _, _, _, h65) => {
                        h65
                    }
                } {
                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h66, _, _, _, _, _, _, _, _, _) => {
                            h66
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h67, _, _, _, _, _, _, _, _) => {
                            h67
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h68, _, _, _, _, _, _, _) => {
                            h68
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h69, _, _, _, _, _, _) => {
                            h69
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h70, _, _, _, _, _) => {
                            h70
                        }
                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h71, _) => {
                            h71
                        }
                    }, Some(Adt8::C7)), None::<Adt6>, f2(v0, v1)))
                } else {
                    let a82 = {
                        let m73 = match v1.clone() {
                            Adt9::C0(_, _, _, _, h72, _, _) => {
                                h72
                            }
                        };
                        match m73 {
                            None => {
                                true
                            }
                            Some(v3) => {
                                let a80 = {
                                    let m76 = match v3 {
                                        Adt7::C0(h75, _, _) => {
                                            h75
                                        }
                                    };
                                    match m76 {
                                        Adt3::C0(h74, _, _) => {
                                            h74
                                        }
                                    }
                                };
                                let a81 = {
                                    let m79 = match v0.clone() {
                                        Adt0::C0(h78, _, _, _, _, _, _, _, _, _) => {
                                            h78
                                        }
                                    };
                                    match m79 {
                                        Adt1::C0(h77, _, _) => {
                                            h77
                                        }
                                    }
                                };
                                nat_eq(a80, a81)
                            }
                        }
                    };
                    if bool_not(a82) {
                        Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h83, _, _, _, _, _, _, _, _, _) => {
                                h83
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h84, _, _, _, _, _, _, _, _) => {
                                h84
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h85, _, _, _, _, _, _, _) => {
                                h85
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h86, _, _, _, _, _, _) => {
                                h86
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h87, _, _, _, _, _) => {
                                h87
                            }
                        }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, h88, _) => {
                                h88
                            }
                        }, Some(Adt8::C1)), None::<Adt6>, f2(v0, v1)))
                    } else {
                        let a89 = f3(v0.clone());
                        let a90 = f4(v1.clone());
                        if nat_lt(a89, a90) {
                            Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                Adt0::C0(h91, _, _, _, _, _, _, _, _, _) => {
                                    h91
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, h92, _, _, _, _, _, _, _, _) => {
                                    h92
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, h93, _, _, _, _, _, _, _) => {
                                    h93
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h94, _, _, _, _, _, _) => {
                                    h94
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h95, _, _, _, _, _) => {
                                    h95
                                }
                            }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, _, _, h96, _) => {
                                    h96
                                }
                            }, Some(Adt8::C4)), None::<Adt6>, f2(v0, v1)))
                        } else {
                            let a97 = f5(v0.clone(), v1.clone())?;
                            if bool_not(a97) {
                                Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                    Adt0::C0(h98, _, _, _, _, _, _, _, _, _) => {
                                        h98
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, h99, _, _, _, _, _, _, _, _) => {
                                        h99
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, h100, _, _, _, _, _, _, _) => {
                                        h100
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, h101, _, _, _, _, _, _) => {
                                        h101
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, _, h102, _, _, _, _, _) => {
                                        h102
                                    }
                                }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                    Adt0::C0(_, _, _, _, _, _, _, _, h103, _) => {
                                        h103
                                    }
                                }, Some(Adt8::C5)), None::<Adt6>, f2(v0, v1)))
                            } else {
                                let a104 = f4(v1.clone());
                                let a105 = 0u64;
                                if if nat_eq(a104, a105) {
                                    let a107 = match v1.clone() {
                                        Adt9::C0(_, _, _, _, _, h106, _) => {
                                            h106
                                        }
                                    };
                                    bool_not(a107)
                                } else {
                                    false
                                } {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h108, _, _, _, _, _, _, _, _, _) => {
                                            h108
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h109, _, _, _, _, _, _, _, _) => {
                                            h109
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h110, _, _, _, _, _, _, _) => {
                                            h110
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, h111, _, _, _, _, _, _) => {
                                            h111
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, _, h112, _, _, _, _, _) => {
                                            h112
                                        }
                                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                        Adt0::C0(_, _, _, _, _, _, _, _, h113, _) => {
                                            h113
                                        }
                                    }, Some(Adt8::C6)), None::<Adt6>, f2(v0, v1)))
                                } else {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h114, _, _, _, _, _, _, _, _, _) => {
                                            h114
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h115, _, _, _, _, _, _, _, _) => {
                                            h115
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h116, _, _, _, _, _, _, _) => {
                                            h116
                                        }
                                    }, {
                                        let a118 = match v0.clone() {
                                            Adt0::C0(_, _, _, h117, _, _, _, _, _, _) => {
                                                h117
                                            }
                                        };
                                        let a119 = f4(v1.clone());
                                        nat_add(a118, a119)?
                                    }, match v0 {
                                        Adt0::C0(_, _, _, _, h120, _, _, _, _, _) => {
                                            h120
                                        }
                                    }, {
                                        let a121 = f4(v1.clone());
                                        let a122 = 0u64;
                                        if nat_eq(a121, a122) {
                                            Adt5::C4
                                        } else {
                                            Adt5::C3
                                        }
                                    }, None::<Adt6>, {
                                        let a123 = f4(v1.clone());
                                        let a124 = 0u64;
                                        if nat_eq(a123, a124) {
                                            None::<Adt7>
                                        } else {
                                            match v1.clone() {
                                                Adt9::C0(_, _, _, _, h125, _, _) => {
                                                    h125
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt9::C0(_, _, _, _, _, h126, _) => {
                                            h126
                                        }
                                    }, None::<Adt8>), None::<Adt6>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt10::C0(v0.clone(), None::<Adt6>, f2(v0, v1)))
            }
        }
        Adt5::C2 => {
            if f1(v0.clone(), v1.clone()) {
                Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                    Adt0::C0(h127, _, _, _, _, _, _, _, _, _) => {
                        h127
                    }
                }, match v0.clone() {
                    Adt0::C0(_, h128, _, _, _, _, _, _, _, _) => {
                        h128
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, h129, _, _, _, _, _, _, _) => {
                        h129
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, h130, _, _, _, _, _, _) => {
                        h130
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, h131, _, _, _, _, _) => {
                        h131
                    }
                }, Adt5::C5, None::<Adt6>, None::<Adt7>, match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, _, _, h132, _) => {
                        h132
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, _, _, _, h133) => {
                        h133
                    }
                }), None::<Adt6>, f2(v0, v1)))
            } else {
                Ok(Adt10::C0(v0.clone(), None::<Adt6>, f2(v0, v1)))
            }
        }
        Adt5::C3 => {
            if f1(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt9::C0(_, _, _, _, _, _, h134) => {
                        h134
                    }
                } {
                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h135, _, _, _, _, _, _, _, _, _) => {
                            h135
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h136, _, _, _, _, _, _, _, _) => {
                            h136
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h137, _, _, _, _, _, _, _) => {
                            h137
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h138, _, _, _, _, _, _) => {
                            h138
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h139, _, _, _, _, _) => {
                            h139
                        }
                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h140, _) => {
                            h140
                        }
                    }, Some(Adt8::C7)), None::<Adt6>, f2(v0, v1)))
                } else {
                    let a151 = {
                        let m142 = match v1.clone() {
                            Adt9::C0(_, _, _, _, h141, _, _) => {
                                h141
                            }
                        };
                        match m142 {
                            None => {
                                true
                            }
                            Some(v4) => {
                                let a149 = {
                                    let m145 = match v4 {
                                        Adt7::C0(h144, _, _) => {
                                            h144
                                        }
                                    };
                                    match m145 {
                                        Adt3::C0(h143, _, _) => {
                                            h143
                                        }
                                    }
                                };
                                let a150 = {
                                    let m148 = match v0.clone() {
                                        Adt0::C0(h147, _, _, _, _, _, _, _, _, _) => {
                                            h147
                                        }
                                    };
                                    match m148 {
                                        Adt1::C0(h146, _, _) => {
                                            h146
                                        }
                                    }
                                };
                                nat_eq(a149, a150)
                            }
                        }
                    };
                    if bool_not(a151) {
                        Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h152, _, _, _, _, _, _, _, _, _) => {
                                h152
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h153, _, _, _, _, _, _, _, _) => {
                                h153
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h154, _, _, _, _, _, _, _) => {
                                h154
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h155, _, _, _, _, _, _) => {
                                h155
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h156, _, _, _, _, _) => {
                                h156
                            }
                        }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, h157, _) => {
                                h157
                            }
                        }, Some(Adt8::C1)), None::<Adt6>, f2(v0, v1)))
                    } else {
                        let a158 = f3(v0.clone());
                        let a159 = f4(v1.clone());
                        if nat_lt(a158, a159) {
                            Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                Adt0::C0(h160, _, _, _, _, _, _, _, _, _) => {
                                    h160
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, h161, _, _, _, _, _, _, _, _) => {
                                    h161
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, h162, _, _, _, _, _, _, _) => {
                                    h162
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h163, _, _, _, _, _, _) => {
                                    h163
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h164, _, _, _, _, _) => {
                                    h164
                                }
                            }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, _, _, h165, _) => {
                                    h165
                                }
                            }, Some(Adt8::C4)), None::<Adt6>, f2(v0, v1)))
                        } else {
                            let a166 = f5(v0.clone(), v1.clone())?;
                            if bool_not(a166) {
                                Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                    Adt0::C0(h167, _, _, _, _, _, _, _, _, _) => {
                                        h167
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, h168, _, _, _, _, _, _, _, _) => {
                                        h168
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, h169, _, _, _, _, _, _, _) => {
                                        h169
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, h170, _, _, _, _, _, _) => {
                                        h170
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, _, h171, _, _, _, _, _) => {
                                        h171
                                    }
                                }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                    Adt0::C0(_, _, _, _, _, _, _, _, h172, _) => {
                                        h172
                                    }
                                }, Some(Adt8::C5)), None::<Adt6>, f2(v0, v1)))
                            } else {
                                let a173 = f4(v1.clone());
                                let a174 = 0u64;
                                if if nat_eq(a173, a174) {
                                    let a176 = match v1.clone() {
                                        Adt9::C0(_, _, _, _, _, h175, _) => {
                                            h175
                                        }
                                    };
                                    bool_not(a176)
                                } else {
                                    false
                                } {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h177, _, _, _, _, _, _, _, _, _) => {
                                            h177
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h178, _, _, _, _, _, _, _, _) => {
                                            h178
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h179, _, _, _, _, _, _, _) => {
                                            h179
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, h180, _, _, _, _, _, _) => {
                                            h180
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, _, h181, _, _, _, _, _) => {
                                            h181
                                        }
                                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                        Adt0::C0(_, _, _, _, _, _, _, _, h182, _) => {
                                            h182
                                        }
                                    }, Some(Adt8::C6)), None::<Adt6>, f2(v0, v1)))
                                } else {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h183, _, _, _, _, _, _, _, _, _) => {
                                            h183
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h184, _, _, _, _, _, _, _, _) => {
                                            h184
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h185, _, _, _, _, _, _, _) => {
                                            h185
                                        }
                                    }, {
                                        let a187 = match v0.clone() {
                                            Adt0::C0(_, _, _, h186, _, _, _, _, _, _) => {
                                                h186
                                            }
                                        };
                                        let a188 = f4(v1.clone());
                                        nat_add(a187, a188)?
                                    }, match v0 {
                                        Adt0::C0(_, _, _, _, h189, _, _, _, _, _) => {
                                            h189
                                        }
                                    }, {
                                        let a190 = f4(v1.clone());
                                        let a191 = 0u64;
                                        if nat_eq(a190, a191) {
                                            Adt5::C4
                                        } else {
                                            Adt5::C3
                                        }
                                    }, None::<Adt6>, {
                                        let a192 = f4(v1.clone());
                                        let a193 = 0u64;
                                        if nat_eq(a192, a193) {
                                            None::<Adt7>
                                        } else {
                                            match v1.clone() {
                                                Adt9::C0(_, _, _, _, h194, _, _) => {
                                                    h194
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt9::C0(_, _, _, _, _, h195, _) => {
                                            h195
                                        }
                                    }, None::<Adt8>), None::<Adt6>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt10::C0(v0.clone(), None::<Adt6>, f2(v0, v1)))
            }
        }
        Adt5::C4 => {
            if f1(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt9::C0(_, _, _, _, _, _, h196) => {
                        h196
                    }
                } {
                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h197, _, _, _, _, _, _, _, _, _) => {
                            h197
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h198, _, _, _, _, _, _, _, _) => {
                            h198
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h199, _, _, _, _, _, _, _) => {
                            h199
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h200, _, _, _, _, _, _) => {
                            h200
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h201, _, _, _, _, _) => {
                            h201
                        }
                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h202, _) => {
                            h202
                        }
                    }, Some(Adt8::C7)), None::<Adt6>, f2(v0, v1)))
                } else {
                    let a213 = {
                        let m204 = match v1.clone() {
                            Adt9::C0(_, _, _, _, h203, _, _) => {
                                h203
                            }
                        };
                        match m204 {
                            None => {
                                true
                            }
                            Some(v5) => {
                                let a211 = {
                                    let m207 = match v5 {
                                        Adt7::C0(h206, _, _) => {
                                            h206
                                        }
                                    };
                                    match m207 {
                                        Adt3::C0(h205, _, _) => {
                                            h205
                                        }
                                    }
                                };
                                let a212 = {
                                    let m210 = match v0.clone() {
                                        Adt0::C0(h209, _, _, _, _, _, _, _, _, _) => {
                                            h209
                                        }
                                    };
                                    match m210 {
                                        Adt1::C0(h208, _, _) => {
                                            h208
                                        }
                                    }
                                };
                                nat_eq(a211, a212)
                            }
                        }
                    };
                    if bool_not(a213) {
                        Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h214, _, _, _, _, _, _, _, _, _) => {
                                h214
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h215, _, _, _, _, _, _, _, _) => {
                                h215
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h216, _, _, _, _, _, _, _) => {
                                h216
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h217, _, _, _, _, _, _) => {
                                h217
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h218, _, _, _, _, _) => {
                                h218
                            }
                        }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, h219, _) => {
                                h219
                            }
                        }, Some(Adt8::C1)), None::<Adt6>, f2(v0, v1)))
                    } else {
                        let a220 = f3(v0.clone());
                        let a221 = f4(v1.clone());
                        if nat_lt(a220, a221) {
                            Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                Adt0::C0(h222, _, _, _, _, _, _, _, _, _) => {
                                    h222
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, h223, _, _, _, _, _, _, _, _) => {
                                    h223
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, h224, _, _, _, _, _, _, _) => {
                                    h224
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h225, _, _, _, _, _, _) => {
                                    h225
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h226, _, _, _, _, _) => {
                                    h226
                                }
                            }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, _, _, h227, _) => {
                                    h227
                                }
                            }, Some(Adt8::C4)), None::<Adt6>, f2(v0, v1)))
                        } else {
                            let a228 = f5(v0.clone(), v1.clone())?;
                            if bool_not(a228) {
                                Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                    Adt0::C0(h229, _, _, _, _, _, _, _, _, _) => {
                                        h229
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, h230, _, _, _, _, _, _, _, _) => {
                                        h230
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, h231, _, _, _, _, _, _, _) => {
                                        h231
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, h232, _, _, _, _, _, _) => {
                                        h232
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, _, h233, _, _, _, _, _) => {
                                        h233
                                    }
                                }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                    Adt0::C0(_, _, _, _, _, _, _, _, h234, _) => {
                                        h234
                                    }
                                }, Some(Adt8::C5)), None::<Adt6>, f2(v0, v1)))
                            } else {
                                let a235 = f4(v1.clone());
                                let a236 = 0u64;
                                if if nat_eq(a235, a236) {
                                    let a238 = match v1.clone() {
                                        Adt9::C0(_, _, _, _, _, h237, _) => {
                                            h237
                                        }
                                    };
                                    bool_not(a238)
                                } else {
                                    false
                                } {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h239, _, _, _, _, _, _, _, _, _) => {
                                            h239
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h240, _, _, _, _, _, _, _, _) => {
                                            h240
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h241, _, _, _, _, _, _, _) => {
                                            h241
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, h242, _, _, _, _, _, _) => {
                                            h242
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, _, h243, _, _, _, _, _) => {
                                            h243
                                        }
                                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                        Adt0::C0(_, _, _, _, _, _, _, _, h244, _) => {
                                            h244
                                        }
                                    }, Some(Adt8::C6)), None::<Adt6>, f2(v0, v1)))
                                } else {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h245, _, _, _, _, _, _, _, _, _) => {
                                            h245
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h246, _, _, _, _, _, _, _, _) => {
                                            h246
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h247, _, _, _, _, _, _, _) => {
                                            h247
                                        }
                                    }, {
                                        let a249 = match v0.clone() {
                                            Adt0::C0(_, _, _, h248, _, _, _, _, _, _) => {
                                                h248
                                            }
                                        };
                                        let a250 = f4(v1.clone());
                                        nat_add(a249, a250)?
                                    }, match v0 {
                                        Adt0::C0(_, _, _, _, h251, _, _, _, _, _) => {
                                            h251
                                        }
                                    }, {
                                        let a252 = f4(v1.clone());
                                        let a253 = 0u64;
                                        if nat_eq(a252, a253) {
                                            Adt5::C4
                                        } else {
                                            Adt5::C3
                                        }
                                    }, None::<Adt6>, {
                                        let a254 = f4(v1.clone());
                                        let a255 = 0u64;
                                        if nat_eq(a254, a255) {
                                            None::<Adt7>
                                        } else {
                                            match v1.clone() {
                                                Adt9::C0(_, _, _, _, h256, _, _) => {
                                                    h256
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt9::C0(_, _, _, _, _, h257, _) => {
                                            h257
                                        }
                                    }, None::<Adt8>), None::<Adt6>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt10::C0(v0.clone(), None::<Adt6>, f2(v0, v1)))
            }
        }
        Adt5::C5 => {
            if f1(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt9::C0(_, _, _, _, _, _, h258) => {
                        h258
                    }
                } {
                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h259, _, _, _, _, _, _, _, _, _) => {
                            h259
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h260, _, _, _, _, _, _, _, _) => {
                            h260
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h261, _, _, _, _, _, _, _) => {
                            h261
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h262, _, _, _, _, _, _) => {
                            h262
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h263, _, _, _, _, _) => {
                            h263
                        }
                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h264, _) => {
                            h264
                        }
                    }, Some(Adt8::C7)), None::<Adt6>, f2(v0, v1)))
                } else {
                    let a275 = {
                        let m266 = match v1.clone() {
                            Adt9::C0(_, _, _, _, h265, _, _) => {
                                h265
                            }
                        };
                        match m266 {
                            None => {
                                true
                            }
                            Some(v6) => {
                                let a273 = {
                                    let m269 = match v6 {
                                        Adt7::C0(h268, _, _) => {
                                            h268
                                        }
                                    };
                                    match m269 {
                                        Adt3::C0(h267, _, _) => {
                                            h267
                                        }
                                    }
                                };
                                let a274 = {
                                    let m272 = match v0.clone() {
                                        Adt0::C0(h271, _, _, _, _, _, _, _, _, _) => {
                                            h271
                                        }
                                    };
                                    match m272 {
                                        Adt1::C0(h270, _, _) => {
                                            h270
                                        }
                                    }
                                };
                                nat_eq(a273, a274)
                            }
                        }
                    };
                    if bool_not(a275) {
                        Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h276, _, _, _, _, _, _, _, _, _) => {
                                h276
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h277, _, _, _, _, _, _, _, _) => {
                                h277
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h278, _, _, _, _, _, _, _) => {
                                h278
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h279, _, _, _, _, _, _) => {
                                h279
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h280, _, _, _, _, _) => {
                                h280
                            }
                        }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, h281, _) => {
                                h281
                            }
                        }, Some(Adt8::C1)), None::<Adt6>, f2(v0, v1)))
                    } else {
                        let a282 = f3(v0.clone());
                        let a283 = f4(v1.clone());
                        if nat_lt(a282, a283) {
                            Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                Adt0::C0(h284, _, _, _, _, _, _, _, _, _) => {
                                    h284
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, h285, _, _, _, _, _, _, _, _) => {
                                    h285
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, h286, _, _, _, _, _, _, _) => {
                                    h286
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h287, _, _, _, _, _, _) => {
                                    h287
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h288, _, _, _, _, _) => {
                                    h288
                                }
                            }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, _, _, h289, _) => {
                                    h289
                                }
                            }, Some(Adt8::C4)), None::<Adt6>, f2(v0, v1)))
                        } else {
                            let a290 = f5(v0.clone(), v1.clone())?;
                            if bool_not(a290) {
                                Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                    Adt0::C0(h291, _, _, _, _, _, _, _, _, _) => {
                                        h291
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, h292, _, _, _, _, _, _, _, _) => {
                                        h292
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, h293, _, _, _, _, _, _, _) => {
                                        h293
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, h294, _, _, _, _, _, _) => {
                                        h294
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, _, h295, _, _, _, _, _) => {
                                        h295
                                    }
                                }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                    Adt0::C0(_, _, _, _, _, _, _, _, h296, _) => {
                                        h296
                                    }
                                }, Some(Adt8::C5)), None::<Adt6>, f2(v0, v1)))
                            } else {
                                let a297 = f4(v1.clone());
                                let a298 = 0u64;
                                if if nat_eq(a297, a298) {
                                    let a300 = match v1.clone() {
                                        Adt9::C0(_, _, _, _, _, h299, _) => {
                                            h299
                                        }
                                    };
                                    bool_not(a300)
                                } else {
                                    false
                                } {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h301, _, _, _, _, _, _, _, _, _) => {
                                            h301
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h302, _, _, _, _, _, _, _, _) => {
                                            h302
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h303, _, _, _, _, _, _, _) => {
                                            h303
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, h304, _, _, _, _, _, _) => {
                                            h304
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, _, h305, _, _, _, _, _) => {
                                            h305
                                        }
                                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                        Adt0::C0(_, _, _, _, _, _, _, _, h306, _) => {
                                            h306
                                        }
                                    }, Some(Adt8::C6)), None::<Adt6>, f2(v0, v1)))
                                } else {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h307, _, _, _, _, _, _, _, _, _) => {
                                            h307
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h308, _, _, _, _, _, _, _, _) => {
                                            h308
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h309, _, _, _, _, _, _, _) => {
                                            h309
                                        }
                                    }, {
                                        let a311 = match v0.clone() {
                                            Adt0::C0(_, _, _, h310, _, _, _, _, _, _) => {
                                                h310
                                            }
                                        };
                                        let a312 = f4(v1.clone());
                                        nat_add(a311, a312)?
                                    }, match v0 {
                                        Adt0::C0(_, _, _, _, h313, _, _, _, _, _) => {
                                            h313
                                        }
                                    }, {
                                        let a314 = f4(v1.clone());
                                        let a315 = 0u64;
                                        if nat_eq(a314, a315) {
                                            Adt5::C4
                                        } else {
                                            Adt5::C3
                                        }
                                    }, None::<Adt6>, {
                                        let a316 = f4(v1.clone());
                                        let a317 = 0u64;
                                        if nat_eq(a316, a317) {
                                            None::<Adt7>
                                        } else {
                                            match v1.clone() {
                                                Adt9::C0(_, _, _, _, h318, _, _) => {
                                                    h318
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt9::C0(_, _, _, _, _, h319, _) => {
                                            h319
                                        }
                                    }, None::<Adt8>), None::<Adt6>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt10::C0(v0.clone(), None::<Adt6>, f2(v0, v1)))
            }
        }
        Adt5::C6 => {
            if f1(v0.clone(), v1.clone()) {
                if match v1.clone() {
                    Adt9::C0(_, _, _, _, _, _, h320) => {
                        h320
                    }
                } {
                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h321, _, _, _, _, _, _, _, _, _) => {
                            h321
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h322, _, _, _, _, _, _, _, _) => {
                            h322
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h323, _, _, _, _, _, _, _) => {
                            h323
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h324, _, _, _, _, _, _) => {
                            h324
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h325, _, _, _, _, _) => {
                            h325
                        }
                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h326, _) => {
                            h326
                        }
                    }, Some(Adt8::C7)), None::<Adt6>, f2(v0, v1)))
                } else {
                    let a337 = {
                        let m328 = match v1.clone() {
                            Adt9::C0(_, _, _, _, h327, _, _) => {
                                h327
                            }
                        };
                        match m328 {
                            None => {
                                true
                            }
                            Some(v7) => {
                                let a335 = {
                                    let m331 = match v7 {
                                        Adt7::C0(h330, _, _) => {
                                            h330
                                        }
                                    };
                                    match m331 {
                                        Adt3::C0(h329, _, _) => {
                                            h329
                                        }
                                    }
                                };
                                let a336 = {
                                    let m334 = match v0.clone() {
                                        Adt0::C0(h333, _, _, _, _, _, _, _, _, _) => {
                                            h333
                                        }
                                    };
                                    match m334 {
                                        Adt1::C0(h332, _, _) => {
                                            h332
                                        }
                                    }
                                };
                                nat_eq(a335, a336)
                            }
                        }
                    };
                    if bool_not(a337) {
                        Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h338, _, _, _, _, _, _, _, _, _) => {
                                h338
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h339, _, _, _, _, _, _, _, _) => {
                                h339
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h340, _, _, _, _, _, _, _) => {
                                h340
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h341, _, _, _, _, _, _) => {
                                h341
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h342, _, _, _, _, _) => {
                                h342
                            }
                        }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, h343, _) => {
                                h343
                            }
                        }, Some(Adt8::C1)), None::<Adt6>, f2(v0, v1)))
                    } else {
                        let a344 = f3(v0.clone());
                        let a345 = f4(v1.clone());
                        if nat_lt(a344, a345) {
                            Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                Adt0::C0(h346, _, _, _, _, _, _, _, _, _) => {
                                    h346
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, h347, _, _, _, _, _, _, _, _) => {
                                    h347
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, h348, _, _, _, _, _, _, _) => {
                                    h348
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h349, _, _, _, _, _, _) => {
                                    h349
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h350, _, _, _, _, _) => {
                                    h350
                                }
                            }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, _, _, h351, _) => {
                                    h351
                                }
                            }, Some(Adt8::C4)), None::<Adt6>, f2(v0, v1)))
                        } else {
                            let a352 = f5(v0.clone(), v1.clone())?;
                            if bool_not(a352) {
                                Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                    Adt0::C0(h353, _, _, _, _, _, _, _, _, _) => {
                                        h353
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, h354, _, _, _, _, _, _, _, _) => {
                                        h354
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, h355, _, _, _, _, _, _, _) => {
                                        h355
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, h356, _, _, _, _, _, _) => {
                                        h356
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, _, h357, _, _, _, _, _) => {
                                        h357
                                    }
                                }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                    Adt0::C0(_, _, _, _, _, _, _, _, h358, _) => {
                                        h358
                                    }
                                }, Some(Adt8::C5)), None::<Adt6>, f2(v0, v1)))
                            } else {
                                let a359 = f4(v1.clone());
                                let a360 = 0u64;
                                if if nat_eq(a359, a360) {
                                    let a362 = match v1.clone() {
                                        Adt9::C0(_, _, _, _, _, h361, _) => {
                                            h361
                                        }
                                    };
                                    bool_not(a362)
                                } else {
                                    false
                                } {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h363, _, _, _, _, _, _, _, _, _) => {
                                            h363
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h364, _, _, _, _, _, _, _, _) => {
                                            h364
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h365, _, _, _, _, _, _, _) => {
                                            h365
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, h366, _, _, _, _, _, _) => {
                                            h366
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, _, _, h367, _, _, _, _, _) => {
                                            h367
                                        }
                                    }, Adt5::C6, None::<Adt6>, None::<Adt7>, match v0.clone() {
                                        Adt0::C0(_, _, _, _, _, _, _, _, h368, _) => {
                                            h368
                                        }
                                    }, Some(Adt8::C6)), None::<Adt6>, f2(v0, v1)))
                                } else {
                                    Ok(Adt10::C0(Adt0::C0(match v0.clone() {
                                        Adt0::C0(h369, _, _, _, _, _, _, _, _, _) => {
                                            h369
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, h370, _, _, _, _, _, _, _, _) => {
                                            h370
                                        }
                                    }, match v0.clone() {
                                        Adt0::C0(_, _, h371, _, _, _, _, _, _, _) => {
                                            h371
                                        }
                                    }, {
                                        let a373 = match v0.clone() {
                                            Adt0::C0(_, _, _, h372, _, _, _, _, _, _) => {
                                                h372
                                            }
                                        };
                                        let a374 = f4(v1.clone());
                                        nat_add(a373, a374)?
                                    }, match v0 {
                                        Adt0::C0(_, _, _, _, h375, _, _, _, _, _) => {
                                            h375
                                        }
                                    }, {
                                        let a376 = f4(v1.clone());
                                        let a377 = 0u64;
                                        if nat_eq(a376, a377) {
                                            Adt5::C4
                                        } else {
                                            Adt5::C3
                                        }
                                    }, None::<Adt6>, {
                                        let a378 = f4(v1.clone());
                                        let a379 = 0u64;
                                        if nat_eq(a378, a379) {
                                            None::<Adt7>
                                        } else {
                                            match v1.clone() {
                                                Adt9::C0(_, _, _, _, h380, _, _) => {
                                                    h380
                                                }
                                            }
                                        }
                                    }, match v1 {
                                        Adt9::C0(_, _, _, _, _, h381, _) => {
                                            h381
                                        }
                                    }, None::<Adt8>), None::<Adt6>, None::<Adt3>))
                                }
                            }
                        }
                    }
                }
            } else {
                Ok(Adt10::C0(v0.clone(), None::<Adt6>, f2(v0, v1)))
            }
        }
    }
}

pub fn f1(v0: Adt0, v1: Adt9) -> bool {
    let m383 = match v0 {
        Adt0::C0(_, _, _, _, _, _, h382, _, _, _) => {
            h382
        }
    };
    match m383 {
        None => {
            false
        }
        Some(v2) => {
            if f6(match v2.clone() {
                Adt6::C0(h384, _, _, _, _) => {
                    h384
                }
            }, match v1.clone() {
                Adt9::C0(h385, _, _, _, _, _, _) => {
                    h385
                }
            }) {
                if f7(match v2.clone() {
                    Adt6::C0(_, h386, _, _, _) => {
                        h386
                    }
                }, match v1.clone() {
                    Adt9::C0(_, h387, _, _, _, _, _) => {
                        h387
                    }
                }) {
                    let a390 = match v2.clone() {
                        Adt6::C0(_, _, h388, _, _) => {
                            h388
                        }
                    };
                    let a391 = match v1.clone() {
                        Adt9::C0(_, _, h389, _, _, _, _) => {
                            h389
                        }
                    };
                    if nat_eq(a390, a391) {
                        let a394 = match v2 {
                            Adt6::C0(_, _, _, h392, _) => {
                                h392
                            }
                        };
                        let a395 = match v1 {
                            Adt9::C0(_, _, _, h393, _, _, _) => {
                                h393
                            }
                        };
                        nat_eq(a394, a395)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        }
    }
}

pub fn f2(v0: Adt0, v1: Adt9) -> Option<Adt3> {
    let m397 = match v1 {
        Adt9::C0(_, _, _, _, h396, _, _) => {
            h396
        }
    };
    match m397 {
        None => {
            None::<Adt3>
        }
        Some(v2) => {
            let m399 = match v0 {
                Adt0::C0(_, _, _, _, _, _, _, h398, _, _) => {
                    h398
                }
            };
            match m399 {
                None => {
                    f8(v2)
                }
                Some(v3) => {
                    if f7(match v3 {
                        Adt7::C0(h400, _, _) => {
                            h400
                        }
                    }, match v2.clone() {
                        Adt7::C0(h401, _, _) => {
                            h401
                        }
                    }) {
                        None::<Adt3>
                    } else {
                        f8(v2)
                    }
                }
            }
        }
    }
}

pub fn f3(v0: Adt0) -> u64 {
    let m405 = {
        let m404 = match v0.clone() {
            Adt0::C0(_, h403, _, _, _, _, _, _, _, _) => {
                h403
            }
        };
        match m404 {
            Adt2::C0(_, h402, _) => {
                h402
            }
        }
    };
    match m405 {
        None => {
            match v0 {
                Adt0::C0(_, _, h406, _, _, _, _, _, _, _) => {
                    h406
                }
            }
        }
        Some(v1) => {
            let a408 = v1;
            let a409 = match v0.clone() {
                Adt0::C0(_, _, _, h407, _, _, _, _, _, _) => {
                    h407
                }
            };
            if nat_eq(a408, a409) {
                1u64
            } else {
                let a414 = match v0.clone() {
                    Adt0::C0(_, _, h410, _, _, _, _, _, _, _) => {
                        h410
                    }
                };
                let a415 = {
                    let a412 = v1;
                    let a413 = match v0.clone() {
                        Adt0::C0(_, _, _, h411, _, _, _, _, _, _) => {
                            h411
                        }
                    };
                    nat_sub(a412, a413)
                };
                if nat_lt(a414, a415) {
                    match v0 {
                        Adt0::C0(_, _, h416, _, _, _, _, _, _, _) => {
                            h416
                        }
                    }
                } else {
                    let a418 = v1;
                    let a419 = match v0 {
                        Adt0::C0(_, _, _, h417, _, _, _, _, _, _) => {
                            h417
                        }
                    };
                    nat_sub(a418, a419)
                }
            }
        }
    }
}

pub fn f4(v0: Adt9) -> u64 {
    let m421 = match v0 {
        Adt9::C0(_, _, _, _, h420, _, _) => {
            h420
        }
    };
    match m421 {
        None => {
            0u64
        }
        Some(v1) => {
            match v1 {
                Adt7::C0(_, _, h422) => {
                    h422
                }
            }
        }
    }
}

pub fn f5(v0: Adt0, v1: Adt9) -> R<bool> {
    let m426 = {
        let m425 = match v0.clone() {
            Adt0::C0(_, h424, _, _, _, _, _, _, _, _) => {
                h424
            }
        };
        match m425 {
            Adt2::C0(_, h423, _) => {
                h423
            }
        }
    };
    match m426 {
        None => {
            Ok(true)
        }
        Some(v2) => {
            let a432 = {
                let a430 = v2;
                let a431 = {
                    let a428 = match v0.clone() {
                        Adt0::C0(_, _, _, h427, _, _, _, _, _, _) => {
                            h427
                        }
                    };
                    let a429 = f4(v1.clone());
                    nat_add(a428, a429)?
                };
                nat_lt(a430, a431)
            };
            if bool_not(a432) {
                if match v1.clone() {
                    Adt9::C0(_, _, _, _, _, h433, _) => {
                        h433
                    }
                } {
                    let a437 = v2;
                    let a438 = {
                        let a435 = match v0 {
                            Adt0::C0(_, _, _, h434, _, _, _, _, _, _) => {
                                h434
                            }
                        };
                        let a436 = f4(v1);
                        nat_add(a435, a436)?
                    };
                    Ok(nat_eq(a437, a438))
                } else {
                    Ok(true)
                }
            } else {
                Ok(false)
            }
        }
    }
}

pub fn f6(v0: Adt1, v1: Adt1) -> bool {
    let a441 = match v0.clone() {
        Adt1::C0(h439, _, _) => {
            h439
        }
    };
    let a442 = match v1.clone() {
        Adt1::C0(h440, _, _) => {
            h440
        }
    };
    if nat_eq(a441, a442) {
        let a445 = match v0.clone() {
            Adt1::C0(_, h443, _) => {
                h443
            }
        };
        let a446 = match v1.clone() {
            Adt1::C0(_, h444, _) => {
                h444
            }
        };
        if nat_eq(a445, a446) {
            let a449 = match v0 {
                Adt1::C0(_, _, h447) => {
                    h447
                }
            };
            let a450 = match v1 {
                Adt1::C0(_, _, h448) => {
                    h448
                }
            };
            nat_eq(a449, a450)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f7(v0: Adt3, v1: Adt3) -> bool {
    let a453 = match v0.clone() {
        Adt3::C0(h451, _, _) => {
            h451
        }
    };
    let a454 = match v1.clone() {
        Adt3::C0(h452, _, _) => {
            h452
        }
    };
    if nat_eq(a453, a454) {
        let a457 = match v0.clone() {
            Adt3::C0(_, h455, _) => {
                h455
            }
        };
        let a458 = match v1.clone() {
            Adt3::C0(_, h456, _) => {
                h456
            }
        };
        if nat_eq(a457, a458) {
            let a461 = match v0 {
                Adt3::C0(_, _, h459) => {
                    h459
                }
            };
            let a462 = match v1 {
                Adt3::C0(_, _, h460) => {
                    h460
                }
            };
            nat_eq(a461, a462)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f8(v0: Adt7) -> Option<Adt3> {
    let a464 = match v0.clone() {
        Adt7::C0(_, _, h463) => {
            h463
        }
    };
    let a465 = 0u64;
    if nat_eq(a464, a465) {
        None::<Adt3>
    } else {
        Some(match v0 {
            Adt7::C0(h466, _, _) => {
                h466
            }
        })
    }
}
