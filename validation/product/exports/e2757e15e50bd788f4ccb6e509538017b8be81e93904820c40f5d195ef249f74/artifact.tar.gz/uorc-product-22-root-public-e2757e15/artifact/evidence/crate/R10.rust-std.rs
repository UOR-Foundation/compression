#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt2, u64, Adt5, Adt6, Adt11, Option<Adt16>, Adt19, Option<Adt2>, bool, bool),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt3, Option<u64>, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt7, Option<Adt9>),
}

#[derive(Clone)]
pub enum Adt7 {
    C0(Adt8, Adt8, u64, u64),
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(u64, u64, u64),
    C1(Adt10, u64, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64, u64),
}

#[derive(Clone)]
pub enum Adt10 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt11 {
    C0(Adt1, Adt2, u64, u64, u64, Adt12, Option<Adt13>, Option<Adt14>, bool, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt12 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt13 {
    C0(Adt1, Adt3, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Adt3, u64, u64),
}

#[derive(Clone)]
pub enum Adt15 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt1, Adt3, Adt10, Adt5, Adt6, u64, u64, Adt17, Option<Adt18>, Option<Adt14>, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt17 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt1, Adt3, u64, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt19 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt1, Adt3, u64, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt0, List<Adt22>),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt1),
    C1(Adt13),
    C2(Adt18),
    C3(Adt3, u64),
    C4(Adt3),
    C5(Adt1),
    C6(Adt1, Adt3, u64),
    C7(Adt13),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(Adt16, Option<Adt18>, Option<Adt3>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(Adt10, u64),
    C1(Adt10, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64),
    C4(Adt10, u64),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(Adt11, Option<Adt13>, Option<Adt3>),
}

pub fn f0(v0: Adt0, v1: Adt20) -> R<Adt21> {
    let m2 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, h1, _, _, _) => {
            h1
        }
    };
    match m2 {
        Adt19::C0 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C1 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C2 => {
            let m4 = match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h3, _, _, _, _) => {
                    h3
                }
            };
            match m4 {
                None => {
                    Ok(Adt21::C0(v0, List::<Adt22>::nil()))
                }
                Some(v2) => {
                    f1(v0, f2(v2, v1)?)
                }
            }
        }
        Adt19::C3 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C4 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C5 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C6 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C7 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C8 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
    }
}

pub fn f1(v0: Adt0, v1: Adt23) -> R<Adt21> {
    let m8 = {
        let m7 = match v1.clone() {
            Adt23::C0(h6, _, _) => {
                h6
            }
        };
        match m7 {
            Adt16::C0(_, _, _, _, _, _, _, _, h5, _, _) => {
                h5
            }
        }
    };
    match m8 {
        None => {
            let m12 = {
                let m11 = match v1.clone() {
                    Adt23::C0(h10, _, _) => {
                        h10
                    }
                };
                match m11 {
                    Adt16::C0(_, _, _, _, _, _, _, h9, _, _, _) => {
                        h9
                    }
                }
            };
            match m12 {
                Adt17::C0 => {
                    let m16 = {
                        let m15 = match v1.clone() {
                            Adt23::C0(h14, _, _) => {
                                h14
                            }
                        };
                        match m15 {
                            Adt16::C0(_, _, _, _, _, _, _, _, _, h13, _) => {
                                h13
                            }
                        }
                    };
                    match m16 {
                        None => {
                            f3(v0, match v1 {
                                Adt23::C0(h17, _, _) => {
                                    h17
                                }
                            })
                        }
                        Some(_) => {
                            Ok(f4(v0, f5(match v1 {
                                Adt23::C0(h18, _, _) => {
                                    h18
                                }
                            })?))
                        }
                    }
                }
                Adt17::C1 => {
                    let m22 = {
                        let m21 = match v1.clone() {
                            Adt23::C0(h20, _, _) => {
                                h20
                            }
                        };
                        match m21 {
                            Adt16::C0(_, _, _, _, _, _, _, _, _, h19, _) => {
                                h19
                            }
                        }
                    };
                    match m22 {
                        None => {
                            f3(v0, match v1 {
                                Adt23::C0(h23, _, _) => {
                                    h23
                                }
                            })
                        }
                        Some(_) => {
                            Ok(f4(v0, f5(match v1 {
                                Adt23::C0(h24, _, _) => {
                                    h24
                                }
                            })?))
                        }
                    }
                }
                Adt17::C2 => {
                    let m28 = {
                        let m27 = match v1.clone() {
                            Adt23::C0(h26, _, _) => {
                                h26
                            }
                        };
                        match m27 {
                            Adt16::C0(_, _, _, _, _, _, _, _, _, h25, _) => {
                                h25
                            }
                        }
                    };
                    match m28 {
                        None => {
                            f3(v0, match v1 {
                                Adt23::C0(h29, _, _) => {
                                    h29
                                }
                            })
                        }
                        Some(_) => {
                            Ok(f4(v0, f5(match v1 {
                                Adt23::C0(h30, _, _) => {
                                    h30
                                }
                            })?))
                        }
                    }
                }
                Adt17::C3 => {
                    let m34 = {
                        let m33 = match v1.clone() {
                            Adt23::C0(h32, _, _) => {
                                h32
                            }
                        };
                        match m33 {
                            Adt16::C0(_, _, _, _, _, _, _, _, _, h31, _) => {
                                h31
                            }
                        }
                    };
                    match m34 {
                        None => {
                            f3(v0, match v1 {
                                Adt23::C0(h35, _, _) => {
                                    h35
                                }
                            })
                        }
                        Some(_) => {
                            Ok(f4(v0, f5(match v1 {
                                Adt23::C0(h36, _, _) => {
                                    h36
                                }
                            })?))
                        }
                    }
                }
                Adt17::C4 => {
                    Ok(f6(v0, match v1 {
                        Adt23::C0(h37, _, _) => {
                            h37
                        }
                    }))
                }
            }
        }
        Some(_) => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
    }
}

pub fn f2(v0: Adt16, v1: Adt20) -> R<Adt23> {
    let m39 = match v0.clone() {
        Adt16::C0(_, _, _, _, _, _, _, _, h38, _, _) => {
            h38
        }
    };
    match m39 {
        None => {
            Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Some(v2) => {
            if f7(v0.clone(), v1.clone()) {
                let a46 = {
                    let a44 = {
                        let m42 = match v2.clone() {
                            Adt18::C0(_, _, _, _, h41) => {
                                h41
                            }
                        };
                        match m42 {
                            Adt14::C0(_, _, h40) => {
                                h40
                            }
                        }
                    };
                    let a45 = match v1.clone() {
                        Adt20::C0(_, _, _, _, h43, _) => {
                            h43
                        }
                    };
                    nat_lt(a44, a45)
                };
                if bool_not(a46) {
                    Ok(Adt23::C0(Adt16::C0(match v0.clone() {
                        Adt16::C0(h47, _, _, _, _, _, _, _, _, _, _) => {
                            h47
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, h48, _, _, _, _, _, _, _, _, _) => {
                            h48
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, h49, _, _, _, _, _, _, _, _) => {
                            h49
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, h50, _, _, _, _, _, _, _) => {
                            h50
                        }
                    }, f8(match v0.clone() {
                        Adt16::C0(_, _, _, h51, _, _, _, _, _, _, _) => {
                            h51
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, _, h52, _, _, _, _, _, _) => {
                            h52
                        }
                    }, Adt24::C2(match v0.clone() {
                        Adt16::C0(_, _, h53, _, _, _, _, _, _, _, _) => {
                            h53
                        }
                    }, {
                        let m56 = match v2.clone() {
                            Adt18::C0(_, _, _, _, h55) => {
                                h55
                            }
                        };
                        match m56 {
                            Adt14::C0(_, _, h54) => {
                                h54
                            }
                        }
                    }, match v1.clone() {
                        Adt20::C0(_, _, _, _, h57, _) => {
                            h57
                        }
                    }))?, {
                        let a60 = match v0.clone() {
                            Adt16::C0(_, _, _, _, _, h58, _, _, _, _, _) => {
                                h58
                            }
                        };
                        let a61 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h59, _) => {
                                h59
                            }
                        };
                        nat_add(a60, a61)?
                    }, match v0 {
                        Adt16::C0(_, _, _, _, _, _, h62, _, _, _, _) => {
                            h62
                        }
                    }, if if match v1.clone() {
                        Adt20::C0(_, _, _, _, _, h63) => {
                            h63
                        }
                    } {
                        true
                    } else {
                        let a65 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h64, _) => {
                                h64
                            }
                        };
                        let a66 = 0u64;
                        if nat_eq(a65, a66) {
                            let a72 = {
                                let a70 = {
                                    let m69 = match v2.clone() {
                                        Adt18::C0(_, _, _, _, h68) => {
                                            h68
                                        }
                                    };
                                    match m69 {
                                        Adt14::C0(_, _, h67) => {
                                            h67
                                        }
                                    }
                                };
                                let a71 = 0u64;
                                nat_eq(a70, a71)
                            };
                            bool_not(a72)
                        } else {
                            false
                        }
                    } {
                        Adt17::C4
                    } else {
                        Adt17::C0
                    }, None::<Adt18>, {
                        let a77 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h73, _) => {
                                h73
                            }
                        };
                        let a78 = {
                            let m76 = match v2.clone() {
                                Adt18::C0(_, _, _, _, h75) => {
                                    h75
                                }
                            };
                            match m76 {
                                Adt14::C0(_, _, h74) => {
                                    h74
                                }
                            }
                        };
                        if nat_eq(a77, a78) {
                            None::<Adt14>
                        } else {
                            Some(Adt14::C0({
                                let m81 = match v2.clone() {
                                    Adt18::C0(_, _, _, _, h80) => {
                                        h80
                                    }
                                };
                                match m81 {
                                    Adt14::C0(h79, _, _) => {
                                        h79
                                    }
                                }
                            }, {
                                let a86 = {
                                    let m84 = match v2.clone() {
                                        Adt18::C0(_, _, _, _, h83) => {
                                            h83
                                        }
                                    };
                                    match m84 {
                                        Adt14::C0(_, h82, _) => {
                                            h82
                                        }
                                    }
                                };
                                let a87 = match v1.clone() {
                                    Adt20::C0(_, _, _, _, h85, _) => {
                                        h85
                                    }
                                };
                                nat_add(a86, a87)?
                            }, {
                                let a92 = {
                                    let m90 = match v2.clone() {
                                        Adt18::C0(_, _, _, _, h89) => {
                                            h89
                                        }
                                    };
                                    match m90 {
                                        Adt14::C0(_, _, h88) => {
                                            h88
                                        }
                                    }
                                };
                                let a93 = match v1.clone() {
                                    Adt20::C0(_, _, _, _, h91, _) => {
                                        h91
                                    }
                                };
                                nat_sub(a92, a93)
                            }))
                        }
                    }, if if match v1.clone() {
                        Adt20::C0(_, _, _, _, _, h94) => {
                            h94
                        }
                    } {
                        true
                    } else {
                        let a96 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h95, _) => {
                                h95
                            }
                        };
                        let a97 = 0u64;
                        if nat_eq(a96, a97) {
                            let a103 = {
                                let a101 = {
                                    let m100 = match v2.clone() {
                                        Adt18::C0(_, _, _, _, h99) => {
                                            h99
                                        }
                                    };
                                    match m100 {
                                        Adt14::C0(_, _, h98) => {
                                            h98
                                        }
                                    }
                                };
                                let a102 = 0u64;
                                nat_eq(a101, a102)
                            };
                            bool_not(a103)
                        } else {
                            false
                        }
                    } {
                        Some(Adt15::C8)
                    } else {
                        None::<Adt15>
                    }), None::<Adt18>, {
                        let a108 = match v1 {
                            Adt20::C0(_, _, _, _, h104, _) => {
                                h104
                            }
                        };
                        let a109 = {
                            let m107 = match v2.clone() {
                                Adt18::C0(_, _, _, _, h106) => {
                                    h106
                                }
                            };
                            match m107 {
                                Adt14::C0(_, _, h105) => {
                                    h105
                                }
                            }
                        };
                        if nat_eq(a108, a109) {
                            Some({
                                let m112 = match v2 {
                                    Adt18::C0(_, _, _, _, h111) => {
                                        h111
                                    }
                                };
                                match m112 {
                                    Adt14::C0(h110, _, _) => {
                                        h110
                                    }
                                }
                            })
                        } else {
                            None::<Adt3>
                        }
                    }))
                } else {
                    Ok(Adt23::C0(Adt16::C0(match v0.clone() {
                        Adt16::C0(h113, _, _, _, _, _, _, _, _, _, _) => {
                            h113
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, h114, _, _, _, _, _, _, _, _, _) => {
                            h114
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, h115, _, _, _, _, _, _, _, _) => {
                            h115
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, h116, _, _, _, _, _, _, _) => {
                            h116
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, _, h117, _, _, _, _, _, _) => {
                            h117
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, _, _, h118, _, _, _, _, _) => {
                            h118
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, _, _, _, h119, _, _, _, _) => {
                            h119
                        }
                    }, Adt17::C4, match v0.clone() {
                        Adt16::C0(_, _, _, _, _, _, _, _, h120, _, _) => {
                            h120
                        }
                    }, match v0 {
                        Adt16::C0(_, _, _, _, _, _, _, _, _, h121, _) => {
                            h121
                        }
                    }, Some(Adt15::C9)), None::<Adt18>, None::<Adt3>))
                }
            } else {
                Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
            }
        }
    }
}

pub fn f3(v0: Adt0, v1: Adt16) -> R<Adt21> {
    Ok(Adt21::C0({
        let m134 = f9(Adt0::C0(match v0.clone() {
            Adt0::C0(h123, _, _, _, _, _, _, _, _, _, _) => {
                h123
            }
        }, match v0.clone() {
            Adt0::C0(_, h124, _, _, _, _, _, _, _, _, _) => {
                h124
            }
        }, match v0.clone() {
            Adt0::C0(_, _, h125, _, _, _, _, _, _, _, _) => {
                h125
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, h126, _, _, _, _, _, _, _) => {
                h126
            }
        }, match v1.clone() {
            Adt16::C0(_, _, _, _, h127, _, _, _, _, _, _) => {
                h127
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, h128, _, _, _, _, _) => {
                h128
            }
        }, Some(v1.clone()), match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, h129, _, _, _) => {
                h129
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, _, h130, _, _) => {
                h130
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, _, _, h131, _) => {
                h131
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h132) => {
                h132
            }
        }), v1.clone(), f10(match v0.clone() {
            Adt0::C0(_, _, _, _, _, h133, _, _, _, _, _) => {
                h133
            }
        }))?;
        match m134 {
            Adt21::C0(h122, _) => {
                h122
            }
        }
    }, f11({
        let m138 = {
            let m137 = f10(match v0.clone() {
                Adt0::C0(_, _, _, _, _, h136, _, _, _, _, _) => {
                    h136
                }
            });
            match m137 {
                Adt25::C0(_, _, h135) => {
                    h135
                }
            }
        };
        match m138 {
            None => {
                List::<Adt22>::nil()
            }
            Some(v2) => {
                List::cons(Adt22::C4(v2), List::<Adt22>::nil())
            }
        }
    }, {
        let m151 = f9(Adt0::C0(match v0.clone() {
            Adt0::C0(h140, _, _, _, _, _, _, _, _, _, _) => {
                h140
            }
        }, match v0.clone() {
            Adt0::C0(_, h141, _, _, _, _, _, _, _, _, _) => {
                h141
            }
        }, match v0.clone() {
            Adt0::C0(_, _, h142, _, _, _, _, _, _, _, _) => {
                h142
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, h143, _, _, _, _, _, _, _) => {
                h143
            }
        }, match v1.clone() {
            Adt16::C0(_, _, _, _, h144, _, _, _, _, _, _) => {
                h144
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, h145, _, _, _, _, _) => {
                h145
            }
        }, Some(v1.clone()), match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, h146, _, _, _) => {
                h146
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, _, h147, _, _) => {
                h147
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, _, _, h148, _) => {
                h148
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h149) => {
                h149
            }
        }), v1, f10(match v0 {
            Adt0::C0(_, _, _, _, _, h150, _, _, _, _, _) => {
                h150
            }
        }))?;
        match m151 {
            Adt21::C0(_, h139) => {
                h139
            }
        }
    })))
}

pub fn f4(v0: Adt0, v1: Adt23) -> Adt21 {
    let m155 = {
        let m154 = match v1.clone() {
            Adt23::C0(h153, _, _) => {
                h153
            }
        };
        match m154 {
            Adt16::C0(_, _, _, _, _, _, _, h152, _, _, _) => {
                h152
            }
        }
    };
    match m155 {
        Adt17::C0 => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h156, _, _, _, _, _, _, _, _, _, _) => {
                    h156
                }
            }, match v0.clone() {
                Adt0::C0(_, h157, _, _, _, _, _, _, _, _, _) => {
                    h157
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h158, _, _, _, _, _, _, _, _) => {
                    h158
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h159, _, _, _, _, _, _, _) => {
                    h159
                }
            }, {
                let m162 = match v1.clone() {
                    Adt23::C0(h161, _, _) => {
                        h161
                    }
                };
                match m162 {
                    Adt16::C0(_, _, _, _, h160, _, _, _, _, _, _) => {
                        h160
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h163, _, _, _, _, _) => {
                    h163
                }
            }, Some(match v1.clone() {
                Adt23::C0(h164, _, _) => {
                    h164
                }
            }), {
                let m168 = {
                    let m167 = match v1.clone() {
                        Adt23::C0(h166, _, _) => {
                            h166
                        }
                    };
                    match m167 {
                        Adt16::C0(_, _, _, _, _, _, _, h165, _, _, _) => {
                            h165
                        }
                    }
                };
                match m168 {
                    Adt17::C0 => {
                        Adt19::C8
                    }
                    Adt17::C1 => {
                        Adt19::C2
                    }
                    Adt17::C2 => {
                        Adt19::C8
                    }
                    Adt17::C3 => {
                        Adt19::C8
                    }
                    Adt17::C4 => {
                        Adt19::C8
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h169, _, _) => {
                    h169
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h170, _) => {
                    h170
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h171) => {
                    h171
                }
            }), {
                let m173 = match v1 {
                    Adt23::C0(_, h172, _) => {
                        h172
                    }
                };
                match m173 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v2) => {
                        List::cons(Adt22::C2(v2), List::<Adt22>::nil())
                    }
                }
            })
        }
        Adt17::C1 => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h174, _, _, _, _, _, _, _, _, _, _) => {
                    h174
                }
            }, match v0.clone() {
                Adt0::C0(_, h175, _, _, _, _, _, _, _, _, _) => {
                    h175
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h176, _, _, _, _, _, _, _, _) => {
                    h176
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h177, _, _, _, _, _, _, _) => {
                    h177
                }
            }, {
                let m180 = match v1.clone() {
                    Adt23::C0(h179, _, _) => {
                        h179
                    }
                };
                match m180 {
                    Adt16::C0(_, _, _, _, h178, _, _, _, _, _, _) => {
                        h178
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h181, _, _, _, _, _) => {
                    h181
                }
            }, Some(match v1.clone() {
                Adt23::C0(h182, _, _) => {
                    h182
                }
            }), {
                let m186 = {
                    let m185 = match v1.clone() {
                        Adt23::C0(h184, _, _) => {
                            h184
                        }
                    };
                    match m185 {
                        Adt16::C0(_, _, _, _, _, _, _, h183, _, _, _) => {
                            h183
                        }
                    }
                };
                match m186 {
                    Adt17::C0 => {
                        Adt19::C8
                    }
                    Adt17::C1 => {
                        Adt19::C2
                    }
                    Adt17::C2 => {
                        Adt19::C8
                    }
                    Adt17::C3 => {
                        Adt19::C8
                    }
                    Adt17::C4 => {
                        Adt19::C8
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h187, _, _) => {
                    h187
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h188, _) => {
                    h188
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h189) => {
                    h189
                }
            }), {
                let m191 = match v1 {
                    Adt23::C0(_, h190, _) => {
                        h190
                    }
                };
                match m191 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v3) => {
                        List::cons(Adt22::C2(v3), List::<Adt22>::nil())
                    }
                }
            })
        }
        Adt17::C2 => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h192, _, _, _, _, _, _, _, _, _, _) => {
                    h192
                }
            }, match v0.clone() {
                Adt0::C0(_, h193, _, _, _, _, _, _, _, _, _) => {
                    h193
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h194, _, _, _, _, _, _, _, _) => {
                    h194
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h195, _, _, _, _, _, _, _) => {
                    h195
                }
            }, {
                let m198 = match v1.clone() {
                    Adt23::C0(h197, _, _) => {
                        h197
                    }
                };
                match m198 {
                    Adt16::C0(_, _, _, _, h196, _, _, _, _, _, _) => {
                        h196
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h199, _, _, _, _, _) => {
                    h199
                }
            }, Some(match v1.clone() {
                Adt23::C0(h200, _, _) => {
                    h200
                }
            }), {
                let m204 = {
                    let m203 = match v1.clone() {
                        Adt23::C0(h202, _, _) => {
                            h202
                        }
                    };
                    match m203 {
                        Adt16::C0(_, _, _, _, _, _, _, h201, _, _, _) => {
                            h201
                        }
                    }
                };
                match m204 {
                    Adt17::C0 => {
                        Adt19::C8
                    }
                    Adt17::C1 => {
                        Adt19::C2
                    }
                    Adt17::C2 => {
                        Adt19::C8
                    }
                    Adt17::C3 => {
                        Adt19::C8
                    }
                    Adt17::C4 => {
                        Adt19::C8
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h205, _, _) => {
                    h205
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h206, _) => {
                    h206
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h207) => {
                    h207
                }
            }), {
                let m209 = match v1 {
                    Adt23::C0(_, h208, _) => {
                        h208
                    }
                };
                match m209 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v4) => {
                        List::cons(Adt22::C2(v4), List::<Adt22>::nil())
                    }
                }
            })
        }
        Adt17::C3 => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h210, _, _, _, _, _, _, _, _, _, _) => {
                    h210
                }
            }, match v0.clone() {
                Adt0::C0(_, h211, _, _, _, _, _, _, _, _, _) => {
                    h211
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h212, _, _, _, _, _, _, _, _) => {
                    h212
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h213, _, _, _, _, _, _, _) => {
                    h213
                }
            }, {
                let m216 = match v1.clone() {
                    Adt23::C0(h215, _, _) => {
                        h215
                    }
                };
                match m216 {
                    Adt16::C0(_, _, _, _, h214, _, _, _, _, _, _) => {
                        h214
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h217, _, _, _, _, _) => {
                    h217
                }
            }, Some(match v1.clone() {
                Adt23::C0(h218, _, _) => {
                    h218
                }
            }), {
                let m222 = {
                    let m221 = match v1.clone() {
                        Adt23::C0(h220, _, _) => {
                            h220
                        }
                    };
                    match m221 {
                        Adt16::C0(_, _, _, _, _, _, _, h219, _, _, _) => {
                            h219
                        }
                    }
                };
                match m222 {
                    Adt17::C0 => {
                        Adt19::C8
                    }
                    Adt17::C1 => {
                        Adt19::C2
                    }
                    Adt17::C2 => {
                        Adt19::C8
                    }
                    Adt17::C3 => {
                        Adt19::C8
                    }
                    Adt17::C4 => {
                        Adt19::C8
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h223, _, _) => {
                    h223
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h224, _) => {
                    h224
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h225) => {
                    h225
                }
            }), {
                let m227 = match v1 {
                    Adt23::C0(_, h226, _) => {
                        h226
                    }
                };
                match m227 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v5) => {
                        List::cons(Adt22::C2(v5), List::<Adt22>::nil())
                    }
                }
            })
        }
        Adt17::C4 => {
            f6(v0, match v1 {
                Adt23::C0(h228, _, _) => {
                    h228
                }
            })
        }
    }
}

pub fn f5(v0: Adt16) -> R<Adt23> {
    let m230 = match v0.clone() {
        Adt16::C0(_, _, _, _, _, _, _, _, _, h229, _) => {
            h229
        }
    };
    match m230 {
        None => {
            Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Some(v1) => {
            f12(v0, v1)
        }
    }
}

pub fn f6(v0: Adt0, v1: Adt16) -> Adt21 {
    Adt21::C0(Adt0::C0(match v0.clone() {
        Adt0::C0(h231, _, _, _, _, _, _, _, _, _, _) => {
            h231
        }
    }, match v0.clone() {
        Adt0::C0(_, h232, _, _, _, _, _, _, _, _, _) => {
            h232
        }
    }, match v0.clone() {
        Adt0::C0(_, _, h233, _, _, _, _, _, _, _, _) => {
            h233
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, h234, _, _, _, _, _, _, _) => {
            h234
        }
    }, match v1.clone() {
        Adt16::C0(_, _, _, _, h235, _, _, _, _, _, _) => {
            h235
        }
    }, {
        let m238 = f13(match v0.clone() {
            Adt0::C0(_, _, _, _, _, h237, _, _, _, _, _) => {
                h237
            }
        });
        match m238 {
            Adt25::C0(h236, _, _) => {
                h236
            }
        }
    }, Some(v1), Adt19::C8, match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, _, h239, _, _) => {
            h239
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, _, _, h240, _) => {
            h240
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, _, _, _, h241) => {
            h241
        }
    }), {
        let m245 = {
            let m244 = f13(match v0 {
                Adt0::C0(_, _, _, _, _, h243, _, _, _, _, _) => {
                    h243
                }
            });
            match m244 {
                Adt25::C0(_, _, h242) => {
                    h242
                }
            }
        };
        match m245 {
            None => {
                List::<Adt22>::nil()
            }
            Some(v2) => {
                List::cons(Adt22::C4(v2), List::<Adt22>::nil())
            }
        }
    })
}

pub fn f7(v0: Adt16, v1: Adt20) -> bool {
    let m247 = match v0 {
        Adt16::C0(_, _, _, _, _, _, _, _, h246, _, _) => {
            h246
        }
    };
    match m247 {
        None => {
            false
        }
        Some(v2) => {
            if f14(match v2.clone() {
                Adt18::C0(h248, _, _, _, _) => {
                    h248
                }
            }, match v1.clone() {
                Adt20::C0(h249, _, _, _, _, _) => {
                    h249
                }
            }) {
                if f15(match v2.clone() {
                    Adt18::C0(_, h250, _, _, _) => {
                        h250
                    }
                }, match v1.clone() {
                    Adt20::C0(_, h251, _, _, _, _) => {
                        h251
                    }
                }) {
                    let a254 = match v2.clone() {
                        Adt18::C0(_, _, h252, _, _) => {
                            h252
                        }
                    };
                    let a255 = match v1.clone() {
                        Adt20::C0(_, _, h253, _, _, _) => {
                            h253
                        }
                    };
                    if nat_eq(a254, a255) {
                        let a258 = match v2 {
                            Adt18::C0(_, _, _, h256, _) => {
                                h256
                            }
                        };
                        let a259 = match v1 {
                            Adt20::C0(_, _, _, h257, _, _) => {
                                h257
                            }
                        };
                        nat_eq(a258, a259)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        }
    }
}

pub fn f8(v0: Adt5, v1: Adt6, v2: Adt24) -> R<Adt6> {
    let m260 = v2;
    match m260 {
        Adt24::C0(v3, v4) => {
            let m262 = f16(v0, match v1.clone() {
                Adt6::C0(h261, _) => {
                    h261
                }
            }, v3, v4)?;
            match m262 {
                Ok(v6) => {
                    Ok(Adt6::C0(v6, None::<Adt9>))
                }
                Err(v5) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h263, _) => {
                            h263
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt24::C1(v7, v8, v9) => {
            let m265 = f17(match v1.clone() {
                Adt6::C0(h264, _) => {
                    h264
                }
            }, v7, v8, v9)?;
            match m265 {
                Ok(v11) => {
                    Ok(Adt6::C0(v11, None::<Adt9>))
                }
                Err(v10) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h266, _) => {
                            h266
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt24::C2(v12, v13, v14) => {
            let m268 = f17(match v1.clone() {
                Adt6::C0(h267, _) => {
                    h267
                }
            }, v12, v13, v14)?;
            match m268 {
                Ok(v16) => {
                    Ok(Adt6::C0(v16, None::<Adt9>))
                }
                Err(v15) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h269, _) => {
                            h269
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt24::C3(v17, v18) => {
            let m271 = f18(match v1.clone() {
                Adt6::C0(h270, _) => {
                    h270
                }
            }, v17, v18)?;
            match m271 {
                Ok(v20) => {
                    Ok(Adt6::C0(v20, None::<Adt9>))
                }
                Err(v19) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h272, _) => {
                            h272
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt24::C4(v21, v22) => {
            let m274 = f18(match v1.clone() {
                Adt6::C0(h273, _) => {
                    h273
                }
            }, v21, v22)?;
            match m274 {
                Ok(v24) => {
                    Ok(Adt6::C0(v24, None::<Adt9>))
                }
                Err(v23) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h275, _) => {
                            h275
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f9(v0: Adt0, v1: Adt16, v2: Adt25) -> R<Adt21> {
    let m279 = {
        let m278 = match v2.clone() {
            Adt25::C0(h277, _, _) => {
                h277
            }
        };
        match m278 {
            Adt11::C0(_, _, _, _, _, h276, _, _, _, _) => {
                h276
            }
        }
    };
    match m279 {
        Adt12::C0 => {
            Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h280, _, _, _, _, _, _, _, _, _, _) => {
                    h280
                }
            }, match v0.clone() {
                Adt0::C0(_, h281, _, _, _, _, _, _, _, _, _) => {
                    h281
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h282, _, _, _, _, _, _, _, _) => {
                    h282
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h283, _, _, _, _, _, _, _) => {
                    h283
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h284, _, _, _, _, _, _) => {
                    h284
                }
            }, {
                let m287 = f19(match v2.clone() {
                    Adt25::C0(h286, _, _) => {
                        h286
                    }
                })?;
                match m287 {
                    Adt25::C0(h285, _, _) => {
                        h285
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h288, _, _, _, _) => {
                    h288
                }
            }, Adt19::C1, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h289, _, _) => {
                    h289
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h290, _) => {
                    h290
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h291) => {
                    h291
                }
            }), {
                let m295 = {
                    let m294 = f19(match v2 {
                        Adt25::C0(h293, _, _) => {
                            h293
                        }
                    })?;
                    match m294 {
                        Adt25::C0(_, h292, _) => {
                            h292
                        }
                    }
                };
                match m295 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v3) => {
                        List::cons(Adt22::C1(v3), List::<Adt22>::nil())
                    }
                }
            }))
        }
        Adt12::C1 => {
            Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h296, _, _, _, _, _, _, _, _, _, _) => {
                    h296
                }
            }, match v0.clone() {
                Adt0::C0(_, h297, _, _, _, _, _, _, _, _, _) => {
                    h297
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h298, _, _, _, _, _, _, _, _) => {
                    h298
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h299, _, _, _, _, _, _, _) => {
                    h299
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h300, _, _, _, _, _, _) => {
                    h300
                }
            }, {
                let m303 = f19(match v2.clone() {
                    Adt25::C0(h302, _, _) => {
                        h302
                    }
                })?;
                match m303 {
                    Adt25::C0(h301, _, _) => {
                        h301
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h304, _, _, _, _) => {
                    h304
                }
            }, Adt19::C1, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h305, _, _) => {
                    h305
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h306, _) => {
                    h306
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h307) => {
                    h307
                }
            }), {
                let m311 = {
                    let m310 = f19(match v2 {
                        Adt25::C0(h309, _, _) => {
                            h309
                        }
                    })?;
                    match m310 {
                        Adt25::C0(_, h308, _) => {
                            h308
                        }
                    }
                };
                match m311 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v4) => {
                        List::cons(Adt22::C1(v4), List::<Adt22>::nil())
                    }
                }
            }))
        }
        Adt12::C2 => {
            Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h372, _, _, _, _, _, _, _, _, _, _) => {
                    h372
                }
            }, match v0.clone() {
                Adt0::C0(_, h373, _, _, _, _, _, _, _, _, _) => {
                    h373
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h374, _, _, _, _, _, _, _, _) => {
                    h374
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h375, _, _, _, _, _, _, _) => {
                    h375
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h376, _, _, _, _, _, _) => {
                    h376
                }
            }, {
                let m379 = f19(match v2.clone() {
                    Adt25::C0(h378, _, _) => {
                        h378
                    }
                })?;
                match m379 {
                    Adt25::C0(h377, _, _) => {
                        h377
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h380, _, _, _, _) => {
                    h380
                }
            }, Adt19::C1, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h381, _, _) => {
                    h381
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h382, _) => {
                    h382
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h383) => {
                    h383
                }
            }), {
                let m387 = {
                    let m386 = f19(match v2 {
                        Adt25::C0(h385, _, _) => {
                            h385
                        }
                    })?;
                    match m386 {
                        Adt25::C0(_, h384, _) => {
                            h384
                        }
                    }
                };
                match m387 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v8) => {
                        List::cons(Adt22::C1(v8), List::<Adt22>::nil())
                    }
                }
            }))
        }
        Adt12::C3 => {
            Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h312, _, _, _, _, _, _, _, _, _, _) => {
                    h312
                }
            }, match v0.clone() {
                Adt0::C0(_, h313, _, _, _, _, _, _, _, _, _) => {
                    h313
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h314, _, _, _, _, _, _, _, _) => {
                    h314
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h315, _, _, _, _, _, _, _) => {
                    h315
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h316, _, _, _, _, _, _) => {
                    h316
                }
            }, {
                let m319 = f19(match v2.clone() {
                    Adt25::C0(h318, _, _) => {
                        h318
                    }
                })?;
                match m319 {
                    Adt25::C0(h317, _, _) => {
                        h317
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h320, _, _, _, _) => {
                    h320
                }
            }, Adt19::C1, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h321, _, _) => {
                    h321
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h322, _) => {
                    h322
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h323) => {
                    h323
                }
            }), {
                let m327 = {
                    let m326 = f19(match v2 {
                        Adt25::C0(h325, _, _) => {
                            h325
                        }
                    })?;
                    match m326 {
                        Adt25::C0(_, h324, _) => {
                            h324
                        }
                    }
                };
                match m327 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v5) => {
                        List::cons(Adt22::C1(v5), List::<Adt22>::nil())
                    }
                }
            }))
        }
        Adt12::C4 => {
            Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h328, _, _, _, _, _, _, _, _, _, _) => {
                    h328
                }
            }, match v0.clone() {
                Adt0::C0(_, h329, _, _, _, _, _, _, _, _, _) => {
                    h329
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h330, _, _, _, _, _, _, _, _) => {
                    h330
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h331, _, _, _, _, _, _, _) => {
                    h331
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h332, _, _, _, _, _, _) => {
                    h332
                }
            }, match v2 {
                Adt25::C0(h333, _, _) => {
                    h333
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h334, _, _, _, _) => {
                    h334
                }
            }, Adt19::C3, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h335, _, _) => {
                    h335
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h336, _) => {
                    h336
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h337) => {
                    h337
                }
            }), List::cons(Adt22::C3(match v1.clone() {
                Adt16::C0(_, h338, _, _, _, _, _, _, _, _, _) => {
                    h338
                }
            }, match v1 {
                Adt16::C0(_, _, _, _, _, h339, _, _, _, _, _) => {
                    h339
                }
            }), List::<Adt22>::nil())))
        }
        Adt12::C5 => {
            Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h340, _, _, _, _, _, _, _, _, _, _) => {
                    h340
                }
            }, match v0.clone() {
                Adt0::C0(_, h341, _, _, _, _, _, _, _, _, _) => {
                    h341
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h342, _, _, _, _, _, _, _, _) => {
                    h342
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h343, _, _, _, _, _, _, _) => {
                    h343
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h344, _, _, _, _, _, _) => {
                    h344
                }
            }, {
                let m347 = f19(match v2.clone() {
                    Adt25::C0(h346, _, _) => {
                        h346
                    }
                })?;
                match m347 {
                    Adt25::C0(h345, _, _) => {
                        h345
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h348, _, _, _, _) => {
                    h348
                }
            }, Adt19::C1, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h349, _, _) => {
                    h349
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h350, _) => {
                    h350
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h351) => {
                    h351
                }
            }), {
                let m355 = {
                    let m354 = f19(match v2 {
                        Adt25::C0(h353, _, _) => {
                            h353
                        }
                    })?;
                    match m354 {
                        Adt25::C0(_, h352, _) => {
                            h352
                        }
                    }
                };
                match m355 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v6) => {
                        List::cons(Adt22::C1(v6), List::<Adt22>::nil())
                    }
                }
            }))
        }
        Adt12::C6 => {
            Ok(Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h356, _, _, _, _, _, _, _, _, _, _) => {
                    h356
                }
            }, match v0.clone() {
                Adt0::C0(_, h357, _, _, _, _, _, _, _, _, _) => {
                    h357
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h358, _, _, _, _, _, _, _, _) => {
                    h358
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h359, _, _, _, _, _, _, _) => {
                    h359
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h360, _, _, _, _, _, _) => {
                    h360
                }
            }, {
                let m363 = f19(match v2.clone() {
                    Adt25::C0(h362, _, _) => {
                        h362
                    }
                })?;
                match m363 {
                    Adt25::C0(h361, _, _) => {
                        h361
                    }
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h364, _, _, _, _) => {
                    h364
                }
            }, Adt19::C1, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h365, _, _) => {
                    h365
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h366, _) => {
                    h366
                }
            }, match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h367) => {
                    h367
                }
            }), {
                let m371 = {
                    let m370 = f19(match v2 {
                        Adt25::C0(h369, _, _) => {
                            h369
                        }
                    })?;
                    match m370 {
                        Adt25::C0(_, h368, _) => {
                            h368
                        }
                    }
                };
                match m371 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v7) => {
                        List::cons(Adt22::C1(v7), List::<Adt22>::nil())
                    }
                }
            }))
        }
    }
}

pub fn f10(v0: Adt11) -> Adt25 {
    let m389 = match v0.clone() {
        Adt11::C0(_, _, _, _, _, h388, _, _, _, _) => {
            h388
        }
    };
    match m389 {
        Adt12::C0 => {
            Adt25::C0(v0, None::<Adt13>, None::<Adt3>)
        }
        Adt12::C1 => {
            Adt25::C0(v0, None::<Adt13>, None::<Adt3>)
        }
        Adt12::C2 => {
            Adt25::C0(v0, None::<Adt13>, None::<Adt3>)
        }
        Adt12::C3 => {
            Adt25::C0(Adt11::C0(match v0.clone() {
                Adt11::C0(h390, _, _, _, _, _, _, _, _, _) => {
                    h390
                }
            }, match v0.clone() {
                Adt11::C0(_, h391, _, _, _, _, _, _, _, _) => {
                    h391
                }
            }, match v0.clone() {
                Adt11::C0(_, _, h392, _, _, _, _, _, _, _) => {
                    h392
                }
            }, match v0.clone() {
                Adt11::C0(_, _, _, h393, _, _, _, _, _, _) => {
                    h393
                }
            }, match v0.clone() {
                Adt11::C0(_, _, _, _, h394, _, _, _, _, _) => {
                    h394
                }
            }, if match v0.clone() {
                Adt11::C0(_, _, _, _, _, _, _, _, h395, _) => {
                    h395
                }
            } {
                Adt12::C4
            } else {
                Adt12::C0
            }, match v0.clone() {
                Adt11::C0(_, _, _, _, _, _, h396, _, _, _) => {
                    h396
                }
            }, None::<Adt14>, match v0.clone() {
                Adt11::C0(_, _, _, _, _, _, _, _, h397, _) => {
                    h397
                }
            }, match v0.clone() {
                Adt11::C0(_, _, _, _, _, _, _, _, _, h398) => {
                    h398
                }
            }), None::<Adt13>, {
                let m400 = match v0 {
                    Adt11::C0(_, _, _, _, _, _, _, h399, _, _) => {
                        h399
                    }
                };
                match m400 {
                    None => {
                        None::<Adt3>
                    }
                    Some(v1) => {
                        Some(match v1 {
                            Adt14::C0(h401, _, _) => {
                                h401
                            }
                        })
                    }
                }
            })
        }
        Adt12::C4 => {
            Adt25::C0(v0, None::<Adt13>, None::<Adt3>)
        }
        Adt12::C5 => {
            Adt25::C0(v0, None::<Adt13>, None::<Adt3>)
        }
        Adt12::C6 => {
            Adt25::C0(v0, None::<Adt13>, None::<Adt3>)
        }
    }
}

pub fn f11(v0: List<Adt22>, v1: List<Adt22>) -> List<Adt22> {
    let m402 = v0;
    match m402.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f11(v3, v1))
        }
    }
}

pub fn f12(v0: Adt16, v1: Adt14) -> R<Adt23> {
    let m404 = match v0.clone() {
        Adt16::C0(_, _, _, _, _, _, _, h403, _, _, _) => {
            h403
        }
    };
    match m404 {
        Adt17::C0 => {
            f20(v0.clone(), v1.clone(), f8(match v0.clone() {
                Adt16::C0(_, _, _, h405, _, _, _, _, _, _, _) => {
                    h405
                }
            }, match v0.clone() {
                Adt16::C0(_, _, _, _, h406, _, _, _, _, _, _) => {
                    h406
                }
            }, Adt24::C0(match v0 {
                Adt16::C0(_, _, h407, _, _, _, _, _, _, _, _) => {
                    h407
                }
            }, match v1 {
                Adt14::C0(_, _, h408) => {
                    h408
                }
            }))?)
        }
        Adt17::C1 => {
            Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Adt17::C2 => {
            Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Adt17::C3 => {
            Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Adt17::C4 => {
            Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
        }
    }
}

pub fn f13(v0: Adt11) -> Adt25 {
    Adt25::C0(Adt11::C0(match v0.clone() {
        Adt11::C0(h409, _, _, _, _, _, _, _, _, _) => {
            h409
        }
    }, match v0.clone() {
        Adt11::C0(_, h410, _, _, _, _, _, _, _, _) => {
            h410
        }
    }, match v0.clone() {
        Adt11::C0(_, _, h411, _, _, _, _, _, _, _) => {
            h411
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, h412, _, _, _, _, _, _) => {
            h412
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, _, h413, _, _, _, _, _) => {
            h413
        }
    }, {
        let m415 = match v0.clone() {
            Adt11::C0(_, _, _, _, _, _, h414, _, _, _) => {
                h414
            }
        };
        if match m415 {
            None => {
                false
            }
            Some(_) => {
                true
            }
        } {
            Adt12::C2
        } else {
            Adt12::C5
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, _, _, _, h416, _, _, _) => {
            h416
        }
    }, None::<Adt14>, match v0.clone() {
        Adt11::C0(_, _, _, _, _, _, _, _, h417, _) => {
            h417
        }
    }, Some(Adt15::C11)), None::<Adt13>, {
        let m419 = match v0 {
            Adt11::C0(_, _, _, _, _, _, _, h418, _, _) => {
                h418
            }
        };
        match m419 {
            None => {
                None::<Adt3>
            }
            Some(v2) => {
                f21(v2)
            }
        }
    })
}

pub fn f14(v0: Adt1, v1: Adt1) -> bool {
    let a422 = match v0.clone() {
        Adt1::C0(h420, _, _) => {
            h420
        }
    };
    let a423 = match v1.clone() {
        Adt1::C0(h421, _, _) => {
            h421
        }
    };
    if nat_eq(a422, a423) {
        let a426 = match v0.clone() {
            Adt1::C0(_, h424, _) => {
                h424
            }
        };
        let a427 = match v1.clone() {
            Adt1::C0(_, h425, _) => {
                h425
            }
        };
        if nat_eq(a426, a427) {
            let a430 = match v0 {
                Adt1::C0(_, _, h428) => {
                    h428
                }
            };
            let a431 = match v1 {
                Adt1::C0(_, _, h429) => {
                    h429
                }
            };
            nat_eq(a430, a431)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f15(v0: Adt3, v1: Adt3) -> bool {
    let a434 = match v0.clone() {
        Adt3::C0(h432, _, _) => {
            h432
        }
    };
    let a435 = match v1.clone() {
        Adt3::C0(h433, _, _) => {
            h433
        }
    };
    if nat_eq(a434, a435) {
        let a438 = match v0.clone() {
            Adt3::C0(_, h436, _) => {
                h436
            }
        };
        let a439 = match v1.clone() {
            Adt3::C0(_, h437, _) => {
                h437
            }
        };
        if nat_eq(a438, a439) {
            let a442 = match v0 {
                Adt3::C0(_, _, h440) => {
                    h440
                }
            };
            let a443 = match v1 {
                Adt3::C0(_, _, h441) => {
                    h441
                }
            };
            nat_eq(a442, a443)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f16(v0: Adt5, v1: Adt7, v2: Adt10, v3: u64) -> R<Result<Adt7, Adt9>> {
    if f22(match v0.clone() {
        Adt5::C0(h444, _, _, _, _) => {
            h444
        }
    }, f23(v1.clone())?, v3)? {
        if f22(f24(v0.clone(), v2.clone()), {
            let a447 = f25(match v1.clone() {
                Adt7::C0(h445, _, _, _) => {
                    h445
                }
            }, v2.clone());
            let a448 = f25(match v1.clone() {
                Adt7::C0(_, h446, _, _) => {
                    h446
                }
            }, v2.clone());
            nat_add(a447, a448)?
        }, v3)? {
            Ok(Ok::<Adt7, Adt9>(Adt7::C0(match v1.clone() {
                Adt7::C0(h449, _, _, _) => {
                    h449
                }
            }, f26(match v1.clone() {
                Adt7::C0(_, h450, _, _) => {
                    h450
                }
            }, v2.clone(), {
                let a452 = f25(match v1.clone() {
                    Adt7::C0(_, h451, _, _) => {
                        h451
                    }
                }, v2.clone());
                let a453 = v3;
                nat_add(a452, a453)?
            }), f27(match v1.clone() {
                Adt7::C0(_, _, h454, _) => {
                    h454
                }
            }, f28(match v1.clone() {
                Adt7::C0(h455, _, _, _) => {
                    h455
                }
            })?), f27(match v1.clone() {
                Adt7::C0(_, _, _, h456) => {
                    h456
                }
            }, {
                let a462 = f28(match v1.clone() {
                    Adt7::C0(h457, _, _, _) => {
                        h457
                    }
                })?;
                let a463 = f28(f26(match v1.clone() {
                    Adt7::C0(_, h458, _, _) => {
                        h458
                    }
                }, v2.clone(), {
                    let a460 = f25(match v1 {
                        Adt7::C0(_, h459, _, _) => {
                            h459
                        }
                    }, v2);
                    let a461 = v3;
                    nat_add(a460, a461)?
                }))?;
                nat_add(a462, a463)?
            }))))
        } else {
            Ok(Err::<Adt7, Adt9>(Adt9::C1(v2.clone(), {
                let a466 = f25(match v1.clone() {
                    Adt7::C0(h464, _, _, _) => {
                        h464
                    }
                }, v2.clone());
                let a467 = f25(match v1 {
                    Adt7::C0(_, h465, _, _) => {
                        h465
                    }
                }, v2.clone());
                nat_add(a466, a467)?
            }, v3, {
                let m468 = f24(v0, v2);
                match m468 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C0(f23(v1)?, v3, {
            let m470 = match v0 {
                Adt5::C0(h469, _, _, _, _) => {
                    h469
                }
            };
            match m470 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f17(v0: Adt7, v1: Adt10, v2: u64, v3: u64) -> R<Result<Adt7, Adt9>> {
    let a474 = {
        let a472 = f25(match v0.clone() {
            Adt7::C0(_, h471, _, _) => {
                h471
            }
        }, v1.clone());
        let a473 = v2;
        nat_lt(a472, a473)
    };
    if if bool_not(a474) {
        let a477 = {
            let a475 = v2;
            let a476 = v3;
            nat_lt(a475, a476)
        };
        bool_not(a477)
    } else {
        false
    } {
        Ok(Ok::<Adt7, Adt9>(Adt7::C0(f26(match v0.clone() {
            Adt7::C0(h478, _, _, _) => {
                h478
            }
        }, v1.clone(), {
            let a480 = f25(match v0.clone() {
                Adt7::C0(h479, _, _, _) => {
                    h479
                }
            }, v1.clone());
            let a481 = v3;
            nat_add(a480, a481)?
        }), f26(match v0.clone() {
            Adt7::C0(_, h482, _, _) => {
                h482
            }
        }, v1.clone(), {
            let a484 = f25(match v0.clone() {
                Adt7::C0(_, h483, _, _) => {
                    h483
                }
            }, v1.clone());
            let a485 = v2;
            nat_sub(a484, a485)
        }), f27(match v0.clone() {
            Adt7::C0(_, _, h486, _) => {
                h486
            }
        }, f28(f26(match v0.clone() {
            Adt7::C0(h487, _, _, _) => {
                h487
            }
        }, v1.clone(), {
            let a489 = f25(match v0.clone() {
                Adt7::C0(h488, _, _, _) => {
                    h488
                }
            }, v1.clone());
            let a490 = v3;
            nat_add(a489, a490)?
        }))?), f27(match v0.clone() {
            Adt7::C0(_, _, _, h491) => {
                h491
            }
        }, {
            let a500 = f28(f26(match v0.clone() {
                Adt7::C0(h492, _, _, _) => {
                    h492
                }
            }, v1.clone(), {
                let a494 = f25(match v0.clone() {
                    Adt7::C0(h493, _, _, _) => {
                        h493
                    }
                }, v1.clone());
                let a495 = v3;
                nat_add(a494, a495)?
            }))?;
            let a501 = f28(f26(match v0.clone() {
                Adt7::C0(_, h496, _, _) => {
                    h496
                }
            }, v1.clone(), {
                let a498 = f25(match v0 {
                    Adt7::C0(_, h497, _, _) => {
                        h497
                    }
                }, v1);
                let a499 = v2;
                nat_sub(a498, a499)
            }))?;
            nat_add(a500, a501)?
        }))))
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C2(v1, v2, v3)))
    }
}

pub fn f18(v0: Adt7, v1: Adt10, v2: u64) -> R<Result<Adt7, Adt9>> {
    let a505 = {
        let a503 = f25(match v0.clone() {
            Adt7::C0(h502, _, _, _) => {
                h502
            }
        }, v1.clone());
        let a504 = v2;
        nat_lt(a503, a504)
    };
    if bool_not(a505) {
        Ok(Ok::<Adt7, Adt9>(Adt7::C0(f26(match v0.clone() {
            Adt7::C0(h506, _, _, _) => {
                h506
            }
        }, v1.clone(), {
            let a508 = f25(match v0.clone() {
                Adt7::C0(h507, _, _, _) => {
                    h507
                }
            }, v1.clone());
            let a509 = v2;
            nat_sub(a508, a509)
        }), match v0.clone() {
            Adt7::C0(_, h510, _, _) => {
                h510
            }
        }, f27(match v0.clone() {
            Adt7::C0(_, _, h511, _) => {
                h511
            }
        }, f28(f26(match v0.clone() {
            Adt7::C0(h512, _, _, _) => {
                h512
            }
        }, v1.clone(), {
            let a514 = f25(match v0.clone() {
                Adt7::C0(h513, _, _, _) => {
                    h513
                }
            }, v1.clone());
            let a515 = v2;
            nat_sub(a514, a515)
        }))?), f27(match v0.clone() {
            Adt7::C0(_, _, _, h516) => {
                h516
            }
        }, {
            let a522 = f28(f26(match v0.clone() {
                Adt7::C0(h517, _, _, _) => {
                    h517
                }
            }, v1.clone(), {
                let a519 = f25(match v0.clone() {
                    Adt7::C0(h518, _, _, _) => {
                        h518
                    }
                }, v1);
                let a520 = v2;
                nat_sub(a519, a520)
            }))?;
            let a523 = f28(match v0 {
                Adt7::C0(_, h521, _, _) => {
                    h521
                }
            })?;
            nat_add(a522, a523)?
        }))))
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C3(v1.clone(), f25(match v0 {
            Adt7::C0(h524, _, _, _) => {
                h524
            }
        }, v1), v2)))
    }
}

pub fn f19(v0: Adt11) -> R<Adt25> {
    let m526 = match v0.clone() {
        Adt11::C0(_, _, _, _, _, h525, _, _, _, _) => {
            h525
        }
    };
    match m526 {
        Adt12::C0 => {
            let a528 = match v0.clone() {
                Adt11::C0(_, _, h527, _, _, _, _, _, _, _) => {
                    h527
                }
            };
            let a529 = 0u64;
            if nat_eq(a528, a529) {
                Ok(Adt25::C0(Adt11::C0(match v0.clone() {
                    Adt11::C0(h530, _, _, _, _, _, _, _, _, _) => {
                        h530
                    }
                }, match v0.clone() {
                    Adt11::C0(_, h531, _, _, _, _, _, _, _, _) => {
                        h531
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, h532, _, _, _, _, _, _, _) => {
                        h532
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, h533, _, _, _, _, _, _) => {
                        h533
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, _, h534, _, _, _, _, _) => {
                        h534
                    }
                }, Adt12::C6, match v0.clone() {
                    Adt11::C0(_, _, _, _, _, _, h535, _, _, _) => {
                        h535
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, _, _, _, _, h536, _, _) => {
                        h536
                    }
                }, match v0 {
                    Adt11::C0(_, _, _, _, _, _, _, _, h537, _) => {
                        h537
                    }
                }, Some(Adt15::C0)), None::<Adt13>, None::<Adt3>))
            } else {
                Ok(Adt25::C0(Adt11::C0(match v0.clone() {
                    Adt11::C0(h538, _, _, _, _, _, _, _, _, _) => {
                        h538
                    }
                }, match v0.clone() {
                    Adt11::C0(_, h539, _, _, _, _, _, _, _, _) => {
                        h539
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, h540, _, _, _, _, _, _, _) => {
                        h540
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, h541, _, _, _, _, _, _) => {
                        h541
                    }
                }, {
                    let a543 = match v0.clone() {
                        Adt11::C0(_, _, _, _, h542, _, _, _, _, _) => {
                            h542
                        }
                    };
                    let a544 = 1u64;
                    nat_add(a543, a544)?
                }, Adt12::C1, Some(Adt13::C0(match v0.clone() {
                    Adt11::C0(h545, _, _, _, _, _, _, _, _, _) => {
                        h545
                    }
                }, {
                    let m548 = match v0.clone() {
                        Adt11::C0(_, h547, _, _, _, _, _, _, _, _) => {
                            h547
                        }
                    };
                    match m548 {
                        Adt2::C0(h546, _, _) => {
                            h546
                        }
                    }
                }, {
                    let a550 = match v0.clone() {
                        Adt11::C0(_, _, _, _, h549, _, _, _, _, _) => {
                            h549
                        }
                    };
                    let a551 = 1u64;
                    nat_add(a550, a551)?
                }, match v0.clone() {
                    Adt11::C0(_, _, _, h552, _, _, _, _, _, _) => {
                        h552
                    }
                }, f29(v0.clone()))), match v0.clone() {
                    Adt11::C0(_, _, _, _, _, _, _, h553, _, _) => {
                        h553
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, _, _, _, _, _, h554, _) => {
                        h554
                    }
                }, match v0.clone() {
                    Adt11::C0(_, _, _, _, _, _, _, _, _, h555) => {
                        h555
                    }
                }), Some(Adt13::C0(match v0.clone() {
                    Adt11::C0(h556, _, _, _, _, _, _, _, _, _) => {
                        h556
                    }
                }, {
                    let m559 = match v0.clone() {
                        Adt11::C0(_, h558, _, _, _, _, _, _, _, _) => {
                            h558
                        }
                    };
                    match m559 {
                        Adt2::C0(h557, _, _) => {
                            h557
                        }
                    }
                }, {
                    let a561 = match v0.clone() {
                        Adt11::C0(_, _, _, _, h560, _, _, _, _, _) => {
                            h560
                        }
                    };
                    let a562 = 1u64;
                    nat_add(a561, a562)?
                }, match v0.clone() {
                    Adt11::C0(_, _, _, h563, _, _, _, _, _, _) => {
                        h563
                    }
                }, f29(v0))), None::<Adt3>))
            }
        }
        Adt12::C1 => {
            Ok(Adt25::C0(v0, None::<Adt13>, None::<Adt3>))
        }
        Adt12::C2 => {
            Ok(Adt25::C0(v0, None::<Adt13>, None::<Adt3>))
        }
        Adt12::C3 => {
            Ok(Adt25::C0(v0, None::<Adt13>, None::<Adt3>))
        }
        Adt12::C4 => {
            Ok(Adt25::C0(v0, None::<Adt13>, None::<Adt3>))
        }
        Adt12::C5 => {
            Ok(Adt25::C0(v0, None::<Adt13>, None::<Adt3>))
        }
        Adt12::C6 => {
            Ok(Adt25::C0(v0, None::<Adt13>, None::<Adt3>))
        }
    }
}

pub fn f20(v0: Adt16, v1: Adt14, v2: Adt6) -> R<Adt23> {
    let m565 = match v2.clone() {
        Adt6::C0(_, h564) => {
            h564
        }
    };
    match m565 {
        None => {
            Ok(Adt23::C0(Adt16::C0(match v0.clone() {
                Adt16::C0(h574, _, _, _, _, _, _, _, _, _, _) => {
                    h574
                }
            }, match v0.clone() {
                Adt16::C0(_, h575, _, _, _, _, _, _, _, _, _) => {
                    h575
                }
            }, match v0.clone() {
                Adt16::C0(_, _, h576, _, _, _, _, _, _, _, _) => {
                    h576
                }
            }, match v0.clone() {
                Adt16::C0(_, _, _, h577, _, _, _, _, _, _, _) => {
                    h577
                }
            }, v2, match v0.clone() {
                Adt16::C0(_, _, _, _, _, h578, _, _, _, _, _) => {
                    h578
                }
            }, {
                let a580 = match v0.clone() {
                    Adt16::C0(_, _, _, _, _, _, h579, _, _, _, _) => {
                        h579
                    }
                };
                let a581 = 1u64;
                nat_add(a580, a581)?
            }, Adt17::C1, Some(Adt18::C0(match v0.clone() {
                Adt16::C0(h582, _, _, _, _, _, _, _, _, _, _) => {
                    h582
                }
            }, match v0.clone() {
                Adt16::C0(_, h583, _, _, _, _, _, _, _, _, _) => {
                    h583
                }
            }, {
                let a585 = match v0.clone() {
                    Adt16::C0(_, _, _, _, _, _, h584, _, _, _, _) => {
                        h584
                    }
                };
                let a586 = 1u64;
                nat_add(a585, a586)?
            }, match v0.clone() {
                Adt16::C0(_, _, _, _, _, h587, _, _, _, _, _) => {
                    h587
                }
            }, v1.clone())), Some(v1.clone()), match v0.clone() {
                Adt16::C0(_, _, _, _, _, _, _, _, _, _, h588) => {
                    h588
                }
            }), Some(Adt18::C0(match v0.clone() {
                Adt16::C0(h589, _, _, _, _, _, _, _, _, _, _) => {
                    h589
                }
            }, match v0.clone() {
                Adt16::C0(_, h590, _, _, _, _, _, _, _, _, _) => {
                    h590
                }
            }, {
                let a592 = match v0.clone() {
                    Adt16::C0(_, _, _, _, _, _, h591, _, _, _, _) => {
                        h591
                    }
                };
                let a593 = 1u64;
                nat_add(a592, a593)?
            }, match v0 {
                Adt16::C0(_, _, _, _, _, h594, _, _, _, _, _) => {
                    h594
                }
            }, v1)), None::<Adt3>))
        }
        Some(_) => {
            Ok(Adt23::C0(Adt16::C0(match v0.clone() {
                Adt16::C0(h566, _, _, _, _, _, _, _, _, _, _) => {
                    h566
                }
            }, match v0.clone() {
                Adt16::C0(_, h567, _, _, _, _, _, _, _, _, _) => {
                    h567
                }
            }, match v0.clone() {
                Adt16::C0(_, _, h568, _, _, _, _, _, _, _, _) => {
                    h568
                }
            }, match v0.clone() {
                Adt16::C0(_, _, _, h569, _, _, _, _, _, _, _) => {
                    h569
                }
            }, v2, match v0.clone() {
                Adt16::C0(_, _, _, _, _, h570, _, _, _, _, _) => {
                    h570
                }
            }, match v0.clone() {
                Adt16::C0(_, _, _, _, _, _, h571, _, _, _, _) => {
                    h571
                }
            }, Adt17::C4, match v0.clone() {
                Adt16::C0(_, _, _, _, _, _, _, _, h572, _, _) => {
                    h572
                }
            }, Some(v1), match v0 {
                Adt16::C0(_, _, _, _, _, _, _, _, _, _, h573) => {
                    h573
                }
            }), None::<Adt18>, None::<Adt3>))
        }
    }
}

pub fn f21(v0: Adt14) -> Option<Adt3> {
    let a596 = match v0.clone() {
        Adt14::C0(_, _, h595) => {
            h595
        }
    };
    let a597 = 0u64;
    if nat_eq(a596, a597) {
        None::<Adt3>
    } else {
        Some(match v0 {
            Adt14::C0(h598, _, _) => {
                h598
            }
        })
    }
}

pub fn f22(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m599 = v0;
    match m599 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a604 = {
                let a602 = v3;
                let a603 = {
                    let a600 = v1;
                    let a601 = v2;
                    nat_add(a600, a601)?
                };
                nat_lt(a602, a603)
            };
            Ok(bool_not(a604))
        }
    }
}

pub fn f23(v0: Adt7) -> R<u64> {
    let a605 = f30(v0.clone())?;
    let a606 = f31(v0)?;
    nat_add(a605, a606)
}

pub fn f24(v0: Adt5, v1: Adt10) -> Option<u64> {
    let m607 = v1;
    match m607 {
        Adt10::C0 => {
            match v0 {
                Adt5::C0(_, h608, _, _, _) => {
                    h608
                }
            }
        }
        Adt10::C1 => {
            match v0 {
                Adt5::C0(_, _, h609, _, _) => {
                    h609
                }
            }
        }
        Adt10::C2 => {
            match v0 {
                Adt5::C0(_, _, _, h610, _) => {
                    h610
                }
            }
        }
        Adt10::C3 => {
            match v0 {
                Adt5::C0(_, _, _, _, h611) => {
                    h611
                }
            }
        }
    }
}

pub fn f25(v0: Adt8, v1: Adt10) -> u64 {
    let m612 = v1;
    match m612 {
        Adt10::C0 => {
            match v0 {
                Adt8::C0(h613, _, _, _) => {
                    h613
                }
            }
        }
        Adt10::C1 => {
            match v0 {
                Adt8::C0(_, h614, _, _) => {
                    h614
                }
            }
        }
        Adt10::C2 => {
            match v0 {
                Adt8::C0(_, _, h615, _) => {
                    h615
                }
            }
        }
        Adt10::C3 => {
            match v0 {
                Adt8::C0(_, _, _, h616) => {
                    h616
                }
            }
        }
    }
}

pub fn f26(v0: Adt8, v1: Adt10, v2: u64) -> Adt8 {
    let m617 = v1;
    match m617 {
        Adt10::C0 => {
            Adt8::C0(v2, match v0.clone() {
                Adt8::C0(_, h618, _, _) => {
                    h618
                }
            }, match v0.clone() {
                Adt8::C0(_, _, h619, _) => {
                    h619
                }
            }, match v0 {
                Adt8::C0(_, _, _, h620) => {
                    h620
                }
            })
        }
        Adt10::C1 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h621, _, _, _) => {
                    h621
                }
            }, v2, match v0.clone() {
                Adt8::C0(_, _, h622, _) => {
                    h622
                }
            }, match v0 {
                Adt8::C0(_, _, _, h623) => {
                    h623
                }
            })
        }
        Adt10::C2 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h624, _, _, _) => {
                    h624
                }
            }, match v0.clone() {
                Adt8::C0(_, h625, _, _) => {
                    h625
                }
            }, v2, match v0 {
                Adt8::C0(_, _, _, h626) => {
                    h626
                }
            })
        }
        Adt10::C3 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h627, _, _, _) => {
                    h627
                }
            }, match v0.clone() {
                Adt8::C0(_, h628, _, _) => {
                    h628
                }
            }, match v0 {
                Adt8::C0(_, _, h629, _) => {
                    h629
                }
            }, v2)
        }
    }
}

pub fn f27(v0: u64, v1: u64) -> u64 {
    let a630 = v0;
    let a631 = v1;
    if nat_lt(a630, a631) {
        v1
    } else {
        v0
    }
}

pub fn f28(v0: Adt8) -> R<u64> {
    let a642 = {
        let a639 = {
            let a636 = {
                let a633 = 0u64;
                let a634 = match v0.clone() {
                    Adt8::C0(h632, _, _, _) => {
                        h632
                    }
                };
                nat_add(a633, a634)?
            };
            let a637 = match v0.clone() {
                Adt8::C0(_, h635, _, _) => {
                    h635
                }
            };
            nat_add(a636, a637)?
        };
        let a640 = match v0.clone() {
            Adt8::C0(_, _, h638, _) => {
                h638
            }
        };
        nat_add(a639, a640)?
    };
    let a643 = match v0 {
        Adt8::C0(_, _, _, h641) => {
            h641
        }
    };
    nat_add(a642, a643)
}

pub fn f29(v0: Adt11) -> u64 {
    let m647 = {
        let m646 = match v0.clone() {
            Adt11::C0(_, h645, _, _, _, _, _, _, _, _) => {
                h645
            }
        };
        match m646 {
            Adt2::C0(_, h644, _) => {
                h644
            }
        }
    };
    match m647 {
        None => {
            match v0 {
                Adt11::C0(_, _, h648, _, _, _, _, _, _, _) => {
                    h648
                }
            }
        }
        Some(v1) => {
            let a650 = v1;
            let a651 = match v0.clone() {
                Adt11::C0(_, _, _, h649, _, _, _, _, _, _) => {
                    h649
                }
            };
            if nat_eq(a650, a651) {
                1u64
            } else {
                let a656 = match v0.clone() {
                    Adt11::C0(_, _, h652, _, _, _, _, _, _, _) => {
                        h652
                    }
                };
                let a657 = {
                    let a654 = v1;
                    let a655 = match v0.clone() {
                        Adt11::C0(_, _, _, h653, _, _, _, _, _, _) => {
                            h653
                        }
                    };
                    nat_sub(a654, a655)
                };
                if nat_lt(a656, a657) {
                    match v0 {
                        Adt11::C0(_, _, h658, _, _, _, _, _, _, _) => {
                            h658
                        }
                    }
                } else {
                    let a660 = v1;
                    let a661 = match v0 {
                        Adt11::C0(_, _, _, h659, _, _, _, _, _, _) => {
                            h659
                        }
                    };
                    nat_sub(a660, a661)
                }
            }
        }
    }
}

pub fn f30(v0: Adt7) -> R<u64> {
    f28(match v0 {
        Adt7::C0(h662, _, _, _) => {
            h662
        }
    })
}

pub fn f31(v0: Adt7) -> R<u64> {
    f28(match v0 {
        Adt7::C0(_, h663, _, _) => {
            h663
        }
    })
}
