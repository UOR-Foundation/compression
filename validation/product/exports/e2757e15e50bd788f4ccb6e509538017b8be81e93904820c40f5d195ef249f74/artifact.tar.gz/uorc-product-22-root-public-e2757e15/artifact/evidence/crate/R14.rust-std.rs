#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt2, u64, Adt5, Adt6, Adt11, Option<Adt16>, Adt19, Option<Adt2>, bool, bool),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt3, Option<u64>, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt7, Option<Adt9>),
}

#[derive(Clone)]
pub enum Adt7 {
    C0(Adt8, Adt8, u64, u64),
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(u64, u64, u64),
    C1(Adt10, u64, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64, u64),
}

#[derive(Clone)]
pub enum Adt10 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt11 {
    C0(Adt1, Adt2, u64, u64, u64, Adt12, Option<Adt13>, Option<Adt14>, bool, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt12 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt13 {
    C0(Adt1, Adt3, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Adt3, u64, u64),
}

#[derive(Clone)]
pub enum Adt15 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt1, Adt3, Adt10, Adt5, Adt6, u64, u64, Adt17, Option<Adt18>, Option<Adt14>, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt17 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt1, Adt3, u64, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt19 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt0, List<Adt21>),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt1),
    C1(Adt13),
    C2(Adt18),
    C3(Adt3, u64),
    C4(Adt3),
    C5(Adt1),
    C6(Adt1, Adt3, u64),
    C7(Adt13),
}

pub fn f0(v0: Adt0) -> Adt20 {
    let a2 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, _, _, h1, _) => {
            h1
        }
    };
    if if bool_not(a2) {
        let a4 = match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h3) => {
                h3
            }
        };
        if bool_not(a4) {
            let a9 = {
                let m8 = {
                    let m7 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h6, _, _, _, _, _) => {
                            h6
                        }
                    };
                    match m7 {
                        Adt11::C0(_, _, _, _, _, _, h5, _, _, _) => {
                            h5
                        }
                    }
                };
                match m8 {
                    None => {
                        false
                    }
                    Some(_) => {
                        true
                    }
                }
            };
            if bool_not(a9) {
                let a14 = {
                    let m13 = {
                        let m12 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h11, _, _, _, _, _) => {
                                h11
                            }
                        };
                        match m12 {
                            Adt11::C0(_, _, _, _, _, _, _, h10, _, _) => {
                                h10
                            }
                        }
                    };
                    match m13 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                };
                bool_not(a14)
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    } {
        let m16 = match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, _, h15, _, _, _) => {
                h15
            }
        };
        match m16 {
            Adt19::C0 => {
                let m18 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h17, _, _, _, _) => {
                        h17
                    }
                };
                match m18 {
                    None => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h19, _, _, _, _, _, _, _, _, _, _) => {
                                h19
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h20, _, _, _, _, _, _, _, _, _) => {
                                h20
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h21, _, _, _, _, _, _, _, _) => {
                                h21
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h22, _, _, _, _, _, _, _) => {
                                h22
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h23, _, _, _, _, _, _) => {
                                h23
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h24, _, _, _, _, _) => {
                                h24
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h25, _, _, _, _) => {
                                h25
                            }
                        }, Adt19::C7, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h26, _) => {
                                h26
                            }
                        }, match v0 {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h27) => {
                                h27
                            }
                        }), List::<Adt21>::nil())
                    }
                    Some(v3) => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h28, _, _, _, _, _, _, _, _, _, _) => {
                                h28
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h29, _, _, _, _, _, _, _, _, _) => {
                                h29
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h30, _, _, _, _, _, _, _, _) => {
                                h30
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h31, _, _, _, _, _, _, _) => {
                                h31
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h32, _, _, _, _, _, _) => {
                                h32
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h33, _, _, _, _, _) => {
                                h33
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h34, _, _, _, _) => {
                                h34
                            }
                        }, Adt19::C6, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h35, _) => {
                                h35
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h36) => {
                                h36
                            }
                        }), List::cons(Adt21::C6(match v0 {
                            Adt0::C0(h37, _, _, _, _, _, _, _, _, _, _) => {
                                h37
                            }
                        }, match v3.clone() {
                            Adt16::C0(_, h38, _, _, _, _, _, _, _, _, _) => {
                                h38
                            }
                        }, match v3 {
                            Adt16::C0(_, _, _, _, _, h39, _, _, _, _, _) => {
                                h39
                            }
                        }), List::<Adt21>::nil()))
                    }
                }
            }
            Adt19::C1 => {
                let m41 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h40, _, _, _, _) => {
                        h40
                    }
                };
                match m41 {
                    None => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h42, _, _, _, _, _, _, _, _, _, _) => {
                                h42
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h43, _, _, _, _, _, _, _, _, _) => {
                                h43
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h44, _, _, _, _, _, _, _, _) => {
                                h44
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h45, _, _, _, _, _, _, _) => {
                                h45
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h46, _, _, _, _, _, _) => {
                                h46
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h47, _, _, _, _, _) => {
                                h47
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h48, _, _, _, _) => {
                                h48
                            }
                        }, Adt19::C7, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h49, _) => {
                                h49
                            }
                        }, match v0 {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h50) => {
                                h50
                            }
                        }), List::<Adt21>::nil())
                    }
                    Some(v4) => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h51, _, _, _, _, _, _, _, _, _, _) => {
                                h51
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h52, _, _, _, _, _, _, _, _, _) => {
                                h52
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h53, _, _, _, _, _, _, _, _) => {
                                h53
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h54, _, _, _, _, _, _, _) => {
                                h54
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h55, _, _, _, _, _, _) => {
                                h55
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h56, _, _, _, _, _) => {
                                h56
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h57, _, _, _, _) => {
                                h57
                            }
                        }, Adt19::C6, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h58, _) => {
                                h58
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h59) => {
                                h59
                            }
                        }), List::cons(Adt21::C6(match v0 {
                            Adt0::C0(h60, _, _, _, _, _, _, _, _, _, _) => {
                                h60
                            }
                        }, match v4.clone() {
                            Adt16::C0(_, h61, _, _, _, _, _, _, _, _, _) => {
                                h61
                            }
                        }, match v4 {
                            Adt16::C0(_, _, _, _, _, h62, _, _, _, _, _) => {
                                h62
                            }
                        }), List::<Adt21>::nil()))
                    }
                }
            }
            Adt19::C2 => {
                Adt20::C0(v0, List::<Adt21>::nil())
            }
            Adt19::C3 => {
                let m64 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h63, _, _, _, _) => {
                        h63
                    }
                };
                match m64 {
                    None => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h65, _, _, _, _, _, _, _, _, _, _) => {
                                h65
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h66, _, _, _, _, _, _, _, _, _) => {
                                h66
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h67, _, _, _, _, _, _, _, _) => {
                                h67
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h68, _, _, _, _, _, _, _) => {
                                h68
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h69, _, _, _, _, _, _) => {
                                h69
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h70, _, _, _, _, _) => {
                                h70
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h71, _, _, _, _) => {
                                h71
                            }
                        }, Adt19::C7, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h72, _) => {
                                h72
                            }
                        }, match v0 {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h73) => {
                                h73
                            }
                        }), List::<Adt21>::nil())
                    }
                    Some(v5) => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h74, _, _, _, _, _, _, _, _, _, _) => {
                                h74
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h75, _, _, _, _, _, _, _, _, _) => {
                                h75
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h76, _, _, _, _, _, _, _, _) => {
                                h76
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h77, _, _, _, _, _, _, _) => {
                                h77
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h78, _, _, _, _, _, _) => {
                                h78
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h79, _, _, _, _, _) => {
                                h79
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h80, _, _, _, _) => {
                                h80
                            }
                        }, Adt19::C6, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h81, _) => {
                                h81
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h82) => {
                                h82
                            }
                        }), List::cons(Adt21::C6(match v0 {
                            Adt0::C0(h83, _, _, _, _, _, _, _, _, _, _) => {
                                h83
                            }
                        }, match v5.clone() {
                            Adt16::C0(_, h84, _, _, _, _, _, _, _, _, _) => {
                                h84
                            }
                        }, match v5 {
                            Adt16::C0(_, _, _, _, _, h85, _, _, _, _, _) => {
                                h85
                            }
                        }), List::<Adt21>::nil()))
                    }
                }
            }
            Adt19::C4 => {
                let m87 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h86, _, _, _, _) => {
                        h86
                    }
                };
                match m87 {
                    None => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h88, _, _, _, _, _, _, _, _, _, _) => {
                                h88
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h89, _, _, _, _, _, _, _, _, _) => {
                                h89
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h90, _, _, _, _, _, _, _, _) => {
                                h90
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h91, _, _, _, _, _, _, _) => {
                                h91
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h92, _, _, _, _, _, _) => {
                                h92
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h93, _, _, _, _, _) => {
                                h93
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h94, _, _, _, _) => {
                                h94
                            }
                        }, Adt19::C7, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h95, _) => {
                                h95
                            }
                        }, match v0 {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h96) => {
                                h96
                            }
                        }), List::<Adt21>::nil())
                    }
                    Some(v6) => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h97, _, _, _, _, _, _, _, _, _, _) => {
                                h97
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h98, _, _, _, _, _, _, _, _, _) => {
                                h98
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h99, _, _, _, _, _, _, _, _) => {
                                h99
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h100, _, _, _, _, _, _, _) => {
                                h100
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h101, _, _, _, _, _, _) => {
                                h101
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h102, _, _, _, _, _) => {
                                h102
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h103, _, _, _, _) => {
                                h103
                            }
                        }, Adt19::C6, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h104, _) => {
                                h104
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h105) => {
                                h105
                            }
                        }), List::cons(Adt21::C6(match v0 {
                            Adt0::C0(h106, _, _, _, _, _, _, _, _, _, _) => {
                                h106
                            }
                        }, match v6.clone() {
                            Adt16::C0(_, h107, _, _, _, _, _, _, _, _, _) => {
                                h107
                            }
                        }, match v6 {
                            Adt16::C0(_, _, _, _, _, h108, _, _, _, _, _) => {
                                h108
                            }
                        }), List::<Adt21>::nil()))
                    }
                }
            }
            Adt19::C5 => {
                Adt20::C0(v0, List::<Adt21>::nil())
            }
            Adt19::C6 => {
                Adt20::C0(v0, List::<Adt21>::nil())
            }
            Adt19::C7 => {
                let m110 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h109, _, _, _, _) => {
                        h109
                    }
                };
                match m110 {
                    None => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h111, _, _, _, _, _, _, _, _, _, _) => {
                                h111
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h112, _, _, _, _, _, _, _, _, _) => {
                                h112
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h113, _, _, _, _, _, _, _, _) => {
                                h113
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h114, _, _, _, _, _, _, _) => {
                                h114
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h115, _, _, _, _, _, _) => {
                                h115
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h116, _, _, _, _, _) => {
                                h116
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h117, _, _, _, _) => {
                                h117
                            }
                        }, Adt19::C7, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h118, _) => {
                                h118
                            }
                        }, match v0 {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h119) => {
                                h119
                            }
                        }), List::<Adt21>::nil())
                    }
                    Some(v7) => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h120, _, _, _, _, _, _, _, _, _, _) => {
                                h120
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h121, _, _, _, _, _, _, _, _, _) => {
                                h121
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h122, _, _, _, _, _, _, _, _) => {
                                h122
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h123, _, _, _, _, _, _, _) => {
                                h123
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h124, _, _, _, _, _, _) => {
                                h124
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h125, _, _, _, _, _) => {
                                h125
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h126, _, _, _, _) => {
                                h126
                            }
                        }, Adt19::C6, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h127, _) => {
                                h127
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h128) => {
                                h128
                            }
                        }), List::cons(Adt21::C6(match v0 {
                            Adt0::C0(h129, _, _, _, _, _, _, _, _, _, _) => {
                                h129
                            }
                        }, match v7.clone() {
                            Adt16::C0(_, h130, _, _, _, _, _, _, _, _, _) => {
                                h130
                            }
                        }, match v7 {
                            Adt16::C0(_, _, _, _, _, h131, _, _, _, _, _) => {
                                h131
                            }
                        }), List::<Adt21>::nil()))
                    }
                }
            }
            Adt19::C8 => {
                let m133 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h132, _, _, _, _) => {
                        h132
                    }
                };
                match m133 {
                    None => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h134, _, _, _, _, _, _, _, _, _, _) => {
                                h134
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h135, _, _, _, _, _, _, _, _, _) => {
                                h135
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h136, _, _, _, _, _, _, _, _) => {
                                h136
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h137, _, _, _, _, _, _, _) => {
                                h137
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h138, _, _, _, _, _, _) => {
                                h138
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h139, _, _, _, _, _) => {
                                h139
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h140, _, _, _, _) => {
                                h140
                            }
                        }, Adt19::C7, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h141, _) => {
                                h141
                            }
                        }, match v0 {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h142) => {
                                h142
                            }
                        }), List::<Adt21>::nil())
                    }
                    Some(v8) => {
                        Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h143, _, _, _, _, _, _, _, _, _, _) => {
                                h143
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h144, _, _, _, _, _, _, _, _, _) => {
                                h144
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h145, _, _, _, _, _, _, _, _) => {
                                h145
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h146, _, _, _, _, _, _, _) => {
                                h146
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h147, _, _, _, _, _, _) => {
                                h147
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h148, _, _, _, _, _) => {
                                h148
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h149, _, _, _, _) => {
                                h149
                            }
                        }, Adt19::C6, None::<Adt2>, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h150, _) => {
                                h150
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h151) => {
                                h151
                            }
                        }), List::cons(Adt21::C6(match v0 {
                            Adt0::C0(h152, _, _, _, _, _, _, _, _, _, _) => {
                                h152
                            }
                        }, match v8.clone() {
                            Adt16::C0(_, h153, _, _, _, _, _, _, _, _, _) => {
                                h153
                            }
                        }, match v8 {
                            Adt16::C0(_, _, _, _, _, h154, _, _, _, _, _) => {
                                h154
                            }
                        }), List::<Adt21>::nil()))
                    }
                }
            }
        }
    } else {
        Adt20::C0(v0, List::<Adt21>::nil())
    }
}
