#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt2, u64, Adt5, Adt6, Adt11, Option<Adt16>, Adt19, Option<Adt2>, bool, bool),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt3, Option<u64>, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt7, Option<Adt9>),
}

#[derive(Clone)]
pub enum Adt7 {
    C0(Adt8, Adt8, u64, u64),
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(u64, u64, u64),
    C1(Adt10, u64, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64, u64),
}

#[derive(Clone)]
pub enum Adt10 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt11 {
    C0(Adt1, Adt2, u64, u64, u64, Adt12, Option<Adt13>, Option<Adt14>, bool, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt12 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt13 {
    C0(Adt1, Adt3, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Adt3, u64, u64),
}

#[derive(Clone)]
pub enum Adt15 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt1, Adt3, Adt10, Adt5, Adt6, u64, u64, Adt17, Option<Adt18>, Option<Adt14>, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt17 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt1, Adt3, u64, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt19 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt1, Adt3, u64, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt0, List<Adt22>),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt1),
    C1(Adt13),
    C2(Adt18),
    C3(Adt3, u64),
    C4(Adt3),
    C5(Adt1),
    C6(Adt1, Adt3, u64),
    C7(Adt13),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(Adt16, Option<Adt18>, Option<Adt3>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(Adt10, u64),
    C1(Adt10, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64),
    C4(Adt10, u64),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(Adt11, Option<Adt13>, Option<Adt3>),
}

pub fn f0(v0: Adt0, v1: Adt20) -> R<Adt21> {
    let m2 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, h1, _, _, _) => {
            h1
        }
    };
    match m2 {
        Adt19::C0 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C1 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C2 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C3 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C4 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C5 => {
            let m4 = match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h3, _, _, _, _) => {
                    h3
                }
            };
            match m4 {
                None => {
                    Ok(Adt21::C0(v0, List::<Adt22>::nil()))
                }
                Some(v2) => {
                    Ok(f1(v0, f2(v2, v1)?))
                }
            }
        }
        Adt19::C6 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C7 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
        Adt19::C8 => {
            Ok(Adt21::C0(v0, List::<Adt22>::nil()))
        }
    }
}

pub fn f1(v0: Adt0, v1: Adt23) -> Adt21 {
    let m8 = {
        let m7 = match v1.clone() {
            Adt23::C0(h6, _, _) => {
                h6
            }
        };
        match m7 {
            Adt16::C0(_, _, _, _, _, _, _, _, h5, _, _) => {
                h5
            }
        }
    };
    match m8 {
        None => {
            Adt21::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h9, _, _, _, _, _, _, _, _, _, _) => {
                    h9
                }
            }, match v0.clone() {
                Adt0::C0(_, h10, _, _, _, _, _, _, _, _, _) => {
                    h10
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h11, _, _, _, _, _, _, _, _) => {
                    h11
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h12, _, _, _, _, _, _, _) => {
                    h12
                }
            }, {
                let m15 = match v1.clone() {
                    Adt23::C0(h14, _, _) => {
                        h14
                    }
                };
                match m15 {
                    Adt16::C0(_, _, _, _, h13, _, _, _, _, _, _) => {
                        h13
                    }
                }
            }, {
                let m18 = f3(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h17, _, _, _, _, _) => {
                        h17
                    }
                });
                match m18 {
                    Adt25::C0(h16, _, _) => {
                        h16
                    }
                }
            }, Some(match v1 {
                Adt23::C0(h19, _, _) => {
                    h19
                }
            }), Adt19::C7, None::<Adt2>, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, h20, _) => {
                    h20
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h21) => {
                    h21
                }
            }), {
                let m25 = {
                    let m24 = f3(match v0 {
                        Adt0::C0(_, _, _, _, _, h23, _, _, _, _, _) => {
                            h23
                        }
                    });
                    match m24 {
                        Adt25::C0(_, _, h22) => {
                            h22
                        }
                    }
                };
                match m25 {
                    None => {
                        List::<Adt22>::nil()
                    }
                    Some(v3) => {
                        List::cons(Adt22::C4(v3), List::<Adt22>::nil())
                    }
                }
            })
        }
        Some(_) => {
            Adt21::C0(v0, List::<Adt22>::nil())
        }
    }
}

pub fn f2(v0: Adt16, v1: Adt20) -> R<Adt23> {
    let m27 = match v0.clone() {
        Adt16::C0(_, _, _, _, _, _, _, _, h26, _, _) => {
            h26
        }
    };
    match m27 {
        None => {
            Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
        }
        Some(v2) => {
            if f4(v0.clone(), v1.clone()) {
                let a34 = {
                    let a32 = {
                        let m30 = match v2.clone() {
                            Adt18::C0(_, _, _, _, h29) => {
                                h29
                            }
                        };
                        match m30 {
                            Adt14::C0(_, _, h28) => {
                                h28
                            }
                        }
                    };
                    let a33 = match v1.clone() {
                        Adt20::C0(_, _, _, _, h31, _) => {
                            h31
                        }
                    };
                    nat_lt(a32, a33)
                };
                if bool_not(a34) {
                    Ok(Adt23::C0(Adt16::C0(match v0.clone() {
                        Adt16::C0(h35, _, _, _, _, _, _, _, _, _, _) => {
                            h35
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, h36, _, _, _, _, _, _, _, _, _) => {
                            h36
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, h37, _, _, _, _, _, _, _, _) => {
                            h37
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, h38, _, _, _, _, _, _, _) => {
                            h38
                        }
                    }, f5(match v0.clone() {
                        Adt16::C0(_, _, _, h39, _, _, _, _, _, _, _) => {
                            h39
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, _, h40, _, _, _, _, _, _) => {
                            h40
                        }
                    }, Adt24::C2(match v0.clone() {
                        Adt16::C0(_, _, h41, _, _, _, _, _, _, _, _) => {
                            h41
                        }
                    }, {
                        let m44 = match v2.clone() {
                            Adt18::C0(_, _, _, _, h43) => {
                                h43
                            }
                        };
                        match m44 {
                            Adt14::C0(_, _, h42) => {
                                h42
                            }
                        }
                    }, match v1.clone() {
                        Adt20::C0(_, _, _, _, h45, _) => {
                            h45
                        }
                    }))?, {
                        let a48 = match v0.clone() {
                            Adt16::C0(_, _, _, _, _, h46, _, _, _, _, _) => {
                                h46
                            }
                        };
                        let a49 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h47, _) => {
                                h47
                            }
                        };
                        nat_add(a48, a49)?
                    }, match v0 {
                        Adt16::C0(_, _, _, _, _, _, h50, _, _, _, _) => {
                            h50
                        }
                    }, if if match v1.clone() {
                        Adt20::C0(_, _, _, _, _, h51) => {
                            h51
                        }
                    } {
                        true
                    } else {
                        let a53 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h52, _) => {
                                h52
                            }
                        };
                        let a54 = 0u64;
                        if nat_eq(a53, a54) {
                            let a60 = {
                                let a58 = {
                                    let m57 = match v2.clone() {
                                        Adt18::C0(_, _, _, _, h56) => {
                                            h56
                                        }
                                    };
                                    match m57 {
                                        Adt14::C0(_, _, h55) => {
                                            h55
                                        }
                                    }
                                };
                                let a59 = 0u64;
                                nat_eq(a58, a59)
                            };
                            bool_not(a60)
                        } else {
                            false
                        }
                    } {
                        Adt17::C4
                    } else {
                        Adt17::C0
                    }, None::<Adt18>, {
                        let a65 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h61, _) => {
                                h61
                            }
                        };
                        let a66 = {
                            let m64 = match v2.clone() {
                                Adt18::C0(_, _, _, _, h63) => {
                                    h63
                                }
                            };
                            match m64 {
                                Adt14::C0(_, _, h62) => {
                                    h62
                                }
                            }
                        };
                        if nat_eq(a65, a66) {
                            None::<Adt14>
                        } else {
                            Some(Adt14::C0({
                                let m69 = match v2.clone() {
                                    Adt18::C0(_, _, _, _, h68) => {
                                        h68
                                    }
                                };
                                match m69 {
                                    Adt14::C0(h67, _, _) => {
                                        h67
                                    }
                                }
                            }, {
                                let a74 = {
                                    let m72 = match v2.clone() {
                                        Adt18::C0(_, _, _, _, h71) => {
                                            h71
                                        }
                                    };
                                    match m72 {
                                        Adt14::C0(_, h70, _) => {
                                            h70
                                        }
                                    }
                                };
                                let a75 = match v1.clone() {
                                    Adt20::C0(_, _, _, _, h73, _) => {
                                        h73
                                    }
                                };
                                nat_add(a74, a75)?
                            }, {
                                let a80 = {
                                    let m78 = match v2.clone() {
                                        Adt18::C0(_, _, _, _, h77) => {
                                            h77
                                        }
                                    };
                                    match m78 {
                                        Adt14::C0(_, _, h76) => {
                                            h76
                                        }
                                    }
                                };
                                let a81 = match v1.clone() {
                                    Adt20::C0(_, _, _, _, h79, _) => {
                                        h79
                                    }
                                };
                                nat_sub(a80, a81)
                            }))
                        }
                    }, if if match v1.clone() {
                        Adt20::C0(_, _, _, _, _, h82) => {
                            h82
                        }
                    } {
                        true
                    } else {
                        let a84 = match v1.clone() {
                            Adt20::C0(_, _, _, _, h83, _) => {
                                h83
                            }
                        };
                        let a85 = 0u64;
                        if nat_eq(a84, a85) {
                            let a91 = {
                                let a89 = {
                                    let m88 = match v2.clone() {
                                        Adt18::C0(_, _, _, _, h87) => {
                                            h87
                                        }
                                    };
                                    match m88 {
                                        Adt14::C0(_, _, h86) => {
                                            h86
                                        }
                                    }
                                };
                                let a90 = 0u64;
                                nat_eq(a89, a90)
                            };
                            bool_not(a91)
                        } else {
                            false
                        }
                    } {
                        Some(Adt15::C8)
                    } else {
                        None::<Adt15>
                    }), None::<Adt18>, {
                        let a96 = match v1 {
                            Adt20::C0(_, _, _, _, h92, _) => {
                                h92
                            }
                        };
                        let a97 = {
                            let m95 = match v2.clone() {
                                Adt18::C0(_, _, _, _, h94) => {
                                    h94
                                }
                            };
                            match m95 {
                                Adt14::C0(_, _, h93) => {
                                    h93
                                }
                            }
                        };
                        if nat_eq(a96, a97) {
                            Some({
                                let m100 = match v2 {
                                    Adt18::C0(_, _, _, _, h99) => {
                                        h99
                                    }
                                };
                                match m100 {
                                    Adt14::C0(h98, _, _) => {
                                        h98
                                    }
                                }
                            })
                        } else {
                            None::<Adt3>
                        }
                    }))
                } else {
                    Ok(Adt23::C0(Adt16::C0(match v0.clone() {
                        Adt16::C0(h101, _, _, _, _, _, _, _, _, _, _) => {
                            h101
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, h102, _, _, _, _, _, _, _, _, _) => {
                            h102
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, h103, _, _, _, _, _, _, _, _) => {
                            h103
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, h104, _, _, _, _, _, _, _) => {
                            h104
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, _, h105, _, _, _, _, _, _) => {
                            h105
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, _, _, h106, _, _, _, _, _) => {
                            h106
                        }
                    }, match v0.clone() {
                        Adt16::C0(_, _, _, _, _, _, h107, _, _, _, _) => {
                            h107
                        }
                    }, Adt17::C4, match v0.clone() {
                        Adt16::C0(_, _, _, _, _, _, _, _, h108, _, _) => {
                            h108
                        }
                    }, match v0 {
                        Adt16::C0(_, _, _, _, _, _, _, _, _, h109, _) => {
                            h109
                        }
                    }, Some(Adt15::C9)), None::<Adt18>, None::<Adt3>))
                }
            } else {
                Ok(Adt23::C0(v0, None::<Adt18>, None::<Adt3>))
            }
        }
    }
}

pub fn f3(v0: Adt11) -> Adt25 {
    Adt25::C0(Adt11::C0(match v0.clone() {
        Adt11::C0(h110, _, _, _, _, _, _, _, _, _) => {
            h110
        }
    }, match v0.clone() {
        Adt11::C0(_, h111, _, _, _, _, _, _, _, _) => {
            h111
        }
    }, match v0.clone() {
        Adt11::C0(_, _, h112, _, _, _, _, _, _, _) => {
            h112
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, h113, _, _, _, _, _, _) => {
            h113
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, _, h114, _, _, _, _, _) => {
            h114
        }
    }, {
        let m116 = match v0.clone() {
            Adt11::C0(_, _, _, _, _, _, h115, _, _, _) => {
                h115
            }
        };
        if match m116 {
            None => {
                false
            }
            Some(_) => {
                true
            }
        } {
            Adt12::C2
        } else {
            Adt12::C5
        }
    }, match v0.clone() {
        Adt11::C0(_, _, _, _, _, _, h117, _, _, _) => {
            h117
        }
    }, None::<Adt14>, match v0.clone() {
        Adt11::C0(_, _, _, _, _, _, _, _, h118, _) => {
            h118
        }
    }, Some(Adt15::C11)), None::<Adt13>, {
        let m120 = match v0 {
            Adt11::C0(_, _, _, _, _, _, _, h119, _, _) => {
                h119
            }
        };
        match m120 {
            None => {
                None::<Adt3>
            }
            Some(v2) => {
                f6(v2)
            }
        }
    })
}

pub fn f4(v0: Adt16, v1: Adt20) -> bool {
    let m122 = match v0 {
        Adt16::C0(_, _, _, _, _, _, _, _, h121, _, _) => {
            h121
        }
    };
    match m122 {
        None => {
            false
        }
        Some(v2) => {
            if f7(match v2.clone() {
                Adt18::C0(h123, _, _, _, _) => {
                    h123
                }
            }, match v1.clone() {
                Adt20::C0(h124, _, _, _, _, _) => {
                    h124
                }
            }) {
                if f8(match v2.clone() {
                    Adt18::C0(_, h125, _, _, _) => {
                        h125
                    }
                }, match v1.clone() {
                    Adt20::C0(_, h126, _, _, _, _) => {
                        h126
                    }
                }) {
                    let a129 = match v2.clone() {
                        Adt18::C0(_, _, h127, _, _) => {
                            h127
                        }
                    };
                    let a130 = match v1.clone() {
                        Adt20::C0(_, _, h128, _, _, _) => {
                            h128
                        }
                    };
                    if nat_eq(a129, a130) {
                        let a133 = match v2 {
                            Adt18::C0(_, _, _, h131, _) => {
                                h131
                            }
                        };
                        let a134 = match v1 {
                            Adt20::C0(_, _, _, h132, _, _) => {
                                h132
                            }
                        };
                        nat_eq(a133, a134)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        }
    }
}

pub fn f5(v0: Adt5, v1: Adt6, v2: Adt24) -> R<Adt6> {
    let m135 = v2;
    match m135 {
        Adt24::C0(v3, v4) => {
            let m137 = f9(v0, match v1.clone() {
                Adt6::C0(h136, _) => {
                    h136
                }
            }, v3, v4)?;
            match m137 {
                Ok(v6) => {
                    Ok(Adt6::C0(v6, None::<Adt9>))
                }
                Err(v5) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h138, _) => {
                            h138
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt24::C1(v7, v8, v9) => {
            let m140 = f10(match v1.clone() {
                Adt6::C0(h139, _) => {
                    h139
                }
            }, v7, v8, v9)?;
            match m140 {
                Ok(v11) => {
                    Ok(Adt6::C0(v11, None::<Adt9>))
                }
                Err(v10) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h141, _) => {
                            h141
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt24::C2(v12, v13, v14) => {
            let m143 = f10(match v1.clone() {
                Adt6::C0(h142, _) => {
                    h142
                }
            }, v12, v13, v14)?;
            match m143 {
                Ok(v16) => {
                    Ok(Adt6::C0(v16, None::<Adt9>))
                }
                Err(v15) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h144, _) => {
                            h144
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt24::C3(v17, v18) => {
            let m146 = f11(match v1.clone() {
                Adt6::C0(h145, _) => {
                    h145
                }
            }, v17, v18)?;
            match m146 {
                Ok(v20) => {
                    Ok(Adt6::C0(v20, None::<Adt9>))
                }
                Err(v19) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h147, _) => {
                            h147
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt24::C4(v21, v22) => {
            let m149 = f11(match v1.clone() {
                Adt6::C0(h148, _) => {
                    h148
                }
            }, v21, v22)?;
            match m149 {
                Ok(v24) => {
                    Ok(Adt6::C0(v24, None::<Adt9>))
                }
                Err(v23) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h150, _) => {
                            h150
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f6(v0: Adt14) -> Option<Adt3> {
    let a152 = match v0.clone() {
        Adt14::C0(_, _, h151) => {
            h151
        }
    };
    let a153 = 0u64;
    if nat_eq(a152, a153) {
        None::<Adt3>
    } else {
        Some(match v0 {
            Adt14::C0(h154, _, _) => {
                h154
            }
        })
    }
}

pub fn f7(v0: Adt1, v1: Adt1) -> bool {
    let a157 = match v0.clone() {
        Adt1::C0(h155, _, _) => {
            h155
        }
    };
    let a158 = match v1.clone() {
        Adt1::C0(h156, _, _) => {
            h156
        }
    };
    if nat_eq(a157, a158) {
        let a161 = match v0.clone() {
            Adt1::C0(_, h159, _) => {
                h159
            }
        };
        let a162 = match v1.clone() {
            Adt1::C0(_, h160, _) => {
                h160
            }
        };
        if nat_eq(a161, a162) {
            let a165 = match v0 {
                Adt1::C0(_, _, h163) => {
                    h163
                }
            };
            let a166 = match v1 {
                Adt1::C0(_, _, h164) => {
                    h164
                }
            };
            nat_eq(a165, a166)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f8(v0: Adt3, v1: Adt3) -> bool {
    let a169 = match v0.clone() {
        Adt3::C0(h167, _, _) => {
            h167
        }
    };
    let a170 = match v1.clone() {
        Adt3::C0(h168, _, _) => {
            h168
        }
    };
    if nat_eq(a169, a170) {
        let a173 = match v0.clone() {
            Adt3::C0(_, h171, _) => {
                h171
            }
        };
        let a174 = match v1.clone() {
            Adt3::C0(_, h172, _) => {
                h172
            }
        };
        if nat_eq(a173, a174) {
            let a177 = match v0 {
                Adt3::C0(_, _, h175) => {
                    h175
                }
            };
            let a178 = match v1 {
                Adt3::C0(_, _, h176) => {
                    h176
                }
            };
            nat_eq(a177, a178)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f9(v0: Adt5, v1: Adt7, v2: Adt10, v3: u64) -> R<Result<Adt7, Adt9>> {
    if f12(match v0.clone() {
        Adt5::C0(h179, _, _, _, _) => {
            h179
        }
    }, f13(v1.clone())?, v3)? {
        if f12(f14(v0.clone(), v2.clone()), {
            let a182 = f15(match v1.clone() {
                Adt7::C0(h180, _, _, _) => {
                    h180
                }
            }, v2.clone());
            let a183 = f15(match v1.clone() {
                Adt7::C0(_, h181, _, _) => {
                    h181
                }
            }, v2.clone());
            nat_add(a182, a183)?
        }, v3)? {
            Ok(Ok::<Adt7, Adt9>(Adt7::C0(match v1.clone() {
                Adt7::C0(h184, _, _, _) => {
                    h184
                }
            }, f16(match v1.clone() {
                Adt7::C0(_, h185, _, _) => {
                    h185
                }
            }, v2.clone(), {
                let a187 = f15(match v1.clone() {
                    Adt7::C0(_, h186, _, _) => {
                        h186
                    }
                }, v2.clone());
                let a188 = v3;
                nat_add(a187, a188)?
            }), f17(match v1.clone() {
                Adt7::C0(_, _, h189, _) => {
                    h189
                }
            }, f18(match v1.clone() {
                Adt7::C0(h190, _, _, _) => {
                    h190
                }
            })?), f17(match v1.clone() {
                Adt7::C0(_, _, _, h191) => {
                    h191
                }
            }, {
                let a197 = f18(match v1.clone() {
                    Adt7::C0(h192, _, _, _) => {
                        h192
                    }
                })?;
                let a198 = f18(f16(match v1.clone() {
                    Adt7::C0(_, h193, _, _) => {
                        h193
                    }
                }, v2.clone(), {
                    let a195 = f15(match v1 {
                        Adt7::C0(_, h194, _, _) => {
                            h194
                        }
                    }, v2);
                    let a196 = v3;
                    nat_add(a195, a196)?
                }))?;
                nat_add(a197, a198)?
            }))))
        } else {
            Ok(Err::<Adt7, Adt9>(Adt9::C1(v2.clone(), {
                let a201 = f15(match v1.clone() {
                    Adt7::C0(h199, _, _, _) => {
                        h199
                    }
                }, v2.clone());
                let a202 = f15(match v1 {
                    Adt7::C0(_, h200, _, _) => {
                        h200
                    }
                }, v2.clone());
                nat_add(a201, a202)?
            }, v3, {
                let m203 = f14(v0, v2);
                match m203 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C0(f13(v1)?, v3, {
            let m205 = match v0 {
                Adt5::C0(h204, _, _, _, _) => {
                    h204
                }
            };
            match m205 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f10(v0: Adt7, v1: Adt10, v2: u64, v3: u64) -> R<Result<Adt7, Adt9>> {
    let a209 = {
        let a207 = f15(match v0.clone() {
            Adt7::C0(_, h206, _, _) => {
                h206
            }
        }, v1.clone());
        let a208 = v2;
        nat_lt(a207, a208)
    };
    if if bool_not(a209) {
        let a212 = {
            let a210 = v2;
            let a211 = v3;
            nat_lt(a210, a211)
        };
        bool_not(a212)
    } else {
        false
    } {
        Ok(Ok::<Adt7, Adt9>(Adt7::C0(f16(match v0.clone() {
            Adt7::C0(h213, _, _, _) => {
                h213
            }
        }, v1.clone(), {
            let a215 = f15(match v0.clone() {
                Adt7::C0(h214, _, _, _) => {
                    h214
                }
            }, v1.clone());
            let a216 = v3;
            nat_add(a215, a216)?
        }), f16(match v0.clone() {
            Adt7::C0(_, h217, _, _) => {
                h217
            }
        }, v1.clone(), {
            let a219 = f15(match v0.clone() {
                Adt7::C0(_, h218, _, _) => {
                    h218
                }
            }, v1.clone());
            let a220 = v2;
            nat_sub(a219, a220)
        }), f17(match v0.clone() {
            Adt7::C0(_, _, h221, _) => {
                h221
            }
        }, f18(f16(match v0.clone() {
            Adt7::C0(h222, _, _, _) => {
                h222
            }
        }, v1.clone(), {
            let a224 = f15(match v0.clone() {
                Adt7::C0(h223, _, _, _) => {
                    h223
                }
            }, v1.clone());
            let a225 = v3;
            nat_add(a224, a225)?
        }))?), f17(match v0.clone() {
            Adt7::C0(_, _, _, h226) => {
                h226
            }
        }, {
            let a235 = f18(f16(match v0.clone() {
                Adt7::C0(h227, _, _, _) => {
                    h227
                }
            }, v1.clone(), {
                let a229 = f15(match v0.clone() {
                    Adt7::C0(h228, _, _, _) => {
                        h228
                    }
                }, v1.clone());
                let a230 = v3;
                nat_add(a229, a230)?
            }))?;
            let a236 = f18(f16(match v0.clone() {
                Adt7::C0(_, h231, _, _) => {
                    h231
                }
            }, v1.clone(), {
                let a233 = f15(match v0 {
                    Adt7::C0(_, h232, _, _) => {
                        h232
                    }
                }, v1);
                let a234 = v2;
                nat_sub(a233, a234)
            }))?;
            nat_add(a235, a236)?
        }))))
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C2(v1, v2, v3)))
    }
}

pub fn f11(v0: Adt7, v1: Adt10, v2: u64) -> R<Result<Adt7, Adt9>> {
    let a240 = {
        let a238 = f15(match v0.clone() {
            Adt7::C0(h237, _, _, _) => {
                h237
            }
        }, v1.clone());
        let a239 = v2;
        nat_lt(a238, a239)
    };
    if bool_not(a240) {
        Ok(Ok::<Adt7, Adt9>(Adt7::C0(f16(match v0.clone() {
            Adt7::C0(h241, _, _, _) => {
                h241
            }
        }, v1.clone(), {
            let a243 = f15(match v0.clone() {
                Adt7::C0(h242, _, _, _) => {
                    h242
                }
            }, v1.clone());
            let a244 = v2;
            nat_sub(a243, a244)
        }), match v0.clone() {
            Adt7::C0(_, h245, _, _) => {
                h245
            }
        }, f17(match v0.clone() {
            Adt7::C0(_, _, h246, _) => {
                h246
            }
        }, f18(f16(match v0.clone() {
            Adt7::C0(h247, _, _, _) => {
                h247
            }
        }, v1.clone(), {
            let a249 = f15(match v0.clone() {
                Adt7::C0(h248, _, _, _) => {
                    h248
                }
            }, v1.clone());
            let a250 = v2;
            nat_sub(a249, a250)
        }))?), f17(match v0.clone() {
            Adt7::C0(_, _, _, h251) => {
                h251
            }
        }, {
            let a257 = f18(f16(match v0.clone() {
                Adt7::C0(h252, _, _, _) => {
                    h252
                }
            }, v1.clone(), {
                let a254 = f15(match v0.clone() {
                    Adt7::C0(h253, _, _, _) => {
                        h253
                    }
                }, v1);
                let a255 = v2;
                nat_sub(a254, a255)
            }))?;
            let a258 = f18(match v0 {
                Adt7::C0(_, h256, _, _) => {
                    h256
                }
            })?;
            nat_add(a257, a258)?
        }))))
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C3(v1.clone(), f15(match v0 {
            Adt7::C0(h259, _, _, _) => {
                h259
            }
        }, v1), v2)))
    }
}

pub fn f12(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m260 = v0;
    match m260 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a265 = {
                let a263 = v3;
                let a264 = {
                    let a261 = v1;
                    let a262 = v2;
                    nat_add(a261, a262)?
                };
                nat_lt(a263, a264)
            };
            Ok(bool_not(a265))
        }
    }
}

pub fn f13(v0: Adt7) -> R<u64> {
    let a266 = f19(v0.clone())?;
    let a267 = f20(v0)?;
    nat_add(a266, a267)
}

pub fn f14(v0: Adt5, v1: Adt10) -> Option<u64> {
    let m268 = v1;
    match m268 {
        Adt10::C0 => {
            match v0 {
                Adt5::C0(_, h269, _, _, _) => {
                    h269
                }
            }
        }
        Adt10::C1 => {
            match v0 {
                Adt5::C0(_, _, h270, _, _) => {
                    h270
                }
            }
        }
        Adt10::C2 => {
            match v0 {
                Adt5::C0(_, _, _, h271, _) => {
                    h271
                }
            }
        }
        Adt10::C3 => {
            match v0 {
                Adt5::C0(_, _, _, _, h272) => {
                    h272
                }
            }
        }
    }
}

pub fn f15(v0: Adt8, v1: Adt10) -> u64 {
    let m273 = v1;
    match m273 {
        Adt10::C0 => {
            match v0 {
                Adt8::C0(h274, _, _, _) => {
                    h274
                }
            }
        }
        Adt10::C1 => {
            match v0 {
                Adt8::C0(_, h275, _, _) => {
                    h275
                }
            }
        }
        Adt10::C2 => {
            match v0 {
                Adt8::C0(_, _, h276, _) => {
                    h276
                }
            }
        }
        Adt10::C3 => {
            match v0 {
                Adt8::C0(_, _, _, h277) => {
                    h277
                }
            }
        }
    }
}

pub fn f16(v0: Adt8, v1: Adt10, v2: u64) -> Adt8 {
    let m278 = v1;
    match m278 {
        Adt10::C0 => {
            Adt8::C0(v2, match v0.clone() {
                Adt8::C0(_, h279, _, _) => {
                    h279
                }
            }, match v0.clone() {
                Adt8::C0(_, _, h280, _) => {
                    h280
                }
            }, match v0 {
                Adt8::C0(_, _, _, h281) => {
                    h281
                }
            })
        }
        Adt10::C1 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h282, _, _, _) => {
                    h282
                }
            }, v2, match v0.clone() {
                Adt8::C0(_, _, h283, _) => {
                    h283
                }
            }, match v0 {
                Adt8::C0(_, _, _, h284) => {
                    h284
                }
            })
        }
        Adt10::C2 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h285, _, _, _) => {
                    h285
                }
            }, match v0.clone() {
                Adt8::C0(_, h286, _, _) => {
                    h286
                }
            }, v2, match v0 {
                Adt8::C0(_, _, _, h287) => {
                    h287
                }
            })
        }
        Adt10::C3 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h288, _, _, _) => {
                    h288
                }
            }, match v0.clone() {
                Adt8::C0(_, h289, _, _) => {
                    h289
                }
            }, match v0 {
                Adt8::C0(_, _, h290, _) => {
                    h290
                }
            }, v2)
        }
    }
}

pub fn f17(v0: u64, v1: u64) -> u64 {
    let a291 = v0;
    let a292 = v1;
    if nat_lt(a291, a292) {
        v1
    } else {
        v0
    }
}

pub fn f18(v0: Adt8) -> R<u64> {
    let a303 = {
        let a300 = {
            let a297 = {
                let a294 = 0u64;
                let a295 = match v0.clone() {
                    Adt8::C0(h293, _, _, _) => {
                        h293
                    }
                };
                nat_add(a294, a295)?
            };
            let a298 = match v0.clone() {
                Adt8::C0(_, h296, _, _) => {
                    h296
                }
            };
            nat_add(a297, a298)?
        };
        let a301 = match v0.clone() {
            Adt8::C0(_, _, h299, _) => {
                h299
            }
        };
        nat_add(a300, a301)?
    };
    let a304 = match v0 {
        Adt8::C0(_, _, _, h302) => {
            h302
        }
    };
    nat_add(a303, a304)
}

pub fn f19(v0: Adt7) -> R<u64> {
    f18(match v0 {
        Adt7::C0(h305, _, _, _) => {
            h305
        }
    })
}

pub fn f20(v0: Adt7) -> R<u64> {
    f18(match v0 {
        Adt7::C0(_, h306, _, _) => {
            h306
        }
    })
}
