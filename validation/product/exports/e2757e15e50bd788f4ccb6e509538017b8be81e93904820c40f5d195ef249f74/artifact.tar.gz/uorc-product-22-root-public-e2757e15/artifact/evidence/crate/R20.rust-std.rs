#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt53, u64, Option<Adt55>, Adt56, List<Adt58>, Option<Adt60>),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, Adt2, Adt5, Adt8, Option<Adt9>, Option<Adt22>, Adt40, Option<Adt11>, bool, bool, Option<Adt41>, Option<Adt47>, Option<Adt11>, bool, bool, Adt48, Adt49, bool, Adt50, Option<Adt23>, List<Adt51>),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u64, u64, bool, bool, Adt3, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Adt6, bool, u64, bool, Adt7),
}

#[derive(Clone)]
pub enum Adt6 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt7 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, bool, bool, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(Adt10),
    C1(Adt15),
    C2(Adt15),
    C3(Adt16),
    C4(Adt17),
    C5(Adt18),
    C6(Adt19),
    C7(Adt20),
    C8(Adt21),
    C9(Adt21),
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt11 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt12 {
    C0(Adt13, Option<Adt11>),
}

#[derive(Clone)]
pub enum Adt13 {
    C0(u64, u64, u64, u64, Option<u64>, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt15 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt11, Option<Adt11>, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt17 {
    C0(Adt11, Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt19 {
    C0(Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt11, Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt23, Adt28, bool, bool, Adt29, Adt30, Adt32, bool, Option<Adt11>, Option<Adt33>),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, Adt24, Option<Adt26>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(Adt25, Adt25, u64, u64),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt26 {
    C0(Option<u64>, Option<u64>, Adt27, u64),
}

#[derive(Clone)]
pub enum Adt27 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt28 {
    C0(bool, bool, bool, bool, bool),
}

#[derive(Clone)]
pub enum Adt29 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt30 {
    C0,
    C1(Adt31),
    C2(Adt31),
    C3(Adt31),
    C4(Adt31),
}

#[derive(Clone)]
pub enum Adt31 {
    C0(Bytes, Adt11, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt32 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt33 {
    C0(Adt34),
    C1(Adt34),
    C2(Adt34),
    C3(u64),
    C4(Adt35),
    C5(Adt36),
    C6(Adt37),
    C7(Adt39),
}

#[derive(Clone)]
pub enum Adt34 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt35 {
    C0(Bytes, u64, u64),
}

#[derive(Clone)]
pub enum Adt36 {
    C0(Adt11, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt37 {
    C0(Adt38, Adt38, bool),
}

#[derive(Clone)]
pub enum Adt38 {
    C0(Adt23, Adt28, bool, Adt30),
}

#[derive(Clone)]
pub enum Adt39 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt40 {
    C0(u64, u64, u64, u64, u64, Str),
}

#[derive(Clone)]
pub enum Adt41 {
    C0(u64, Str),
    C1(u64, Str),
    C2(Bytes),
    C3(Bytes),
    C4,
    C5,
    C6(Adt42, u64),
    C7,
    C8(Str),
    C9(Adt7, Str),
    C10(Adt43),
    C11(Adt44),
    C12,
    C13,
    C14(Str),
    C15(Str),
    C16(Adt45),
}

#[derive(Clone)]
pub enum Adt42 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt43 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
    C12,
    C13,
    C14,
    C15,
    C16,
    C17,
}

#[derive(Clone)]
pub enum Adt44 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt45 {
    C0(u64, u64, u64),
    C1(Adt46, u64, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64, u64),
}

#[derive(Clone)]
pub enum Adt46 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt47 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt48 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt49 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt50 {
    C0(Adt24, Option<Adt45>),
}

#[derive(Clone)]
pub enum Adt51 {
    C0(Adt52, Adt14, Adt50, Option<Adt23>),
}

#[derive(Clone)]
pub enum Adt52 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt53 {
    C0(Adt54, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt54 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
}

#[derive(Clone)]
pub enum Adt55 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt56 {
    C0(u64, Adt57),
}

#[derive(Clone)]
pub enum Adt57 {
    C0(Adt55),
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt58 {
    C0(Adt55, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt59 {
    C0(u64, Str, Option<u64>),
}

#[derive(Clone)]
pub enum Adt60 {
    C0(Adt55, Adt52, u64, Adt11, List<Adt59>, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt61 {
    C0(Adt52, u64, Adt62),
}

#[derive(Clone)]
pub enum Adt62 {
    C0(Adt54),
    C1(Adt55),
    C2(Adt55),
    C3(Adt13),
    C4,
    C5(Adt63),
    C6(u64),
    C7(Adt55, u64),
    C8(Adt55, u64, u64),
}

#[derive(Clone)]
pub enum Adt63 {
    C0,
    C1(Adt48),
    C2,
    C3,
    C4,
    C5,
    C6,
    C7(u64),
    C8,
}

#[derive(Clone)]
pub enum Adt64 {
    C0(Adt65, Adt70, Str),
}

#[derive(Clone)]
pub enum Adt65 {
    C0(Adt0, List<Adt66>),
}

#[derive(Clone)]
pub enum Adt66 {
    C0(Adt67),
    C1(Adt55, Adt52, u64),
    C2(Adt60),
    C3(Adt60),
}

#[derive(Clone)]
pub enum Adt67 {
    C0(Adt52, Adt9),
    C1(Adt52, Adt68),
    C2(Adt52, u64),
    C3(Adt52, u64),
    C4(Adt52),
    C5(Adt52),
    C6(Adt11),
    C7(Adt52, Adt11),
    C8(u64),
    C9(Adt52),
}

#[derive(Clone)]
pub enum Adt68 {
    C0(u64),
    C1(Adt69),
    C2(u64),
    C3,
}

#[derive(Clone)]
pub enum Adt69 {
    C0(Adt11, u64, u64),
}

#[derive(Clone)]
pub enum Adt70 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt71 {
    C0(Adt54),
    C1(Adt55),
    C2(Adt55, Adt52, u64, Adt11, List<Adt59>),
    C3(Adt55),
    C4(Adt13),
    C5,
    C6(Adt63),
    C7(u64),
    C8(Adt55, u64),
    C9(Adt55, u64, u64),
    C10(Adt52, u64, Adt11, List<Adt59>),
    C11(Adt52, u64, Str),
}

#[derive(Clone)]
pub enum Adt72 {
    C0(Adt9),
    C1,
    C2,
    C3(Adt48),
    C4,
    C5,
    C6,
    C7,
    C8(u64),
    C9(Adt52),
    C10(Adt52, Adt68),
    C11(u64),
    C12(Adt52, Adt40),
    C13(Adt52, Adt11),
    C14(u64),
    C15(Adt52, Adt22),
    C16(Adt52, Adt73),
    C17(Adt52, Adt47),
    C18,
    C19(Adt52, Adt7),
    C20,
    C21(Adt52, u64),
    C22(Adt52, Adt74),
    C23(Adt52, Adt74),
    C24(Adt52),
}

#[derive(Clone)]
pub enum Adt73 {
    C0(Adt41, Adt23, Adt7),
}

#[derive(Clone)]
pub enum Adt74 {
    C0(Adt46, u64),
    C1(Adt46, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64),
    C4(Adt46, u64),
}

#[derive(Clone)]
pub enum Adt75 {
    C0(Adt1, List<Adt67>),
}

#[derive(Clone)]
pub enum Adt76 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt77 {
    C0(Adt78, Adt5),
    C1(Adt44),
}

#[derive(Clone)]
pub enum Adt78 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt79 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt80 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt81 {
    C0,
    C1,
    C2,
    C3,
}

pub fn f0(v0: Adt0, v1: Adt61) -> R<Adt64> {
    if if f1(match v0.clone() {
        Adt0::C0(h1, _, _, _, _, _, _) => {
            h1
        }
    }, match v1.clone() {
        Adt61::C0(h2, _, _) => {
            h2
        }
    }) {
        let a5 = match v0.clone() {
            Adt0::C0(_, _, h3, _, _, _, _) => {
                h3
            }
        };
        let a6 = match v1.clone() {
            Adt61::C0(_, h4, _) => {
                h4
            }
        };
        nat_eq(a5, a6)
    } else {
        false
    } {
        Ok(Adt64::C0(f2(v0, f3(match v1 {
            Adt61::C0(_, _, h7) => {
                h7
            }
        }))?, Adt70::C0, Str::lit("")))
    } else {
        Ok(Adt64::C0(Adt65::C0(v0, List::<Adt66>::nil()), Adt70::C1, Str::lit("The selection or operation changed; this action was not applied.")))
    }
}

pub fn f1(v0: Adt1, v1: Adt52) -> bool {
    let a10 = match v0.clone() {
        Adt1::C0(h8, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h8
        }
    };
    let a11 = match v1.clone() {
        Adt52::C0(h9, _, _) => {
            h9
        }
    };
    if nat_eq(a10, a11) {
        let a16 = {
            let m14 = match v0.clone() {
                Adt1::C0(_, h13, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h13
                }
            };
            match m14 {
                Adt2::C0(_, h12, _, _, _, _) => {
                    h12
                }
            }
        };
        let a17 = match v1.clone() {
            Adt52::C0(_, h15, _) => {
                h15
            }
        };
        if nat_eq(a16, a17) {
            let a22 = {
                let m20 = match v0.clone() {
                    Adt1::C0(_, h19, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h19
                    }
                };
                match m20 {
                    Adt2::C0(h18, _, _, _, _, _) => {
                        h18
                    }
                }
            };
            let a23 = match v1 {
                Adt52::C0(_, _, h21) => {
                    h21
                }
            };
            if nat_eq(a22, a23) {
                if match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h24, _, _, _, _, _, _, _) => {
                        h24
                    }
                } {
                    let a26 = match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h25, _, _, _, _, _, _) => {
                            h25
                        }
                    };
                    bool_not(a26)
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f2(v0: Adt0, v1: Adt71) -> R<Adt65> {
    if f4(v1.clone()) {
        Ok(Adt65::C0({
            let m30 = f5({
                let m29 = f6(v0.clone())?;
                match m29 {
                    Adt65::C0(h28, _) => {
                        h28
                    }
                }
            }, v1.clone())?;
            match m30 {
                Adt65::C0(h27, _) => {
                    h27
                }
            }
        }, f7({
            let m32 = f6(v0.clone())?;
            match m32 {
                Adt65::C0(_, h31) => {
                    h31
                }
            }
        }, {
            let m36 = f5({
                let m35 = f6(v0)?;
                match m35 {
                    Adt65::C0(h34, _) => {
                        h34
                    }
                }
            }, v1)?;
            match m36 {
                Adt65::C0(_, h33) => {
                    h33
                }
            }
        })))
    } else {
        f5(v0, v1)
    }
}

pub fn f3(v0: Adt62) -> Adt71 {
    let m37 = v0;
    match m37 {
        Adt62::C0(v1) => {
            Adt71::C0(v1)
        }
        Adt62::C1(v2) => {
            Adt71::C1(v2)
        }
        Adt62::C2(v3) => {
            Adt71::C3(v3)
        }
        Adt62::C3(v4) => {
            Adt71::C4(v4)
        }
        Adt62::C4 => {
            Adt71::C5
        }
        Adt62::C5(v5) => {
            Adt71::C6(v5)
        }
        Adt62::C6(v6) => {
            Adt71::C7(v6)
        }
        Adt62::C7(v7, v8) => {
            Adt71::C8(v7, v8)
        }
        Adt62::C8(v9, v10, v11) => {
            Adt71::C9(v9, v10, v11)
        }
    }
}

pub fn f4(v0: Adt71) -> bool {
    let m38 = v0;
    match m38 {
        Adt71::C0(_) => {
            true
        }
        Adt71::C1(_) => {
            true
        }
        Adt71::C2(_, _, _, _, _) => {
            false
        }
        Adt71::C3(_) => {
            true
        }
        Adt71::C4(_) => {
            true
        }
        Adt71::C5 => {
            false
        }
        Adt71::C6(v10) => {
            let m39 = v10;
            match m39 {
                Adt63::C0 => {
                    true
                }
                Adt63::C1(_) => {
                    false
                }
                Adt63::C2 => {
                    false
                }
                Adt63::C3 => {
                    false
                }
                Adt63::C4 => {
                    false
                }
                Adt63::C5 => {
                    false
                }
                Adt63::C6 => {
                    false
                }
                Adt63::C7(_) => {
                    false
                }
                Adt63::C8 => {
                    false
                }
            }
        }
        Adt71::C7(_) => {
            false
        }
        Adt71::C8(_, _) => {
            false
        }
        Adt71::C9(_, _, _) => {
            false
        }
        Adt71::C10(_, _, _, _) => {
            false
        }
        Adt71::C11(_, _, _) => {
            false
        }
    }
}

pub fn f5(v0: Adt0, v1: Adt71) -> R<Adt65> {
    f8(v0.clone(), v1.clone(), {
        let m40 = v1;
        match m40 {
            Adt71::C0(v2) => {
                f9(v0.clone(), match v0 {
                    Adt0::C0(_, h41, _, _, _, _, _) => {
                        h41
                    }
                }, v2)?
            }
            Adt71::C1(v3) => {
                f10(v0, v3)?
            }
            Adt71::C2(v4, v5, v6, v7, v8) => {
                if if f11(v0.clone(), v4.clone(), v5, v6, v7.clone()) {
                    f12(v8.clone())
                } else {
                    false
                } {
                    f13(v0, v4, v7, v8)?
                } else {
                    Adt65::C0(v0, List::cons(Adt66::C0(Adt67::C6(v7)), List::<Adt66>::nil()))
                }
            }
            Adt71::C3(v9) => {
                Adt65::C0(Adt0::C0({
                    let m45 = {
                        let m44 = f14(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m44 {
                            Adt65::C0(h43, _) => {
                                h43
                            }
                        }
                    };
                    match m45 {
                        Adt0::C0(h42, _, _, _, _, _, _) => {
                            h42
                        }
                    }
                }, {
                    let m49 = {
                        let m48 = f14(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m48 {
                            Adt65::C0(h47, _) => {
                                h47
                            }
                        }
                    };
                    match m49 {
                        Adt0::C0(_, h46, _, _, _, _, _) => {
                            h46
                        }
                    }
                }, {
                    let m53 = {
                        let m52 = f14(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m52 {
                            Adt65::C0(h51, _) => {
                                h51
                            }
                        }
                    };
                    match m53 {
                        Adt0::C0(_, _, h50, _, _, _, _) => {
                            h50
                        }
                    }
                }, {
                    let m57 = {
                        let m56 = f14(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m56 {
                            Adt65::C0(h55, _) => {
                                h55
                            }
                        }
                    };
                    match m57 {
                        Adt0::C0(_, _, _, h54, _, _, _) => {
                            h54
                        }
                    }
                }, {
                    let m61 = {
                        let m60 = f14(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m60 {
                            Adt65::C0(h59, _) => {
                                h59
                            }
                        }
                    };
                    match m61 {
                        Adt0::C0(_, _, _, _, h58, _, _) => {
                            h58
                        }
                    }
                }, f15(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h62, _) => {
                        h62
                    }
                }, v9.clone(), List::<Adt59>::nil()), {
                    let m66 = {
                        let m65 = f14(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m65 {
                            Adt65::C0(h64, _) => {
                                h64
                            }
                        }
                    };
                    match m66 {
                        Adt0::C0(_, _, _, _, _, _, h63) => {
                            h63
                        }
                    }
                }), {
                    let m68 = f14(v0, v9, None::<Adt11>)?;
                    match m68 {
                        Adt65::C0(_, h67) => {
                            h67
                        }
                    }
                })
            }
            Adt71::C4(v10) => {
                f16(v0.clone(), match v0 {
                    Adt0::C0(_, h69, _, _, _, _, _) => {
                        h69
                    }
                }, v10)?
            }
            Adt71::C5 => {
                let m71 = f17(match v0.clone() {
                    Adt0::C0(_, h70, _, _, _, _, _) => {
                        h70
                    }
                });
                match m71 {
                    Ok(v12) => {
                        f18(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h74, _, _, _, _, _) => {
                                h74
                            }
                        }, f20(match v0 {
                            Adt0::C0(h75, _, _, _, _, _, _) => {
                                h75
                            }
                        }, v12)?)
                    }
                    Err(v11) => {
                        f18(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h72, _, _, _, _, _) => {
                                h72
                            }
                        }, f19(match v0 {
                            Adt0::C0(h73, _, _, _, _, _, _) => {
                                h73
                            }
                        }, Adt41::C10(v11)))
                    }
                }
            }
            Adt71::C6(v13) => {
                f21(v0, v13)?
            }
            Adt71::C7(v14) => {
                f22(v0, v14)?
            }
            Adt71::C8(v15, v16) => {
                f23(v0.clone(), v15.clone(), f24(f25(match v0 {
                    Adt0::C0(_, _, _, _, _, h76, _) => {
                        h76
                    }
                }, v15), v16))?
            }
            Adt71::C9(v17, v18, v19) => {
                f23(v0.clone(), v17.clone(), f26(f25(match v0 {
                    Adt0::C0(_, _, _, _, _, h77, _) => {
                        h77
                    }
                }, v17), v18, v19))?
            }
            Adt71::C10(v20, v21, v22, v23) => {
                f27(v0, v20, v21, v22, v23)?
            }
            Adt71::C11(v24, v25, v26) => {
                f28(v0, v24, v25, v26)?
            }
        }
    })
}

pub fn f6(v0: Adt0) -> R<Adt65> {
    let m79 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h78) => {
            h78
        }
    };
    match m79 {
        None => {
            Ok(Adt65::C0(v0, List::<Adt66>::nil()))
        }
        Some(v1) => {
            Ok(Adt65::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h80, _, _, _, _, _, _) => {
                    h80
                }
            }, f29(match v0.clone() {
                Adt0::C0(_, h81, _, _, _, _, _) => {
                    h81
                }
            }, match v1.clone() {
                Adt60::C0(h82, _, _, _, _, _) => {
                    h82
                }
            }, Some(match v1.clone() {
                Adt60::C0(_, _, _, h83, _, _) => {
                    h83
                }
            })), {
                let a85 = match v0.clone() {
                    Adt0::C0(_, _, h84, _, _, _, _) => {
                        h84
                    }
                };
                let a86 = 1u64;
                nat_add(a85, a86)?
            }, match v0.clone() {
                Adt0::C0(_, _, _, h87, _, _, _) => {
                    h87
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h88, _, _) => {
                    h88
                }
            }, f15(match v0 {
                Adt0::C0(_, _, _, _, _, h89, _) => {
                    h89
                }
            }, match v1.clone() {
                Adt60::C0(h90, _, _, _, _, _) => {
                    h90
                }
            }, match v1.clone() {
                Adt60::C0(_, _, _, _, _, h91) => {
                    h91
                }
            }), None::<Adt60>), List::cons(Adt66::C3(v1), List::<Adt66>::nil())))
        }
    }
}

pub fn f7(v0: List<Adt66>, v1: List<Adt66>) -> List<Adt66> {
    let m92 = v0;
    match m92.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f7(v3, v1))
        }
    }
}

pub fn f8(v0: Adt0, v1: Adt71, v2: Adt65) -> R<Adt65> {
    let m98 = {
        let m97 = {
            let m96 = match v2.clone() {
                Adt65::C0(h95, _) => {
                    h95
                }
            };
            match m96 {
                Adt0::C0(h94, _, _, _, _, _, _) => {
                    h94
                }
            }
        };
        match m97 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h93, _, _, _, _, _, _, _, _, _, _) => {
                h93
            }
        }
    };
    if match m98 {
        None => {
            let m104 = {
                let m103 = {
                    let m102 = match v2.clone() {
                        Adt65::C0(h101, _) => {
                            h101
                        }
                    };
                    match m102 {
                        Adt0::C0(h100, _, _, _, _, _, _) => {
                            h100
                        }
                    }
                };
                match m103 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h99, _, _, _, _, _, _, _, _, _) => {
                        h99
                    }
                }
            };
            match m104 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Some(_) => {
            true
        }
    } {
        f30(v0, v2, Adt57::C4)
    } else {
        let m105 = v1;
        match m105 {
            Adt71::C0(_) => {
                f30(v0, v2, Adt57::C1)
            }
            Adt71::C1(_) => {
                Ok(v2)
            }
            Adt71::C2(v7, _, _, _, _) => {
                f30(v0, v2, Adt57::C0(v7))
            }
            Adt71::C3(v12) => {
                f30(v0, v2, Adt57::C0(v12))
            }
            Adt71::C4(_) => {
                Ok(v2)
            }
            Adt71::C5 => {
                f30(v0, v2, Adt57::C2)
            }
            Adt71::C6(v14) => {
                let m106 = v14;
                match m106 {
                    Adt63::C0 => {
                        f30(v0, v2, Adt57::C2)
                    }
                    Adt63::C1(_) => {
                        f30(v0, v2, Adt57::C5)
                    }
                    Adt63::C2 => {
                        f30(v0, v2, Adt57::C5)
                    }
                    Adt63::C3 => {
                        Ok(v2)
                    }
                    Adt63::C4 => {
                        Ok(v2)
                    }
                    Adt63::C5 => {
                        Ok(v2)
                    }
                    Adt63::C6 => {
                        f30(v0, v2, Adt57::C2)
                    }
                    Adt63::C7(_) => {
                        f30(v0, v2, Adt57::C2)
                    }
                    Adt63::C8 => {
                        f30(v0, v2, Adt57::C2)
                    }
                }
            }
            Adt71::C7(_) => {
                f30(v0, v2, Adt57::C2)
            }
            Adt71::C8(v18, _) => {
                f30(v0, v2, Adt57::C0(v18))
            }
            Adt71::C9(v20, _, _) => {
                f30(v0, v2, Adt57::C0(v20))
            }
            Adt71::C10(_, _, _, _) => {
                Ok(v2)
            }
            Adt71::C11(_, _, _) => {
                Ok(v2)
            }
        }
    }
}

pub fn f9(v0: Adt0, v1: Adt53, v2: Adt54) -> R<Adt65> {
    f31(v0, Adt53::C0(v2, match v1.clone() {
        Adt53::C0(_, h107, _, _, _, _, _, _) => {
            h107
        }
    }, match v1.clone() {
        Adt53::C0(_, _, h108, _, _, _, _, _) => {
            h108
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, h109, _, _, _, _) => {
            h109
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, h110, _, _, _) => {
            h110
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, h111, _, _) => {
            h111
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, _, h112, _) => {
            h112
        }
    }, match v1 {
        Adt53::C0(_, _, _, _, _, _, _, h113) => {
            h113
        }
    }))
}

pub fn f10(v0: Adt0, v1: Adt55) -> R<Adt65> {
    let m116 = match v0.clone() {
        Adt0::C0(h115, _, _, _, _, _, _) => {
            h115
        }
    };
    if if match m116 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h114, _, _, _, _, _, _, _) => {
            h114
        }
    } {
        let a120 = {
            let m119 = match v0.clone() {
                Adt0::C0(h118, _, _, _, _, _, _) => {
                    h118
                }
            };
            match m119 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h117, _, _, _, _, _, _) => {
                    h117
                }
            }
        };
        bool_not(a120)
    } else {
        false
    } {
        Ok(Adt65::C0(Adt0::C0(match v0.clone() {
            Adt0::C0(h121, _, _, _, _, _, _) => {
                h121
            }
        }, match v0.clone() {
            Adt0::C0(_, h122, _, _, _, _, _) => {
                h122
            }
        }, {
            let a124 = match v0.clone() {
                Adt0::C0(_, _, h123, _, _, _, _) => {
                    h123
                }
            };
            let a125 = 1u64;
            nat_add(a124, a125)?
        }, Some(v1.clone()), match v0.clone() {
            Adt0::C0(_, _, _, _, h126, _, _) => {
                h126
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, h127, _) => {
                h127
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, h128) => {
                h128
            }
        }), List::cons(Adt66::C1(v1, f32(match v0.clone() {
            Adt0::C0(h129, _, _, _, _, _, _) => {
                h129
            }
        }), {
            let a131 = match v0 {
                Adt0::C0(_, _, h130, _, _, _, _) => {
                    h130
                }
            };
            let a132 = 1u64;
            nat_add(a131, a132)?
        }), List::<Adt66>::nil())))
    } else {
        Ok(Adt65::C0(v0, List::<Adt66>::nil()))
    }
}

pub fn f11(v0: Adt0, v1: Adt55, v2: Adt52, v3: u64, v4: Adt11) -> bool {
    if f1(match v0.clone() {
        Adt0::C0(h133, _, _, _, _, _, _) => {
            h133
        }
    }, v2) {
        let a135 = match v0.clone() {
            Adt0::C0(_, _, h134, _, _, _, _) => {
                h134
            }
        };
        let a136 = v3;
        if nat_eq(a135, a136) {
            let a141 = match v4 {
                Adt11::C0(h137, _, _) => {
                    h137
                }
            };
            let a142 = {
                let m140 = match v0.clone() {
                    Adt0::C0(h139, _, _, _, _, _, _) => {
                        h139
                    }
                };
                match m140 {
                    Adt1::C0(h138, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h138
                    }
                }
            };
            if nat_eq(a141, a142) {
                let m144 = match v0 {
                    Adt0::C0(_, _, _, h143, _, _, _) => {
                        h143
                    }
                };
                match m144 {
                    None => {
                        false
                    }
                    Some(v5) => {
                        f33(v5, v1)
                    }
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f12(p148: List<Adt59>) -> bool {
    let m147 = p148;
    {
        let mut m147 = m147;
        loop {
            let step = {
                let v0 = m147;
                let m145 = v0;
                match m145.uncons() {
                    None => {
                        Err::<List<Adt59>, bool>(true)
                    }
                    Some((v1, v2)) => {
                        if f34(v2.clone(), match v1 {
                            Adt59::C0(h146, _, _) => {
                                h146
                            }
                        }) {
                            Err::<List<Adt59>, bool>(false)
                        } else {
                            Ok::<List<Adt59>, bool>(v2)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m147 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f13(v0: Adt0, v1: Adt55, v2: Adt11, v3: List<Adt59>) -> R<Adt65> {
    Ok(Adt65::C0(Adt0::C0({
        let m152 = {
            let m151 = f14(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m151 {
                Adt65::C0(h150, _) => {
                    h150
                }
            }
        };
        match m152 {
            Adt0::C0(h149, _, _, _, _, _, _) => {
                h149
            }
        }
    }, {
        let m156 = {
            let m155 = f14(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m155 {
                Adt65::C0(h154, _) => {
                    h154
                }
            }
        };
        match m156 {
            Adt0::C0(_, h153, _, _, _, _, _) => {
                h153
            }
        }
    }, {
        let m160 = {
            let m159 = f14(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m159 {
                Adt65::C0(h158, _) => {
                    h158
                }
            }
        };
        match m160 {
            Adt0::C0(_, _, h157, _, _, _, _) => {
                h157
            }
        }
    }, {
        let m164 = {
            let m163 = f14(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m163 {
                Adt65::C0(h162, _) => {
                    h162
                }
            }
        };
        match m164 {
            Adt0::C0(_, _, _, h161, _, _, _) => {
                h161
            }
        }
    }, {
        let m168 = {
            let m167 = f14(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m167 {
                Adt65::C0(h166, _) => {
                    h166
                }
            }
        };
        match m168 {
            Adt0::C0(_, _, _, _, h165, _, _) => {
                h165
            }
        }
    }, f15(match v0.clone() {
        Adt0::C0(_, _, _, _, _, h169, _) => {
            h169
        }
    }, v1.clone(), v3), {
        let m173 = {
            let m172 = f14(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m172 {
                Adt65::C0(h171, _) => {
                    h171
                }
            }
        };
        match m173 {
            Adt0::C0(_, _, _, _, _, _, h170) => {
                h170
            }
        }
    }), {
        let m175 = f14(v0, v1, Some(v2))?;
        match m175 {
            Adt65::C0(_, h174) => {
                h174
            }
        }
    }))
}

pub fn f14(v0: Adt0, v1: Adt55, v2: Option<Adt11>) -> R<Adt65> {
    Ok(Adt65::C0({
        let m178 = f31(v0.clone(), f29(match v0.clone() {
            Adt0::C0(_, h177, _, _, _, _, _) => {
                h177
            }
        }, v1.clone(), v2.clone()))?;
        match m178 {
            Adt65::C0(h176, _) => {
                h176
            }
        }
    }, f35(f36(f37(f38(match v0.clone() {
        Adt0::C0(_, h179, _, _, _, _, _) => {
            h179
        }
    }, v1), v2), {
        let m182 = f39(match v0 {
            Adt0::C0(h181, _, _, _, _, _, _) => {
                h181
            }
        }, Adt72::C1)?;
        match m182 {
            Adt75::C0(_, h180) => {
                h180
            }
        }
    }))))
}

pub fn f15(v0: List<Adt58>, v1: Adt55, v2: List<Adt59>) -> List<Adt58> {
    let m183 = v0;
    match m183.uncons() {
        None => {
            List::cons(Adt58::C0(v1, v2), List::<Adt58>::nil())
        }
        Some((v3, v4)) => {
            if f33(match v3.clone() {
                Adt58::C0(h184, _) => {
                    h184
                }
            }, v1.clone()) {
                List::cons(Adt58::C0(v1, v2), v4)
            } else {
                List::cons(v3, f15(v4, v1, v2))
            }
        }
    }
}

pub fn f16(v0: Adt0, v1: Adt53, v2: Adt13) -> R<Adt65> {
    f31(v0, Adt53::C0(match v1.clone() {
        Adt53::C0(h185, _, _, _, _, _, _, _) => {
            h185
        }
    }, match v1.clone() {
        Adt53::C0(_, h186, _, _, _, _, _, _) => {
            h186
        }
    }, match v1.clone() {
        Adt53::C0(_, _, h187, _, _, _, _, _) => {
            h187
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, h188, _, _, _, _) => {
            h188
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, h189, _, _, _) => {
            h189
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, h190, _, _) => {
            h190
        }
    }, match v1 {
        Adt53::C0(_, _, _, _, _, _, h191, _) => {
            h191
        }
    }, v2))
}

pub fn f17(v0: Adt53) -> Result<Adt9, Adt43> {
    let m193 = match v0.clone() {
        Adt53::C0(h192, _, _, _, _, _, _, _) => {
            h192
        }
    };
    match m193 {
        Adt54::C0 => {
            let m195 = match v0.clone() {
                Adt53::C0(_, h194, _, _, _, _, _, _) => {
                    h194
                }
            };
            match m195 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v1) => {
                    Ok::<Adt9, Adt43>(Adt9::C0(Adt10::C0(v1, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h196) => {
                            h196
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h197, _, _, _, _) => {
                            h197
                        }
                    }))))
                }
            }
        }
        Adt54::C1 => {
            let m199 = match v0.clone() {
                Adt53::C0(_, _, h198, _, _, _, _, _) => {
                    h198
                }
            };
            match m199 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v2) => {
                    Ok::<Adt9, Adt43>(Adt9::C1(Adt15::C0(v2, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h200) => {
                            h200
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h201, _, _, _, _) => {
                            h201
                        }
                    }))))
                }
            }
        }
        Adt54::C2 => {
            let m203 = match v0.clone() {
                Adt53::C0(_, _, h202, _, _, _, _, _) => {
                    h202
                }
            };
            match m203 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v3) => {
                    Ok::<Adt9, Adt43>(Adt9::C2(Adt15::C0(v3, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h204) => {
                            h204
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h205, _, _, _, _) => {
                            h205
                        }
                    }))))
                }
            }
        }
        Adt54::C3 => {
            let m207 = match v0.clone() {
                Adt53::C0(_, _, h206, _, _, _, _, _) => {
                    h206
                }
            };
            match m207 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v4) => {
                    Ok::<Adt9, Adt43>(Adt9::C3(Adt16::C0(v4, match v0.clone() {
                        Adt53::C0(_, _, _, _, h208, _, _, _) => {
                            h208
                        }
                    }, None::<Adt11>, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h209) => {
                            h209
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h210, _, _, _, _) => {
                            h210
                        }
                    }))))
                }
            }
        }
        Adt54::C4 => {
            let m212 = match v0.clone() {
                Adt53::C0(_, h211, _, _, _, _, _, _) => {
                    h211
                }
            };
            match m212 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v5) => {
                    let m214 = match v0.clone() {
                        Adt53::C0(_, _, _, _, _, h213, _, _) => {
                            h213
                        }
                    };
                    match m214 {
                        None => {
                            Err::<Adt9, Adt43>(Adt43::C4)
                        }
                        Some(v6) => {
                            Ok::<Adt9, Adt43>(Adt9::C4(Adt17::C0(v5, v6, Adt12::C0(match v0.clone() {
                                Adt53::C0(_, _, _, _, _, _, _, h215) => {
                                    h215
                                }
                            }, match v0 {
                                Adt53::C0(_, _, _, h216, _, _, _, _) => {
                                    h216
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt54::C5 => {
            let m218 = match v0.clone() {
                Adt53::C0(_, h217, _, _, _, _, _, _) => {
                    h217
                }
            };
            match m218 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v7) => {
                    Ok::<Adt9, Adt43>(Adt9::C5(Adt18::C0(v7, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h219) => {
                            h219
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h220, _, _, _, _) => {
                            h220
                        }
                    }))))
                }
            }
        }
        Adt54::C6 => {
            let m222 = match v0.clone() {
                Adt53::C0(_, h221, _, _, _, _, _, _) => {
                    h221
                }
            };
            match m222 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v8) => {
                    Ok::<Adt9, Adt43>(Adt9::C6(Adt19::C0(v8, match v0.clone() {
                        Adt53::C0(_, _, h223, _, _, _, _, _) => {
                            h223
                        }
                    }, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h224) => {
                            h224
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h225, _, _, _, _) => {
                            h225
                        }
                    }))))
                }
            }
        }
        Adt54::C7 => {
            let m227 = match v0.clone() {
                Adt53::C0(_, _, h226, _, _, _, _, _) => {
                    h226
                }
            };
            match m227 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v9) => {
                    let m229 = match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, h228, _) => {
                            h228
                        }
                    };
                    match m229 {
                        None => {
                            Err::<Adt9, Adt43>(Adt43::C16)
                        }
                        Some(v10) => {
                            Ok::<Adt9, Adt43>(Adt9::C7(Adt20::C0(v9, v10, match v0.clone() {
                                Adt53::C0(_, _, _, _, h230, _, _, _) => {
                                    h230
                                }
                            }, Adt12::C0(match v0.clone() {
                                Adt53::C0(_, _, _, _, _, _, _, h231) => {
                                    h231
                                }
                            }, match v0 {
                                Adt53::C0(_, _, _, h232, _, _, _, _) => {
                                    h232
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt54::C8 => {
            let m234 = match v0.clone() {
                Adt53::C0(_, h233, _, _, _, _, _, _) => {
                    h233
                }
            };
            match m234 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v11) => {
                    Ok::<Adt9, Adt43>(Adt9::C8(Adt21::C0(v11, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h235) => {
                            h235
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h236, _, _, _, _) => {
                            h236
                        }
                    }))))
                }
            }
        }
        Adt54::C9 => {
            let m238 = match v0.clone() {
                Adt53::C0(_, h237, _, _, _, _, _, _) => {
                    h237
                }
            };
            match m238 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v12) => {
                    Ok::<Adt9, Adt43>(Adt9::C9(Adt21::C0(v12, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h239) => {
                            h239
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h240, _, _, _, _) => {
                            h240
                        }
                    }))))
                }
            }
        }
    }
}

pub fn f18(v0: Adt0, v1: Adt53, v2: Adt75) -> Adt65 {
    Adt65::C0(Adt0::C0(match v2.clone() {
        Adt75::C0(h241, _) => {
            h241
        }
    }, v1, match v0.clone() {
        Adt0::C0(_, _, h242, _, _, _, _) => {
            h242
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, h243, _, _, _) => {
            h243
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, h244, _, _) => {
            h244
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, _, h245, _) => {
            h245
        }
    }, match v0 {
        Adt0::C0(_, _, _, _, _, _, h246) => {
            h246
        }
    }), f35(match v2 {
        Adt75::C0(_, h247) => {
            h247
        }
    }))
}

pub fn f19(v0: Adt1, v1: Adt41) -> Adt75 {
    Adt75::C0(Adt1::C0(match v0.clone() {
        Adt1::C0(h248, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h248
        }
    }, match v0.clone() {
        Adt1::C0(_, h249, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h249
        }
    }, match v0.clone() {
        Adt1::C0(_, _, h250, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h250
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, h251, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h251
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, h252, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h252
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, h253, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h253
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h254, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h254
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, h255, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h255
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, h256, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h256
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, h257, _, _, _, _, _, _, _, _, _, _, _) => {
            h257
        }
    }, Some(v1), match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h258, _, _, _, _, _, _, _, _, _) => {
            h258
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h259, _, _, _, _, _, _, _, _) => {
            h259
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h260, _, _, _, _, _, _, _) => {
            h260
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h261, _, _, _, _, _, _) => {
            h261
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h262, _, _, _, _, _) => {
            h262
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h263, _, _, _, _) => {
            h263
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h264, _, _, _) => {
            h264
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h265, _, _) => {
            h265
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h266, _) => {
            h266
        }
    }, match v0 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h267) => {
            h267
        }
    }), List::<Adt67>::nil())
}

pub fn f20(v0: Adt1, v1: Adt9) -> R<Adt75> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h268, _, _, _, _, _, _) => {
            h268
        }
    } {
        Ok(Adt75::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h269, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h269
            }
        }, match v0.clone() {
            Adt1::C0(_, h270, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h270
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h271, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h271
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h272, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h272
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h273, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h273
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h274, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h274
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h275, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h275
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h276, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h276
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h277, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h277
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h278, _, _, _, _, _, _, _, _, _, _, _) => {
                h278
            }
        }, Some(Adt41::C10(Adt43::C1)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h279, _, _, _, _, _, _, _, _, _) => {
                h279
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h280, _, _, _, _, _, _, _, _) => {
                h280
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h281, _, _, _, _, _, _, _) => {
                h281
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h282, _, _, _, _, _, _) => {
                h282
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h283, _, _, _, _, _) => {
                h283
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h284, _, _, _, _) => {
                h284
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h285, _, _, _) => {
                h285
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h286, _, _) => {
                h286
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h287, _) => {
                h287
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h288) => {
                h288
            }
        }), List::<Adt67>::nil()))
    } else {
        let a290 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h289, _, _, _, _, _, _, _) => {
                h289
            }
        };
        if bool_not(a290) {
            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h291, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h291
                }
            }, match v0.clone() {
                Adt1::C0(_, h292, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h292
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h293, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h293
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h294, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h294
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h295, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h295
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h296, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h296
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h297, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h297
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h298, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h298
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h299, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h299
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h300, _, _, _, _, _, _, _, _, _, _, _) => {
                    h300
                }
            }, Some(Adt41::C10(Adt43::C2)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h301, _, _, _, _, _, _, _, _, _) => {
                    h301
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h302, _, _, _, _, _, _, _, _) => {
                    h302
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h303, _, _, _, _, _, _, _) => {
                    h303
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h304, _, _, _, _, _, _) => {
                    h304
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h305, _, _, _, _, _) => {
                    h305
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h306, _, _, _, _) => {
                    h306
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h307, _, _, _) => {
                    h307
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h308, _, _) => {
                    h308
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h309, _) => {
                    h309
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h310) => {
                    h310
                }
            }), List::<Adt67>::nil()))
        } else {
            let m313 = match v0.clone() {
                Adt1::C0(_, h312, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h312
                }
            };
            if match m313 {
                Adt2::C0(_, _, h311, _, _, _) => {
                    h311
                }
            } {
                Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h314, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h314
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h315, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h315
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h316, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h316
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h317, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h317
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h318, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h318
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h319, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h319
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h320, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h320
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h321, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h321
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h322, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h322
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h323, _, _, _, _, _, _, _, _, _, _, _) => {
                        h323
                    }
                }, Some(Adt41::C10(Adt43::C0)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h324, _, _, _, _, _, _, _, _, _) => {
                        h324
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h325, _, _, _, _, _, _, _, _) => {
                        h325
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h326, _, _, _, _, _, _, _) => {
                        h326
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h327, _, _, _, _, _, _) => {
                        h327
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h328, _, _, _, _, _) => {
                        h328
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h329, _, _, _, _) => {
                        h329
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h330, _, _, _) => {
                        h330
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h331, _, _) => {
                        h331
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h332, _) => {
                        h332
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h333) => {
                        h333
                    }
                }), List::<Adt67>::nil()))
            } else {
                if match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h334, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h334
                    }
                } {
                    Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h335, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h335
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, h336, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h336
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, h337, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h337
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h338, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h338
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h339, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h339
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h340, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h340
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h341, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h341
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h342, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h342
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, h343, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h343
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, h344, _, _, _, _, _, _, _, _, _, _, _) => {
                            h344
                        }
                    }, Some(Adt41::C10(Adt43::C6)), match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h345, _, _, _, _, _, _, _, _, _) => {
                            h345
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h346, _, _, _, _, _, _, _, _) => {
                            h346
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h347, _, _, _, _, _, _, _) => {
                            h347
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h348, _, _, _, _, _, _) => {
                            h348
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h349, _, _, _, _, _) => {
                            h349
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h350, _, _, _, _) => {
                            h350
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h351, _, _, _) => {
                            h351
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h352, _, _) => {
                            h352
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h353, _) => {
                            h353
                        }
                    }, match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h354) => {
                            h354
                        }
                    }), List::<Adt67>::nil()))
                } else {
                    Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h355, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h355
                        }
                    }, f40(match v0.clone() {
                        Adt1::C0(_, h356, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h356
                        }
                    })?, f41(), f42(), Some(v1.clone()), None::<Adt22>, Adt40::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h357, _, _, _, _, _, _, _) => {
                            h357
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h358, _, _, _, _, _, _) => {
                            h358
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h359, _, _, _, _, _) => {
                            h359
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h360, _, _, _, _) => {
                            h360
                        }
                    }, true, f43(), None::<Adt23>, f44(v0.clone())), f36(List::cons(Adt67::C0(f32(Adt1::C0(match v0.clone() {
                        Adt1::C0(h361, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h361
                        }
                    }, f40(match v0.clone() {
                        Adt1::C0(_, h362, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h362
                        }
                    })?, f41(), f42(), Some(v1.clone()), None::<Adt22>, Adt40::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h363, _, _, _, _, _, _, _) => {
                            h363
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h364, _, _, _, _, _, _) => {
                            h364
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h365, _, _, _, _, _) => {
                            h365
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h366, _, _, _, _) => {
                            h366
                        }
                    }, true, f43(), None::<Adt23>, f44(v0.clone()))), v1), List::<Adt67>::nil()), f45(v0))))
                }
            }
        }
    }
}

pub fn f21(v0: Adt0, v1: Adt63) -> R<Adt65> {
    let m367 = v1;
    match m367 {
        Adt63::C0 => {
            Ok(f18(v0.clone(), match v0.clone() {
                Adt0::C0(_, h368, _, _, _, _, _) => {
                    h368
                }
            }, f39(match v0 {
                Adt0::C0(h369, _, _, _, _, _, _) => {
                    h369
                }
            }, Adt72::C2)?))
        }
        Adt63::C1(v2) => {
            Ok(f18(v0.clone(), match v0.clone() {
                Adt0::C0(_, h370, _, _, _, _, _) => {
                    h370
                }
            }, f39(match v0 {
                Adt0::C0(h371, _, _, _, _, _, _) => {
                    h371
                }
            }, Adt72::C3(v2))?))
        }
        Adt63::C2 => {
            Ok(f18(v0.clone(), match v0.clone() {
                Adt0::C0(_, h372, _, _, _, _, _) => {
                    h372
                }
            }, f39(match v0 {
                Adt0::C0(h373, _, _, _, _, _, _) => {
                    h373
                }
            }, Adt72::C4)?))
        }
        Adt63::C3 => {
            f46(v0)
        }
        Adt63::C4 => {
            f46(v0)
        }
        Adt63::C5 => {
            f46(v0)
        }
        Adt63::C6 => {
            Ok(f18(v0.clone(), match v0.clone() {
                Adt0::C0(_, h374, _, _, _, _, _) => {
                    h374
                }
            }, f39(match v0 {
                Adt0::C0(h375, _, _, _, _, _, _) => {
                    h375
                }
            }, Adt72::C18)?))
        }
        Adt63::C7(v3) => {
            Ok(f18(v0.clone(), match v0.clone() {
                Adt0::C0(_, h376, _, _, _, _, _) => {
                    h376
                }
            }, f39(match v0 {
                Adt0::C0(h377, _, _, _, _, _, _) => {
                    h377
                }
            }, Adt72::C14(v3))?))
        }
        Adt63::C8 => {
            Ok(f18(v0.clone(), match v0.clone() {
                Adt0::C0(_, h378, _, _, _, _, _) => {
                    h378
                }
            }, f39(match v0 {
                Adt0::C0(h379, _, _, _, _, _, _) => {
                    h379
                }
            }, Adt72::C20)?))
        }
    }
}

pub fn f22(v0: Adt0, v1: u64) -> R<Adt65> {
    let m384 = {
        let m383 = match v0.clone() {
            Adt0::C0(h382, _, _, _, _, _, _) => {
                h382
            }
        };
        match m383 {
            Adt1::C0(_, h381, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h381
            }
        }
    };
    if match m384 {
        Adt2::C0(_, _, h380, _, _, _) => {
            h380
        }
    } {
        Ok(f18(v0.clone(), match v0.clone() {
            Adt0::C0(_, h385, _, _, _, _, _) => {
                h385
            }
        }, f47(match v0 {
            Adt0::C0(h386, _, _, _, _, _, _) => {
                h386
            }
        }, v1)))
    } else {
        let m390 = {
            let m389 = match v0.clone() {
                Adt0::C0(h388, _, _, _, _, _, _) => {
                    h388
                }
            };
            match m389 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h387, _, _, _, _, _, _, _, _) => {
                    h387
                }
            }
        };
        match m390 {
            None => {
                Ok(f18(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h391, _, _, _, _, _) => {
                        h391
                    }
                }, f19(match v0 {
                    Adt0::C0(h392, _, _, _, _, _, _) => {
                        h392
                    }
                }, Adt41::C10(Adt43::C4))))
            }
            Some(v2) => {
                let m396 = {
                    let m395 = match v0.clone() {
                        Adt0::C0(_, h394, _, _, _, _, _) => {
                            h394
                        }
                    };
                    match m395 {
                        Adt53::C0(_, h393, _, _, _, _, _, _) => {
                            h393
                        }
                    }
                };
                match m396 {
                    None => {
                        Ok(f18(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h397, _, _, _, _, _) => {
                                h397
                            }
                        }, f19(match v0 {
                            Adt0::C0(h398, _, _, _, _, _, _) => {
                                h398
                            }
                        }, Adt41::C10(Adt43::C14))))
                    }
                    Some(v3) => {
                        Ok(f18(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h399, _, _, _, _, _) => {
                                h399
                            }
                        }, f48(match v0.clone() {
                            Adt0::C0(h400, _, _, _, _, _, _) => {
                                h400
                            }
                        }, Adt17::C0(v3, v2, Adt12::C0(Adt13::C0({
                            let m405 = {
                                let m404 = match v0.clone() {
                                    Adt0::C0(_, h403, _, _, _, _, _) => {
                                        h403
                                    }
                                };
                                match m404 {
                                    Adt53::C0(_, _, _, _, _, _, _, h402) => {
                                        h402
                                    }
                                }
                            };
                            match m405 {
                                Adt13::C0(h401, _, _, _, _, _, _) => {
                                    h401
                                }
                            }
                        }, {
                            let m410 = {
                                let m409 = match v0.clone() {
                                    Adt0::C0(_, h408, _, _, _, _, _) => {
                                        h408
                                    }
                                };
                                match m409 {
                                    Adt53::C0(_, _, _, _, _, _, _, h407) => {
                                        h407
                                    }
                                }
                            };
                            match m410 {
                                Adt13::C0(_, h406, _, _, _, _, _) => {
                                    h406
                                }
                            }
                        }, {
                            let m415 = {
                                let m414 = match v0.clone() {
                                    Adt0::C0(_, h413, _, _, _, _, _) => {
                                        h413
                                    }
                                };
                                match m414 {
                                    Adt53::C0(_, _, _, _, _, _, _, h412) => {
                                        h412
                                    }
                                }
                            };
                            match m415 {
                                Adt13::C0(_, _, h411, _, _, _, _) => {
                                    h411
                                }
                            }
                        }, {
                            let a421 = {
                                let m420 = {
                                    let m419 = match v0.clone() {
                                        Adt0::C0(_, h418, _, _, _, _, _) => {
                                            h418
                                        }
                                    };
                                    match m419 {
                                        Adt53::C0(_, _, _, _, _, _, _, h417) => {
                                            h417
                                        }
                                    }
                                };
                                match m420 {
                                    Adt13::C0(_, _, _, h416, _, _, _) => {
                                        h416
                                    }
                                }
                            };
                            let a422 = v1;
                            nat_add(a421, a422)?
                        }, {
                            let m427 = {
                                let m426 = match v0.clone() {
                                    Adt0::C0(_, h425, _, _, _, _, _) => {
                                        h425
                                    }
                                };
                                match m426 {
                                    Adt53::C0(_, _, _, _, _, _, _, h424) => {
                                        h424
                                    }
                                }
                            };
                            match m427 {
                                Adt13::C0(_, _, _, _, h423, _, _) => {
                                    h423
                                }
                            }
                        }, {
                            let m432 = {
                                let m431 = match v0.clone() {
                                    Adt0::C0(_, h430, _, _, _, _, _) => {
                                        h430
                                    }
                                };
                                match m431 {
                                    Adt53::C0(_, _, _, _, _, _, _, h429) => {
                                        h429
                                    }
                                }
                            };
                            match m432 {
                                Adt13::C0(_, _, _, _, _, h428, _) => {
                                    h428
                                }
                            }
                        }, {
                            let m437 = {
                                let m436 = match v0.clone() {
                                    Adt0::C0(_, h435, _, _, _, _, _) => {
                                        h435
                                    }
                                };
                                match m436 {
                                    Adt53::C0(_, _, _, _, _, _, _, h434) => {
                                        h434
                                    }
                                }
                            };
                            match m437 {
                                Adt13::C0(_, _, _, _, _, _, h433) => {
                                    h433
                                }
                            }
                        }), {
                            let m440 = match v0 {
                                Adt0::C0(_, h439, _, _, _, _, _) => {
                                    h439
                                }
                            };
                            match m440 {
                                Adt53::C0(_, _, _, h438, _, _, _, _) => {
                                    h438
                                }
                            }
                        })))?))
                    }
                }
            }
        }
    }
}

pub fn f23(v0: Adt0, v1: Adt55, v2: List<Adt59>) -> R<Adt65> {
    let m442 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h441) => {
            h441
        }
    };
    match m442 {
        None => {
            let m444 = f38(match v0.clone() {
                Adt0::C0(_, h443, _, _, _, _, _) => {
                    h443
                }
            }, v1.clone());
            match m444 {
                None => {
                    Ok(Adt65::C0(v0, List::<Adt66>::nil()))
                }
                Some(v4) => {
                    Ok(Adt65::C0(Adt0::C0({
                        let m447 = f39(match v0.clone() {
                            Adt0::C0(h446, _, _, _, _, _, _) => {
                                h446
                            }
                        }, Adt72::C1)?;
                        match m447 {
                            Adt75::C0(h445, _) => {
                                h445
                            }
                        }
                    }, f29(match v0.clone() {
                        Adt0::C0(_, h448, _, _, _, _, _) => {
                            h448
                        }
                    }, v1.clone(), None::<Adt11>), {
                        let a450 = match v0.clone() {
                            Adt0::C0(_, _, h449, _, _, _, _) => {
                                h449
                            }
                        };
                        let a451 = 1u64;
                        nat_add(a450, a451)?
                    }, None::<Adt55>, match v0.clone() {
                        Adt0::C0(_, _, _, _, h452, _, _) => {
                            h452
                        }
                    }, f15(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h453, _) => {
                            h453
                        }
                    }, v1.clone(), v2.clone()), Some(Adt60::C0(v1.clone(), f32({
                        let m456 = f39(match v0.clone() {
                            Adt0::C0(h455, _, _, _, _, _, _) => {
                                h455
                            }
                        }, Adt72::C1)?;
                        match m456 {
                            Adt75::C0(h454, _) => {
                                h454
                            }
                        }
                    }), {
                        let a458 = match v0.clone() {
                            Adt0::C0(_, _, h457, _, _, _, _) => {
                                h457
                            }
                        };
                        let a459 = 1u64;
                        nat_add(a458, a459)?
                    }, v4.clone(), v2.clone(), f25(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h460, _) => {
                            h460
                        }
                    }, v1.clone())))), List::cons(Adt66::C2(Adt60::C0(v1.clone(), f32({
                        let m463 = f39(match v0.clone() {
                            Adt0::C0(h462, _, _, _, _, _, _) => {
                                h462
                            }
                        }, Adt72::C1)?;
                        match m463 {
                            Adt75::C0(h461, _) => {
                                h461
                            }
                        }
                    }), {
                        let a465 = match v0.clone() {
                            Adt0::C0(_, _, h464, _, _, _, _) => {
                                h464
                            }
                        };
                        let a466 = 1u64;
                        nat_add(a465, a466)?
                    }, v4, v2, f25(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h467, _) => {
                            h467
                        }
                    }, v1))), f35({
                        let m470 = f39(match v0 {
                            Adt0::C0(h469, _, _, _, _, _, _) => {
                                h469
                            }
                        }, Adt72::C1)?;
                        match m470 {
                            Adt75::C0(_, h468) => {
                                h468
                            }
                        }
                    }))))
                }
            }
        }
        Some(_) => {
            Ok(Adt65::C0(v0, List::<Adt66>::nil()))
        }
    }
}

pub fn f24(v0: List<Adt59>, v1: u64) -> List<Adt59> {
    let m471 = v0;
    match m471.uncons() {
        None => {
            List::<Adt59>::nil()
        }
        Some((v2, v3)) => {
            let a473 = match v2.clone() {
                Adt59::C0(h472, _, _) => {
                    h472
                }
            };
            let a474 = v1;
            if nat_eq(a473, a474) {
                v3
            } else {
                List::cons(v2, f24(v3, v1))
            }
        }
    }
}

pub fn f25(p479: List<Adt58>, v1: Adt55) -> List<Adt59> {
    let m478 = p479;
    {
        let mut m478 = m478;
        loop {
            let step = {
                let v0 = m478;
                let m475 = v0;
                match m475.uncons() {
                    None => {
                        Err::<List<Adt58>, List<Adt59>>(List::<Adt59>::nil())
                    }
                    Some((v2, v3)) => {
                        if f33(match v2.clone() {
                            Adt58::C0(h476, _) => {
                                h476
                            }
                        }, v1.clone()) {
                            match v2 {
                                Adt58::C0(_, h477) => {
                                    Err::<List<Adt58>, List<Adt59>>(h477)
                                }
                            }
                        } else {
                            Ok::<List<Adt58>, List<Adt59>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m478 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f26(v0: List<Adt59>, v1: u64, v2: u64) -> List<Adt59> {
    let m480 = f49(v0.clone(), v1);
    match m480 {
        None => {
            v0
        }
        Some(v3) => {
            f50(f24(v0, v1), v2, v3)
        }
    }
}

pub fn f27(v0: Adt0, v1: Adt52, v2: u64, v3: Adt11, v4: List<Adt59>) -> R<Adt65> {
    let m482 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h481) => {
            h481
        }
    };
    match m482 {
        None => {
            Ok(Adt65::C0(v0, List::cons(Adt66::C0(Adt67::C6(v3)), List::<Adt66>::nil())))
        }
        Some(v5) => {
            if if f1(match v0.clone() {
                Adt0::C0(h483, _, _, _, _, _, _) => {
                    h483
                }
            }, v1) {
                let a485 = match v5.clone() {
                    Adt60::C0(_, _, h484, _, _, _) => {
                        h484
                    }
                };
                let a486 = v2;
                if nat_eq(a485, a486) {
                    let a491 = match v3.clone() {
                        Adt11::C0(h487, _, _) => {
                            h487
                        }
                    };
                    let a492 = {
                        let m490 = match v0.clone() {
                            Adt0::C0(h489, _, _, _, _, _, _) => {
                                h489
                            }
                        };
                        match m490 {
                            Adt1::C0(h488, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h488
                            }
                        }
                    };
                    if nat_eq(a491, a492) {
                        if f12(v4.clone()) {
                            f51(match v5.clone() {
                                Adt60::C0(_, _, _, _, h493, _) => {
                                    h493
                                }
                            }, v4.clone())
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(Adt65::C0(Adt0::C0({
                    let m498 = {
                        let m497 = f13(v0.clone(), match v5.clone() {
                            Adt60::C0(h496, _, _, _, _, _) => {
                                h496
                            }
                        }, v3.clone(), v4.clone())?;
                        match m497 {
                            Adt65::C0(h495, _) => {
                                h495
                            }
                        }
                    };
                    match m498 {
                        Adt0::C0(h494, _, _, _, _, _, _) => {
                            h494
                        }
                    }
                }, {
                    let m503 = {
                        let m502 = f13(v0.clone(), match v5.clone() {
                            Adt60::C0(h501, _, _, _, _, _) => {
                                h501
                            }
                        }, v3.clone(), v4.clone())?;
                        match m502 {
                            Adt65::C0(h500, _) => {
                                h500
                            }
                        }
                    };
                    match m503 {
                        Adt0::C0(_, h499, _, _, _, _, _) => {
                            h499
                        }
                    }
                }, {
                    let m508 = {
                        let m507 = f13(v0.clone(), match v5.clone() {
                            Adt60::C0(h506, _, _, _, _, _) => {
                                h506
                            }
                        }, v3.clone(), v4.clone())?;
                        match m507 {
                            Adt65::C0(h505, _) => {
                                h505
                            }
                        }
                    };
                    match m508 {
                        Adt0::C0(_, _, h504, _, _, _, _) => {
                            h504
                        }
                    }
                }, {
                    let m513 = {
                        let m512 = f13(v0.clone(), match v5.clone() {
                            Adt60::C0(h511, _, _, _, _, _) => {
                                h511
                            }
                        }, v3.clone(), v4.clone())?;
                        match m512 {
                            Adt65::C0(h510, _) => {
                                h510
                            }
                        }
                    };
                    match m513 {
                        Adt0::C0(_, _, _, h509, _, _, _) => {
                            h509
                        }
                    }
                }, {
                    let m518 = {
                        let m517 = f13(v0.clone(), match v5.clone() {
                            Adt60::C0(h516, _, _, _, _, _) => {
                                h516
                            }
                        }, v3.clone(), v4.clone())?;
                        match m517 {
                            Adt65::C0(h515, _) => {
                                h515
                            }
                        }
                    };
                    match m518 {
                        Adt0::C0(_, _, _, _, h514, _, _) => {
                            h514
                        }
                    }
                }, {
                    let m523 = {
                        let m522 = f13(v0.clone(), match v5.clone() {
                            Adt60::C0(h521, _, _, _, _, _) => {
                                h521
                            }
                        }, v3.clone(), v4.clone())?;
                        match m522 {
                            Adt65::C0(h520, _) => {
                                h520
                            }
                        }
                    };
                    match m523 {
                        Adt0::C0(_, _, _, _, _, h519, _) => {
                            h519
                        }
                    }
                }, None::<Adt60>), List::cons(Adt66::C0(Adt67::C6(match v5.clone() {
                    Adt60::C0(_, _, _, h524, _, _) => {
                        h524
                    }
                })), {
                    let m527 = f13(v0, match v5 {
                        Adt60::C0(h526, _, _, _, _, _) => {
                            h526
                        }
                    }, v3, v4)?;
                    match m527 {
                        Adt65::C0(_, h525) => {
                            h525
                        }
                    }
                })))
            } else {
                Ok(Adt65::C0(v0, List::cons(Adt66::C0(Adt67::C6(v3)), List::<Adt66>::nil())))
            }
        }
    }
}

pub fn f28(v0: Adt0, v1: Adt52, v2: u64, v3: Str) -> R<Adt65> {
    let m529 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h528) => {
            h528
        }
    };
    match m529 {
        None => {
            Ok(Adt65::C0(v0, List::<Adt66>::nil()))
        }
        Some(v4) => {
            if if f1(match v0.clone() {
                Adt0::C0(h530, _, _, _, _, _, _) => {
                    h530
                }
            }, v1) {
                let a532 = match v4.clone() {
                    Adt60::C0(_, _, h531, _, _, _) => {
                        h531
                    }
                };
                let a533 = v2;
                nat_eq(a532, a533)
            } else {
                false
            } {
                Ok(Adt65::C0(Adt0::C0({
                    let m536 = f19(match v0.clone() {
                        Adt0::C0(h535, _, _, _, _, _, _) => {
                            h535
                        }
                    }, Adt41::C8(v3));
                    match m536 {
                        Adt75::C0(h534, _) => {
                            h534
                        }
                    }
                }, {
                    let m550 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h538, _, _, _, _, _, _) => {
                            h538
                        }
                    }, f29(match v0.clone() {
                        Adt0::C0(_, h539, _, _, _, _, _) => {
                            h539
                        }
                    }, match v4.clone() {
                        Adt60::C0(h540, _, _, _, _, _) => {
                            h540
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h541, _, _) => {
                            h541
                        }
                    })), {
                        let a543 = match v0.clone() {
                            Adt0::C0(_, _, h542, _, _, _, _) => {
                                h542
                            }
                        };
                        let a544 = 1u64;
                        nat_add(a543, a544)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h545, _, _, _) => {
                            h545
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h546, _, _) => {
                            h546
                        }
                    }, f15(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h547, _) => {
                            h547
                        }
                    }, match v4.clone() {
                        Adt60::C0(h548, _, _, _, _, _) => {
                            h548
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h549) => {
                            h549
                        }
                    }), None::<Adt60>);
                    match m550 {
                        Adt0::C0(_, h537, _, _, _, _, _) => {
                            h537
                        }
                    }
                }, {
                    let m564 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h552, _, _, _, _, _, _) => {
                            h552
                        }
                    }, f29(match v0.clone() {
                        Adt0::C0(_, h553, _, _, _, _, _) => {
                            h553
                        }
                    }, match v4.clone() {
                        Adt60::C0(h554, _, _, _, _, _) => {
                            h554
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h555, _, _) => {
                            h555
                        }
                    })), {
                        let a557 = match v0.clone() {
                            Adt0::C0(_, _, h556, _, _, _, _) => {
                                h556
                            }
                        };
                        let a558 = 1u64;
                        nat_add(a557, a558)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h559, _, _, _) => {
                            h559
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h560, _, _) => {
                            h560
                        }
                    }, f15(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h561, _) => {
                            h561
                        }
                    }, match v4.clone() {
                        Adt60::C0(h562, _, _, _, _, _) => {
                            h562
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h563) => {
                            h563
                        }
                    }), None::<Adt60>);
                    match m564 {
                        Adt0::C0(_, _, h551, _, _, _, _) => {
                            h551
                        }
                    }
                }, {
                    let m578 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h566, _, _, _, _, _, _) => {
                            h566
                        }
                    }, f29(match v0.clone() {
                        Adt0::C0(_, h567, _, _, _, _, _) => {
                            h567
                        }
                    }, match v4.clone() {
                        Adt60::C0(h568, _, _, _, _, _) => {
                            h568
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h569, _, _) => {
                            h569
                        }
                    })), {
                        let a571 = match v0.clone() {
                            Adt0::C0(_, _, h570, _, _, _, _) => {
                                h570
                            }
                        };
                        let a572 = 1u64;
                        nat_add(a571, a572)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h573, _, _, _) => {
                            h573
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h574, _, _) => {
                            h574
                        }
                    }, f15(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h575, _) => {
                            h575
                        }
                    }, match v4.clone() {
                        Adt60::C0(h576, _, _, _, _, _) => {
                            h576
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h577) => {
                            h577
                        }
                    }), None::<Adt60>);
                    match m578 {
                        Adt0::C0(_, _, _, h565, _, _, _) => {
                            h565
                        }
                    }
                }, {
                    let m592 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h580, _, _, _, _, _, _) => {
                            h580
                        }
                    }, f29(match v0.clone() {
                        Adt0::C0(_, h581, _, _, _, _, _) => {
                            h581
                        }
                    }, match v4.clone() {
                        Adt60::C0(h582, _, _, _, _, _) => {
                            h582
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h583, _, _) => {
                            h583
                        }
                    })), {
                        let a585 = match v0.clone() {
                            Adt0::C0(_, _, h584, _, _, _, _) => {
                                h584
                            }
                        };
                        let a586 = 1u64;
                        nat_add(a585, a586)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h587, _, _, _) => {
                            h587
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h588, _, _) => {
                            h588
                        }
                    }, f15(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h589, _) => {
                            h589
                        }
                    }, match v4.clone() {
                        Adt60::C0(h590, _, _, _, _, _) => {
                            h590
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h591) => {
                            h591
                        }
                    }), None::<Adt60>);
                    match m592 {
                        Adt0::C0(_, _, _, _, h579, _, _) => {
                            h579
                        }
                    }
                }, {
                    let m606 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h594, _, _, _, _, _, _) => {
                            h594
                        }
                    }, f29(match v0.clone() {
                        Adt0::C0(_, h595, _, _, _, _, _) => {
                            h595
                        }
                    }, match v4.clone() {
                        Adt60::C0(h596, _, _, _, _, _) => {
                            h596
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h597, _, _) => {
                            h597
                        }
                    })), {
                        let a599 = match v0.clone() {
                            Adt0::C0(_, _, h598, _, _, _, _) => {
                                h598
                            }
                        };
                        let a600 = 1u64;
                        nat_add(a599, a600)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h601, _, _, _) => {
                            h601
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h602, _, _) => {
                            h602
                        }
                    }, f15(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h603, _) => {
                            h603
                        }
                    }, match v4.clone() {
                        Adt60::C0(h604, _, _, _, _, _) => {
                            h604
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h605) => {
                            h605
                        }
                    }), None::<Adt60>);
                    match m606 {
                        Adt0::C0(_, _, _, _, _, h593, _) => {
                            h593
                        }
                    }
                }, {
                    let m620 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h608, _, _, _, _, _, _) => {
                            h608
                        }
                    }, f29(match v0.clone() {
                        Adt0::C0(_, h609, _, _, _, _, _) => {
                            h609
                        }
                    }, match v4.clone() {
                        Adt60::C0(h610, _, _, _, _, _) => {
                            h610
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h611, _, _) => {
                            h611
                        }
                    })), {
                        let a613 = match v0.clone() {
                            Adt0::C0(_, _, h612, _, _, _, _) => {
                                h612
                            }
                        };
                        let a614 = 1u64;
                        nat_add(a613, a614)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h615, _, _, _) => {
                            h615
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h616, _, _) => {
                            h616
                        }
                    }, f15(match v0 {
                        Adt0::C0(_, _, _, _, _, h617, _) => {
                            h617
                        }
                    }, match v4.clone() {
                        Adt60::C0(h618, _, _, _, _, _) => {
                            h618
                        }
                    }, match v4 {
                        Adt60::C0(_, _, _, _, _, h619) => {
                            h619
                        }
                    }), None::<Adt60>);
                    match m620 {
                        Adt0::C0(_, _, _, _, _, _, h607) => {
                            h607
                        }
                    }
                }), List::<Adt66>::nil()))
            } else {
                Ok(Adt65::C0(v0, List::<Adt66>::nil()))
            }
        }
    }
}

pub fn f29(v0: Adt53, v1: Adt55, v2: Option<Adt11>) -> Adt53 {
    let m621 = v1;
    match m621 {
        Adt55::C0 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h622, _, _, _, _, _, _, _) => {
                    h622
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, h623, _, _, _, _, _) => {
                    h623
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h624, _, _, _, _) => {
                    h624
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h625, _, _, _) => {
                    h625
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h626, _, _) => {
                    h626
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h627, _) => {
                    h627
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h628) => {
                    h628
                }
            })
        }
        Adt55::C1 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h629, _, _, _, _, _, _, _) => {
                    h629
                }
            }, match v0.clone() {
                Adt53::C0(_, h630, _, _, _, _, _, _) => {
                    h630
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, h631, _, _, _, _) => {
                    h631
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h632, _, _, _) => {
                    h632
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h633, _, _) => {
                    h633
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h634, _) => {
                    h634
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h635) => {
                    h635
                }
            })
        }
        Adt55::C2 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h636, _, _, _, _, _, _, _) => {
                    h636
                }
            }, match v0.clone() {
                Adt53::C0(_, h637, _, _, _, _, _, _) => {
                    h637
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h638, _, _, _, _, _) => {
                    h638
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, h639, _, _, _) => {
                    h639
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h640, _, _) => {
                    h640
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h641, _) => {
                    h641
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h642) => {
                    h642
                }
            })
        }
        Adt55::C3 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h643, _, _, _, _, _, _, _) => {
                    h643
                }
            }, match v0.clone() {
                Adt53::C0(_, h644, _, _, _, _, _, _) => {
                    h644
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h645, _, _, _, _, _) => {
                    h645
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h646, _, _, _, _) => {
                    h646
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h647, _, _) => {
                    h647
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h648, _) => {
                    h648
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h649) => {
                    h649
                }
            })
        }
        Adt55::C4 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h650, _, _, _, _, _, _, _) => {
                    h650
                }
            }, match v0.clone() {
                Adt53::C0(_, h651, _, _, _, _, _, _) => {
                    h651
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h652, _, _, _, _, _) => {
                    h652
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h653, _, _, _, _) => {
                    h653
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h654, _, _, _) => {
                    h654
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h655, _) => {
                    h655
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h656) => {
                    h656
                }
            })
        }
        Adt55::C5 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h657, _, _, _, _, _, _, _) => {
                    h657
                }
            }, match v0.clone() {
                Adt53::C0(_, h658, _, _, _, _, _, _) => {
                    h658
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h659, _, _, _, _, _) => {
                    h659
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h660, _, _, _, _) => {
                    h660
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h661, _, _, _) => {
                    h661
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h662, _, _) => {
                    h662
                }
            }, v2, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h663) => {
                    h663
                }
            })
        }
    }
}

pub fn f30(v0: Adt0, v1: Adt65, v2: Adt57) -> R<Adt65> {
    Ok(Adt65::C0(Adt0::C0({
        let m666 = match v1.clone() {
            Adt65::C0(h665, _) => {
                h665
            }
        };
        match m666 {
            Adt0::C0(h664, _, _, _, _, _, _) => {
                h664
            }
        }
    }, {
        let m669 = match v1.clone() {
            Adt65::C0(h668, _) => {
                h668
            }
        };
        match m669 {
            Adt0::C0(_, h667, _, _, _, _, _) => {
                h667
            }
        }
    }, {
        let m672 = match v1.clone() {
            Adt65::C0(h671, _) => {
                h671
            }
        };
        match m672 {
            Adt0::C0(_, _, h670, _, _, _, _) => {
                h670
            }
        }
    }, {
        let m675 = match v1.clone() {
            Adt65::C0(h674, _) => {
                h674
            }
        };
        match m675 {
            Adt0::C0(_, _, _, h673, _, _, _) => {
                h673
            }
        }
    }, Adt56::C0({
        let a679 = {
            let m678 = match v0 {
                Adt0::C0(_, _, _, _, h677, _, _) => {
                    h677
                }
            };
            match m678 {
                Adt56::C0(h676, _) => {
                    h676
                }
            }
        };
        let a680 = 1u64;
        nat_add(a679, a680)?
    }, v2), {
        let m683 = match v1.clone() {
            Adt65::C0(h682, _) => {
                h682
            }
        };
        match m683 {
            Adt0::C0(_, _, _, _, _, h681, _) => {
                h681
            }
        }
    }, {
        let m686 = match v1.clone() {
            Adt65::C0(h685, _) => {
                h685
            }
        };
        match m686 {
            Adt0::C0(_, _, _, _, _, _, h684) => {
                h684
            }
        }
    }), match v1 {
        Adt65::C0(_, h687) => {
            h687
        }
    }))
}

pub fn f31(v0: Adt0, v1: Adt53) -> R<Adt65> {
    Ok(f18(v0.clone(), v1, f39(match v0 {
        Adt0::C0(h688, _, _, _, _, _, _) => {
            h688
        }
    }, Adt72::C1)?))
}

pub fn f32(v0: Adt1) -> Adt52 {
    Adt52::C0(match v0.clone() {
        Adt1::C0(h689, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h689
        }
    }, {
        let m692 = match v0.clone() {
            Adt1::C0(_, h691, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h691
            }
        };
        match m692 {
            Adt2::C0(_, h690, _, _, _, _) => {
                h690
            }
        }
    }, {
        let m695 = match v0 {
            Adt1::C0(_, h694, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h694
            }
        };
        match m695 {
            Adt2::C0(h693, _, _, _, _, _) => {
                h693
            }
        }
    })
}

pub fn f33(v0: Adt55, v1: Adt55) -> bool {
    let m696 = v0;
    match m696 {
        Adt55::C0 => {
            let m697 = v1;
            match m697 {
                Adt55::C0 => {
                    true
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C1 => {
            let m698 = v1;
            match m698 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    true
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C2 => {
            let m699 = v1;
            match m699 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    true
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C3 => {
            let m700 = v1;
            match m700 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    true
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C4 => {
            let m701 = v1;
            match m701 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    true
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C5 => {
            let m702 = v1;
            match m702 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    true
                }
            }
        }
    }
}

pub fn f34(p708: List<Adt59>, v1: u64) -> bool {
    let m707 = p708;
    {
        let mut m707 = m707;
        loop {
            let step = {
                let v0 = m707;
                let m703 = v0;
                match m703.uncons() {
                    None => {
                        Err::<List<Adt59>, bool>(false)
                    }
                    Some((v2, v3)) => {
                        let a705 = match v2 {
                            Adt59::C0(h704, _, _) => {
                                h704
                            }
                        };
                        let a706 = v1;
                        if nat_eq(a705, a706) {
                            Err::<List<Adt59>, bool>(true)
                        } else {
                            Ok::<List<Adt59>, bool>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m707 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f35(v0: List<Adt67>) -> List<Adt66> {
    let m709 = v0;
    match m709.uncons() {
        None => {
            List::<Adt66>::nil()
        }
        Some((v1, v2)) => {
            List::cons(Adt66::C0(v1), f35(v2))
        }
    }
}

pub fn f36(v0: List<Adt67>, v1: List<Adt67>) -> List<Adt67> {
    let m710 = v0;
    match m710.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f36(v3, v1))
        }
    }
}

pub fn f37(v0: Option<Adt11>, v1: Option<Adt11>) -> List<Adt67> {
    let m711 = v0;
    match m711 {
        None => {
            List::<Adt67>::nil()
        }
        Some(v2) => {
            let m712 = v1;
            match m712 {
                None => {
                    List::cons(Adt67::C6(v2), List::<Adt67>::nil())
                }
                Some(v3) => {
                    if f52(v2.clone(), v3) {
                        List::<Adt67>::nil()
                    } else {
                        List::cons(Adt67::C6(v2), List::<Adt67>::nil())
                    }
                }
            }
        }
    }
}

pub fn f38(v0: Adt53, v1: Adt55) -> Option<Adt11> {
    let m713 = v1;
    match m713 {
        Adt55::C0 => {
            match v0 {
                Adt53::C0(_, h714, _, _, _, _, _, _) => {
                    h714
                }
            }
        }
        Adt55::C1 => {
            match v0 {
                Adt53::C0(_, _, h715, _, _, _, _, _) => {
                    h715
                }
            }
        }
        Adt55::C2 => {
            match v0 {
                Adt53::C0(_, _, _, h716, _, _, _, _) => {
                    h716
                }
            }
        }
        Adt55::C3 => {
            match v0 {
                Adt53::C0(_, _, _, _, h717, _, _, _) => {
                    h717
                }
            }
        }
        Adt55::C4 => {
            match v0 {
                Adt53::C0(_, _, _, _, _, h718, _, _) => {
                    h718
                }
            }
        }
        Adt55::C5 => {
            match v0 {
                Adt53::C0(_, _, _, _, _, _, h719, _) => {
                    h719
                }
            }
        }
    }
}

pub fn f39(v0: Adt1, v1: Adt72) -> R<Adt75> {
    let m720 = v1;
    match m720 {
        Adt72::C0(v2) => {
            f20(v0, v2)
        }
        Adt72::C1 => {
            f53(v0.clone(), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h721, _, _, _, _, _, _, _) => {
                    h721
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h722, _, _, _, _, _, _) => {
                    h722
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h723, _, _, _, _, _) => {
                    h723
                }
            })
        }
        Adt72::C2 => {
            f54(v0)
        }
        Adt72::C3(v3) => {
            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h724, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h724
                }
            }, match v0.clone() {
                Adt1::C0(_, h725, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h725
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h726, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h726
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h727, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h727
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h728, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h728
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h729, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h729
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h730, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h730
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h731, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h731
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h732, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h732
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h733, _, _, _, _, _, _, _, _, _, _, _) => {
                    h733
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h734, _, _, _, _, _, _, _, _, _, _) => {
                    h734
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h735, _, _, _, _, _, _, _, _, _) => {
                    h735
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h736, _, _, _, _, _, _, _, _) => {
                    h736
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h737, _, _, _, _, _, _, _) => {
                    h737
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h738, _, _, _, _, _, _) => {
                    h738
                }
            }, v3, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h739, _, _, _, _) => {
                    h739
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h740, _, _, _) => {
                    h740
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h741, _, _) => {
                    h741
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h742, _) => {
                    h742
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h743) => {
                    h743
                }
            }), List::<Adt67>::nil()))
        }
        Adt72::C4 => {
            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h744, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h744
                }
            }, match v0.clone() {
                Adt1::C0(_, h745, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h745
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h746, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h746
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h747, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h747
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h748, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h748
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h749, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h749
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h750, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h750
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h751, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h751
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h752, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h752
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h753, _, _, _, _, _, _, _, _, _, _, _) => {
                    h753
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h754, _, _, _, _, _, _, _, _, _, _) => {
                    h754
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h755, _, _, _, _, _, _, _, _, _) => {
                    h755
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h756, _, _, _, _, _, _, _, _) => {
                    h756
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h757, _, _, _, _, _, _, _) => {
                    h757
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h758, _, _, _, _, _, _) => {
                    h758
                }
            }, Adt48::C0, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h759, _, _, _, _) => {
                    h759
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h760, _, _, _) => {
                    h760
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h761, _, _) => {
                    h761
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h762, _) => {
                    h762
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h763) => {
                    h763
                }
            }), List::<Adt67>::nil()))
        }
        Adt72::C5 => {
            if match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h764, _, _, _, _, _, _, _) => {
                    h764
                }
            } {
                f53(v0.clone(), false, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h765, _, _, _, _, _, _) => {
                        h765
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h766, _, _, _, _, _) => {
                        h766
                    }
                })
            } else {
                Ok(Adt75::C0(v0, List::<Adt67>::nil()))
            }
        }
        Adt72::C6 => {
            f55(v0)
        }
        Adt72::C7 => {
            f55(v0)
        }
        Adt72::C8(v4) => {
            let a768 = match v0.clone() {
                Adt1::C0(h767, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h767
                }
            };
            let a769 = v4;
            if nat_eq(a768, a769) {
                Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h770, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h770
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h771, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h771
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h772, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h772
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h773, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h773
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h774, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h774
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h775, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h775
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h776, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h776
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h777, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h777
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h778, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h778
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h779, _, _, _, _, _, _, _, _, _, _, _) => {
                        h779
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h780, _, _, _, _, _, _, _, _, _, _) => {
                        h780
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h781, _, _, _, _, _, _, _, _, _) => {
                        h781
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h782, _, _, _, _, _, _, _, _) => {
                        h782
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h783, _, _, _, _, _, _, _) => {
                        h783
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h784, _, _, _, _, _, _) => {
                        h784
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h785, _, _, _, _, _) => {
                        h785
                    }
                }, Adt49::C2, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h786, _, _, _) => {
                        h786
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h787, _, _) => {
                        h787
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h788, _) => {
                        h788
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h789) => {
                        h789
                    }
                }), List::<Adt67>::nil()))
            } else {
                Ok(Adt75::C0(v0, List::<Adt67>::nil()))
            }
        }
        Adt72::C9(v5) => {
            Ok(f56(v0, v5))
        }
        Adt72::C10(v6, v7) => {
            f57(v0, v6, v7)
        }
        Adt72::C11(v8) => {
            let m792 = match v0.clone() {
                Adt1::C0(_, h791, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h791
                }
            };
            if match m792 {
                Adt2::C0(_, _, h790, _, _, _) => {
                    h790
                }
            } {
                Ok(Adt75::C0(v0.clone(), List::cons(Adt67::C2(f32(v0), v8), List::<Adt67>::nil())))
            } else {
                Ok(Adt75::C0(v0, List::<Adt67>::nil()))
            }
        }
        Adt72::C12(v9, v10) => {
            if f58(v0.clone(), v9) {
                Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h793, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h793
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h794, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h794
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h795, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h795
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h796, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h796
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h797, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h797
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h798, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h798
                    }
                }, v10, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h799, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h799
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h800, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h800
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h801, _, _, _, _, _, _, _, _, _, _, _) => {
                        h801
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h802, _, _, _, _, _, _, _, _, _, _) => {
                        h802
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h803, _, _, _, _, _, _, _, _, _) => {
                        h803
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h804, _, _, _, _, _, _, _, _) => {
                        h804
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h805, _, _, _, _, _, _, _) => {
                        h805
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h806, _, _, _, _, _, _) => {
                        h806
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h807, _, _, _, _, _) => {
                        h807
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h808, _, _, _, _) => {
                        h808
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h809, _, _, _) => {
                        h809
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h810, _, _) => {
                        h810
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h811, _) => {
                        h811
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h812) => {
                        h812
                    }
                }), List::<Adt67>::nil()))
            } else {
                Ok(Adt75::C0(v0, List::<Adt67>::nil()))
            }
        }
        Adt72::C13(v11, v12) => {
            if if f58(v0.clone(), v11) {
                let a815 = match v12.clone() {
                    Adt11::C0(h813, _, _) => {
                        h813
                    }
                };
                let a816 = match v0.clone() {
                    Adt1::C0(h814, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h814
                    }
                };
                nat_eq(a815, a816)
            } else {
                false
            } {
                Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h817, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h817
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h818, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h818
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h819, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h819
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h820, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h820
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h821, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h821
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h822, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h822
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h823, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h823
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h824, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h824
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h825, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h825
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h826, _, _, _, _, _, _, _, _, _, _, _) => {
                        h826
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h827, _, _, _, _, _, _, _, _, _, _) => {
                        h827
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h828, _, _, _, _, _, _, _, _, _) => {
                        h828
                    }
                }, Some(v12), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h829, _, _, _, _, _, _, _) => {
                        h829
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h830, _, _, _, _, _, _) => {
                        h830
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h831, _, _, _, _, _) => {
                        h831
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h832, _, _, _, _) => {
                        h832
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h833, _, _, _) => {
                        h833
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h834, _, _) => {
                        h834
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h835, _) => {
                        h835
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h836) => {
                        h836
                    }
                }), f59(match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h837, _, _, _, _, _, _, _, _) => {
                        h837
                    }
                })))
            } else {
                Ok(Adt75::C0(v0, List::cons(Adt67::C6(v12), List::<Adt67>::nil())))
            }
        }
        Adt72::C14(v13) => {
            Ok(f47(v0, v13))
        }
        Adt72::C15(v14, v15) => {
            f60(v0, v14, v15)
        }
        Adt72::C16(v16, v17) => {
            Ok(f61(v0, v16, v17))
        }
        Adt72::C17(v18, v19) => {
            if f58(v0.clone(), v18.clone()) {
                Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h838, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h838
                    }
                }, f62(match v0.clone() {
                    Adt1::C0(_, h839, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h839
                    }
                }), f63(match v0.clone() {
                    Adt1::C0(_, _, h840, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h840
                    }
                }, Adt7::C3), match v0.clone() {
                    Adt1::C0(_, _, _, h841, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h841
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h842, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h842
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h843, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h843
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h844, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h844
                    }
                }, None::<Adt11>, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h845, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h845
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h846, _, _, _, _, _, _, _, _, _, _, _) => {
                        h846
                    }
                }, None::<Adt41>, Some(v19), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h847, _, _, _, _, _, _, _, _) => {
                        h847
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h848, _, _, _, _, _, _, _) => {
                        h848
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h849, _, _, _, _, _, _) => {
                        h849
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h850, _, _, _, _, _) => {
                        h850
                    }
                }, Adt49::C1, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h851, _, _, _) => {
                        h851
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h852, _, _) => {
                        h852
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h853, _) => {
                        h853
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h854) => {
                        h854
                    }
                }), List::cons(Adt67::C4(v18.clone()), List::cons(Adt67::C5(v18), List::<Adt67>::nil()))))
            } else {
                Ok(Adt75::C0(v0, List::<Adt67>::nil()))
            }
        }
        Adt72::C18 => {
            Ok(f64(v0))
        }
        Adt72::C19(v20, v21) => {
            Ok(f65(v0, v20, v21))
        }
        Adt72::C20 => {
            Ok(f64(v0))
        }
        Adt72::C21(v22, v23) => {
            f66(v0, v22, v23)
        }
        Adt72::C22(v24, v25) => {
            f67(v0, v24, v25)
        }
        Adt72::C23(v26, v27) => {
            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h855, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h855
                }
            }, match v0.clone() {
                Adt1::C0(_, h856, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h856
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h857, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h857
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h858, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h858
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h859, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h859
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h860, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h860
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h861, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h861
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h862, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h862
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h863, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h863
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h864, _, _, _, _, _, _, _, _, _, _, _) => {
                    h864
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h865, _, _, _, _, _, _, _, _, _, _) => {
                    h865
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h866, _, _, _, _, _, _, _, _, _) => {
                    h866
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h867, _, _, _, _, _, _, _, _) => {
                    h867
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h868, _, _, _, _, _, _, _) => {
                    h868
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h869, _, _, _, _, _, _) => {
                    h869
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h870, _, _, _, _, _) => {
                    h870
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h871, _, _, _, _) => {
                    h871
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h872, _, _, _) => {
                    h872
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h873, _, _) => {
                    h873
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h874, _) => {
                    h874
                }
            }, f68(match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h875) => {
                    h875
                }
            }, v26, v27)?), List::<Adt67>::nil()))
        }
        Adt72::C24(v28) => {
            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h876, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h876
                }
            }, match v0.clone() {
                Adt1::C0(_, h877, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h877
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h878, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h878
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h879, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h879
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h880, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h880
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h881, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h881
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h882, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h882
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h883, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h883
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h884, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h884
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h885, _, _, _, _, _, _, _, _, _, _, _) => {
                    h885
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h886, _, _, _, _, _, _, _, _, _, _) => {
                    h886
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h887, _, _, _, _, _, _, _, _, _) => {
                    h887
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h888, _, _, _, _, _, _, _, _) => {
                    h888
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h889, _, _, _, _, _, _, _) => {
                    h889
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h890, _, _, _, _, _, _) => {
                    h890
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h891, _, _, _, _, _) => {
                    h891
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h892, _, _, _, _) => {
                    h892
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h893, _, _, _) => {
                    h893
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h894, _, _) => {
                    h894
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h895, _) => {
                    h895
                }
            }, f69(match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h896) => {
                    h896
                }
            }, v28)?), List::<Adt67>::nil()))
        }
    }
}

pub fn f40(v0: Adt2) -> R<Adt2> {
    Ok(Adt2::C0(match v0.clone() {
        Adt2::C0(h897, _, _, _, _, _) => {
            h897
        }
    }, {
        let a899 = match v0 {
            Adt2::C0(_, h898, _, _, _, _) => {
                h898
            }
        };
        let a900 = 1u64;
        nat_add(a899, a900)?
    }, true, false, Adt3::C1, Adt4::C0))
}

pub fn f41() -> Adt5 {
    Adt5::C0(Adt6::C0, false, 0u64, false, Adt7::C0)
}

pub fn f42() -> Adt8 {
    Adt8::C0(0u64, false, false, 0u64)
}

pub fn f43() -> Adt50 {
    Adt50::C0(f70(), None::<Adt45>)
}

pub fn f44(v0: Adt1) -> List<Adt51> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h901, _, _, _) => {
            h901
        }
    } {
        List::cons(Adt51::C0(f32(v0.clone()), {
            let m903 = match v0.clone() {
                Adt1::C0(_, _, _, _, h902, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h902
                }
            };
            match m903 {
                None => {
                    f71()
                }
                Some(v1) => {
                    let m907 = {
                        let m906 = f72(v1);
                        match m906 {
                            Adt12::C0(h905, _) => {
                                h905
                            }
                        }
                    };
                    match m907 {
                        Adt13::C0(_, _, _, _, _, _, h904) => {
                            h904
                        }
                    }
                }
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h908, _, _) => {
                h908
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h909, _) => {
                h909
            }
        }), match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h910) => {
                h910
            }
        })
    } else {
        match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h911) => {
                h911
            }
        }
    }
}

pub fn f45(v0: Adt1) -> List<Adt67> {
    f36(if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, h912, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h912
        }
    } {
        List::cons(Adt67::C9(f32(v0.clone())), List::<Adt67>::nil())
    } else {
        List::<Adt67>::nil()
    }, f36(if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h913, _, _, _) => {
            h913
        }
    } {
        let m916 = match v0.clone() {
            Adt1::C0(_, h915, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h915
            }
        };
        if match m916 {
            Adt2::C0(_, _, h914, _, _, _) => {
                h914
            }
        } {
            List::cons(Adt67::C4(f32(v0.clone())), List::cons(Adt67::C5(f32(v0.clone())), List::<Adt67>::nil()))
        } else {
            List::cons(Adt67::C5(f32(v0.clone())), List::<Adt67>::nil())
        }
    } else {
        List::<Adt67>::nil()
    }, f36(f59(match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, h917, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h917
        }
    }), f59(match v0 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h918, _, _, _, _, _, _, _, _) => {
            h918
        }
    }))))
}

pub fn f46(v0: Adt0) -> R<Adt65> {
    let m920 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h919) => {
            h919
        }
    };
    match m920 {
        None => {
            let m923 = match v0.clone() {
                Adt0::C0(h922, _, _, _, _, _, _) => {
                    h922
                }
            };
            if match m923 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h921, _, _, _, _, _, _) => {
                    h921
                }
            } {
                Ok(f18(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h924, _, _, _, _, _) => {
                        h924
                    }
                }, f55(match v0 {
                    Adt0::C0(h925, _, _, _, _, _, _) => {
                        h925
                    }
                })?))
            } else {
                Ok(Adt65::C0(Adt0::C0({
                    let m928 = f55(match v0.clone() {
                        Adt0::C0(h927, _, _, _, _, _, _) => {
                            h927
                        }
                    })?;
                    match m928 {
                        Adt75::C0(h926, _) => {
                            h926
                        }
                    }
                }, Adt53::C0({
                    let m931 = match v0.clone() {
                        Adt0::C0(_, h930, _, _, _, _, _) => {
                            h930
                        }
                    };
                    match m931 {
                        Adt53::C0(h929, _, _, _, _, _, _, _) => {
                            h929
                        }
                    }
                }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                    let m934 = match v0.clone() {
                        Adt0::C0(_, h933, _, _, _, _, _) => {
                            h933
                        }
                    };
                    match m934 {
                        Adt53::C0(_, _, _, _, _, _, _, h932) => {
                            h932
                        }
                    }
                }), match v0.clone() {
                    Adt0::C0(_, _, h935, _, _, _, _) => {
                        h935
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, h936, _, _, _) => {
                        h936
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, h937, _, _) => {
                        h937
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h938, _) => {
                        h938
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h939) => {
                        h939
                    }
                }), f35(f36(f73(match v0.clone() {
                    Adt0::C0(_, h940, _, _, _, _, _) => {
                        h940
                    }
                }), {
                    let m943 = f55(match v0 {
                        Adt0::C0(h942, _, _, _, _, _, _) => {
                            h942
                        }
                    })?;
                    match m943 {
                        Adt75::C0(_, h941) => {
                            h941
                        }
                    }
                }))))
            }
        }
        Some(v1) => {
            Ok(Adt65::C0(Adt0::C0({
                let m970 = {
                    let m969 = {
                        let m948 = match v0.clone() {
                            Adt0::C0(h947, _, _, _, _, _, _) => {
                                h947
                            }
                        };
                        if match m948 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h946, _, _, _, _, _, _) => {
                                h946
                            }
                        } {
                            f18(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h949, _, _, _, _, _) => {
                                    h949
                                }
                            }, f55(match v0.clone() {
                                Adt0::C0(h950, _, _, _, _, _, _) => {
                                    h950
                                }
                            })?)
                        } else {
                            Adt65::C0(Adt0::C0({
                                let m953 = f55(match v0.clone() {
                                    Adt0::C0(h952, _, _, _, _, _, _) => {
                                        h952
                                    }
                                })?;
                                match m953 {
                                    Adt75::C0(h951, _) => {
                                        h951
                                    }
                                }
                            }, Adt53::C0({
                                let m956 = match v0.clone() {
                                    Adt0::C0(_, h955, _, _, _, _, _) => {
                                        h955
                                    }
                                };
                                match m956 {
                                    Adt53::C0(h954, _, _, _, _, _, _, _) => {
                                        h954
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m959 = match v0.clone() {
                                    Adt0::C0(_, h958, _, _, _, _, _) => {
                                        h958
                                    }
                                };
                                match m959 {
                                    Adt53::C0(_, _, _, _, _, _, _, h957) => {
                                        h957
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h960, _, _, _, _) => {
                                    h960
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h961, _, _, _) => {
                                    h961
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h962, _, _) => {
                                    h962
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h963, _) => {
                                    h963
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h964) => {
                                    h964
                                }
                            }), f35(f36(f73(match v0.clone() {
                                Adt0::C0(_, h965, _, _, _, _, _) => {
                                    h965
                                }
                            }), {
                                let m968 = f55(match v0.clone() {
                                    Adt0::C0(h967, _, _, _, _, _, _) => {
                                        h967
                                    }
                                })?;
                                match m968 {
                                    Adt75::C0(_, h966) => {
                                        h966
                                    }
                                }
                            })))
                        }
                    };
                    match m969 {
                        Adt65::C0(h945, _) => {
                            h945
                        }
                    }
                };
                match m970 {
                    Adt0::C0(h944, _, _, _, _, _, _) => {
                        h944
                    }
                }
            }, {
                let m997 = {
                    let m996 = {
                        let m975 = match v0.clone() {
                            Adt0::C0(h974, _, _, _, _, _, _) => {
                                h974
                            }
                        };
                        if match m975 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h973, _, _, _, _, _, _) => {
                                h973
                            }
                        } {
                            f18(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h976, _, _, _, _, _) => {
                                    h976
                                }
                            }, f55(match v0.clone() {
                                Adt0::C0(h977, _, _, _, _, _, _) => {
                                    h977
                                }
                            })?)
                        } else {
                            Adt65::C0(Adt0::C0({
                                let m980 = f55(match v0.clone() {
                                    Adt0::C0(h979, _, _, _, _, _, _) => {
                                        h979
                                    }
                                })?;
                                match m980 {
                                    Adt75::C0(h978, _) => {
                                        h978
                                    }
                                }
                            }, Adt53::C0({
                                let m983 = match v0.clone() {
                                    Adt0::C0(_, h982, _, _, _, _, _) => {
                                        h982
                                    }
                                };
                                match m983 {
                                    Adt53::C0(h981, _, _, _, _, _, _, _) => {
                                        h981
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m986 = match v0.clone() {
                                    Adt0::C0(_, h985, _, _, _, _, _) => {
                                        h985
                                    }
                                };
                                match m986 {
                                    Adt53::C0(_, _, _, _, _, _, _, h984) => {
                                        h984
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h987, _, _, _, _) => {
                                    h987
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h988, _, _, _) => {
                                    h988
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h989, _, _) => {
                                    h989
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h990, _) => {
                                    h990
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h991) => {
                                    h991
                                }
                            }), f35(f36(f73(match v0.clone() {
                                Adt0::C0(_, h992, _, _, _, _, _) => {
                                    h992
                                }
                            }), {
                                let m995 = f55(match v0.clone() {
                                    Adt0::C0(h994, _, _, _, _, _, _) => {
                                        h994
                                    }
                                })?;
                                match m995 {
                                    Adt75::C0(_, h993) => {
                                        h993
                                    }
                                }
                            })))
                        }
                    };
                    match m996 {
                        Adt65::C0(h972, _) => {
                            h972
                        }
                    }
                };
                match m997 {
                    Adt0::C0(_, h971, _, _, _, _, _) => {
                        h971
                    }
                }
            }, {
                let m1024 = {
                    let m1023 = {
                        let m1002 = match v0.clone() {
                            Adt0::C0(h1001, _, _, _, _, _, _) => {
                                h1001
                            }
                        };
                        if match m1002 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1000, _, _, _, _, _, _) => {
                                h1000
                            }
                        } {
                            f18(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1003, _, _, _, _, _) => {
                                    h1003
                                }
                            }, f55(match v0.clone() {
                                Adt0::C0(h1004, _, _, _, _, _, _) => {
                                    h1004
                                }
                            })?)
                        } else {
                            Adt65::C0(Adt0::C0({
                                let m1007 = f55(match v0.clone() {
                                    Adt0::C0(h1006, _, _, _, _, _, _) => {
                                        h1006
                                    }
                                })?;
                                match m1007 {
                                    Adt75::C0(h1005, _) => {
                                        h1005
                                    }
                                }
                            }, Adt53::C0({
                                let m1010 = match v0.clone() {
                                    Adt0::C0(_, h1009, _, _, _, _, _) => {
                                        h1009
                                    }
                                };
                                match m1010 {
                                    Adt53::C0(h1008, _, _, _, _, _, _, _) => {
                                        h1008
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1013 = match v0.clone() {
                                    Adt0::C0(_, h1012, _, _, _, _, _) => {
                                        h1012
                                    }
                                };
                                match m1013 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1011) => {
                                        h1011
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1014, _, _, _, _) => {
                                    h1014
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1015, _, _, _) => {
                                    h1015
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1016, _, _) => {
                                    h1016
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1017, _) => {
                                    h1017
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1018) => {
                                    h1018
                                }
                            }), f35(f36(f73(match v0.clone() {
                                Adt0::C0(_, h1019, _, _, _, _, _) => {
                                    h1019
                                }
                            }), {
                                let m1022 = f55(match v0.clone() {
                                    Adt0::C0(h1021, _, _, _, _, _, _) => {
                                        h1021
                                    }
                                })?;
                                match m1022 {
                                    Adt75::C0(_, h1020) => {
                                        h1020
                                    }
                                }
                            })))
                        }
                    };
                    match m1023 {
                        Adt65::C0(h999, _) => {
                            h999
                        }
                    }
                };
                match m1024 {
                    Adt0::C0(_, _, h998, _, _, _, _) => {
                        h998
                    }
                }
            }, {
                let m1051 = {
                    let m1050 = {
                        let m1029 = match v0.clone() {
                            Adt0::C0(h1028, _, _, _, _, _, _) => {
                                h1028
                            }
                        };
                        if match m1029 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1027, _, _, _, _, _, _) => {
                                h1027
                            }
                        } {
                            f18(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1030, _, _, _, _, _) => {
                                    h1030
                                }
                            }, f55(match v0.clone() {
                                Adt0::C0(h1031, _, _, _, _, _, _) => {
                                    h1031
                                }
                            })?)
                        } else {
                            Adt65::C0(Adt0::C0({
                                let m1034 = f55(match v0.clone() {
                                    Adt0::C0(h1033, _, _, _, _, _, _) => {
                                        h1033
                                    }
                                })?;
                                match m1034 {
                                    Adt75::C0(h1032, _) => {
                                        h1032
                                    }
                                }
                            }, Adt53::C0({
                                let m1037 = match v0.clone() {
                                    Adt0::C0(_, h1036, _, _, _, _, _) => {
                                        h1036
                                    }
                                };
                                match m1037 {
                                    Adt53::C0(h1035, _, _, _, _, _, _, _) => {
                                        h1035
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1040 = match v0.clone() {
                                    Adt0::C0(_, h1039, _, _, _, _, _) => {
                                        h1039
                                    }
                                };
                                match m1040 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1038) => {
                                        h1038
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1041, _, _, _, _) => {
                                    h1041
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1042, _, _, _) => {
                                    h1042
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1043, _, _) => {
                                    h1043
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1044, _) => {
                                    h1044
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1045) => {
                                    h1045
                                }
                            }), f35(f36(f73(match v0.clone() {
                                Adt0::C0(_, h1046, _, _, _, _, _) => {
                                    h1046
                                }
                            }), {
                                let m1049 = f55(match v0.clone() {
                                    Adt0::C0(h1048, _, _, _, _, _, _) => {
                                        h1048
                                    }
                                })?;
                                match m1049 {
                                    Adt75::C0(_, h1047) => {
                                        h1047
                                    }
                                }
                            })))
                        }
                    };
                    match m1050 {
                        Adt65::C0(h1026, _) => {
                            h1026
                        }
                    }
                };
                match m1051 {
                    Adt0::C0(_, _, _, h1025, _, _, _) => {
                        h1025
                    }
                }
            }, {
                let m1078 = {
                    let m1077 = {
                        let m1056 = match v0.clone() {
                            Adt0::C0(h1055, _, _, _, _, _, _) => {
                                h1055
                            }
                        };
                        if match m1056 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1054, _, _, _, _, _, _) => {
                                h1054
                            }
                        } {
                            f18(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1057, _, _, _, _, _) => {
                                    h1057
                                }
                            }, f55(match v0.clone() {
                                Adt0::C0(h1058, _, _, _, _, _, _) => {
                                    h1058
                                }
                            })?)
                        } else {
                            Adt65::C0(Adt0::C0({
                                let m1061 = f55(match v0.clone() {
                                    Adt0::C0(h1060, _, _, _, _, _, _) => {
                                        h1060
                                    }
                                })?;
                                match m1061 {
                                    Adt75::C0(h1059, _) => {
                                        h1059
                                    }
                                }
                            }, Adt53::C0({
                                let m1064 = match v0.clone() {
                                    Adt0::C0(_, h1063, _, _, _, _, _) => {
                                        h1063
                                    }
                                };
                                match m1064 {
                                    Adt53::C0(h1062, _, _, _, _, _, _, _) => {
                                        h1062
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1067 = match v0.clone() {
                                    Adt0::C0(_, h1066, _, _, _, _, _) => {
                                        h1066
                                    }
                                };
                                match m1067 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1065) => {
                                        h1065
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1068, _, _, _, _) => {
                                    h1068
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1069, _, _, _) => {
                                    h1069
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1070, _, _) => {
                                    h1070
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1071, _) => {
                                    h1071
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1072) => {
                                    h1072
                                }
                            }), f35(f36(f73(match v0.clone() {
                                Adt0::C0(_, h1073, _, _, _, _, _) => {
                                    h1073
                                }
                            }), {
                                let m1076 = f55(match v0.clone() {
                                    Adt0::C0(h1075, _, _, _, _, _, _) => {
                                        h1075
                                    }
                                })?;
                                match m1076 {
                                    Adt75::C0(_, h1074) => {
                                        h1074
                                    }
                                }
                            })))
                        }
                    };
                    match m1077 {
                        Adt65::C0(h1053, _) => {
                            h1053
                        }
                    }
                };
                match m1078 {
                    Adt0::C0(_, _, _, _, h1052, _, _) => {
                        h1052
                    }
                }
            }, {
                let m1105 = {
                    let m1104 = {
                        let m1083 = match v0.clone() {
                            Adt0::C0(h1082, _, _, _, _, _, _) => {
                                h1082
                            }
                        };
                        if match m1083 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1081, _, _, _, _, _, _) => {
                                h1081
                            }
                        } {
                            f18(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1084, _, _, _, _, _) => {
                                    h1084
                                }
                            }, f55(match v0.clone() {
                                Adt0::C0(h1085, _, _, _, _, _, _) => {
                                    h1085
                                }
                            })?)
                        } else {
                            Adt65::C0(Adt0::C0({
                                let m1088 = f55(match v0.clone() {
                                    Adt0::C0(h1087, _, _, _, _, _, _) => {
                                        h1087
                                    }
                                })?;
                                match m1088 {
                                    Adt75::C0(h1086, _) => {
                                        h1086
                                    }
                                }
                            }, Adt53::C0({
                                let m1091 = match v0.clone() {
                                    Adt0::C0(_, h1090, _, _, _, _, _) => {
                                        h1090
                                    }
                                };
                                match m1091 {
                                    Adt53::C0(h1089, _, _, _, _, _, _, _) => {
                                        h1089
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1094 = match v0.clone() {
                                    Adt0::C0(_, h1093, _, _, _, _, _) => {
                                        h1093
                                    }
                                };
                                match m1094 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1092) => {
                                        h1092
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1095, _, _, _, _) => {
                                    h1095
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1096, _, _, _) => {
                                    h1096
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1097, _, _) => {
                                    h1097
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1098, _) => {
                                    h1098
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1099) => {
                                    h1099
                                }
                            }), f35(f36(f73(match v0.clone() {
                                Adt0::C0(_, h1100, _, _, _, _, _) => {
                                    h1100
                                }
                            }), {
                                let m1103 = f55(match v0.clone() {
                                    Adt0::C0(h1102, _, _, _, _, _, _) => {
                                        h1102
                                    }
                                })?;
                                match m1103 {
                                    Adt75::C0(_, h1101) => {
                                        h1101
                                    }
                                }
                            })))
                        }
                    };
                    match m1104 {
                        Adt65::C0(h1080, _) => {
                            h1080
                        }
                    }
                };
                match m1105 {
                    Adt0::C0(_, _, _, _, _, h1079, _) => {
                        h1079
                    }
                }
            }, None::<Adt60>), List::cons(Adt66::C3(v1.clone()), List::cons(Adt66::C0(Adt67::C6(match v1 {
                Adt60::C0(_, _, _, h1106, _, _) => {
                    h1106
                }
            })), {
                let m1131 = {
                    let m1110 = match v0.clone() {
                        Adt0::C0(h1109, _, _, _, _, _, _) => {
                            h1109
                        }
                    };
                    if match m1110 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1108, _, _, _, _, _, _) => {
                            h1108
                        }
                    } {
                        f18(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h1111, _, _, _, _, _) => {
                                h1111
                            }
                        }, f55(match v0 {
                            Adt0::C0(h1112, _, _, _, _, _, _) => {
                                h1112
                            }
                        })?)
                    } else {
                        Adt65::C0(Adt0::C0({
                            let m1115 = f55(match v0.clone() {
                                Adt0::C0(h1114, _, _, _, _, _, _) => {
                                    h1114
                                }
                            })?;
                            match m1115 {
                                Adt75::C0(h1113, _) => {
                                    h1113
                                }
                            }
                        }, Adt53::C0({
                            let m1118 = match v0.clone() {
                                Adt0::C0(_, h1117, _, _, _, _, _) => {
                                    h1117
                                }
                            };
                            match m1118 {
                                Adt53::C0(h1116, _, _, _, _, _, _, _) => {
                                    h1116
                                }
                            }
                        }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                            let m1121 = match v0.clone() {
                                Adt0::C0(_, h1120, _, _, _, _, _) => {
                                    h1120
                                }
                            };
                            match m1121 {
                                Adt53::C0(_, _, _, _, _, _, _, h1119) => {
                                    h1119
                                }
                            }
                        }), match v0.clone() {
                            Adt0::C0(_, _, h1122, _, _, _, _) => {
                                h1122
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h1123, _, _, _) => {
                                h1123
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h1124, _, _) => {
                                h1124
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h1125, _) => {
                                h1125
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1126) => {
                                h1126
                            }
                        }), f35(f36(f73(match v0.clone() {
                            Adt0::C0(_, h1127, _, _, _, _, _) => {
                                h1127
                            }
                        }), {
                            let m1130 = f55(match v0 {
                                Adt0::C0(h1129, _, _, _, _, _, _) => {
                                    h1129
                                }
                            })?;
                            match m1130 {
                                Adt75::C0(_, h1128) => {
                                    h1128
                                }
                            }
                        })))
                    }
                };
                match m1131 {
                    Adt65::C0(_, h1107) => {
                        h1107
                    }
                }
            }))))
        }
    }
}

pub fn f47(v0: Adt1, v1: u64) -> Adt75 {
    let a1132 = v1;
    let a1133 = 0u64;
    if nat_eq(a1132, a1133) {
        Adt75::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1134, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1134
            }
        }, match v0.clone() {
            Adt1::C0(_, h1135, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1135
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1136, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1136
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1137, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1137
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1138, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1138
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1139, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1139
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1140, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1140
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1141, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1141
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1142, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1142
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1143, _, _, _, _, _, _, _, _, _, _, _) => {
                h1143
            }
        }, Some(Adt41::C10(Adt43::C12)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1144, _, _, _, _, _, _, _, _, _) => {
                h1144
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1145, _, _, _, _, _, _, _, _) => {
                h1145
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1146, _, _, _, _, _, _, _) => {
                h1146
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1147, _, _, _, _, _, _) => {
                h1147
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1148, _, _, _, _, _) => {
                h1148
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1149, _, _, _, _) => {
                h1149
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1150, _, _, _) => {
                h1150
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1151, _, _) => {
                h1151
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1152, _) => {
                h1152
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1153) => {
                h1153
            }
        }), List::<Adt67>::nil())
    } else {
        let m1156 = match v0.clone() {
            Adt1::C0(_, h1155, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1155
            }
        };
        if match m1156 {
            Adt2::C0(_, _, h1154, _, _, _) => {
                h1154
            }
        } {
            Adt75::C0(v0.clone(), List::cons(Adt67::C3(f32(v0), v1), List::<Adt67>::nil()))
        } else {
            Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1157, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1157
                }
            }, match v0.clone() {
                Adt1::C0(_, h1158, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1158
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1159, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1159
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1160, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1160
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1161, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1161
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1162, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1162
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1163, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1163
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1164, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1164
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1165, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1165
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1166, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1166
                }
            }, Some(Adt41::C10(Adt43::C3)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1167, _, _, _, _, _, _, _, _, _) => {
                    h1167
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1168, _, _, _, _, _, _, _, _) => {
                    h1168
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1169, _, _, _, _, _, _, _) => {
                    h1169
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1170, _, _, _, _, _, _) => {
                    h1170
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1171, _, _, _, _, _) => {
                    h1171
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1172, _, _, _, _) => {
                    h1172
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1173, _, _, _) => {
                    h1173
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1174, _, _) => {
                    h1174
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1175, _) => {
                    h1175
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1176) => {
                    h1176
                }
            }), List::<Adt67>::nil())
        }
    }
}

pub fn f48(v0: Adt1, v1: Adt17) -> R<Adt75> {
    f20(v0, Adt9::C4(v1))
}

pub fn f49(p1182: List<Adt59>, v1: u64) -> Option<Adt59> {
    let m1181 = p1182;
    {
        let mut m1181 = m1181;
        loop {
            let step = {
                let v0 = m1181;
                let m1177 = v0;
                match m1177.uncons() {
                    None => {
                        Err::<List<Adt59>, Option<Adt59>>(None::<Adt59>)
                    }
                    Some((v2, v3)) => {
                        let a1179 = match v2.clone() {
                            Adt59::C0(h1178, _, _) => {
                                h1178
                            }
                        };
                        let a1180 = v1;
                        if nat_eq(a1179, a1180) {
                            Err::<List<Adt59>, Option<Adt59>>(Some(v2))
                        } else {
                            Ok::<List<Adt59>, Option<Adt59>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m1181 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f50(v0: List<Adt59>, v1: u64, v2: Adt59) -> List<Adt59> {
    let m1183 = v0;
    match m1183.uncons() {
        None => {
            List::cons(v2, List::<Adt59>::nil())
        }
        Some((v3, v4)) => {
            let a1184 = v1;
            let a1185 = 0u64;
            if nat_eq(a1184, a1185) {
                List::cons(v2, List::cons(v3, v4))
            } else {
                List::cons(v3, f50(v4, {
                    let a1186 = v1;
                    let a1187 = 1u64;
                    nat_sub(a1186, a1187)
                }, v2))
            }
        }
    }
}

pub fn f51(p1196: List<Adt59>, p1197: List<Adt59>) -> bool {
    let m1195 = (p1196, p1197);
    {
        let mut m1195 = m1195;
        loop {
            let step = {
                let (v0, v1) = m1195;
                let m1188 = v0;
                match m1188.uncons() {
                    None => {
                        let m1189 = v1;
                        match m1189.uncons() {
                            None => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(true)
                            }
                            Some((_, _)) => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(false)
                            }
                        }
                    }
                    Some((v4, v5)) => {
                        let m1190 = v1;
                        match m1190.uncons() {
                            None => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(false)
                            }
                            Some((v6, v7)) => {
                                let a1193 = match v4 {
                                    Adt59::C0(h1191, _, _) => {
                                        h1191
                                    }
                                };
                                let a1194 = match v6 {
                                    Adt59::C0(h1192, _, _) => {
                                        h1192
                                    }
                                };
                                if nat_eq(a1193, a1194) {
                                    Ok::<(List<Adt59>, List<Adt59>), bool>((v5, v7))
                                } else {
                                    Err::<(List<Adt59>, List<Adt59>), bool>(false)
                                }
                            }
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m1195 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f52(v0: Adt11, v1: Adt11) -> bool {
    let a1200 = match v0.clone() {
        Adt11::C0(h1198, _, _) => {
            h1198
        }
    };
    let a1201 = match v1.clone() {
        Adt11::C0(h1199, _, _) => {
            h1199
        }
    };
    if nat_eq(a1200, a1201) {
        let a1204 = match v0.clone() {
            Adt11::C0(_, h1202, _) => {
                h1202
            }
        };
        let a1205 = match v1.clone() {
            Adt11::C0(_, h1203, _) => {
                h1203
            }
        };
        if nat_eq(a1204, a1205) {
            let a1208 = match v0 {
                Adt11::C0(_, _, h1206) => {
                    h1206
                }
            };
            let a1209 = match v1 {
                Adt11::C0(_, _, h1207) => {
                    h1207
                }
            };
            nat_eq(a1208, a1209)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f53(v0: Adt1, v1: bool, v2: bool, v3: Adt48) -> R<Adt75> {
    Ok(Adt75::C0(Adt1::C0(match v0.clone() {
        Adt1::C0(h1210, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1210
        }
    }, f74(match v0.clone() {
        Adt1::C0(_, h1211, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1211
        }
    })?, f41(), f42(), None::<Adt9>, None::<Adt22>, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h1212, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1212
        }
    }, None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, v1, v2, v3, Adt49::C1, false, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1213, _, _) => {
            h1213
        }
    }, None::<Adt23>, f44(v0.clone())), f45(v0)))
}

pub fn f54(v0: Adt1) -> R<Adt75> {
    let m1216 = match v0.clone() {
        Adt1::C0(_, h1215, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1215
        }
    };
    if match m1216 {
        Adt2::C0(_, _, h1214, _, _, _) => {
            h1214
        }
    } {
        Ok(Adt75::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1217, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1217
            }
        }, f62(match v0.clone() {
            Adt1::C0(_, h1218, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1218
            }
        }), f63(match v0.clone() {
            Adt1::C0(_, _, h1219, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1219
            }
        }, Adt7::C2), match v0.clone() {
            Adt1::C0(_, _, _, h1220, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1220
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1221, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1221
            }
        }, None::<Adt22>, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1222, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1222
            }
        }, None::<Adt11>, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1223, _, _, _, _, _, _, _, _, _, _, _) => {
                h1223
            }
        }, Some(Adt41::C7), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1224, _, _, _, _, _, _, _, _, _) => {
                h1224
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1225, _, _, _, _, _, _, _, _) => {
                h1225
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1226, _, _, _, _, _, _, _) => {
                h1226
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1227, _, _, _, _, _, _) => {
                h1227
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1228, _, _, _, _, _) => {
                h1228
            }
        }, Adt49::C1, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1229, _, _) => {
                h1229
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1230, _) => {
                h1230
            }
        }, f44(v0.clone())), List::cons(Adt67::C4(f32(v0.clone())), List::cons(Adt67::C5(f32(v0)), List::<Adt67>::nil()))))
    } else {
        if match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1231, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1231
            }
        } {
            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1232, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1232
                }
            }, f74(match v0.clone() {
                Adt1::C0(_, h1233, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1233
                }
            })?, f63(match v0.clone() {
                Adt1::C0(_, _, h1234, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1234
                }
            }, Adt7::C3), match v0.clone() {
                Adt1::C0(_, _, _, h1235, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1235
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1236, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1236
                }
            }, None::<Adt22>, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1237, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1237
                }
            }, None::<Adt11>, false, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1238, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1238
                }
            }, Some(Adt41::C7), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1239, _, _, _, _, _, _, _, _, _) => {
                    h1239
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1240, _, _, _, _, _, _, _, _) => {
                    h1240
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1241, _, _, _, _, _, _, _) => {
                    h1241
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1242, _, _, _, _, _, _) => {
                    h1242
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1243, _, _, _, _, _) => {
                    h1243
                }
            }, Adt49::C1, false, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1244, _, _) => {
                    h1244
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1245, _) => {
                    h1245
                }
            }, f44(v0.clone())), f45(v0)))
        } else {
            Ok(Adt75::C0(v0, List::<Adt67>::nil()))
        }
    }
}

pub fn f55(v0: Adt1) -> R<Adt75> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1246, _, _, _, _, _, _) => {
            h1246
        }
    } {
        Ok(Adt75::C0(v0, List::<Adt67>::nil()))
    } else {
        Ok(Adt75::C0({
            let m1249 = f53(v0.clone(), false, true, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1248, _, _, _, _, _) => {
                    h1248
                }
            })?;
            match m1249 {
                Adt75::C0(h1247, _) => {
                    h1247
                }
            }
        }, f36(f45(v0.clone()), List::cons(Adt67::C8(match v0 {
            Adt1::C0(h1250, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1250
            }
        }), List::<Adt67>::nil()))))
    }
}

pub fn f56(v0: Adt1, v1: Adt52) -> Adt75 {
    if f58(v0.clone(), v1) {
        let m1252 = f75(match v0.clone() {
            Adt1::C0(_, _, h1251, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1251
            }
        });
        match m1252 {
            Ok(v3) => {
                Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1273, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1273
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1274, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1274
                    }
                }, v3, match v0.clone() {
                    Adt1::C0(_, _, _, h1275, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1275
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1276, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1276
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1277, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1277
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1278, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1278
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1279, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1279
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1280, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1280
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1281, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1281
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1282, _, _, _, _, _, _, _, _, _, _) => {
                        h1282
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1283, _, _, _, _, _, _, _, _, _) => {
                        h1283
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1284, _, _, _, _, _, _, _, _) => {
                        h1284
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1285, _, _, _, _, _, _, _) => {
                        h1285
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1286, _, _, _, _, _, _) => {
                        h1286
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1287, _, _, _, _, _) => {
                        h1287
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1288, _, _, _, _) => {
                        h1288
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1289, _, _, _) => {
                        h1289
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1290, _, _) => {
                        h1290
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1291, _) => {
                        h1291
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1292) => {
                        h1292
                    }
                }), List::<Adt67>::nil())
            }
            Err(v2) => {
                Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1253, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1253
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1254, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1254
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1255, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1255
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1256, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1256
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1257, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1257
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1258, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1258
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1259, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1259
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1260, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1260
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1261, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1261
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1262, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1262
                    }
                }, Some(Adt41::C11(v2)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1263, _, _, _, _, _, _, _, _, _) => {
                        h1263
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1264, _, _, _, _, _, _, _, _) => {
                        h1264
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1265, _, _, _, _, _, _, _) => {
                        h1265
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1266, _, _, _, _, _, _) => {
                        h1266
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1267, _, _, _, _, _) => {
                        h1267
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1268, _, _, _, _) => {
                        h1268
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1269, _, _, _) => {
                        h1269
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1270, _, _) => {
                        h1270
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1271, _) => {
                        h1271
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1272) => {
                        h1272
                    }
                }), List::<Adt67>::nil())
            }
        }
    } else {
        Adt75::C0(v0, List::<Adt67>::nil())
    }
}

pub fn f57(v0: Adt1, v1: Adt52, v2: Adt68) -> R<Adt75> {
    if f58(v0.clone(), v1.clone()) {
        if f76(v0.clone(), v2.clone()) {
            let m1294 = f77(match v0.clone() {
                Adt1::C0(_, _, h1293, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1293
                }
            }, f78(v2.clone()));
            match m1294 {
                Adt77::C0(_, v5) => {
                    let m1316 = f79(match v0.clone() {
                        Adt1::C0(_, _, _, h1315, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1315
                        }
                    }, v2.clone())?;
                    match m1316 {
                        Ok(v7) => {
                            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                                Adt1::C0(h1337, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1337
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, h1338, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1338
                                }
                            }, v5, v7, match v0.clone() {
                                Adt1::C0(_, _, _, _, h1339, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1339
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h1340, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1340
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h1341, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1341
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, h1342, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1342
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, h1343, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1343
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, h1344, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1344
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1345, _, _, _, _, _, _, _, _, _, _) => {
                                    h1345
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1346, _, _, _, _, _, _, _, _, _) => {
                                    h1346
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1347, _, _, _, _, _, _, _, _) => {
                                    h1347
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1348, _, _, _, _, _, _, _) => {
                                    h1348
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1349, _, _, _, _, _, _) => {
                                    h1349
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1350, _, _, _, _, _) => {
                                    h1350
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1351, _, _, _, _) => {
                                    h1351
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1352, _, _, _) => {
                                    h1352
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1353, _, _) => {
                                    h1353
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1354, _) => {
                                    h1354
                                }
                            }, match v0 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1355) => {
                                    h1355
                                }
                            }), List::cons(Adt67::C1(v1, v2), List::<Adt67>::nil())))
                        }
                        Err(_) => {
                            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                                Adt1::C0(h1317, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1317
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, h1318, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1318
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, h1319, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1319
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h1320, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1320
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h1321, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1321
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h1322, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1322
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h1323, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1323
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, h1324, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1324
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, h1325, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1325
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, h1326, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1326
                                }
                            }, Some(Adt41::C10(Adt43::C8)), match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1327, _, _, _, _, _, _, _, _, _) => {
                                    h1327
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1328, _, _, _, _, _, _, _, _) => {
                                    h1328
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1329, _, _, _, _, _, _, _) => {
                                    h1329
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1330, _, _, _, _, _, _) => {
                                    h1330
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1331, _, _, _, _, _) => {
                                    h1331
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1332, _, _, _, _) => {
                                    h1332
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1333, _, _, _) => {
                                    h1333
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1334, _, _) => {
                                    h1334
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1335, _) => {
                                    h1335
                                }
                            }, match v0 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1336) => {
                                    h1336
                                }
                            }), List::<Adt67>::nil()))
                        }
                    }
                }
                Adt77::C1(v3) => {
                    Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h1295, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1295
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, h1296, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1296
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, h1297, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1297
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h1298, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1298
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h1299, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1299
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h1300, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1300
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1301, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1301
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h1302, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1302
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, h1303, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1303
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, h1304, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1304
                        }
                    }, Some(Adt41::C11(v3)), match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1305, _, _, _, _, _, _, _, _, _) => {
                            h1305
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1306, _, _, _, _, _, _, _, _) => {
                            h1306
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1307, _, _, _, _, _, _, _) => {
                            h1307
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1308, _, _, _, _, _, _) => {
                            h1308
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1309, _, _, _, _, _) => {
                            h1309
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1310, _, _, _, _) => {
                            h1310
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1311, _, _, _) => {
                            h1311
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1312, _, _) => {
                            h1312
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1313, _) => {
                            h1313
                        }
                    }, match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1314) => {
                            h1314
                        }
                    }), List::<Adt67>::nil()))
                }
            }
        } else {
            Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1356, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1356
                }
            }, match v0.clone() {
                Adt1::C0(_, h1357, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1357
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1358, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1358
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1359, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1359
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1360, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1360
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1361, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1361
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1362, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1362
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1363, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1363
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1364, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1364
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1365, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1365
                }
            }, Some(Adt41::C10(Adt43::C11)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1366, _, _, _, _, _, _, _, _, _) => {
                    h1366
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1367, _, _, _, _, _, _, _, _) => {
                    h1367
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1368, _, _, _, _, _, _, _) => {
                    h1368
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1369, _, _, _, _, _, _) => {
                    h1369
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1370, _, _, _, _, _) => {
                    h1370
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1371, _, _, _, _) => {
                    h1371
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1372, _, _, _) => {
                    h1372
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1373, _, _) => {
                    h1373
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1374, _) => {
                    h1374
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1375) => {
                    h1375
                }
            }), List::<Adt67>::nil()))
        }
    } else {
        Ok(Adt75::C0(v0, List::<Adt67>::nil()))
    }
}

pub fn f58(v0: Adt1, v1: Adt52) -> bool {
    let a1378 = match v0.clone() {
        Adt1::C0(h1376, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1376
        }
    };
    let a1379 = match v1.clone() {
        Adt52::C0(h1377, _, _) => {
            h1377
        }
    };
    if nat_eq(a1378, a1379) {
        if match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1380, _, _, _, _, _, _, _) => {
                h1380
            }
        } {
            let a1382 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1381, _, _, _, _, _, _) => {
                    h1381
                }
            };
            if bool_not(a1382) {
                f80(match v0 {
                    Adt1::C0(_, h1383, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1383
                    }
                }, match v1.clone() {
                    Adt52::C0(_, h1384, _) => {
                        h1384
                    }
                }, match v1 {
                    Adt52::C0(_, _, h1385) => {
                        h1385
                    }
                })
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f59(v0: Option<Adt11>) -> List<Adt67> {
    let m1386 = v0;
    match m1386 {
        None => {
            List::<Adt67>::nil()
        }
        Some(v1) => {
            List::cons(Adt67::C6(v1), List::<Adt67>::nil())
        }
    }
}

pub fn f60(v0: Adt1, v1: Adt52, v2: Adt22) -> R<Adt75> {
    f81(v0.clone(), v1.clone(), v2, f58(v0, v1))
}

pub fn f61(v0: Adt1, v1: Adt52, v2: Adt73) -> Adt75 {
    if if f1(v0.clone(), v1.clone()) {
        match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1387, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1387
            }
        }
    } else {
        false
    } {
        Adt75::C0(Adt1::C0({
            let m1392 = {
                let m1391 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1390) => {
                        h1390
                    }
                });
                match m1391 {
                    Adt75::C0(h1389, _) => {
                        h1389
                    }
                }
            };
            match m1392 {
                Adt1::C0(h1388, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1388
                }
            }
        }, {
            let m1397 = {
                let m1396 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1395) => {
                        h1395
                    }
                });
                match m1396 {
                    Adt75::C0(h1394, _) => {
                        h1394
                    }
                }
            };
            match m1397 {
                Adt1::C0(_, h1393, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1393
                }
            }
        }, {
            let m1402 = {
                let m1401 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1400) => {
                        h1400
                    }
                });
                match m1401 {
                    Adt75::C0(h1399, _) => {
                        h1399
                    }
                }
            };
            match m1402 {
                Adt1::C0(_, _, h1398, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1398
                }
            }
        }, {
            let m1407 = {
                let m1406 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1405) => {
                        h1405
                    }
                });
                match m1406 {
                    Adt75::C0(h1404, _) => {
                        h1404
                    }
                }
            };
            match m1407 {
                Adt1::C0(_, _, _, h1403, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1403
                }
            }
        }, {
            let m1412 = {
                let m1411 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1410) => {
                        h1410
                    }
                });
                match m1411 {
                    Adt75::C0(h1409, _) => {
                        h1409
                    }
                }
            };
            match m1412 {
                Adt1::C0(_, _, _, _, h1408, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1408
                }
            }
        }, {
            let m1417 = {
                let m1416 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1415) => {
                        h1415
                    }
                });
                match m1416 {
                    Adt75::C0(h1414, _) => {
                        h1414
                    }
                }
            };
            match m1417 {
                Adt1::C0(_, _, _, _, _, h1413, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1413
                }
            }
        }, {
            let m1422 = {
                let m1421 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1420) => {
                        h1420
                    }
                });
                match m1421 {
                    Adt75::C0(h1419, _) => {
                        h1419
                    }
                }
            };
            match m1422 {
                Adt1::C0(_, _, _, _, _, _, h1418, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1418
                }
            }
        }, {
            let m1427 = {
                let m1426 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1425) => {
                        h1425
                    }
                });
                match m1426 {
                    Adt75::C0(h1424, _) => {
                        h1424
                    }
                }
            };
            match m1427 {
                Adt1::C0(_, _, _, _, _, _, _, h1423, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1423
                }
            }
        }, {
            let m1432 = {
                let m1431 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1430) => {
                        h1430
                    }
                });
                match m1431 {
                    Adt75::C0(h1429, _) => {
                        h1429
                    }
                }
            };
            match m1432 {
                Adt1::C0(_, _, _, _, _, _, _, _, h1428, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1428
                }
            }
        }, {
            let m1437 = {
                let m1436 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1435) => {
                        h1435
                    }
                });
                match m1436 {
                    Adt75::C0(h1434, _) => {
                        h1434
                    }
                }
            };
            match m1437 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1433, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1433
                }
            }
        }, Some(match v2.clone() {
            Adt73::C0(h1438, _, _) => {
                h1438
            }
        }), {
            let m1443 = {
                let m1442 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1441) => {
                        h1441
                    }
                });
                match m1442 {
                    Adt75::C0(h1440, _) => {
                        h1440
                    }
                }
            };
            match m1443 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1439, _, _, _, _, _, _, _, _, _) => {
                    h1439
                }
            }
        }, {
            let m1448 = {
                let m1447 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1446) => {
                        h1446
                    }
                });
                match m1447 {
                    Adt75::C0(h1445, _) => {
                        h1445
                    }
                }
            };
            match m1448 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1444, _, _, _, _, _, _, _, _) => {
                    h1444
                }
            }
        }, {
            let m1453 = {
                let m1452 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1451) => {
                        h1451
                    }
                });
                match m1452 {
                    Adt75::C0(h1450, _) => {
                        h1450
                    }
                }
            };
            match m1453 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1449, _, _, _, _, _, _, _) => {
                    h1449
                }
            }
        }, {
            let m1458 = {
                let m1457 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1456) => {
                        h1456
                    }
                });
                match m1457 {
                    Adt75::C0(h1455, _) => {
                        h1455
                    }
                }
            };
            match m1458 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1454, _, _, _, _, _, _) => {
                    h1454
                }
            }
        }, {
            let m1463 = {
                let m1462 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1461) => {
                        h1461
                    }
                });
                match m1462 {
                    Adt75::C0(h1460, _) => {
                        h1460
                    }
                }
            };
            match m1463 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1459, _, _, _, _, _) => {
                    h1459
                }
            }
        }, {
            let m1468 = {
                let m1467 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1466) => {
                        h1466
                    }
                });
                match m1467 {
                    Adt75::C0(h1465, _) => {
                        h1465
                    }
                }
            };
            match m1468 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1464, _, _, _, _) => {
                    h1464
                }
            }
        }, {
            let m1473 = {
                let m1472 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1471) => {
                        h1471
                    }
                });
                match m1472 {
                    Adt75::C0(h1470, _) => {
                        h1470
                    }
                }
            };
            match m1473 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1469, _, _, _) => {
                    h1469
                }
            }
        }, {
            let m1478 = {
                let m1477 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1476) => {
                        h1476
                    }
                });
                match m1477 {
                    Adt75::C0(h1475, _) => {
                        h1475
                    }
                }
            };
            match m1478 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1474, _, _) => {
                    h1474
                }
            }
        }, Some(match v2.clone() {
            Adt73::C0(_, h1479, _) => {
                h1479
            }
        }), {
            let m1484 = {
                let m1483 = f65(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1482) => {
                        h1482
                    }
                });
                match m1483 {
                    Adt75::C0(h1481, _) => {
                        h1481
                    }
                }
            };
            match m1484 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1480) => {
                    h1480
                }
            }
        }), {
            let m1487 = f65(v0, v1, match v2 {
                Adt73::C0(_, _, h1486) => {
                    h1486
                }
            });
            match m1487 {
                Adt75::C0(_, h1485) => {
                    h1485
                }
            }
        })
    } else {
        if f58(v0.clone(), v1.clone()) {
            Adt75::C0(Adt1::C0({
                let m1492 = {
                    let m1491 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1490, _, _) => {
                            h1490
                        }
                    });
                    match m1491 {
                        Adt75::C0(h1489, _) => {
                            h1489
                        }
                    }
                };
                match m1492 {
                    Adt1::C0(h1488, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1488
                    }
                }
            }, {
                let m1497 = {
                    let m1496 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1495, _, _) => {
                            h1495
                        }
                    });
                    match m1496 {
                        Adt75::C0(h1494, _) => {
                            h1494
                        }
                    }
                };
                match m1497 {
                    Adt1::C0(_, h1493, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1493
                    }
                }
            }, f63(match v0.clone() {
                Adt1::C0(_, _, h1498, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1498
                }
            }, match v2.clone() {
                Adt73::C0(_, _, h1499) => {
                    h1499
                }
            }), {
                let m1504 = {
                    let m1503 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1502, _, _) => {
                            h1502
                        }
                    });
                    match m1503 {
                        Adt75::C0(h1501, _) => {
                            h1501
                        }
                    }
                };
                match m1504 {
                    Adt1::C0(_, _, _, h1500, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1500
                    }
                }
            }, {
                let m1509 = {
                    let m1508 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1507, _, _) => {
                            h1507
                        }
                    });
                    match m1508 {
                        Adt75::C0(h1506, _) => {
                            h1506
                        }
                    }
                };
                match m1509 {
                    Adt1::C0(_, _, _, _, h1505, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1505
                    }
                }
            }, {
                let m1514 = {
                    let m1513 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1512, _, _) => {
                            h1512
                        }
                    });
                    match m1513 {
                        Adt75::C0(h1511, _) => {
                            h1511
                        }
                    }
                };
                match m1514 {
                    Adt1::C0(_, _, _, _, _, h1510, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1510
                    }
                }
            }, {
                let m1519 = {
                    let m1518 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1517, _, _) => {
                            h1517
                        }
                    });
                    match m1518 {
                        Adt75::C0(h1516, _) => {
                            h1516
                        }
                    }
                };
                match m1519 {
                    Adt1::C0(_, _, _, _, _, _, h1515, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1515
                    }
                }
            }, {
                let m1524 = {
                    let m1523 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1522, _, _) => {
                            h1522
                        }
                    });
                    match m1523 {
                        Adt75::C0(h1521, _) => {
                            h1521
                        }
                    }
                };
                match m1524 {
                    Adt1::C0(_, _, _, _, _, _, _, h1520, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1520
                    }
                }
            }, {
                let m1529 = {
                    let m1528 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1527, _, _) => {
                            h1527
                        }
                    });
                    match m1528 {
                        Adt75::C0(h1526, _) => {
                            h1526
                        }
                    }
                };
                match m1529 {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1525, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1525
                    }
                }
            }, {
                let m1534 = {
                    let m1533 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1532, _, _) => {
                            h1532
                        }
                    });
                    match m1533 {
                        Adt75::C0(h1531, _) => {
                            h1531
                        }
                    }
                };
                match m1534 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1530, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1530
                    }
                }
            }, {
                let m1539 = {
                    let m1538 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1537, _, _) => {
                            h1537
                        }
                    });
                    match m1538 {
                        Adt75::C0(h1536, _) => {
                            h1536
                        }
                    }
                };
                match m1539 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1535, _, _, _, _, _, _, _, _, _, _) => {
                        h1535
                    }
                }
            }, {
                let m1544 = {
                    let m1543 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1542, _, _) => {
                            h1542
                        }
                    });
                    match m1543 {
                        Adt75::C0(h1541, _) => {
                            h1541
                        }
                    }
                };
                match m1544 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1540, _, _, _, _, _, _, _, _, _) => {
                        h1540
                    }
                }
            }, {
                let m1549 = {
                    let m1548 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1547, _, _) => {
                            h1547
                        }
                    });
                    match m1548 {
                        Adt75::C0(h1546, _) => {
                            h1546
                        }
                    }
                };
                match m1549 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1545, _, _, _, _, _, _, _, _) => {
                        h1545
                    }
                }
            }, {
                let m1554 = {
                    let m1553 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1552, _, _) => {
                            h1552
                        }
                    });
                    match m1553 {
                        Adt75::C0(h1551, _) => {
                            h1551
                        }
                    }
                };
                match m1554 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1550, _, _, _, _, _, _, _) => {
                        h1550
                    }
                }
            }, {
                let m1559 = {
                    let m1558 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1557, _, _) => {
                            h1557
                        }
                    });
                    match m1558 {
                        Adt75::C0(h1556, _) => {
                            h1556
                        }
                    }
                };
                match m1559 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1555, _, _, _, _, _, _) => {
                        h1555
                    }
                }
            }, {
                let m1564 = {
                    let m1563 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1562, _, _) => {
                            h1562
                        }
                    });
                    match m1563 {
                        Adt75::C0(h1561, _) => {
                            h1561
                        }
                    }
                };
                match m1564 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1560, _, _, _, _, _) => {
                        h1560
                    }
                }
            }, {
                let m1569 = {
                    let m1568 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1567, _, _) => {
                            h1567
                        }
                    });
                    match m1568 {
                        Adt75::C0(h1566, _) => {
                            h1566
                        }
                    }
                };
                match m1569 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1565, _, _, _, _) => {
                        h1565
                    }
                }
            }, {
                let m1574 = {
                    let m1573 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1572, _, _) => {
                            h1572
                        }
                    });
                    match m1573 {
                        Adt75::C0(h1571, _) => {
                            h1571
                        }
                    }
                };
                match m1574 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1570, _, _, _) => {
                        h1570
                    }
                }
            }, {
                let m1579 = {
                    let m1578 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1577, _, _) => {
                            h1577
                        }
                    });
                    match m1578 {
                        Adt75::C0(h1576, _) => {
                            h1576
                        }
                    }
                };
                match m1579 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1575, _, _) => {
                        h1575
                    }
                }
            }, Some(match v2.clone() {
                Adt73::C0(_, h1580, _) => {
                    h1580
                }
            }), {
                let m1585 = {
                    let m1584 = f82(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1583, _, _) => {
                            h1583
                        }
                    });
                    match m1584 {
                        Adt75::C0(h1582, _) => {
                            h1582
                        }
                    }
                };
                match m1585 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1581) => {
                        h1581
                    }
                }
            }), {
                let m1588 = f82(v0, v1, match v2 {
                    Adt73::C0(h1587, _, _) => {
                        h1587
                    }
                });
                match m1588 {
                    Adt75::C0(_, h1586) => {
                        h1586
                    }
                }
            })
        } else {
            Adt75::C0(v0, List::<Adt67>::nil())
        }
    }
}

pub fn f62(v0: Adt2) -> Adt2 {
    if match v0.clone() {
        Adt2::C0(_, _, h1589, _, _, _) => {
            h1589
        }
    } {
        Adt2::C0(match v0.clone() {
            Adt2::C0(h1590, _, _, _, _, _) => {
                h1590
            }
        }, match v0 {
            Adt2::C0(_, h1591, _, _, _, _) => {
                h1591
            }
        }, false, false, Adt3::C5, Adt4::C0)
    } else {
        v0
    }
}

pub fn f63(v0: Adt5, v1: Adt7) -> Adt5 {
    Adt5::C0(Adt6::C4, match v0.clone() {
        Adt5::C0(_, h1592, _, _, _) => {
            h1592
        }
    }, match v0 {
        Adt5::C0(_, _, h1593, _, _) => {
            h1593
        }
    }, false, v1)
}

pub fn f64(v0: Adt1) -> Adt75 {
    if f83(v0.clone()) {
        let m1595 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1594, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1594
            }
        };
        match m1595 {
            None => {
                Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1596, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1596
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1597, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1597
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1598, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1598
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1599, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1599
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1600, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1600
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1601, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1601
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1602, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1602
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1603, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1603
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1604, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1604
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1605, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1605
                    }
                }, Some(Adt41::C10(Adt43::C5)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1606, _, _, _, _, _, _, _, _, _) => {
                        h1606
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1607, _, _, _, _, _, _, _, _) => {
                        h1607
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1608, _, _, _, _, _, _, _) => {
                        h1608
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1609, _, _, _, _, _, _) => {
                        h1609
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1610, _, _, _, _, _) => {
                        h1610
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1611, _, _, _, _) => {
                        h1611
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1612, _, _, _) => {
                        h1612
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1613, _, _) => {
                        h1613
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1614, _) => {
                        h1614
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1615) => {
                        h1615
                    }
                }), List::<Adt67>::nil())
            }
            Some(v1) => {
                Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1616, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1616
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1617, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1617
                    }
                }, f84(match v0.clone() {
                    Adt1::C0(_, _, h1618, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1618
                    }
                }), match v0.clone() {
                    Adt1::C0(_, _, _, h1619, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1619
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1620, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1620
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1621, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1621
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1622, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1622
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1623, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1623
                    }
                }, true, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1624, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1624
                    }
                }, None::<Adt41>, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1625, _, _, _, _, _, _, _, _, _) => {
                        h1625
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1626, _, _, _, _, _, _, _, _) => {
                        h1626
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1627, _, _, _, _, _, _, _) => {
                        h1627
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1628, _, _, _, _, _, _) => {
                        h1628
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1629, _, _, _, _, _) => {
                        h1629
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1630, _, _, _, _) => {
                        h1630
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1631, _, _, _) => {
                        h1631
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1632, _, _) => {
                        h1632
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1633, _) => {
                        h1633
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1634) => {
                        h1634
                    }
                }), List::cons(Adt67::C7(f32(v0), v1), List::<Adt67>::nil()))
            }
        }
    } else {
        Adt75::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1635, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1635
            }
        }, match v0.clone() {
            Adt1::C0(_, h1636, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1636
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1637, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1637
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1638, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1638
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1639, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1639
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1640, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1640
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1641, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1641
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1642, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1642
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1643, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1643
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1644, _, _, _, _, _, _, _, _, _, _, _) => {
                h1644
            }
        }, Some(Adt41::C10(Adt43::C5)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1645, _, _, _, _, _, _, _, _, _) => {
                h1645
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1646, _, _, _, _, _, _, _, _) => {
                h1646
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1647, _, _, _, _, _, _, _) => {
                h1647
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1648, _, _, _, _, _, _) => {
                h1648
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1649, _, _, _, _, _) => {
                h1649
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1650, _, _, _, _) => {
                h1650
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1651, _, _, _) => {
                h1651
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1652, _, _) => {
                h1652
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1653, _) => {
                h1653
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1654) => {
                h1654
            }
        }), List::<Adt67>::nil())
    }
}

pub fn f65(v0: Adt1, v1: Adt52, v2: Adt7) -> Adt75 {
    if if f1(v0.clone(), v1) {
        match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1655, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1655
            }
        }
    } else {
        false
    } {
        let m1657 = f85(match v0.clone() {
            Adt1::C0(_, _, h1656, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1656
            }
        }, v2.clone());
        match m1657 {
            Ok(v4) => {
                let m1678 = v2.clone();
                match m1678 {
                    Adt7::C0 => {
                        Adt75::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1679, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1679
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1680, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1680
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, h1681, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1681
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, h1682, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1682
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1683, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1683
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1684, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1684
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1685, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1685
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1686, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1686
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h1687, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1687
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1688, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1688
                            }
                        }, Some(Adt41::C10(Adt43::C13)), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1689, _, _, _, _, _, _, _, _, _) => {
                                h1689
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1690, _, _, _, _, _, _, _, _) => {
                                h1690
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1691, _, _, _, _, _, _, _) => {
                                h1691
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1692, _, _, _, _, _, _) => {
                                h1692
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1693, _, _, _, _, _) => {
                                h1693
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1694, _, _, _, _) => {
                                h1694
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1695, _, _, _) => {
                                h1695
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1696, _, _) => {
                                h1696
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1697, _) => {
                                h1697
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1698) => {
                                h1698
                            }
                        }), List::<Adt67>::nil())
                    }
                    Adt7::C1 => {
                        Adt75::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1699, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1699
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1700, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1700
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1701, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1701
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1702, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1702
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1703, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1703
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1704, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1704
                            }
                        }, None::<Adt11>, false, true, None::<Adt41>, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1705, _, _, _, _, _, _, _, _, _) => {
                                h1705
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1706, _, _, _, _, _, _, _, _) => {
                                h1706
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1707, _, _, _, _, _, _, _) => {
                                h1707
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1708, _, _, _, _, _, _) => {
                                h1708
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1709, _, _, _, _, _) => {
                                h1709
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1710, _, _, _, _) => {
                                h1710
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1711, _, _, _) => {
                                h1711
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1712, _, _) => {
                                h1712
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1713, _) => {
                                h1713
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1714) => {
                                h1714
                            }
                        }), List::<Adt67>::nil())
                    }
                    Adt7::C2 => {
                        Adt75::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1715, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1715
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1716, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1716
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1717, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1717
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1718, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1718
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1719, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1719
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1720, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1720
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1721, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1721
                            }
                        }, false, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1722, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1722
                            }
                        }, Some(Adt41::C9(v2, Str::lit("Output was not published; the staged result is retained."))), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1723, _, _, _, _, _, _, _, _, _) => {
                                h1723
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1724, _, _, _, _, _, _, _, _) => {
                                h1724
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1725, _, _, _, _, _, _, _) => {
                                h1725
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1726, _, _, _, _, _, _) => {
                                h1726
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1727, _, _, _, _, _) => {
                                h1727
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1728, _, _, _, _) => {
                                h1728
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1729, _, _, _) => {
                                h1729
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1730, _, _) => {
                                h1730
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1731, _) => {
                                h1731
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1732) => {
                                h1732
                            }
                        }), List::<Adt67>::nil())
                    }
                    Adt7::C3 => {
                        Adt75::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1733, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1733
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1734, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1734
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1735, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1735
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1736, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1736
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1737, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1737
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1738, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1738
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1739, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1739
                            }
                        }, false, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1740, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1740
                            }
                        }, Some(Adt41::C9(v2, Str::lit("Publication outcome is unknown; reconcile with the destination before retrying."))), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1741, _, _, _, _, _, _, _, _, _) => {
                                h1741
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1742, _, _, _, _, _, _, _, _) => {
                                h1742
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1743, _, _, _, _, _, _, _) => {
                                h1743
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1744, _, _, _, _, _, _) => {
                                h1744
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1745, _, _, _, _, _) => {
                                h1745
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1746, _, _, _, _) => {
                                h1746
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1747, _, _, _) => {
                                h1747
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1748, _, _) => {
                                h1748
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1749, _) => {
                                h1749
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1750) => {
                                h1750
                            }
                        }), List::<Adt67>::nil())
                    }
                }
            }
            Err(v3) => {
                Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1658, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1658
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1659, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1659
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1660, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1660
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1661, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1661
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1662, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1662
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1663, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1663
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1664, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1664
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1665, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1665
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1666, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1666
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1667, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1667
                    }
                }, Some(Adt41::C11(v3)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1668, _, _, _, _, _, _, _, _, _) => {
                        h1668
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1669, _, _, _, _, _, _, _, _) => {
                        h1669
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1670, _, _, _, _, _, _, _) => {
                        h1670
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1671, _, _, _, _, _, _) => {
                        h1671
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1672, _, _, _, _, _) => {
                        h1672
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1673, _, _, _, _) => {
                        h1673
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1674, _, _, _) => {
                        h1674
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1675, _, _) => {
                        h1675
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1676, _) => {
                        h1676
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1677) => {
                        h1677
                    }
                }), List::<Adt67>::nil())
            }
        }
    } else {
        Adt75::C0(v0, List::<Adt67>::nil())
    }
}

pub fn f66(v0: Adt1, v1: Adt52, v2: u64) -> R<Adt75> {
    if f58(v0.clone(), v1.clone()) {
        let m1752 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1751, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1751
            }
        };
        match m1752 {
            None => {
                Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1753, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1753
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1754, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1754
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1755, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1755
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1756, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1756
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1757, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1757
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1758, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1758
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1759, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1759
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1760, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1760
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1761, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1761
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1762, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1762
                    }
                }, Some(Adt41::C10(Adt43::C3)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1763, _, _, _, _, _, _, _, _, _) => {
                        h1763
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1764, _, _, _, _, _, _, _, _) => {
                        h1764
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1765, _, _, _, _, _, _, _) => {
                        h1765
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1766, _, _, _, _, _, _) => {
                        h1766
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1767, _, _, _, _, _) => {
                        h1767
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1768, _, _, _, _) => {
                        h1768
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1769, _, _, _) => {
                        h1769
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1770, _, _) => {
                        h1770
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1771, _) => {
                        h1771
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1772) => {
                        h1772
                    }
                }), List::<Adt67>::nil()))
            }
            Some(v3) => {
                let m1784 = f86(match v0.clone() {
                    Adt1::C0(_, _, h1773, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1773
                    }
                }, v2, {
                    let m1778 = {
                        let m1777 = {
                            let m1776 = f72(v3);
                            match m1776 {
                                Adt12::C0(h1775, _) => {
                                    h1775
                                }
                            }
                        };
                        match m1777 {
                            Adt13::C0(_, _, _, _, h1774, _, _) => {
                                h1774
                            }
                        }
                    };
                    match m1778 {
                        None => {
                            let a1782 = {
                                let m1781 = match v0.clone() {
                                    Adt1::C0(_, _, h1780, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                        h1780
                                    }
                                };
                                match m1781 {
                                    Adt5::C0(_, _, h1779, _, _) => {
                                        h1779
                                    }
                                }
                            };
                            let a1783 = v2;
                            nat_add(a1782, a1783)?
                        }
                        Some(v4) => {
                            v4
                        }
                    }
                })?;
                match m1784 {
                    Ok(v6) => {
                        Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1785, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1785
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1786, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1786
                            }
                        }, v6, match v0.clone() {
                            Adt1::C0(_, _, _, h1787, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1787
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1788, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1788
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1789, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1789
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1790, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1790
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1791, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1791
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h1792, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1792
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1793, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1793
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1794, _, _, _, _, _, _, _, _, _, _) => {
                                h1794
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1795, _, _, _, _, _, _, _, _, _) => {
                                h1795
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1796, _, _, _, _, _, _, _, _) => {
                                h1796
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1797, _, _, _, _, _, _, _) => {
                                h1797
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1798, _, _, _, _, _, _) => {
                                h1798
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1799, _, _, _, _, _) => {
                                h1799
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1800, _, _, _, _) => {
                                h1800
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1801, _, _, _) => {
                                h1801
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1802, _, _) => {
                                h1802
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1803, _) => {
                                h1803
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1804) => {
                                h1804
                            }
                        }), List::<Adt67>::nil()))
                    }
                    Err(v5) => {
                        Ok(f82(v0, v1, Adt41::C11(v5)))
                    }
                }
            }
        }
    } else {
        Ok(Adt75::C0(v0, List::<Adt67>::nil()))
    }
}

pub fn f67(v0: Adt1, v1: Adt52, v2: Adt74) -> R<Adt75> {
    if f1(v0.clone(), v1.clone()) {
        let m1806 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1805, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1805
            }
        };
        match m1806 {
            None => {
                Ok(Adt75::C0(v0, List::<Adt67>::nil()))
            }
            Some(v3) => {
                Ok(f87(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1807, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1807
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1808, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1808
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1809, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1809
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1810, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1810
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1811, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1811
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1812, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1812
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1813, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1813
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1814, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1814
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1815, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1815
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1816, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1816
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1817, _, _, _, _, _, _, _, _, _, _) => {
                        h1817
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1818, _, _, _, _, _, _, _, _, _) => {
                        h1818
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1819, _, _, _, _, _, _, _, _) => {
                        h1819
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1820, _, _, _, _, _, _, _) => {
                        h1820
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1821, _, _, _, _, _, _) => {
                        h1821
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1822, _, _, _, _, _) => {
                        h1822
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1823, _, _, _, _) => {
                        h1823
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1824, _, _, _) => {
                        h1824
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1825, _, _) => {
                        h1825
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1826, _) => {
                        h1826
                    }
                }, f68(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1827) => {
                        h1827
                    }
                }, v1, v2.clone())?), f88({
                    let m1831 = {
                        let m1830 = f72(v3);
                        match m1830 {
                            Adt12::C0(h1829, _) => {
                                h1829
                            }
                        }
                    };
                    match m1831 {
                        Adt13::C0(_, _, _, _, _, _, h1828) => {
                            h1828
                        }
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1832, _, _) => {
                        h1832
                    }
                }, v2)?))
            }
        }
    } else {
        Ok(Adt75::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1833, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1833
            }
        }, match v0.clone() {
            Adt1::C0(_, h1834, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1834
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1835, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1835
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1836, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1836
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1837, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1837
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1838, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1838
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1839, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1839
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1840, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1840
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1841, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1841
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1842, _, _, _, _, _, _, _, _, _, _, _) => {
                h1842
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1843, _, _, _, _, _, _, _, _, _, _) => {
                h1843
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1844, _, _, _, _, _, _, _, _, _) => {
                h1844
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1845, _, _, _, _, _, _, _, _) => {
                h1845
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1846, _, _, _, _, _, _, _) => {
                h1846
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1847, _, _, _, _, _, _) => {
                h1847
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1848, _, _, _, _, _) => {
                h1848
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1849, _, _, _, _) => {
                h1849
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1850, _, _, _) => {
                h1850
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1851, _, _) => {
                h1851
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1852, _) => {
                h1852
            }
        }, f68(match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1853) => {
                h1853
            }
        }, v1, v2)?), List::<Adt67>::nil()))
    }
}

pub fn f68(v0: List<Adt51>, v1: Adt52, v2: Adt74) -> R<List<Adt51>> {
    let m1854 = v0;
    match m1854.uncons() {
        None => {
            Ok(List::<Adt51>::nil())
        }
        Some((v3, v4)) => {
            Ok(List::cons(if f89(match v3.clone() {
                Adt51::C0(h1855, _, _, _) => {
                    h1855
                }
            }, v1.clone()) {
                Adt51::C0(match v3.clone() {
                    Adt51::C0(h1856, _, _, _) => {
                        h1856
                    }
                }, match v3.clone() {
                    Adt51::C0(_, h1857, _, _) => {
                        h1857
                    }
                }, f88(match v3.clone() {
                    Adt51::C0(_, h1858, _, _) => {
                        h1858
                    }
                }, match v3.clone() {
                    Adt51::C0(_, _, h1859, _) => {
                        h1859
                    }
                }, v2.clone())?, match v3 {
                    Adt51::C0(_, _, _, h1860) => {
                        h1860
                    }
                })
            } else {
                v3
            }, f68(v4, v1, v2)?))
        }
    }
}

pub fn f69(v0: List<Adt51>, v1: Adt52) -> R<List<Adt51>> {
    let m1861 = v0;
    match m1861.uncons() {
        None => {
            Ok(List::<Adt51>::nil())
        }
        Some((v2, v3)) => {
            if if f89(match v2.clone() {
                Adt51::C0(h1862, _, _, _) => {
                    h1862
                }
            }, v1.clone()) {
                let a1866 = f90({
                    let m1865 = match v2.clone() {
                        Adt51::C0(_, _, h1864, _) => {
                            h1864
                        }
                    };
                    match m1865 {
                        Adt50::C0(h1863, _) => {
                            h1863
                        }
                    }
                })?;
                let a1867 = 0u64;
                if nat_eq(a1866, a1867) {
                    let a1871 = f91({
                        let m1870 = match v2.clone() {
                            Adt51::C0(_, _, h1869, _) => {
                                h1869
                            }
                        };
                        match m1870 {
                            Adt50::C0(h1868, _) => {
                                h1868
                            }
                        }
                    })?;
                    let a1872 = 0u64;
                    nat_eq(a1871, a1872)
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(v3)
            } else {
                Ok(List::cons(v2, f69(v3, v1)?))
            }
        }
    }
}

pub fn f70() -> Adt24 {
    Adt24::C0(f92(), f92(), 0u64, 0u64)
}

pub fn f71() -> Adt14 {
    Adt14::C0(None::<u64>, None::<u64>, None::<u64>, None::<u64>, None::<u64>)
}

pub fn f72(v0: Adt9) -> Adt12 {
    let m1873 = v0;
    match m1873 {
        Adt9::C0(v1) => {
            match v1 {
                Adt10::C0(_, h1874) => {
                    h1874
                }
            }
        }
        Adt9::C1(v2) => {
            match v2 {
                Adt15::C0(_, h1875) => {
                    h1875
                }
            }
        }
        Adt9::C2(v3) => {
            match v3 {
                Adt15::C0(_, h1876) => {
                    h1876
                }
            }
        }
        Adt9::C3(v4) => {
            match v4 {
                Adt16::C0(_, _, _, h1877) => {
                    h1877
                }
            }
        }
        Adt9::C4(v5) => {
            match v5 {
                Adt17::C0(_, _, h1878) => {
                    h1878
                }
            }
        }
        Adt9::C5(v6) => {
            match v6 {
                Adt18::C0(_, h1879) => {
                    h1879
                }
            }
        }
        Adt9::C6(v7) => {
            match v7 {
                Adt19::C0(_, _, h1880) => {
                    h1880
                }
            }
        }
        Adt9::C7(v8) => {
            match v8 {
                Adt20::C0(_, _, _, h1881) => {
                    h1881
                }
            }
        }
        Adt9::C8(v9) => {
            match v9 {
                Adt21::C0(_, h1882) => {
                    h1882
                }
            }
        }
        Adt9::C9(v10) => {
            match v10 {
                Adt21::C0(_, h1883) => {
                    h1883
                }
            }
        }
    }
}

pub fn f73(v0: Adt53) -> List<Adt67> {
    f36(f59(match v0.clone() {
        Adt53::C0(_, h1884, _, _, _, _, _, _) => {
            h1884
        }
    }), f36(f59(match v0.clone() {
        Adt53::C0(_, _, h1885, _, _, _, _, _) => {
            h1885
        }
    }), f36(f59(match v0.clone() {
        Adt53::C0(_, _, _, h1886, _, _, _, _) => {
            h1886
        }
    }), f36(f59(match v0.clone() {
        Adt53::C0(_, _, _, _, h1887, _, _, _) => {
            h1887
        }
    }), f36(f59(match v0.clone() {
        Adt53::C0(_, _, _, _, _, h1888, _, _) => {
            h1888
        }
    }), f36(f59(match v0 {
        Adt53::C0(_, _, _, _, _, _, h1889, _) => {
            h1889
        }
    }), List::<Adt67>::nil()))))))
}

pub fn f74(v0: Adt2) -> R<Adt2> {
    Ok(Adt2::C0({
        let a1891 = match v0.clone() {
            Adt2::C0(h1890, _, _, _, _, _) => {
                h1890
            }
        };
        let a1892 = 1u64;
        nat_add(a1891, a1892)?
    }, match v0 {
        Adt2::C0(_, h1893, _, _, _, _) => {
            h1893
        }
    }, false, false, Adt3::C0, Adt4::C0))
}

pub fn f75(v0: Adt5) -> Result<Adt5, Adt44> {
    let m1895 = match v0.clone() {
        Adt5::C0(h1894, _, _, _, _) => {
            h1894
        }
    };
    match m1895 {
        Adt6::C0 => {
            if match v0.clone() {
                Adt5::C0(_, h1896, _, _, _) => {
                    h1896
                }
            } {
                Err::<Adt5, Adt44>(Adt44::C1)
            } else {
                Ok::<Adt5, Adt44>(Adt5::C0(Adt6::C1, match v0.clone() {
                    Adt5::C0(_, h1897, _, _, _) => {
                        h1897
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h1898, _, _) => {
                        h1898
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, _, h1899, _) => {
                        h1899
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, _, h1900) => {
                        h1900
                    }
                }))
            }
        }
        Adt6::C1 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C2 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C3 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C4 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
    }
}

pub fn f76(v0: Adt1, v1: Adt68) -> bool {
    let m1901 = v1;
    match m1901 {
        Adt68::C0(_) => {
            true
        }
        Adt68::C1(v3) => {
            let a1906 = {
                let m1904 = match v3 {
                    Adt69::C0(h1903, _, _) => {
                        h1903
                    }
                };
                match m1904 {
                    Adt11::C0(h1902, _, _) => {
                        h1902
                    }
                }
            };
            let a1907 = match v0 {
                Adt1::C0(h1905, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1905
                }
            };
            nat_eq(a1906, a1907)
        }
        Adt68::C2(_) => {
            true
        }
        Adt68::C3 => {
            true
        }
    }
}

pub fn f77(v0: Adt5, v1: Adt76) -> Adt77 {
    let m1908 = v1;
    match m1908 {
        Adt76::C0 => {
            let m1910 = match v0.clone() {
                Adt5::C0(h1909, _, _, _, _) => {
                    h1909
                }
            };
            match m1910 {
                Adt6::C0 => {
                    Adt77::C0(Adt78::C0, v0)
                }
                Adt6::C1 => {
                    Adt77::C1(Adt44::C2)
                }
                Adt6::C2 => {
                    Adt77::C1(Adt44::C2)
                }
                Adt6::C3 => {
                    Adt77::C1(Adt44::C2)
                }
                Adt6::C4 => {
                    Adt77::C1(Adt44::C2)
                }
            }
        }
        Adt76::C1 => {
            let m1912 = match v0.clone() {
                Adt5::C0(h1911, _, _, _, _) => {
                    h1911
                }
            };
            match m1912 {
                Adt6::C0 => {
                    Adt77::C1(Adt44::C0)
                }
                Adt6::C1 => {
                    if match v0.clone() {
                        Adt5::C0(_, h1913, _, _, _) => {
                            h1913
                        }
                    } {
                        Adt77::C1(Adt44::C1)
                    } else {
                        Adt77::C0(Adt78::C1, Adt5::C0(Adt6::C0, match v0.clone() {
                            Adt5::C0(_, h1914, _, _, _) => {
                                h1914
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, h1915, _, _) => {
                                h1915
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, _, h1916, _) => {
                                h1916
                            }
                        }, match v0 {
                            Adt5::C0(_, _, _, _, h1917) => {
                                h1917
                            }
                        }))
                    }
                }
                Adt6::C2 => {
                    Adt77::C1(Adt44::C0)
                }
                Adt6::C3 => {
                    Adt77::C1(Adt44::C0)
                }
                Adt6::C4 => {
                    Adt77::C1(Adt44::C0)
                }
            }
        }
        Adt76::C2 => {
            let m1919 = match v0.clone() {
                Adt5::C0(h1918, _, _, _, _) => {
                    h1918
                }
            };
            match m1919 {
                Adt6::C0 => {
                    Adt77::C1(Adt44::C0)
                }
                Adt6::C1 => {
                    if match v0.clone() {
                        Adt5::C0(_, h1920, _, _, _) => {
                            h1920
                        }
                    } {
                        Adt77::C1(Adt44::C1)
                    } else {
                        Adt77::C0(Adt78::C2, Adt5::C0(Adt6::C0, true, match v0.clone() {
                            Adt5::C0(_, _, h1921, _, _) => {
                                h1921
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, _, h1922, _) => {
                                h1922
                            }
                        }, match v0 {
                            Adt5::C0(_, _, _, _, h1923) => {
                                h1923
                            }
                        }))
                    }
                }
                Adt6::C2 => {
                    Adt77::C1(Adt44::C0)
                }
                Adt6::C3 => {
                    Adt77::C1(Adt44::C0)
                }
                Adt6::C4 => {
                    Adt77::C1(Adt44::C0)
                }
            }
        }
        Adt76::C3 => {
            let m1925 = match v0.clone() {
                Adt5::C0(h1924, _, _, _, _) => {
                    h1924
                }
            };
            match m1925 {
                Adt6::C0 => {
                    Adt77::C0(Adt78::C3, Adt5::C0(Adt6::C3, match v0.clone() {
                        Adt5::C0(_, h1926, _, _, _) => {
                            h1926
                        }
                    }, match v0 {
                        Adt5::C0(_, _, h1927, _, _) => {
                            h1927
                        }
                    }, false, Adt7::C2))
                }
                Adt6::C1 => {
                    Adt77::C0(Adt78::C3, Adt5::C0(Adt6::C3, match v0.clone() {
                        Adt5::C0(_, h1928, _, _, _) => {
                            h1928
                        }
                    }, match v0 {
                        Adt5::C0(_, _, h1929, _, _) => {
                            h1929
                        }
                    }, false, Adt7::C2))
                }
                Adt6::C2 => {
                    Adt77::C0(Adt78::C4, v0)
                }
                Adt6::C3 => {
                    Adt77::C0(Adt78::C4, v0)
                }
                Adt6::C4 => {
                    Adt77::C0(Adt78::C4, v0)
                }
            }
        }
    }
}

pub fn f78(v0: Adt68) -> Adt76 {
    let m1930 = v0;
    match m1930 {
        Adt68::C0(_) => {
            Adt76::C1
        }
        Adt68::C1(_) => {
            Adt76::C1
        }
        Adt68::C2(_) => {
            Adt76::C1
        }
        Adt68::C3 => {
            Adt76::C2
        }
    }
}

pub fn f79(v0: Adt8, v1: Adt68) -> R<Result<Adt8, Adt79>> {
    if match v0.clone() {
        Adt8::C0(_, _, h1931, _) => {
            h1931
        }
    } {
        Ok(Err::<Adt8, Adt79>(Adt79::C0))
    } else {
        let m1932 = v1;
        match m1932 {
            Adt68::C0(v2) => {
                if match v0.clone() {
                    Adt8::C0(_, h1933, _, _) => {
                        h1933
                    }
                } {
                    Ok(Err::<Adt8, Adt79>(Adt79::C1))
                } else {
                    let a1935 = v2;
                    let a1936 = match v0.clone() {
                        Adt8::C0(h1934, _, _, _) => {
                            h1934
                        }
                    };
                    if nat_eq(a1935, a1936) {
                        Ok(Ok::<Adt8, Adt79>(Adt8::C0(match v0.clone() {
                            Adt8::C0(h1937, _, _, _) => {
                                h1937
                            }
                        }, true, match v0.clone() {
                            Adt8::C0(_, _, h1938, _) => {
                                h1938
                            }
                        }, match v0 {
                            Adt8::C0(_, _, _, h1939) => {
                                h1939
                            }
                        })))
                    } else {
                        Ok(Err::<Adt8, Adt79>(Adt79::C3))
                    }
                }
            }
            Adt68::C1(v3) => {
                if match v0.clone() {
                    Adt8::C0(_, h1940, _, _) => {
                        h1940
                    }
                } {
                    Ok(Ok::<Adt8, Adt79>(Adt8::C0(match v0.clone() {
                        Adt8::C0(h1941, _, _, _) => {
                            h1941
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, h1942, _, _) => {
                            h1942
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, _, h1943, _) => {
                            h1943
                        }
                    }, {
                        let a1946 = match v0 {
                            Adt8::C0(_, _, _, h1944) => {
                                h1944
                            }
                        };
                        let a1947 = match v3 {
                            Adt69::C0(_, _, h1945) => {
                                h1945
                            }
                        };
                        nat_add(a1946, a1947)?
                    })))
                } else {
                    Ok(Err::<Adt8, Adt79>(Adt79::C2))
                }
            }
            Adt68::C2(v4) => {
                if match v0.clone() {
                    Adt8::C0(_, h1948, _, _) => {
                        h1948
                    }
                } {
                    let a1950 = v4;
                    let a1951 = match v0.clone() {
                        Adt8::C0(h1949, _, _, _) => {
                            h1949
                        }
                    };
                    if nat_eq(a1950, a1951) {
                        Ok(Ok::<Adt8, Adt79>(Adt8::C0({
                            let a1953 = match v0.clone() {
                                Adt8::C0(h1952, _, _, _) => {
                                    h1952
                                }
                            };
                            let a1954 = 1u64;
                            nat_add(a1953, a1954)?
                        }, false, match v0.clone() {
                            Adt8::C0(_, _, h1955, _) => {
                                h1955
                            }
                        }, match v0 {
                            Adt8::C0(_, _, _, h1956) => {
                                h1956
                            }
                        })))
                    } else {
                        Ok(Err::<Adt8, Adt79>(Adt79::C3))
                    }
                } else {
                    Ok(Err::<Adt8, Adt79>(Adt79::C2))
                }
            }
            Adt68::C3 => {
                if match v0.clone() {
                    Adt8::C0(_, h1957, _, _) => {
                        h1957
                    }
                } {
                    Ok(Err::<Adt8, Adt79>(Adt79::C4))
                } else {
                    Ok(Ok::<Adt8, Adt79>(Adt8::C0(match v0.clone() {
                        Adt8::C0(h1958, _, _, _) => {
                            h1958
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, h1959, _, _) => {
                            h1959
                        }
                    }, true, match v0 {
                        Adt8::C0(_, _, _, h1960) => {
                            h1960
                        }
                    })))
                }
            }
        }
    }
}

pub fn f80(v0: Adt2, v1: u64, v2: u64) -> bool {
    if match v0.clone() {
        Adt2::C0(_, _, h1961, _, _, _) => {
            h1961
        }
    } {
        let a1963 = match v0.clone() {
            Adt2::C0(_, h1962, _, _, _, _) => {
                h1962
            }
        };
        let a1964 = v1;
        if nat_eq(a1963, a1964) {
            let a1966 = match v0 {
                Adt2::C0(h1965, _, _, _, _, _) => {
                    h1965
                }
            };
            let a1967 = v2;
            nat_eq(a1966, a1967)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f81(v0: Adt1, v1: Adt52, v2: Adt22, v3: bool) -> R<Adt75> {
    if v3 {
        let m1969 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1968, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1968
            }
        };
        match m1969 {
            None => {
                Ok(f93(v0, v2))
            }
            Some(v4) => {
                f94(v0, v1, f95(v4.clone()), f96(v4, v2))
            }
        }
    } else {
        Ok(f93(v0, v2))
    }
}

pub fn f82(v0: Adt1, v1: Adt52, v2: Adt41) -> Adt75 {
    if f58(v0.clone(), v1.clone()) {
        Adt75::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1970, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1970
            }
        }, f97(match v0.clone() {
            Adt1::C0(_, h1971, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1971
            }
        }, match v1.clone() {
            Adt52::C0(_, h1972, _) => {
                h1972
            }
        }, match v1.clone() {
            Adt52::C0(_, _, h1973) => {
                h1973
            }
        }, Adt4::C5), f63(match v0.clone() {
            Adt1::C0(_, _, h1974, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1974
            }
        }, Adt7::C2), match v0.clone() {
            Adt1::C0(_, _, _, h1975, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1975
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1976, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1976
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1977, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1977
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1978, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1978
            }
        }, None::<Adt11>, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1979, _, _, _, _, _, _, _, _, _, _, _) => {
                h1979
            }
        }, Some(v2), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1980, _, _, _, _, _, _, _, _, _) => {
                h1980
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1981, _, _, _, _, _, _, _, _) => {
                h1981
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1982, _, _, _, _, _, _, _) => {
                h1982
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1983, _, _, _, _, _, _) => {
                h1983
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1984, _, _, _, _, _) => {
                h1984
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1985, _, _, _, _) => {
                h1985
            }
        }, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1986, _, _) => {
                h1986
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1987, _) => {
                h1987
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1988) => {
                h1988
            }
        }), List::cons(Adt67::C5(v1), List::<Adt67>::nil()))
    } else {
        Adt75::C0(v0, List::<Adt67>::nil())
    }
}

pub fn f83(v0: Adt1) -> bool {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1989, _, _, _, _, _, _, _) => {
            h1989
        }
    } {
        let a1991 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1990, _, _, _, _, _, _) => {
                h1990
            }
        };
        if bool_not(a1991) {
            let a1993 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1992, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1992
                }
            };
            if bool_not(a1993) {
                let m1996 = match v0.clone() {
                    Adt1::C0(_, _, h1995, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1995
                    }
                };
                if match m1996 {
                    Adt5::C0(_, _, _, h1994, _) => {
                        h1994
                    }
                } {
                    let m1998 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h1997, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1997
                        }
                    };
                    if match m1998 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    } {
                        let m2002 = {
                            let m2001 = match v0 {
                                Adt1::C0(_, _, h2000, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h2000
                                }
                            };
                            match m2001 {
                                Adt5::C0(_, _, _, _, h1999) => {
                                    h1999
                                }
                            }
                        };
                        match m2002 {
                            Adt7::C0 => {
                                true
                            }
                            Adt7::C1 => {
                                false
                            }
                            Adt7::C2 => {
                                true
                            }
                            Adt7::C3 => {
                                false
                            }
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f84(v0: Adt5) -> Adt5 {
    Adt5::C0(match v0.clone() {
        Adt5::C0(h2003, _, _, _, _) => {
            h2003
        }
    }, match v0.clone() {
        Adt5::C0(_, h2004, _, _, _) => {
            h2004
        }
    }, match v0.clone() {
        Adt5::C0(_, _, h2005, _, _) => {
            h2005
        }
    }, match v0 {
        Adt5::C0(_, _, _, h2006, _) => {
            h2006
        }
    }, Adt7::C0)
}

pub fn f85(v0: Adt5, v1: Adt7) -> Result<Adt5, Adt44> {
    if f98(v0.clone()) {
        let m2007 = v1;
        match m2007 {
            Adt7::C0 => {
                Err::<Adt5, Adt44>(Adt44::C3)
            }
            Adt7::C1 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2008, _, _, _, _) => {
                        h2008
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2009, _, _, _) => {
                        h2009
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2010, _, _) => {
                        h2010
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2011, _) => {
                        h2011
                    }
                }, Adt7::C1))
            }
            Adt7::C2 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2012, _, _, _, _) => {
                        h2012
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2013, _, _, _) => {
                        h2013
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2014, _, _) => {
                        h2014
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2015, _) => {
                        h2015
                    }
                }, Adt7::C2))
            }
            Adt7::C3 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2016, _, _, _, _) => {
                        h2016
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2017, _, _, _) => {
                        h2017
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2018, _, _) => {
                        h2018
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2019, _) => {
                        h2019
                    }
                }, Adt7::C3))
            }
        }
    } else {
        Err::<Adt5, Adt44>(Adt44::C3)
    }
}

pub fn f86(v0: Adt5, v1: u64, v2: u64) -> R<Result<Adt5, Adt44>> {
    let m2021 = match v0.clone() {
        Adt5::C0(h2020, _, _, _, _) => {
            h2020
        }
    };
    match m2021 {
        Adt6::C0 => {
            let a2023 = match v0.clone() {
                Adt5::C0(_, _, h2022, _, _) => {
                    h2022
                }
            };
            let a2024 = v2;
            if if nat_le(a2023, a2024) {
                let a2028 = v1;
                let a2029 = {
                    let a2026 = v2;
                    let a2027 = match v0.clone() {
                        Adt5::C0(_, _, h2025, _, _) => {
                            h2025
                        }
                    };
                    nat_sub(a2026, a2027)
                };
                nat_le(a2028, a2029)
            } else {
                false
            } {
                Ok(Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2030, _, _, _, _) => {
                        h2030
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2031, _, _, _) => {
                        h2031
                    }
                }, {
                    let a2033 = match v0.clone() {
                        Adt5::C0(_, _, h2032, _, _) => {
                            h2032
                        }
                    };
                    let a2034 = v1;
                    nat_add(a2033, a2034)?
                }, match v0.clone() {
                    Adt5::C0(_, _, _, h2035, _) => {
                        h2035
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, _, h2036) => {
                        h2036
                    }
                })))
            } else {
                Ok(Err::<Adt5, Adt44>(Adt44::C4))
            }
        }
        Adt6::C1 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C2 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C3 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C4 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
    }
}

pub fn f87(v0: Adt1, v1: Adt50) -> Adt75 {
    let m2038 = match v1.clone() {
        Adt50::C0(_, h2037) => {
            h2037
        }
    };
    match m2038 {
        None => {
            Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h2039, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2039
                }
            }, match v0.clone() {
                Adt1::C0(_, h2040, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2040
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h2041, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2041
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h2042, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2042
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h2043, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2043
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h2044, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2044
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h2045, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2045
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2046, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2046
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h2047, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2047
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h2048, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2048
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h2049, _, _, _, _, _, _, _, _, _, _) => {
                    h2049
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2050, _, _, _, _, _, _, _, _, _) => {
                    h2050
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2051, _, _, _, _, _, _, _, _) => {
                    h2051
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2052, _, _, _, _, _, _, _) => {
                    h2052
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2053, _, _, _, _, _, _) => {
                    h2053
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2054, _, _, _, _, _) => {
                    h2054
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2055, _, _, _, _) => {
                    h2055
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2056, _, _, _) => {
                    h2056
                }
            }, v1, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2057, _) => {
                    h2057
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2058) => {
                    h2058
                }
            }), List::<Adt67>::nil())
        }
        Some(v2) => {
            Adt75::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h2059, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2059
                }
            }, match v0.clone() {
                Adt1::C0(_, h2060, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2060
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h2061, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2061
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h2062, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2062
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h2063, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2063
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h2064, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2064
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h2065, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2065
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2066, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2066
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h2067, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2067
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h2068, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2068
                }
            }, Some(Adt41::C16(v2)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2069, _, _, _, _, _, _, _, _, _) => {
                    h2069
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2070, _, _, _, _, _, _, _, _) => {
                    h2070
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2071, _, _, _, _, _, _, _) => {
                    h2071
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2072, _, _, _, _, _, _) => {
                    h2072
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2073, _, _, _, _, _) => {
                    h2073
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2074, _, _, _, _) => {
                    h2074
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2075, _, _, _) => {
                    h2075
                }
            }, v1, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2076, _) => {
                    h2076
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2077) => {
                    h2077
                }
            }), List::<Adt67>::nil())
        }
    }
}

pub fn f88(v0: Adt14, v1: Adt50, v2: Adt74) -> R<Adt50> {
    let m2078 = v2;
    match m2078 {
        Adt74::C0(v3, v4) => {
            let m2080 = f99(v0, match v1.clone() {
                Adt50::C0(h2079, _) => {
                    h2079
                }
            }, v3, v4)?;
            match m2080 {
                Ok(v6) => {
                    Ok(Adt50::C0(v6, None::<Adt45>))
                }
                Err(v5) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2081, _) => {
                            h2081
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt74::C1(v7, v8, v9) => {
            let m2083 = f100(match v1.clone() {
                Adt50::C0(h2082, _) => {
                    h2082
                }
            }, v7, v8, v9)?;
            match m2083 {
                Ok(v11) => {
                    Ok(Adt50::C0(v11, None::<Adt45>))
                }
                Err(v10) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2084, _) => {
                            h2084
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt74::C2(v12, v13, v14) => {
            let m2086 = f100(match v1.clone() {
                Adt50::C0(h2085, _) => {
                    h2085
                }
            }, v12, v13, v14)?;
            match m2086 {
                Ok(v16) => {
                    Ok(Adt50::C0(v16, None::<Adt45>))
                }
                Err(v15) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2087, _) => {
                            h2087
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt74::C3(v17, v18) => {
            let m2089 = f101(match v1.clone() {
                Adt50::C0(h2088, _) => {
                    h2088
                }
            }, v17, v18)?;
            match m2089 {
                Ok(v20) => {
                    Ok(Adt50::C0(v20, None::<Adt45>))
                }
                Err(v19) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2090, _) => {
                            h2090
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt74::C4(v21, v22) => {
            let m2092 = f101(match v1.clone() {
                Adt50::C0(h2091, _) => {
                    h2091
                }
            }, v21, v22)?;
            match m2092 {
                Ok(v24) => {
                    Ok(Adt50::C0(v24, None::<Adt45>))
                }
                Err(v23) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2093, _) => {
                            h2093
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f89(v0: Adt52, v1: Adt52) -> bool {
    let a2096 = match v0.clone() {
        Adt52::C0(h2094, _, _) => {
            h2094
        }
    };
    let a2097 = match v1.clone() {
        Adt52::C0(h2095, _, _) => {
            h2095
        }
    };
    if nat_eq(a2096, a2097) {
        let a2100 = match v0.clone() {
            Adt52::C0(_, h2098, _) => {
                h2098
            }
        };
        let a2101 = match v1.clone() {
            Adt52::C0(_, h2099, _) => {
                h2099
            }
        };
        if nat_eq(a2100, a2101) {
            let a2104 = match v0 {
                Adt52::C0(_, _, h2102) => {
                    h2102
                }
            };
            let a2105 = match v1 {
                Adt52::C0(_, _, h2103) => {
                    h2103
                }
            };
            nat_eq(a2104, a2105)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f90(v0: Adt24) -> R<u64> {
    f102(match v0 {
        Adt24::C0(h2106, _, _, _) => {
            h2106
        }
    })
}

pub fn f91(v0: Adt24) -> R<u64> {
    f102(match v0 {
        Adt24::C0(_, h2107, _, _) => {
            h2107
        }
    })
}

pub fn f92() -> Adt25 {
    Adt25::C0(0u64, 0u64, 0u64, 0u64)
}

pub fn f93(v0: Adt1, v1: Adt22) -> Adt75 {
    Adt75::C0(v0.clone(), {
        let m2114 = {
            let m2110 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2109, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2109
                }
            };
            match m2110 {
                None => {
                    Adt75::C0(v0, f59(match v1 {
                        Adt22::C0(_, _, _, _, _, _, _, _, h2111, _) => {
                            h2111
                        }
                    }))
                }
                Some(v2) => {
                    let m2113 = match v1 {
                        Adt22::C0(_, _, _, _, _, _, _, _, h2112, _) => {
                            h2112
                        }
                    };
                    match m2113 {
                        None => {
                            Adt75::C0(v0, List::<Adt67>::nil())
                        }
                        Some(v3) => {
                            if f52(v2, v3.clone()) {
                                Adt75::C0(v0, List::<Adt67>::nil())
                            } else {
                                Adt75::C0(v0, List::cons(Adt67::C6(v3), List::<Adt67>::nil()))
                            }
                        }
                    }
                }
            }
        };
        match m2114 {
            Adt75::C0(_, h2108) => {
                h2108
            }
        }
    })
}

pub fn f94(v0: Adt1, v1: Adt52, v2: Adt54, v3: Adt22) -> R<Adt75> {
    if f103(v0.clone(), v2.clone(), v3.clone())? {
        let m2115 = f104(v2.clone(), v3.clone());
        match m2115 {
            Adt80::C0 => {
                let m2117 = f105(match v0.clone() {
                    Adt1::C0(_, _, h2116, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2116
                    }
                });
                match m2117 {
                    Ok(v5) => {
                        Ok(Adt75::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h2118, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2118
                            }
                        }, f97(match v0.clone() {
                            Adt1::C0(_, h2119, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2119
                            }
                        }, match v1.clone() {
                            Adt52::C0(_, h2120, _) => {
                                h2120
                            }
                        }, match v1 {
                            Adt52::C0(_, _, h2121) => {
                                h2121
                            }
                        }, {
                            let m2122 = v2;
                            match m2122 {
                                Adt54::C0 => {
                                    Adt4::C2
                                }
                                Adt54::C1 => {
                                    Adt4::C3
                                }
                                Adt54::C2 => {
                                    Adt4::C1
                                }
                                Adt54::C3 => {
                                    Adt4::C1
                                }
                                Adt54::C4 => {
                                    Adt4::C2
                                }
                                Adt54::C5 => {
                                    Adt4::C2
                                }
                                Adt54::C6 => {
                                    Adt4::C1
                                }
                                Adt54::C7 => {
                                    Adt4::C1
                                }
                                Adt54::C8 => {
                                    Adt4::C1
                                }
                                Adt54::C9 => {
                                    Adt4::C1
                                }
                            }
                        }), v5, match v0.clone() {
                            Adt1::C0(_, _, _, h2123, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2123
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h2124, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2124
                            }
                        }, Some(v3.clone()), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2125, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2125
                            }
                        }, match v3.clone() {
                            Adt22::C0(_, _, _, _, _, _, _, _, h2126, _) => {
                                h2126
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h2127, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2127
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h2128, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2128
                            }
                        }, None::<Adt41>, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2129, _, _, _, _, _, _, _, _, _) => {
                                h2129
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2130, _, _, _, _, _, _, _, _) => {
                                h2130
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2131, _, _, _, _, _, _, _) => {
                                h2131
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2132, _, _, _, _, _, _) => {
                                h2132
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2133, _, _, _, _, _) => {
                                h2133
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2134, _, _, _, _) => {
                                h2134
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2135, _, _, _) => {
                                h2135
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2136, _, _) => {
                                h2136
                            }
                        }, Some(match v3 {
                            Adt22::C0(h2137, _, _, _, _, _, _, _, _, _) => {
                                h2137
                            }
                        }), match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2138) => {
                                h2138
                            }
                        }), List::<Adt67>::nil()))
                    }
                    Err(v4) => {
                        Ok(f82(v0, v1, Adt41::C11(v4)))
                    }
                }
            }
            Adt80::C1 => {
                Ok(f82(v0, v1, Adt41::C12))
            }
            Adt80::C2 => {
                Ok(f82(v0, v1, Adt41::C13))
            }
            Adt80::C3 => {
                Ok(f82(v0, v1, Adt41::C7))
            }
            Adt80::C4 => {
                Ok(f82(v0, v1, Adt41::C5))
            }
        }
    } else {
        Ok(f82(v0, v1, Adt41::C15(Str::lit("Staged output ownership or byte count does not match the operation."))))
    }
}

pub fn f95(v0: Adt9) -> Adt54 {
    let m2139 = v0;
    match m2139 {
        Adt9::C0(_) => {
            Adt54::C0
        }
        Adt9::C1(_) => {
            Adt54::C1
        }
        Adt9::C2(_) => {
            Adt54::C2
        }
        Adt9::C3(_) => {
            Adt54::C3
        }
        Adt9::C4(_) => {
            Adt54::C4
        }
        Adt9::C5(_) => {
            Adt54::C5
        }
        Adt9::C6(_) => {
            Adt54::C6
        }
        Adt9::C7(_) => {
            Adt54::C7
        }
        Adt9::C8(_) => {
            Adt54::C8
        }
        Adt9::C9(_) => {
            Adt54::C9
        }
    }
}

pub fn f96(v0: Adt9, v1: Adt22) -> Adt22 {
    Adt22::C0(match v1.clone() {
        Adt22::C0(h2140, _, _, _, _, _, _, _, _, _) => {
            h2140
        }
    }, match v1.clone() {
        Adt22::C0(_, h2141, _, _, _, _, _, _, _, _) => {
            h2141
        }
    }, match v1.clone() {
        Adt22::C0(_, _, h2142, _, _, _, _, _, _, _) => {
            h2142
        }
    }, f106(v0), match v1.clone() {
        Adt22::C0(_, _, _, _, h2143, _, _, _, _, _) => {
            h2143
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, h2144, _, _, _, _) => {
            h2144
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, h2145, _, _, _) => {
            h2145
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, _, h2146, _, _) => {
            h2146
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, _, _, h2147, _) => {
            h2147
        }
    }, match v1 {
        Adt22::C0(_, _, _, _, _, _, _, _, _, h2148) => {
            h2148
        }
    })
}

pub fn f97(v0: Adt2, v1: u64, v2: u64, v3: Adt4) -> Adt2 {
    if f80(v0.clone(), v1, v2) {
        Adt2::C0(match v0.clone() {
            Adt2::C0(h2149, _, _, _, _, _) => {
                h2149
            }
        }, match v0 {
            Adt2::C0(_, h2150, _, _, _, _) => {
                h2150
            }
        }, false, true, {
            let m2151 = v3.clone();
            match m2151 {
                Adt4::C0 => {
                    Adt3::C6
                }
                Adt4::C1 => {
                    Adt3::C4
                }
                Adt4::C2 => {
                    Adt3::C4
                }
                Adt4::C3 => {
                    Adt3::C4
                }
                Adt4::C4 => {
                    Adt3::C4
                }
                Adt4::C5 => {
                    Adt3::C6
                }
            }
        }, v3)
    } else {
        v0
    }
}

pub fn f98(v0: Adt5) -> bool {
    let m2153 = match v0.clone() {
        Adt5::C0(h2152, _, _, _, _) => {
            h2152
        }
    };
    match m2153 {
        Adt6::C0 => {
            false
        }
        Adt6::C1 => {
            false
        }
        Adt6::C2 => {
            if match v0.clone() {
                Adt5::C0(_, _, _, h2154, _) => {
                    h2154
                }
            } {
                let m2156 = match v0 {
                    Adt5::C0(_, _, _, _, h2155) => {
                        h2155
                    }
                };
                match m2156 {
                    Adt7::C0 => {
                        true
                    }
                    Adt7::C1 => {
                        false
                    }
                    Adt7::C2 => {
                        false
                    }
                    Adt7::C3 => {
                        false
                    }
                }
            } else {
                false
            }
        }
        Adt6::C3 => {
            false
        }
        Adt6::C4 => {
            false
        }
    }
}

pub fn f99(v0: Adt14, v1: Adt24, v2: Adt46, v3: u64) -> R<Result<Adt24, Adt45>> {
    if f107(match v0.clone() {
        Adt14::C0(h2157, _, _, _, _) => {
            h2157
        }
    }, f108(v1.clone())?, v3)? {
        if f107(f109(v0.clone(), v2.clone()), {
            let a2160 = f110(match v1.clone() {
                Adt24::C0(h2158, _, _, _) => {
                    h2158
                }
            }, v2.clone());
            let a2161 = f110(match v1.clone() {
                Adt24::C0(_, h2159, _, _) => {
                    h2159
                }
            }, v2.clone());
            nat_add(a2160, a2161)?
        }, v3)? {
            Ok(Ok::<Adt24, Adt45>(Adt24::C0(match v1.clone() {
                Adt24::C0(h2162, _, _, _) => {
                    h2162
                }
            }, f111(match v1.clone() {
                Adt24::C0(_, h2163, _, _) => {
                    h2163
                }
            }, v2.clone(), {
                let a2165 = f110(match v1.clone() {
                    Adt24::C0(_, h2164, _, _) => {
                        h2164
                    }
                }, v2.clone());
                let a2166 = v3;
                nat_add(a2165, a2166)?
            }), f112(match v1.clone() {
                Adt24::C0(_, _, h2167, _) => {
                    h2167
                }
            }, f102(match v1.clone() {
                Adt24::C0(h2168, _, _, _) => {
                    h2168
                }
            })?), f112(match v1.clone() {
                Adt24::C0(_, _, _, h2169) => {
                    h2169
                }
            }, {
                let a2175 = f102(match v1.clone() {
                    Adt24::C0(h2170, _, _, _) => {
                        h2170
                    }
                })?;
                let a2176 = f102(f111(match v1.clone() {
                    Adt24::C0(_, h2171, _, _) => {
                        h2171
                    }
                }, v2.clone(), {
                    let a2173 = f110(match v1 {
                        Adt24::C0(_, h2172, _, _) => {
                            h2172
                        }
                    }, v2);
                    let a2174 = v3;
                    nat_add(a2173, a2174)?
                }))?;
                nat_add(a2175, a2176)?
            }))))
        } else {
            Ok(Err::<Adt24, Adt45>(Adt45::C1(v2.clone(), {
                let a2179 = f110(match v1.clone() {
                    Adt24::C0(h2177, _, _, _) => {
                        h2177
                    }
                }, v2.clone());
                let a2180 = f110(match v1 {
                    Adt24::C0(_, h2178, _, _) => {
                        h2178
                    }
                }, v2.clone());
                nat_add(a2179, a2180)?
            }, v3, {
                let m2181 = f109(v0, v2);
                match m2181 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C0(f108(v1)?, v3, {
            let m2183 = match v0 {
                Adt14::C0(h2182, _, _, _, _) => {
                    h2182
                }
            };
            match m2183 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f100(v0: Adt24, v1: Adt46, v2: u64, v3: u64) -> R<Result<Adt24, Adt45>> {
    let a2187 = {
        let a2185 = f110(match v0.clone() {
            Adt24::C0(_, h2184, _, _) => {
                h2184
            }
        }, v1.clone());
        let a2186 = v2;
        nat_lt(a2185, a2186)
    };
    if if bool_not(a2187) {
        let a2190 = {
            let a2188 = v2;
            let a2189 = v3;
            nat_lt(a2188, a2189)
        };
        bool_not(a2190)
    } else {
        false
    } {
        Ok(Ok::<Adt24, Adt45>(Adt24::C0(f111(match v0.clone() {
            Adt24::C0(h2191, _, _, _) => {
                h2191
            }
        }, v1.clone(), {
            let a2193 = f110(match v0.clone() {
                Adt24::C0(h2192, _, _, _) => {
                    h2192
                }
            }, v1.clone());
            let a2194 = v3;
            nat_add(a2193, a2194)?
        }), f111(match v0.clone() {
            Adt24::C0(_, h2195, _, _) => {
                h2195
            }
        }, v1.clone(), {
            let a2197 = f110(match v0.clone() {
                Adt24::C0(_, h2196, _, _) => {
                    h2196
                }
            }, v1.clone());
            let a2198 = v2;
            nat_sub(a2197, a2198)
        }), f112(match v0.clone() {
            Adt24::C0(_, _, h2199, _) => {
                h2199
            }
        }, f102(f111(match v0.clone() {
            Adt24::C0(h2200, _, _, _) => {
                h2200
            }
        }, v1.clone(), {
            let a2202 = f110(match v0.clone() {
                Adt24::C0(h2201, _, _, _) => {
                    h2201
                }
            }, v1.clone());
            let a2203 = v3;
            nat_add(a2202, a2203)?
        }))?), f112(match v0.clone() {
            Adt24::C0(_, _, _, h2204) => {
                h2204
            }
        }, {
            let a2213 = f102(f111(match v0.clone() {
                Adt24::C0(h2205, _, _, _) => {
                    h2205
                }
            }, v1.clone(), {
                let a2207 = f110(match v0.clone() {
                    Adt24::C0(h2206, _, _, _) => {
                        h2206
                    }
                }, v1.clone());
                let a2208 = v3;
                nat_add(a2207, a2208)?
            }))?;
            let a2214 = f102(f111(match v0.clone() {
                Adt24::C0(_, h2209, _, _) => {
                    h2209
                }
            }, v1.clone(), {
                let a2211 = f110(match v0 {
                    Adt24::C0(_, h2210, _, _) => {
                        h2210
                    }
                }, v1);
                let a2212 = v2;
                nat_sub(a2211, a2212)
            }))?;
            nat_add(a2213, a2214)?
        }))))
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C2(v1, v2, v3)))
    }
}

pub fn f101(v0: Adt24, v1: Adt46, v2: u64) -> R<Result<Adt24, Adt45>> {
    let a2218 = {
        let a2216 = f110(match v0.clone() {
            Adt24::C0(h2215, _, _, _) => {
                h2215
            }
        }, v1.clone());
        let a2217 = v2;
        nat_lt(a2216, a2217)
    };
    if bool_not(a2218) {
        Ok(Ok::<Adt24, Adt45>(Adt24::C0(f111(match v0.clone() {
            Adt24::C0(h2219, _, _, _) => {
                h2219
            }
        }, v1.clone(), {
            let a2221 = f110(match v0.clone() {
                Adt24::C0(h2220, _, _, _) => {
                    h2220
                }
            }, v1.clone());
            let a2222 = v2;
            nat_sub(a2221, a2222)
        }), match v0.clone() {
            Adt24::C0(_, h2223, _, _) => {
                h2223
            }
        }, f112(match v0.clone() {
            Adt24::C0(_, _, h2224, _) => {
                h2224
            }
        }, f102(f111(match v0.clone() {
            Adt24::C0(h2225, _, _, _) => {
                h2225
            }
        }, v1.clone(), {
            let a2227 = f110(match v0.clone() {
                Adt24::C0(h2226, _, _, _) => {
                    h2226
                }
            }, v1.clone());
            let a2228 = v2;
            nat_sub(a2227, a2228)
        }))?), f112(match v0.clone() {
            Adt24::C0(_, _, _, h2229) => {
                h2229
            }
        }, {
            let a2235 = f102(f111(match v0.clone() {
                Adt24::C0(h2230, _, _, _) => {
                    h2230
                }
            }, v1.clone(), {
                let a2232 = f110(match v0.clone() {
                    Adt24::C0(h2231, _, _, _) => {
                        h2231
                    }
                }, v1);
                let a2233 = v2;
                nat_sub(a2232, a2233)
            }))?;
            let a2236 = f102(match v0 {
                Adt24::C0(_, h2234, _, _) => {
                    h2234
                }
            })?;
            nat_add(a2235, a2236)?
        }))))
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C3(v1.clone(), f110(match v0 {
            Adt24::C0(h2237, _, _, _) => {
                h2237
            }
        }, v1), v2)))
    }
}

pub fn f102(v0: Adt25) -> R<u64> {
    let a2248 = {
        let a2245 = {
            let a2242 = {
                let a2239 = 0u64;
                let a2240 = match v0.clone() {
                    Adt25::C0(h2238, _, _, _) => {
                        h2238
                    }
                };
                nat_add(a2239, a2240)?
            };
            let a2243 = match v0.clone() {
                Adt25::C0(_, h2241, _, _) => {
                    h2241
                }
            };
            nat_add(a2242, a2243)?
        };
        let a2246 = match v0.clone() {
            Adt25::C0(_, _, h2244, _) => {
                h2244
            }
        };
        nat_add(a2245, a2246)?
    };
    let a2249 = match v0 {
        Adt25::C0(_, _, _, h2247) => {
            h2247
        }
    };
    nat_add(a2248, a2249)
}

pub fn f103(v0: Adt1, v1: Adt54, v2: Adt22) -> R<bool> {
    let a2256 = {
        let m2252 = match v2.clone() {
            Adt22::C0(h2251, _, _, _, _, _, _, _, _, _) => {
                h2251
            }
        };
        match m2252 {
            Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, h2250, _, _) => {
                h2250
            }
        }
    };
    let a2257 = {
        let m2255 = match v0.clone() {
            Adt1::C0(_, _, h2254, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2254
            }
        };
        match m2255 {
            Adt5::C0(_, _, h2253, _, _) => {
                h2253
            }
        }
    };
    if if nat_eq(a2256, a2257) {
        let m2259 = match v2.clone() {
            Adt22::C0(_, _, _, _, _, _, _, _, h2258, _) => {
                h2258
            }
        };
        match m2259 {
            None => {
                let m2260 = v1;
                match m2260 {
                    Adt54::C0 => {
                        false
                    }
                    Adt54::C1 => {
                        false
                    }
                    Adt54::C2 => {
                        true
                    }
                    Adt54::C3 => {
                        true
                    }
                    Adt54::C4 => {
                        false
                    }
                    Adt54::C5 => {
                        false
                    }
                    Adt54::C6 => {
                        true
                    }
                    Adt54::C7 => {
                        true
                    }
                    Adt54::C8 => {
                        true
                    }
                    Adt54::C9 => {
                        true
                    }
                }
            }
            Some(v3) => {
                let a2263 = match v3 {
                    Adt11::C0(h2261, _, _) => {
                        h2261
                    }
                };
                let a2264 = match v0.clone() {
                    Adt1::C0(h2262, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2262
                    }
                };
                if nat_eq(a2263, a2264) {
                    let m2265 = v1;
                    match m2265 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                } else {
                    false
                }
            }
        }
    } else {
        false
    } {
        if f113({
            let m2268 = match v2 {
                Adt22::C0(h2267, _, _, _, _, _, _, _, _, _) => {
                    h2267
                }
            };
            match m2268 {
                Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2266, _) => {
                    h2266
                }
            }
        }, {
            let m2271 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2270, _, _) => {
                    h2270
                }
            };
            match m2271 {
                Adt50::C0(h2269, _) => {
                    h2269
                }
            }
        }) {
            let a2275 = f91({
                let m2274 = match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2273, _, _) => {
                        h2273
                    }
                };
                match m2274 {
                    Adt50::C0(h2272, _) => {
                        h2272
                    }
                }
            })?;
            let a2276 = 0u64;
            if nat_eq(a2275, a2276) {
                let m2280 = {
                    let m2279 = match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2278, _, _) => {
                            h2278
                        }
                    };
                    match m2279 {
                        Adt50::C0(_, h2277) => {
                            h2277
                        }
                    }
                };
                match m2280 {
                    None => {
                        Ok(true)
                    }
                    Some(_) => {
                        Ok(false)
                    }
                }
            } else {
                Ok(false)
            }
        } else {
            Ok(false)
        }
    } else {
        Ok(false)
    }
}

pub fn f104(v0: Adt54, v1: Adt22) -> Adt80 {
    let m2281 = v0;
    match m2281 {
        Adt54::C0 => {
            let m2284 = match v1.clone() {
                Adt22::C0(_, h2283, _, _, _, _, _, _, _, _) => {
                    h2283
                }
            };
            if if match m2284 {
                Adt28::C0(h2282, _, _, _, _) => {
                    h2282
                }
            } {
                let m2287 = match v1.clone() {
                    Adt22::C0(_, h2286, _, _, _, _, _, _, _, _) => {
                        h2286
                    }
                };
                if match m2287 {
                    Adt28::C0(_, h2285, _, _, _) => {
                        h2285
                    }
                } {
                    let m2290 = match v1.clone() {
                        Adt22::C0(_, h2289, _, _, _, _, _, _, _, _) => {
                            h2289
                        }
                    };
                    if match m2290 {
                        Adt28::C0(_, _, h2288, _, _) => {
                            h2288
                        }
                    } {
                        if match v1.clone() {
                            Adt22::C0(_, _, h2291, _, _, _, _, _, _, _) => {
                                h2291
                            }
                        } {
                            if match v1.clone() {
                                Adt22::C0(_, _, _, h2292, _, _, _, _, _, _) => {
                                    h2292
                                }
                            } {
                                let m2295 = match v1.clone() {
                                    Adt22::C0(_, h2294, _, _, _, _, _, _, _, _) => {
                                        h2294
                                    }
                                };
                                match m2295 {
                                    Adt28::C0(_, _, _, h2293, _) => {
                                        h2293
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f114(match v1.clone() {
                    Adt22::C0(_, _, _, _, h2296, _, _, _, _, _) => {
                        h2296
                    }
                }, false, f115(match v1 {
                    Adt22::C0(_, _, _, _, _, h2297, _, _, _, _) => {
                        h2297
                    }
                }))
            } else {
                Adt80::C2
            }
        }
        Adt54::C1 => {
            f116({
                let m2300 = match v1.clone() {
                    Adt22::C0(_, h2299, _, _, _, _, _, _, _, _) => {
                        h2299
                    }
                };
                match m2300 {
                    Adt28::C0(h2298, _, _, _, _) => {
                        h2298
                    }
                }
            }, {
                let m2303 = match v1.clone() {
                    Adt22::C0(_, h2302, _, _, _, _, _, _, _, _) => {
                        h2302
                    }
                };
                match m2303 {
                    Adt28::C0(_, h2301, _, _, _) => {
                        h2301
                    }
                }
            }, {
                let m2306 = match v1.clone() {
                    Adt22::C0(_, h2305, _, _, _, _, _, _, _, _) => {
                        h2305
                    }
                };
                match m2306 {
                    Adt28::C0(_, _, h2304, _, _) => {
                        h2304
                    }
                }
            }, match v1 {
                Adt22::C0(_, _, h2307, _, _, _, _, _, _, _) => {
                    h2307
                }
            }, false)
        }
        Adt54::C2 => {
            let m2310 = match v1 {
                Adt22::C0(_, h2309, _, _, _, _, _, _, _, _) => {
                    h2309
                }
            };
            if match m2310 {
                Adt28::C0(h2308, _, _, _, _) => {
                    h2308
                }
            } {
                Adt80::C0
            } else {
                Adt80::C2
            }
        }
        Adt54::C3 => {
            if match v1.clone() {
                Adt22::C0(_, _, _, h2311, _, _, _, _, _, _) => {
                    h2311
                }
            } {
                let m2314 = match v1.clone() {
                    Adt22::C0(_, h2313, _, _, _, _, _, _, _, _) => {
                        h2313
                    }
                };
                if if match m2314 {
                    Adt28::C0(h2312, _, _, _, _) => {
                        h2312
                    }
                } {
                    let m2317 = match v1.clone() {
                        Adt22::C0(_, h2316, _, _, _, _, _, _, _, _) => {
                            h2316
                        }
                    };
                    if match m2317 {
                        Adt28::C0(_, h2315, _, _, _) => {
                            h2315
                        }
                    } {
                        let m2320 = match v1.clone() {
                            Adt22::C0(_, h2319, _, _, _, _, _, _, _, _) => {
                                h2319
                            }
                        };
                        if match m2320 {
                            Adt28::C0(_, _, h2318, _, _) => {
                                h2318
                            }
                        } {
                            let m2323 = match v1.clone() {
                                Adt22::C0(_, h2322, _, _, _, _, _, _, _, _) => {
                                    h2322
                                }
                            };
                            if match m2323 {
                                Adt28::C0(_, _, _, h2321, _) => {
                                    h2321
                                }
                            } {
                                match v1.clone() {
                                    Adt22::C0(_, _, h2324, _, _, _, _, _, _, _) => {
                                        h2324
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                } {
                    f114(match v1.clone() {
                        Adt22::C0(_, _, _, _, h2325, _, _, _, _, _) => {
                            h2325
                        }
                    }, false, f115(match v1 {
                        Adt22::C0(_, _, _, _, _, h2326, _, _, _, _) => {
                            h2326
                        }
                    }))
                } else {
                    Adt80::C2
                }
            } else {
                f116({
                    let m2329 = match v1.clone() {
                        Adt22::C0(_, h2328, _, _, _, _, _, _, _, _) => {
                            h2328
                        }
                    };
                    match m2329 {
                        Adt28::C0(h2327, _, _, _, _) => {
                            h2327
                        }
                    }
                }, {
                    let m2332 = match v1.clone() {
                        Adt22::C0(_, h2331, _, _, _, _, _, _, _, _) => {
                            h2331
                        }
                    };
                    match m2332 {
                        Adt28::C0(_, h2330, _, _, _) => {
                            h2330
                        }
                    }
                }, {
                    let m2335 = match v1.clone() {
                        Adt22::C0(_, h2334, _, _, _, _, _, _, _, _) => {
                            h2334
                        }
                    };
                    match m2335 {
                        Adt28::C0(_, _, h2333, _, _) => {
                            h2333
                        }
                    }
                }, match v1 {
                    Adt22::C0(_, _, h2336, _, _, _, _, _, _, _) => {
                        h2336
                    }
                }, false)
            }
        }
        Adt54::C4 => {
            let m2339 = match v1.clone() {
                Adt22::C0(_, h2338, _, _, _, _, _, _, _, _) => {
                    h2338
                }
            };
            if if match m2339 {
                Adt28::C0(h2337, _, _, _, _) => {
                    h2337
                }
            } {
                let m2342 = match v1.clone() {
                    Adt22::C0(_, h2341, _, _, _, _, _, _, _, _) => {
                        h2341
                    }
                };
                if match m2342 {
                    Adt28::C0(_, h2340, _, _, _) => {
                        h2340
                    }
                } {
                    let m2345 = match v1.clone() {
                        Adt22::C0(_, h2344, _, _, _, _, _, _, _, _) => {
                            h2344
                        }
                    };
                    if match m2345 {
                        Adt28::C0(_, _, h2343, _, _) => {
                            h2343
                        }
                    } {
                        if match v1.clone() {
                            Adt22::C0(_, _, h2346, _, _, _, _, _, _, _) => {
                                h2346
                            }
                        } {
                            if match v1.clone() {
                                Adt22::C0(_, _, _, h2347, _, _, _, _, _, _) => {
                                    h2347
                                }
                            } {
                                let m2350 = match v1.clone() {
                                    Adt22::C0(_, h2349, _, _, _, _, _, _, _, _) => {
                                        h2349
                                    }
                                };
                                match m2350 {
                                    Adt28::C0(_, _, _, h2348, _) => {
                                        h2348
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f114(match v1.clone() {
                    Adt22::C0(_, _, _, _, h2351, _, _, _, _, _) => {
                        h2351
                    }
                }, false, f115(match v1 {
                    Adt22::C0(_, _, _, _, _, h2352, _, _, _, _) => {
                        h2352
                    }
                }))
            } else {
                Adt80::C2
            }
        }
        Adt54::C5 => {
            if match v1 {
                Adt22::C0(_, _, _, _, _, _, _, h2353, _, _) => {
                    h2353
                }
            } {
                Adt80::C0
            } else {
                Adt80::C2
            }
        }
        Adt54::C6 => {
            Adt80::C0
        }
        Adt54::C7 => {
            Adt80::C0
        }
        Adt54::C8 => {
            Adt80::C0
        }
        Adt54::C9 => {
            Adt80::C0
        }
    }
}

pub fn f105(v0: Adt5) -> Result<Adt5, Adt44> {
    let m2355 = match v0.clone() {
        Adt5::C0(h2354, _, _, _, _) => {
            h2354
        }
    };
    match m2355 {
        Adt6::C0 => {
            if match v0.clone() {
                Adt5::C0(_, h2356, _, _, _) => {
                    h2356
                }
            } {
                Ok::<Adt5, Adt44>(Adt5::C0(Adt6::C2, match v0.clone() {
                    Adt5::C0(_, h2357, _, _, _) => {
                        h2357
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2358, _, _) => {
                        h2358
                    }
                }, true, match v0 {
                    Adt5::C0(_, _, _, _, h2359) => {
                        h2359
                    }
                }))
            } else {
                Err::<Adt5, Adt44>(Adt44::C3)
            }
        }
        Adt6::C1 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C2 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C3 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C4 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
    }
}

pub fn f106(v0: Adt9) -> bool {
    let m2360 = v0;
    match m2360 {
        Adt9::C0(_) => {
            true
        }
        Adt9::C1(_) => {
            false
        }
        Adt9::C2(_) => {
            false
        }
        Adt9::C3(v4) => {
            let m2362 = match v4 {
                Adt16::C0(_, h2361, _, _) => {
                    h2361
                }
            };
            match m2362 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt9::C4(_) => {
            true
        }
        Adt9::C5(_) => {
            false
        }
        Adt9::C6(_) => {
            false
        }
        Adt9::C7(v9) => {
            let m2364 = match v9 {
                Adt20::C0(_, _, h2363, _) => {
                    h2363
                }
            };
            match m2364 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt9::C8(_) => {
            false
        }
        Adt9::C9(_) => {
            false
        }
    }
}

pub fn f107(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m2365 = v0;
    match m2365 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a2370 = {
                let a2368 = v3;
                let a2369 = {
                    let a2366 = v1;
                    let a2367 = v2;
                    nat_add(a2366, a2367)?
                };
                nat_lt(a2368, a2369)
            };
            Ok(bool_not(a2370))
        }
    }
}

pub fn f108(v0: Adt24) -> R<u64> {
    let a2371 = f90(v0.clone())?;
    let a2372 = f91(v0)?;
    nat_add(a2371, a2372)
}

pub fn f109(v0: Adt14, v1: Adt46) -> Option<u64> {
    let m2373 = v1;
    match m2373 {
        Adt46::C0 => {
            match v0 {
                Adt14::C0(_, h2374, _, _, _) => {
                    h2374
                }
            }
        }
        Adt46::C1 => {
            match v0 {
                Adt14::C0(_, _, h2375, _, _) => {
                    h2375
                }
            }
        }
        Adt46::C2 => {
            match v0 {
                Adt14::C0(_, _, _, h2376, _) => {
                    h2376
                }
            }
        }
        Adt46::C3 => {
            match v0 {
                Adt14::C0(_, _, _, _, h2377) => {
                    h2377
                }
            }
        }
    }
}

pub fn f110(v0: Adt25, v1: Adt46) -> u64 {
    let m2378 = v1;
    match m2378 {
        Adt46::C0 => {
            match v0 {
                Adt25::C0(h2379, _, _, _) => {
                    h2379
                }
            }
        }
        Adt46::C1 => {
            match v0 {
                Adt25::C0(_, h2380, _, _) => {
                    h2380
                }
            }
        }
        Adt46::C2 => {
            match v0 {
                Adt25::C0(_, _, h2381, _) => {
                    h2381
                }
            }
        }
        Adt46::C3 => {
            match v0 {
                Adt25::C0(_, _, _, h2382) => {
                    h2382
                }
            }
        }
    }
}

pub fn f111(v0: Adt25, v1: Adt46, v2: u64) -> Adt25 {
    let m2383 = v1;
    match m2383 {
        Adt46::C0 => {
            Adt25::C0(v2, match v0.clone() {
                Adt25::C0(_, h2384, _, _) => {
                    h2384
                }
            }, match v0.clone() {
                Adt25::C0(_, _, h2385, _) => {
                    h2385
                }
            }, match v0 {
                Adt25::C0(_, _, _, h2386) => {
                    h2386
                }
            })
        }
        Adt46::C1 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2387, _, _, _) => {
                    h2387
                }
            }, v2, match v0.clone() {
                Adt25::C0(_, _, h2388, _) => {
                    h2388
                }
            }, match v0 {
                Adt25::C0(_, _, _, h2389) => {
                    h2389
                }
            })
        }
        Adt46::C2 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2390, _, _, _) => {
                    h2390
                }
            }, match v0.clone() {
                Adt25::C0(_, h2391, _, _) => {
                    h2391
                }
            }, v2, match v0 {
                Adt25::C0(_, _, _, h2392) => {
                    h2392
                }
            })
        }
        Adt46::C3 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2393, _, _, _) => {
                    h2393
                }
            }, match v0.clone() {
                Adt25::C0(_, h2394, _, _) => {
                    h2394
                }
            }, match v0 {
                Adt25::C0(_, _, h2395, _) => {
                    h2395
                }
            }, v2)
        }
    }
}

pub fn f112(v0: u64, v1: u64) -> u64 {
    let a2396 = v0;
    let a2397 = v1;
    if nat_lt(a2396, a2397) {
        v1
    } else {
        v0
    }
}

pub fn f113(v0: Adt24, v1: Adt24) -> bool {
    let a2404 = {
        let m2400 = match v0.clone() {
            Adt24::C0(h2399, _, _, _) => {
                h2399
            }
        };
        match m2400 {
            Adt25::C0(h2398, _, _, _) => {
                h2398
            }
        }
    };
    let a2405 = {
        let m2403 = match v1.clone() {
            Adt24::C0(h2402, _, _, _) => {
                h2402
            }
        };
        match m2403 {
            Adt25::C0(h2401, _, _, _) => {
                h2401
            }
        }
    };
    if nat_eq(a2404, a2405) {
        let a2412 = {
            let m2408 = match v0.clone() {
                Adt24::C0(h2407, _, _, _) => {
                    h2407
                }
            };
            match m2408 {
                Adt25::C0(_, h2406, _, _) => {
                    h2406
                }
            }
        };
        let a2413 = {
            let m2411 = match v1.clone() {
                Adt24::C0(h2410, _, _, _) => {
                    h2410
                }
            };
            match m2411 {
                Adt25::C0(_, h2409, _, _) => {
                    h2409
                }
            }
        };
        if nat_eq(a2412, a2413) {
            let a2420 = {
                let m2416 = match v0.clone() {
                    Adt24::C0(h2415, _, _, _) => {
                        h2415
                    }
                };
                match m2416 {
                    Adt25::C0(_, _, h2414, _) => {
                        h2414
                    }
                }
            };
            let a2421 = {
                let m2419 = match v1.clone() {
                    Adt24::C0(h2418, _, _, _) => {
                        h2418
                    }
                };
                match m2419 {
                    Adt25::C0(_, _, h2417, _) => {
                        h2417
                    }
                }
            };
            if nat_eq(a2420, a2421) {
                let a2428 = {
                    let m2424 = match v0.clone() {
                        Adt24::C0(h2423, _, _, _) => {
                            h2423
                        }
                    };
                    match m2424 {
                        Adt25::C0(_, _, _, h2422) => {
                            h2422
                        }
                    }
                };
                let a2429 = {
                    let m2427 = match v1.clone() {
                        Adt24::C0(h2426, _, _, _) => {
                            h2426
                        }
                    };
                    match m2427 {
                        Adt25::C0(_, _, _, h2425) => {
                            h2425
                        }
                    }
                };
                if nat_eq(a2428, a2429) {
                    let a2436 = {
                        let m2432 = match v0.clone() {
                            Adt24::C0(_, h2431, _, _) => {
                                h2431
                            }
                        };
                        match m2432 {
                            Adt25::C0(h2430, _, _, _) => {
                                h2430
                            }
                        }
                    };
                    let a2437 = {
                        let m2435 = match v1.clone() {
                            Adt24::C0(_, h2434, _, _) => {
                                h2434
                            }
                        };
                        match m2435 {
                            Adt25::C0(h2433, _, _, _) => {
                                h2433
                            }
                        }
                    };
                    if nat_eq(a2436, a2437) {
                        let a2444 = {
                            let m2440 = match v0.clone() {
                                Adt24::C0(_, h2439, _, _) => {
                                    h2439
                                }
                            };
                            match m2440 {
                                Adt25::C0(_, h2438, _, _) => {
                                    h2438
                                }
                            }
                        };
                        let a2445 = {
                            let m2443 = match v1.clone() {
                                Adt24::C0(_, h2442, _, _) => {
                                    h2442
                                }
                            };
                            match m2443 {
                                Adt25::C0(_, h2441, _, _) => {
                                    h2441
                                }
                            }
                        };
                        if nat_eq(a2444, a2445) {
                            let a2452 = {
                                let m2448 = match v0.clone() {
                                    Adt24::C0(_, h2447, _, _) => {
                                        h2447
                                    }
                                };
                                match m2448 {
                                    Adt25::C0(_, _, h2446, _) => {
                                        h2446
                                    }
                                }
                            };
                            let a2453 = {
                                let m2451 = match v1.clone() {
                                    Adt24::C0(_, h2450, _, _) => {
                                        h2450
                                    }
                                };
                                match m2451 {
                                    Adt25::C0(_, _, h2449, _) => {
                                        h2449
                                    }
                                }
                            };
                            if nat_eq(a2452, a2453) {
                                let a2460 = {
                                    let m2456 = match v0.clone() {
                                        Adt24::C0(_, h2455, _, _) => {
                                            h2455
                                        }
                                    };
                                    match m2456 {
                                        Adt25::C0(_, _, _, h2454) => {
                                            h2454
                                        }
                                    }
                                };
                                let a2461 = {
                                    let m2459 = match v1.clone() {
                                        Adt24::C0(_, h2458, _, _) => {
                                            h2458
                                        }
                                    };
                                    match m2459 {
                                        Adt25::C0(_, _, _, h2457) => {
                                            h2457
                                        }
                                    }
                                };
                                if nat_eq(a2460, a2461) {
                                    let a2464 = match v0.clone() {
                                        Adt24::C0(_, _, h2462, _) => {
                                            h2462
                                        }
                                    };
                                    let a2465 = match v1.clone() {
                                        Adt24::C0(_, _, h2463, _) => {
                                            h2463
                                        }
                                    };
                                    if nat_eq(a2464, a2465) {
                                        let a2468 = match v0 {
                                            Adt24::C0(_, _, _, h2466) => {
                                                h2466
                                            }
                                        };
                                        let a2469 = match v1 {
                                            Adt24::C0(_, _, _, h2467) => {
                                                h2467
                                            }
                                        };
                                        nat_eq(a2468, a2469)
                                    } else {
                                        false
                                    }
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f114(v0: Adt29, v1: bool, v2: Adt81) -> Adt80 {
    let m2470 = v0;
    match m2470 {
        Adt29::C0 => {
            if v1 {
                let m2471 = v2;
                if match m2471 {
                    Adt81::C0 => {
                        false
                    }
                    Adt81::C1 => {
                        true
                    }
                    Adt81::C2 => {
                        false
                    }
                    Adt81::C3 => {
                        false
                    }
                } {
                    Adt80::C0
                } else {
                    Adt80::C4
                }
            } else {
                Adt80::C0
            }
        }
        Adt29::C1 => {
            Adt80::C1
        }
        Adt29::C2 => {
            Adt80::C2
        }
        Adt29::C3 => {
            Adt80::C3
        }
    }
}

pub fn f115(v0: Adt30) -> Adt81 {
    let m2472 = v0;
    match m2472 {
        Adt30::C0 => {
            Adt81::C0
        }
        Adt30::C1(_) => {
            Adt81::C3
        }
        Adt30::C2(_) => {
            Adt81::C2
        }
        Adt30::C3(_) => {
            Adt81::C3
        }
        Adt30::C4(_) => {
            Adt81::C1
        }
    }
}

pub fn f116(v0: bool, v1: bool, v2: bool, v3: bool, v4: bool) -> Adt80 {
    if v4 {
        Adt80::C3
    } else {
        if if v0 {
            if v1 {
                if v2 {
                    if v3 {
                        let a2473 = v4;
                        bool_not(a2473)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        } {
            Adt80::C0
        } else {
            Adt80::C2
        }
    }
}
