#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt53, u64, Option<Adt55>, Adt56, List<Adt58>, Option<Adt60>),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, Adt2, Adt5, Adt8, Option<Adt9>, Option<Adt22>, Adt40, Option<Adt11>, bool, bool, Option<Adt41>, Option<Adt47>, Option<Adt11>, bool, bool, Adt48, Adt49, bool, Adt50, Option<Adt23>, List<Adt51>),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u64, u64, bool, bool, Adt3, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Adt6, bool, u64, bool, Adt7),
}

#[derive(Clone)]
pub enum Adt6 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt7 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, bool, bool, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(Adt10),
    C1(Adt15),
    C2(Adt15),
    C3(Adt16),
    C4(Adt17),
    C5(Adt18),
    C6(Adt19),
    C7(Adt20),
    C8(Adt21),
    C9(Adt21),
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt11 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt12 {
    C0(Adt13, Option<Adt11>),
}

#[derive(Clone)]
pub enum Adt13 {
    C0(u64, u64, u64, u64, Option<u64>, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt15 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt11, Option<Adt11>, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt17 {
    C0(Adt11, Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt19 {
    C0(Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt11, Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt23, Adt28, bool, bool, Adt29, Adt30, Adt32, bool, Option<Adt11>, Option<Adt33>),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, Adt24, Option<Adt26>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(Adt25, Adt25, u64, u64),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt26 {
    C0(Option<u64>, Option<u64>, Adt27, u64),
}

#[derive(Clone)]
pub enum Adt27 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt28 {
    C0(bool, bool, bool, bool, bool),
}

#[derive(Clone)]
pub enum Adt29 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt30 {
    C0,
    C1(Adt31),
    C2(Adt31),
    C3(Adt31),
    C4(Adt31),
}

#[derive(Clone)]
pub enum Adt31 {
    C0(Bytes, Adt11, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt32 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt33 {
    C0(Adt34),
    C1(Adt34),
    C2(Adt34),
    C3(u64),
    C4(Adt35),
    C5(Adt36),
    C6(Adt37),
    C7(Adt39),
}

#[derive(Clone)]
pub enum Adt34 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt35 {
    C0(Bytes, u64, u64),
}

#[derive(Clone)]
pub enum Adt36 {
    C0(Adt11, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt37 {
    C0(Adt38, Adt38, bool),
}

#[derive(Clone)]
pub enum Adt38 {
    C0(Adt23, Adt28, bool, Adt30),
}

#[derive(Clone)]
pub enum Adt39 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt40 {
    C0(u64, u64, u64, u64, u64, Str),
}

#[derive(Clone)]
pub enum Adt41 {
    C0(u64, Str),
    C1(u64, Str),
    C2(Bytes),
    C3(Bytes),
    C4,
    C5,
    C6(Adt42, u64),
    C7,
    C8(Str),
    C9(Adt7, Str),
    C10(Adt43),
    C11(Adt44),
    C12,
    C13,
    C14(Str),
    C15(Str),
    C16(Adt45),
}

#[derive(Clone)]
pub enum Adt42 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt43 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
    C12,
    C13,
    C14,
    C15,
    C16,
    C17,
}

#[derive(Clone)]
pub enum Adt44 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt45 {
    C0(u64, u64, u64),
    C1(Adt46, u64, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64, u64),
}

#[derive(Clone)]
pub enum Adt46 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt47 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt48 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt49 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt50 {
    C0(Adt24, Option<Adt45>),
}

#[derive(Clone)]
pub enum Adt51 {
    C0(Adt52, Adt14, Adt50, Option<Adt23>),
}

#[derive(Clone)]
pub enum Adt52 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt53 {
    C0(Adt54, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt54 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
}

#[derive(Clone)]
pub enum Adt55 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt56 {
    C0(u64, Adt57),
}

#[derive(Clone)]
pub enum Adt57 {
    C0(Adt55),
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt58 {
    C0(Adt55, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt59 {
    C0(u64, Str, Option<u64>),
}

#[derive(Clone)]
pub enum Adt60 {
    C0(Adt55, Adt52, u64, Adt11, List<Adt59>, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt61 {
    C0(u64),
    C1(Adt52),
    C2(Adt52, Adt40),
    C3(Adt52, Adt11),
    C4(Adt52, Adt22),
    C5(Adt52, Adt62),
    C6(Adt52, Adt47),
    C7(Adt52, Adt7),
    C8(Adt52, u64),
    C9(Adt52, Adt63),
    C10(Adt52, Adt63),
    C11(Adt52),
}

#[derive(Clone)]
pub enum Adt62 {
    C0(Adt41, Adt23, Adt7),
}

#[derive(Clone)]
pub enum Adt63 {
    C0(Adt46, u64),
    C1(Adt46, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64),
    C4(Adt46, u64),
}

#[derive(Clone)]
pub enum Adt64 {
    C0(Adt0, List<Adt65>),
}

#[derive(Clone)]
pub enum Adt65 {
    C0(Adt66),
    C1(Adt55, Adt52, u64),
    C2(Adt60),
    C3(Adt60),
}

#[derive(Clone)]
pub enum Adt66 {
    C0(Adt52, Adt9),
    C1(Adt52, Adt67),
    C2(Adt52, u64),
    C3(Adt52, u64),
    C4(Adt52),
    C5(Adt52),
    C6(Adt11),
    C7(Adt52, Adt11),
    C8(u64),
    C9(Adt52),
}

#[derive(Clone)]
pub enum Adt67 {
    C0(u64),
    C1(Adt68),
    C2(u64),
    C3,
}

#[derive(Clone)]
pub enum Adt68 {
    C0(Adt11, u64, u64),
}

#[derive(Clone)]
pub enum Adt69 {
    C0(Adt9),
    C1,
    C2,
    C3(Adt48),
    C4,
    C5,
    C6,
    C7,
    C8(u64),
    C9(Adt52),
    C10(Adt52, Adt67),
    C11(u64),
    C12(Adt52, Adt40),
    C13(Adt52, Adt11),
    C14(u64),
    C15(Adt52, Adt22),
    C16(Adt52, Adt62),
    C17(Adt52, Adt47),
    C18,
    C19(Adt52, Adt7),
    C20,
    C21(Adt52, u64),
    C22(Adt52, Adt63),
    C23(Adt52, Adt63),
    C24(Adt52),
}

#[derive(Clone)]
pub enum Adt70 {
    C0(Adt1, List<Adt66>),
}

#[derive(Clone)]
pub enum Adt71 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt72 {
    C0(Adt73, Adt5),
    C1(Adt44),
}

#[derive(Clone)]
pub enum Adt73 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt74 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt75 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt76 {
    C0,
    C1,
    C2,
    C3,
}

pub fn f0(v0: Adt0, v1: Adt61) -> R<Adt64> {
    f1(v0.clone(), v1.clone(), {
        let m1 = v1;
        match m1 {
            Adt61::C0(v2) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h2, _, _, _, _, _) => {
                        h2
                    }
                }, f3(match v0 {
                    Adt0::C0(h3, _, _, _, _, _, _) => {
                        h3
                    }
                }, Adt69::C8(v2))?)
            }
            Adt61::C1(v3) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h4, _, _, _, _, _) => {
                        h4
                    }
                }, f3(match v0 {
                    Adt0::C0(h5, _, _, _, _, _, _) => {
                        h5
                    }
                }, Adt69::C9(v3))?)
            }
            Adt61::C2(v4, v5) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h6, _, _, _, _, _) => {
                        h6
                    }
                }, f3(match v0 {
                    Adt0::C0(h7, _, _, _, _, _, _) => {
                        h7
                    }
                }, Adt69::C12(v4, v5))?)
            }
            Adt61::C3(v6, v7) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h8, _, _, _, _, _) => {
                        h8
                    }
                }, f3(match v0 {
                    Adt0::C0(h9, _, _, _, _, _, _) => {
                        h9
                    }
                }, Adt69::C13(v6, v7))?)
            }
            Adt61::C4(v8, v9) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h10, _, _, _, _, _) => {
                        h10
                    }
                }, f3(match v0 {
                    Adt0::C0(h11, _, _, _, _, _, _) => {
                        h11
                    }
                }, Adt69::C15(v8, v9))?)
            }
            Adt61::C5(v10, v11) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h12, _, _, _, _, _) => {
                        h12
                    }
                }, f3(match v0 {
                    Adt0::C0(h13, _, _, _, _, _, _) => {
                        h13
                    }
                }, Adt69::C16(v10, v11))?)
            }
            Adt61::C6(v12, v13) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h14, _, _, _, _, _) => {
                        h14
                    }
                }, f3(match v0 {
                    Adt0::C0(h15, _, _, _, _, _, _) => {
                        h15
                    }
                }, Adt69::C17(v12, v13))?)
            }
            Adt61::C7(v14, v15) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h16, _, _, _, _, _) => {
                        h16
                    }
                }, f3(match v0 {
                    Adt0::C0(h17, _, _, _, _, _, _) => {
                        h17
                    }
                }, Adt69::C19(v14, v15))?)
            }
            Adt61::C8(v16, v17) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h18, _, _, _, _, _) => {
                        h18
                    }
                }, f3(match v0 {
                    Adt0::C0(h19, _, _, _, _, _, _) => {
                        h19
                    }
                }, Adt69::C21(v16, v17))?)
            }
            Adt61::C9(v18, v19) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h20, _, _, _, _, _) => {
                        h20
                    }
                }, f3(match v0 {
                    Adt0::C0(h21, _, _, _, _, _, _) => {
                        h21
                    }
                }, Adt69::C22(v18, v19))?)
            }
            Adt61::C10(v20, v21) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h22, _, _, _, _, _) => {
                        h22
                    }
                }, f3(match v0 {
                    Adt0::C0(h23, _, _, _, _, _, _) => {
                        h23
                    }
                }, Adt69::C23(v20, v21))?)
            }
            Adt61::C11(v22) => {
                f2(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h24, _, _, _, _, _) => {
                        h24
                    }
                }, f3(match v0 {
                    Adt0::C0(h25, _, _, _, _, _, _) => {
                        h25
                    }
                }, Adt69::C24(v22))?)
            }
        }
    })
}

pub fn f1(v0: Adt0, v1: Adt61, v2: Adt64) -> R<Adt64> {
    let m26 = v1;
    match m26 {
        Adt61::C0(_) => {
            Ok(v2)
        }
        Adt61::C1(_) => {
            Ok(v2)
        }
        Adt61::C2(_, _) => {
            Ok(v2)
        }
        Adt61::C3(_, _) => {
            Ok(v2)
        }
        Adt61::C4(v9, _) => {
            if f4(match v0.clone() {
                Adt0::C0(h27, _, _, _, _, _, _) => {
                    h27
                }
            }, v9) {
                let m33 = {
                    let m32 = {
                        let m31 = match v2.clone() {
                            Adt64::C0(h30, _) => {
                                h30
                            }
                        };
                        match m31 {
                            Adt0::C0(h29, _, _, _, _, _, _) => {
                                h29
                            }
                        }
                    };
                    match m32 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, h28, _, _, _, _, _, _, _, _, _, _) => {
                            h28
                        }
                    }
                };
                if match m33 {
                    None => {
                        let m39 = {
                            let m38 = {
                                let m37 = match v2.clone() {
                                    Adt64::C0(h36, _) => {
                                        h36
                                    }
                                };
                                match m37 {
                                    Adt0::C0(h35, _, _, _, _, _, _) => {
                                        h35
                                    }
                                }
                            };
                            match m38 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h34, _, _, _, _, _, _, _, _, _) => {
                                    h34
                                }
                            }
                        };
                        match m39 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    }
                    Some(_) => {
                        true
                    }
                } {
                    f5(v0, v2, Adt57::C4)
                } else {
                    f5(v0, v2, Adt57::C3)
                }
            } else {
                Ok(v2)
            }
        }
        Adt61::C5(v13, _) => {
            if if f6(match v0.clone() {
                Adt0::C0(h40, _, _, _, _, _, _) => {
                    h40
                }
            }, v13) {
                let m43 = match v0.clone() {
                    Adt0::C0(h42, _, _, _, _, _, _) => {
                        h42
                    }
                };
                if match m43 {
                    Adt1::C0(_, _, _, _, _, _, _, _, h41, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h41
                    }
                } {
                    true
                } else {
                    let m48 = {
                        let m47 = match v0.clone() {
                            Adt0::C0(h46, _, _, _, _, _, _) => {
                                h46
                            }
                        };
                        match m47 {
                            Adt1::C0(_, h45, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h45
                            }
                        }
                    };
                    match m48 {
                        Adt2::C0(_, _, h44, _, _, _) => {
                            h44
                        }
                    }
                }
            } else {
                false
            } {
                let m54 = {
                    let m53 = {
                        let m52 = match v2.clone() {
                            Adt64::C0(h51, _) => {
                                h51
                            }
                        };
                        match m52 {
                            Adt0::C0(h50, _, _, _, _, _, _) => {
                                h50
                            }
                        }
                    };
                    match m53 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, h49, _, _, _, _, _, _, _, _, _, _) => {
                            h49
                        }
                    }
                };
                if match m54 {
                    None => {
                        let m60 = {
                            let m59 = {
                                let m58 = match v2.clone() {
                                    Adt64::C0(h57, _) => {
                                        h57
                                    }
                                };
                                match m58 {
                                    Adt0::C0(h56, _, _, _, _, _, _) => {
                                        h56
                                    }
                                }
                            };
                            match m59 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h55, _, _, _, _, _, _, _, _, _) => {
                                    h55
                                }
                            }
                        };
                        match m60 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    }
                    Some(_) => {
                        true
                    }
                } {
                    f5(v0, v2, Adt57::C4)
                } else {
                    f5(v0, v2, Adt57::C3)
                }
            } else {
                Ok(v2)
            }
        }
        Adt61::C6(v17, _) => {
            if f4(match v0.clone() {
                Adt0::C0(h61, _, _, _, _, _, _) => {
                    h61
                }
            }, v17) {
                let m67 = {
                    let m66 = {
                        let m65 = match v2.clone() {
                            Adt64::C0(h64, _) => {
                                h64
                            }
                        };
                        match m65 {
                            Adt0::C0(h63, _, _, _, _, _, _) => {
                                h63
                            }
                        }
                    };
                    match m66 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, h62, _, _, _, _, _, _, _, _, _, _) => {
                            h62
                        }
                    }
                };
                if match m67 {
                    None => {
                        let m73 = {
                            let m72 = {
                                let m71 = match v2.clone() {
                                    Adt64::C0(h70, _) => {
                                        h70
                                    }
                                };
                                match m71 {
                                    Adt0::C0(h69, _, _, _, _, _, _) => {
                                        h69
                                    }
                                }
                            };
                            match m72 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h68, _, _, _, _, _, _, _, _, _) => {
                                    h68
                                }
                            }
                        };
                        match m73 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    }
                    Some(_) => {
                        true
                    }
                } {
                    f5(v0, v2, Adt57::C4)
                } else {
                    f5(v0, v2, Adt57::C3)
                }
            } else {
                Ok(v2)
            }
        }
        Adt61::C7(v21, _) => {
            if if f6(match v0.clone() {
                Adt0::C0(h74, _, _, _, _, _, _) => {
                    h74
                }
            }, v21) {
                let m77 = match v0.clone() {
                    Adt0::C0(h76, _, _, _, _, _, _) => {
                        h76
                    }
                };
                match m77 {
                    Adt1::C0(_, _, _, _, _, _, _, _, h75, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h75
                    }
                }
            } else {
                false
            } {
                let m83 = {
                    let m82 = {
                        let m81 = match v2.clone() {
                            Adt64::C0(h80, _) => {
                                h80
                            }
                        };
                        match m81 {
                            Adt0::C0(h79, _, _, _, _, _, _) => {
                                h79
                            }
                        }
                    };
                    match m82 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, h78, _, _, _, _, _, _, _, _, _, _) => {
                            h78
                        }
                    }
                };
                if match m83 {
                    None => {
                        let m89 = {
                            let m88 = {
                                let m87 = match v2.clone() {
                                    Adt64::C0(h86, _) => {
                                        h86
                                    }
                                };
                                match m87 {
                                    Adt0::C0(h85, _, _, _, _, _, _) => {
                                        h85
                                    }
                                }
                            };
                            match m88 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h84, _, _, _, _, _, _, _, _, _) => {
                                    h84
                                }
                            }
                        };
                        match m89 {
                            None => {
                                false
                            }
                            Some(_) => {
                                true
                            }
                        }
                    }
                    Some(_) => {
                        true
                    }
                } {
                    f5(v0, v2, Adt57::C4)
                } else {
                    f5(v0, v2, Adt57::C3)
                }
            } else {
                Ok(v2)
            }
        }
        Adt61::C8(_, _) => {
            Ok(v2)
        }
        Adt61::C9(v27, _) => {
            if if f6(match v0.clone() {
                Adt0::C0(h90, _, _, _, _, _, _) => {
                    h90
                }
            }, v27) {
                let m94 = {
                    let m93 = match v0.clone() {
                        Adt0::C0(h92, _, _, _, _, _, _) => {
                            h92
                        }
                    };
                    match m93 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, h91, _, _, _, _, _, _, _, _, _, _) => {
                            h91
                        }
                    }
                };
                if match m94 {
                    None => {
                        true
                    }
                    Some(_) => {
                        false
                    }
                } {
                    let m100 = {
                        let m99 = {
                            let m98 = match v2.clone() {
                                Adt64::C0(h97, _) => {
                                    h97
                                }
                            };
                            match m98 {
                                Adt0::C0(h96, _, _, _, _, _, _) => {
                                    h96
                                }
                            }
                        };
                        match m99 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h95, _, _, _, _, _, _, _, _, _, _) => {
                                h95
                            }
                        }
                    };
                    match m100 {
                        None => {
                            let m106 = {
                                let m105 = {
                                    let m104 = match v2.clone() {
                                        Adt64::C0(h103, _) => {
                                            h103
                                        }
                                    };
                                    match m104 {
                                        Adt0::C0(h102, _, _, _, _, _, _) => {
                                            h102
                                        }
                                    }
                                };
                                match m105 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h101, _, _, _, _, _, _, _, _, _) => {
                                        h101
                                    }
                                }
                            };
                            match m106 {
                                None => {
                                    false
                                }
                                Some(_) => {
                                    true
                                }
                            }
                        }
                        Some(_) => {
                            true
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f5(v0, v2, Adt57::C4)
            } else {
                Ok(v2)
            }
        }
        Adt61::C10(_, _) => {
            Ok(v2)
        }
        Adt61::C11(_) => {
            Ok(v2)
        }
    }
}

pub fn f2(v0: Adt0, v1: Adt53, v2: Adt70) -> Adt64 {
    Adt64::C0(Adt0::C0(match v2.clone() {
        Adt70::C0(h107, _) => {
            h107
        }
    }, v1, match v0.clone() {
        Adt0::C0(_, _, h108, _, _, _, _) => {
            h108
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, h109, _, _, _) => {
            h109
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, h110, _, _) => {
            h110
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, _, h111, _) => {
            h111
        }
    }, match v0 {
        Adt0::C0(_, _, _, _, _, _, h112) => {
            h112
        }
    }), f7(match v2 {
        Adt70::C0(_, h113) => {
            h113
        }
    }))
}

pub fn f3(v0: Adt1, v1: Adt69) -> R<Adt70> {
    let m114 = v1;
    match m114 {
        Adt69::C0(v2) => {
            f8(v0, v2)
        }
        Adt69::C1 => {
            f9(v0.clone(), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h115, _, _, _, _, _, _, _) => {
                    h115
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h116, _, _, _, _, _, _) => {
                    h116
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h117, _, _, _, _, _) => {
                    h117
                }
            })
        }
        Adt69::C2 => {
            f10(v0)
        }
        Adt69::C3(v3) => {
            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h118, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h118
                }
            }, match v0.clone() {
                Adt1::C0(_, h119, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h119
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h120, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h120
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h121, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h121
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h122, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h122
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h123, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h123
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h124, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h124
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h125, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h125
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h126, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h126
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h127, _, _, _, _, _, _, _, _, _, _, _) => {
                    h127
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h128, _, _, _, _, _, _, _, _, _, _) => {
                    h128
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h129, _, _, _, _, _, _, _, _, _) => {
                    h129
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h130, _, _, _, _, _, _, _, _) => {
                    h130
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h131, _, _, _, _, _, _, _) => {
                    h131
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h132, _, _, _, _, _, _) => {
                    h132
                }
            }, v3, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h133, _, _, _, _) => {
                    h133
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h134, _, _, _) => {
                    h134
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h135, _, _) => {
                    h135
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h136, _) => {
                    h136
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h137) => {
                    h137
                }
            }), List::<Adt66>::nil()))
        }
        Adt69::C4 => {
            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h138, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h138
                }
            }, match v0.clone() {
                Adt1::C0(_, h139, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h139
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h140, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h140
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h141, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h141
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h142, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h142
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h143, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h143
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h144, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h144
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h145, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h145
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h146, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h146
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h147, _, _, _, _, _, _, _, _, _, _, _) => {
                    h147
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h148, _, _, _, _, _, _, _, _, _, _) => {
                    h148
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h149, _, _, _, _, _, _, _, _, _) => {
                    h149
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h150, _, _, _, _, _, _, _, _) => {
                    h150
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h151, _, _, _, _, _, _, _) => {
                    h151
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h152, _, _, _, _, _, _) => {
                    h152
                }
            }, Adt48::C0, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h153, _, _, _, _) => {
                    h153
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h154, _, _, _) => {
                    h154
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h155, _, _) => {
                    h155
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h156, _) => {
                    h156
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h157) => {
                    h157
                }
            }), List::<Adt66>::nil()))
        }
        Adt69::C5 => {
            if match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h158, _, _, _, _, _, _, _) => {
                    h158
                }
            } {
                f9(v0.clone(), false, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h159, _, _, _, _, _, _) => {
                        h159
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h160, _, _, _, _, _) => {
                        h160
                    }
                })
            } else {
                Ok(Adt70::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt69::C6 => {
            f11(v0)
        }
        Adt69::C7 => {
            f11(v0)
        }
        Adt69::C8(v4) => {
            let a162 = match v0.clone() {
                Adt1::C0(h161, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h161
                }
            };
            let a163 = v4;
            if nat_eq(a162, a163) {
                Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h164, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h164
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h165, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h165
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h166, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h166
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h167, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h167
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h168, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h168
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h169, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h169
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h170, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h170
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h171, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h171
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h172, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h172
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h173, _, _, _, _, _, _, _, _, _, _, _) => {
                        h173
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h174, _, _, _, _, _, _, _, _, _, _) => {
                        h174
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h175, _, _, _, _, _, _, _, _, _) => {
                        h175
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h176, _, _, _, _, _, _, _, _) => {
                        h176
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h177, _, _, _, _, _, _, _) => {
                        h177
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h178, _, _, _, _, _, _) => {
                        h178
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h179, _, _, _, _, _) => {
                        h179
                    }
                }, Adt49::C2, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h180, _, _, _) => {
                        h180
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h181, _, _) => {
                        h181
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h182, _) => {
                        h182
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h183) => {
                        h183
                    }
                }), List::<Adt66>::nil()))
            } else {
                Ok(Adt70::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt69::C9(v5) => {
            Ok(f12(v0, v5))
        }
        Adt69::C10(v6, v7) => {
            f13(v0, v6, v7)
        }
        Adt69::C11(v8) => {
            let m186 = match v0.clone() {
                Adt1::C0(_, h185, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h185
                }
            };
            if match m186 {
                Adt2::C0(_, _, h184, _, _, _) => {
                    h184
                }
            } {
                Ok(Adt70::C0(v0.clone(), List::cons(Adt66::C2(f14(v0), v8), List::<Adt66>::nil())))
            } else {
                Ok(Adt70::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt69::C12(v9, v10) => {
            if f4(v0.clone(), v9) {
                Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h187, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h187
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h188, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h188
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h189, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h189
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h190, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h190
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h191, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h191
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h192, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h192
                    }
                }, v10, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h193, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h193
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h194, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h194
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h195, _, _, _, _, _, _, _, _, _, _, _) => {
                        h195
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h196, _, _, _, _, _, _, _, _, _, _) => {
                        h196
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h197, _, _, _, _, _, _, _, _, _) => {
                        h197
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h198, _, _, _, _, _, _, _, _) => {
                        h198
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h199, _, _, _, _, _, _, _) => {
                        h199
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h200, _, _, _, _, _, _) => {
                        h200
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h201, _, _, _, _, _) => {
                        h201
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h202, _, _, _, _) => {
                        h202
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h203, _, _, _) => {
                        h203
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h204, _, _) => {
                        h204
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h205, _) => {
                        h205
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h206) => {
                        h206
                    }
                }), List::<Adt66>::nil()))
            } else {
                Ok(Adt70::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt69::C13(v11, v12) => {
            if if f4(v0.clone(), v11) {
                let a209 = match v12.clone() {
                    Adt11::C0(h207, _, _) => {
                        h207
                    }
                };
                let a210 = match v0.clone() {
                    Adt1::C0(h208, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h208
                    }
                };
                nat_eq(a209, a210)
            } else {
                false
            } {
                Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h211, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h211
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h212, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h212
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h213, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h213
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h214, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h214
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h215, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h215
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h216, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h216
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h217, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h217
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h218, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h218
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h219, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h219
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h220, _, _, _, _, _, _, _, _, _, _, _) => {
                        h220
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h221, _, _, _, _, _, _, _, _, _, _) => {
                        h221
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h222, _, _, _, _, _, _, _, _, _) => {
                        h222
                    }
                }, Some(v12), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h223, _, _, _, _, _, _, _) => {
                        h223
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h224, _, _, _, _, _, _) => {
                        h224
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h225, _, _, _, _, _) => {
                        h225
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h226, _, _, _, _) => {
                        h226
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h227, _, _, _) => {
                        h227
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h228, _, _) => {
                        h228
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h229, _) => {
                        h229
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h230) => {
                        h230
                    }
                }), f15(match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h231, _, _, _, _, _, _, _, _) => {
                        h231
                    }
                })))
            } else {
                Ok(Adt70::C0(v0, List::cons(Adt66::C6(v12), List::<Adt66>::nil())))
            }
        }
        Adt69::C14(v13) => {
            Ok(f16(v0, v13))
        }
        Adt69::C15(v14, v15) => {
            f17(v0, v14, v15)
        }
        Adt69::C16(v16, v17) => {
            Ok(f18(v0, v16, v17))
        }
        Adt69::C17(v18, v19) => {
            if f4(v0.clone(), v18.clone()) {
                Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h232, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h232
                    }
                }, f19(match v0.clone() {
                    Adt1::C0(_, h233, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h233
                    }
                }), f20(match v0.clone() {
                    Adt1::C0(_, _, h234, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h234
                    }
                }, Adt7::C3), match v0.clone() {
                    Adt1::C0(_, _, _, h235, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h235
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h236, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h236
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h237, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h237
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h238, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h238
                    }
                }, None::<Adt11>, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h239, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h239
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h240, _, _, _, _, _, _, _, _, _, _, _) => {
                        h240
                    }
                }, None::<Adt41>, Some(v19), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h241, _, _, _, _, _, _, _, _) => {
                        h241
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h242, _, _, _, _, _, _, _) => {
                        h242
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h243, _, _, _, _, _, _) => {
                        h243
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h244, _, _, _, _, _) => {
                        h244
                    }
                }, Adt49::C1, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h245, _, _, _) => {
                        h245
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h246, _, _) => {
                        h246
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h247, _) => {
                        h247
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h248) => {
                        h248
                    }
                }), List::cons(Adt66::C4(v18.clone()), List::cons(Adt66::C5(v18), List::<Adt66>::nil()))))
            } else {
                Ok(Adt70::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt69::C18 => {
            Ok(f21(v0))
        }
        Adt69::C19(v20, v21) => {
            Ok(f22(v0, v20, v21))
        }
        Adt69::C20 => {
            Ok(f21(v0))
        }
        Adt69::C21(v22, v23) => {
            f23(v0, v22, v23)
        }
        Adt69::C22(v24, v25) => {
            f24(v0, v24, v25)
        }
        Adt69::C23(v26, v27) => {
            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h249, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h249
                }
            }, match v0.clone() {
                Adt1::C0(_, h250, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h250
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h251, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h251
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h252, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h252
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h253, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h253
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h254, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h254
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h255, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h255
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h256, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h256
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h257, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h257
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h258, _, _, _, _, _, _, _, _, _, _, _) => {
                    h258
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h259, _, _, _, _, _, _, _, _, _, _) => {
                    h259
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h260, _, _, _, _, _, _, _, _, _) => {
                    h260
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h261, _, _, _, _, _, _, _, _) => {
                    h261
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h262, _, _, _, _, _, _, _) => {
                    h262
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h263, _, _, _, _, _, _) => {
                    h263
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h264, _, _, _, _, _) => {
                    h264
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h265, _, _, _, _) => {
                    h265
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h266, _, _, _) => {
                    h266
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h267, _, _) => {
                    h267
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h268, _) => {
                    h268
                }
            }, f25(match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h269) => {
                    h269
                }
            }, v26, v27)?), List::<Adt66>::nil()))
        }
        Adt69::C24(v28) => {
            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h270, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h270
                }
            }, match v0.clone() {
                Adt1::C0(_, h271, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h271
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h272, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h272
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h273, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h273
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h274, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h274
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h275, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h275
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h276, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h276
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h277, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h277
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h278, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h278
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h279, _, _, _, _, _, _, _, _, _, _, _) => {
                    h279
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h280, _, _, _, _, _, _, _, _, _, _) => {
                    h280
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h281, _, _, _, _, _, _, _, _, _) => {
                    h281
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h282, _, _, _, _, _, _, _, _) => {
                    h282
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h283, _, _, _, _, _, _, _) => {
                    h283
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h284, _, _, _, _, _, _) => {
                    h284
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h285, _, _, _, _, _) => {
                    h285
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h286, _, _, _, _) => {
                    h286
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h287, _, _, _) => {
                    h287
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h288, _, _) => {
                    h288
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h289, _) => {
                    h289
                }
            }, f26(match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h290) => {
                    h290
                }
            }, v28)?), List::<Adt66>::nil()))
        }
    }
}

pub fn f4(v0: Adt1, v1: Adt52) -> bool {
    let a293 = match v0.clone() {
        Adt1::C0(h291, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h291
        }
    };
    let a294 = match v1.clone() {
        Adt52::C0(h292, _, _) => {
            h292
        }
    };
    if nat_eq(a293, a294) {
        if match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h295, _, _, _, _, _, _, _) => {
                h295
            }
        } {
            let a297 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h296, _, _, _, _, _, _) => {
                    h296
                }
            };
            if bool_not(a297) {
                f27(match v0 {
                    Adt1::C0(_, h298, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h298
                    }
                }, match v1.clone() {
                    Adt52::C0(_, h299, _) => {
                        h299
                    }
                }, match v1 {
                    Adt52::C0(_, _, h300) => {
                        h300
                    }
                })
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f5(v0: Adt0, v1: Adt64, v2: Adt57) -> R<Adt64> {
    Ok(Adt64::C0(Adt0::C0({
        let m303 = match v1.clone() {
            Adt64::C0(h302, _) => {
                h302
            }
        };
        match m303 {
            Adt0::C0(h301, _, _, _, _, _, _) => {
                h301
            }
        }
    }, {
        let m306 = match v1.clone() {
            Adt64::C0(h305, _) => {
                h305
            }
        };
        match m306 {
            Adt0::C0(_, h304, _, _, _, _, _) => {
                h304
            }
        }
    }, {
        let m309 = match v1.clone() {
            Adt64::C0(h308, _) => {
                h308
            }
        };
        match m309 {
            Adt0::C0(_, _, h307, _, _, _, _) => {
                h307
            }
        }
    }, {
        let m312 = match v1.clone() {
            Adt64::C0(h311, _) => {
                h311
            }
        };
        match m312 {
            Adt0::C0(_, _, _, h310, _, _, _) => {
                h310
            }
        }
    }, Adt56::C0({
        let a316 = {
            let m315 = match v0 {
                Adt0::C0(_, _, _, _, h314, _, _) => {
                    h314
                }
            };
            match m315 {
                Adt56::C0(h313, _) => {
                    h313
                }
            }
        };
        let a317 = 1u64;
        nat_add(a316, a317)?
    }, v2), {
        let m320 = match v1.clone() {
            Adt64::C0(h319, _) => {
                h319
            }
        };
        match m320 {
            Adt0::C0(_, _, _, _, _, h318, _) => {
                h318
            }
        }
    }, {
        let m323 = match v1.clone() {
            Adt64::C0(h322, _) => {
                h322
            }
        };
        match m323 {
            Adt0::C0(_, _, _, _, _, _, h321) => {
                h321
            }
        }
    }), match v1 {
        Adt64::C0(_, h324) => {
            h324
        }
    }))
}

pub fn f6(v0: Adt1, v1: Adt52) -> bool {
    let a327 = match v0.clone() {
        Adt1::C0(h325, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h325
        }
    };
    let a328 = match v1.clone() {
        Adt52::C0(h326, _, _) => {
            h326
        }
    };
    if nat_eq(a327, a328) {
        let a333 = {
            let m331 = match v0.clone() {
                Adt1::C0(_, h330, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h330
                }
            };
            match m331 {
                Adt2::C0(_, h329, _, _, _, _) => {
                    h329
                }
            }
        };
        let a334 = match v1.clone() {
            Adt52::C0(_, h332, _) => {
                h332
            }
        };
        if nat_eq(a333, a334) {
            let a339 = {
                let m337 = match v0.clone() {
                    Adt1::C0(_, h336, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h336
                    }
                };
                match m337 {
                    Adt2::C0(h335, _, _, _, _, _) => {
                        h335
                    }
                }
            };
            let a340 = match v1 {
                Adt52::C0(_, _, h338) => {
                    h338
                }
            };
            if nat_eq(a339, a340) {
                if match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h341, _, _, _, _, _, _, _) => {
                        h341
                    }
                } {
                    let a343 = match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h342, _, _, _, _, _, _) => {
                            h342
                        }
                    };
                    bool_not(a343)
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f7(v0: List<Adt66>) -> List<Adt65> {
    let m344 = v0;
    match m344.uncons() {
        None => {
            List::<Adt65>::nil()
        }
        Some((v1, v2)) => {
            List::cons(Adt65::C0(v1), f7(v2))
        }
    }
}

pub fn f8(v0: Adt1, v1: Adt9) -> R<Adt70> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h345, _, _, _, _, _, _) => {
            h345
        }
    } {
        Ok(Adt70::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h346, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h346
            }
        }, match v0.clone() {
            Adt1::C0(_, h347, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h347
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h348, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h348
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h349, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h349
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h350, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h350
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h351, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h351
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h352, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h352
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h353, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h353
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h354, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h354
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h355, _, _, _, _, _, _, _, _, _, _, _) => {
                h355
            }
        }, Some(Adt41::C10(Adt43::C1)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h356, _, _, _, _, _, _, _, _, _) => {
                h356
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h357, _, _, _, _, _, _, _, _) => {
                h357
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h358, _, _, _, _, _, _, _) => {
                h358
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h359, _, _, _, _, _, _) => {
                h359
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h360, _, _, _, _, _) => {
                h360
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h361, _, _, _, _) => {
                h361
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h362, _, _, _) => {
                h362
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h363, _, _) => {
                h363
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h364, _) => {
                h364
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h365) => {
                h365
            }
        }), List::<Adt66>::nil()))
    } else {
        let a367 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h366, _, _, _, _, _, _, _) => {
                h366
            }
        };
        if bool_not(a367) {
            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h368, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h368
                }
            }, match v0.clone() {
                Adt1::C0(_, h369, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h369
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h370, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h370
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h371, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h371
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h372, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h372
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h373, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h373
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h374, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h374
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h375, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h375
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h376, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h376
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h377, _, _, _, _, _, _, _, _, _, _, _) => {
                    h377
                }
            }, Some(Adt41::C10(Adt43::C2)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h378, _, _, _, _, _, _, _, _, _) => {
                    h378
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h379, _, _, _, _, _, _, _, _) => {
                    h379
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h380, _, _, _, _, _, _, _) => {
                    h380
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h381, _, _, _, _, _, _) => {
                    h381
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h382, _, _, _, _, _) => {
                    h382
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h383, _, _, _, _) => {
                    h383
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h384, _, _, _) => {
                    h384
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h385, _, _) => {
                    h385
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h386, _) => {
                    h386
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h387) => {
                    h387
                }
            }), List::<Adt66>::nil()))
        } else {
            let m390 = match v0.clone() {
                Adt1::C0(_, h389, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h389
                }
            };
            if match m390 {
                Adt2::C0(_, _, h388, _, _, _) => {
                    h388
                }
            } {
                Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h391, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h391
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h392, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h392
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h393, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h393
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h394, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h394
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h395, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h395
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h396, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h396
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h397, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h397
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h398, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h398
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h399, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h399
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h400, _, _, _, _, _, _, _, _, _, _, _) => {
                        h400
                    }
                }, Some(Adt41::C10(Adt43::C0)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h401, _, _, _, _, _, _, _, _, _) => {
                        h401
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h402, _, _, _, _, _, _, _, _) => {
                        h402
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h403, _, _, _, _, _, _, _) => {
                        h403
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h404, _, _, _, _, _, _) => {
                        h404
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h405, _, _, _, _, _) => {
                        h405
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h406, _, _, _, _) => {
                        h406
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h407, _, _, _) => {
                        h407
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h408, _, _) => {
                        h408
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h409, _) => {
                        h409
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h410) => {
                        h410
                    }
                }), List::<Adt66>::nil()))
            } else {
                if match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h411, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h411
                    }
                } {
                    Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h412, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h412
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, h413, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h413
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, h414, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h414
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h415, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h415
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h416, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h416
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h417, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h417
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h418, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h418
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h419, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h419
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, h420, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h420
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, h421, _, _, _, _, _, _, _, _, _, _, _) => {
                            h421
                        }
                    }, Some(Adt41::C10(Adt43::C6)), match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h422, _, _, _, _, _, _, _, _, _) => {
                            h422
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h423, _, _, _, _, _, _, _, _) => {
                            h423
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h424, _, _, _, _, _, _, _) => {
                            h424
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h425, _, _, _, _, _, _) => {
                            h425
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h426, _, _, _, _, _) => {
                            h426
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h427, _, _, _, _) => {
                            h427
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h428, _, _, _) => {
                            h428
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h429, _, _) => {
                            h429
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h430, _) => {
                            h430
                        }
                    }, match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h431) => {
                            h431
                        }
                    }), List::<Adt66>::nil()))
                } else {
                    Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h432, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h432
                        }
                    }, f28(match v0.clone() {
                        Adt1::C0(_, h433, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h433
                        }
                    })?, f29(), f30(), Some(v1.clone()), None::<Adt22>, Adt40::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h434, _, _, _, _, _, _, _) => {
                            h434
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h435, _, _, _, _, _, _) => {
                            h435
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h436, _, _, _, _, _) => {
                            h436
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h437, _, _, _, _) => {
                            h437
                        }
                    }, true, f31(), None::<Adt23>, f32(v0.clone())), f33(List::cons(Adt66::C0(f14(Adt1::C0(match v0.clone() {
                        Adt1::C0(h438, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h438
                        }
                    }, f28(match v0.clone() {
                        Adt1::C0(_, h439, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h439
                        }
                    })?, f29(), f30(), Some(v1.clone()), None::<Adt22>, Adt40::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h440, _, _, _, _, _, _, _) => {
                            h440
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h441, _, _, _, _, _, _) => {
                            h441
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h442, _, _, _, _, _) => {
                            h442
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h443, _, _, _, _) => {
                            h443
                        }
                    }, true, f31(), None::<Adt23>, f32(v0.clone()))), v1), List::<Adt66>::nil()), f34(v0))))
                }
            }
        }
    }
}

pub fn f9(v0: Adt1, v1: bool, v2: bool, v3: Adt48) -> R<Adt70> {
    Ok(Adt70::C0(Adt1::C0(match v0.clone() {
        Adt1::C0(h444, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h444
        }
    }, f35(match v0.clone() {
        Adt1::C0(_, h445, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h445
        }
    })?, f29(), f30(), None::<Adt9>, None::<Adt22>, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h446, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h446
        }
    }, None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, v1, v2, v3, Adt49::C1, false, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h447, _, _) => {
            h447
        }
    }, None::<Adt23>, f32(v0.clone())), f34(v0)))
}

pub fn f10(v0: Adt1) -> R<Adt70> {
    let m450 = match v0.clone() {
        Adt1::C0(_, h449, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h449
        }
    };
    if match m450 {
        Adt2::C0(_, _, h448, _, _, _) => {
            h448
        }
    } {
        Ok(Adt70::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h451, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h451
            }
        }, f19(match v0.clone() {
            Adt1::C0(_, h452, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h452
            }
        }), f20(match v0.clone() {
            Adt1::C0(_, _, h453, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h453
            }
        }, Adt7::C2), match v0.clone() {
            Adt1::C0(_, _, _, h454, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h454
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h455, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h455
            }
        }, None::<Adt22>, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h456, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h456
            }
        }, None::<Adt11>, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h457, _, _, _, _, _, _, _, _, _, _, _) => {
                h457
            }
        }, Some(Adt41::C7), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h458, _, _, _, _, _, _, _, _, _) => {
                h458
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h459, _, _, _, _, _, _, _, _) => {
                h459
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h460, _, _, _, _, _, _, _) => {
                h460
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h461, _, _, _, _, _, _) => {
                h461
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h462, _, _, _, _, _) => {
                h462
            }
        }, Adt49::C1, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h463, _, _) => {
                h463
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h464, _) => {
                h464
            }
        }, f32(v0.clone())), List::cons(Adt66::C4(f14(v0.clone())), List::cons(Adt66::C5(f14(v0)), List::<Adt66>::nil()))))
    } else {
        if match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h465, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h465
            }
        } {
            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h466, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h466
                }
            }, f35(match v0.clone() {
                Adt1::C0(_, h467, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h467
                }
            })?, f20(match v0.clone() {
                Adt1::C0(_, _, h468, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h468
                }
            }, Adt7::C3), match v0.clone() {
                Adt1::C0(_, _, _, h469, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h469
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h470, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h470
                }
            }, None::<Adt22>, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h471, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h471
                }
            }, None::<Adt11>, false, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h472, _, _, _, _, _, _, _, _, _, _, _) => {
                    h472
                }
            }, Some(Adt41::C7), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h473, _, _, _, _, _, _, _, _, _) => {
                    h473
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h474, _, _, _, _, _, _, _, _) => {
                    h474
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h475, _, _, _, _, _, _, _) => {
                    h475
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h476, _, _, _, _, _, _) => {
                    h476
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h477, _, _, _, _, _) => {
                    h477
                }
            }, Adt49::C1, false, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h478, _, _) => {
                    h478
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h479, _) => {
                    h479
                }
            }, f32(v0.clone())), f34(v0)))
        } else {
            Ok(Adt70::C0(v0, List::<Adt66>::nil()))
        }
    }
}

pub fn f11(v0: Adt1) -> R<Adt70> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h480, _, _, _, _, _, _) => {
            h480
        }
    } {
        Ok(Adt70::C0(v0, List::<Adt66>::nil()))
    } else {
        Ok(Adt70::C0({
            let m483 = f9(v0.clone(), false, true, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h482, _, _, _, _, _) => {
                    h482
                }
            })?;
            match m483 {
                Adt70::C0(h481, _) => {
                    h481
                }
            }
        }, f33(f34(v0.clone()), List::cons(Adt66::C8(match v0 {
            Adt1::C0(h484, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h484
            }
        }), List::<Adt66>::nil()))))
    }
}

pub fn f12(v0: Adt1, v1: Adt52) -> Adt70 {
    if f4(v0.clone(), v1) {
        let m486 = f36(match v0.clone() {
            Adt1::C0(_, _, h485, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h485
            }
        });
        match m486 {
            Ok(v3) => {
                Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h507, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h507
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h508, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h508
                    }
                }, v3, match v0.clone() {
                    Adt1::C0(_, _, _, h509, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h509
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h510, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h510
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h511, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h511
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h512, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h512
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h513, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h513
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h514, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h514
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h515, _, _, _, _, _, _, _, _, _, _, _) => {
                        h515
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h516, _, _, _, _, _, _, _, _, _, _) => {
                        h516
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h517, _, _, _, _, _, _, _, _, _) => {
                        h517
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h518, _, _, _, _, _, _, _, _) => {
                        h518
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h519, _, _, _, _, _, _, _) => {
                        h519
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h520, _, _, _, _, _, _) => {
                        h520
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h521, _, _, _, _, _) => {
                        h521
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h522, _, _, _, _) => {
                        h522
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h523, _, _, _) => {
                        h523
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h524, _, _) => {
                        h524
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h525, _) => {
                        h525
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h526) => {
                        h526
                    }
                }), List::<Adt66>::nil())
            }
            Err(v2) => {
                Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h487, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h487
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h488, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h488
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h489, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h489
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h490, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h490
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h491, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h491
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h492, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h492
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h493, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h493
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h494, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h494
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h495, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h495
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h496, _, _, _, _, _, _, _, _, _, _, _) => {
                        h496
                    }
                }, Some(Adt41::C11(v2)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h497, _, _, _, _, _, _, _, _, _) => {
                        h497
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h498, _, _, _, _, _, _, _, _) => {
                        h498
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h499, _, _, _, _, _, _, _) => {
                        h499
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h500, _, _, _, _, _, _) => {
                        h500
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h501, _, _, _, _, _) => {
                        h501
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h502, _, _, _, _) => {
                        h502
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h503, _, _, _) => {
                        h503
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h504, _, _) => {
                        h504
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h505, _) => {
                        h505
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h506) => {
                        h506
                    }
                }), List::<Adt66>::nil())
            }
        }
    } else {
        Adt70::C0(v0, List::<Adt66>::nil())
    }
}

pub fn f13(v0: Adt1, v1: Adt52, v2: Adt67) -> R<Adt70> {
    if f4(v0.clone(), v1.clone()) {
        if f37(v0.clone(), v2.clone()) {
            let m528 = f38(match v0.clone() {
                Adt1::C0(_, _, h527, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h527
                }
            }, f39(v2.clone()));
            match m528 {
                Adt72::C0(_, v5) => {
                    let m550 = f40(match v0.clone() {
                        Adt1::C0(_, _, _, h549, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h549
                        }
                    }, v2.clone())?;
                    match m550 {
                        Ok(v7) => {
                            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                                Adt1::C0(h571, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h571
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, h572, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h572
                                }
                            }, v5, v7, match v0.clone() {
                                Adt1::C0(_, _, _, _, h573, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h573
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h574, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h574
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h575, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h575
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, h576, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h576
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, h577, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h577
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, h578, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h578
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h579, _, _, _, _, _, _, _, _, _, _) => {
                                    h579
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h580, _, _, _, _, _, _, _, _, _) => {
                                    h580
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h581, _, _, _, _, _, _, _, _) => {
                                    h581
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h582, _, _, _, _, _, _, _) => {
                                    h582
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h583, _, _, _, _, _, _) => {
                                    h583
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h584, _, _, _, _, _) => {
                                    h584
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h585, _, _, _, _) => {
                                    h585
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h586, _, _, _) => {
                                    h586
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h587, _, _) => {
                                    h587
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h588, _) => {
                                    h588
                                }
                            }, match v0 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h589) => {
                                    h589
                                }
                            }), List::cons(Adt66::C1(v1, v2), List::<Adt66>::nil())))
                        }
                        Err(_) => {
                            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                                Adt1::C0(h551, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h551
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, h552, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h552
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, h553, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h553
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h554, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h554
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h555, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h555
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h556, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h556
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h557, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h557
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, h558, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h558
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, h559, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h559
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, h560, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h560
                                }
                            }, Some(Adt41::C10(Adt43::C8)), match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h561, _, _, _, _, _, _, _, _, _) => {
                                    h561
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h562, _, _, _, _, _, _, _, _) => {
                                    h562
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h563, _, _, _, _, _, _, _) => {
                                    h563
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h564, _, _, _, _, _, _) => {
                                    h564
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h565, _, _, _, _, _) => {
                                    h565
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h566, _, _, _, _) => {
                                    h566
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h567, _, _, _) => {
                                    h567
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h568, _, _) => {
                                    h568
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h569, _) => {
                                    h569
                                }
                            }, match v0 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h570) => {
                                    h570
                                }
                            }), List::<Adt66>::nil()))
                        }
                    }
                }
                Adt72::C1(v3) => {
                    Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h529, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h529
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, h530, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h530
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, h531, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h531
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h532, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h532
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h533, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h533
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h534, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h534
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h535, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h535
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h536, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h536
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, h537, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h537
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, h538, _, _, _, _, _, _, _, _, _, _, _) => {
                            h538
                        }
                    }, Some(Adt41::C11(v3)), match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h539, _, _, _, _, _, _, _, _, _) => {
                            h539
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h540, _, _, _, _, _, _, _, _) => {
                            h540
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h541, _, _, _, _, _, _, _) => {
                            h541
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h542, _, _, _, _, _, _) => {
                            h542
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h543, _, _, _, _, _) => {
                            h543
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h544, _, _, _, _) => {
                            h544
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h545, _, _, _) => {
                            h545
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h546, _, _) => {
                            h546
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h547, _) => {
                            h547
                        }
                    }, match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h548) => {
                            h548
                        }
                    }), List::<Adt66>::nil()))
                }
            }
        } else {
            Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h590, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h590
                }
            }, match v0.clone() {
                Adt1::C0(_, h591, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h591
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h592, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h592
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h593, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h593
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h594, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h594
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h595, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h595
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h596, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h596
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h597, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h597
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h598, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h598
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h599, _, _, _, _, _, _, _, _, _, _, _) => {
                    h599
                }
            }, Some(Adt41::C10(Adt43::C11)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h600, _, _, _, _, _, _, _, _, _) => {
                    h600
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h601, _, _, _, _, _, _, _, _) => {
                    h601
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h602, _, _, _, _, _, _, _) => {
                    h602
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h603, _, _, _, _, _, _) => {
                    h603
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h604, _, _, _, _, _) => {
                    h604
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h605, _, _, _, _) => {
                    h605
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h606, _, _, _) => {
                    h606
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h607, _, _) => {
                    h607
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h608, _) => {
                    h608
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h609) => {
                    h609
                }
            }), List::<Adt66>::nil()))
        }
    } else {
        Ok(Adt70::C0(v0, List::<Adt66>::nil()))
    }
}

pub fn f14(v0: Adt1) -> Adt52 {
    Adt52::C0(match v0.clone() {
        Adt1::C0(h610, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h610
        }
    }, {
        let m613 = match v0.clone() {
            Adt1::C0(_, h612, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h612
            }
        };
        match m613 {
            Adt2::C0(_, h611, _, _, _, _) => {
                h611
            }
        }
    }, {
        let m616 = match v0 {
            Adt1::C0(_, h615, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h615
            }
        };
        match m616 {
            Adt2::C0(h614, _, _, _, _, _) => {
                h614
            }
        }
    })
}

pub fn f15(v0: Option<Adt11>) -> List<Adt66> {
    let m617 = v0;
    match m617 {
        None => {
            List::<Adt66>::nil()
        }
        Some(v1) => {
            List::cons(Adt66::C6(v1), List::<Adt66>::nil())
        }
    }
}

pub fn f16(v0: Adt1, v1: u64) -> Adt70 {
    let a618 = v1;
    let a619 = 0u64;
    if nat_eq(a618, a619) {
        Adt70::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h620, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h620
            }
        }, match v0.clone() {
            Adt1::C0(_, h621, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h621
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h622, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h622
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h623, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h623
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h624, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h624
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h625, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h625
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h626, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h626
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h627, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h627
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h628, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h628
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h629, _, _, _, _, _, _, _, _, _, _, _) => {
                h629
            }
        }, Some(Adt41::C10(Adt43::C12)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h630, _, _, _, _, _, _, _, _, _) => {
                h630
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h631, _, _, _, _, _, _, _, _) => {
                h631
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h632, _, _, _, _, _, _, _) => {
                h632
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h633, _, _, _, _, _, _) => {
                h633
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h634, _, _, _, _, _) => {
                h634
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h635, _, _, _, _) => {
                h635
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h636, _, _, _) => {
                h636
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h637, _, _) => {
                h637
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h638, _) => {
                h638
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h639) => {
                h639
            }
        }), List::<Adt66>::nil())
    } else {
        let m642 = match v0.clone() {
            Adt1::C0(_, h641, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h641
            }
        };
        if match m642 {
            Adt2::C0(_, _, h640, _, _, _) => {
                h640
            }
        } {
            Adt70::C0(v0.clone(), List::cons(Adt66::C3(f14(v0), v1), List::<Adt66>::nil()))
        } else {
            Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h643, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h643
                }
            }, match v0.clone() {
                Adt1::C0(_, h644, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h644
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h645, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h645
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h646, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h646
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h647, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h647
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h648, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h648
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h649, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h649
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h650, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h650
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h651, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h651
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h652, _, _, _, _, _, _, _, _, _, _, _) => {
                    h652
                }
            }, Some(Adt41::C10(Adt43::C3)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h653, _, _, _, _, _, _, _, _, _) => {
                    h653
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h654, _, _, _, _, _, _, _, _) => {
                    h654
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h655, _, _, _, _, _, _, _) => {
                    h655
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h656, _, _, _, _, _, _) => {
                    h656
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h657, _, _, _, _, _) => {
                    h657
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h658, _, _, _, _) => {
                    h658
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h659, _, _, _) => {
                    h659
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h660, _, _) => {
                    h660
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h661, _) => {
                    h661
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h662) => {
                    h662
                }
            }), List::<Adt66>::nil())
        }
    }
}

pub fn f17(v0: Adt1, v1: Adt52, v2: Adt22) -> R<Adt70> {
    f41(v0.clone(), v1.clone(), v2, f4(v0, v1))
}

pub fn f18(v0: Adt1, v1: Adt52, v2: Adt62) -> Adt70 {
    if if f6(v0.clone(), v1.clone()) {
        match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h663, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h663
            }
        }
    } else {
        false
    } {
        Adt70::C0(Adt1::C0({
            let m668 = {
                let m667 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h666) => {
                        h666
                    }
                });
                match m667 {
                    Adt70::C0(h665, _) => {
                        h665
                    }
                }
            };
            match m668 {
                Adt1::C0(h664, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h664
                }
            }
        }, {
            let m673 = {
                let m672 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h671) => {
                        h671
                    }
                });
                match m672 {
                    Adt70::C0(h670, _) => {
                        h670
                    }
                }
            };
            match m673 {
                Adt1::C0(_, h669, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h669
                }
            }
        }, {
            let m678 = {
                let m677 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h676) => {
                        h676
                    }
                });
                match m677 {
                    Adt70::C0(h675, _) => {
                        h675
                    }
                }
            };
            match m678 {
                Adt1::C0(_, _, h674, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h674
                }
            }
        }, {
            let m683 = {
                let m682 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h681) => {
                        h681
                    }
                });
                match m682 {
                    Adt70::C0(h680, _) => {
                        h680
                    }
                }
            };
            match m683 {
                Adt1::C0(_, _, _, h679, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h679
                }
            }
        }, {
            let m688 = {
                let m687 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h686) => {
                        h686
                    }
                });
                match m687 {
                    Adt70::C0(h685, _) => {
                        h685
                    }
                }
            };
            match m688 {
                Adt1::C0(_, _, _, _, h684, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h684
                }
            }
        }, {
            let m693 = {
                let m692 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h691) => {
                        h691
                    }
                });
                match m692 {
                    Adt70::C0(h690, _) => {
                        h690
                    }
                }
            };
            match m693 {
                Adt1::C0(_, _, _, _, _, h689, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h689
                }
            }
        }, {
            let m698 = {
                let m697 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h696) => {
                        h696
                    }
                });
                match m697 {
                    Adt70::C0(h695, _) => {
                        h695
                    }
                }
            };
            match m698 {
                Adt1::C0(_, _, _, _, _, _, h694, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h694
                }
            }
        }, {
            let m703 = {
                let m702 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h701) => {
                        h701
                    }
                });
                match m702 {
                    Adt70::C0(h700, _) => {
                        h700
                    }
                }
            };
            match m703 {
                Adt1::C0(_, _, _, _, _, _, _, h699, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h699
                }
            }
        }, {
            let m708 = {
                let m707 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h706) => {
                        h706
                    }
                });
                match m707 {
                    Adt70::C0(h705, _) => {
                        h705
                    }
                }
            };
            match m708 {
                Adt1::C0(_, _, _, _, _, _, _, _, h704, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h704
                }
            }
        }, {
            let m713 = {
                let m712 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h711) => {
                        h711
                    }
                });
                match m712 {
                    Adt70::C0(h710, _) => {
                        h710
                    }
                }
            };
            match m713 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h709, _, _, _, _, _, _, _, _, _, _, _) => {
                    h709
                }
            }
        }, Some(match v2.clone() {
            Adt62::C0(h714, _, _) => {
                h714
            }
        }), {
            let m719 = {
                let m718 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h717) => {
                        h717
                    }
                });
                match m718 {
                    Adt70::C0(h716, _) => {
                        h716
                    }
                }
            };
            match m719 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h715, _, _, _, _, _, _, _, _, _) => {
                    h715
                }
            }
        }, {
            let m724 = {
                let m723 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h722) => {
                        h722
                    }
                });
                match m723 {
                    Adt70::C0(h721, _) => {
                        h721
                    }
                }
            };
            match m724 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h720, _, _, _, _, _, _, _, _) => {
                    h720
                }
            }
        }, {
            let m729 = {
                let m728 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h727) => {
                        h727
                    }
                });
                match m728 {
                    Adt70::C0(h726, _) => {
                        h726
                    }
                }
            };
            match m729 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h725, _, _, _, _, _, _, _) => {
                    h725
                }
            }
        }, {
            let m734 = {
                let m733 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h732) => {
                        h732
                    }
                });
                match m733 {
                    Adt70::C0(h731, _) => {
                        h731
                    }
                }
            };
            match m734 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h730, _, _, _, _, _, _) => {
                    h730
                }
            }
        }, {
            let m739 = {
                let m738 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h737) => {
                        h737
                    }
                });
                match m738 {
                    Adt70::C0(h736, _) => {
                        h736
                    }
                }
            };
            match m739 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h735, _, _, _, _, _) => {
                    h735
                }
            }
        }, {
            let m744 = {
                let m743 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h742) => {
                        h742
                    }
                });
                match m743 {
                    Adt70::C0(h741, _) => {
                        h741
                    }
                }
            };
            match m744 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h740, _, _, _, _) => {
                    h740
                }
            }
        }, {
            let m749 = {
                let m748 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h747) => {
                        h747
                    }
                });
                match m748 {
                    Adt70::C0(h746, _) => {
                        h746
                    }
                }
            };
            match m749 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h745, _, _, _) => {
                    h745
                }
            }
        }, {
            let m754 = {
                let m753 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h752) => {
                        h752
                    }
                });
                match m753 {
                    Adt70::C0(h751, _) => {
                        h751
                    }
                }
            };
            match m754 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h750, _, _) => {
                    h750
                }
            }
        }, Some(match v2.clone() {
            Adt62::C0(_, h755, _) => {
                h755
            }
        }), {
            let m760 = {
                let m759 = f22(v0.clone(), v1.clone(), match v2.clone() {
                    Adt62::C0(_, _, h758) => {
                        h758
                    }
                });
                match m759 {
                    Adt70::C0(h757, _) => {
                        h757
                    }
                }
            };
            match m760 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h756) => {
                    h756
                }
            }
        }), {
            let m763 = f22(v0, v1, match v2 {
                Adt62::C0(_, _, h762) => {
                    h762
                }
            });
            match m763 {
                Adt70::C0(_, h761) => {
                    h761
                }
            }
        })
    } else {
        if f4(v0.clone(), v1.clone()) {
            Adt70::C0(Adt1::C0({
                let m768 = {
                    let m767 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h766, _, _) => {
                            h766
                        }
                    });
                    match m767 {
                        Adt70::C0(h765, _) => {
                            h765
                        }
                    }
                };
                match m768 {
                    Adt1::C0(h764, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h764
                    }
                }
            }, {
                let m773 = {
                    let m772 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h771, _, _) => {
                            h771
                        }
                    });
                    match m772 {
                        Adt70::C0(h770, _) => {
                            h770
                        }
                    }
                };
                match m773 {
                    Adt1::C0(_, h769, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h769
                    }
                }
            }, f20(match v0.clone() {
                Adt1::C0(_, _, h774, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h774
                }
            }, match v2.clone() {
                Adt62::C0(_, _, h775) => {
                    h775
                }
            }), {
                let m780 = {
                    let m779 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h778, _, _) => {
                            h778
                        }
                    });
                    match m779 {
                        Adt70::C0(h777, _) => {
                            h777
                        }
                    }
                };
                match m780 {
                    Adt1::C0(_, _, _, h776, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h776
                    }
                }
            }, {
                let m785 = {
                    let m784 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h783, _, _) => {
                            h783
                        }
                    });
                    match m784 {
                        Adt70::C0(h782, _) => {
                            h782
                        }
                    }
                };
                match m785 {
                    Adt1::C0(_, _, _, _, h781, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h781
                    }
                }
            }, {
                let m790 = {
                    let m789 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h788, _, _) => {
                            h788
                        }
                    });
                    match m789 {
                        Adt70::C0(h787, _) => {
                            h787
                        }
                    }
                };
                match m790 {
                    Adt1::C0(_, _, _, _, _, h786, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h786
                    }
                }
            }, {
                let m795 = {
                    let m794 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h793, _, _) => {
                            h793
                        }
                    });
                    match m794 {
                        Adt70::C0(h792, _) => {
                            h792
                        }
                    }
                };
                match m795 {
                    Adt1::C0(_, _, _, _, _, _, h791, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h791
                    }
                }
            }, {
                let m800 = {
                    let m799 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h798, _, _) => {
                            h798
                        }
                    });
                    match m799 {
                        Adt70::C0(h797, _) => {
                            h797
                        }
                    }
                };
                match m800 {
                    Adt1::C0(_, _, _, _, _, _, _, h796, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h796
                    }
                }
            }, {
                let m805 = {
                    let m804 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h803, _, _) => {
                            h803
                        }
                    });
                    match m804 {
                        Adt70::C0(h802, _) => {
                            h802
                        }
                    }
                };
                match m805 {
                    Adt1::C0(_, _, _, _, _, _, _, _, h801, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h801
                    }
                }
            }, {
                let m810 = {
                    let m809 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h808, _, _) => {
                            h808
                        }
                    });
                    match m809 {
                        Adt70::C0(h807, _) => {
                            h807
                        }
                    }
                };
                match m810 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h806, _, _, _, _, _, _, _, _, _, _, _) => {
                        h806
                    }
                }
            }, {
                let m815 = {
                    let m814 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h813, _, _) => {
                            h813
                        }
                    });
                    match m814 {
                        Adt70::C0(h812, _) => {
                            h812
                        }
                    }
                };
                match m815 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h811, _, _, _, _, _, _, _, _, _, _) => {
                        h811
                    }
                }
            }, {
                let m820 = {
                    let m819 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h818, _, _) => {
                            h818
                        }
                    });
                    match m819 {
                        Adt70::C0(h817, _) => {
                            h817
                        }
                    }
                };
                match m820 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h816, _, _, _, _, _, _, _, _, _) => {
                        h816
                    }
                }
            }, {
                let m825 = {
                    let m824 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h823, _, _) => {
                            h823
                        }
                    });
                    match m824 {
                        Adt70::C0(h822, _) => {
                            h822
                        }
                    }
                };
                match m825 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h821, _, _, _, _, _, _, _, _) => {
                        h821
                    }
                }
            }, {
                let m830 = {
                    let m829 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h828, _, _) => {
                            h828
                        }
                    });
                    match m829 {
                        Adt70::C0(h827, _) => {
                            h827
                        }
                    }
                };
                match m830 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h826, _, _, _, _, _, _, _) => {
                        h826
                    }
                }
            }, {
                let m835 = {
                    let m834 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h833, _, _) => {
                            h833
                        }
                    });
                    match m834 {
                        Adt70::C0(h832, _) => {
                            h832
                        }
                    }
                };
                match m835 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h831, _, _, _, _, _, _) => {
                        h831
                    }
                }
            }, {
                let m840 = {
                    let m839 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h838, _, _) => {
                            h838
                        }
                    });
                    match m839 {
                        Adt70::C0(h837, _) => {
                            h837
                        }
                    }
                };
                match m840 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h836, _, _, _, _, _) => {
                        h836
                    }
                }
            }, {
                let m845 = {
                    let m844 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h843, _, _) => {
                            h843
                        }
                    });
                    match m844 {
                        Adt70::C0(h842, _) => {
                            h842
                        }
                    }
                };
                match m845 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h841, _, _, _, _) => {
                        h841
                    }
                }
            }, {
                let m850 = {
                    let m849 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h848, _, _) => {
                            h848
                        }
                    });
                    match m849 {
                        Adt70::C0(h847, _) => {
                            h847
                        }
                    }
                };
                match m850 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h846, _, _, _) => {
                        h846
                    }
                }
            }, {
                let m855 = {
                    let m854 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h853, _, _) => {
                            h853
                        }
                    });
                    match m854 {
                        Adt70::C0(h852, _) => {
                            h852
                        }
                    }
                };
                match m855 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h851, _, _) => {
                        h851
                    }
                }
            }, Some(match v2.clone() {
                Adt62::C0(_, h856, _) => {
                    h856
                }
            }), {
                let m861 = {
                    let m860 = f42(v0.clone(), v1.clone(), match v2.clone() {
                        Adt62::C0(h859, _, _) => {
                            h859
                        }
                    });
                    match m860 {
                        Adt70::C0(h858, _) => {
                            h858
                        }
                    }
                };
                match m861 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h857) => {
                        h857
                    }
                }
            }), {
                let m864 = f42(v0, v1, match v2 {
                    Adt62::C0(h863, _, _) => {
                        h863
                    }
                });
                match m864 {
                    Adt70::C0(_, h862) => {
                        h862
                    }
                }
            })
        } else {
            Adt70::C0(v0, List::<Adt66>::nil())
        }
    }
}

pub fn f19(v0: Adt2) -> Adt2 {
    if match v0.clone() {
        Adt2::C0(_, _, h865, _, _, _) => {
            h865
        }
    } {
        Adt2::C0(match v0.clone() {
            Adt2::C0(h866, _, _, _, _, _) => {
                h866
            }
        }, match v0 {
            Adt2::C0(_, h867, _, _, _, _) => {
                h867
            }
        }, false, false, Adt3::C5, Adt4::C0)
    } else {
        v0
    }
}

pub fn f20(v0: Adt5, v1: Adt7) -> Adt5 {
    Adt5::C0(Adt6::C4, match v0.clone() {
        Adt5::C0(_, h868, _, _, _) => {
            h868
        }
    }, match v0 {
        Adt5::C0(_, _, h869, _, _) => {
            h869
        }
    }, false, v1)
}

pub fn f21(v0: Adt1) -> Adt70 {
    if f43(v0.clone()) {
        let m871 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h870, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h870
            }
        };
        match m871 {
            None => {
                Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h872, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h872
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h873, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h873
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h874, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h874
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h875, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h875
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h876, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h876
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h877, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h877
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h878, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h878
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h879, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h879
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h880, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h880
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h881, _, _, _, _, _, _, _, _, _, _, _) => {
                        h881
                    }
                }, Some(Adt41::C10(Adt43::C5)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h882, _, _, _, _, _, _, _, _, _) => {
                        h882
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h883, _, _, _, _, _, _, _, _) => {
                        h883
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h884, _, _, _, _, _, _, _) => {
                        h884
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h885, _, _, _, _, _, _) => {
                        h885
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h886, _, _, _, _, _) => {
                        h886
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h887, _, _, _, _) => {
                        h887
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h888, _, _, _) => {
                        h888
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h889, _, _) => {
                        h889
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h890, _) => {
                        h890
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h891) => {
                        h891
                    }
                }), List::<Adt66>::nil())
            }
            Some(v1) => {
                Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h892, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h892
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h893, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h893
                    }
                }, f44(match v0.clone() {
                    Adt1::C0(_, _, h894, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h894
                    }
                }), match v0.clone() {
                    Adt1::C0(_, _, _, h895, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h895
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h896, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h896
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h897, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h897
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h898, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h898
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h899, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h899
                    }
                }, true, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h900, _, _, _, _, _, _, _, _, _, _, _) => {
                        h900
                    }
                }, None::<Adt41>, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h901, _, _, _, _, _, _, _, _, _) => {
                        h901
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h902, _, _, _, _, _, _, _, _) => {
                        h902
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h903, _, _, _, _, _, _, _) => {
                        h903
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h904, _, _, _, _, _, _) => {
                        h904
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h905, _, _, _, _, _) => {
                        h905
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h906, _, _, _, _) => {
                        h906
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h907, _, _, _) => {
                        h907
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h908, _, _) => {
                        h908
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h909, _) => {
                        h909
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h910) => {
                        h910
                    }
                }), List::cons(Adt66::C7(f14(v0), v1), List::<Adt66>::nil()))
            }
        }
    } else {
        Adt70::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h911, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h911
            }
        }, match v0.clone() {
            Adt1::C0(_, h912, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h912
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h913, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h913
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h914, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h914
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h915, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h915
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h916, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h916
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h917, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h917
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h918, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h918
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h919, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h919
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h920, _, _, _, _, _, _, _, _, _, _, _) => {
                h920
            }
        }, Some(Adt41::C10(Adt43::C5)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h921, _, _, _, _, _, _, _, _, _) => {
                h921
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h922, _, _, _, _, _, _, _, _) => {
                h922
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h923, _, _, _, _, _, _, _) => {
                h923
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h924, _, _, _, _, _, _) => {
                h924
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h925, _, _, _, _, _) => {
                h925
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h926, _, _, _, _) => {
                h926
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h927, _, _, _) => {
                h927
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h928, _, _) => {
                h928
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h929, _) => {
                h929
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h930) => {
                h930
            }
        }), List::<Adt66>::nil())
    }
}

pub fn f22(v0: Adt1, v1: Adt52, v2: Adt7) -> Adt70 {
    if if f6(v0.clone(), v1) {
        match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h931, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h931
            }
        }
    } else {
        false
    } {
        let m933 = f45(match v0.clone() {
            Adt1::C0(_, _, h932, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h932
            }
        }, v2.clone());
        match m933 {
            Ok(v4) => {
                let m954 = v2.clone();
                match m954 {
                    Adt7::C0 => {
                        Adt70::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h955, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h955
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h956, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h956
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, h957, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h957
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, h958, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h958
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h959, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h959
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h960, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h960
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h961, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h961
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h962, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h962
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h963, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h963
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h964, _, _, _, _, _, _, _, _, _, _, _) => {
                                h964
                            }
                        }, Some(Adt41::C10(Adt43::C13)), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h965, _, _, _, _, _, _, _, _, _) => {
                                h965
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h966, _, _, _, _, _, _, _, _) => {
                                h966
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h967, _, _, _, _, _, _, _) => {
                                h967
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h968, _, _, _, _, _, _) => {
                                h968
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h969, _, _, _, _, _) => {
                                h969
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h970, _, _, _, _) => {
                                h970
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h971, _, _, _) => {
                                h971
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h972, _, _) => {
                                h972
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h973, _) => {
                                h973
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h974) => {
                                h974
                            }
                        }), List::<Adt66>::nil())
                    }
                    Adt7::C1 => {
                        Adt70::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h975, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h975
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h976, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h976
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h977, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h977
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h978, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h978
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h979, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h979
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h980, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h980
                            }
                        }, None::<Adt11>, false, true, None::<Adt41>, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h981, _, _, _, _, _, _, _, _, _) => {
                                h981
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h982, _, _, _, _, _, _, _, _) => {
                                h982
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h983, _, _, _, _, _, _, _) => {
                                h983
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h984, _, _, _, _, _, _) => {
                                h984
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h985, _, _, _, _, _) => {
                                h985
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h986, _, _, _, _) => {
                                h986
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h987, _, _, _) => {
                                h987
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h988, _, _) => {
                                h988
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h989, _) => {
                                h989
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h990) => {
                                h990
                            }
                        }), List::<Adt66>::nil())
                    }
                    Adt7::C2 => {
                        Adt70::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h991, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h991
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h992, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h992
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h993, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h993
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h994, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h994
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h995, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h995
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h996, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h996
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h997, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h997
                            }
                        }, false, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h998, _, _, _, _, _, _, _, _, _, _, _) => {
                                h998
                            }
                        }, Some(Adt41::C9(v2, Str::lit("Output was not published; the staged result is retained."))), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h999, _, _, _, _, _, _, _, _, _) => {
                                h999
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1000, _, _, _, _, _, _, _, _) => {
                                h1000
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1001, _, _, _, _, _, _, _) => {
                                h1001
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1002, _, _, _, _, _, _) => {
                                h1002
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1003, _, _, _, _, _) => {
                                h1003
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1004, _, _, _, _) => {
                                h1004
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1005, _, _, _) => {
                                h1005
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1006, _, _) => {
                                h1006
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1007, _) => {
                                h1007
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1008) => {
                                h1008
                            }
                        }), List::<Adt66>::nil())
                    }
                    Adt7::C3 => {
                        Adt70::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1009, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1009
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1010, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1010
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1011, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1011
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1012, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1012
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1013, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1013
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1014, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1014
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1015, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1015
                            }
                        }, false, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1016, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1016
                            }
                        }, Some(Adt41::C9(v2, Str::lit("Publication outcome is unknown; reconcile with the destination before retrying."))), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1017, _, _, _, _, _, _, _, _, _) => {
                                h1017
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1018, _, _, _, _, _, _, _, _) => {
                                h1018
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1019, _, _, _, _, _, _, _) => {
                                h1019
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1020, _, _, _, _, _, _) => {
                                h1020
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1021, _, _, _, _, _) => {
                                h1021
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1022, _, _, _, _) => {
                                h1022
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1023, _, _, _) => {
                                h1023
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1024, _, _) => {
                                h1024
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1025, _) => {
                                h1025
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1026) => {
                                h1026
                            }
                        }), List::<Adt66>::nil())
                    }
                }
            }
            Err(v3) => {
                Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h934, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h934
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h935, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h935
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h936, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h936
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h937, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h937
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h938, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h938
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h939, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h939
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h940, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h940
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h941, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h941
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h942, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h942
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h943, _, _, _, _, _, _, _, _, _, _, _) => {
                        h943
                    }
                }, Some(Adt41::C11(v3)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h944, _, _, _, _, _, _, _, _, _) => {
                        h944
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h945, _, _, _, _, _, _, _, _) => {
                        h945
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h946, _, _, _, _, _, _, _) => {
                        h946
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h947, _, _, _, _, _, _) => {
                        h947
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h948, _, _, _, _, _) => {
                        h948
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h949, _, _, _, _) => {
                        h949
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h950, _, _, _) => {
                        h950
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h951, _, _) => {
                        h951
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h952, _) => {
                        h952
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h953) => {
                        h953
                    }
                }), List::<Adt66>::nil())
            }
        }
    } else {
        Adt70::C0(v0, List::<Adt66>::nil())
    }
}

pub fn f23(v0: Adt1, v1: Adt52, v2: u64) -> R<Adt70> {
    if f4(v0.clone(), v1.clone()) {
        let m1028 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1027, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1027
            }
        };
        match m1028 {
            None => {
                Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1029, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1029
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1030, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1030
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1031, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1031
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1032, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1032
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1033, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1033
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1034, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1034
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1035, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1035
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1036, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1036
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1037, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1037
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1038, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1038
                    }
                }, Some(Adt41::C10(Adt43::C3)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1039, _, _, _, _, _, _, _, _, _) => {
                        h1039
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1040, _, _, _, _, _, _, _, _) => {
                        h1040
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1041, _, _, _, _, _, _, _) => {
                        h1041
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1042, _, _, _, _, _, _) => {
                        h1042
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1043, _, _, _, _, _) => {
                        h1043
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1044, _, _, _, _) => {
                        h1044
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1045, _, _, _) => {
                        h1045
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1046, _, _) => {
                        h1046
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1047, _) => {
                        h1047
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1048) => {
                        h1048
                    }
                }), List::<Adt66>::nil()))
            }
            Some(v3) => {
                let m1060 = f46(match v0.clone() {
                    Adt1::C0(_, _, h1049, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1049
                    }
                }, v2, {
                    let m1054 = {
                        let m1053 = {
                            let m1052 = f47(v3);
                            match m1052 {
                                Adt12::C0(h1051, _) => {
                                    h1051
                                }
                            }
                        };
                        match m1053 {
                            Adt13::C0(_, _, _, _, h1050, _, _) => {
                                h1050
                            }
                        }
                    };
                    match m1054 {
                        None => {
                            let a1058 = {
                                let m1057 = match v0.clone() {
                                    Adt1::C0(_, _, h1056, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                        h1056
                                    }
                                };
                                match m1057 {
                                    Adt5::C0(_, _, h1055, _, _) => {
                                        h1055
                                    }
                                }
                            };
                            let a1059 = v2;
                            nat_add(a1058, a1059)?
                        }
                        Some(v4) => {
                            v4
                        }
                    }
                })?;
                match m1060 {
                    Ok(v6) => {
                        Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1061, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1061
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1062, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1062
                            }
                        }, v6, match v0.clone() {
                            Adt1::C0(_, _, _, h1063, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1063
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1064, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1064
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1065, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1065
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1066, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1066
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1067, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1067
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h1068, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1068
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1069, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1069
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1070, _, _, _, _, _, _, _, _, _, _) => {
                                h1070
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1071, _, _, _, _, _, _, _, _, _) => {
                                h1071
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1072, _, _, _, _, _, _, _, _) => {
                                h1072
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1073, _, _, _, _, _, _, _) => {
                                h1073
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1074, _, _, _, _, _, _) => {
                                h1074
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1075, _, _, _, _, _) => {
                                h1075
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1076, _, _, _, _) => {
                                h1076
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1077, _, _, _) => {
                                h1077
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1078, _, _) => {
                                h1078
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1079, _) => {
                                h1079
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1080) => {
                                h1080
                            }
                        }), List::<Adt66>::nil()))
                    }
                    Err(v5) => {
                        Ok(f42(v0, v1, Adt41::C11(v5)))
                    }
                }
            }
        }
    } else {
        Ok(Adt70::C0(v0, List::<Adt66>::nil()))
    }
}

pub fn f24(v0: Adt1, v1: Adt52, v2: Adt63) -> R<Adt70> {
    if f6(v0.clone(), v1.clone()) {
        let m1082 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1081, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1081
            }
        };
        match m1082 {
            None => {
                Ok(Adt70::C0(v0, List::<Adt66>::nil()))
            }
            Some(v3) => {
                Ok(f48(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1083, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1083
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1084, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1084
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1085, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1085
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1086, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1086
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1087, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1087
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1088, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1088
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1089, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1089
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1090, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1090
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1091, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1091
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1092, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1092
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1093, _, _, _, _, _, _, _, _, _, _) => {
                        h1093
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1094, _, _, _, _, _, _, _, _, _) => {
                        h1094
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1095, _, _, _, _, _, _, _, _) => {
                        h1095
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1096, _, _, _, _, _, _, _) => {
                        h1096
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1097, _, _, _, _, _, _) => {
                        h1097
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1098, _, _, _, _, _) => {
                        h1098
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1099, _, _, _, _) => {
                        h1099
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1100, _, _, _) => {
                        h1100
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1101, _, _) => {
                        h1101
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1102, _) => {
                        h1102
                    }
                }, f25(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1103) => {
                        h1103
                    }
                }, v1, v2.clone())?), f49({
                    let m1107 = {
                        let m1106 = f47(v3);
                        match m1106 {
                            Adt12::C0(h1105, _) => {
                                h1105
                            }
                        }
                    };
                    match m1107 {
                        Adt13::C0(_, _, _, _, _, _, h1104) => {
                            h1104
                        }
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1108, _, _) => {
                        h1108
                    }
                }, v2)?))
            }
        }
    } else {
        Ok(Adt70::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1109, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1109
            }
        }, match v0.clone() {
            Adt1::C0(_, h1110, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1110
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1111, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1111
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1112, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1112
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1113, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1113
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1114, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1114
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1115, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1115
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1116, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1116
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1117, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1117
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1118, _, _, _, _, _, _, _, _, _, _, _) => {
                h1118
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1119, _, _, _, _, _, _, _, _, _, _) => {
                h1119
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1120, _, _, _, _, _, _, _, _, _) => {
                h1120
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1121, _, _, _, _, _, _, _, _) => {
                h1121
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1122, _, _, _, _, _, _, _) => {
                h1122
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1123, _, _, _, _, _, _) => {
                h1123
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1124, _, _, _, _, _) => {
                h1124
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1125, _, _, _, _) => {
                h1125
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1126, _, _, _) => {
                h1126
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1127, _, _) => {
                h1127
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1128, _) => {
                h1128
            }
        }, f25(match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1129) => {
                h1129
            }
        }, v1, v2)?), List::<Adt66>::nil()))
    }
}

pub fn f25(v0: List<Adt51>, v1: Adt52, v2: Adt63) -> R<List<Adt51>> {
    let m1130 = v0;
    match m1130.uncons() {
        None => {
            Ok(List::<Adt51>::nil())
        }
        Some((v3, v4)) => {
            Ok(List::cons(if f50(match v3.clone() {
                Adt51::C0(h1131, _, _, _) => {
                    h1131
                }
            }, v1.clone()) {
                Adt51::C0(match v3.clone() {
                    Adt51::C0(h1132, _, _, _) => {
                        h1132
                    }
                }, match v3.clone() {
                    Adt51::C0(_, h1133, _, _) => {
                        h1133
                    }
                }, f49(match v3.clone() {
                    Adt51::C0(_, h1134, _, _) => {
                        h1134
                    }
                }, match v3.clone() {
                    Adt51::C0(_, _, h1135, _) => {
                        h1135
                    }
                }, v2.clone())?, match v3 {
                    Adt51::C0(_, _, _, h1136) => {
                        h1136
                    }
                })
            } else {
                v3
            }, f25(v4, v1, v2)?))
        }
    }
}

pub fn f26(v0: List<Adt51>, v1: Adt52) -> R<List<Adt51>> {
    let m1137 = v0;
    match m1137.uncons() {
        None => {
            Ok(List::<Adt51>::nil())
        }
        Some((v2, v3)) => {
            if if f50(match v2.clone() {
                Adt51::C0(h1138, _, _, _) => {
                    h1138
                }
            }, v1.clone()) {
                let a1142 = f51({
                    let m1141 = match v2.clone() {
                        Adt51::C0(_, _, h1140, _) => {
                            h1140
                        }
                    };
                    match m1141 {
                        Adt50::C0(h1139, _) => {
                            h1139
                        }
                    }
                })?;
                let a1143 = 0u64;
                if nat_eq(a1142, a1143) {
                    let a1147 = f52({
                        let m1146 = match v2.clone() {
                            Adt51::C0(_, _, h1145, _) => {
                                h1145
                            }
                        };
                        match m1146 {
                            Adt50::C0(h1144, _) => {
                                h1144
                            }
                        }
                    })?;
                    let a1148 = 0u64;
                    nat_eq(a1147, a1148)
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(v3)
            } else {
                Ok(List::cons(v2, f26(v3, v1)?))
            }
        }
    }
}

pub fn f27(v0: Adt2, v1: u64, v2: u64) -> bool {
    if match v0.clone() {
        Adt2::C0(_, _, h1149, _, _, _) => {
            h1149
        }
    } {
        let a1151 = match v0.clone() {
            Adt2::C0(_, h1150, _, _, _, _) => {
                h1150
            }
        };
        let a1152 = v1;
        if nat_eq(a1151, a1152) {
            let a1154 = match v0 {
                Adt2::C0(h1153, _, _, _, _, _) => {
                    h1153
                }
            };
            let a1155 = v2;
            nat_eq(a1154, a1155)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f28(v0: Adt2) -> R<Adt2> {
    Ok(Adt2::C0(match v0.clone() {
        Adt2::C0(h1156, _, _, _, _, _) => {
            h1156
        }
    }, {
        let a1158 = match v0 {
            Adt2::C0(_, h1157, _, _, _, _) => {
                h1157
            }
        };
        let a1159 = 1u64;
        nat_add(a1158, a1159)?
    }, true, false, Adt3::C1, Adt4::C0))
}

pub fn f29() -> Adt5 {
    Adt5::C0(Adt6::C0, false, 0u64, false, Adt7::C0)
}

pub fn f30() -> Adt8 {
    Adt8::C0(0u64, false, false, 0u64)
}

pub fn f31() -> Adt50 {
    Adt50::C0(f53(), None::<Adt45>)
}

pub fn f32(v0: Adt1) -> List<Adt51> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1160, _, _, _) => {
            h1160
        }
    } {
        List::cons(Adt51::C0(f14(v0.clone()), {
            let m1162 = match v0.clone() {
                Adt1::C0(_, _, _, _, h1161, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1161
                }
            };
            match m1162 {
                None => {
                    f54()
                }
                Some(v1) => {
                    let m1166 = {
                        let m1165 = f47(v1);
                        match m1165 {
                            Adt12::C0(h1164, _) => {
                                h1164
                            }
                        }
                    };
                    match m1166 {
                        Adt13::C0(_, _, _, _, _, _, h1163) => {
                            h1163
                        }
                    }
                }
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1167, _, _) => {
                h1167
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1168, _) => {
                h1168
            }
        }), match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1169) => {
                h1169
            }
        })
    } else {
        match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1170) => {
                h1170
            }
        }
    }
}

pub fn f33(v0: List<Adt66>, v1: List<Adt66>) -> List<Adt66> {
    let m1171 = v0;
    match m1171.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f33(v3, v1))
        }
    }
}

pub fn f34(v0: Adt1) -> List<Adt66> {
    f33(if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, h1172, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1172
        }
    } {
        List::cons(Adt66::C9(f14(v0.clone())), List::<Adt66>::nil())
    } else {
        List::<Adt66>::nil()
    }, f33(if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1173, _, _, _) => {
            h1173
        }
    } {
        let m1176 = match v0.clone() {
            Adt1::C0(_, h1175, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1175
            }
        };
        if match m1176 {
            Adt2::C0(_, _, h1174, _, _, _) => {
                h1174
            }
        } {
            List::cons(Adt66::C4(f14(v0.clone())), List::cons(Adt66::C5(f14(v0.clone())), List::<Adt66>::nil()))
        } else {
            List::cons(Adt66::C5(f14(v0.clone())), List::<Adt66>::nil())
        }
    } else {
        List::<Adt66>::nil()
    }, f33(f15(match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, h1177, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1177
        }
    }), f15(match v0 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1178, _, _, _, _, _, _, _, _) => {
            h1178
        }
    }))))
}

pub fn f35(v0: Adt2) -> R<Adt2> {
    Ok(Adt2::C0({
        let a1180 = match v0.clone() {
            Adt2::C0(h1179, _, _, _, _, _) => {
                h1179
            }
        };
        let a1181 = 1u64;
        nat_add(a1180, a1181)?
    }, match v0 {
        Adt2::C0(_, h1182, _, _, _, _) => {
            h1182
        }
    }, false, false, Adt3::C0, Adt4::C0))
}

pub fn f36(v0: Adt5) -> Result<Adt5, Adt44> {
    let m1184 = match v0.clone() {
        Adt5::C0(h1183, _, _, _, _) => {
            h1183
        }
    };
    match m1184 {
        Adt6::C0 => {
            if match v0.clone() {
                Adt5::C0(_, h1185, _, _, _) => {
                    h1185
                }
            } {
                Err::<Adt5, Adt44>(Adt44::C1)
            } else {
                Ok::<Adt5, Adt44>(Adt5::C0(Adt6::C1, match v0.clone() {
                    Adt5::C0(_, h1186, _, _, _) => {
                        h1186
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h1187, _, _) => {
                        h1187
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, _, h1188, _) => {
                        h1188
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, _, h1189) => {
                        h1189
                    }
                }))
            }
        }
        Adt6::C1 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C2 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C3 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C4 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
    }
}

pub fn f37(v0: Adt1, v1: Adt67) -> bool {
    let m1190 = v1;
    match m1190 {
        Adt67::C0(_) => {
            true
        }
        Adt67::C1(v3) => {
            let a1195 = {
                let m1193 = match v3 {
                    Adt68::C0(h1192, _, _) => {
                        h1192
                    }
                };
                match m1193 {
                    Adt11::C0(h1191, _, _) => {
                        h1191
                    }
                }
            };
            let a1196 = match v0 {
                Adt1::C0(h1194, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1194
                }
            };
            nat_eq(a1195, a1196)
        }
        Adt67::C2(_) => {
            true
        }
        Adt67::C3 => {
            true
        }
    }
}

pub fn f38(v0: Adt5, v1: Adt71) -> Adt72 {
    let m1197 = v1;
    match m1197 {
        Adt71::C0 => {
            let m1199 = match v0.clone() {
                Adt5::C0(h1198, _, _, _, _) => {
                    h1198
                }
            };
            match m1199 {
                Adt6::C0 => {
                    Adt72::C0(Adt73::C0, v0)
                }
                Adt6::C1 => {
                    Adt72::C1(Adt44::C2)
                }
                Adt6::C2 => {
                    Adt72::C1(Adt44::C2)
                }
                Adt6::C3 => {
                    Adt72::C1(Adt44::C2)
                }
                Adt6::C4 => {
                    Adt72::C1(Adt44::C2)
                }
            }
        }
        Adt71::C1 => {
            let m1201 = match v0.clone() {
                Adt5::C0(h1200, _, _, _, _) => {
                    h1200
                }
            };
            match m1201 {
                Adt6::C0 => {
                    Adt72::C1(Adt44::C0)
                }
                Adt6::C1 => {
                    if match v0.clone() {
                        Adt5::C0(_, h1202, _, _, _) => {
                            h1202
                        }
                    } {
                        Adt72::C1(Adt44::C1)
                    } else {
                        Adt72::C0(Adt73::C1, Adt5::C0(Adt6::C0, match v0.clone() {
                            Adt5::C0(_, h1203, _, _, _) => {
                                h1203
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, h1204, _, _) => {
                                h1204
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, _, h1205, _) => {
                                h1205
                            }
                        }, match v0 {
                            Adt5::C0(_, _, _, _, h1206) => {
                                h1206
                            }
                        }))
                    }
                }
                Adt6::C2 => {
                    Adt72::C1(Adt44::C0)
                }
                Adt6::C3 => {
                    Adt72::C1(Adt44::C0)
                }
                Adt6::C4 => {
                    Adt72::C1(Adt44::C0)
                }
            }
        }
        Adt71::C2 => {
            let m1208 = match v0.clone() {
                Adt5::C0(h1207, _, _, _, _) => {
                    h1207
                }
            };
            match m1208 {
                Adt6::C0 => {
                    Adt72::C1(Adt44::C0)
                }
                Adt6::C1 => {
                    if match v0.clone() {
                        Adt5::C0(_, h1209, _, _, _) => {
                            h1209
                        }
                    } {
                        Adt72::C1(Adt44::C1)
                    } else {
                        Adt72::C0(Adt73::C2, Adt5::C0(Adt6::C0, true, match v0.clone() {
                            Adt5::C0(_, _, h1210, _, _) => {
                                h1210
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, _, h1211, _) => {
                                h1211
                            }
                        }, match v0 {
                            Adt5::C0(_, _, _, _, h1212) => {
                                h1212
                            }
                        }))
                    }
                }
                Adt6::C2 => {
                    Adt72::C1(Adt44::C0)
                }
                Adt6::C3 => {
                    Adt72::C1(Adt44::C0)
                }
                Adt6::C4 => {
                    Adt72::C1(Adt44::C0)
                }
            }
        }
        Adt71::C3 => {
            let m1214 = match v0.clone() {
                Adt5::C0(h1213, _, _, _, _) => {
                    h1213
                }
            };
            match m1214 {
                Adt6::C0 => {
                    Adt72::C0(Adt73::C3, Adt5::C0(Adt6::C3, match v0.clone() {
                        Adt5::C0(_, h1215, _, _, _) => {
                            h1215
                        }
                    }, match v0 {
                        Adt5::C0(_, _, h1216, _, _) => {
                            h1216
                        }
                    }, false, Adt7::C2))
                }
                Adt6::C1 => {
                    Adt72::C0(Adt73::C3, Adt5::C0(Adt6::C3, match v0.clone() {
                        Adt5::C0(_, h1217, _, _, _) => {
                            h1217
                        }
                    }, match v0 {
                        Adt5::C0(_, _, h1218, _, _) => {
                            h1218
                        }
                    }, false, Adt7::C2))
                }
                Adt6::C2 => {
                    Adt72::C0(Adt73::C4, v0)
                }
                Adt6::C3 => {
                    Adt72::C0(Adt73::C4, v0)
                }
                Adt6::C4 => {
                    Adt72::C0(Adt73::C4, v0)
                }
            }
        }
    }
}

pub fn f39(v0: Adt67) -> Adt71 {
    let m1219 = v0;
    match m1219 {
        Adt67::C0(_) => {
            Adt71::C1
        }
        Adt67::C1(_) => {
            Adt71::C1
        }
        Adt67::C2(_) => {
            Adt71::C1
        }
        Adt67::C3 => {
            Adt71::C2
        }
    }
}

pub fn f40(v0: Adt8, v1: Adt67) -> R<Result<Adt8, Adt74>> {
    if match v0.clone() {
        Adt8::C0(_, _, h1220, _) => {
            h1220
        }
    } {
        Ok(Err::<Adt8, Adt74>(Adt74::C0))
    } else {
        let m1221 = v1;
        match m1221 {
            Adt67::C0(v2) => {
                if match v0.clone() {
                    Adt8::C0(_, h1222, _, _) => {
                        h1222
                    }
                } {
                    Ok(Err::<Adt8, Adt74>(Adt74::C1))
                } else {
                    let a1224 = v2;
                    let a1225 = match v0.clone() {
                        Adt8::C0(h1223, _, _, _) => {
                            h1223
                        }
                    };
                    if nat_eq(a1224, a1225) {
                        Ok(Ok::<Adt8, Adt74>(Adt8::C0(match v0.clone() {
                            Adt8::C0(h1226, _, _, _) => {
                                h1226
                            }
                        }, true, match v0.clone() {
                            Adt8::C0(_, _, h1227, _) => {
                                h1227
                            }
                        }, match v0 {
                            Adt8::C0(_, _, _, h1228) => {
                                h1228
                            }
                        })))
                    } else {
                        Ok(Err::<Adt8, Adt74>(Adt74::C3))
                    }
                }
            }
            Adt67::C1(v3) => {
                if match v0.clone() {
                    Adt8::C0(_, h1229, _, _) => {
                        h1229
                    }
                } {
                    Ok(Ok::<Adt8, Adt74>(Adt8::C0(match v0.clone() {
                        Adt8::C0(h1230, _, _, _) => {
                            h1230
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, h1231, _, _) => {
                            h1231
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, _, h1232, _) => {
                            h1232
                        }
                    }, {
                        let a1235 = match v0 {
                            Adt8::C0(_, _, _, h1233) => {
                                h1233
                            }
                        };
                        let a1236 = match v3 {
                            Adt68::C0(_, _, h1234) => {
                                h1234
                            }
                        };
                        nat_add(a1235, a1236)?
                    })))
                } else {
                    Ok(Err::<Adt8, Adt74>(Adt74::C2))
                }
            }
            Adt67::C2(v4) => {
                if match v0.clone() {
                    Adt8::C0(_, h1237, _, _) => {
                        h1237
                    }
                } {
                    let a1239 = v4;
                    let a1240 = match v0.clone() {
                        Adt8::C0(h1238, _, _, _) => {
                            h1238
                        }
                    };
                    if nat_eq(a1239, a1240) {
                        Ok(Ok::<Adt8, Adt74>(Adt8::C0({
                            let a1242 = match v0.clone() {
                                Adt8::C0(h1241, _, _, _) => {
                                    h1241
                                }
                            };
                            let a1243 = 1u64;
                            nat_add(a1242, a1243)?
                        }, false, match v0.clone() {
                            Adt8::C0(_, _, h1244, _) => {
                                h1244
                            }
                        }, match v0 {
                            Adt8::C0(_, _, _, h1245) => {
                                h1245
                            }
                        })))
                    } else {
                        Ok(Err::<Adt8, Adt74>(Adt74::C3))
                    }
                } else {
                    Ok(Err::<Adt8, Adt74>(Adt74::C2))
                }
            }
            Adt67::C3 => {
                if match v0.clone() {
                    Adt8::C0(_, h1246, _, _) => {
                        h1246
                    }
                } {
                    Ok(Err::<Adt8, Adt74>(Adt74::C4))
                } else {
                    Ok(Ok::<Adt8, Adt74>(Adt8::C0(match v0.clone() {
                        Adt8::C0(h1247, _, _, _) => {
                            h1247
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, h1248, _, _) => {
                            h1248
                        }
                    }, true, match v0 {
                        Adt8::C0(_, _, _, h1249) => {
                            h1249
                        }
                    })))
                }
            }
        }
    }
}

pub fn f41(v0: Adt1, v1: Adt52, v2: Adt22, v3: bool) -> R<Adt70> {
    if v3 {
        let m1251 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1250, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1250
            }
        };
        match m1251 {
            None => {
                Ok(f55(v0, v2))
            }
            Some(v4) => {
                f56(v0, v1, f57(v4.clone()), f58(v4, v2))
            }
        }
    } else {
        Ok(f55(v0, v2))
    }
}

pub fn f42(v0: Adt1, v1: Adt52, v2: Adt41) -> Adt70 {
    if f4(v0.clone(), v1.clone()) {
        Adt70::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1252, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1252
            }
        }, f59(match v0.clone() {
            Adt1::C0(_, h1253, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1253
            }
        }, match v1.clone() {
            Adt52::C0(_, h1254, _) => {
                h1254
            }
        }, match v1.clone() {
            Adt52::C0(_, _, h1255) => {
                h1255
            }
        }, Adt4::C5), f20(match v0.clone() {
            Adt1::C0(_, _, h1256, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1256
            }
        }, Adt7::C2), match v0.clone() {
            Adt1::C0(_, _, _, h1257, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1257
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1258, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1258
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1259, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1259
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1260, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1260
            }
        }, None::<Adt11>, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1261, _, _, _, _, _, _, _, _, _, _, _) => {
                h1261
            }
        }, Some(v2), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1262, _, _, _, _, _, _, _, _, _) => {
                h1262
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1263, _, _, _, _, _, _, _, _) => {
                h1263
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1264, _, _, _, _, _, _, _) => {
                h1264
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1265, _, _, _, _, _, _) => {
                h1265
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1266, _, _, _, _, _) => {
                h1266
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1267, _, _, _, _) => {
                h1267
            }
        }, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1268, _, _) => {
                h1268
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1269, _) => {
                h1269
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1270) => {
                h1270
            }
        }), List::cons(Adt66::C5(v1), List::<Adt66>::nil()))
    } else {
        Adt70::C0(v0, List::<Adt66>::nil())
    }
}

pub fn f43(v0: Adt1) -> bool {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1271, _, _, _, _, _, _, _) => {
            h1271
        }
    } {
        let a1273 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1272, _, _, _, _, _, _) => {
                h1272
            }
        };
        if bool_not(a1273) {
            let a1275 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1274, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1274
                }
            };
            if bool_not(a1275) {
                let m1278 = match v0.clone() {
                    Adt1::C0(_, _, h1277, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1277
                    }
                };
                if match m1278 {
                    Adt5::C0(_, _, _, h1276, _) => {
                        h1276
                    }
                } {
                    let m1280 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h1279, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1279
                        }
                    };
                    if match m1280 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    } {
                        let m1284 = {
                            let m1283 = match v0 {
                                Adt1::C0(_, _, h1282, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1282
                                }
                            };
                            match m1283 {
                                Adt5::C0(_, _, _, _, h1281) => {
                                    h1281
                                }
                            }
                        };
                        match m1284 {
                            Adt7::C0 => {
                                true
                            }
                            Adt7::C1 => {
                                false
                            }
                            Adt7::C2 => {
                                true
                            }
                            Adt7::C3 => {
                                false
                            }
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f44(v0: Adt5) -> Adt5 {
    Adt5::C0(match v0.clone() {
        Adt5::C0(h1285, _, _, _, _) => {
            h1285
        }
    }, match v0.clone() {
        Adt5::C0(_, h1286, _, _, _) => {
            h1286
        }
    }, match v0.clone() {
        Adt5::C0(_, _, h1287, _, _) => {
            h1287
        }
    }, match v0 {
        Adt5::C0(_, _, _, h1288, _) => {
            h1288
        }
    }, Adt7::C0)
}

pub fn f45(v0: Adt5, v1: Adt7) -> Result<Adt5, Adt44> {
    if f60(v0.clone()) {
        let m1289 = v1;
        match m1289 {
            Adt7::C0 => {
                Err::<Adt5, Adt44>(Adt44::C3)
            }
            Adt7::C1 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h1290, _, _, _, _) => {
                        h1290
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h1291, _, _, _) => {
                        h1291
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h1292, _, _) => {
                        h1292
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h1293, _) => {
                        h1293
                    }
                }, Adt7::C1))
            }
            Adt7::C2 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h1294, _, _, _, _) => {
                        h1294
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h1295, _, _, _) => {
                        h1295
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h1296, _, _) => {
                        h1296
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h1297, _) => {
                        h1297
                    }
                }, Adt7::C2))
            }
            Adt7::C3 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h1298, _, _, _, _) => {
                        h1298
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h1299, _, _, _) => {
                        h1299
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h1300, _, _) => {
                        h1300
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h1301, _) => {
                        h1301
                    }
                }, Adt7::C3))
            }
        }
    } else {
        Err::<Adt5, Adt44>(Adt44::C3)
    }
}

pub fn f46(v0: Adt5, v1: u64, v2: u64) -> R<Result<Adt5, Adt44>> {
    let m1303 = match v0.clone() {
        Adt5::C0(h1302, _, _, _, _) => {
            h1302
        }
    };
    match m1303 {
        Adt6::C0 => {
            let a1305 = match v0.clone() {
                Adt5::C0(_, _, h1304, _, _) => {
                    h1304
                }
            };
            let a1306 = v2;
            if if nat_le(a1305, a1306) {
                let a1310 = v1;
                let a1311 = {
                    let a1308 = v2;
                    let a1309 = match v0.clone() {
                        Adt5::C0(_, _, h1307, _, _) => {
                            h1307
                        }
                    };
                    nat_sub(a1308, a1309)
                };
                nat_le(a1310, a1311)
            } else {
                false
            } {
                Ok(Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h1312, _, _, _, _) => {
                        h1312
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h1313, _, _, _) => {
                        h1313
                    }
                }, {
                    let a1315 = match v0.clone() {
                        Adt5::C0(_, _, h1314, _, _) => {
                            h1314
                        }
                    };
                    let a1316 = v1;
                    nat_add(a1315, a1316)?
                }, match v0.clone() {
                    Adt5::C0(_, _, _, h1317, _) => {
                        h1317
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, _, h1318) => {
                        h1318
                    }
                })))
            } else {
                Ok(Err::<Adt5, Adt44>(Adt44::C4))
            }
        }
        Adt6::C1 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C2 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C3 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C4 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
    }
}

pub fn f47(v0: Adt9) -> Adt12 {
    let m1319 = v0;
    match m1319 {
        Adt9::C0(v1) => {
            match v1 {
                Adt10::C0(_, h1320) => {
                    h1320
                }
            }
        }
        Adt9::C1(v2) => {
            match v2 {
                Adt15::C0(_, h1321) => {
                    h1321
                }
            }
        }
        Adt9::C2(v3) => {
            match v3 {
                Adt15::C0(_, h1322) => {
                    h1322
                }
            }
        }
        Adt9::C3(v4) => {
            match v4 {
                Adt16::C0(_, _, _, h1323) => {
                    h1323
                }
            }
        }
        Adt9::C4(v5) => {
            match v5 {
                Adt17::C0(_, _, h1324) => {
                    h1324
                }
            }
        }
        Adt9::C5(v6) => {
            match v6 {
                Adt18::C0(_, h1325) => {
                    h1325
                }
            }
        }
        Adt9::C6(v7) => {
            match v7 {
                Adt19::C0(_, _, h1326) => {
                    h1326
                }
            }
        }
        Adt9::C7(v8) => {
            match v8 {
                Adt20::C0(_, _, _, h1327) => {
                    h1327
                }
            }
        }
        Adt9::C8(v9) => {
            match v9 {
                Adt21::C0(_, h1328) => {
                    h1328
                }
            }
        }
        Adt9::C9(v10) => {
            match v10 {
                Adt21::C0(_, h1329) => {
                    h1329
                }
            }
        }
    }
}

pub fn f48(v0: Adt1, v1: Adt50) -> Adt70 {
    let m1331 = match v1.clone() {
        Adt50::C0(_, h1330) => {
            h1330
        }
    };
    match m1331 {
        None => {
            Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1332, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1332
                }
            }, match v0.clone() {
                Adt1::C0(_, h1333, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1333
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1334, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1334
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1335, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1335
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1336, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1336
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1337, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1337
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1338, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1338
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1339, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1339
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1340, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1340
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1341, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1341
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1342, _, _, _, _, _, _, _, _, _, _) => {
                    h1342
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1343, _, _, _, _, _, _, _, _, _) => {
                    h1343
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1344, _, _, _, _, _, _, _, _) => {
                    h1344
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1345, _, _, _, _, _, _, _) => {
                    h1345
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1346, _, _, _, _, _, _) => {
                    h1346
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1347, _, _, _, _, _) => {
                    h1347
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1348, _, _, _, _) => {
                    h1348
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1349, _, _, _) => {
                    h1349
                }
            }, v1, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1350, _) => {
                    h1350
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1351) => {
                    h1351
                }
            }), List::<Adt66>::nil())
        }
        Some(v2) => {
            Adt70::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1352, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1352
                }
            }, match v0.clone() {
                Adt1::C0(_, h1353, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1353
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1354, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1354
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1355, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1355
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1356, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1356
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1357, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1357
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1358, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1358
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1359, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1359
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1360, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1360
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1361, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1361
                }
            }, Some(Adt41::C16(v2)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1362, _, _, _, _, _, _, _, _, _) => {
                    h1362
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1363, _, _, _, _, _, _, _, _) => {
                    h1363
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1364, _, _, _, _, _, _, _) => {
                    h1364
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1365, _, _, _, _, _, _) => {
                    h1365
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1366, _, _, _, _, _) => {
                    h1366
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1367, _, _, _, _) => {
                    h1367
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1368, _, _, _) => {
                    h1368
                }
            }, v1, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1369, _) => {
                    h1369
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1370) => {
                    h1370
                }
            }), List::<Adt66>::nil())
        }
    }
}

pub fn f49(v0: Adt14, v1: Adt50, v2: Adt63) -> R<Adt50> {
    let m1371 = v2;
    match m1371 {
        Adt63::C0(v3, v4) => {
            let m1373 = f61(v0, match v1.clone() {
                Adt50::C0(h1372, _) => {
                    h1372
                }
            }, v3, v4)?;
            match m1373 {
                Ok(v6) => {
                    Ok(Adt50::C0(v6, None::<Adt45>))
                }
                Err(v5) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h1374, _) => {
                            h1374
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt63::C1(v7, v8, v9) => {
            let m1376 = f62(match v1.clone() {
                Adt50::C0(h1375, _) => {
                    h1375
                }
            }, v7, v8, v9)?;
            match m1376 {
                Ok(v11) => {
                    Ok(Adt50::C0(v11, None::<Adt45>))
                }
                Err(v10) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h1377, _) => {
                            h1377
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt63::C2(v12, v13, v14) => {
            let m1379 = f62(match v1.clone() {
                Adt50::C0(h1378, _) => {
                    h1378
                }
            }, v12, v13, v14)?;
            match m1379 {
                Ok(v16) => {
                    Ok(Adt50::C0(v16, None::<Adt45>))
                }
                Err(v15) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h1380, _) => {
                            h1380
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt63::C3(v17, v18) => {
            let m1382 = f63(match v1.clone() {
                Adt50::C0(h1381, _) => {
                    h1381
                }
            }, v17, v18)?;
            match m1382 {
                Ok(v20) => {
                    Ok(Adt50::C0(v20, None::<Adt45>))
                }
                Err(v19) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h1383, _) => {
                            h1383
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt63::C4(v21, v22) => {
            let m1385 = f63(match v1.clone() {
                Adt50::C0(h1384, _) => {
                    h1384
                }
            }, v21, v22)?;
            match m1385 {
                Ok(v24) => {
                    Ok(Adt50::C0(v24, None::<Adt45>))
                }
                Err(v23) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h1386, _) => {
                            h1386
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f50(v0: Adt52, v1: Adt52) -> bool {
    let a1389 = match v0.clone() {
        Adt52::C0(h1387, _, _) => {
            h1387
        }
    };
    let a1390 = match v1.clone() {
        Adt52::C0(h1388, _, _) => {
            h1388
        }
    };
    if nat_eq(a1389, a1390) {
        let a1393 = match v0.clone() {
            Adt52::C0(_, h1391, _) => {
                h1391
            }
        };
        let a1394 = match v1.clone() {
            Adt52::C0(_, h1392, _) => {
                h1392
            }
        };
        if nat_eq(a1393, a1394) {
            let a1397 = match v0 {
                Adt52::C0(_, _, h1395) => {
                    h1395
                }
            };
            let a1398 = match v1 {
                Adt52::C0(_, _, h1396) => {
                    h1396
                }
            };
            nat_eq(a1397, a1398)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f51(v0: Adt24) -> R<u64> {
    f64(match v0 {
        Adt24::C0(h1399, _, _, _) => {
            h1399
        }
    })
}

pub fn f52(v0: Adt24) -> R<u64> {
    f64(match v0 {
        Adt24::C0(_, h1400, _, _) => {
            h1400
        }
    })
}

pub fn f53() -> Adt24 {
    Adt24::C0(f65(), f65(), 0u64, 0u64)
}

pub fn f54() -> Adt14 {
    Adt14::C0(None::<u64>, None::<u64>, None::<u64>, None::<u64>, None::<u64>)
}

pub fn f55(v0: Adt1, v1: Adt22) -> Adt70 {
    Adt70::C0(v0.clone(), {
        let m1407 = {
            let m1403 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1402, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1402
                }
            };
            match m1403 {
                None => {
                    Adt70::C0(v0, f15(match v1 {
                        Adt22::C0(_, _, _, _, _, _, _, _, h1404, _) => {
                            h1404
                        }
                    }))
                }
                Some(v2) => {
                    let m1406 = match v1 {
                        Adt22::C0(_, _, _, _, _, _, _, _, h1405, _) => {
                            h1405
                        }
                    };
                    match m1406 {
                        None => {
                            Adt70::C0(v0, List::<Adt66>::nil())
                        }
                        Some(v3) => {
                            if f66(v2, v3.clone()) {
                                Adt70::C0(v0, List::<Adt66>::nil())
                            } else {
                                Adt70::C0(v0, List::cons(Adt66::C6(v3), List::<Adt66>::nil()))
                            }
                        }
                    }
                }
            }
        };
        match m1407 {
            Adt70::C0(_, h1401) => {
                h1401
            }
        }
    })
}

pub fn f56(v0: Adt1, v1: Adt52, v2: Adt54, v3: Adt22) -> R<Adt70> {
    if f67(v0.clone(), v2.clone(), v3.clone())? {
        let m1408 = f68(v2.clone(), v3.clone());
        match m1408 {
            Adt75::C0 => {
                let m1410 = f69(match v0.clone() {
                    Adt1::C0(_, _, h1409, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1409
                    }
                });
                match m1410 {
                    Ok(v5) => {
                        Ok(Adt70::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1411, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1411
                            }
                        }, f59(match v0.clone() {
                            Adt1::C0(_, h1412, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1412
                            }
                        }, match v1.clone() {
                            Adt52::C0(_, h1413, _) => {
                                h1413
                            }
                        }, match v1 {
                            Adt52::C0(_, _, h1414) => {
                                h1414
                            }
                        }, {
                            let m1415 = v2;
                            match m1415 {
                                Adt54::C0 => {
                                    Adt4::C2
                                }
                                Adt54::C1 => {
                                    Adt4::C3
                                }
                                Adt54::C2 => {
                                    Adt4::C1
                                }
                                Adt54::C3 => {
                                    Adt4::C1
                                }
                                Adt54::C4 => {
                                    Adt4::C2
                                }
                                Adt54::C5 => {
                                    Adt4::C2
                                }
                                Adt54::C6 => {
                                    Adt4::C1
                                }
                                Adt54::C7 => {
                                    Adt4::C1
                                }
                                Adt54::C8 => {
                                    Adt4::C1
                                }
                                Adt54::C9 => {
                                    Adt4::C1
                                }
                            }
                        }), v5, match v0.clone() {
                            Adt1::C0(_, _, _, h1416, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1416
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1417, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1417
                            }
                        }, Some(v3.clone()), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1418, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1418
                            }
                        }, match v3.clone() {
                            Adt22::C0(_, _, _, _, _, _, _, _, h1419, _) => {
                                h1419
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h1420, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1420
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1421, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1421
                            }
                        }, None::<Adt41>, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1422, _, _, _, _, _, _, _, _, _) => {
                                h1422
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1423, _, _, _, _, _, _, _, _) => {
                                h1423
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1424, _, _, _, _, _, _, _) => {
                                h1424
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1425, _, _, _, _, _, _) => {
                                h1425
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1426, _, _, _, _, _) => {
                                h1426
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1427, _, _, _, _) => {
                                h1427
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1428, _, _, _) => {
                                h1428
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1429, _, _) => {
                                h1429
                            }
                        }, Some(match v3 {
                            Adt22::C0(h1430, _, _, _, _, _, _, _, _, _) => {
                                h1430
                            }
                        }), match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1431) => {
                                h1431
                            }
                        }), List::<Adt66>::nil()))
                    }
                    Err(v4) => {
                        Ok(f42(v0, v1, Adt41::C11(v4)))
                    }
                }
            }
            Adt75::C1 => {
                Ok(f42(v0, v1, Adt41::C12))
            }
            Adt75::C2 => {
                Ok(f42(v0, v1, Adt41::C13))
            }
            Adt75::C3 => {
                Ok(f42(v0, v1, Adt41::C7))
            }
            Adt75::C4 => {
                Ok(f42(v0, v1, Adt41::C5))
            }
        }
    } else {
        Ok(f42(v0, v1, Adt41::C15(Str::lit("Staged output ownership or byte count does not match the operation."))))
    }
}

pub fn f57(v0: Adt9) -> Adt54 {
    let m1432 = v0;
    match m1432 {
        Adt9::C0(_) => {
            Adt54::C0
        }
        Adt9::C1(_) => {
            Adt54::C1
        }
        Adt9::C2(_) => {
            Adt54::C2
        }
        Adt9::C3(_) => {
            Adt54::C3
        }
        Adt9::C4(_) => {
            Adt54::C4
        }
        Adt9::C5(_) => {
            Adt54::C5
        }
        Adt9::C6(_) => {
            Adt54::C6
        }
        Adt9::C7(_) => {
            Adt54::C7
        }
        Adt9::C8(_) => {
            Adt54::C8
        }
        Adt9::C9(_) => {
            Adt54::C9
        }
    }
}

pub fn f58(v0: Adt9, v1: Adt22) -> Adt22 {
    Adt22::C0(match v1.clone() {
        Adt22::C0(h1433, _, _, _, _, _, _, _, _, _) => {
            h1433
        }
    }, match v1.clone() {
        Adt22::C0(_, h1434, _, _, _, _, _, _, _, _) => {
            h1434
        }
    }, match v1.clone() {
        Adt22::C0(_, _, h1435, _, _, _, _, _, _, _) => {
            h1435
        }
    }, f70(v0), match v1.clone() {
        Adt22::C0(_, _, _, _, h1436, _, _, _, _, _) => {
            h1436
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, h1437, _, _, _, _) => {
            h1437
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, h1438, _, _, _) => {
            h1438
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, _, h1439, _, _) => {
            h1439
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, _, _, h1440, _) => {
            h1440
        }
    }, match v1 {
        Adt22::C0(_, _, _, _, _, _, _, _, _, h1441) => {
            h1441
        }
    })
}

pub fn f59(v0: Adt2, v1: u64, v2: u64, v3: Adt4) -> Adt2 {
    if f27(v0.clone(), v1, v2) {
        Adt2::C0(match v0.clone() {
            Adt2::C0(h1442, _, _, _, _, _) => {
                h1442
            }
        }, match v0 {
            Adt2::C0(_, h1443, _, _, _, _) => {
                h1443
            }
        }, false, true, {
            let m1444 = v3.clone();
            match m1444 {
                Adt4::C0 => {
                    Adt3::C6
                }
                Adt4::C1 => {
                    Adt3::C4
                }
                Adt4::C2 => {
                    Adt3::C4
                }
                Adt4::C3 => {
                    Adt3::C4
                }
                Adt4::C4 => {
                    Adt3::C4
                }
                Adt4::C5 => {
                    Adt3::C6
                }
            }
        }, v3)
    } else {
        v0
    }
}

pub fn f60(v0: Adt5) -> bool {
    let m1446 = match v0.clone() {
        Adt5::C0(h1445, _, _, _, _) => {
            h1445
        }
    };
    match m1446 {
        Adt6::C0 => {
            false
        }
        Adt6::C1 => {
            false
        }
        Adt6::C2 => {
            if match v0.clone() {
                Adt5::C0(_, _, _, h1447, _) => {
                    h1447
                }
            } {
                let m1449 = match v0 {
                    Adt5::C0(_, _, _, _, h1448) => {
                        h1448
                    }
                };
                match m1449 {
                    Adt7::C0 => {
                        true
                    }
                    Adt7::C1 => {
                        false
                    }
                    Adt7::C2 => {
                        false
                    }
                    Adt7::C3 => {
                        false
                    }
                }
            } else {
                false
            }
        }
        Adt6::C3 => {
            false
        }
        Adt6::C4 => {
            false
        }
    }
}

pub fn f61(v0: Adt14, v1: Adt24, v2: Adt46, v3: u64) -> R<Result<Adt24, Adt45>> {
    if f71(match v0.clone() {
        Adt14::C0(h1450, _, _, _, _) => {
            h1450
        }
    }, f72(v1.clone())?, v3)? {
        if f71(f73(v0.clone(), v2.clone()), {
            let a1453 = f74(match v1.clone() {
                Adt24::C0(h1451, _, _, _) => {
                    h1451
                }
            }, v2.clone());
            let a1454 = f74(match v1.clone() {
                Adt24::C0(_, h1452, _, _) => {
                    h1452
                }
            }, v2.clone());
            nat_add(a1453, a1454)?
        }, v3)? {
            Ok(Ok::<Adt24, Adt45>(Adt24::C0(match v1.clone() {
                Adt24::C0(h1455, _, _, _) => {
                    h1455
                }
            }, f75(match v1.clone() {
                Adt24::C0(_, h1456, _, _) => {
                    h1456
                }
            }, v2.clone(), {
                let a1458 = f74(match v1.clone() {
                    Adt24::C0(_, h1457, _, _) => {
                        h1457
                    }
                }, v2.clone());
                let a1459 = v3;
                nat_add(a1458, a1459)?
            }), f76(match v1.clone() {
                Adt24::C0(_, _, h1460, _) => {
                    h1460
                }
            }, f64(match v1.clone() {
                Adt24::C0(h1461, _, _, _) => {
                    h1461
                }
            })?), f76(match v1.clone() {
                Adt24::C0(_, _, _, h1462) => {
                    h1462
                }
            }, {
                let a1468 = f64(match v1.clone() {
                    Adt24::C0(h1463, _, _, _) => {
                        h1463
                    }
                })?;
                let a1469 = f64(f75(match v1.clone() {
                    Adt24::C0(_, h1464, _, _) => {
                        h1464
                    }
                }, v2.clone(), {
                    let a1466 = f74(match v1 {
                        Adt24::C0(_, h1465, _, _) => {
                            h1465
                        }
                    }, v2);
                    let a1467 = v3;
                    nat_add(a1466, a1467)?
                }))?;
                nat_add(a1468, a1469)?
            }))))
        } else {
            Ok(Err::<Adt24, Adt45>(Adt45::C1(v2.clone(), {
                let a1472 = f74(match v1.clone() {
                    Adt24::C0(h1470, _, _, _) => {
                        h1470
                    }
                }, v2.clone());
                let a1473 = f74(match v1 {
                    Adt24::C0(_, h1471, _, _) => {
                        h1471
                    }
                }, v2.clone());
                nat_add(a1472, a1473)?
            }, v3, {
                let m1474 = f73(v0, v2);
                match m1474 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C0(f72(v1)?, v3, {
            let m1476 = match v0 {
                Adt14::C0(h1475, _, _, _, _) => {
                    h1475
                }
            };
            match m1476 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f62(v0: Adt24, v1: Adt46, v2: u64, v3: u64) -> R<Result<Adt24, Adt45>> {
    let a1480 = {
        let a1478 = f74(match v0.clone() {
            Adt24::C0(_, h1477, _, _) => {
                h1477
            }
        }, v1.clone());
        let a1479 = v2;
        nat_lt(a1478, a1479)
    };
    if if bool_not(a1480) {
        let a1483 = {
            let a1481 = v2;
            let a1482 = v3;
            nat_lt(a1481, a1482)
        };
        bool_not(a1483)
    } else {
        false
    } {
        Ok(Ok::<Adt24, Adt45>(Adt24::C0(f75(match v0.clone() {
            Adt24::C0(h1484, _, _, _) => {
                h1484
            }
        }, v1.clone(), {
            let a1486 = f74(match v0.clone() {
                Adt24::C0(h1485, _, _, _) => {
                    h1485
                }
            }, v1.clone());
            let a1487 = v3;
            nat_add(a1486, a1487)?
        }), f75(match v0.clone() {
            Adt24::C0(_, h1488, _, _) => {
                h1488
            }
        }, v1.clone(), {
            let a1490 = f74(match v0.clone() {
                Adt24::C0(_, h1489, _, _) => {
                    h1489
                }
            }, v1.clone());
            let a1491 = v2;
            nat_sub(a1490, a1491)
        }), f76(match v0.clone() {
            Adt24::C0(_, _, h1492, _) => {
                h1492
            }
        }, f64(f75(match v0.clone() {
            Adt24::C0(h1493, _, _, _) => {
                h1493
            }
        }, v1.clone(), {
            let a1495 = f74(match v0.clone() {
                Adt24::C0(h1494, _, _, _) => {
                    h1494
                }
            }, v1.clone());
            let a1496 = v3;
            nat_add(a1495, a1496)?
        }))?), f76(match v0.clone() {
            Adt24::C0(_, _, _, h1497) => {
                h1497
            }
        }, {
            let a1506 = f64(f75(match v0.clone() {
                Adt24::C0(h1498, _, _, _) => {
                    h1498
                }
            }, v1.clone(), {
                let a1500 = f74(match v0.clone() {
                    Adt24::C0(h1499, _, _, _) => {
                        h1499
                    }
                }, v1.clone());
                let a1501 = v3;
                nat_add(a1500, a1501)?
            }))?;
            let a1507 = f64(f75(match v0.clone() {
                Adt24::C0(_, h1502, _, _) => {
                    h1502
                }
            }, v1.clone(), {
                let a1504 = f74(match v0 {
                    Adt24::C0(_, h1503, _, _) => {
                        h1503
                    }
                }, v1);
                let a1505 = v2;
                nat_sub(a1504, a1505)
            }))?;
            nat_add(a1506, a1507)?
        }))))
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C2(v1, v2, v3)))
    }
}

pub fn f63(v0: Adt24, v1: Adt46, v2: u64) -> R<Result<Adt24, Adt45>> {
    let a1511 = {
        let a1509 = f74(match v0.clone() {
            Adt24::C0(h1508, _, _, _) => {
                h1508
            }
        }, v1.clone());
        let a1510 = v2;
        nat_lt(a1509, a1510)
    };
    if bool_not(a1511) {
        Ok(Ok::<Adt24, Adt45>(Adt24::C0(f75(match v0.clone() {
            Adt24::C0(h1512, _, _, _) => {
                h1512
            }
        }, v1.clone(), {
            let a1514 = f74(match v0.clone() {
                Adt24::C0(h1513, _, _, _) => {
                    h1513
                }
            }, v1.clone());
            let a1515 = v2;
            nat_sub(a1514, a1515)
        }), match v0.clone() {
            Adt24::C0(_, h1516, _, _) => {
                h1516
            }
        }, f76(match v0.clone() {
            Adt24::C0(_, _, h1517, _) => {
                h1517
            }
        }, f64(f75(match v0.clone() {
            Adt24::C0(h1518, _, _, _) => {
                h1518
            }
        }, v1.clone(), {
            let a1520 = f74(match v0.clone() {
                Adt24::C0(h1519, _, _, _) => {
                    h1519
                }
            }, v1.clone());
            let a1521 = v2;
            nat_sub(a1520, a1521)
        }))?), f76(match v0.clone() {
            Adt24::C0(_, _, _, h1522) => {
                h1522
            }
        }, {
            let a1528 = f64(f75(match v0.clone() {
                Adt24::C0(h1523, _, _, _) => {
                    h1523
                }
            }, v1.clone(), {
                let a1525 = f74(match v0.clone() {
                    Adt24::C0(h1524, _, _, _) => {
                        h1524
                    }
                }, v1);
                let a1526 = v2;
                nat_sub(a1525, a1526)
            }))?;
            let a1529 = f64(match v0 {
                Adt24::C0(_, h1527, _, _) => {
                    h1527
                }
            })?;
            nat_add(a1528, a1529)?
        }))))
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C3(v1.clone(), f74(match v0 {
            Adt24::C0(h1530, _, _, _) => {
                h1530
            }
        }, v1), v2)))
    }
}

pub fn f64(v0: Adt25) -> R<u64> {
    let a1541 = {
        let a1538 = {
            let a1535 = {
                let a1532 = 0u64;
                let a1533 = match v0.clone() {
                    Adt25::C0(h1531, _, _, _) => {
                        h1531
                    }
                };
                nat_add(a1532, a1533)?
            };
            let a1536 = match v0.clone() {
                Adt25::C0(_, h1534, _, _) => {
                    h1534
                }
            };
            nat_add(a1535, a1536)?
        };
        let a1539 = match v0.clone() {
            Adt25::C0(_, _, h1537, _) => {
                h1537
            }
        };
        nat_add(a1538, a1539)?
    };
    let a1542 = match v0 {
        Adt25::C0(_, _, _, h1540) => {
            h1540
        }
    };
    nat_add(a1541, a1542)
}

pub fn f65() -> Adt25 {
    Adt25::C0(0u64, 0u64, 0u64, 0u64)
}

pub fn f66(v0: Adt11, v1: Adt11) -> bool {
    let a1545 = match v0.clone() {
        Adt11::C0(h1543, _, _) => {
            h1543
        }
    };
    let a1546 = match v1.clone() {
        Adt11::C0(h1544, _, _) => {
            h1544
        }
    };
    if nat_eq(a1545, a1546) {
        let a1549 = match v0.clone() {
            Adt11::C0(_, h1547, _) => {
                h1547
            }
        };
        let a1550 = match v1.clone() {
            Adt11::C0(_, h1548, _) => {
                h1548
            }
        };
        if nat_eq(a1549, a1550) {
            let a1553 = match v0 {
                Adt11::C0(_, _, h1551) => {
                    h1551
                }
            };
            let a1554 = match v1 {
                Adt11::C0(_, _, h1552) => {
                    h1552
                }
            };
            nat_eq(a1553, a1554)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f67(v0: Adt1, v1: Adt54, v2: Adt22) -> R<bool> {
    let a1561 = {
        let m1557 = match v2.clone() {
            Adt22::C0(h1556, _, _, _, _, _, _, _, _, _) => {
                h1556
            }
        };
        match m1557 {
            Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, h1555, _, _) => {
                h1555
            }
        }
    };
    let a1562 = {
        let m1560 = match v0.clone() {
            Adt1::C0(_, _, h1559, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1559
            }
        };
        match m1560 {
            Adt5::C0(_, _, h1558, _, _) => {
                h1558
            }
        }
    };
    if if nat_eq(a1561, a1562) {
        let m1564 = match v2.clone() {
            Adt22::C0(_, _, _, _, _, _, _, _, h1563, _) => {
                h1563
            }
        };
        match m1564 {
            None => {
                let m1565 = v1;
                match m1565 {
                    Adt54::C0 => {
                        false
                    }
                    Adt54::C1 => {
                        false
                    }
                    Adt54::C2 => {
                        true
                    }
                    Adt54::C3 => {
                        true
                    }
                    Adt54::C4 => {
                        false
                    }
                    Adt54::C5 => {
                        false
                    }
                    Adt54::C6 => {
                        true
                    }
                    Adt54::C7 => {
                        true
                    }
                    Adt54::C8 => {
                        true
                    }
                    Adt54::C9 => {
                        true
                    }
                }
            }
            Some(v3) => {
                let a1568 = match v3 {
                    Adt11::C0(h1566, _, _) => {
                        h1566
                    }
                };
                let a1569 = match v0.clone() {
                    Adt1::C0(h1567, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1567
                    }
                };
                if nat_eq(a1568, a1569) {
                    let m1570 = v1;
                    match m1570 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                } else {
                    false
                }
            }
        }
    } else {
        false
    } {
        if f77({
            let m1573 = match v2 {
                Adt22::C0(h1572, _, _, _, _, _, _, _, _, _) => {
                    h1572
                }
            };
            match m1573 {
                Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1571, _) => {
                    h1571
                }
            }
        }, {
            let m1576 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1575, _, _) => {
                    h1575
                }
            };
            match m1576 {
                Adt50::C0(h1574, _) => {
                    h1574
                }
            }
        }) {
            let a1580 = f52({
                let m1579 = match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1578, _, _) => {
                        h1578
                    }
                };
                match m1579 {
                    Adt50::C0(h1577, _) => {
                        h1577
                    }
                }
            })?;
            let a1581 = 0u64;
            if nat_eq(a1580, a1581) {
                let m1585 = {
                    let m1584 = match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1583, _, _) => {
                            h1583
                        }
                    };
                    match m1584 {
                        Adt50::C0(_, h1582) => {
                            h1582
                        }
                    }
                };
                match m1585 {
                    None => {
                        Ok(true)
                    }
                    Some(_) => {
                        Ok(false)
                    }
                }
            } else {
                Ok(false)
            }
        } else {
            Ok(false)
        }
    } else {
        Ok(false)
    }
}

pub fn f68(v0: Adt54, v1: Adt22) -> Adt75 {
    let m1586 = v0;
    match m1586 {
        Adt54::C0 => {
            let m1589 = match v1.clone() {
                Adt22::C0(_, h1588, _, _, _, _, _, _, _, _) => {
                    h1588
                }
            };
            if if match m1589 {
                Adt28::C0(h1587, _, _, _, _) => {
                    h1587
                }
            } {
                let m1592 = match v1.clone() {
                    Adt22::C0(_, h1591, _, _, _, _, _, _, _, _) => {
                        h1591
                    }
                };
                if match m1592 {
                    Adt28::C0(_, h1590, _, _, _) => {
                        h1590
                    }
                } {
                    let m1595 = match v1.clone() {
                        Adt22::C0(_, h1594, _, _, _, _, _, _, _, _) => {
                            h1594
                        }
                    };
                    if match m1595 {
                        Adt28::C0(_, _, h1593, _, _) => {
                            h1593
                        }
                    } {
                        if match v1.clone() {
                            Adt22::C0(_, _, h1596, _, _, _, _, _, _, _) => {
                                h1596
                            }
                        } {
                            if match v1.clone() {
                                Adt22::C0(_, _, _, h1597, _, _, _, _, _, _) => {
                                    h1597
                                }
                            } {
                                let m1600 = match v1.clone() {
                                    Adt22::C0(_, h1599, _, _, _, _, _, _, _, _) => {
                                        h1599
                                    }
                                };
                                match m1600 {
                                    Adt28::C0(_, _, _, h1598, _) => {
                                        h1598
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f78(match v1.clone() {
                    Adt22::C0(_, _, _, _, h1601, _, _, _, _, _) => {
                        h1601
                    }
                }, false, f79(match v1 {
                    Adt22::C0(_, _, _, _, _, h1602, _, _, _, _) => {
                        h1602
                    }
                }))
            } else {
                Adt75::C2
            }
        }
        Adt54::C1 => {
            f80({
                let m1605 = match v1.clone() {
                    Adt22::C0(_, h1604, _, _, _, _, _, _, _, _) => {
                        h1604
                    }
                };
                match m1605 {
                    Adt28::C0(h1603, _, _, _, _) => {
                        h1603
                    }
                }
            }, {
                let m1608 = match v1.clone() {
                    Adt22::C0(_, h1607, _, _, _, _, _, _, _, _) => {
                        h1607
                    }
                };
                match m1608 {
                    Adt28::C0(_, h1606, _, _, _) => {
                        h1606
                    }
                }
            }, {
                let m1611 = match v1.clone() {
                    Adt22::C0(_, h1610, _, _, _, _, _, _, _, _) => {
                        h1610
                    }
                };
                match m1611 {
                    Adt28::C0(_, _, h1609, _, _) => {
                        h1609
                    }
                }
            }, match v1 {
                Adt22::C0(_, _, h1612, _, _, _, _, _, _, _) => {
                    h1612
                }
            }, false)
        }
        Adt54::C2 => {
            let m1615 = match v1 {
                Adt22::C0(_, h1614, _, _, _, _, _, _, _, _) => {
                    h1614
                }
            };
            if match m1615 {
                Adt28::C0(h1613, _, _, _, _) => {
                    h1613
                }
            } {
                Adt75::C0
            } else {
                Adt75::C2
            }
        }
        Adt54::C3 => {
            if match v1.clone() {
                Adt22::C0(_, _, _, h1616, _, _, _, _, _, _) => {
                    h1616
                }
            } {
                let m1619 = match v1.clone() {
                    Adt22::C0(_, h1618, _, _, _, _, _, _, _, _) => {
                        h1618
                    }
                };
                if if match m1619 {
                    Adt28::C0(h1617, _, _, _, _) => {
                        h1617
                    }
                } {
                    let m1622 = match v1.clone() {
                        Adt22::C0(_, h1621, _, _, _, _, _, _, _, _) => {
                            h1621
                        }
                    };
                    if match m1622 {
                        Adt28::C0(_, h1620, _, _, _) => {
                            h1620
                        }
                    } {
                        let m1625 = match v1.clone() {
                            Adt22::C0(_, h1624, _, _, _, _, _, _, _, _) => {
                                h1624
                            }
                        };
                        if match m1625 {
                            Adt28::C0(_, _, h1623, _, _) => {
                                h1623
                            }
                        } {
                            let m1628 = match v1.clone() {
                                Adt22::C0(_, h1627, _, _, _, _, _, _, _, _) => {
                                    h1627
                                }
                            };
                            if match m1628 {
                                Adt28::C0(_, _, _, h1626, _) => {
                                    h1626
                                }
                            } {
                                match v1.clone() {
                                    Adt22::C0(_, _, h1629, _, _, _, _, _, _, _) => {
                                        h1629
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                } {
                    f78(match v1.clone() {
                        Adt22::C0(_, _, _, _, h1630, _, _, _, _, _) => {
                            h1630
                        }
                    }, false, f79(match v1 {
                        Adt22::C0(_, _, _, _, _, h1631, _, _, _, _) => {
                            h1631
                        }
                    }))
                } else {
                    Adt75::C2
                }
            } else {
                f80({
                    let m1634 = match v1.clone() {
                        Adt22::C0(_, h1633, _, _, _, _, _, _, _, _) => {
                            h1633
                        }
                    };
                    match m1634 {
                        Adt28::C0(h1632, _, _, _, _) => {
                            h1632
                        }
                    }
                }, {
                    let m1637 = match v1.clone() {
                        Adt22::C0(_, h1636, _, _, _, _, _, _, _, _) => {
                            h1636
                        }
                    };
                    match m1637 {
                        Adt28::C0(_, h1635, _, _, _) => {
                            h1635
                        }
                    }
                }, {
                    let m1640 = match v1.clone() {
                        Adt22::C0(_, h1639, _, _, _, _, _, _, _, _) => {
                            h1639
                        }
                    };
                    match m1640 {
                        Adt28::C0(_, _, h1638, _, _) => {
                            h1638
                        }
                    }
                }, match v1 {
                    Adt22::C0(_, _, h1641, _, _, _, _, _, _, _) => {
                        h1641
                    }
                }, false)
            }
        }
        Adt54::C4 => {
            let m1644 = match v1.clone() {
                Adt22::C0(_, h1643, _, _, _, _, _, _, _, _) => {
                    h1643
                }
            };
            if if match m1644 {
                Adt28::C0(h1642, _, _, _, _) => {
                    h1642
                }
            } {
                let m1647 = match v1.clone() {
                    Adt22::C0(_, h1646, _, _, _, _, _, _, _, _) => {
                        h1646
                    }
                };
                if match m1647 {
                    Adt28::C0(_, h1645, _, _, _) => {
                        h1645
                    }
                } {
                    let m1650 = match v1.clone() {
                        Adt22::C0(_, h1649, _, _, _, _, _, _, _, _) => {
                            h1649
                        }
                    };
                    if match m1650 {
                        Adt28::C0(_, _, h1648, _, _) => {
                            h1648
                        }
                    } {
                        if match v1.clone() {
                            Adt22::C0(_, _, h1651, _, _, _, _, _, _, _) => {
                                h1651
                            }
                        } {
                            if match v1.clone() {
                                Adt22::C0(_, _, _, h1652, _, _, _, _, _, _) => {
                                    h1652
                                }
                            } {
                                let m1655 = match v1.clone() {
                                    Adt22::C0(_, h1654, _, _, _, _, _, _, _, _) => {
                                        h1654
                                    }
                                };
                                match m1655 {
                                    Adt28::C0(_, _, _, h1653, _) => {
                                        h1653
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f78(match v1.clone() {
                    Adt22::C0(_, _, _, _, h1656, _, _, _, _, _) => {
                        h1656
                    }
                }, false, f79(match v1 {
                    Adt22::C0(_, _, _, _, _, h1657, _, _, _, _) => {
                        h1657
                    }
                }))
            } else {
                Adt75::C2
            }
        }
        Adt54::C5 => {
            if match v1 {
                Adt22::C0(_, _, _, _, _, _, _, h1658, _, _) => {
                    h1658
                }
            } {
                Adt75::C0
            } else {
                Adt75::C2
            }
        }
        Adt54::C6 => {
            Adt75::C0
        }
        Adt54::C7 => {
            Adt75::C0
        }
        Adt54::C8 => {
            Adt75::C0
        }
        Adt54::C9 => {
            Adt75::C0
        }
    }
}

pub fn f69(v0: Adt5) -> Result<Adt5, Adt44> {
    let m1660 = match v0.clone() {
        Adt5::C0(h1659, _, _, _, _) => {
            h1659
        }
    };
    match m1660 {
        Adt6::C0 => {
            if match v0.clone() {
                Adt5::C0(_, h1661, _, _, _) => {
                    h1661
                }
            } {
                Ok::<Adt5, Adt44>(Adt5::C0(Adt6::C2, match v0.clone() {
                    Adt5::C0(_, h1662, _, _, _) => {
                        h1662
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h1663, _, _) => {
                        h1663
                    }
                }, true, match v0 {
                    Adt5::C0(_, _, _, _, h1664) => {
                        h1664
                    }
                }))
            } else {
                Err::<Adt5, Adt44>(Adt44::C3)
            }
        }
        Adt6::C1 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C2 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C3 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C4 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
    }
}

pub fn f70(v0: Adt9) -> bool {
    let m1665 = v0;
    match m1665 {
        Adt9::C0(_) => {
            true
        }
        Adt9::C1(_) => {
            false
        }
        Adt9::C2(_) => {
            false
        }
        Adt9::C3(v4) => {
            let m1667 = match v4 {
                Adt16::C0(_, h1666, _, _) => {
                    h1666
                }
            };
            match m1667 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt9::C4(_) => {
            true
        }
        Adt9::C5(_) => {
            false
        }
        Adt9::C6(_) => {
            false
        }
        Adt9::C7(v9) => {
            let m1669 = match v9 {
                Adt20::C0(_, _, h1668, _) => {
                    h1668
                }
            };
            match m1669 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt9::C8(_) => {
            false
        }
        Adt9::C9(_) => {
            false
        }
    }
}

pub fn f71(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m1670 = v0;
    match m1670 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a1675 = {
                let a1673 = v3;
                let a1674 = {
                    let a1671 = v1;
                    let a1672 = v2;
                    nat_add(a1671, a1672)?
                };
                nat_lt(a1673, a1674)
            };
            Ok(bool_not(a1675))
        }
    }
}

pub fn f72(v0: Adt24) -> R<u64> {
    let a1676 = f51(v0.clone())?;
    let a1677 = f52(v0)?;
    nat_add(a1676, a1677)
}

pub fn f73(v0: Adt14, v1: Adt46) -> Option<u64> {
    let m1678 = v1;
    match m1678 {
        Adt46::C0 => {
            match v0 {
                Adt14::C0(_, h1679, _, _, _) => {
                    h1679
                }
            }
        }
        Adt46::C1 => {
            match v0 {
                Adt14::C0(_, _, h1680, _, _) => {
                    h1680
                }
            }
        }
        Adt46::C2 => {
            match v0 {
                Adt14::C0(_, _, _, h1681, _) => {
                    h1681
                }
            }
        }
        Adt46::C3 => {
            match v0 {
                Adt14::C0(_, _, _, _, h1682) => {
                    h1682
                }
            }
        }
    }
}

pub fn f74(v0: Adt25, v1: Adt46) -> u64 {
    let m1683 = v1;
    match m1683 {
        Adt46::C0 => {
            match v0 {
                Adt25::C0(h1684, _, _, _) => {
                    h1684
                }
            }
        }
        Adt46::C1 => {
            match v0 {
                Adt25::C0(_, h1685, _, _) => {
                    h1685
                }
            }
        }
        Adt46::C2 => {
            match v0 {
                Adt25::C0(_, _, h1686, _) => {
                    h1686
                }
            }
        }
        Adt46::C3 => {
            match v0 {
                Adt25::C0(_, _, _, h1687) => {
                    h1687
                }
            }
        }
    }
}

pub fn f75(v0: Adt25, v1: Adt46, v2: u64) -> Adt25 {
    let m1688 = v1;
    match m1688 {
        Adt46::C0 => {
            Adt25::C0(v2, match v0.clone() {
                Adt25::C0(_, h1689, _, _) => {
                    h1689
                }
            }, match v0.clone() {
                Adt25::C0(_, _, h1690, _) => {
                    h1690
                }
            }, match v0 {
                Adt25::C0(_, _, _, h1691) => {
                    h1691
                }
            })
        }
        Adt46::C1 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h1692, _, _, _) => {
                    h1692
                }
            }, v2, match v0.clone() {
                Adt25::C0(_, _, h1693, _) => {
                    h1693
                }
            }, match v0 {
                Adt25::C0(_, _, _, h1694) => {
                    h1694
                }
            })
        }
        Adt46::C2 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h1695, _, _, _) => {
                    h1695
                }
            }, match v0.clone() {
                Adt25::C0(_, h1696, _, _) => {
                    h1696
                }
            }, v2, match v0 {
                Adt25::C0(_, _, _, h1697) => {
                    h1697
                }
            })
        }
        Adt46::C3 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h1698, _, _, _) => {
                    h1698
                }
            }, match v0.clone() {
                Adt25::C0(_, h1699, _, _) => {
                    h1699
                }
            }, match v0 {
                Adt25::C0(_, _, h1700, _) => {
                    h1700
                }
            }, v2)
        }
    }
}

pub fn f76(v0: u64, v1: u64) -> u64 {
    let a1701 = v0;
    let a1702 = v1;
    if nat_lt(a1701, a1702) {
        v1
    } else {
        v0
    }
}

pub fn f77(v0: Adt24, v1: Adt24) -> bool {
    let a1709 = {
        let m1705 = match v0.clone() {
            Adt24::C0(h1704, _, _, _) => {
                h1704
            }
        };
        match m1705 {
            Adt25::C0(h1703, _, _, _) => {
                h1703
            }
        }
    };
    let a1710 = {
        let m1708 = match v1.clone() {
            Adt24::C0(h1707, _, _, _) => {
                h1707
            }
        };
        match m1708 {
            Adt25::C0(h1706, _, _, _) => {
                h1706
            }
        }
    };
    if nat_eq(a1709, a1710) {
        let a1717 = {
            let m1713 = match v0.clone() {
                Adt24::C0(h1712, _, _, _) => {
                    h1712
                }
            };
            match m1713 {
                Adt25::C0(_, h1711, _, _) => {
                    h1711
                }
            }
        };
        let a1718 = {
            let m1716 = match v1.clone() {
                Adt24::C0(h1715, _, _, _) => {
                    h1715
                }
            };
            match m1716 {
                Adt25::C0(_, h1714, _, _) => {
                    h1714
                }
            }
        };
        if nat_eq(a1717, a1718) {
            let a1725 = {
                let m1721 = match v0.clone() {
                    Adt24::C0(h1720, _, _, _) => {
                        h1720
                    }
                };
                match m1721 {
                    Adt25::C0(_, _, h1719, _) => {
                        h1719
                    }
                }
            };
            let a1726 = {
                let m1724 = match v1.clone() {
                    Adt24::C0(h1723, _, _, _) => {
                        h1723
                    }
                };
                match m1724 {
                    Adt25::C0(_, _, h1722, _) => {
                        h1722
                    }
                }
            };
            if nat_eq(a1725, a1726) {
                let a1733 = {
                    let m1729 = match v0.clone() {
                        Adt24::C0(h1728, _, _, _) => {
                            h1728
                        }
                    };
                    match m1729 {
                        Adt25::C0(_, _, _, h1727) => {
                            h1727
                        }
                    }
                };
                let a1734 = {
                    let m1732 = match v1.clone() {
                        Adt24::C0(h1731, _, _, _) => {
                            h1731
                        }
                    };
                    match m1732 {
                        Adt25::C0(_, _, _, h1730) => {
                            h1730
                        }
                    }
                };
                if nat_eq(a1733, a1734) {
                    let a1741 = {
                        let m1737 = match v0.clone() {
                            Adt24::C0(_, h1736, _, _) => {
                                h1736
                            }
                        };
                        match m1737 {
                            Adt25::C0(h1735, _, _, _) => {
                                h1735
                            }
                        }
                    };
                    let a1742 = {
                        let m1740 = match v1.clone() {
                            Adt24::C0(_, h1739, _, _) => {
                                h1739
                            }
                        };
                        match m1740 {
                            Adt25::C0(h1738, _, _, _) => {
                                h1738
                            }
                        }
                    };
                    if nat_eq(a1741, a1742) {
                        let a1749 = {
                            let m1745 = match v0.clone() {
                                Adt24::C0(_, h1744, _, _) => {
                                    h1744
                                }
                            };
                            match m1745 {
                                Adt25::C0(_, h1743, _, _) => {
                                    h1743
                                }
                            }
                        };
                        let a1750 = {
                            let m1748 = match v1.clone() {
                                Adt24::C0(_, h1747, _, _) => {
                                    h1747
                                }
                            };
                            match m1748 {
                                Adt25::C0(_, h1746, _, _) => {
                                    h1746
                                }
                            }
                        };
                        if nat_eq(a1749, a1750) {
                            let a1757 = {
                                let m1753 = match v0.clone() {
                                    Adt24::C0(_, h1752, _, _) => {
                                        h1752
                                    }
                                };
                                match m1753 {
                                    Adt25::C0(_, _, h1751, _) => {
                                        h1751
                                    }
                                }
                            };
                            let a1758 = {
                                let m1756 = match v1.clone() {
                                    Adt24::C0(_, h1755, _, _) => {
                                        h1755
                                    }
                                };
                                match m1756 {
                                    Adt25::C0(_, _, h1754, _) => {
                                        h1754
                                    }
                                }
                            };
                            if nat_eq(a1757, a1758) {
                                let a1765 = {
                                    let m1761 = match v0.clone() {
                                        Adt24::C0(_, h1760, _, _) => {
                                            h1760
                                        }
                                    };
                                    match m1761 {
                                        Adt25::C0(_, _, _, h1759) => {
                                            h1759
                                        }
                                    }
                                };
                                let a1766 = {
                                    let m1764 = match v1.clone() {
                                        Adt24::C0(_, h1763, _, _) => {
                                            h1763
                                        }
                                    };
                                    match m1764 {
                                        Adt25::C0(_, _, _, h1762) => {
                                            h1762
                                        }
                                    }
                                };
                                if nat_eq(a1765, a1766) {
                                    let a1769 = match v0.clone() {
                                        Adt24::C0(_, _, h1767, _) => {
                                            h1767
                                        }
                                    };
                                    let a1770 = match v1.clone() {
                                        Adt24::C0(_, _, h1768, _) => {
                                            h1768
                                        }
                                    };
                                    if nat_eq(a1769, a1770) {
                                        let a1773 = match v0 {
                                            Adt24::C0(_, _, _, h1771) => {
                                                h1771
                                            }
                                        };
                                        let a1774 = match v1 {
                                            Adt24::C0(_, _, _, h1772) => {
                                                h1772
                                            }
                                        };
                                        nat_eq(a1773, a1774)
                                    } else {
                                        false
                                    }
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f78(v0: Adt29, v1: bool, v2: Adt76) -> Adt75 {
    let m1775 = v0;
    match m1775 {
        Adt29::C0 => {
            if v1 {
                let m1776 = v2;
                if match m1776 {
                    Adt76::C0 => {
                        false
                    }
                    Adt76::C1 => {
                        true
                    }
                    Adt76::C2 => {
                        false
                    }
                    Adt76::C3 => {
                        false
                    }
                } {
                    Adt75::C0
                } else {
                    Adt75::C4
                }
            } else {
                Adt75::C0
            }
        }
        Adt29::C1 => {
            Adt75::C1
        }
        Adt29::C2 => {
            Adt75::C2
        }
        Adt29::C3 => {
            Adt75::C3
        }
    }
}

pub fn f79(v0: Adt30) -> Adt76 {
    let m1777 = v0;
    match m1777 {
        Adt30::C0 => {
            Adt76::C0
        }
        Adt30::C1(_) => {
            Adt76::C3
        }
        Adt30::C2(_) => {
            Adt76::C2
        }
        Adt30::C3(_) => {
            Adt76::C3
        }
        Adt30::C4(_) => {
            Adt76::C1
        }
    }
}

pub fn f80(v0: bool, v1: bool, v2: bool, v3: bool, v4: bool) -> Adt75 {
    if v4 {
        Adt75::C3
    } else {
        if if v0 {
            if v1 {
                if v2 {
                    if v3 {
                        let a1778 = v4;
                        bool_not(a1778)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        } {
            Adt75::C0
        } else {
            Adt75::C2
        }
    }
}
