#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt53, u64, Option<Adt55>, Adt56, List<Adt58>, Option<Adt60>),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, Adt2, Adt5, Adt8, Option<Adt9>, Option<Adt22>, Adt40, Option<Adt11>, bool, bool, Option<Adt41>, Option<Adt47>, Option<Adt11>, bool, bool, Adt48, Adt49, bool, Adt50, Option<Adt23>, List<Adt51>),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u64, u64, bool, bool, Adt3, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Adt6, bool, u64, bool, Adt7),
}

#[derive(Clone)]
pub enum Adt6 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt7 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, bool, bool, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(Adt10),
    C1(Adt15),
    C2(Adt15),
    C3(Adt16),
    C4(Adt17),
    C5(Adt18),
    C6(Adt19),
    C7(Adt20),
    C8(Adt21),
    C9(Adt21),
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt11 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt12 {
    C0(Adt13, Option<Adt11>),
}

#[derive(Clone)]
pub enum Adt13 {
    C0(u64, u64, u64, u64, Option<u64>, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt15 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt11, Option<Adt11>, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt17 {
    C0(Adt11, Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt19 {
    C0(Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt11, Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt23, Adt28, bool, bool, Adt29, Adt30, Adt32, bool, Option<Adt11>, Option<Adt33>),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, Adt24, Option<Adt26>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(Adt25, Adt25, u64, u64),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt26 {
    C0(Option<u64>, Option<u64>, Adt27, u64),
}

#[derive(Clone)]
pub enum Adt27 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt28 {
    C0(bool, bool, bool, bool, bool),
}

#[derive(Clone)]
pub enum Adt29 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt30 {
    C0,
    C1(Adt31),
    C2(Adt31),
    C3(Adt31),
    C4(Adt31),
}

#[derive(Clone)]
pub enum Adt31 {
    C0(Bytes, Adt11, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt32 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt33 {
    C0(Adt34),
    C1(Adt34),
    C2(Adt34),
    C3(u64),
    C4(Adt35),
    C5(Adt36),
    C6(Adt37),
    C7(Adt39),
}

#[derive(Clone)]
pub enum Adt34 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt35 {
    C0(Bytes, u64, u64),
}

#[derive(Clone)]
pub enum Adt36 {
    C0(Adt11, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt37 {
    C0(Adt38, Adt38, bool),
}

#[derive(Clone)]
pub enum Adt38 {
    C0(Adt23, Adt28, bool, Adt30),
}

#[derive(Clone)]
pub enum Adt39 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt40 {
    C0(u64, u64, u64, u64, u64, Str),
}

#[derive(Clone)]
pub enum Adt41 {
    C0(u64, Str),
    C1(u64, Str),
    C2(Bytes),
    C3(Bytes),
    C4,
    C5,
    C6(Adt42, u64),
    C7,
    C8(Str),
    C9(Adt7, Str),
    C10(Adt43),
    C11(Adt44),
    C12,
    C13,
    C14(Str),
    C15(Str),
    C16(Adt45),
}

#[derive(Clone)]
pub enum Adt42 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt43 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
    C12,
    C13,
    C14,
    C15,
    C16,
    C17,
}

#[derive(Clone)]
pub enum Adt44 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt45 {
    C0(u64, u64, u64),
    C1(Adt46, u64, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64, u64),
}

#[derive(Clone)]
pub enum Adt46 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt47 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt48 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt49 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt50 {
    C0(Adt24, Option<Adt45>),
}

#[derive(Clone)]
pub enum Adt51 {
    C0(Adt52, Adt14, Adt50, Option<Adt23>),
}

#[derive(Clone)]
pub enum Adt52 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt53 {
    C0(Adt54, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt54 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
}

#[derive(Clone)]
pub enum Adt55 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt56 {
    C0(u64, Adt57),
}

#[derive(Clone)]
pub enum Adt57 {
    C0(Adt55),
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt58 {
    C0(Adt55, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt59 {
    C0(u64, Str, Option<u64>),
}

#[derive(Clone)]
pub enum Adt60 {
    C0(Adt55, Adt52, u64, Adt11, List<Adt59>, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt61 {
    C0(Str, Str, Str, Str, Str, Option<Adt31>, List<Adt62>, List<Adt62>, List<Adt66>, List<Adt68>, Adt56, Adt69, bool, bool, bool, bool, Option<Adt70>, Option<Adt30>, Option<Adt32>, Option<Adt33>, Adt48, List<Adt62>, List<Adt62>, Option<Adt24>, Option<Adt26>, Str, List<Adt71>, Str),
}

#[derive(Clone)]
pub enum Adt62 {
    C0(Str, Str, Adt63, bool, bool),
}

#[derive(Clone)]
pub enum Adt63 {
    C0(Adt52, u64, Adt64),
}

#[derive(Clone)]
pub enum Adt64 {
    C0(Adt54),
    C1(Adt55),
    C2(Adt55),
    C3(Adt13),
    C4,
    C5(Adt65),
    C6(u64),
    C7(Adt55, u64),
    C8(Adt55, u64, u64),
}

#[derive(Clone)]
pub enum Adt65 {
    C0,
    C1(Adt48),
    C2,
    C3,
    C4,
    C5,
    C6,
    C7(u64),
    C8,
}

#[derive(Clone)]
pub enum Adt66 {
    C0(Adt55, Str, Adt63, bool, bool, bool, bool, Str, List<Adt67>, bool, bool),
}

#[derive(Clone)]
pub enum Adt67 {
    C0(u64, u64, Str, Option<u64>, bool, Adt63, Adt63, Adt63, bool, bool, bool, u64, Str, Str, Str),
}

#[derive(Clone)]
pub enum Adt68 {
    C0(Str, u64, Str),
}

#[derive(Clone)]
pub enum Adt69 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt70 {
    C0(bool, bool, bool, bool, bool, bool, bool),
}

#[derive(Clone)]
pub enum Adt71 {
    C0(Str, Str, Str, Str, bool, bool, Adt72, Str),
}

#[derive(Clone)]
pub enum Adt72 {
    C0(Adt52, u64, Adt73),
}

#[derive(Clone)]
pub enum Adt73 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
}

#[derive(Clone)]
pub enum Adt74 {
    C0,
    C1,
    C2,
    C3,
}

pub fn f0(v0: Adt0) -> R<Adt61> {
    Ok(Adt61::C0(Str::lit("UORC"), Str::lit("Compress and reconstruct arbitrary bytes"), f1(v0.clone()), {
        let m4 = {
            let m3 = match v0.clone() {
                Adt0::C0(h2, _, _, _, _, _, _) => {
                    h2
                }
            };
            match m3 {
                Adt1::C0(_, _, _, _, _, h1, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1
                }
            }
        };
        match m4 {
            None => {
                Str::lit("No result evidence")
            }
            Some(v1) => {
                f2({
                    let m8 = {
                        let m7 = match v0.clone() {
                            Adt0::C0(h6, _, _, _, _, _, _) => {
                                h6
                            }
                        };
                        match m7 {
                            Adt1::C0(_, _, _, _, h5, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h5
                            }
                        }
                    };
                    match m8 {
                        None => {
                            let m11 = match v0.clone() {
                                Adt0::C0(_, h10, _, _, _, _, _) => {
                                    h10
                                }
                            };
                            match m11 {
                                Adt53::C0(h9, _, _, _, _, _, _, _) => {
                                    h9
                                }
                            }
                        }
                        Some(v2) => {
                            f3(v2)
                        }
                    }
                }, v1)
            }
        }
    }, {
        let m15 = {
            let m14 = match v0.clone() {
                Adt0::C0(h13, _, _, _, _, _, _) => {
                    h13
                }
            };
            match m14 {
                Adt1::C0(_, _, _, _, _, h12, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h12
                }
            }
        };
        match m15 {
            None => {
                Str::lit("No original-byte comparison")
            }
            Some(v3) => {
                f4({
                    let m19 = {
                        let m18 = match v0.clone() {
                            Adt0::C0(h17, _, _, _, _, _, _) => {
                                h17
                            }
                        };
                        match m18 {
                            Adt1::C0(_, _, _, _, h16, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h16
                            }
                        }
                    };
                    match m19 {
                        None => {
                            let m22 = match v0.clone() {
                                Adt0::C0(_, h21, _, _, _, _, _) => {
                                    h21
                                }
                            };
                            match m22 {
                                Adt53::C0(h20, _, _, _, _, _, _, _) => {
                                    h20
                                }
                            }
                        }
                        Some(v4) => {
                            f3(v4)
                        }
                    }
                }, v3)
            }
        }
    }, {
        let m26 = {
            let m25 = match v0.clone() {
                Adt0::C0(h24, _, _, _, _, _, _) => {
                    h24
                }
            };
            match m25 {
                Adt1::C0(_, _, _, _, _, h23, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h23
                }
            }
        };
        match m26 {
            None => {
                None::<Adt31>
            }
            Some(v5) => {
                f5(v5)
            }
        }
    }, List::cons(Adt62::C0(Str::lit("start"), f6({
        let m29 = match v0.clone() {
            Adt0::C0(_, h28, _, _, _, _, _) => {
                h28
            }
        };
        match m29 {
            Adt53::C0(h27, _, _, _, _, _, _, _) => {
                h27
            }
        }
    }), f7(v0.clone(), Adt64::C4), {
        let m32 = match v0.clone() {
            Adt0::C0(h31, _, _, _, _, _, _) => {
                h31
            }
        };
        if if match m32 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h30, _, _, _, _, _, _, _) => {
                h30
            }
        } {
            let a36 = {
                let m35 = match v0.clone() {
                    Adt0::C0(h34, _, _, _, _, _, _) => {
                        h34
                    }
                };
                match m35 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h33, _, _, _, _, _, _) => {
                        h33
                    }
                }
            };
            bool_not(a36)
        } else {
            false
        } {
            let a42 = {
                let m41 = {
                    let m40 = match v0.clone() {
                        Adt0::C0(h39, _, _, _, _, _, _) => {
                            h39
                        }
                    };
                    match m40 {
                        Adt1::C0(_, h38, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h38
                        }
                    }
                };
                match m41 {
                    Adt2::C0(_, _, h37, _, _, _) => {
                        h37
                    }
                }
            };
            if bool_not(a42) {
                let a46 = {
                    let m45 = match v0.clone() {
                        Adt0::C0(h44, _, _, _, _, _, _) => {
                            h44
                        }
                    };
                    match m45 {
                        Adt1::C0(_, _, _, _, _, _, _, _, h43, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h43
                        }
                    }
                };
                if bool_not(a46) {
                    let m48 = f8(match v0.clone() {
                        Adt0::C0(_, h47, _, _, _, _, _) => {
                            h47
                        }
                    });
                    match m48 {
                        Ok(_) => {
                            true
                        }
                        Err(_) => {
                            false
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("cancel"), Str::lit("Cancel"), f7(v0.clone(), Adt64::C5(Adt65::C0)), {
        let m51 = match v0.clone() {
            Adt0::C0(h50, _, _, _, _, _, _) => {
                h50
            }
        };
        if if match m51 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h49, _, _, _, _, _, _, _) => {
                h49
            }
        } {
            let a55 = {
                let m54 = match v0.clone() {
                    Adt0::C0(h53, _, _, _, _, _, _) => {
                        h53
                    }
                };
                match m54 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h52, _, _, _, _, _, _) => {
                        h52
                    }
                }
            };
            bool_not(a55)
        } else {
            false
        } {
            let m60 = {
                let m59 = match v0.clone() {
                    Adt0::C0(h58, _, _, _, _, _, _) => {
                        h58
                    }
                };
                match m59 {
                    Adt1::C0(_, h57, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h57
                    }
                }
            };
            if match m60 {
                Adt2::C0(_, _, h56, _, _, _) => {
                    h56
                }
            } {
                true
            } else {
                let m63 = match v0.clone() {
                    Adt0::C0(h62, _, _, _, _, _, _) => {
                        h62
                    }
                };
                match m63 {
                    Adt1::C0(_, _, _, _, _, _, _, _, h61, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h61
                    }
                }
            }
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("download"), Str::lit("Download result"), f7(v0.clone(), Adt64::C5(Adt65::C6)), f9(match v0.clone() {
        Adt0::C0(h64, _, _, _, _, _, _) => {
            h64
        }
    }), true), List::cons(Adt62::C0(Str::lit("extend"), Str::lit("Continue search"), f7(v0.clone(), Adt64::C6(1000000u64)), {
        let m67 = match v0.clone() {
            Adt0::C0(h66, _, _, _, _, _, _) => {
                h66
            }
        };
        if if match m67 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h65, _, _, _, _, _, _, _) => {
                h65
            }
        } {
            let a71 = {
                let m70 = match v0.clone() {
                    Adt0::C0(h69, _, _, _, _, _, _) => {
                        h69
                    }
                };
                match m70 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h68, _, _, _, _, _, _) => {
                        h68
                    }
                }
            };
            bool_not(a71)
        } else {
            false
        } {
            let m76 = {
                let m75 = match v0.clone() {
                    Adt0::C0(h74, _, _, _, _, _, _) => {
                        h74
                    }
                };
                match m75 {
                    Adt1::C0(_, h73, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h73
                    }
                }
            };
            if match m76 {
                Adt2::C0(_, _, h72, _, _, _) => {
                    h72
                }
            } {
                true
            } else {
                let m80 = {
                    let m79 = match v0.clone() {
                        Adt0::C0(h78, _, _, _, _, _, _) => {
                            h78
                        }
                    };
                    match m79 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h77, _, _, _, _, _, _, _, _) => {
                            h77
                        }
                    }
                };
                if match m80 {
                    None => {
                        false
                    }
                    Some(_) => {
                        true
                    }
                } {
                    let m84 = {
                        let m83 = match v0.clone() {
                            Adt0::C0(_, h82, _, _, _, _, _) => {
                                h82
                            }
                        };
                        match m83 {
                            Adt53::C0(_, h81, _, _, _, _, _, _) => {
                                h81
                            }
                        }
                    };
                    match m84 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                } else {
                    false
                }
            }
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("back"), Str::lit("Back"), f7(v0.clone(), Adt64::C5(Adt65::C2)), {
        let m87 = match v0.clone() {
            Adt0::C0(h86, _, _, _, _, _, _) => {
                h86
            }
        };
        if match m87 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h85, _, _, _, _, _, _, _) => {
                h85
            }
        } {
            let a91 = {
                let m90 = match v0.clone() {
                    Adt0::C0(h89, _, _, _, _, _, _) => {
                        h89
                    }
                };
                match m90 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h88, _, _, _, _, _, _) => {
                        h88
                    }
                }
            };
            bool_not(a91)
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("advanced"), Str::lit("Advanced"), f7(v0.clone(), Adt64::C5(Adt65::C1(Adt48::C1))), {
        let m94 = match v0.clone() {
            Adt0::C0(h93, _, _, _, _, _, _) => {
                h93
            }
        };
        if match m94 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h92, _, _, _, _, _, _, _) => {
                h92
            }
        } {
            let a98 = {
                let m97 = match v0.clone() {
                    Adt0::C0(h96, _, _, _, _, _, _) => {
                        h96
                    }
                };
                match m97 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h95, _, _, _, _, _, _) => {
                        h95
                    }
                }
            };
            bool_not(a98)
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("evidence"), Str::lit("Evidence"), f7(v0.clone(), Adt64::C5(Adt65::C1(Adt48::C2))), {
        let m101 = match v0.clone() {
            Adt0::C0(h100, _, _, _, _, _, _) => {
                h100
            }
        };
        if match m101 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h99, _, _, _, _, _, _, _) => {
                h99
            }
        } {
            let a105 = {
                let m104 = match v0.clone() {
                    Adt0::C0(h103, _, _, _, _, _, _) => {
                        h103
                    }
                };
                match m104 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h102, _, _, _, _, _, _) => {
                        h102
                    }
                }
            };
            bool_not(a105)
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("close"), Str::lit("Close"), f7(v0.clone(), Adt64::C5(Adt65::C4)), {
        let m108 = match v0.clone() {
            Adt0::C0(h107, _, _, _, _, _, _) => {
                h107
            }
        };
        if match m108 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h106, _, _, _, _, _, _, _) => {
                h106
            }
        } {
            let a112 = {
                let m111 = match v0.clone() {
                    Adt0::C0(h110, _, _, _, _, _, _) => {
                        h110
                    }
                };
                match m111 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h109, _, _, _, _, _, _) => {
                        h109
                    }
                }
            };
            bool_not(a112)
        } else {
            false
        }
    }, true), List::<Adt62>::nil())))))))), List::cons(Adt62::C0(Str::lit("compress"), Str::lit("Compress"), f7(v0.clone(), Adt64::C0(Adt54::C0)), {
        let m115 = match v0.clone() {
            Adt0::C0(h114, _, _, _, _, _, _) => {
                h114
            }
        };
        if match m115 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h113, _, _, _, _, _, _, _) => {
                h113
            }
        } {
            let a119 = {
                let m118 = match v0.clone() {
                    Adt0::C0(h117, _, _, _, _, _, _) => {
                        h117
                    }
                };
                match m118 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h116, _, _, _, _, _, _) => {
                        h116
                    }
                }
            };
            bool_not(a119)
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("decompress"), Str::lit("Decompress"), f7(v0.clone(), Adt64::C0(Adt54::C1)), {
        let m122 = match v0.clone() {
            Adt0::C0(h121, _, _, _, _, _, _) => {
                h121
            }
        };
        if match m122 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h120, _, _, _, _, _, _, _) => {
                h120
            }
        } {
            let a126 = {
                let m125 = match v0.clone() {
                    Adt0::C0(h124, _, _, _, _, _, _) => {
                        h124
                    }
                };
                match m125 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h123, _, _, _, _, _, _) => {
                        h123
                    }
                }
            };
            bool_not(a126)
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("inspect"), Str::lit("Inspect"), f7(v0.clone(), Adt64::C0(Adt54::C2)), {
        let m129 = match v0.clone() {
            Adt0::C0(h128, _, _, _, _, _, _) => {
                h128
            }
        };
        if match m129 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h127, _, _, _, _, _, _, _) => {
                h127
            }
        } {
            let a133 = {
                let m132 = match v0.clone() {
                    Adt0::C0(h131, _, _, _, _, _, _) => {
                        h131
                    }
                };
                match m132 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h130, _, _, _, _, _, _) => {
                        h130
                    }
                }
            };
            bool_not(a133)
        } else {
            false
        }
    }, true), List::cons(Adt62::C0(Str::lit("verify"), Str::lit("Verify"), f7(v0.clone(), Adt64::C0(Adt54::C3)), {
        let m136 = match v0.clone() {
            Adt0::C0(h135, _, _, _, _, _, _) => {
                h135
            }
        };
        if match m136 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h134, _, _, _, _, _, _, _) => {
                h134
            }
        } {
            let a140 = {
                let m139 = match v0.clone() {
                    Adt0::C0(h138, _, _, _, _, _, _) => {
                        h138
                    }
                };
                match m139 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h137, _, _, _, _, _, _) => {
                        h137
                    }
                }
            };
            bool_not(a140)
        } else {
            false
        }
    }, true), List::<Adt62>::nil())))), f10(v0.clone())?, {
        let m144 = {
            let m143 = match v0.clone() {
                Adt0::C0(h142, _, _, _, _, _, _) => {
                    h142
                }
            };
            match m143 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h141, _) => {
                    h141
                }
            }
        };
        match m144 {
            None => {
                let m148 = {
                    let m147 = match v0.clone() {
                        Adt0::C0(h146, _, _, _, _, _, _) => {
                            h146
                        }
                    };
                    match m147 {
                        Adt1::C0(_, _, _, _, _, h145, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h145
                        }
                    }
                };
                match m148 {
                    None => {
                        List::<Adt68>::nil()
                    }
                    Some(v10) => {
                        f11(v10)
                    }
                }
            }
            Some(v11) => {
                f12(v11)
            }
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, h149, _, _) => {
            h149
        }
    }, {
        let m153 = {
            let m152 = match v0.clone() {
                Adt0::C0(h151, _, _, _, _, _, _) => {
                    h151
                }
            };
            match m152 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h150, _, _, _, _, _, _, _, _, _) => {
                    h150
                }
            }
        };
        if match m153 {
            None => {
                let m157 = {
                    let m156 = match v0.clone() {
                        Adt0::C0(h155, _, _, _, _, _, _) => {
                            h155
                        }
                    };
                    match m156 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, h154, _, _, _, _, _, _, _, _, _, _) => {
                            h154
                        }
                    }
                };
                match m157 {
                    None => {
                        false
                    }
                    Some(_) => {
                        true
                    }
                }
            }
            Some(_) => {
                true
            }
        } {
            Adt69::C1
        } else {
            Adt69::C0
        }
    }, {
        let m162 = {
            let m161 = match v0.clone() {
                Adt0::C0(h160, _, _, _, _, _, _) => {
                    h160
                }
            };
            match m161 {
                Adt1::C0(_, h159, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h159
                }
            }
        };
        match m162 {
            Adt2::C0(_, _, h158, _, _, _) => {
                h158
            }
        }
    }, true, false, false, {
        let m166 = {
            let m165 = match v0.clone() {
                Adt0::C0(h164, _, _, _, _, _, _) => {
                    h164
                }
            };
            match m165 {
                Adt1::C0(_, _, _, _, _, h163, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h163
                }
            }
        };
        match m166 {
            None => {
                None::<Adt70>
            }
            Some(v14) => {
                Some(f13({
                    let m170 = {
                        let m169 = match v0.clone() {
                            Adt0::C0(h168, _, _, _, _, _, _) => {
                                h168
                            }
                        };
                        match m169 {
                            Adt1::C0(_, _, _, _, h167, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h167
                            }
                        }
                    };
                    match m170 {
                        None => {
                            let m173 = match v0.clone() {
                                Adt0::C0(_, h172, _, _, _, _, _) => {
                                    h172
                                }
                            };
                            match m173 {
                                Adt53::C0(h171, _, _, _, _, _, _, _) => {
                                    h171
                                }
                            }
                        }
                        Some(v15) => {
                            f3(v15)
                        }
                    }
                }, v14))
            }
        }
    }, {
        let m177 = {
            let m176 = match v0.clone() {
                Adt0::C0(h175, _, _, _, _, _, _) => {
                    h175
                }
            };
            match m176 {
                Adt1::C0(_, _, _, _, _, h174, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h174
                }
            }
        };
        match m177 {
            None => {
                None::<Adt30>
            }
            Some(v16) => {
                Some(match v16 {
                    Adt22::C0(_, _, _, _, _, h178, _, _, _, _) => {
                        h178
                    }
                })
            }
        }
    }, {
        let m182 = {
            let m181 = match v0.clone() {
                Adt0::C0(h180, _, _, _, _, _, _) => {
                    h180
                }
            };
            match m181 {
                Adt1::C0(_, _, _, _, _, h179, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h179
                }
            }
        };
        match m182 {
            None => {
                None::<Adt32>
            }
            Some(v17) => {
                Some(match v17 {
                    Adt22::C0(_, _, _, _, _, _, h183, _, _, _) => {
                        h183
                    }
                })
            }
        }
    }, {
        let m187 = {
            let m186 = match v0.clone() {
                Adt0::C0(h185, _, _, _, _, _, _) => {
                    h185
                }
            };
            match m186 {
                Adt1::C0(_, _, _, _, _, h184, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h184
                }
            }
        };
        match m187 {
            None => {
                None::<Adt33>
            }
            Some(v18) => {
                match v18 {
                    Adt22::C0(_, _, _, _, _, _, _, _, _, h188) => {
                        h188
                    }
                }
            }
        }
    }, {
        let m191 = match v0.clone() {
            Adt0::C0(h190, _, _, _, _, _, _) => {
                h190
            }
        };
        match m191 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h189, _, _, _, _, _) => {
                h189
            }
        }
    }, {
        let m195 = {
            let m194 = match v0.clone() {
                Adt0::C0(h193, _, _, _, _, _, _) => {
                    h193
                }
            };
            match m194 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h192, _, _, _, _, _) => {
                    h192
                }
            }
        };
        if match m195 {
            Adt48::C0 => {
                false
            }
            Adt48::C1 => {
                true
            }
            Adt48::C2 => {
                false
            }
            Adt48::C3 => {
                false
            }
        } {
            List::cons(Adt62::C0(Str::lit("resume"), Str::lit("Resume"), f7(v0.clone(), Adt64::C0(Adt54::C4)), {
                let m198 = match v0.clone() {
                    Adt0::C0(h197, _, _, _, _, _, _) => {
                        h197
                    }
                };
                if match m198 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h196, _, _, _, _, _, _, _) => {
                        h196
                    }
                } {
                    let a202 = {
                        let m201 = match v0.clone() {
                            Adt0::C0(h200, _, _, _, _, _, _) => {
                                h200
                            }
                        };
                        match m201 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h199, _, _, _, _, _, _) => {
                                h199
                            }
                        }
                    };
                    bool_not(a202)
                } else {
                    false
                }
            }, true), List::cons(Adt62::C0(Str::lit("buildBasis"), Str::lit("Build basis"), f7(v0.clone(), Adt64::C0(Adt54::C5)), {
                let m205 = match v0.clone() {
                    Adt0::C0(h204, _, _, _, _, _, _) => {
                        h204
                    }
                };
                if match m205 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h203, _, _, _, _, _, _, _) => {
                        h203
                    }
                } {
                    let a209 = {
                        let m208 = match v0.clone() {
                            Adt0::C0(h207, _, _, _, _, _, _) => {
                                h207
                            }
                        };
                        match m208 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h206, _, _, _, _, _, _) => {
                                h206
                            }
                        }
                    };
                    bool_not(a209)
                } else {
                    false
                }
            }, true), List::cons(Adt62::C0(Str::lit("analyzeFrontier"), Str::lit("Analyze frontier"), f7(v0.clone(), Adt64::C0(Adt54::C6)), {
                let m212 = match v0.clone() {
                    Adt0::C0(h211, _, _, _, _, _, _) => {
                        h211
                    }
                };
                if match m212 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h210, _, _, _, _, _, _, _) => {
                        h210
                    }
                } {
                    let a216 = {
                        let m215 = match v0.clone() {
                            Adt0::C0(h214, _, _, _, _, _, _) => {
                                h214
                            }
                        };
                        match m215 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h213, _, _, _, _, _, _) => {
                                h213
                            }
                        }
                    };
                    bool_not(a216)
                } else {
                    false
                }
            }, true), List::cons(Adt62::C0(Str::lit("compare"), Str::lit("Compare"), f7(v0.clone(), Adt64::C0(Adt54::C7)), {
                let m219 = match v0.clone() {
                    Adt0::C0(h218, _, _, _, _, _, _) => {
                        h218
                    }
                };
                if match m219 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h217, _, _, _, _, _, _, _) => {
                        h217
                    }
                } {
                    let a223 = {
                        let m222 = match v0.clone() {
                            Adt0::C0(h221, _, _, _, _, _, _) => {
                                h221
                            }
                        };
                        match m222 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h220, _, _, _, _, _, _) => {
                                h220
                            }
                        }
                    };
                    bool_not(a223)
                } else {
                    false
                }
            }, true), List::<Adt62>::nil()))))
        } else {
            List::<Adt62>::nil()
        }
    }, f14(v0.clone()), Some({
        let m228 = {
            let m227 = match v0.clone() {
                Adt0::C0(h226, _, _, _, _, _, _) => {
                    h226
                }
            };
            match m227 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h225, _, _) => {
                    h225
                }
            }
        };
        match m228 {
            Adt50::C0(h224, _) => {
                h224
            }
        }
    }), {
        let m232 = {
            let m231 = match v0.clone() {
                Adt0::C0(h230, _, _, _, _, _, _) => {
                    h230
                }
            };
            match m231 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h229, _) => {
                    h229
                }
            }
        };
        match m232 {
            None => {
                None::<Adt26>
            }
            Some(v19) => {
                match v19 {
                    Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h233) => {
                        h233
                    }
                }
            }
        }
    }, Str::lit("Archive contents preserve ordered bytes and empty-object boundaries. The names shown here are selection labels; filenames, directory paths and filesystem metadata are not restored by this archive model."), f15(v0)?, Str::lit("Requested quotas govern each job. An empty optional quota adds no product limit; actual host capacity and runtime addressability still require admission. Logical arena memory, external storage and physical measurements are separate.")))
}

pub fn f1(v0: Adt0) -> Str {
    let m237 = {
        let m236 = match v0.clone() {
            Adt0::C0(h235, _, _, _, _, _, _) => {
                h235
            }
        };
        match m236 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h234, _, _, _, _, _, _, _, _, _) => {
                h234
            }
        }
    };
    match m237 {
        None => {
            let m241 = {
                let m240 = match v0.clone() {
                    Adt0::C0(h239, _, _, _, _, _, _) => {
                        h239
                    }
                };
                match m240 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h238, _, _, _, _, _, _, _, _, _, _) => {
                        h238
                    }
                }
            };
            match m241 {
                None => {
                    let m244 = match v0.clone() {
                        Adt0::C0(h243, _, _, _, _, _, _) => {
                            h243
                        }
                    };
                    if match m244 {
                        Adt1::C0(_, _, _, _, _, _, _, _, h242, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h242
                        }
                    } {
                        Str::lit("Downloading")
                    } else {
                        let m247 = match v0.clone() {
                            Adt0::C0(h246, _, _, _, _, _, _) => {
                                h246
                            }
                        };
                        if match m247 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h245, _, _, _, _, _, _, _, _, _, _, _) => {
                                h245
                            }
                        } {
                            Str::lit("Downloaded; the destination owns the result")
                        } else {
                            let m252 = {
                                let m251 = match v0.clone() {
                                    Adt0::C0(h250, _, _, _, _, _, _) => {
                                        h250
                                    }
                                };
                                match m251 {
                                    Adt1::C0(_, h249, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                        h249
                                    }
                                }
                            };
                            if match m252 {
                                Adt2::C0(_, _, h248, _, _, _) => {
                                    h248
                                }
                            } {
                                let m257 = {
                                    let m256 = match v0 {
                                        Adt0::C0(h255, _, _, _, _, _, _) => {
                                            h255
                                        }
                                    };
                                    match m256 {
                                        Adt1::C0(_, _, _, _, _, _, h254, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                            h254
                                        }
                                    }
                                };
                                match m257 {
                                    Adt40::C0(_, _, _, _, _, h253) => {
                                        h253
                                    }
                                }
                            } else {
                                let m261 = {
                                    let m260 = match v0.clone() {
                                        Adt0::C0(h259, _, _, _, _, _, _) => {
                                            h259
                                        }
                                    };
                                    match m260 {
                                        Adt1::C0(_, _, _, _, _, h258, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                            h258
                                        }
                                    }
                                };
                                match m261 {
                                    None => {
                                        Str::lit("Choose input and start")
                                    }
                                    Some(_) => {
                                        let m265 = {
                                            let m264 = match v0 {
                                                Adt0::C0(h263, _, _, _, _, _, _) => {
                                                    h263
                                                }
                                            };
                                            match m264 {
                                                Adt1::C0(_, _, _, _, h262, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                    h262
                                                }
                                            }
                                        };
                                        match m265 {
                                            None => {
                                                Str::lit("Result ready")
                                            }
                                            Some(v4) => {
                                                f18(f3(v4))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Some(v2) => {
                    f17(v2)
                }
            }
        }
        Some(v1) => {
            f16(v1)
        }
    }
}

pub fn f2(v0: Adt54, v1: Adt22) -> Str {
    let m267 = match v1.clone() {
        Adt22::C0(_, _, _, _, _, h266, _, _, _, _) => {
            h266
        }
    };
    match m267 {
        Adt30::C0 => {
            Str::lit("No certificate requested")
        }
        Adt30::C1(_) => {
            Str::lit("Certificate open")
        }
        Adt30::C2(_) => {
            Str::lit("Certificate failed")
        }
        Adt30::C3(_) => {
            Str::lit("Certificate incomplete")
        }
        Adt30::C4(_) => {
            let m269 = f13(v0, v1);
            if match m269 {
                Adt70::C0(_, _, _, _, h268, _, _) => {
                    h268
                }
            } {
                Str::lit("Scoped minimum certificate checked under the displayed scope")
            } else {
                Str::lit("Certificate supplied; not established for this result")
            }
        }
    }
}

pub fn f3(v0: Adt9) -> Adt54 {
    let m270 = v0;
    match m270 {
        Adt9::C0(_) => {
            Adt54::C0
        }
        Adt9::C1(_) => {
            Adt54::C1
        }
        Adt9::C2(_) => {
            Adt54::C2
        }
        Adt9::C3(_) => {
            Adt54::C3
        }
        Adt9::C4(_) => {
            Adt54::C4
        }
        Adt9::C5(_) => {
            Adt54::C5
        }
        Adt9::C6(_) => {
            Adt54::C6
        }
        Adt9::C7(_) => {
            Adt54::C7
        }
        Adt9::C8(_) => {
            Adt54::C8
        }
        Adt9::C9(_) => {
            Adt54::C9
        }
    }
}

pub fn f4(v0: Adt54, v1: Adt22) -> Str {
    let m272 = f13(v0, v1);
    if match m272 {
        Adt70::C0(_, _, _, h271, _, _, _) => {
            h271
        }
    } {
        Str::lit("Original bytes and ordered boundaries compared equal")
    } else {
        Str::lit("Original-byte equality is not established")
    }
}

pub fn f5(v0: Adt22) -> Option<Adt31> {
    let m274 = match v0 {
        Adt22::C0(_, _, _, _, _, h273, _, _, _, _) => {
            h273
        }
    };
    match m274 {
        Adt30::C0 => {
            None::<Adt31>
        }
        Adt30::C1(v1) => {
            Some(v1)
        }
        Adt30::C2(v2) => {
            Some(v2)
        }
        Adt30::C3(v3) => {
            Some(v3)
        }
        Adt30::C4(v4) => {
            Some(v4)
        }
    }
}

pub fn f6(v0: Adt54) -> Str {
    let m275 = v0;
    match m275 {
        Adt54::C0 => {
            Str::lit("Compress")
        }
        Adt54::C1 => {
            Str::lit("Decompress")
        }
        Adt54::C2 => {
            Str::lit("Inspect")
        }
        Adt54::C3 => {
            Str::lit("Verify")
        }
        Adt54::C4 => {
            Str::lit("Resume")
        }
        Adt54::C5 => {
            Str::lit("Build basis")
        }
        Adt54::C6 => {
            Str::lit("Analyze frontier")
        }
        Adt54::C7 => {
            Str::lit("Compare")
        }
        Adt54::C8 => {
            Str::lit("Run acceptance")
        }
        Adt54::C9 => {
            Str::lit("Run core request")
        }
    }
}

pub fn f7(v0: Adt0, v1: Adt64) -> Adt63 {
    Adt63::C0(f19(match v0.clone() {
        Adt0::C0(h276, _, _, _, _, _, _) => {
            h276
        }
    }), match v0 {
        Adt0::C0(_, _, h277, _, _, _, _) => {
            h277
        }
    }, v1)
}

pub fn f8(v0: Adt53) -> Result<Adt9, Adt43> {
    let m279 = match v0.clone() {
        Adt53::C0(h278, _, _, _, _, _, _, _) => {
            h278
        }
    };
    match m279 {
        Adt54::C0 => {
            let m281 = match v0.clone() {
                Adt53::C0(_, h280, _, _, _, _, _, _) => {
                    h280
                }
            };
            match m281 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v1) => {
                    Ok::<Adt9, Adt43>(Adt9::C0(Adt10::C0(v1, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h282) => {
                            h282
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h283, _, _, _, _) => {
                            h283
                        }
                    }))))
                }
            }
        }
        Adt54::C1 => {
            let m285 = match v0.clone() {
                Adt53::C0(_, _, h284, _, _, _, _, _) => {
                    h284
                }
            };
            match m285 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v2) => {
                    Ok::<Adt9, Adt43>(Adt9::C1(Adt15::C0(v2, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h286) => {
                            h286
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h287, _, _, _, _) => {
                            h287
                        }
                    }))))
                }
            }
        }
        Adt54::C2 => {
            let m289 = match v0.clone() {
                Adt53::C0(_, _, h288, _, _, _, _, _) => {
                    h288
                }
            };
            match m289 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v3) => {
                    Ok::<Adt9, Adt43>(Adt9::C2(Adt15::C0(v3, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h290) => {
                            h290
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h291, _, _, _, _) => {
                            h291
                        }
                    }))))
                }
            }
        }
        Adt54::C3 => {
            let m293 = match v0.clone() {
                Adt53::C0(_, _, h292, _, _, _, _, _) => {
                    h292
                }
            };
            match m293 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v4) => {
                    Ok::<Adt9, Adt43>(Adt9::C3(Adt16::C0(v4, match v0.clone() {
                        Adt53::C0(_, _, _, _, h294, _, _, _) => {
                            h294
                        }
                    }, None::<Adt11>, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h295) => {
                            h295
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h296, _, _, _, _) => {
                            h296
                        }
                    }))))
                }
            }
        }
        Adt54::C4 => {
            let m298 = match v0.clone() {
                Adt53::C0(_, h297, _, _, _, _, _, _) => {
                    h297
                }
            };
            match m298 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v5) => {
                    let m300 = match v0.clone() {
                        Adt53::C0(_, _, _, _, _, h299, _, _) => {
                            h299
                        }
                    };
                    match m300 {
                        None => {
                            Err::<Adt9, Adt43>(Adt43::C4)
                        }
                        Some(v6) => {
                            Ok::<Adt9, Adt43>(Adt9::C4(Adt17::C0(v5, v6, Adt12::C0(match v0.clone() {
                                Adt53::C0(_, _, _, _, _, _, _, h301) => {
                                    h301
                                }
                            }, match v0 {
                                Adt53::C0(_, _, _, h302, _, _, _, _) => {
                                    h302
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt54::C5 => {
            let m304 = match v0.clone() {
                Adt53::C0(_, h303, _, _, _, _, _, _) => {
                    h303
                }
            };
            match m304 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v7) => {
                    Ok::<Adt9, Adt43>(Adt9::C5(Adt18::C0(v7, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h305) => {
                            h305
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h306, _, _, _, _) => {
                            h306
                        }
                    }))))
                }
            }
        }
        Adt54::C6 => {
            let m308 = match v0.clone() {
                Adt53::C0(_, h307, _, _, _, _, _, _) => {
                    h307
                }
            };
            match m308 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v8) => {
                    Ok::<Adt9, Adt43>(Adt9::C6(Adt19::C0(v8, match v0.clone() {
                        Adt53::C0(_, _, h309, _, _, _, _, _) => {
                            h309
                        }
                    }, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h310) => {
                            h310
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h311, _, _, _, _) => {
                            h311
                        }
                    }))))
                }
            }
        }
        Adt54::C7 => {
            let m313 = match v0.clone() {
                Adt53::C0(_, _, h312, _, _, _, _, _) => {
                    h312
                }
            };
            match m313 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v9) => {
                    let m315 = match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, h314, _) => {
                            h314
                        }
                    };
                    match m315 {
                        None => {
                            Err::<Adt9, Adt43>(Adt43::C16)
                        }
                        Some(v10) => {
                            Ok::<Adt9, Adt43>(Adt9::C7(Adt20::C0(v9, v10, match v0.clone() {
                                Adt53::C0(_, _, _, _, h316, _, _, _) => {
                                    h316
                                }
                            }, Adt12::C0(match v0.clone() {
                                Adt53::C0(_, _, _, _, _, _, _, h317) => {
                                    h317
                                }
                            }, match v0 {
                                Adt53::C0(_, _, _, h318, _, _, _, _) => {
                                    h318
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt54::C8 => {
            let m320 = match v0.clone() {
                Adt53::C0(_, h319, _, _, _, _, _, _) => {
                    h319
                }
            };
            match m320 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v11) => {
                    Ok::<Adt9, Adt43>(Adt9::C8(Adt21::C0(v11, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h321) => {
                            h321
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h322, _, _, _, _) => {
                            h322
                        }
                    }))))
                }
            }
        }
        Adt54::C9 => {
            let m324 = match v0.clone() {
                Adt53::C0(_, h323, _, _, _, _, _, _) => {
                    h323
                }
            };
            match m324 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v12) => {
                    Ok::<Adt9, Adt43>(Adt9::C9(Adt21::C0(v12, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h325) => {
                            h325
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h326, _, _, _, _) => {
                            h326
                        }
                    }))))
                }
            }
        }
    }
}

pub fn f9(v0: Adt1) -> bool {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h327, _, _, _, _, _, _, _) => {
            h327
        }
    } {
        let a329 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h328, _, _, _, _, _, _) => {
                h328
            }
        };
        if bool_not(a329) {
            let a331 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h330, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h330
                }
            };
            if bool_not(a331) {
                let m334 = match v0.clone() {
                    Adt1::C0(_, _, h333, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h333
                    }
                };
                if match m334 {
                    Adt5::C0(_, _, _, h332, _) => {
                        h332
                    }
                } {
                    let m336 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h335, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h335
                        }
                    };
                    if match m336 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    } {
                        let m340 = {
                            let m339 = match v0 {
                                Adt1::C0(_, _, h338, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h338
                                }
                            };
                            match m339 {
                                Adt5::C0(_, _, _, _, h337) => {
                                    h337
                                }
                            }
                        };
                        match m340 {
                            Adt7::C0 => {
                                true
                            }
                            Adt7::C1 => {
                                false
                            }
                            Adt7::C2 => {
                                true
                            }
                            Adt7::C3 => {
                                false
                            }
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f10(v0: Adt0) -> R<List<Adt66>> {
    let m344 = {
        let m343 = match v0.clone() {
            Adt0::C0(_, h342, _, _, _, _, _) => {
                h342
            }
        };
        match m343 {
            Adt53::C0(h341, _, _, _, _, _, _, _) => {
                h341
            }
        }
    };
    match m344 {
        Adt54::C0 => {
            let m348 = {
                let m347 = match v0.clone() {
                    Adt0::C0(h346, _, _, _, _, _, _) => {
                        h346
                    }
                };
                match m347 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h345, _, _, _, _, _) => {
                        h345
                    }
                }
            };
            if if match m348 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m352 = {
                        let m351 = match v0.clone() {
                            Adt0::C0(_, h350, _, _, _, _, _) => {
                                h350
                            }
                        };
                        match m351 {
                            Adt53::C0(h349, _, _, _, _, _, _, _) => {
                                h349
                            }
                        }
                    };
                    match m352 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m356 = {
                        let m355 = match v0.clone() {
                            Adt0::C0(_, h354, _, _, _, _, _) => {
                                h354
                            }
                        };
                        match m355 {
                            Adt53::C0(_, h353, _, _, _, _, _, _) => {
                                h353
                            }
                        }
                    };
                    match m356 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h357, _) => {
                        h357
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h358, _) => {
                        h358
                    }
                }, Adt55::C0))?, {
                    let a362 = {
                        let m360 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h359) => {
                                h359
                            }
                        };
                        match m360 {
                            None => {
                                false
                            }
                            Some(v2) => {
                                f25(match v2 {
                                    Adt60::C0(h361, _, _, _, _, _) => {
                                        h361
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a362) {
                        let m365 = match v0.clone() {
                            Adt0::C0(h364, _, _, _, _, _, _) => {
                                h364
                            }
                        };
                        if match m365 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h363, _, _, _, _, _, _, _) => {
                                h363
                            }
                        } {
                            let a369 = {
                                let m368 = match v0.clone() {
                                    Adt0::C0(h367, _, _, _, _, _, _) => {
                                        h367
                                    }
                                };
                                match m368 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h366, _, _, _, _, _, _) => {
                                        h366
                                    }
                                }
                            };
                            bool_not(a369)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m371 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h370) => {
                            h370
                        }
                    };
                    match m371 {
                        None => {
                            false
                        }
                        Some(v3) => {
                            f25(match v3 {
                                Adt60::C0(h372, _, _, _, _, _) => {
                                    h372
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a376 = {
                        let m374 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h373) => {
                                h373
                            }
                        };
                        match m374 {
                            None => {
                                false
                            }
                            Some(v4) => {
                                f25(match v4 {
                                    Adt60::C0(h375, _, _, _, _, _) => {
                                        h375
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a376) {
                        let m379 = match v0.clone() {
                            Adt0::C0(h378, _, _, _, _, _, _) => {
                                h378
                            }
                        };
                        if match m379 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h377, _, _, _, _, _, _, _) => {
                                h377
                            }
                        } {
                            let a383 = {
                                let m382 = match v0.clone() {
                                    Adt0::C0(h381, _, _, _, _, _, _) => {
                                        h381
                                    }
                                };
                                match m382 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h380, _, _, _, _, _, _) => {
                                        h380
                                    }
                                }
                            };
                            bool_not(a383)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m387 = {
                        let m386 = match v0.clone() {
                            Adt0::C0(_, h385, _, _, _, _, _) => {
                                h385
                            }
                        };
                        match m386 {
                            Adt53::C0(h384, _, _, _, _, _, _, _) => {
                                h384
                            }
                        }
                    };
                    match m387 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m391 = {
                        let m390 = match v0.clone() {
                            Adt0::C0(_, h389, _, _, _, _, _) => {
                                h389
                            }
                        };
                        match m390 {
                            Adt53::C0(_, _, _, h388, _, _, _, _) => {
                                h388
                            }
                        }
                    };
                    match m391 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h392, _) => {
                        h392
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h393, _) => {
                        h393
                    }
                }, Adt55::C2))?, {
                    let a397 = {
                        let m395 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h394) => {
                                h394
                            }
                        };
                        match m395 {
                            None => {
                                false
                            }
                            Some(v6) => {
                                f25(match v6 {
                                    Adt60::C0(h396, _, _, _, _, _) => {
                                        h396
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a397) {
                        let m400 = match v0.clone() {
                            Adt0::C0(h399, _, _, _, _, _, _) => {
                                h399
                            }
                        };
                        if match m400 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h398, _, _, _, _, _, _, _) => {
                                h398
                            }
                        } {
                            let a404 = {
                                let m403 = match v0.clone() {
                                    Adt0::C0(h402, _, _, _, _, _, _) => {
                                        h402
                                    }
                                };
                                match m403 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h401, _, _, _, _, _, _) => {
                                        h401
                                    }
                                }
                            };
                            bool_not(a404)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m406 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h405) => {
                            h405
                        }
                    };
                    match m406 {
                        None => {
                            false
                        }
                        Some(v7) => {
                            f25(match v7 {
                                Adt60::C0(h407, _, _, _, _, _) => {
                                    h407
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a411 = {
                        let m409 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h408) => {
                                h408
                            }
                        };
                        match m409 {
                            None => {
                                false
                            }
                            Some(v8) => {
                                f25(match v8 {
                                    Adt60::C0(h410, _, _, _, _, _) => {
                                        h410
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a411) {
                        let m414 = match v0.clone() {
                            Adt0::C0(h413, _, _, _, _, _, _) => {
                                h413
                            }
                        };
                        if match m414 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h412, _, _, _, _, _, _, _) => {
                                h412
                            }
                        } {
                            let a418 = {
                                let m417 = match v0 {
                                    Adt0::C0(h416, _, _, _, _, _, _) => {
                                        h416
                                    }
                                };
                                match m417 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h415, _, _, _, _, _, _) => {
                                        h415
                                    }
                                }
                            };
                            bool_not(a418)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m422 = {
                        let m421 = match v0.clone() {
                            Adt0::C0(_, h420, _, _, _, _, _) => {
                                h420
                            }
                        };
                        match m421 {
                            Adt53::C0(h419, _, _, _, _, _, _, _) => {
                                h419
                            }
                        }
                    };
                    match m422 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m426 = {
                        let m425 = match v0.clone() {
                            Adt0::C0(_, h424, _, _, _, _, _) => {
                                h424
                            }
                        };
                        match m425 {
                            Adt53::C0(_, h423, _, _, _, _, _, _) => {
                                h423
                            }
                        }
                    };
                    match m426 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h427, _) => {
                        h427
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h428, _) => {
                        h428
                    }
                }, Adt55::C0))?, {
                    let a432 = {
                        let m430 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h429) => {
                                h429
                            }
                        };
                        match m430 {
                            None => {
                                false
                            }
                            Some(v10) => {
                                f25(match v10 {
                                    Adt60::C0(h431, _, _, _, _, _) => {
                                        h431
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a432) {
                        let m435 = match v0.clone() {
                            Adt0::C0(h434, _, _, _, _, _, _) => {
                                h434
                            }
                        };
                        if match m435 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h433, _, _, _, _, _, _, _) => {
                                h433
                            }
                        } {
                            let a439 = {
                                let m438 = match v0.clone() {
                                    Adt0::C0(h437, _, _, _, _, _, _) => {
                                        h437
                                    }
                                };
                                match m438 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h436, _, _, _, _, _, _) => {
                                        h436
                                    }
                                }
                            };
                            bool_not(a439)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m441 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h440) => {
                            h440
                        }
                    };
                    match m441 {
                        None => {
                            false
                        }
                        Some(v11) => {
                            f25(match v11 {
                                Adt60::C0(h442, _, _, _, _, _) => {
                                    h442
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a446 = {
                        let m444 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h443) => {
                                h443
                            }
                        };
                        match m444 {
                            None => {
                                false
                            }
                            Some(v12) => {
                                f25(match v12 {
                                    Adt60::C0(h445, _, _, _, _, _) => {
                                        h445
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a446) {
                        let m449 = match v0.clone() {
                            Adt0::C0(h448, _, _, _, _, _, _) => {
                                h448
                            }
                        };
                        if match m449 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h447, _, _, _, _, _, _, _) => {
                                h447
                            }
                        } {
                            let a453 = {
                                let m452 = match v0 {
                                    Adt0::C0(h451, _, _, _, _, _, _) => {
                                        h451
                                    }
                                };
                                match m452 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h450, _, _, _, _, _, _) => {
                                        h450
                                    }
                                }
                            };
                            bool_not(a453)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))
            }
        }
        Adt54::C1 => {
            let m457 = {
                let m456 = match v0.clone() {
                    Adt0::C0(h455, _, _, _, _, _, _) => {
                        h455
                    }
                };
                match m456 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h454, _, _, _, _, _) => {
                        h454
                    }
                }
            };
            if if match m457 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m461 = {
                        let m460 = match v0.clone() {
                            Adt0::C0(_, h459, _, _, _, _, _) => {
                                h459
                            }
                        };
                        match m460 {
                            Adt53::C0(h458, _, _, _, _, _, _, _) => {
                                h458
                            }
                        }
                    };
                    match m461 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m465 = {
                        let m464 = match v0.clone() {
                            Adt0::C0(_, h463, _, _, _, _, _) => {
                                h463
                            }
                        };
                        match m464 {
                            Adt53::C0(_, _, h462, _, _, _, _, _) => {
                                h462
                            }
                        }
                    };
                    match m465 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h466, _) => {
                        h466
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h467, _) => {
                        h467
                    }
                }, Adt55::C1))?, {
                    let a471 = {
                        let m469 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h468) => {
                                h468
                            }
                        };
                        match m469 {
                            None => {
                                false
                            }
                            Some(v14) => {
                                f25(match v14 {
                                    Adt60::C0(h470, _, _, _, _, _) => {
                                        h470
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a471) {
                        let m474 = match v0.clone() {
                            Adt0::C0(h473, _, _, _, _, _, _) => {
                                h473
                            }
                        };
                        if match m474 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h472, _, _, _, _, _, _, _) => {
                                h472
                            }
                        } {
                            let a478 = {
                                let m477 = match v0.clone() {
                                    Adt0::C0(h476, _, _, _, _, _, _) => {
                                        h476
                                    }
                                };
                                match m477 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h475, _, _, _, _, _, _) => {
                                        h475
                                    }
                                }
                            };
                            bool_not(a478)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m480 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h479) => {
                            h479
                        }
                    };
                    match m480 {
                        None => {
                            false
                        }
                        Some(v15) => {
                            f25(match v15 {
                                Adt60::C0(h481, _, _, _, _, _) => {
                                    h481
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a485 = {
                        let m483 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h482) => {
                                h482
                            }
                        };
                        match m483 {
                            None => {
                                false
                            }
                            Some(v16) => {
                                f25(match v16 {
                                    Adt60::C0(h484, _, _, _, _, _) => {
                                        h484
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a485) {
                        let m488 = match v0.clone() {
                            Adt0::C0(h487, _, _, _, _, _, _) => {
                                h487
                            }
                        };
                        if match m488 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h486, _, _, _, _, _, _, _) => {
                                h486
                            }
                        } {
                            let a492 = {
                                let m491 = match v0.clone() {
                                    Adt0::C0(h490, _, _, _, _, _, _) => {
                                        h490
                                    }
                                };
                                match m491 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h489, _, _, _, _, _, _) => {
                                        h489
                                    }
                                }
                            };
                            bool_not(a492)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m496 = {
                        let m495 = match v0.clone() {
                            Adt0::C0(_, h494, _, _, _, _, _) => {
                                h494
                            }
                        };
                        match m495 {
                            Adt53::C0(h493, _, _, _, _, _, _, _) => {
                                h493
                            }
                        }
                    };
                    match m496 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m500 = {
                        let m499 = match v0.clone() {
                            Adt0::C0(_, h498, _, _, _, _, _) => {
                                h498
                            }
                        };
                        match m499 {
                            Adt53::C0(_, _, _, h497, _, _, _, _) => {
                                h497
                            }
                        }
                    };
                    match m500 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h501, _) => {
                        h501
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h502, _) => {
                        h502
                    }
                }, Adt55::C2))?, {
                    let a506 = {
                        let m504 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h503) => {
                                h503
                            }
                        };
                        match m504 {
                            None => {
                                false
                            }
                            Some(v18) => {
                                f25(match v18 {
                                    Adt60::C0(h505, _, _, _, _, _) => {
                                        h505
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a506) {
                        let m509 = match v0.clone() {
                            Adt0::C0(h508, _, _, _, _, _, _) => {
                                h508
                            }
                        };
                        if match m509 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h507, _, _, _, _, _, _, _) => {
                                h507
                            }
                        } {
                            let a513 = {
                                let m512 = match v0.clone() {
                                    Adt0::C0(h511, _, _, _, _, _, _) => {
                                        h511
                                    }
                                };
                                match m512 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h510, _, _, _, _, _, _) => {
                                        h510
                                    }
                                }
                            };
                            bool_not(a513)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m515 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h514) => {
                            h514
                        }
                    };
                    match m515 {
                        None => {
                            false
                        }
                        Some(v19) => {
                            f25(match v19 {
                                Adt60::C0(h516, _, _, _, _, _) => {
                                    h516
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a520 = {
                        let m518 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h517) => {
                                h517
                            }
                        };
                        match m518 {
                            None => {
                                false
                            }
                            Some(v20) => {
                                f25(match v20 {
                                    Adt60::C0(h519, _, _, _, _, _) => {
                                        h519
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a520) {
                        let m523 = match v0.clone() {
                            Adt0::C0(h522, _, _, _, _, _, _) => {
                                h522
                            }
                        };
                        if match m523 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h521, _, _, _, _, _, _, _) => {
                                h521
                            }
                        } {
                            let a527 = {
                                let m526 = match v0 {
                                    Adt0::C0(h525, _, _, _, _, _, _) => {
                                        h525
                                    }
                                };
                                match m526 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h524, _, _, _, _, _, _) => {
                                        h524
                                    }
                                }
                            };
                            bool_not(a527)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m531 = {
                        let m530 = match v0.clone() {
                            Adt0::C0(_, h529, _, _, _, _, _) => {
                                h529
                            }
                        };
                        match m530 {
                            Adt53::C0(h528, _, _, _, _, _, _, _) => {
                                h528
                            }
                        }
                    };
                    match m531 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m535 = {
                        let m534 = match v0.clone() {
                            Adt0::C0(_, h533, _, _, _, _, _) => {
                                h533
                            }
                        };
                        match m534 {
                            Adt53::C0(_, _, h532, _, _, _, _, _) => {
                                h532
                            }
                        }
                    };
                    match m535 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h536, _) => {
                        h536
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h537, _) => {
                        h537
                    }
                }, Adt55::C1))?, {
                    let a541 = {
                        let m539 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h538) => {
                                h538
                            }
                        };
                        match m539 {
                            None => {
                                false
                            }
                            Some(v22) => {
                                f25(match v22 {
                                    Adt60::C0(h540, _, _, _, _, _) => {
                                        h540
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a541) {
                        let m544 = match v0.clone() {
                            Adt0::C0(h543, _, _, _, _, _, _) => {
                                h543
                            }
                        };
                        if match m544 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h542, _, _, _, _, _, _, _) => {
                                h542
                            }
                        } {
                            let a548 = {
                                let m547 = match v0.clone() {
                                    Adt0::C0(h546, _, _, _, _, _, _) => {
                                        h546
                                    }
                                };
                                match m547 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h545, _, _, _, _, _, _) => {
                                        h545
                                    }
                                }
                            };
                            bool_not(a548)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m550 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h549) => {
                            h549
                        }
                    };
                    match m550 {
                        None => {
                            false
                        }
                        Some(v23) => {
                            f25(match v23 {
                                Adt60::C0(h551, _, _, _, _, _) => {
                                    h551
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a555 = {
                        let m553 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h552) => {
                                h552
                            }
                        };
                        match m553 {
                            None => {
                                false
                            }
                            Some(v24) => {
                                f25(match v24 {
                                    Adt60::C0(h554, _, _, _, _, _) => {
                                        h554
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a555) {
                        let m558 = match v0.clone() {
                            Adt0::C0(h557, _, _, _, _, _, _) => {
                                h557
                            }
                        };
                        if match m558 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h556, _, _, _, _, _, _, _) => {
                                h556
                            }
                        } {
                            let a562 = {
                                let m561 = match v0 {
                                    Adt0::C0(h560, _, _, _, _, _, _) => {
                                        h560
                                    }
                                };
                                match m561 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h559, _, _, _, _, _, _) => {
                                        h559
                                    }
                                }
                            };
                            bool_not(a562)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))
            }
        }
        Adt54::C2 => {
            let m566 = {
                let m565 = match v0.clone() {
                    Adt0::C0(h564, _, _, _, _, _, _) => {
                        h564
                    }
                };
                match m565 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h563, _, _, _, _, _) => {
                        h563
                    }
                }
            };
            if if match m566 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m570 = {
                        let m569 = match v0.clone() {
                            Adt0::C0(_, h568, _, _, _, _, _) => {
                                h568
                            }
                        };
                        match m569 {
                            Adt53::C0(h567, _, _, _, _, _, _, _) => {
                                h567
                            }
                        }
                    };
                    match m570 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m574 = {
                        let m573 = match v0.clone() {
                            Adt0::C0(_, h572, _, _, _, _, _) => {
                                h572
                            }
                        };
                        match m573 {
                            Adt53::C0(_, _, h571, _, _, _, _, _) => {
                                h571
                            }
                        }
                    };
                    match m574 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h575, _) => {
                        h575
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h576, _) => {
                        h576
                    }
                }, Adt55::C1))?, {
                    let a580 = {
                        let m578 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h577) => {
                                h577
                            }
                        };
                        match m578 {
                            None => {
                                false
                            }
                            Some(v26) => {
                                f25(match v26 {
                                    Adt60::C0(h579, _, _, _, _, _) => {
                                        h579
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a580) {
                        let m583 = match v0.clone() {
                            Adt0::C0(h582, _, _, _, _, _, _) => {
                                h582
                            }
                        };
                        if match m583 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h581, _, _, _, _, _, _, _) => {
                                h581
                            }
                        } {
                            let a587 = {
                                let m586 = match v0.clone() {
                                    Adt0::C0(h585, _, _, _, _, _, _) => {
                                        h585
                                    }
                                };
                                match m586 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h584, _, _, _, _, _, _) => {
                                        h584
                                    }
                                }
                            };
                            bool_not(a587)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m589 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h588) => {
                            h588
                        }
                    };
                    match m589 {
                        None => {
                            false
                        }
                        Some(v27) => {
                            f25(match v27 {
                                Adt60::C0(h590, _, _, _, _, _) => {
                                    h590
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a594 = {
                        let m592 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h591) => {
                                h591
                            }
                        };
                        match m592 {
                            None => {
                                false
                            }
                            Some(v28) => {
                                f25(match v28 {
                                    Adt60::C0(h593, _, _, _, _, _) => {
                                        h593
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a594) {
                        let m597 = match v0.clone() {
                            Adt0::C0(h596, _, _, _, _, _, _) => {
                                h596
                            }
                        };
                        if match m597 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h595, _, _, _, _, _, _, _) => {
                                h595
                            }
                        } {
                            let a601 = {
                                let m600 = match v0.clone() {
                                    Adt0::C0(h599, _, _, _, _, _, _) => {
                                        h599
                                    }
                                };
                                match m600 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h598, _, _, _, _, _, _) => {
                                        h598
                                    }
                                }
                            };
                            bool_not(a601)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m605 = {
                        let m604 = match v0.clone() {
                            Adt0::C0(_, h603, _, _, _, _, _) => {
                                h603
                            }
                        };
                        match m604 {
                            Adt53::C0(h602, _, _, _, _, _, _, _) => {
                                h602
                            }
                        }
                    };
                    match m605 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m609 = {
                        let m608 = match v0.clone() {
                            Adt0::C0(_, h607, _, _, _, _, _) => {
                                h607
                            }
                        };
                        match m608 {
                            Adt53::C0(_, _, _, h606, _, _, _, _) => {
                                h606
                            }
                        }
                    };
                    match m609 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h610, _) => {
                        h610
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h611, _) => {
                        h611
                    }
                }, Adt55::C2))?, {
                    let a615 = {
                        let m613 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h612) => {
                                h612
                            }
                        };
                        match m613 {
                            None => {
                                false
                            }
                            Some(v30) => {
                                f25(match v30 {
                                    Adt60::C0(h614, _, _, _, _, _) => {
                                        h614
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a615) {
                        let m618 = match v0.clone() {
                            Adt0::C0(h617, _, _, _, _, _, _) => {
                                h617
                            }
                        };
                        if match m618 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h616, _, _, _, _, _, _, _) => {
                                h616
                            }
                        } {
                            let a622 = {
                                let m621 = match v0.clone() {
                                    Adt0::C0(h620, _, _, _, _, _, _) => {
                                        h620
                                    }
                                };
                                match m621 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h619, _, _, _, _, _, _) => {
                                        h619
                                    }
                                }
                            };
                            bool_not(a622)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m624 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h623) => {
                            h623
                        }
                    };
                    match m624 {
                        None => {
                            false
                        }
                        Some(v31) => {
                            f25(match v31 {
                                Adt60::C0(h625, _, _, _, _, _) => {
                                    h625
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a629 = {
                        let m627 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h626) => {
                                h626
                            }
                        };
                        match m627 {
                            None => {
                                false
                            }
                            Some(v32) => {
                                f25(match v32 {
                                    Adt60::C0(h628, _, _, _, _, _) => {
                                        h628
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a629) {
                        let m632 = match v0.clone() {
                            Adt0::C0(h631, _, _, _, _, _, _) => {
                                h631
                            }
                        };
                        if match m632 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h630, _, _, _, _, _, _, _) => {
                                h630
                            }
                        } {
                            let a636 = {
                                let m635 = match v0 {
                                    Adt0::C0(h634, _, _, _, _, _, _) => {
                                        h634
                                    }
                                };
                                match m635 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h633, _, _, _, _, _, _) => {
                                        h633
                                    }
                                }
                            };
                            bool_not(a636)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m640 = {
                        let m639 = match v0.clone() {
                            Adt0::C0(_, h638, _, _, _, _, _) => {
                                h638
                            }
                        };
                        match m639 {
                            Adt53::C0(h637, _, _, _, _, _, _, _) => {
                                h637
                            }
                        }
                    };
                    match m640 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m644 = {
                        let m643 = match v0.clone() {
                            Adt0::C0(_, h642, _, _, _, _, _) => {
                                h642
                            }
                        };
                        match m643 {
                            Adt53::C0(_, _, h641, _, _, _, _, _) => {
                                h641
                            }
                        }
                    };
                    match m644 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h645, _) => {
                        h645
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h646, _) => {
                        h646
                    }
                }, Adt55::C1))?, {
                    let a650 = {
                        let m648 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h647) => {
                                h647
                            }
                        };
                        match m648 {
                            None => {
                                false
                            }
                            Some(v34) => {
                                f25(match v34 {
                                    Adt60::C0(h649, _, _, _, _, _) => {
                                        h649
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a650) {
                        let m653 = match v0.clone() {
                            Adt0::C0(h652, _, _, _, _, _, _) => {
                                h652
                            }
                        };
                        if match m653 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h651, _, _, _, _, _, _, _) => {
                                h651
                            }
                        } {
                            let a657 = {
                                let m656 = match v0.clone() {
                                    Adt0::C0(h655, _, _, _, _, _, _) => {
                                        h655
                                    }
                                };
                                match m656 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h654, _, _, _, _, _, _) => {
                                        h654
                                    }
                                }
                            };
                            bool_not(a657)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m659 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h658) => {
                            h658
                        }
                    };
                    match m659 {
                        None => {
                            false
                        }
                        Some(v35) => {
                            f25(match v35 {
                                Adt60::C0(h660, _, _, _, _, _) => {
                                    h660
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a664 = {
                        let m662 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h661) => {
                                h661
                            }
                        };
                        match m662 {
                            None => {
                                false
                            }
                            Some(v36) => {
                                f25(match v36 {
                                    Adt60::C0(h663, _, _, _, _, _) => {
                                        h663
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a664) {
                        let m667 = match v0.clone() {
                            Adt0::C0(h666, _, _, _, _, _, _) => {
                                h666
                            }
                        };
                        if match m667 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h665, _, _, _, _, _, _, _) => {
                                h665
                            }
                        } {
                            let a671 = {
                                let m670 = match v0 {
                                    Adt0::C0(h669, _, _, _, _, _, _) => {
                                        h669
                                    }
                                };
                                match m670 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h668, _, _, _, _, _, _) => {
                                        h668
                                    }
                                }
                            };
                            bool_not(a671)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))
            }
        }
        Adt54::C3 => {
            let m675 = {
                let m674 = match v0.clone() {
                    Adt0::C0(h673, _, _, _, _, _, _) => {
                        h673
                    }
                };
                match m674 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h672, _, _, _, _, _) => {
                        h672
                    }
                }
            };
            if if match m675 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m679 = {
                        let m678 = match v0.clone() {
                            Adt0::C0(_, h677, _, _, _, _, _) => {
                                h677
                            }
                        };
                        match m678 {
                            Adt53::C0(h676, _, _, _, _, _, _, _) => {
                                h676
                            }
                        }
                    };
                    match m679 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m683 = {
                        let m682 = match v0.clone() {
                            Adt0::C0(_, h681, _, _, _, _, _) => {
                                h681
                            }
                        };
                        match m682 {
                            Adt53::C0(_, _, h680, _, _, _, _, _) => {
                                h680
                            }
                        }
                    };
                    match m683 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h684, _) => {
                        h684
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h685, _) => {
                        h685
                    }
                }, Adt55::C1))?, {
                    let a689 = {
                        let m687 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h686) => {
                                h686
                            }
                        };
                        match m687 {
                            None => {
                                false
                            }
                            Some(v38) => {
                                f25(match v38 {
                                    Adt60::C0(h688, _, _, _, _, _) => {
                                        h688
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a689) {
                        let m692 = match v0.clone() {
                            Adt0::C0(h691, _, _, _, _, _, _) => {
                                h691
                            }
                        };
                        if match m692 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h690, _, _, _, _, _, _, _) => {
                                h690
                            }
                        } {
                            let a696 = {
                                let m695 = match v0.clone() {
                                    Adt0::C0(h694, _, _, _, _, _, _) => {
                                        h694
                                    }
                                };
                                match m695 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h693, _, _, _, _, _, _) => {
                                        h693
                                    }
                                }
                            };
                            bool_not(a696)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m698 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h697) => {
                            h697
                        }
                    };
                    match m698 {
                        None => {
                            false
                        }
                        Some(v39) => {
                            f25(match v39 {
                                Adt60::C0(h699, _, _, _, _, _) => {
                                    h699
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a703 = {
                        let m701 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h700) => {
                                h700
                            }
                        };
                        match m701 {
                            None => {
                                false
                            }
                            Some(v40) => {
                                f25(match v40 {
                                    Adt60::C0(h702, _, _, _, _, _) => {
                                        h702
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a703) {
                        let m706 = match v0.clone() {
                            Adt0::C0(h705, _, _, _, _, _, _) => {
                                h705
                            }
                        };
                        if match m706 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h704, _, _, _, _, _, _, _) => {
                                h704
                            }
                        } {
                            let a710 = {
                                let m709 = match v0.clone() {
                                    Adt0::C0(h708, _, _, _, _, _, _) => {
                                        h708
                                    }
                                };
                                match m709 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h707, _, _, _, _, _, _) => {
                                        h707
                                    }
                                }
                            };
                            bool_not(a710)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C3, Str::lit("Original objects for byte comparison (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C3)), true, {
                    let m714 = {
                        let m713 = match v0.clone() {
                            Adt0::C0(_, h712, _, _, _, _, _) => {
                                h712
                            }
                        };
                        match m713 {
                            Adt53::C0(h711, _, _, _, _, _, _, _) => {
                                h711
                            }
                        }
                    };
                    match m714 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m718 = {
                        let m717 = match v0.clone() {
                            Adt0::C0(_, h716, _, _, _, _, _) => {
                                h716
                            }
                        };
                        match m717 {
                            Adt53::C0(_, _, _, _, h715, _, _, _) => {
                                h715
                            }
                        }
                    };
                    match m718 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C3), f22(v0.clone(), Adt55::C3, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h719, _) => {
                        h719
                    }
                }, Adt55::C3), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h720, _) => {
                        h720
                    }
                }, Adt55::C3))?, {
                    let a724 = {
                        let m722 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h721) => {
                                h721
                            }
                        };
                        match m722 {
                            None => {
                                false
                            }
                            Some(v42) => {
                                f25(match v42 {
                                    Adt60::C0(h723, _, _, _, _, _) => {
                                        h723
                                    }
                                }, Adt55::C3)
                            }
                        }
                    };
                    if bool_not(a724) {
                        let m727 = match v0.clone() {
                            Adt0::C0(h726, _, _, _, _, _, _) => {
                                h726
                            }
                        };
                        if match m727 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h725, _, _, _, _, _, _, _) => {
                                h725
                            }
                        } {
                            let a731 = {
                                let m730 = match v0.clone() {
                                    Adt0::C0(h729, _, _, _, _, _, _) => {
                                        h729
                                    }
                                };
                                match m730 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h728, _, _, _, _, _, _) => {
                                        h728
                                    }
                                }
                            };
                            bool_not(a731)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m733 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h732) => {
                            h732
                        }
                    };
                    match m733 {
                        None => {
                            false
                        }
                        Some(v43) => {
                            f25(match v43 {
                                Adt60::C0(h734, _, _, _, _, _) => {
                                    h734
                                }
                            }, Adt55::C3)
                        }
                    }
                }, {
                    let a738 = {
                        let m736 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h735) => {
                                h735
                            }
                        };
                        match m736 {
                            None => {
                                false
                            }
                            Some(v44) => {
                                f25(match v44 {
                                    Adt60::C0(h737, _, _, _, _, _) => {
                                        h737
                                    }
                                }, Adt55::C3)
                            }
                        }
                    };
                    if bool_not(a738) {
                        let m741 = match v0.clone() {
                            Adt0::C0(h740, _, _, _, _, _, _) => {
                                h740
                            }
                        };
                        if match m741 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h739, _, _, _, _, _, _, _) => {
                                h739
                            }
                        } {
                            let a745 = {
                                let m744 = match v0.clone() {
                                    Adt0::C0(h743, _, _, _, _, _, _) => {
                                        h743
                                    }
                                };
                                match m744 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h742, _, _, _, _, _, _) => {
                                        h742
                                    }
                                }
                            };
                            bool_not(a745)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m749 = {
                        let m748 = match v0.clone() {
                            Adt0::C0(_, h747, _, _, _, _, _) => {
                                h747
                            }
                        };
                        match m748 {
                            Adt53::C0(h746, _, _, _, _, _, _, _) => {
                                h746
                            }
                        }
                    };
                    match m749 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m753 = {
                        let m752 = match v0.clone() {
                            Adt0::C0(_, h751, _, _, _, _, _) => {
                                h751
                            }
                        };
                        match m752 {
                            Adt53::C0(_, _, _, h750, _, _, _, _) => {
                                h750
                            }
                        }
                    };
                    match m753 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h754, _) => {
                        h754
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h755, _) => {
                        h755
                    }
                }, Adt55::C2))?, {
                    let a759 = {
                        let m757 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h756) => {
                                h756
                            }
                        };
                        match m757 {
                            None => {
                                false
                            }
                            Some(v46) => {
                                f25(match v46 {
                                    Adt60::C0(h758, _, _, _, _, _) => {
                                        h758
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a759) {
                        let m762 = match v0.clone() {
                            Adt0::C0(h761, _, _, _, _, _, _) => {
                                h761
                            }
                        };
                        if match m762 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h760, _, _, _, _, _, _, _) => {
                                h760
                            }
                        } {
                            let a766 = {
                                let m765 = match v0.clone() {
                                    Adt0::C0(h764, _, _, _, _, _, _) => {
                                        h764
                                    }
                                };
                                match m765 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h763, _, _, _, _, _, _) => {
                                        h763
                                    }
                                }
                            };
                            bool_not(a766)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m768 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h767) => {
                            h767
                        }
                    };
                    match m768 {
                        None => {
                            false
                        }
                        Some(v47) => {
                            f25(match v47 {
                                Adt60::C0(h769, _, _, _, _, _) => {
                                    h769
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a773 = {
                        let m771 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h770) => {
                                h770
                            }
                        };
                        match m771 {
                            None => {
                                false
                            }
                            Some(v48) => {
                                f25(match v48 {
                                    Adt60::C0(h772, _, _, _, _, _) => {
                                        h772
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a773) {
                        let m776 = match v0.clone() {
                            Adt0::C0(h775, _, _, _, _, _, _) => {
                                h775
                            }
                        };
                        if match m776 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h774, _, _, _, _, _, _, _) => {
                                h774
                            }
                        } {
                            let a780 = {
                                let m779 = match v0 {
                                    Adt0::C0(h778, _, _, _, _, _, _) => {
                                        h778
                                    }
                                };
                                match m779 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h777, _, _, _, _, _, _) => {
                                        h777
                                    }
                                }
                            };
                            bool_not(a780)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m784 = {
                        let m783 = match v0.clone() {
                            Adt0::C0(_, h782, _, _, _, _, _) => {
                                h782
                            }
                        };
                        match m783 {
                            Adt53::C0(h781, _, _, _, _, _, _, _) => {
                                h781
                            }
                        }
                    };
                    match m784 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m788 = {
                        let m787 = match v0.clone() {
                            Adt0::C0(_, h786, _, _, _, _, _) => {
                                h786
                            }
                        };
                        match m787 {
                            Adt53::C0(_, _, h785, _, _, _, _, _) => {
                                h785
                            }
                        }
                    };
                    match m788 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h789, _) => {
                        h789
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h790, _) => {
                        h790
                    }
                }, Adt55::C1))?, {
                    let a794 = {
                        let m792 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h791) => {
                                h791
                            }
                        };
                        match m792 {
                            None => {
                                false
                            }
                            Some(v50) => {
                                f25(match v50 {
                                    Adt60::C0(h793, _, _, _, _, _) => {
                                        h793
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a794) {
                        let m797 = match v0.clone() {
                            Adt0::C0(h796, _, _, _, _, _, _) => {
                                h796
                            }
                        };
                        if match m797 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h795, _, _, _, _, _, _, _) => {
                                h795
                            }
                        } {
                            let a801 = {
                                let m800 = match v0.clone() {
                                    Adt0::C0(h799, _, _, _, _, _, _) => {
                                        h799
                                    }
                                };
                                match m800 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h798, _, _, _, _, _, _) => {
                                        h798
                                    }
                                }
                            };
                            bool_not(a801)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m803 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h802) => {
                            h802
                        }
                    };
                    match m803 {
                        None => {
                            false
                        }
                        Some(v51) => {
                            f25(match v51 {
                                Adt60::C0(h804, _, _, _, _, _) => {
                                    h804
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a808 = {
                        let m806 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h805) => {
                                h805
                            }
                        };
                        match m806 {
                            None => {
                                false
                            }
                            Some(v52) => {
                                f25(match v52 {
                                    Adt60::C0(h807, _, _, _, _, _) => {
                                        h807
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a808) {
                        let m811 = match v0.clone() {
                            Adt0::C0(h810, _, _, _, _, _, _) => {
                                h810
                            }
                        };
                        if match m811 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h809, _, _, _, _, _, _, _) => {
                                h809
                            }
                        } {
                            let a815 = {
                                let m814 = match v0.clone() {
                                    Adt0::C0(h813, _, _, _, _, _, _) => {
                                        h813
                                    }
                                };
                                match m814 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h812, _, _, _, _, _, _) => {
                                        h812
                                    }
                                }
                            };
                            bool_not(a815)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C3, Str::lit("Original objects for byte comparison (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C3)), true, {
                    let m819 = {
                        let m818 = match v0.clone() {
                            Adt0::C0(_, h817, _, _, _, _, _) => {
                                h817
                            }
                        };
                        match m818 {
                            Adt53::C0(h816, _, _, _, _, _, _, _) => {
                                h816
                            }
                        }
                    };
                    match m819 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m823 = {
                        let m822 = match v0.clone() {
                            Adt0::C0(_, h821, _, _, _, _, _) => {
                                h821
                            }
                        };
                        match m822 {
                            Adt53::C0(_, _, _, _, h820, _, _, _) => {
                                h820
                            }
                        }
                    };
                    match m823 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C3), f22(v0.clone(), Adt55::C3, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h824, _) => {
                        h824
                    }
                }, Adt55::C3), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h825, _) => {
                        h825
                    }
                }, Adt55::C3))?, {
                    let a829 = {
                        let m827 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h826) => {
                                h826
                            }
                        };
                        match m827 {
                            None => {
                                false
                            }
                            Some(v54) => {
                                f25(match v54 {
                                    Adt60::C0(h828, _, _, _, _, _) => {
                                        h828
                                    }
                                }, Adt55::C3)
                            }
                        }
                    };
                    if bool_not(a829) {
                        let m832 = match v0.clone() {
                            Adt0::C0(h831, _, _, _, _, _, _) => {
                                h831
                            }
                        };
                        if match m832 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h830, _, _, _, _, _, _, _) => {
                                h830
                            }
                        } {
                            let a836 = {
                                let m835 = match v0.clone() {
                                    Adt0::C0(h834, _, _, _, _, _, _) => {
                                        h834
                                    }
                                };
                                match m835 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h833, _, _, _, _, _, _) => {
                                        h833
                                    }
                                }
                            };
                            bool_not(a836)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m838 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h837) => {
                            h837
                        }
                    };
                    match m838 {
                        None => {
                            false
                        }
                        Some(v55) => {
                            f25(match v55 {
                                Adt60::C0(h839, _, _, _, _, _) => {
                                    h839
                                }
                            }, Adt55::C3)
                        }
                    }
                }, {
                    let a843 = {
                        let m841 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h840) => {
                                h840
                            }
                        };
                        match m841 {
                            None => {
                                false
                            }
                            Some(v56) => {
                                f25(match v56 {
                                    Adt60::C0(h842, _, _, _, _, _) => {
                                        h842
                                    }
                                }, Adt55::C3)
                            }
                        }
                    };
                    if bool_not(a843) {
                        let m846 = match v0.clone() {
                            Adt0::C0(h845, _, _, _, _, _, _) => {
                                h845
                            }
                        };
                        if match m846 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h844, _, _, _, _, _, _, _) => {
                                h844
                            }
                        } {
                            let a850 = {
                                let m849 = match v0 {
                                    Adt0::C0(h848, _, _, _, _, _, _) => {
                                        h848
                                    }
                                };
                                match m849 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h847, _, _, _, _, _, _) => {
                                        h847
                                    }
                                }
                            };
                            bool_not(a850)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            }
        }
        Adt54::C4 => {
            let m854 = {
                let m853 = match v0.clone() {
                    Adt0::C0(h852, _, _, _, _, _, _) => {
                        h852
                    }
                };
                match m853 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h851, _, _, _, _, _) => {
                        h851
                    }
                }
            };
            if if match m854 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m858 = {
                        let m857 = match v0.clone() {
                            Adt0::C0(_, h856, _, _, _, _, _) => {
                                h856
                            }
                        };
                        match m857 {
                            Adt53::C0(h855, _, _, _, _, _, _, _) => {
                                h855
                            }
                        }
                    };
                    match m858 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m862 = {
                        let m861 = match v0.clone() {
                            Adt0::C0(_, h860, _, _, _, _, _) => {
                                h860
                            }
                        };
                        match m861 {
                            Adt53::C0(_, h859, _, _, _, _, _, _) => {
                                h859
                            }
                        }
                    };
                    match m862 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h863, _) => {
                        h863
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h864, _) => {
                        h864
                    }
                }, Adt55::C0))?, {
                    let a868 = {
                        let m866 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h865) => {
                                h865
                            }
                        };
                        match m866 {
                            None => {
                                false
                            }
                            Some(v58) => {
                                f25(match v58 {
                                    Adt60::C0(h867, _, _, _, _, _) => {
                                        h867
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a868) {
                        let m871 = match v0.clone() {
                            Adt0::C0(h870, _, _, _, _, _, _) => {
                                h870
                            }
                        };
                        if match m871 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h869, _, _, _, _, _, _, _) => {
                                h869
                            }
                        } {
                            let a875 = {
                                let m874 = match v0.clone() {
                                    Adt0::C0(h873, _, _, _, _, _, _) => {
                                        h873
                                    }
                                };
                                match m874 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h872, _, _, _, _, _, _) => {
                                        h872
                                    }
                                }
                            };
                            bool_not(a875)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m877 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h876) => {
                            h876
                        }
                    };
                    match m877 {
                        None => {
                            false
                        }
                        Some(v59) => {
                            f25(match v59 {
                                Adt60::C0(h878, _, _, _, _, _) => {
                                    h878
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a882 = {
                        let m880 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h879) => {
                                h879
                            }
                        };
                        match m880 {
                            None => {
                                false
                            }
                            Some(v60) => {
                                f25(match v60 {
                                    Adt60::C0(h881, _, _, _, _, _) => {
                                        h881
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a882) {
                        let m885 = match v0.clone() {
                            Adt0::C0(h884, _, _, _, _, _, _) => {
                                h884
                            }
                        };
                        if match m885 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h883, _, _, _, _, _, _, _) => {
                                h883
                            }
                        } {
                            let a889 = {
                                let m888 = match v0.clone() {
                                    Adt0::C0(h887, _, _, _, _, _, _) => {
                                        h887
                                    }
                                };
                                match m888 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h886, _, _, _, _, _, _) => {
                                        h886
                                    }
                                }
                            };
                            bool_not(a889)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C4, Str::lit("Checkpoint"), f7(v0.clone(), Adt64::C1(Adt55::C4)), false, {
                    let m893 = {
                        let m892 = match v0.clone() {
                            Adt0::C0(_, h891, _, _, _, _, _) => {
                                h891
                            }
                        };
                        match m892 {
                            Adt53::C0(h890, _, _, _, _, _, _, _) => {
                                h890
                            }
                        }
                    };
                    match m893 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m897 = {
                        let m896 = match v0.clone() {
                            Adt0::C0(_, h895, _, _, _, _, _) => {
                                h895
                            }
                        };
                        match m896 {
                            Adt53::C0(_, _, _, _, _, h894, _, _) => {
                                h894
                            }
                        }
                    };
                    match m897 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C4), f22(v0.clone(), Adt55::C4, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h898, _) => {
                        h898
                    }
                }, Adt55::C4), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h899, _) => {
                        h899
                    }
                }, Adt55::C4))?, {
                    let a903 = {
                        let m901 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h900) => {
                                h900
                            }
                        };
                        match m901 {
                            None => {
                                false
                            }
                            Some(v62) => {
                                f25(match v62 {
                                    Adt60::C0(h902, _, _, _, _, _) => {
                                        h902
                                    }
                                }, Adt55::C4)
                            }
                        }
                    };
                    if bool_not(a903) {
                        let m906 = match v0.clone() {
                            Adt0::C0(h905, _, _, _, _, _, _) => {
                                h905
                            }
                        };
                        if match m906 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h904, _, _, _, _, _, _, _) => {
                                h904
                            }
                        } {
                            let a910 = {
                                let m909 = match v0.clone() {
                                    Adt0::C0(h908, _, _, _, _, _, _) => {
                                        h908
                                    }
                                };
                                match m909 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h907, _, _, _, _, _, _) => {
                                        h907
                                    }
                                }
                            };
                            bool_not(a910)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m912 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h911) => {
                            h911
                        }
                    };
                    match m912 {
                        None => {
                            false
                        }
                        Some(v63) => {
                            f25(match v63 {
                                Adt60::C0(h913, _, _, _, _, _) => {
                                    h913
                                }
                            }, Adt55::C4)
                        }
                    }
                }, {
                    let a917 = {
                        let m915 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h914) => {
                                h914
                            }
                        };
                        match m915 {
                            None => {
                                false
                            }
                            Some(v64) => {
                                f25(match v64 {
                                    Adt60::C0(h916, _, _, _, _, _) => {
                                        h916
                                    }
                                }, Adt55::C4)
                            }
                        }
                    };
                    if bool_not(a917) {
                        let m920 = match v0.clone() {
                            Adt0::C0(h919, _, _, _, _, _, _) => {
                                h919
                            }
                        };
                        if match m920 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h918, _, _, _, _, _, _, _) => {
                                h918
                            }
                        } {
                            let a924 = {
                                let m923 = match v0.clone() {
                                    Adt0::C0(h922, _, _, _, _, _, _) => {
                                        h922
                                    }
                                };
                                match m923 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h921, _, _, _, _, _, _) => {
                                        h921
                                    }
                                }
                            };
                            bool_not(a924)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m928 = {
                        let m927 = match v0.clone() {
                            Adt0::C0(_, h926, _, _, _, _, _) => {
                                h926
                            }
                        };
                        match m927 {
                            Adt53::C0(h925, _, _, _, _, _, _, _) => {
                                h925
                            }
                        }
                    };
                    match m928 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m932 = {
                        let m931 = match v0.clone() {
                            Adt0::C0(_, h930, _, _, _, _, _) => {
                                h930
                            }
                        };
                        match m931 {
                            Adt53::C0(_, _, _, h929, _, _, _, _) => {
                                h929
                            }
                        }
                    };
                    match m932 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h933, _) => {
                        h933
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h934, _) => {
                        h934
                    }
                }, Adt55::C2))?, {
                    let a938 = {
                        let m936 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h935) => {
                                h935
                            }
                        };
                        match m936 {
                            None => {
                                false
                            }
                            Some(v66) => {
                                f25(match v66 {
                                    Adt60::C0(h937, _, _, _, _, _) => {
                                        h937
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a938) {
                        let m941 = match v0.clone() {
                            Adt0::C0(h940, _, _, _, _, _, _) => {
                                h940
                            }
                        };
                        if match m941 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h939, _, _, _, _, _, _, _) => {
                                h939
                            }
                        } {
                            let a945 = {
                                let m944 = match v0.clone() {
                                    Adt0::C0(h943, _, _, _, _, _, _) => {
                                        h943
                                    }
                                };
                                match m944 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h942, _, _, _, _, _, _) => {
                                        h942
                                    }
                                }
                            };
                            bool_not(a945)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m947 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h946) => {
                            h946
                        }
                    };
                    match m947 {
                        None => {
                            false
                        }
                        Some(v67) => {
                            f25(match v67 {
                                Adt60::C0(h948, _, _, _, _, _) => {
                                    h948
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a952 = {
                        let m950 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h949) => {
                                h949
                            }
                        };
                        match m950 {
                            None => {
                                false
                            }
                            Some(v68) => {
                                f25(match v68 {
                                    Adt60::C0(h951, _, _, _, _, _) => {
                                        h951
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a952) {
                        let m955 = match v0.clone() {
                            Adt0::C0(h954, _, _, _, _, _, _) => {
                                h954
                            }
                        };
                        if match m955 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h953, _, _, _, _, _, _, _) => {
                                h953
                            }
                        } {
                            let a959 = {
                                let m958 = match v0 {
                                    Adt0::C0(h957, _, _, _, _, _, _) => {
                                        h957
                                    }
                                };
                                match m958 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h956, _, _, _, _, _, _) => {
                                        h956
                                    }
                                }
                            };
                            bool_not(a959)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m963 = {
                        let m962 = match v0.clone() {
                            Adt0::C0(_, h961, _, _, _, _, _) => {
                                h961
                            }
                        };
                        match m962 {
                            Adt53::C0(h960, _, _, _, _, _, _, _) => {
                                h960
                            }
                        }
                    };
                    match m963 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m967 = {
                        let m966 = match v0.clone() {
                            Adt0::C0(_, h965, _, _, _, _, _) => {
                                h965
                            }
                        };
                        match m966 {
                            Adt53::C0(_, h964, _, _, _, _, _, _) => {
                                h964
                            }
                        }
                    };
                    match m967 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h968, _) => {
                        h968
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h969, _) => {
                        h969
                    }
                }, Adt55::C0))?, {
                    let a973 = {
                        let m971 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h970) => {
                                h970
                            }
                        };
                        match m971 {
                            None => {
                                false
                            }
                            Some(v70) => {
                                f25(match v70 {
                                    Adt60::C0(h972, _, _, _, _, _) => {
                                        h972
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a973) {
                        let m976 = match v0.clone() {
                            Adt0::C0(h975, _, _, _, _, _, _) => {
                                h975
                            }
                        };
                        if match m976 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h974, _, _, _, _, _, _, _) => {
                                h974
                            }
                        } {
                            let a980 = {
                                let m979 = match v0.clone() {
                                    Adt0::C0(h978, _, _, _, _, _, _) => {
                                        h978
                                    }
                                };
                                match m979 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h977, _, _, _, _, _, _) => {
                                        h977
                                    }
                                }
                            };
                            bool_not(a980)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m982 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h981) => {
                            h981
                        }
                    };
                    match m982 {
                        None => {
                            false
                        }
                        Some(v71) => {
                            f25(match v71 {
                                Adt60::C0(h983, _, _, _, _, _) => {
                                    h983
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a987 = {
                        let m985 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h984) => {
                                h984
                            }
                        };
                        match m985 {
                            None => {
                                false
                            }
                            Some(v72) => {
                                f25(match v72 {
                                    Adt60::C0(h986, _, _, _, _, _) => {
                                        h986
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a987) {
                        let m990 = match v0.clone() {
                            Adt0::C0(h989, _, _, _, _, _, _) => {
                                h989
                            }
                        };
                        if match m990 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h988, _, _, _, _, _, _, _) => {
                                h988
                            }
                        } {
                            let a994 = {
                                let m993 = match v0.clone() {
                                    Adt0::C0(h992, _, _, _, _, _, _) => {
                                        h992
                                    }
                                };
                                match m993 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h991, _, _, _, _, _, _) => {
                                        h991
                                    }
                                }
                            };
                            bool_not(a994)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C4, Str::lit("Checkpoint"), f7(v0.clone(), Adt64::C1(Adt55::C4)), false, {
                    let m998 = {
                        let m997 = match v0.clone() {
                            Adt0::C0(_, h996, _, _, _, _, _) => {
                                h996
                            }
                        };
                        match m997 {
                            Adt53::C0(h995, _, _, _, _, _, _, _) => {
                                h995
                            }
                        }
                    };
                    match m998 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1002 = {
                        let m1001 = match v0.clone() {
                            Adt0::C0(_, h1000, _, _, _, _, _) => {
                                h1000
                            }
                        };
                        match m1001 {
                            Adt53::C0(_, _, _, _, _, h999, _, _) => {
                                h999
                            }
                        }
                    };
                    match m1002 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C4), f22(v0.clone(), Adt55::C4, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1003, _) => {
                        h1003
                    }
                }, Adt55::C4), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1004, _) => {
                        h1004
                    }
                }, Adt55::C4))?, {
                    let a1008 = {
                        let m1006 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1005) => {
                                h1005
                            }
                        };
                        match m1006 {
                            None => {
                                false
                            }
                            Some(v74) => {
                                f25(match v74 {
                                    Adt60::C0(h1007, _, _, _, _, _) => {
                                        h1007
                                    }
                                }, Adt55::C4)
                            }
                        }
                    };
                    if bool_not(a1008) {
                        let m1011 = match v0.clone() {
                            Adt0::C0(h1010, _, _, _, _, _, _) => {
                                h1010
                            }
                        };
                        if match m1011 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1009, _, _, _, _, _, _, _) => {
                                h1009
                            }
                        } {
                            let a1015 = {
                                let m1014 = match v0.clone() {
                                    Adt0::C0(h1013, _, _, _, _, _, _) => {
                                        h1013
                                    }
                                };
                                match m1014 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1012, _, _, _, _, _, _) => {
                                        h1012
                                    }
                                }
                            };
                            bool_not(a1015)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1017 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1016) => {
                            h1016
                        }
                    };
                    match m1017 {
                        None => {
                            false
                        }
                        Some(v75) => {
                            f25(match v75 {
                                Adt60::C0(h1018, _, _, _, _, _) => {
                                    h1018
                                }
                            }, Adt55::C4)
                        }
                    }
                }, {
                    let a1022 = {
                        let m1020 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1019) => {
                                h1019
                            }
                        };
                        match m1020 {
                            None => {
                                false
                            }
                            Some(v76) => {
                                f25(match v76 {
                                    Adt60::C0(h1021, _, _, _, _, _) => {
                                        h1021
                                    }
                                }, Adt55::C4)
                            }
                        }
                    };
                    if bool_not(a1022) {
                        let m1025 = match v0.clone() {
                            Adt0::C0(h1024, _, _, _, _, _, _) => {
                                h1024
                            }
                        };
                        if match m1025 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1023, _, _, _, _, _, _, _) => {
                                h1023
                            }
                        } {
                            let a1029 = {
                                let m1028 = match v0 {
                                    Adt0::C0(h1027, _, _, _, _, _, _) => {
                                        h1027
                                    }
                                };
                                match m1028 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1026, _, _, _, _, _, _) => {
                                        h1026
                                    }
                                }
                            };
                            bool_not(a1029)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            }
        }
        Adt54::C5 => {
            let m1033 = {
                let m1032 = match v0.clone() {
                    Adt0::C0(h1031, _, _, _, _, _, _) => {
                        h1031
                    }
                };
                match m1032 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1030, _, _, _, _, _) => {
                        h1030
                    }
                }
            };
            if if match m1033 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m1037 = {
                        let m1036 = match v0.clone() {
                            Adt0::C0(_, h1035, _, _, _, _, _) => {
                                h1035
                            }
                        };
                        match m1036 {
                            Adt53::C0(h1034, _, _, _, _, _, _, _) => {
                                h1034
                            }
                        }
                    };
                    match m1037 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m1041 = {
                        let m1040 = match v0.clone() {
                            Adt0::C0(_, h1039, _, _, _, _, _) => {
                                h1039
                            }
                        };
                        match m1040 {
                            Adt53::C0(_, h1038, _, _, _, _, _, _) => {
                                h1038
                            }
                        }
                    };
                    match m1041 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1042, _) => {
                        h1042
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1043, _) => {
                        h1043
                    }
                }, Adt55::C0))?, {
                    let a1047 = {
                        let m1045 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1044) => {
                                h1044
                            }
                        };
                        match m1045 {
                            None => {
                                false
                            }
                            Some(v78) => {
                                f25(match v78 {
                                    Adt60::C0(h1046, _, _, _, _, _) => {
                                        h1046
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1047) {
                        let m1050 = match v0.clone() {
                            Adt0::C0(h1049, _, _, _, _, _, _) => {
                                h1049
                            }
                        };
                        if match m1050 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1048, _, _, _, _, _, _, _) => {
                                h1048
                            }
                        } {
                            let a1054 = {
                                let m1053 = match v0.clone() {
                                    Adt0::C0(h1052, _, _, _, _, _, _) => {
                                        h1052
                                    }
                                };
                                match m1053 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1051, _, _, _, _, _, _) => {
                                        h1051
                                    }
                                }
                            };
                            bool_not(a1054)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1056 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1055) => {
                            h1055
                        }
                    };
                    match m1056 {
                        None => {
                            false
                        }
                        Some(v79) => {
                            f25(match v79 {
                                Adt60::C0(h1057, _, _, _, _, _) => {
                                    h1057
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a1061 = {
                        let m1059 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1058) => {
                                h1058
                            }
                        };
                        match m1059 {
                            None => {
                                false
                            }
                            Some(v80) => {
                                f25(match v80 {
                                    Adt60::C0(h1060, _, _, _, _, _) => {
                                        h1060
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1061) {
                        let m1064 = match v0.clone() {
                            Adt0::C0(h1063, _, _, _, _, _, _) => {
                                h1063
                            }
                        };
                        if match m1064 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1062, _, _, _, _, _, _, _) => {
                                h1062
                            }
                        } {
                            let a1068 = {
                                let m1067 = match v0.clone() {
                                    Adt0::C0(h1066, _, _, _, _, _, _) => {
                                        h1066
                                    }
                                };
                                match m1067 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1065, _, _, _, _, _, _) => {
                                        h1065
                                    }
                                }
                            };
                            bool_not(a1068)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m1072 = {
                        let m1071 = match v0.clone() {
                            Adt0::C0(_, h1070, _, _, _, _, _) => {
                                h1070
                            }
                        };
                        match m1071 {
                            Adt53::C0(h1069, _, _, _, _, _, _, _) => {
                                h1069
                            }
                        }
                    };
                    match m1072 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1076 = {
                        let m1075 = match v0.clone() {
                            Adt0::C0(_, h1074, _, _, _, _, _) => {
                                h1074
                            }
                        };
                        match m1075 {
                            Adt53::C0(_, _, _, h1073, _, _, _, _) => {
                                h1073
                            }
                        }
                    };
                    match m1076 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1077, _) => {
                        h1077
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1078, _) => {
                        h1078
                    }
                }, Adt55::C2))?, {
                    let a1082 = {
                        let m1080 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1079) => {
                                h1079
                            }
                        };
                        match m1080 {
                            None => {
                                false
                            }
                            Some(v82) => {
                                f25(match v82 {
                                    Adt60::C0(h1081, _, _, _, _, _) => {
                                        h1081
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1082) {
                        let m1085 = match v0.clone() {
                            Adt0::C0(h1084, _, _, _, _, _, _) => {
                                h1084
                            }
                        };
                        if match m1085 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1083, _, _, _, _, _, _, _) => {
                                h1083
                            }
                        } {
                            let a1089 = {
                                let m1088 = match v0.clone() {
                                    Adt0::C0(h1087, _, _, _, _, _, _) => {
                                        h1087
                                    }
                                };
                                match m1088 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1086, _, _, _, _, _, _) => {
                                        h1086
                                    }
                                }
                            };
                            bool_not(a1089)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1091 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1090) => {
                            h1090
                        }
                    };
                    match m1091 {
                        None => {
                            false
                        }
                        Some(v83) => {
                            f25(match v83 {
                                Adt60::C0(h1092, _, _, _, _, _) => {
                                    h1092
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a1096 = {
                        let m1094 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1093) => {
                                h1093
                            }
                        };
                        match m1094 {
                            None => {
                                false
                            }
                            Some(v84) => {
                                f25(match v84 {
                                    Adt60::C0(h1095, _, _, _, _, _) => {
                                        h1095
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1096) {
                        let m1099 = match v0.clone() {
                            Adt0::C0(h1098, _, _, _, _, _, _) => {
                                h1098
                            }
                        };
                        if match m1099 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1097, _, _, _, _, _, _, _) => {
                                h1097
                            }
                        } {
                            let a1103 = {
                                let m1102 = match v0 {
                                    Adt0::C0(h1101, _, _, _, _, _, _) => {
                                        h1101
                                    }
                                };
                                match m1102 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1100, _, _, _, _, _, _) => {
                                        h1100
                                    }
                                }
                            };
                            bool_not(a1103)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m1107 = {
                        let m1106 = match v0.clone() {
                            Adt0::C0(_, h1105, _, _, _, _, _) => {
                                h1105
                            }
                        };
                        match m1106 {
                            Adt53::C0(h1104, _, _, _, _, _, _, _) => {
                                h1104
                            }
                        }
                    };
                    match m1107 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m1111 = {
                        let m1110 = match v0.clone() {
                            Adt0::C0(_, h1109, _, _, _, _, _) => {
                                h1109
                            }
                        };
                        match m1110 {
                            Adt53::C0(_, h1108, _, _, _, _, _, _) => {
                                h1108
                            }
                        }
                    };
                    match m1111 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1112, _) => {
                        h1112
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1113, _) => {
                        h1113
                    }
                }, Adt55::C0))?, {
                    let a1117 = {
                        let m1115 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1114) => {
                                h1114
                            }
                        };
                        match m1115 {
                            None => {
                                false
                            }
                            Some(v86) => {
                                f25(match v86 {
                                    Adt60::C0(h1116, _, _, _, _, _) => {
                                        h1116
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1117) {
                        let m1120 = match v0.clone() {
                            Adt0::C0(h1119, _, _, _, _, _, _) => {
                                h1119
                            }
                        };
                        if match m1120 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1118, _, _, _, _, _, _, _) => {
                                h1118
                            }
                        } {
                            let a1124 = {
                                let m1123 = match v0.clone() {
                                    Adt0::C0(h1122, _, _, _, _, _, _) => {
                                        h1122
                                    }
                                };
                                match m1123 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1121, _, _, _, _, _, _) => {
                                        h1121
                                    }
                                }
                            };
                            bool_not(a1124)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1126 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1125) => {
                            h1125
                        }
                    };
                    match m1126 {
                        None => {
                            false
                        }
                        Some(v87) => {
                            f25(match v87 {
                                Adt60::C0(h1127, _, _, _, _, _) => {
                                    h1127
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a1131 = {
                        let m1129 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1128) => {
                                h1128
                            }
                        };
                        match m1129 {
                            None => {
                                false
                            }
                            Some(v88) => {
                                f25(match v88 {
                                    Adt60::C0(h1130, _, _, _, _, _) => {
                                        h1130
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1131) {
                        let m1134 = match v0.clone() {
                            Adt0::C0(h1133, _, _, _, _, _, _) => {
                                h1133
                            }
                        };
                        if match m1134 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1132, _, _, _, _, _, _, _) => {
                                h1132
                            }
                        } {
                            let a1138 = {
                                let m1137 = match v0 {
                                    Adt0::C0(h1136, _, _, _, _, _, _) => {
                                        h1136
                                    }
                                };
                                match m1137 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1135, _, _, _, _, _, _) => {
                                        h1135
                                    }
                                }
                            };
                            bool_not(a1138)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))
            }
        }
        Adt54::C6 => {
            let m1142 = {
                let m1141 = match v0.clone() {
                    Adt0::C0(h1140, _, _, _, _, _, _) => {
                        h1140
                    }
                };
                match m1141 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1139, _, _, _, _, _) => {
                        h1139
                    }
                }
            };
            if if match m1142 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m1146 = {
                        let m1145 = match v0.clone() {
                            Adt0::C0(_, h1144, _, _, _, _, _) => {
                                h1144
                            }
                        };
                        match m1145 {
                            Adt53::C0(h1143, _, _, _, _, _, _, _) => {
                                h1143
                            }
                        }
                    };
                    match m1146 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m1150 = {
                        let m1149 = match v0.clone() {
                            Adt0::C0(_, h1148, _, _, _, _, _) => {
                                h1148
                            }
                        };
                        match m1149 {
                            Adt53::C0(_, h1147, _, _, _, _, _, _) => {
                                h1147
                            }
                        }
                    };
                    match m1150 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1151, _) => {
                        h1151
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1152, _) => {
                        h1152
                    }
                }, Adt55::C0))?, {
                    let a1156 = {
                        let m1154 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1153) => {
                                h1153
                            }
                        };
                        match m1154 {
                            None => {
                                false
                            }
                            Some(v90) => {
                                f25(match v90 {
                                    Adt60::C0(h1155, _, _, _, _, _) => {
                                        h1155
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1156) {
                        let m1159 = match v0.clone() {
                            Adt0::C0(h1158, _, _, _, _, _, _) => {
                                h1158
                            }
                        };
                        if match m1159 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1157, _, _, _, _, _, _, _) => {
                                h1157
                            }
                        } {
                            let a1163 = {
                                let m1162 = match v0.clone() {
                                    Adt0::C0(h1161, _, _, _, _, _, _) => {
                                        h1161
                                    }
                                };
                                match m1162 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1160, _, _, _, _, _, _) => {
                                        h1160
                                    }
                                }
                            };
                            bool_not(a1163)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1165 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1164) => {
                            h1164
                        }
                    };
                    match m1165 {
                        None => {
                            false
                        }
                        Some(v91) => {
                            f25(match v91 {
                                Adt60::C0(h1166, _, _, _, _, _) => {
                                    h1166
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a1170 = {
                        let m1168 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1167) => {
                                h1167
                            }
                        };
                        match m1168 {
                            None => {
                                false
                            }
                            Some(v92) => {
                                f25(match v92 {
                                    Adt60::C0(h1169, _, _, _, _, _) => {
                                        h1169
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1170) {
                        let m1173 = match v0.clone() {
                            Adt0::C0(h1172, _, _, _, _, _, _) => {
                                h1172
                            }
                        };
                        if match m1173 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1171, _, _, _, _, _, _, _) => {
                                h1171
                            }
                        } {
                            let a1177 = {
                                let m1176 = match v0.clone() {
                                    Adt0::C0(h1175, _, _, _, _, _, _) => {
                                        h1175
                                    }
                                };
                                match m1176 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1174, _, _, _, _, _, _) => {
                                        h1174
                                    }
                                }
                            };
                            bool_not(a1177)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m1181 = {
                        let m1180 = match v0.clone() {
                            Adt0::C0(_, h1179, _, _, _, _, _) => {
                                h1179
                            }
                        };
                        match m1180 {
                            Adt53::C0(h1178, _, _, _, _, _, _, _) => {
                                h1178
                            }
                        }
                    };
                    match m1181 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1185 = {
                        let m1184 = match v0.clone() {
                            Adt0::C0(_, h1183, _, _, _, _, _) => {
                                h1183
                            }
                        };
                        match m1184 {
                            Adt53::C0(_, _, h1182, _, _, _, _, _) => {
                                h1182
                            }
                        }
                    };
                    match m1185 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1186, _) => {
                        h1186
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1187, _) => {
                        h1187
                    }
                }, Adt55::C1))?, {
                    let a1191 = {
                        let m1189 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1188) => {
                                h1188
                            }
                        };
                        match m1189 {
                            None => {
                                false
                            }
                            Some(v94) => {
                                f25(match v94 {
                                    Adt60::C0(h1190, _, _, _, _, _) => {
                                        h1190
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a1191) {
                        let m1194 = match v0.clone() {
                            Adt0::C0(h1193, _, _, _, _, _, _) => {
                                h1193
                            }
                        };
                        if match m1194 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1192, _, _, _, _, _, _, _) => {
                                h1192
                            }
                        } {
                            let a1198 = {
                                let m1197 = match v0.clone() {
                                    Adt0::C0(h1196, _, _, _, _, _, _) => {
                                        h1196
                                    }
                                };
                                match m1197 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1195, _, _, _, _, _, _) => {
                                        h1195
                                    }
                                }
                            };
                            bool_not(a1198)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1200 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1199) => {
                            h1199
                        }
                    };
                    match m1200 {
                        None => {
                            false
                        }
                        Some(v95) => {
                            f25(match v95 {
                                Adt60::C0(h1201, _, _, _, _, _) => {
                                    h1201
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a1205 = {
                        let m1203 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1202) => {
                                h1202
                            }
                        };
                        match m1203 {
                            None => {
                                false
                            }
                            Some(v96) => {
                                f25(match v96 {
                                    Adt60::C0(h1204, _, _, _, _, _) => {
                                        h1204
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a1205) {
                        let m1208 = match v0.clone() {
                            Adt0::C0(h1207, _, _, _, _, _, _) => {
                                h1207
                            }
                        };
                        if match m1208 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1206, _, _, _, _, _, _, _) => {
                                h1206
                            }
                        } {
                            let a1212 = {
                                let m1211 = match v0.clone() {
                                    Adt0::C0(h1210, _, _, _, _, _, _) => {
                                        h1210
                                    }
                                };
                                match m1211 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1209, _, _, _, _, _, _) => {
                                        h1209
                                    }
                                }
                            };
                            bool_not(a1212)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m1216 = {
                        let m1215 = match v0.clone() {
                            Adt0::C0(_, h1214, _, _, _, _, _) => {
                                h1214
                            }
                        };
                        match m1215 {
                            Adt53::C0(h1213, _, _, _, _, _, _, _) => {
                                h1213
                            }
                        }
                    };
                    match m1216 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1220 = {
                        let m1219 = match v0.clone() {
                            Adt0::C0(_, h1218, _, _, _, _, _) => {
                                h1218
                            }
                        };
                        match m1219 {
                            Adt53::C0(_, _, _, h1217, _, _, _, _) => {
                                h1217
                            }
                        }
                    };
                    match m1220 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1221, _) => {
                        h1221
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1222, _) => {
                        h1222
                    }
                }, Adt55::C2))?, {
                    let a1226 = {
                        let m1224 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1223) => {
                                h1223
                            }
                        };
                        match m1224 {
                            None => {
                                false
                            }
                            Some(v98) => {
                                f25(match v98 {
                                    Adt60::C0(h1225, _, _, _, _, _) => {
                                        h1225
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1226) {
                        let m1229 = match v0.clone() {
                            Adt0::C0(h1228, _, _, _, _, _, _) => {
                                h1228
                            }
                        };
                        if match m1229 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1227, _, _, _, _, _, _, _) => {
                                h1227
                            }
                        } {
                            let a1233 = {
                                let m1232 = match v0.clone() {
                                    Adt0::C0(h1231, _, _, _, _, _, _) => {
                                        h1231
                                    }
                                };
                                match m1232 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1230, _, _, _, _, _, _) => {
                                        h1230
                                    }
                                }
                            };
                            bool_not(a1233)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1235 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1234) => {
                            h1234
                        }
                    };
                    match m1235 {
                        None => {
                            false
                        }
                        Some(v99) => {
                            f25(match v99 {
                                Adt60::C0(h1236, _, _, _, _, _) => {
                                    h1236
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a1240 = {
                        let m1238 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1237) => {
                                h1237
                            }
                        };
                        match m1238 {
                            None => {
                                false
                            }
                            Some(v100) => {
                                f25(match v100 {
                                    Adt60::C0(h1239, _, _, _, _, _) => {
                                        h1239
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1240) {
                        let m1243 = match v0.clone() {
                            Adt0::C0(h1242, _, _, _, _, _, _) => {
                                h1242
                            }
                        };
                        if match m1243 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1241, _, _, _, _, _, _, _) => {
                                h1241
                            }
                        } {
                            let a1247 = {
                                let m1246 = match v0 {
                                    Adt0::C0(h1245, _, _, _, _, _, _) => {
                                        h1245
                                    }
                                };
                                match m1246 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1244, _, _, _, _, _, _) => {
                                        h1244
                                    }
                                }
                            };
                            bool_not(a1247)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m1251 = {
                        let m1250 = match v0.clone() {
                            Adt0::C0(_, h1249, _, _, _, _, _) => {
                                h1249
                            }
                        };
                        match m1250 {
                            Adt53::C0(h1248, _, _, _, _, _, _, _) => {
                                h1248
                            }
                        }
                    };
                    match m1251 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m1255 = {
                        let m1254 = match v0.clone() {
                            Adt0::C0(_, h1253, _, _, _, _, _) => {
                                h1253
                            }
                        };
                        match m1254 {
                            Adt53::C0(_, h1252, _, _, _, _, _, _) => {
                                h1252
                            }
                        }
                    };
                    match m1255 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1256, _) => {
                        h1256
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1257, _) => {
                        h1257
                    }
                }, Adt55::C0))?, {
                    let a1261 = {
                        let m1259 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1258) => {
                                h1258
                            }
                        };
                        match m1259 {
                            None => {
                                false
                            }
                            Some(v102) => {
                                f25(match v102 {
                                    Adt60::C0(h1260, _, _, _, _, _) => {
                                        h1260
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1261) {
                        let m1264 = match v0.clone() {
                            Adt0::C0(h1263, _, _, _, _, _, _) => {
                                h1263
                            }
                        };
                        if match m1264 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1262, _, _, _, _, _, _, _) => {
                                h1262
                            }
                        } {
                            let a1268 = {
                                let m1267 = match v0.clone() {
                                    Adt0::C0(h1266, _, _, _, _, _, _) => {
                                        h1266
                                    }
                                };
                                match m1267 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1265, _, _, _, _, _, _) => {
                                        h1265
                                    }
                                }
                            };
                            bool_not(a1268)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1270 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1269) => {
                            h1269
                        }
                    };
                    match m1270 {
                        None => {
                            false
                        }
                        Some(v103) => {
                            f25(match v103 {
                                Adt60::C0(h1271, _, _, _, _, _) => {
                                    h1271
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a1275 = {
                        let m1273 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1272) => {
                                h1272
                            }
                        };
                        match m1273 {
                            None => {
                                false
                            }
                            Some(v104) => {
                                f25(match v104 {
                                    Adt60::C0(h1274, _, _, _, _, _) => {
                                        h1274
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1275) {
                        let m1278 = match v0.clone() {
                            Adt0::C0(h1277, _, _, _, _, _, _) => {
                                h1277
                            }
                        };
                        if match m1278 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1276, _, _, _, _, _, _, _) => {
                                h1276
                            }
                        } {
                            let a1282 = {
                                let m1281 = match v0.clone() {
                                    Adt0::C0(h1280, _, _, _, _, _, _) => {
                                        h1280
                                    }
                                };
                                match m1281 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1279, _, _, _, _, _, _) => {
                                        h1279
                                    }
                                }
                            };
                            bool_not(a1282)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m1286 = {
                        let m1285 = match v0.clone() {
                            Adt0::C0(_, h1284, _, _, _, _, _) => {
                                h1284
                            }
                        };
                        match m1285 {
                            Adt53::C0(h1283, _, _, _, _, _, _, _) => {
                                h1283
                            }
                        }
                    };
                    match m1286 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1290 = {
                        let m1289 = match v0.clone() {
                            Adt0::C0(_, h1288, _, _, _, _, _) => {
                                h1288
                            }
                        };
                        match m1289 {
                            Adt53::C0(_, _, h1287, _, _, _, _, _) => {
                                h1287
                            }
                        }
                    };
                    match m1290 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1291, _) => {
                        h1291
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1292, _) => {
                        h1292
                    }
                }, Adt55::C1))?, {
                    let a1296 = {
                        let m1294 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1293) => {
                                h1293
                            }
                        };
                        match m1294 {
                            None => {
                                false
                            }
                            Some(v106) => {
                                f25(match v106 {
                                    Adt60::C0(h1295, _, _, _, _, _) => {
                                        h1295
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a1296) {
                        let m1299 = match v0.clone() {
                            Adt0::C0(h1298, _, _, _, _, _, _) => {
                                h1298
                            }
                        };
                        if match m1299 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1297, _, _, _, _, _, _, _) => {
                                h1297
                            }
                        } {
                            let a1303 = {
                                let m1302 = match v0.clone() {
                                    Adt0::C0(h1301, _, _, _, _, _, _) => {
                                        h1301
                                    }
                                };
                                match m1302 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1300, _, _, _, _, _, _) => {
                                        h1300
                                    }
                                }
                            };
                            bool_not(a1303)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1305 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1304) => {
                            h1304
                        }
                    };
                    match m1305 {
                        None => {
                            false
                        }
                        Some(v107) => {
                            f25(match v107 {
                                Adt60::C0(h1306, _, _, _, _, _) => {
                                    h1306
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a1310 = {
                        let m1308 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1307) => {
                                h1307
                            }
                        };
                        match m1308 {
                            None => {
                                false
                            }
                            Some(v108) => {
                                f25(match v108 {
                                    Adt60::C0(h1309, _, _, _, _, _) => {
                                        h1309
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a1310) {
                        let m1313 = match v0.clone() {
                            Adt0::C0(h1312, _, _, _, _, _, _) => {
                                h1312
                            }
                        };
                        if match m1313 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1311, _, _, _, _, _, _, _) => {
                                h1311
                            }
                        } {
                            let a1317 = {
                                let m1316 = match v0 {
                                    Adt0::C0(h1315, _, _, _, _, _, _) => {
                                        h1315
                                    }
                                };
                                match m1316 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1314, _, _, _, _, _, _) => {
                                        h1314
                                    }
                                }
                            };
                            bool_not(a1317)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            }
        }
        Adt54::C7 => {
            let m1321 = {
                let m1320 = match v0.clone() {
                    Adt0::C0(h1319, _, _, _, _, _, _) => {
                        h1319
                    }
                };
                match m1320 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1318, _, _, _, _, _) => {
                        h1318
                    }
                }
            };
            if if match m1321 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m1325 = {
                        let m1324 = match v0.clone() {
                            Adt0::C0(_, h1323, _, _, _, _, _) => {
                                h1323
                            }
                        };
                        match m1324 {
                            Adt53::C0(h1322, _, _, _, _, _, _, _) => {
                                h1322
                            }
                        }
                    };
                    match m1325 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1329 = {
                        let m1328 = match v0.clone() {
                            Adt0::C0(_, h1327, _, _, _, _, _) => {
                                h1327
                            }
                        };
                        match m1328 {
                            Adt53::C0(_, _, h1326, _, _, _, _, _) => {
                                h1326
                            }
                        }
                    };
                    match m1329 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1330, _) => {
                        h1330
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1331, _) => {
                        h1331
                    }
                }, Adt55::C1))?, {
                    let a1335 = {
                        let m1333 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1332) => {
                                h1332
                            }
                        };
                        match m1333 {
                            None => {
                                false
                            }
                            Some(v110) => {
                                f25(match v110 {
                                    Adt60::C0(h1334, _, _, _, _, _) => {
                                        h1334
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a1335) {
                        let m1338 = match v0.clone() {
                            Adt0::C0(h1337, _, _, _, _, _, _) => {
                                h1337
                            }
                        };
                        if match m1338 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1336, _, _, _, _, _, _, _) => {
                                h1336
                            }
                        } {
                            let a1342 = {
                                let m1341 = match v0.clone() {
                                    Adt0::C0(h1340, _, _, _, _, _, _) => {
                                        h1340
                                    }
                                };
                                match m1341 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1339, _, _, _, _, _, _) => {
                                        h1339
                                    }
                                }
                            };
                            bool_not(a1342)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1344 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1343) => {
                            h1343
                        }
                    };
                    match m1344 {
                        None => {
                            false
                        }
                        Some(v111) => {
                            f25(match v111 {
                                Adt60::C0(h1345, _, _, _, _, _) => {
                                    h1345
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a1349 = {
                        let m1347 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1346) => {
                                h1346
                            }
                        };
                        match m1347 {
                            None => {
                                false
                            }
                            Some(v112) => {
                                f25(match v112 {
                                    Adt60::C0(h1348, _, _, _, _, _) => {
                                        h1348
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a1349) {
                        let m1352 = match v0.clone() {
                            Adt0::C0(h1351, _, _, _, _, _, _) => {
                                h1351
                            }
                        };
                        if match m1352 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1350, _, _, _, _, _, _, _) => {
                                h1350
                            }
                        } {
                            let a1356 = {
                                let m1355 = match v0.clone() {
                                    Adt0::C0(h1354, _, _, _, _, _, _) => {
                                        h1354
                                    }
                                };
                                match m1355 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1353, _, _, _, _, _, _) => {
                                        h1353
                                    }
                                }
                            };
                            bool_not(a1356)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C5, Str::lit("Second archive"), f7(v0.clone(), Adt64::C1(Adt55::C5)), false, {
                    let m1360 = {
                        let m1359 = match v0.clone() {
                            Adt0::C0(_, h1358, _, _, _, _, _) => {
                                h1358
                            }
                        };
                        match m1359 {
                            Adt53::C0(h1357, _, _, _, _, _, _, _) => {
                                h1357
                            }
                        }
                    };
                    match m1360 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1364 = {
                        let m1363 = match v0.clone() {
                            Adt0::C0(_, h1362, _, _, _, _, _) => {
                                h1362
                            }
                        };
                        match m1363 {
                            Adt53::C0(_, _, _, _, _, _, h1361, _) => {
                                h1361
                            }
                        }
                    };
                    match m1364 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C5), f22(v0.clone(), Adt55::C5, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1365, _) => {
                        h1365
                    }
                }, Adt55::C5), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1366, _) => {
                        h1366
                    }
                }, Adt55::C5))?, {
                    let a1370 = {
                        let m1368 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1367) => {
                                h1367
                            }
                        };
                        match m1368 {
                            None => {
                                false
                            }
                            Some(v114) => {
                                f25(match v114 {
                                    Adt60::C0(h1369, _, _, _, _, _) => {
                                        h1369
                                    }
                                }, Adt55::C5)
                            }
                        }
                    };
                    if bool_not(a1370) {
                        let m1373 = match v0.clone() {
                            Adt0::C0(h1372, _, _, _, _, _, _) => {
                                h1372
                            }
                        };
                        if match m1373 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1371, _, _, _, _, _, _, _) => {
                                h1371
                            }
                        } {
                            let a1377 = {
                                let m1376 = match v0.clone() {
                                    Adt0::C0(h1375, _, _, _, _, _, _) => {
                                        h1375
                                    }
                                };
                                match m1376 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1374, _, _, _, _, _, _) => {
                                        h1374
                                    }
                                }
                            };
                            bool_not(a1377)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1379 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1378) => {
                            h1378
                        }
                    };
                    match m1379 {
                        None => {
                            false
                        }
                        Some(v115) => {
                            f25(match v115 {
                                Adt60::C0(h1380, _, _, _, _, _) => {
                                    h1380
                                }
                            }, Adt55::C5)
                        }
                    }
                }, {
                    let a1384 = {
                        let m1382 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1381) => {
                                h1381
                            }
                        };
                        match m1382 {
                            None => {
                                false
                            }
                            Some(v116) => {
                                f25(match v116 {
                                    Adt60::C0(h1383, _, _, _, _, _) => {
                                        h1383
                                    }
                                }, Adt55::C5)
                            }
                        }
                    };
                    if bool_not(a1384) {
                        let m1387 = match v0.clone() {
                            Adt0::C0(h1386, _, _, _, _, _, _) => {
                                h1386
                            }
                        };
                        if match m1387 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1385, _, _, _, _, _, _, _) => {
                                h1385
                            }
                        } {
                            let a1391 = {
                                let m1390 = match v0.clone() {
                                    Adt0::C0(h1389, _, _, _, _, _, _) => {
                                        h1389
                                    }
                                };
                                match m1390 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1388, _, _, _, _, _, _) => {
                                        h1388
                                    }
                                }
                            };
                            bool_not(a1391)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C3, Str::lit("Original objects for byte comparison (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C3)), true, {
                    let m1395 = {
                        let m1394 = match v0.clone() {
                            Adt0::C0(_, h1393, _, _, _, _, _) => {
                                h1393
                            }
                        };
                        match m1394 {
                            Adt53::C0(h1392, _, _, _, _, _, _, _) => {
                                h1392
                            }
                        }
                    };
                    match m1395 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1399 = {
                        let m1398 = match v0.clone() {
                            Adt0::C0(_, h1397, _, _, _, _, _) => {
                                h1397
                            }
                        };
                        match m1398 {
                            Adt53::C0(_, _, _, _, h1396, _, _, _) => {
                                h1396
                            }
                        }
                    };
                    match m1399 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C3), f22(v0.clone(), Adt55::C3, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1400, _) => {
                        h1400
                    }
                }, Adt55::C3), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1401, _) => {
                        h1401
                    }
                }, Adt55::C3))?, {
                    let a1405 = {
                        let m1403 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1402) => {
                                h1402
                            }
                        };
                        match m1403 {
                            None => {
                                false
                            }
                            Some(v118) => {
                                f25(match v118 {
                                    Adt60::C0(h1404, _, _, _, _, _) => {
                                        h1404
                                    }
                                }, Adt55::C3)
                            }
                        }
                    };
                    if bool_not(a1405) {
                        let m1408 = match v0.clone() {
                            Adt0::C0(h1407, _, _, _, _, _, _) => {
                                h1407
                            }
                        };
                        if match m1408 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1406, _, _, _, _, _, _, _) => {
                                h1406
                            }
                        } {
                            let a1412 = {
                                let m1411 = match v0.clone() {
                                    Adt0::C0(h1410, _, _, _, _, _, _) => {
                                        h1410
                                    }
                                };
                                match m1411 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1409, _, _, _, _, _, _) => {
                                        h1409
                                    }
                                }
                            };
                            bool_not(a1412)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1414 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1413) => {
                            h1413
                        }
                    };
                    match m1414 {
                        None => {
                            false
                        }
                        Some(v119) => {
                            f25(match v119 {
                                Adt60::C0(h1415, _, _, _, _, _) => {
                                    h1415
                                }
                            }, Adt55::C3)
                        }
                    }
                }, {
                    let a1419 = {
                        let m1417 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1416) => {
                                h1416
                            }
                        };
                        match m1417 {
                            None => {
                                false
                            }
                            Some(v120) => {
                                f25(match v120 {
                                    Adt60::C0(h1418, _, _, _, _, _) => {
                                        h1418
                                    }
                                }, Adt55::C3)
                            }
                        }
                    };
                    if bool_not(a1419) {
                        let m1422 = match v0.clone() {
                            Adt0::C0(h1421, _, _, _, _, _, _) => {
                                h1421
                            }
                        };
                        if match m1422 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1420, _, _, _, _, _, _, _) => {
                                h1420
                            }
                        } {
                            let a1426 = {
                                let m1425 = match v0.clone() {
                                    Adt0::C0(h1424, _, _, _, _, _, _) => {
                                        h1424
                                    }
                                };
                                match m1425 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1423, _, _, _, _, _, _) => {
                                        h1423
                                    }
                                }
                            };
                            bool_not(a1426)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m1430 = {
                        let m1429 = match v0.clone() {
                            Adt0::C0(_, h1428, _, _, _, _, _) => {
                                h1428
                            }
                        };
                        match m1429 {
                            Adt53::C0(h1427, _, _, _, _, _, _, _) => {
                                h1427
                            }
                        }
                    };
                    match m1430 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1434 = {
                        let m1433 = match v0.clone() {
                            Adt0::C0(_, h1432, _, _, _, _, _) => {
                                h1432
                            }
                        };
                        match m1433 {
                            Adt53::C0(_, _, _, h1431, _, _, _, _) => {
                                h1431
                            }
                        }
                    };
                    match m1434 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1435, _) => {
                        h1435
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1436, _) => {
                        h1436
                    }
                }, Adt55::C2))?, {
                    let a1440 = {
                        let m1438 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1437) => {
                                h1437
                            }
                        };
                        match m1438 {
                            None => {
                                false
                            }
                            Some(v122) => {
                                f25(match v122 {
                                    Adt60::C0(h1439, _, _, _, _, _) => {
                                        h1439
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1440) {
                        let m1443 = match v0.clone() {
                            Adt0::C0(h1442, _, _, _, _, _, _) => {
                                h1442
                            }
                        };
                        if match m1443 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1441, _, _, _, _, _, _, _) => {
                                h1441
                            }
                        } {
                            let a1447 = {
                                let m1446 = match v0.clone() {
                                    Adt0::C0(h1445, _, _, _, _, _, _) => {
                                        h1445
                                    }
                                };
                                match m1446 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1444, _, _, _, _, _, _) => {
                                        h1444
                                    }
                                }
                            };
                            bool_not(a1447)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1449 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1448) => {
                            h1448
                        }
                    };
                    match m1449 {
                        None => {
                            false
                        }
                        Some(v123) => {
                            f25(match v123 {
                                Adt60::C0(h1450, _, _, _, _, _) => {
                                    h1450
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a1454 = {
                        let m1452 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1451) => {
                                h1451
                            }
                        };
                        match m1452 {
                            None => {
                                false
                            }
                            Some(v124) => {
                                f25(match v124 {
                                    Adt60::C0(h1453, _, _, _, _, _) => {
                                        h1453
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1454) {
                        let m1457 = match v0.clone() {
                            Adt0::C0(h1456, _, _, _, _, _, _) => {
                                h1456
                            }
                        };
                        if match m1457 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1455, _, _, _, _, _, _, _) => {
                                h1455
                            }
                        } {
                            let a1461 = {
                                let m1460 = match v0 {
                                    Adt0::C0(h1459, _, _, _, _, _, _) => {
                                        h1459
                                    }
                                };
                                match m1460 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1458, _, _, _, _, _, _) => {
                                        h1458
                                    }
                                }
                            };
                            bool_not(a1461)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C1, Str::lit("Archive"), f7(v0.clone(), Adt64::C1(Adt55::C1)), false, {
                    let m1465 = {
                        let m1464 = match v0.clone() {
                            Adt0::C0(_, h1463, _, _, _, _, _) => {
                                h1463
                            }
                        };
                        match m1464 {
                            Adt53::C0(h1462, _, _, _, _, _, _, _) => {
                                h1462
                            }
                        }
                    };
                    match m1465 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            true
                        }
                        Adt54::C3 => {
                            true
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1469 = {
                        let m1468 = match v0.clone() {
                            Adt0::C0(_, h1467, _, _, _, _, _) => {
                                h1467
                            }
                        };
                        match m1468 {
                            Adt53::C0(_, _, h1466, _, _, _, _, _) => {
                                h1466
                            }
                        }
                    };
                    match m1469 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C1), f22(v0.clone(), Adt55::C1, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1470, _) => {
                        h1470
                    }
                }, Adt55::C1), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1471, _) => {
                        h1471
                    }
                }, Adt55::C1))?, {
                    let a1475 = {
                        let m1473 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1472) => {
                                h1472
                            }
                        };
                        match m1473 {
                            None => {
                                false
                            }
                            Some(v126) => {
                                f25(match v126 {
                                    Adt60::C0(h1474, _, _, _, _, _) => {
                                        h1474
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a1475) {
                        let m1478 = match v0.clone() {
                            Adt0::C0(h1477, _, _, _, _, _, _) => {
                                h1477
                            }
                        };
                        if match m1478 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1476, _, _, _, _, _, _, _) => {
                                h1476
                            }
                        } {
                            let a1482 = {
                                let m1481 = match v0.clone() {
                                    Adt0::C0(h1480, _, _, _, _, _, _) => {
                                        h1480
                                    }
                                };
                                match m1481 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1479, _, _, _, _, _, _) => {
                                        h1479
                                    }
                                }
                            };
                            bool_not(a1482)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1484 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1483) => {
                            h1483
                        }
                    };
                    match m1484 {
                        None => {
                            false
                        }
                        Some(v127) => {
                            f25(match v127 {
                                Adt60::C0(h1485, _, _, _, _, _) => {
                                    h1485
                                }
                            }, Adt55::C1)
                        }
                    }
                }, {
                    let a1489 = {
                        let m1487 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1486) => {
                                h1486
                            }
                        };
                        match m1487 {
                            None => {
                                false
                            }
                            Some(v128) => {
                                f25(match v128 {
                                    Adt60::C0(h1488, _, _, _, _, _) => {
                                        h1488
                                    }
                                }, Adt55::C1)
                            }
                        }
                    };
                    if bool_not(a1489) {
                        let m1492 = match v0.clone() {
                            Adt0::C0(h1491, _, _, _, _, _, _) => {
                                h1491
                            }
                        };
                        if match m1492 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1490, _, _, _, _, _, _, _) => {
                                h1490
                            }
                        } {
                            let a1496 = {
                                let m1495 = match v0.clone() {
                                    Adt0::C0(h1494, _, _, _, _, _, _) => {
                                        h1494
                                    }
                                };
                                match m1495 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1493, _, _, _, _, _, _) => {
                                        h1493
                                    }
                                }
                            };
                            bool_not(a1496)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C5, Str::lit("Second archive"), f7(v0.clone(), Adt64::C1(Adt55::C5)), false, {
                    let m1500 = {
                        let m1499 = match v0.clone() {
                            Adt0::C0(_, h1498, _, _, _, _, _) => {
                                h1498
                            }
                        };
                        match m1499 {
                            Adt53::C0(h1497, _, _, _, _, _, _, _) => {
                                h1497
                            }
                        }
                    };
                    match m1500 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            true
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1504 = {
                        let m1503 = match v0.clone() {
                            Adt0::C0(_, h1502, _, _, _, _, _) => {
                                h1502
                            }
                        };
                        match m1503 {
                            Adt53::C0(_, _, _, _, _, _, h1501, _) => {
                                h1501
                            }
                        }
                    };
                    match m1504 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C5), f22(v0.clone(), Adt55::C5, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1505, _) => {
                        h1505
                    }
                }, Adt55::C5), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1506, _) => {
                        h1506
                    }
                }, Adt55::C5))?, {
                    let a1510 = {
                        let m1508 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1507) => {
                                h1507
                            }
                        };
                        match m1508 {
                            None => {
                                false
                            }
                            Some(v130) => {
                                f25(match v130 {
                                    Adt60::C0(h1509, _, _, _, _, _) => {
                                        h1509
                                    }
                                }, Adt55::C5)
                            }
                        }
                    };
                    if bool_not(a1510) {
                        let m1513 = match v0.clone() {
                            Adt0::C0(h1512, _, _, _, _, _, _) => {
                                h1512
                            }
                        };
                        if match m1513 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1511, _, _, _, _, _, _, _) => {
                                h1511
                            }
                        } {
                            let a1517 = {
                                let m1516 = match v0.clone() {
                                    Adt0::C0(h1515, _, _, _, _, _, _) => {
                                        h1515
                                    }
                                };
                                match m1516 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1514, _, _, _, _, _, _) => {
                                        h1514
                                    }
                                }
                            };
                            bool_not(a1517)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1519 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1518) => {
                            h1518
                        }
                    };
                    match m1519 {
                        None => {
                            false
                        }
                        Some(v131) => {
                            f25(match v131 {
                                Adt60::C0(h1520, _, _, _, _, _) => {
                                    h1520
                                }
                            }, Adt55::C5)
                        }
                    }
                }, {
                    let a1524 = {
                        let m1522 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1521) => {
                                h1521
                            }
                        };
                        match m1522 {
                            None => {
                                false
                            }
                            Some(v132) => {
                                f25(match v132 {
                                    Adt60::C0(h1523, _, _, _, _, _) => {
                                        h1523
                                    }
                                }, Adt55::C5)
                            }
                        }
                    };
                    if bool_not(a1524) {
                        let m1527 = match v0.clone() {
                            Adt0::C0(h1526, _, _, _, _, _, _) => {
                                h1526
                            }
                        };
                        if match m1527 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1525, _, _, _, _, _, _, _) => {
                                h1525
                            }
                        } {
                            let a1531 = {
                                let m1530 = match v0.clone() {
                                    Adt0::C0(h1529, _, _, _, _, _, _) => {
                                        h1529
                                    }
                                };
                                match m1530 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1528, _, _, _, _, _, _) => {
                                        h1528
                                    }
                                }
                            };
                            bool_not(a1531)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C3, Str::lit("Original objects for byte comparison (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C3)), true, {
                    let m1535 = {
                        let m1534 = match v0.clone() {
                            Adt0::C0(_, h1533, _, _, _, _, _) => {
                                h1533
                            }
                        };
                        match m1534 {
                            Adt53::C0(h1532, _, _, _, _, _, _, _) => {
                                h1532
                            }
                        }
                    };
                    match m1535 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1539 = {
                        let m1538 = match v0.clone() {
                            Adt0::C0(_, h1537, _, _, _, _, _) => {
                                h1537
                            }
                        };
                        match m1538 {
                            Adt53::C0(_, _, _, _, h1536, _, _, _) => {
                                h1536
                            }
                        }
                    };
                    match m1539 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C3), f22(v0.clone(), Adt55::C3, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1540, _) => {
                        h1540
                    }
                }, Adt55::C3), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1541, _) => {
                        h1541
                    }
                }, Adt55::C3))?, {
                    let a1545 = {
                        let m1543 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1542) => {
                                h1542
                            }
                        };
                        match m1543 {
                            None => {
                                false
                            }
                            Some(v134) => {
                                f25(match v134 {
                                    Adt60::C0(h1544, _, _, _, _, _) => {
                                        h1544
                                    }
                                }, Adt55::C3)
                            }
                        }
                    };
                    if bool_not(a1545) {
                        let m1548 = match v0.clone() {
                            Adt0::C0(h1547, _, _, _, _, _, _) => {
                                h1547
                            }
                        };
                        if match m1548 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1546, _, _, _, _, _, _, _) => {
                                h1546
                            }
                        } {
                            let a1552 = {
                                let m1551 = match v0.clone() {
                                    Adt0::C0(h1550, _, _, _, _, _, _) => {
                                        h1550
                                    }
                                };
                                match m1551 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1549, _, _, _, _, _, _) => {
                                        h1549
                                    }
                                }
                            };
                            bool_not(a1552)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1554 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1553) => {
                            h1553
                        }
                    };
                    match m1554 {
                        None => {
                            false
                        }
                        Some(v135) => {
                            f25(match v135 {
                                Adt60::C0(h1555, _, _, _, _, _) => {
                                    h1555
                                }
                            }, Adt55::C3)
                        }
                    }
                }, {
                    let a1559 = {
                        let m1557 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1556) => {
                                h1556
                            }
                        };
                        match m1557 {
                            None => {
                                false
                            }
                            Some(v136) => {
                                f25(match v136 {
                                    Adt60::C0(h1558, _, _, _, _, _) => {
                                        h1558
                                    }
                                }, Adt55::C3)
                            }
                        }
                    };
                    if bool_not(a1559) {
                        let m1562 = match v0.clone() {
                            Adt0::C0(h1561, _, _, _, _, _, _) => {
                                h1561
                            }
                        };
                        if match m1562 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1560, _, _, _, _, _, _, _) => {
                                h1560
                            }
                        } {
                            let a1566 = {
                                let m1565 = match v0 {
                                    Adt0::C0(h1564, _, _, _, _, _, _) => {
                                        h1564
                                    }
                                };
                                match m1565 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1563, _, _, _, _, _, _) => {
                                        h1563
                                    }
                                }
                            };
                            bool_not(a1566)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))))
            }
        }
        Adt54::C8 => {
            let m1570 = {
                let m1569 = match v0.clone() {
                    Adt0::C0(h1568, _, _, _, _, _, _) => {
                        h1568
                    }
                };
                match m1569 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1567, _, _, _, _, _) => {
                        h1567
                    }
                }
            };
            if if match m1570 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m1574 = {
                        let m1573 = match v0.clone() {
                            Adt0::C0(_, h1572, _, _, _, _, _) => {
                                h1572
                            }
                        };
                        match m1573 {
                            Adt53::C0(h1571, _, _, _, _, _, _, _) => {
                                h1571
                            }
                        }
                    };
                    match m1574 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m1578 = {
                        let m1577 = match v0.clone() {
                            Adt0::C0(_, h1576, _, _, _, _, _) => {
                                h1576
                            }
                        };
                        match m1577 {
                            Adt53::C0(_, h1575, _, _, _, _, _, _) => {
                                h1575
                            }
                        }
                    };
                    match m1578 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1579, _) => {
                        h1579
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1580, _) => {
                        h1580
                    }
                }, Adt55::C0))?, {
                    let a1584 = {
                        let m1582 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1581) => {
                                h1581
                            }
                        };
                        match m1582 {
                            None => {
                                false
                            }
                            Some(v138) => {
                                f25(match v138 {
                                    Adt60::C0(h1583, _, _, _, _, _) => {
                                        h1583
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1584) {
                        let m1587 = match v0.clone() {
                            Adt0::C0(h1586, _, _, _, _, _, _) => {
                                h1586
                            }
                        };
                        if match m1587 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1585, _, _, _, _, _, _, _) => {
                                h1585
                            }
                        } {
                            let a1591 = {
                                let m1590 = match v0.clone() {
                                    Adt0::C0(h1589, _, _, _, _, _, _) => {
                                        h1589
                                    }
                                };
                                match m1590 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1588, _, _, _, _, _, _) => {
                                        h1588
                                    }
                                }
                            };
                            bool_not(a1591)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1593 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1592) => {
                            h1592
                        }
                    };
                    match m1593 {
                        None => {
                            false
                        }
                        Some(v139) => {
                            f25(match v139 {
                                Adt60::C0(h1594, _, _, _, _, _) => {
                                    h1594
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a1598 = {
                        let m1596 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1595) => {
                                h1595
                            }
                        };
                        match m1596 {
                            None => {
                                false
                            }
                            Some(v140) => {
                                f25(match v140 {
                                    Adt60::C0(h1597, _, _, _, _, _) => {
                                        h1597
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1598) {
                        let m1601 = match v0.clone() {
                            Adt0::C0(h1600, _, _, _, _, _, _) => {
                                h1600
                            }
                        };
                        if match m1601 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1599, _, _, _, _, _, _, _) => {
                                h1599
                            }
                        } {
                            let a1605 = {
                                let m1604 = match v0.clone() {
                                    Adt0::C0(h1603, _, _, _, _, _, _) => {
                                        h1603
                                    }
                                };
                                match m1604 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1602, _, _, _, _, _, _) => {
                                        h1602
                                    }
                                }
                            };
                            bool_not(a1605)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m1609 = {
                        let m1608 = match v0.clone() {
                            Adt0::C0(_, h1607, _, _, _, _, _) => {
                                h1607
                            }
                        };
                        match m1608 {
                            Adt53::C0(h1606, _, _, _, _, _, _, _) => {
                                h1606
                            }
                        }
                    };
                    match m1609 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1613 = {
                        let m1612 = match v0.clone() {
                            Adt0::C0(_, h1611, _, _, _, _, _) => {
                                h1611
                            }
                        };
                        match m1612 {
                            Adt53::C0(_, _, _, h1610, _, _, _, _) => {
                                h1610
                            }
                        }
                    };
                    match m1613 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1614, _) => {
                        h1614
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1615, _) => {
                        h1615
                    }
                }, Adt55::C2))?, {
                    let a1619 = {
                        let m1617 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1616) => {
                                h1616
                            }
                        };
                        match m1617 {
                            None => {
                                false
                            }
                            Some(v142) => {
                                f25(match v142 {
                                    Adt60::C0(h1618, _, _, _, _, _) => {
                                        h1618
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1619) {
                        let m1622 = match v0.clone() {
                            Adt0::C0(h1621, _, _, _, _, _, _) => {
                                h1621
                            }
                        };
                        if match m1622 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1620, _, _, _, _, _, _, _) => {
                                h1620
                            }
                        } {
                            let a1626 = {
                                let m1625 = match v0.clone() {
                                    Adt0::C0(h1624, _, _, _, _, _, _) => {
                                        h1624
                                    }
                                };
                                match m1625 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1623, _, _, _, _, _, _) => {
                                        h1623
                                    }
                                }
                            };
                            bool_not(a1626)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1628 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1627) => {
                            h1627
                        }
                    };
                    match m1628 {
                        None => {
                            false
                        }
                        Some(v143) => {
                            f25(match v143 {
                                Adt60::C0(h1629, _, _, _, _, _) => {
                                    h1629
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a1633 = {
                        let m1631 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1630) => {
                                h1630
                            }
                        };
                        match m1631 {
                            None => {
                                false
                            }
                            Some(v144) => {
                                f25(match v144 {
                                    Adt60::C0(h1632, _, _, _, _, _) => {
                                        h1632
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1633) {
                        let m1636 = match v0.clone() {
                            Adt0::C0(h1635, _, _, _, _, _, _) => {
                                h1635
                            }
                        };
                        if match m1636 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1634, _, _, _, _, _, _, _) => {
                                h1634
                            }
                        } {
                            let a1640 = {
                                let m1639 = match v0 {
                                    Adt0::C0(h1638, _, _, _, _, _, _) => {
                                        h1638
                                    }
                                };
                                match m1639 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1637, _, _, _, _, _, _) => {
                                        h1637
                                    }
                                }
                            };
                            bool_not(a1640)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m1644 = {
                        let m1643 = match v0.clone() {
                            Adt0::C0(_, h1642, _, _, _, _, _) => {
                                h1642
                            }
                        };
                        match m1643 {
                            Adt53::C0(h1641, _, _, _, _, _, _, _) => {
                                h1641
                            }
                        }
                    };
                    match m1644 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m1648 = {
                        let m1647 = match v0.clone() {
                            Adt0::C0(_, h1646, _, _, _, _, _) => {
                                h1646
                            }
                        };
                        match m1647 {
                            Adt53::C0(_, h1645, _, _, _, _, _, _) => {
                                h1645
                            }
                        }
                    };
                    match m1648 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1649, _) => {
                        h1649
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1650, _) => {
                        h1650
                    }
                }, Adt55::C0))?, {
                    let a1654 = {
                        let m1652 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1651) => {
                                h1651
                            }
                        };
                        match m1652 {
                            None => {
                                false
                            }
                            Some(v146) => {
                                f25(match v146 {
                                    Adt60::C0(h1653, _, _, _, _, _) => {
                                        h1653
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1654) {
                        let m1657 = match v0.clone() {
                            Adt0::C0(h1656, _, _, _, _, _, _) => {
                                h1656
                            }
                        };
                        if match m1657 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1655, _, _, _, _, _, _, _) => {
                                h1655
                            }
                        } {
                            let a1661 = {
                                let m1660 = match v0.clone() {
                                    Adt0::C0(h1659, _, _, _, _, _, _) => {
                                        h1659
                                    }
                                };
                                match m1660 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1658, _, _, _, _, _, _) => {
                                        h1658
                                    }
                                }
                            };
                            bool_not(a1661)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1663 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1662) => {
                            h1662
                        }
                    };
                    match m1663 {
                        None => {
                            false
                        }
                        Some(v147) => {
                            f25(match v147 {
                                Adt60::C0(h1664, _, _, _, _, _) => {
                                    h1664
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a1668 = {
                        let m1666 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1665) => {
                                h1665
                            }
                        };
                        match m1666 {
                            None => {
                                false
                            }
                            Some(v148) => {
                                f25(match v148 {
                                    Adt60::C0(h1667, _, _, _, _, _) => {
                                        h1667
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1668) {
                        let m1671 = match v0.clone() {
                            Adt0::C0(h1670, _, _, _, _, _, _) => {
                                h1670
                            }
                        };
                        if match m1671 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1669, _, _, _, _, _, _, _) => {
                                h1669
                            }
                        } {
                            let a1675 = {
                                let m1674 = match v0 {
                                    Adt0::C0(h1673, _, _, _, _, _, _) => {
                                        h1673
                                    }
                                };
                                match m1674 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1672, _, _, _, _, _, _) => {
                                        h1672
                                    }
                                }
                            };
                            bool_not(a1675)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))
            }
        }
        Adt54::C9 => {
            let m1679 = {
                let m1678 = match v0.clone() {
                    Adt0::C0(h1677, _, _, _, _, _, _) => {
                        h1677
                    }
                };
                match m1678 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1676, _, _, _, _, _) => {
                        h1676
                    }
                }
            };
            if if match m1679 {
                Adt48::C0 => {
                    false
                }
                Adt48::C1 => {
                    true
                }
                Adt48::C2 => {
                    false
                }
                Adt48::C3 => {
                    false
                }
            } {
                true
            } else {
                f20(v0.clone())
            } {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m1683 = {
                        let m1682 = match v0.clone() {
                            Adt0::C0(_, h1681, _, _, _, _, _) => {
                                h1681
                            }
                        };
                        match m1682 {
                            Adt53::C0(h1680, _, _, _, _, _, _, _) => {
                                h1680
                            }
                        }
                    };
                    match m1683 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m1687 = {
                        let m1686 = match v0.clone() {
                            Adt0::C0(_, h1685, _, _, _, _, _) => {
                                h1685
                            }
                        };
                        match m1686 {
                            Adt53::C0(_, h1684, _, _, _, _, _, _) => {
                                h1684
                            }
                        }
                    };
                    match m1687 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1688, _) => {
                        h1688
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1689, _) => {
                        h1689
                    }
                }, Adt55::C0))?, {
                    let a1693 = {
                        let m1691 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1690) => {
                                h1690
                            }
                        };
                        match m1691 {
                            None => {
                                false
                            }
                            Some(v150) => {
                                f25(match v150 {
                                    Adt60::C0(h1692, _, _, _, _, _) => {
                                        h1692
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1693) {
                        let m1696 = match v0.clone() {
                            Adt0::C0(h1695, _, _, _, _, _, _) => {
                                h1695
                            }
                        };
                        if match m1696 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1694, _, _, _, _, _, _, _) => {
                                h1694
                            }
                        } {
                            let a1700 = {
                                let m1699 = match v0.clone() {
                                    Adt0::C0(h1698, _, _, _, _, _, _) => {
                                        h1698
                                    }
                                };
                                match m1699 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1697, _, _, _, _, _, _) => {
                                        h1697
                                    }
                                }
                            };
                            bool_not(a1700)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1702 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1701) => {
                            h1701
                        }
                    };
                    match m1702 {
                        None => {
                            false
                        }
                        Some(v151) => {
                            f25(match v151 {
                                Adt60::C0(h1703, _, _, _, _, _) => {
                                    h1703
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a1707 = {
                        let m1705 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1704) => {
                                h1704
                            }
                        };
                        match m1705 {
                            None => {
                                false
                            }
                            Some(v152) => {
                                f25(match v152 {
                                    Adt60::C0(h1706, _, _, _, _, _) => {
                                        h1706
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1707) {
                        let m1710 = match v0.clone() {
                            Adt0::C0(h1709, _, _, _, _, _, _) => {
                                h1709
                            }
                        };
                        if match m1710 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1708, _, _, _, _, _, _, _) => {
                                h1708
                            }
                        } {
                            let a1714 = {
                                let m1713 = match v0.clone() {
                                    Adt0::C0(h1712, _, _, _, _, _, _) => {
                                        h1712
                                    }
                                };
                                match m1713 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1711, _, _, _, _, _, _) => {
                                        h1711
                                    }
                                }
                            };
                            bool_not(a1714)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::cons(Adt66::C0(Adt55::C2, Str::lit("External basis bytes (optional)"), f7(v0.clone(), Adt64::C1(Adt55::C2)), false, {
                    let m1718 = {
                        let m1717 = match v0.clone() {
                            Adt0::C0(_, h1716, _, _, _, _, _) => {
                                h1716
                            }
                        };
                        match m1717 {
                            Adt53::C0(h1715, _, _, _, _, _, _, _) => {
                                h1715
                            }
                        }
                    };
                    match m1718 {
                        Adt54::C0 => {
                            false
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            false
                        }
                        Adt54::C5 => {
                            false
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                }, {
                    let m1722 = {
                        let m1721 = match v0.clone() {
                            Adt0::C0(_, h1720, _, _, _, _, _) => {
                                h1720
                            }
                        };
                        match m1721 {
                            Adt53::C0(_, _, _, h1719, _, _, _, _) => {
                                h1719
                            }
                        }
                    };
                    match m1722 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C2), f22(v0.clone(), Adt55::C2, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1723, _) => {
                        h1723
                    }
                }, Adt55::C2), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1724, _) => {
                        h1724
                    }
                }, Adt55::C2))?, {
                    let a1728 = {
                        let m1726 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1725) => {
                                h1725
                            }
                        };
                        match m1726 {
                            None => {
                                false
                            }
                            Some(v154) => {
                                f25(match v154 {
                                    Adt60::C0(h1727, _, _, _, _, _) => {
                                        h1727
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1728) {
                        let m1731 = match v0.clone() {
                            Adt0::C0(h1730, _, _, _, _, _, _) => {
                                h1730
                            }
                        };
                        if match m1731 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1729, _, _, _, _, _, _, _) => {
                                h1729
                            }
                        } {
                            let a1735 = {
                                let m1734 = match v0.clone() {
                                    Adt0::C0(h1733, _, _, _, _, _, _) => {
                                        h1733
                                    }
                                };
                                match m1734 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1732, _, _, _, _, _, _) => {
                                        h1732
                                    }
                                }
                            };
                            bool_not(a1735)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1737 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1736) => {
                            h1736
                        }
                    };
                    match m1737 {
                        None => {
                            false
                        }
                        Some(v155) => {
                            f25(match v155 {
                                Adt60::C0(h1738, _, _, _, _, _) => {
                                    h1738
                                }
                            }, Adt55::C2)
                        }
                    }
                }, {
                    let a1742 = {
                        let m1740 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1739) => {
                                h1739
                            }
                        };
                        match m1740 {
                            None => {
                                false
                            }
                            Some(v156) => {
                                f25(match v156 {
                                    Adt60::C0(h1741, _, _, _, _, _) => {
                                        h1741
                                    }
                                }, Adt55::C2)
                            }
                        }
                    };
                    if bool_not(a1742) {
                        let m1745 = match v0.clone() {
                            Adt0::C0(h1744, _, _, _, _, _, _) => {
                                h1744
                            }
                        };
                        if match m1745 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1743, _, _, _, _, _, _, _) => {
                                h1743
                            }
                        } {
                            let a1749 = {
                                let m1748 = match v0 {
                                    Adt0::C0(h1747, _, _, _, _, _, _) => {
                                        h1747
                                    }
                                };
                                match m1748 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1746, _, _, _, _, _, _) => {
                                        h1746
                                    }
                                }
                            };
                            bool_not(a1749)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil())))
            } else {
                Ok(List::cons(Adt66::C0(Adt55::C0, Str::lit("Input objects in order"), f7(v0.clone(), Adt64::C1(Adt55::C0)), true, {
                    let m1753 = {
                        let m1752 = match v0.clone() {
                            Adt0::C0(_, h1751, _, _, _, _, _) => {
                                h1751
                            }
                        };
                        match m1752 {
                            Adt53::C0(h1750, _, _, _, _, _, _, _) => {
                                h1750
                            }
                        }
                    };
                    match m1753 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            false
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            true
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            true
                        }
                        Adt54::C9 => {
                            true
                        }
                    }
                }, {
                    let m1757 = {
                        let m1756 = match v0.clone() {
                            Adt0::C0(_, h1755, _, _, _, _, _) => {
                                h1755
                            }
                        };
                        match m1756 {
                            Adt53::C0(_, h1754, _, _, _, _, _, _) => {
                                h1754
                            }
                        }
                    };
                    match m1757 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    }
                }, true, f21(Adt55::C0), f22(v0.clone(), Adt55::C0, f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1758, _) => {
                        h1758
                    }
                }, Adt55::C0), 0u64, f24(f23(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1759, _) => {
                        h1759
                    }
                }, Adt55::C0))?, {
                    let a1763 = {
                        let m1761 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1760) => {
                                h1760
                            }
                        };
                        match m1761 {
                            None => {
                                false
                            }
                            Some(v158) => {
                                f25(match v158 {
                                    Adt60::C0(h1762, _, _, _, _, _) => {
                                        h1762
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1763) {
                        let m1766 = match v0.clone() {
                            Adt0::C0(h1765, _, _, _, _, _, _) => {
                                h1765
                            }
                        };
                        if match m1766 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1764, _, _, _, _, _, _, _) => {
                                h1764
                            }
                        } {
                            let a1770 = {
                                let m1769 = match v0.clone() {
                                    Adt0::C0(h1768, _, _, _, _, _, _) => {
                                        h1768
                                    }
                                };
                                match m1769 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1767, _, _, _, _, _, _) => {
                                        h1767
                                    }
                                }
                            };
                            bool_not(a1770)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                })?, {
                    let m1772 = match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h1771) => {
                            h1771
                        }
                    };
                    match m1772 {
                        None => {
                            false
                        }
                        Some(v159) => {
                            f25(match v159 {
                                Adt60::C0(h1773, _, _, _, _, _) => {
                                    h1773
                                }
                            }, Adt55::C0)
                        }
                    }
                }, {
                    let a1777 = {
                        let m1775 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1774) => {
                                h1774
                            }
                        };
                        match m1775 {
                            None => {
                                false
                            }
                            Some(v160) => {
                                f25(match v160 {
                                    Adt60::C0(h1776, _, _, _, _, _) => {
                                        h1776
                                    }
                                }, Adt55::C0)
                            }
                        }
                    };
                    if bool_not(a1777) {
                        let m1780 = match v0.clone() {
                            Adt0::C0(h1779, _, _, _, _, _, _) => {
                                h1779
                            }
                        };
                        if match m1780 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1778, _, _, _, _, _, _, _) => {
                                h1778
                            }
                        } {
                            let a1784 = {
                                let m1783 = match v0 {
                                    Adt0::C0(h1782, _, _, _, _, _, _) => {
                                        h1782
                                    }
                                };
                                match m1783 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1781, _, _, _, _, _, _) => {
                                        h1781
                                    }
                                }
                            };
                            bool_not(a1784)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }), List::<Adt66>::nil()))
            }
        }
    }
}

pub fn f11(v0: Adt22) -> List<Adt68> {
    List::cons(Adt68::C0(Str::lit("Input bytes"), {
        let m1787 = match v0.clone() {
            Adt22::C0(h1786, _, _, _, _, _, _, _, _, _) => {
                h1786
            }
        };
        match m1787 {
            Adt23::C0(h1785, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1785
            }
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Exact archive bytes"), {
        let m1790 = match v0.clone() {
            Adt22::C0(h1789, _, _, _, _, _, _, _, _, _) => {
                h1789
            }
        };
        match m1790 {
            Adt23::C0(_, h1788, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1788
            }
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Transport bytes"), {
        let m1793 = match v0.clone() {
            Adt22::C0(h1792, _, _, _, _, _, _, _, _, _) => {
                h1792
            }
        };
        match m1793 {
            Adt23::C0(_, _, h1791, _, _, _, _, _, _, _, _, _, _, _) => {
                h1791
            }
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("External basis bytes"), {
        let m1796 = match v0.clone() {
            Adt22::C0(h1795, _, _, _, _, _, _, _, _, _) => {
                h1795
            }
        };
        match m1796 {
            Adt23::C0(_, _, _, h1794, _, _, _, _, _, _, _, _, _, _) => {
                h1794
            }
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Basis transfer bytes"), {
        let m1799 = match v0.clone() {
            Adt22::C0(h1798, _, _, _, _, _, _, _, _, _) => {
                h1798
            }
        };
        match m1799 {
            Adt23::C0(_, _, _, _, h1797, _, _, _, _, _, _, _, _, _) => {
                h1797
            }
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Output bytes"), {
        let m1802 = match v0.clone() {
            Adt22::C0(h1801, _, _, _, _, _, _, _, _, _) => {
                h1801
            }
        };
        match m1802 {
            Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, h1800, _, _) => {
                h1800
            }
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Ordered objects"), {
        let m1805 = match v0.clone() {
            Adt22::C0(h1804, _, _, _, _, _, _, _, _, _) => {
                h1804
            }
        };
        match m1805 {
            Adt23::C0(_, _, _, _, _, _, _, _, _, _, h1803, _, _, _) => {
                h1803
            }
        }
    }, Str::lit("objects")), List::cons(Adt68::C0(Str::lit("Decode work"), {
        let m1808 = match v0.clone() {
            Adt22::C0(h1807, _, _, _, _, _, _, _, _, _) => {
                h1807
            }
        };
        match m1808 {
            Adt23::C0(_, _, _, _, _, h1806, _, _, _, _, _, _, _, _) => {
                h1806
            }
        }
    }, Str::lit("work units")), List::cons(Adt68::C0(Str::lit("Checker work"), {
        let m1811 = match v0.clone() {
            Adt22::C0(h1810, _, _, _, _, _, _, _, _, _) => {
                h1810
            }
        };
        match m1811 {
            Adt23::C0(_, _, _, _, _, _, h1809, _, _, _, _, _, _, _) => {
                h1809
            }
        }
    }, Str::lit("work units")), List::cons(Adt68::C0(Str::lit("Replay work"), {
        let m1814 = match v0.clone() {
            Adt22::C0(h1813, _, _, _, _, _, _, _, _, _) => {
                h1813
            }
        };
        match m1814 {
            Adt23::C0(_, _, _, _, _, _, _, h1812, _, _, _, _, _, _) => {
                h1812
            }
        }
    }, Str::lit("work units")), List::cons(Adt68::C0(Str::lit("Search work"), {
        let m1817 = match v0.clone() {
            Adt22::C0(h1816, _, _, _, _, _, _, _, _, _) => {
                h1816
            }
        };
        match m1817 {
            Adt23::C0(_, _, _, _, _, _, _, _, h1815, _, _, _, _, _) => {
                h1815
            }
        }
    }, Str::lit("work units")), List::cons(Adt68::C0(Str::lit("Peak logical arena bytes"), {
        let m1820 = match v0 {
            Adt22::C0(h1819, _, _, _, _, _, _, _, _, _) => {
                h1819
            }
        };
        match m1820 {
            Adt23::C0(_, _, _, _, _, _, _, _, _, h1818, _, _, _, _) => {
                h1818
            }
        }
    }, Str::lit("bytes")), List::<Adt68>::nil()))))))))))))
}

pub fn f12(v0: Adt23) -> List<Adt68> {
    List::cons(Adt68::C0(Str::lit("Input bytes"), match v0.clone() {
        Adt23::C0(h1821, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1821
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Exact archive bytes"), match v0.clone() {
        Adt23::C0(_, h1822, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1822
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Transport bytes"), match v0.clone() {
        Adt23::C0(_, _, h1823, _, _, _, _, _, _, _, _, _, _, _) => {
            h1823
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("External basis bytes"), match v0.clone() {
        Adt23::C0(_, _, _, h1824, _, _, _, _, _, _, _, _, _, _) => {
            h1824
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Basis transfer bytes"), match v0.clone() {
        Adt23::C0(_, _, _, _, h1825, _, _, _, _, _, _, _, _, _) => {
            h1825
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Output bytes"), match v0.clone() {
        Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, h1826, _, _) => {
            h1826
        }
    }, Str::lit("bytes")), List::cons(Adt68::C0(Str::lit("Ordered objects"), match v0.clone() {
        Adt23::C0(_, _, _, _, _, _, _, _, _, _, h1827, _, _, _) => {
            h1827
        }
    }, Str::lit("objects")), List::cons(Adt68::C0(Str::lit("Decode work"), match v0.clone() {
        Adt23::C0(_, _, _, _, _, h1828, _, _, _, _, _, _, _, _) => {
            h1828
        }
    }, Str::lit("work units")), List::cons(Adt68::C0(Str::lit("Checker work"), match v0.clone() {
        Adt23::C0(_, _, _, _, _, _, h1829, _, _, _, _, _, _, _) => {
            h1829
        }
    }, Str::lit("work units")), List::cons(Adt68::C0(Str::lit("Replay work"), match v0.clone() {
        Adt23::C0(_, _, _, _, _, _, _, h1830, _, _, _, _, _, _) => {
            h1830
        }
    }, Str::lit("work units")), List::cons(Adt68::C0(Str::lit("Search work"), match v0.clone() {
        Adt23::C0(_, _, _, _, _, _, _, _, h1831, _, _, _, _, _) => {
            h1831
        }
    }, Str::lit("work units")), List::cons(Adt68::C0(Str::lit("Peak modeled owned bytes"), match v0 {
        Adt23::C0(_, _, _, _, _, _, _, _, _, h1832, _, _, _, _) => {
            h1832
        }
    }, Str::lit("bytes")), List::<Adt68>::nil()))))))))))))
}

pub fn f13(v0: Adt54, v1: Adt22) -> Adt70 {
    f26(v0, match v1.clone() {
        Adt22::C0(_, _, _, h1833, _, _, _, _, _, _) => {
            h1833
        }
    }, Adt28::C0({
        let m1836 = match v1.clone() {
            Adt22::C0(_, h1835, _, _, _, _, _, _, _, _) => {
                h1835
            }
        };
        match m1836 {
            Adt28::C0(h1834, _, _, _, _) => {
                h1834
            }
        }
    }, {
        let m1839 = match v1.clone() {
            Adt22::C0(_, h1838, _, _, _, _, _, _, _, _) => {
                h1838
            }
        };
        match m1839 {
            Adt28::C0(_, h1837, _, _, _) => {
                h1837
            }
        }
    }, {
        let m1842 = match v1.clone() {
            Adt22::C0(_, h1841, _, _, _, _, _, _, _, _) => {
                h1841
            }
        };
        if match m1842 {
            Adt28::C0(_, _, h1840, _, _) => {
                h1840
            }
        } {
            match v1.clone() {
                Adt22::C0(_, _, h1843, _, _, _, _, _, _, _) => {
                    h1843
                }
            }
        } else {
            false
        }
    }, {
        let m1846 = match v1.clone() {
            Adt22::C0(_, h1845, _, _, _, _, _, _, _, _) => {
                h1845
            }
        };
        if match m1846 {
            Adt28::C0(_, _, _, h1844, _) => {
                h1844
            }
        } {
            let m1848 = match v1.clone() {
                Adt22::C0(_, _, _, _, h1847, _, _, _, _, _) => {
                    h1847
                }
            };
            match m1848 {
                Adt29::C0 => {
                    true
                }
                Adt29::C1 => {
                    false
                }
                Adt29::C2 => {
                    false
                }
                Adt29::C3 => {
                    false
                }
            }
        } else {
            false
        }
    }, {
        let m1851 = match v1.clone() {
            Adt22::C0(_, h1850, _, _, _, _, _, _, _, _) => {
                h1850
            }
        };
        if match m1851 {
            Adt28::C0(_, _, _, _, h1849) => {
                h1849
            }
        } {
            let m1853 = f27(match v1 {
                Adt22::C0(_, _, _, _, _, h1852, _, _, _, _) => {
                    h1852
                }
            });
            match m1853 {
                Adt74::C0 => {
                    false
                }
                Adt74::C1 => {
                    true
                }
                Adt74::C2 => {
                    false
                }
                Adt74::C3 => {
                    false
                }
            }
        } else {
            false
        }
    }))
}

pub fn f14(v0: Adt0) -> List<Adt62> {
    let m1857 = {
        let m1856 = match v0.clone() {
            Adt0::C0(h1855, _, _, _, _, _, _) => {
                h1855
            }
        };
        match m1856 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1854, _, _, _, _, _) => {
                h1854
            }
        }
    };
    match m1857 {
        Adt48::C0 => {
            List::<Adt62>::nil()
        }
        Adt48::C1 => {
            List::<Adt62>::nil()
        }
        Adt48::C2 => {
            List::<Adt62>::nil()
        }
        Adt48::C3 => {
            List::cons(Adt62::C0(Str::lit("runAcceptance"), Str::lit("Run acceptance"), f7(v0.clone(), Adt64::C0(Adt54::C8)), {
                let m1860 = match v0.clone() {
                    Adt0::C0(h1859, _, _, _, _, _, _) => {
                        h1859
                    }
                };
                if match m1860 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1858, _, _, _, _, _, _, _) => {
                        h1858
                    }
                } {
                    let a1864 = {
                        let m1863 = match v0.clone() {
                            Adt0::C0(h1862, _, _, _, _, _, _) => {
                                h1862
                            }
                        };
                        match m1863 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1861, _, _, _, _, _, _) => {
                                h1861
                            }
                        }
                    };
                    bool_not(a1864)
                } else {
                    false
                }
            }, true), List::cons(Adt62::C0(Str::lit("runCoreRequest"), Str::lit("Run core request"), f7(v0.clone(), Adt64::C0(Adt54::C9)), {
                let m1867 = match v0.clone() {
                    Adt0::C0(h1866, _, _, _, _, _, _) => {
                        h1866
                    }
                };
                if match m1867 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1865, _, _, _, _, _, _, _) => {
                        h1865
                    }
                } {
                    let a1871 = {
                        let m1870 = match v0 {
                            Adt0::C0(h1869, _, _, _, _, _, _) => {
                                h1869
                            }
                        };
                        match m1870 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1868, _, _, _, _, _, _) => {
                                h1868
                            }
                        }
                    };
                    bool_not(a1871)
                } else {
                    false
                }
            }, true), List::<Adt62>::nil()))
        }
    }
}

pub fn f15(v0: Adt0) -> R<List<Adt71>> {
    let m1875 = {
        let m1874 = match v0.clone() {
            Adt0::C0(h1873, _, _, _, _, _, _) => {
                h1873
            }
        };
        match m1874 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1872, _, _, _, _, _) => {
                h1872
            }
        }
    };
    match m1875 {
        Adt48::C0 => {
            Ok(List::<Adt71>::nil())
        }
        Adt48::C1 => {
            Ok(List::cons(Adt71::C0(Str::lit("limit-decodeWork"), Str::lit("Decode work quota"), f28(Some({
                let m1880 = {
                    let m1879 = match v0.clone() {
                        Adt0::C0(_, h1878, _, _, _, _, _) => {
                            h1878
                        }
                    };
                    match m1879 {
                        Adt53::C0(_, _, _, _, _, _, _, h1877) => {
                            h1877
                        }
                    }
                };
                match m1880 {
                    Adt13::C0(h1876, _, _, _, _, _, _) => {
                        h1876
                    }
                }
            }))?, Str::lit("work units"), false, {
                let a1899 = {
                    let a1898 = {
                        let m1883 = match v0.clone() {
                            Adt0::C0(h1882, _, _, _, _, _, _) => {
                                h1882
                            }
                        };
                        if match m1883 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1881, _, _, _, _, _, _, _) => {
                                h1881
                            }
                        } {
                            let a1887 = {
                                let m1886 = match v0.clone() {
                                    Adt0::C0(h1885, _, _, _, _, _, _) => {
                                        h1885
                                    }
                                };
                                match m1886 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1884, _, _, _, _, _, _) => {
                                        h1884
                                    }
                                }
                            };
                            if bool_not(a1887) {
                                let a1893 = {
                                    let m1892 = {
                                        let m1891 = match v0.clone() {
                                            Adt0::C0(h1890, _, _, _, _, _, _) => {
                                                h1890
                                            }
                                        };
                                        match m1891 {
                                            Adt1::C0(_, h1889, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1889
                                            }
                                        }
                                    };
                                    match m1892 {
                                        Adt2::C0(_, _, h1888, _, _, _) => {
                                            h1888
                                        }
                                    }
                                };
                                if bool_not(a1893) {
                                    let a1897 = {
                                        let m1896 = match v0.clone() {
                                            Adt0::C0(h1895, _, _, _, _, _, _) => {
                                                h1895
                                            }
                                        };
                                        match m1896 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h1894, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1894
                                            }
                                        }
                                    };
                                    bool_not(a1897)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a1898)
                };
                bool_not(a1899)
            }, f29(v0.clone(), Adt73::C0), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-checkerWork"), Str::lit("Verification work quota"), f28(Some({
                let m1904 = {
                    let m1903 = match v0.clone() {
                        Adt0::C0(_, h1902, _, _, _, _, _) => {
                            h1902
                        }
                    };
                    match m1903 {
                        Adt53::C0(_, _, _, _, _, _, _, h1901) => {
                            h1901
                        }
                    }
                };
                match m1904 {
                    Adt13::C0(_, h1900, _, _, _, _, _) => {
                        h1900
                    }
                }
            }))?, Str::lit("work units"), false, {
                let a1923 = {
                    let a1922 = {
                        let m1907 = match v0.clone() {
                            Adt0::C0(h1906, _, _, _, _, _, _) => {
                                h1906
                            }
                        };
                        if match m1907 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1905, _, _, _, _, _, _, _) => {
                                h1905
                            }
                        } {
                            let a1911 = {
                                let m1910 = match v0.clone() {
                                    Adt0::C0(h1909, _, _, _, _, _, _) => {
                                        h1909
                                    }
                                };
                                match m1910 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1908, _, _, _, _, _, _) => {
                                        h1908
                                    }
                                }
                            };
                            if bool_not(a1911) {
                                let a1917 = {
                                    let m1916 = {
                                        let m1915 = match v0.clone() {
                                            Adt0::C0(h1914, _, _, _, _, _, _) => {
                                                h1914
                                            }
                                        };
                                        match m1915 {
                                            Adt1::C0(_, h1913, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1913
                                            }
                                        }
                                    };
                                    match m1916 {
                                        Adt2::C0(_, _, h1912, _, _, _) => {
                                            h1912
                                        }
                                    }
                                };
                                if bool_not(a1917) {
                                    let a1921 = {
                                        let m1920 = match v0.clone() {
                                            Adt0::C0(h1919, _, _, _, _, _, _) => {
                                                h1919
                                            }
                                        };
                                        match m1920 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h1918, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1918
                                            }
                                        }
                                    };
                                    bool_not(a1921)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a1922)
                };
                bool_not(a1923)
            }, f29(v0.clone(), Adt73::C1), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-replayWork"), Str::lit("Replay work quota"), f28(Some({
                let m1928 = {
                    let m1927 = match v0.clone() {
                        Adt0::C0(_, h1926, _, _, _, _, _) => {
                            h1926
                        }
                    };
                    match m1927 {
                        Adt53::C0(_, _, _, _, _, _, _, h1925) => {
                            h1925
                        }
                    }
                };
                match m1928 {
                    Adt13::C0(_, _, h1924, _, _, _, _) => {
                        h1924
                    }
                }
            }))?, Str::lit("work units"), false, {
                let a1947 = {
                    let a1946 = {
                        let m1931 = match v0.clone() {
                            Adt0::C0(h1930, _, _, _, _, _, _) => {
                                h1930
                            }
                        };
                        if match m1931 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1929, _, _, _, _, _, _, _) => {
                                h1929
                            }
                        } {
                            let a1935 = {
                                let m1934 = match v0.clone() {
                                    Adt0::C0(h1933, _, _, _, _, _, _) => {
                                        h1933
                                    }
                                };
                                match m1934 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1932, _, _, _, _, _, _) => {
                                        h1932
                                    }
                                }
                            };
                            if bool_not(a1935) {
                                let a1941 = {
                                    let m1940 = {
                                        let m1939 = match v0.clone() {
                                            Adt0::C0(h1938, _, _, _, _, _, _) => {
                                                h1938
                                            }
                                        };
                                        match m1939 {
                                            Adt1::C0(_, h1937, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1937
                                            }
                                        }
                                    };
                                    match m1940 {
                                        Adt2::C0(_, _, h1936, _, _, _) => {
                                            h1936
                                        }
                                    }
                                };
                                if bool_not(a1941) {
                                    let a1945 = {
                                        let m1944 = match v0.clone() {
                                            Adt0::C0(h1943, _, _, _, _, _, _) => {
                                                h1943
                                            }
                                        };
                                        match m1944 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h1942, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1942
                                            }
                                        }
                                    };
                                    bool_not(a1945)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a1946)
                };
                bool_not(a1947)
            }, f29(v0.clone(), Adt73::C2), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-searchWork"), Str::lit("Search effort"), f28(Some({
                let m1952 = {
                    let m1951 = match v0.clone() {
                        Adt0::C0(_, h1950, _, _, _, _, _) => {
                            h1950
                        }
                    };
                    match m1951 {
                        Adt53::C0(_, _, _, _, _, _, _, h1949) => {
                            h1949
                        }
                    }
                };
                match m1952 {
                    Adt13::C0(_, _, _, h1948, _, _, _) => {
                        h1948
                    }
                }
            }))?, Str::lit("work units"), false, {
                let a1971 = {
                    let a1970 = {
                        let m1955 = match v0.clone() {
                            Adt0::C0(h1954, _, _, _, _, _, _) => {
                                h1954
                            }
                        };
                        if match m1955 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1953, _, _, _, _, _, _, _) => {
                                h1953
                            }
                        } {
                            let a1959 = {
                                let m1958 = match v0.clone() {
                                    Adt0::C0(h1957, _, _, _, _, _, _) => {
                                        h1957
                                    }
                                };
                                match m1958 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1956, _, _, _, _, _, _) => {
                                        h1956
                                    }
                                }
                            };
                            if bool_not(a1959) {
                                let a1965 = {
                                    let m1964 = {
                                        let m1963 = match v0.clone() {
                                            Adt0::C0(h1962, _, _, _, _, _, _) => {
                                                h1962
                                            }
                                        };
                                        match m1963 {
                                            Adt1::C0(_, h1961, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1961
                                            }
                                        }
                                    };
                                    match m1964 {
                                        Adt2::C0(_, _, h1960, _, _, _) => {
                                            h1960
                                        }
                                    }
                                };
                                if bool_not(a1965) {
                                    let a1969 = {
                                        let m1968 = match v0.clone() {
                                            Adt0::C0(h1967, _, _, _, _, _, _) => {
                                                h1967
                                            }
                                        };
                                        match m1968 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h1966, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1966
                                            }
                                        }
                                    };
                                    bool_not(a1969)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a1970)
                };
                bool_not(a1971)
            }, f29(v0.clone(), Adt73::C3), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-outputBytes"), Str::lit("Output bytes quota"), f28({
                let m1976 = {
                    let m1975 = match v0.clone() {
                        Adt0::C0(_, h1974, _, _, _, _, _) => {
                            h1974
                        }
                    };
                    match m1975 {
                        Adt53::C0(_, _, _, _, _, _, _, h1973) => {
                            h1973
                        }
                    }
                };
                match m1976 {
                    Adt13::C0(_, _, _, _, h1972, _, _) => {
                        h1972
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a1995 = {
                    let a1994 = {
                        let m1979 = match v0.clone() {
                            Adt0::C0(h1978, _, _, _, _, _, _) => {
                                h1978
                            }
                        };
                        if match m1979 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1977, _, _, _, _, _, _, _) => {
                                h1977
                            }
                        } {
                            let a1983 = {
                                let m1982 = match v0.clone() {
                                    Adt0::C0(h1981, _, _, _, _, _, _) => {
                                        h1981
                                    }
                                };
                                match m1982 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1980, _, _, _, _, _, _) => {
                                        h1980
                                    }
                                }
                            };
                            if bool_not(a1983) {
                                let a1989 = {
                                    let m1988 = {
                                        let m1987 = match v0.clone() {
                                            Adt0::C0(h1986, _, _, _, _, _, _) => {
                                                h1986
                                            }
                                        };
                                        match m1987 {
                                            Adt1::C0(_, h1985, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1985
                                            }
                                        }
                                    };
                                    match m1988 {
                                        Adt2::C0(_, _, h1984, _, _, _) => {
                                            h1984
                                        }
                                    }
                                };
                                if bool_not(a1989) {
                                    let a1993 = {
                                        let m1992 = match v0.clone() {
                                            Adt0::C0(h1991, _, _, _, _, _, _) => {
                                                h1991
                                            }
                                        };
                                        match m1992 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h1990, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h1990
                                            }
                                        }
                                    };
                                    bool_not(a1993)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a1994)
                };
                bool_not(a1995)
            }, f29(v0.clone(), Adt73::C4), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-ownedBytes"), Str::lit("Logical retained arena bytes quota"), f28(Some({
                let m2000 = {
                    let m1999 = match v0.clone() {
                        Adt0::C0(_, h1998, _, _, _, _, _) => {
                            h1998
                        }
                    };
                    match m1999 {
                        Adt53::C0(_, _, _, _, _, _, _, h1997) => {
                            h1997
                        }
                    }
                };
                match m2000 {
                    Adt13::C0(_, _, _, _, _, h1996, _) => {
                        h1996
                    }
                }
            }))?, Str::lit("bytes"), false, {
                let a2019 = {
                    let a2018 = {
                        let m2003 = match v0.clone() {
                            Adt0::C0(h2002, _, _, _, _, _, _) => {
                                h2002
                            }
                        };
                        if match m2003 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2001, _, _, _, _, _, _, _) => {
                                h2001
                            }
                        } {
                            let a2007 = {
                                let m2006 = match v0.clone() {
                                    Adt0::C0(h2005, _, _, _, _, _, _) => {
                                        h2005
                                    }
                                };
                                match m2006 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2004, _, _, _, _, _, _) => {
                                        h2004
                                    }
                                }
                            };
                            if bool_not(a2007) {
                                let a2013 = {
                                    let m2012 = {
                                        let m2011 = match v0.clone() {
                                            Adt0::C0(h2010, _, _, _, _, _, _) => {
                                                h2010
                                            }
                                        };
                                        match m2011 {
                                            Adt1::C0(_, h2009, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2009
                                            }
                                        }
                                    };
                                    match m2012 {
                                        Adt2::C0(_, _, h2008, _, _, _) => {
                                            h2008
                                        }
                                    }
                                };
                                if bool_not(a2013) {
                                    let a2017 = {
                                        let m2016 = match v0.clone() {
                                            Adt0::C0(h2015, _, _, _, _, _, _) => {
                                                h2015
                                            }
                                        };
                                        match m2016 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h2014, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2014
                                            }
                                        }
                                    };
                                    bool_not(a2017)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2018)
                };
                bool_not(a2019)
            }, f29(v0.clone(), Adt73::C5), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-storageTotal"), Str::lit("Total job storage quota"), f28({
                let m2026 = {
                    let m2025 = {
                        let m2024 = match v0.clone() {
                            Adt0::C0(_, h2023, _, _, _, _, _) => {
                                h2023
                            }
                        };
                        match m2024 {
                            Adt53::C0(_, _, _, _, _, _, _, h2022) => {
                                h2022
                            }
                        }
                    };
                    match m2025 {
                        Adt13::C0(_, _, _, _, _, _, h2021) => {
                            h2021
                        }
                    }
                };
                match m2026 {
                    Adt14::C0(h2020, _, _, _, _) => {
                        h2020
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2045 = {
                    let a2044 = {
                        let m2029 = match v0.clone() {
                            Adt0::C0(h2028, _, _, _, _, _, _) => {
                                h2028
                            }
                        };
                        if match m2029 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2027, _, _, _, _, _, _, _) => {
                                h2027
                            }
                        } {
                            let a2033 = {
                                let m2032 = match v0.clone() {
                                    Adt0::C0(h2031, _, _, _, _, _, _) => {
                                        h2031
                                    }
                                };
                                match m2032 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2030, _, _, _, _, _, _) => {
                                        h2030
                                    }
                                }
                            };
                            if bool_not(a2033) {
                                let a2039 = {
                                    let m2038 = {
                                        let m2037 = match v0.clone() {
                                            Adt0::C0(h2036, _, _, _, _, _, _) => {
                                                h2036
                                            }
                                        };
                                        match m2037 {
                                            Adt1::C0(_, h2035, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2035
                                            }
                                        }
                                    };
                                    match m2038 {
                                        Adt2::C0(_, _, h2034, _, _, _) => {
                                            h2034
                                        }
                                    }
                                };
                                if bool_not(a2039) {
                                    let a2043 = {
                                        let m2042 = match v0.clone() {
                                            Adt0::C0(h2041, _, _, _, _, _, _) => {
                                                h2041
                                            }
                                        };
                                        match m2042 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h2040, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2040
                                            }
                                        }
                                    };
                                    bool_not(a2043)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2044)
                };
                bool_not(a2045)
            }, f29(v0.clone(), Adt73::C6), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-stagedOutput"), Str::lit("Staged output storage quota"), f28({
                let m2052 = {
                    let m2051 = {
                        let m2050 = match v0.clone() {
                            Adt0::C0(_, h2049, _, _, _, _, _) => {
                                h2049
                            }
                        };
                        match m2050 {
                            Adt53::C0(_, _, _, _, _, _, _, h2048) => {
                                h2048
                            }
                        }
                    };
                    match m2051 {
                        Adt13::C0(_, _, _, _, _, _, h2047) => {
                            h2047
                        }
                    }
                };
                match m2052 {
                    Adt14::C0(_, h2046, _, _, _) => {
                        h2046
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2071 = {
                    let a2070 = {
                        let m2055 = match v0.clone() {
                            Adt0::C0(h2054, _, _, _, _, _, _) => {
                                h2054
                            }
                        };
                        if match m2055 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2053, _, _, _, _, _, _, _) => {
                                h2053
                            }
                        } {
                            let a2059 = {
                                let m2058 = match v0.clone() {
                                    Adt0::C0(h2057, _, _, _, _, _, _) => {
                                        h2057
                                    }
                                };
                                match m2058 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2056, _, _, _, _, _, _) => {
                                        h2056
                                    }
                                }
                            };
                            if bool_not(a2059) {
                                let a2065 = {
                                    let m2064 = {
                                        let m2063 = match v0.clone() {
                                            Adt0::C0(h2062, _, _, _, _, _, _) => {
                                                h2062
                                            }
                                        };
                                        match m2063 {
                                            Adt1::C0(_, h2061, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2061
                                            }
                                        }
                                    };
                                    match m2064 {
                                        Adt2::C0(_, _, h2060, _, _, _) => {
                                            h2060
                                        }
                                    }
                                };
                                if bool_not(a2065) {
                                    let a2069 = {
                                        let m2068 = match v0.clone() {
                                            Adt0::C0(h2067, _, _, _, _, _, _) => {
                                                h2067
                                            }
                                        };
                                        match m2068 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h2066, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2066
                                            }
                                        }
                                    };
                                    bool_not(a2069)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2070)
                };
                bool_not(a2071)
            }, f29(v0.clone(), Adt73::C7), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-inputSpool"), Str::lit("Input spool storage quota"), f28({
                let m2078 = {
                    let m2077 = {
                        let m2076 = match v0.clone() {
                            Adt0::C0(_, h2075, _, _, _, _, _) => {
                                h2075
                            }
                        };
                        match m2076 {
                            Adt53::C0(_, _, _, _, _, _, _, h2074) => {
                                h2074
                            }
                        }
                    };
                    match m2077 {
                        Adt13::C0(_, _, _, _, _, _, h2073) => {
                            h2073
                        }
                    }
                };
                match m2078 {
                    Adt14::C0(_, _, h2072, _, _) => {
                        h2072
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2097 = {
                    let a2096 = {
                        let m2081 = match v0.clone() {
                            Adt0::C0(h2080, _, _, _, _, _, _) => {
                                h2080
                            }
                        };
                        if match m2081 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2079, _, _, _, _, _, _, _) => {
                                h2079
                            }
                        } {
                            let a2085 = {
                                let m2084 = match v0.clone() {
                                    Adt0::C0(h2083, _, _, _, _, _, _) => {
                                        h2083
                                    }
                                };
                                match m2084 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2082, _, _, _, _, _, _) => {
                                        h2082
                                    }
                                }
                            };
                            if bool_not(a2085) {
                                let a2091 = {
                                    let m2090 = {
                                        let m2089 = match v0.clone() {
                                            Adt0::C0(h2088, _, _, _, _, _, _) => {
                                                h2088
                                            }
                                        };
                                        match m2089 {
                                            Adt1::C0(_, h2087, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2087
                                            }
                                        }
                                    };
                                    match m2090 {
                                        Adt2::C0(_, _, h2086, _, _, _) => {
                                            h2086
                                        }
                                    }
                                };
                                if bool_not(a2091) {
                                    let a2095 = {
                                        let m2094 = match v0.clone() {
                                            Adt0::C0(h2093, _, _, _, _, _, _) => {
                                                h2093
                                            }
                                        };
                                        match m2094 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h2092, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2092
                                            }
                                        }
                                    };
                                    bool_not(a2095)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2096)
                };
                bool_not(a2097)
            }, f29(v0.clone(), Adt73::C8), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-spill"), Str::lit("Spill storage quota"), f28({
                let m2104 = {
                    let m2103 = {
                        let m2102 = match v0.clone() {
                            Adt0::C0(_, h2101, _, _, _, _, _) => {
                                h2101
                            }
                        };
                        match m2102 {
                            Adt53::C0(_, _, _, _, _, _, _, h2100) => {
                                h2100
                            }
                        }
                    };
                    match m2103 {
                        Adt13::C0(_, _, _, _, _, _, h2099) => {
                            h2099
                        }
                    }
                };
                match m2104 {
                    Adt14::C0(_, _, _, h2098, _) => {
                        h2098
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2123 = {
                    let a2122 = {
                        let m2107 = match v0.clone() {
                            Adt0::C0(h2106, _, _, _, _, _, _) => {
                                h2106
                            }
                        };
                        if match m2107 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2105, _, _, _, _, _, _, _) => {
                                h2105
                            }
                        } {
                            let a2111 = {
                                let m2110 = match v0.clone() {
                                    Adt0::C0(h2109, _, _, _, _, _, _) => {
                                        h2109
                                    }
                                };
                                match m2110 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2108, _, _, _, _, _, _) => {
                                        h2108
                                    }
                                }
                            };
                            if bool_not(a2111) {
                                let a2117 = {
                                    let m2116 = {
                                        let m2115 = match v0.clone() {
                                            Adt0::C0(h2114, _, _, _, _, _, _) => {
                                                h2114
                                            }
                                        };
                                        match m2115 {
                                            Adt1::C0(_, h2113, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2113
                                            }
                                        }
                                    };
                                    match m2116 {
                                        Adt2::C0(_, _, h2112, _, _, _) => {
                                            h2112
                                        }
                                    }
                                };
                                if bool_not(a2117) {
                                    let a2121 = {
                                        let m2120 = match v0.clone() {
                                            Adt0::C0(h2119, _, _, _, _, _, _) => {
                                                h2119
                                            }
                                        };
                                        match m2120 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h2118, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2118
                                            }
                                        }
                                    };
                                    bool_not(a2121)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2122)
                };
                bool_not(a2123)
            }, f29(v0.clone(), Adt73::C9), Str::lit("decimal")), List::cons(Adt71::C0(Str::lit("limit-publicationCopy"), Str::lit("Publication copy storage quota"), f28({
                let m2130 = {
                    let m2129 = {
                        let m2128 = match v0.clone() {
                            Adt0::C0(_, h2127, _, _, _, _, _) => {
                                h2127
                            }
                        };
                        match m2128 {
                            Adt53::C0(_, _, _, _, _, _, _, h2126) => {
                                h2126
                            }
                        }
                    };
                    match m2129 {
                        Adt13::C0(_, _, _, _, _, _, h2125) => {
                            h2125
                        }
                    }
                };
                match m2130 {
                    Adt14::C0(_, _, _, _, h2124) => {
                        h2124
                    }
                }
            })?, Str::lit("bytes"), true, {
                let a2149 = {
                    let a2148 = {
                        let m2133 = match v0.clone() {
                            Adt0::C0(h2132, _, _, _, _, _, _) => {
                                h2132
                            }
                        };
                        if match m2133 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2131, _, _, _, _, _, _, _) => {
                                h2131
                            }
                        } {
                            let a2137 = {
                                let m2136 = match v0.clone() {
                                    Adt0::C0(h2135, _, _, _, _, _, _) => {
                                        h2135
                                    }
                                };
                                match m2136 {
                                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2134, _, _, _, _, _, _) => {
                                        h2134
                                    }
                                }
                            };
                            if bool_not(a2137) {
                                let a2143 = {
                                    let m2142 = {
                                        let m2141 = match v0.clone() {
                                            Adt0::C0(h2140, _, _, _, _, _, _) => {
                                                h2140
                                            }
                                        };
                                        match m2141 {
                                            Adt1::C0(_, h2139, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2139
                                            }
                                        }
                                    };
                                    match m2142 {
                                        Adt2::C0(_, _, h2138, _, _, _) => {
                                            h2138
                                        }
                                    }
                                };
                                if bool_not(a2143) {
                                    let a2147 = {
                                        let m2146 = match v0.clone() {
                                            Adt0::C0(h2145, _, _, _, _, _, _) => {
                                                h2145
                                            }
                                        };
                                        match m2146 {
                                            Adt1::C0(_, _, _, _, _, _, _, _, h2144, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                                h2144
                                            }
                                        }
                                    };
                                    bool_not(a2147)
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    };
                    bool_not(a2148)
                };
                bool_not(a2149)
            }, f29(v0, Adt73::C10), Str::lit("decimal")), List::<Adt71>::nil()))))))))))))
        }
        Adt48::C2 => {
            Ok(List::<Adt71>::nil())
        }
        Adt48::C3 => {
            Ok(List::<Adt71>::nil())
        }
    }
}

pub fn f16(v0: Adt47) -> Str {
    let m2150 = v0;
    match m2150 {
        Adt47::C0 => {
            Str::lit("The generated SDK returned a ComputeError.")
        }
        Adt47::C1 => {
            Str::lit("The execution instance terminated. Its output disposition must be reconciled.")
        }
        Adt47::C2 => {
            Str::lit("The host outcome is unknown. Reconcile retained resources before retrying.")
        }
    }
}

pub fn f17(v0: Adt41) -> Str {
    let m2151 = v0;
    match m2151 {
        Adt41::C0(_, _) => {
            Str::lit("The archive syntax is malformed.")
        }
        Adt41::C1(_, _) => {
            Str::lit("The archive parsed but its program could not be decoded or executed.")
        }
        Adt41::C2(_) => {
            Str::lit("Choose the actual external basis bytes required by this archive.")
        }
        Adt41::C3(_) => {
            Str::lit("The supplied basis does not match the archive requirement.")
        }
        Adt41::C4 => {
            Str::lit("Search is incomplete. A checked incumbent remains usable when one is available.")
        }
        Adt41::C5 => {
            Str::lit("Certificate verification is incomplete.")
        }
        Adt41::C6(_, _) => {
            Str::lit("The operation reached a resource budget. Adjust the budget or resume from a checkpoint.")
        }
        Adt41::C7 => {
            Str::lit("Cancelled.")
        }
        Adt41::C8(_) => {
            Str::lit("Input could not be read.")
        }
        Adt41::C9(v10, _) => {
            let m2152 = v10;
            match m2152 {
                Adt7::C0 => {
                    Str::lit("Output remains staged.")
                }
                Adt7::C1 => {
                    Str::lit("The destination reports published output.")
                }
                Adt7::C2 => {
                    Str::lit("Download failed. The checked staged result is retained for retry.")
                }
                Adt7::C3 => {
                    Str::lit("Publication outcome is unknown. Reconcile with the destination before retrying.")
                }
            }
        }
        Adt41::C10(v12) => {
            f30(v12)
        }
        Adt41::C11(_) => {
            Str::lit("The streaming request is out of sequence.")
        }
        Adt41::C12 => {
            Str::lit("Independent reconstruction differs from the original input.")
        }
        Adt41::C13 => {
            Str::lit("Independent verification is incomplete.")
        }
        Adt41::C14(_) => {
            Str::lit("The checkpoint could not be replayed for this input and basis.")
        }
        Adt41::C15(_) => {
            Str::lit("The execution report does not match staged output ownership.")
        }
        Adt41::C16(_) => {
            Str::lit("Storage admission failed. Achieved staging, spool and spill usage is retained in the report.")
        }
    }
}

pub fn f18(v0: Adt54) -> Str {
    let m2153 = v0;
    match m2153 {
        Adt54::C0 => {
            Str::lit("Checked archive ready")
        }
        Adt54::C1 => {
            Str::lit("Checked reconstruction ready")
        }
        Adt54::C2 => {
            Str::lit("Archive inspected")
        }
        Adt54::C3 => {
            Str::lit("Verification complete")
        }
        Adt54::C4 => {
            Str::lit("Checked archive ready")
        }
        Adt54::C5 => {
            Str::lit("Checked basis ready")
        }
        Adt54::C6 => {
            Str::lit("Frontier analysis complete; inspect its search and evidence status")
        }
        Adt54::C7 => {
            Str::lit("Comparison complete; inspect the observations for each archive")
        }
        Adt54::C8 => {
            Str::lit("Acceptance report ready")
        }
        Adt54::C9 => {
            Str::lit("Core request report ready")
        }
    }
}

pub fn f19(v0: Adt1) -> Adt52 {
    Adt52::C0(match v0.clone() {
        Adt1::C0(h2154, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h2154
        }
    }, {
        let m2157 = match v0.clone() {
            Adt1::C0(_, h2156, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2156
            }
        };
        match m2157 {
            Adt2::C0(_, h2155, _, _, _, _) => {
                h2155
            }
        }
    }, {
        let m2160 = match v0 {
            Adt1::C0(_, h2159, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2159
            }
        };
        match m2160 {
            Adt2::C0(h2158, _, _, _, _, _) => {
                h2158
            }
        }
    })
}

pub fn f20(v0: Adt0) -> bool {
    let m2164 = {
        let m2163 = match v0 {
            Adt0::C0(h2162, _, _, _, _, _, _) => {
                h2162
            }
        };
        match m2163 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h2161, _, _, _, _, _, _, _, _, _, _) => {
                h2161
            }
        }
    };
    match m2164 {
        None => {
            false
        }
        Some(v1) => {
            let m2165 = v1;
            match m2165 {
                Adt41::C0(_, _) => {
                    false
                }
                Adt41::C1(_, _) => {
                    false
                }
                Adt41::C2(_) => {
                    true
                }
                Adt41::C3(_) => {
                    true
                }
                Adt41::C4 => {
                    false
                }
                Adt41::C5 => {
                    false
                }
                Adt41::C6(_, _) => {
                    false
                }
                Adt41::C7 => {
                    false
                }
                Adt41::C8(_) => {
                    false
                }
                Adt41::C9(_, _) => {
                    false
                }
                Adt41::C10(_) => {
                    false
                }
                Adt41::C11(_) => {
                    false
                }
                Adt41::C12 => {
                    false
                }
                Adt41::C13 => {
                    false
                }
                Adt41::C14(_) => {
                    false
                }
                Adt41::C15(_) => {
                    false
                }
                Adt41::C16(_) => {
                    false
                }
            }
        }
    }
}

pub fn f21(v0: Adt55) -> Str {
    let m2166 = v0;
    match m2166 {
        Adt55::C0 => {
            Str::lit("file-input")
        }
        Adt55::C1 => {
            Str::lit("file-archive")
        }
        Adt55::C2 => {
            Str::lit("file-basis")
        }
        Adt55::C3 => {
            Str::lit("file-originals")
        }
        Adt55::C4 => {
            Str::lit("file-checkpoint")
        }
        Adt55::C5 => {
            Str::lit("file-comparison")
        }
    }
}

pub fn f22(v0: Adt0, v1: Adt55, v2: List<Adt59>, v3: u64, v4: u64, v5: bool) -> R<List<Adt67>> {
    let m2167 = v2;
    match m2167.uncons() {
        None => {
            Ok(List::<Adt67>::nil())
        }
        Some((v6, v7)) => {
            Ok(List::cons(Adt67::C0(match v6.clone() {
                Adt59::C0(h2168, _, _) => {
                    h2168
                }
            }, v3, match v6.clone() {
                Adt59::C0(_, h2169, _) => {
                    h2169
                }
            }, match v6.clone() {
                Adt59::C0(_, _, h2170) => {
                    h2170
                }
            }, {
                let m2172 = match v6.clone() {
                    Adt59::C0(_, _, h2171) => {
                        h2171
                    }
                };
                match m2172 {
                    None => {
                        false
                    }
                    Some(v8) => {
                        let a2173 = v8;
                        let a2174 = 0u64;
                        nat_eq(a2173, a2174)
                    }
                }
            }, f7(v0.clone(), Adt64::C7(v1.clone(), match v6.clone() {
                Adt59::C0(h2175, _, _) => {
                    h2175
                }
            })), f7(v0.clone(), Adt64::C8(v1.clone(), match v6.clone() {
                Adt59::C0(h2176, _, _) => {
                    h2176
                }
            }, {
                let a2177 = v3;
                let a2178 = 1u64;
                nat_sub(a2177, a2178)
            })), f7(v0.clone(), Adt64::C8(v1.clone(), match v6 {
                Adt59::C0(h2179, _, _) => {
                    h2179
                }
            }, {
                let a2180 = v3;
                let a2181 = 1u64;
                nat_add(a2180, a2181)?
            })), v5, if v5 {
                let a2184 = {
                    let a2182 = v3;
                    let a2183 = 0u64;
                    nat_eq(a2182, a2183)
                };
                bool_not(a2184)
            } else {
                false
            }, if v5 {
                let a2187 = {
                    let a2185 = v3;
                    let a2186 = 1u64;
                    nat_add(a2185, a2186)?
                };
                let a2188 = v4;
                nat_lt(a2187, a2188)
            } else {
                false
            }, {
                let a2189 = v3;
                let a2190 = 1u64;
                nat_add(a2189, a2190)?
            }, Str::lit("Remove object"), Str::lit("Move object earlier"), Str::lit("Move object later")), f22(v0, v1, v7, {
                let a2191 = v3;
                let a2192 = 1u64;
                nat_add(a2191, a2192)?
            }, v4, v5)?))
        }
    }
}

pub fn f23(p2197: List<Adt58>, v1: Adt55) -> List<Adt59> {
    let m2196 = p2197;
    {
        let mut m2196 = m2196;
        loop {
            let step = {
                let v0 = m2196;
                let m2193 = v0;
                match m2193.uncons() {
                    None => {
                        Err::<List<Adt58>, List<Adt59>>(List::<Adt59>::nil())
                    }
                    Some((v2, v3)) => {
                        if f25(match v2.clone() {
                            Adt58::C0(h2194, _) => {
                                h2194
                            }
                        }, v1.clone()) {
                            match v2 {
                                Adt58::C0(_, h2195) => {
                                    Err::<List<Adt58>, List<Adt59>>(h2195)
                                }
                            }
                        } else {
                            Ok::<List<Adt58>, List<Adt59>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m2196 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f24(v0: List<Adt59>) -> R<u64> {
    let m2198 = v0;
    match m2198.uncons() {
        None => {
            Ok(0u64)
        }
        Some((_, v2)) => {
            let a2199 = 1u64;
            let a2200 = f24(v2)?;
            nat_add(a2199, a2200)
        }
    }
}

pub fn f25(v0: Adt55, v1: Adt55) -> bool {
    let m2201 = v0;
    match m2201 {
        Adt55::C0 => {
            let m2202 = v1;
            match m2202 {
                Adt55::C0 => {
                    true
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C1 => {
            let m2203 = v1;
            match m2203 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    true
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C2 => {
            let m2204 = v1;
            match m2204 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    true
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C3 => {
            let m2205 = v1;
            match m2205 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    true
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C4 => {
            let m2206 = v1;
            match m2206 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    true
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C5 => {
            let m2207 = v1;
            match m2207 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    true
                }
            }
        }
    }
}

pub fn f26(v0: Adt54, v1: bool, v2: Adt28) -> Adt70 {
    let m2208 = v0;
    match m2208 {
        Adt54::C0 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2209, _, _, _, _) => {
                    h2209
                }
            }, if match v2.clone() {
                Adt28::C0(h2210, _, _, _, _) => {
                    h2210
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2211, _, _, _) => {
                        h2211
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2212, _, _, _, _) => {
                    h2212
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2213, _, _, _) => {
                        h2213
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2214, _, _) => {
                        h2214
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2215, _, _, _, _) => {
                    h2215
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2216, _, _, _) => {
                        h2216
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2217, _, _) => {
                        h2217
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2218, _) => {
                            h2218
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2219, _, _, _, _) => {
                    h2219
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2220, _, _, _) => {
                        h2220
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2221, _, _) => {
                        h2221
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2222) => {
                        h2222
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt54::C1 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2223, _, _, _, _) => {
                    h2223
                }
            }, if match v2.clone() {
                Adt28::C0(h2224, _, _, _, _) => {
                    h2224
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2225, _, _, _) => {
                        h2225
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2226, _, _, _, _) => {
                    h2226
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2227, _, _, _) => {
                        h2227
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2228, _, _) => {
                        h2228
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2229, _, _, _, _) => {
                    h2229
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2230, _, _, _) => {
                        h2230
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2231, _, _) => {
                        h2231
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2232, _) => {
                            h2232
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2233, _, _, _, _) => {
                    h2233
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2234, _, _, _) => {
                        h2234
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2235, _, _) => {
                        h2235
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2236) => {
                        h2236
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt54::C2 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2237, _, _, _, _) => {
                    h2237
                }
            }, if match v2.clone() {
                Adt28::C0(h2238, _, _, _, _) => {
                    h2238
                }
            } {
                match v2 {
                    Adt28::C0(_, h2239, _, _, _) => {
                        h2239
                    }
                }
            } else {
                false
            }, false, false, false, false, false)
        }
        Adt54::C3 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2240, _, _, _, _) => {
                    h2240
                }
            }, if match v2.clone() {
                Adt28::C0(h2241, _, _, _, _) => {
                    h2241
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2242, _, _, _) => {
                        h2242
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2243, _, _, _, _) => {
                    h2243
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2244, _, _, _) => {
                        h2244
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2245, _, _) => {
                        h2245
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2246, _, _, _, _) => {
                    h2246
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2247, _, _, _) => {
                        h2247
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2248, _, _) => {
                        h2248
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2249, _) => {
                            h2249
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2250, _, _, _, _) => {
                    h2250
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2251, _, _, _) => {
                        h2251
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2252, _, _) => {
                        h2252
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2253) => {
                        h2253
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt54::C4 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2254, _, _, _, _) => {
                    h2254
                }
            }, if match v2.clone() {
                Adt28::C0(h2255, _, _, _, _) => {
                    h2255
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2256, _, _, _) => {
                        h2256
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2257, _, _, _, _) => {
                    h2257
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2258, _, _, _) => {
                        h2258
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2259, _, _) => {
                        h2259
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2260, _, _, _, _) => {
                    h2260
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2261, _, _, _) => {
                        h2261
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2262, _, _) => {
                        h2262
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2263, _) => {
                            h2263
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2264, _, _, _, _) => {
                    h2264
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2265, _, _, _) => {
                        h2265
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2266, _, _) => {
                        h2266
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2267) => {
                        h2267
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt54::C5 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2268, _, _, _, _) => {
                    h2268
                }
            }, if match v2.clone() {
                Adt28::C0(h2269, _, _, _, _) => {
                    h2269
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2270, _, _, _) => {
                        h2270
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2271, _, _, _, _) => {
                    h2271
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2272, _, _, _) => {
                        h2272
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2273, _, _) => {
                        h2273
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2274, _, _, _, _) => {
                    h2274
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2275, _, _, _) => {
                        h2275
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2276, _, _) => {
                        h2276
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2277, _) => {
                            h2277
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2278, _, _, _, _) => {
                    h2278
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2279, _, _, _) => {
                        h2279
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2280, _, _) => {
                        h2280
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2281) => {
                        h2281
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt54::C6 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2282, _, _, _, _) => {
                    h2282
                }
            }, if match v2.clone() {
                Adt28::C0(h2283, _, _, _, _) => {
                    h2283
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2284, _, _, _) => {
                        h2284
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2285, _, _, _, _) => {
                    h2285
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2286, _, _, _) => {
                        h2286
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2287, _, _) => {
                        h2287
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2288, _, _, _, _) => {
                    h2288
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2289, _, _, _) => {
                        h2289
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2290, _, _) => {
                        h2290
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2291, _) => {
                            h2291
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2292, _, _, _, _) => {
                    h2292
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2293, _, _, _) => {
                        h2293
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2294, _, _) => {
                        h2294
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2295) => {
                        h2295
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt54::C7 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2296, _, _, _, _) => {
                    h2296
                }
            }, if match v2.clone() {
                Adt28::C0(h2297, _, _, _, _) => {
                    h2297
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2298, _, _, _) => {
                        h2298
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2299, _, _, _, _) => {
                    h2299
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2300, _, _, _) => {
                        h2300
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2301, _, _) => {
                        h2301
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2302, _, _, _, _) => {
                    h2302
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2303, _, _, _) => {
                        h2303
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2304, _, _) => {
                        h2304
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2305, _) => {
                            h2305
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2306, _, _, _, _) => {
                    h2306
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2307, _, _, _) => {
                        h2307
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2308, _, _) => {
                        h2308
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2309) => {
                        h2309
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt54::C8 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2310, _, _, _, _) => {
                    h2310
                }
            }, if match v2.clone() {
                Adt28::C0(h2311, _, _, _, _) => {
                    h2311
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2312, _, _, _) => {
                        h2312
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2313, _, _, _, _) => {
                    h2313
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2314, _, _, _) => {
                        h2314
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2315, _, _) => {
                        h2315
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2316, _, _, _, _) => {
                    h2316
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2317, _, _, _) => {
                        h2317
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2318, _, _) => {
                        h2318
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2319, _) => {
                            h2319
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2320, _, _, _, _) => {
                    h2320
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2321, _, _, _) => {
                        h2321
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2322, _, _) => {
                        h2322
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2323) => {
                        h2323
                    }
                }
            } else {
                false
            }, false, false)
        }
        Adt54::C9 => {
            Adt70::C0(match v2.clone() {
                Adt28::C0(h2324, _, _, _, _) => {
                    h2324
                }
            }, if match v2.clone() {
                Adt28::C0(h2325, _, _, _, _) => {
                    h2325
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2326, _, _, _) => {
                        h2326
                    }
                }
            } else {
                false
            }, if if match v2.clone() {
                Adt28::C0(h2327, _, _, _, _) => {
                    h2327
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2328, _, _, _) => {
                        h2328
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2329, _, _) => {
                        h2329
                    }
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2330, _, _, _, _) => {
                    h2330
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2331, _, _, _) => {
                        h2331
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2332, _, _) => {
                        h2332
                    }
                }
            } else {
                false
            } {
                if v1 {
                    match v2.clone() {
                        Adt28::C0(_, _, _, h2333, _) => {
                            h2333
                        }
                    }
                } else {
                    false
                }
            } else {
                false
            }, if if if match v2.clone() {
                Adt28::C0(h2334, _, _, _, _) => {
                    h2334
                }
            } {
                match v2.clone() {
                    Adt28::C0(_, h2335, _, _, _) => {
                        h2335
                    }
                }
            } else {
                false
            } {
                match v2.clone() {
                    Adt28::C0(_, _, h2336, _, _) => {
                        h2336
                    }
                }
            } else {
                false
            } {
                match v2 {
                    Adt28::C0(_, _, _, _, h2337) => {
                        h2337
                    }
                }
            } else {
                false
            }, false, false)
        }
    }
}

pub fn f27(v0: Adt30) -> Adt74 {
    let m2338 = v0;
    match m2338 {
        Adt30::C0 => {
            Adt74::C0
        }
        Adt30::C1(_) => {
            Adt74::C3
        }
        Adt30::C2(_) => {
            Adt74::C2
        }
        Adt30::C3(_) => {
            Adt74::C3
        }
        Adt30::C4(_) => {
            Adt74::C1
        }
    }
}

pub fn f28(v0: Option<u64>) -> R<Str> {
    let m2339 = v0;
    match m2339 {
        None => {
            Ok(Str::lit(""))
        }
        Some(v1) => {
            f31(v1)
        }
    }
}

pub fn f29(v0: Adt0, v1: Adt73) -> Adt72 {
    Adt72::C0(f19(match v0.clone() {
        Adt0::C0(h2340, _, _, _, _, _, _) => {
            h2340
        }
    }), match v0 {
        Adt0::C0(_, _, h2341, _, _, _, _) => {
            h2341
        }
    }, v1)
}

pub fn f30(v0: Adt43) -> Str {
    let m2342 = v0;
    match m2342 {
        Adt43::C0 => {
            Str::lit("An operation is already running.")
        }
        Adt43::C1 => {
            Str::lit("This session is closed.")
        }
        Adt43::C2 => {
            Str::lit("This view is detached.")
        }
        Adt43::C3 => {
            Str::lit("Start an operation first.")
        }
        Adt43::C4 => {
            Str::lit("Choose a checkpoint and its original input.")
        }
        Adt43::C5 => {
            Str::lit("No checked staged result is ready to download.")
        }
        Adt43::C6 => {
            Str::lit("The download is awaiting its destination receipt.")
        }
        Adt43::C7 => {
            Str::lit("Reconcile the unknown publication outcome with the destination.")
        }
        Adt43::C8 => {
            Str::lit("Input objects or boundaries arrived out of order.")
        }
        Adt43::C9 => {
            Str::lit("Input has already ended.")
        }
        Adt43::C10 => {
            Str::lit("The operation has not requested more input.")
        }
        Adt43::C11 => {
            Str::lit("The resource belongs to another instance.")
        }
        Adt43::C12 => {
            Str::lit("Add a positive amount of effort.")
        }
        Adt43::C13 => {
            Str::lit("No publication is awaiting a receipt.")
        }
        Adt43::C14 => {
            Str::lit("Choose input objects.")
        }
        Adt43::C15 => {
            Str::lit("Choose an archive.")
        }
        Adt43::C16 => {
            Str::lit("Choose the second archive.")
        }
        Adt43::C17 => {
            Str::lit("Enter a nonnegative whole number. Clear only an optional quota to request no additional limit.")
        }
    }
}

pub fn f31(v0: u64) -> R<Str> {
    Ok(f32({
        let a2343 = v0;
        let a2344 = 1u64;
        nat_add(a2343, a2344)?
    }, v0))
}

pub fn f32(v0: u64, v1: u64) -> Str {
    let m2345 = v0;
    if m2345 == 0 {
        Str::lit("")
    } else {
        let v2 = m2345 - 1;
        let a2346 = v1;
        let a2347 = 10u64;
        if nat_lt(a2346, a2347) {
            f33(v1)
        } else {
            let a2354 = List::cons(f32(v2, {
                let a2348 = v1;
                let a2349 = 10u64;
                let a2350 = 0u64;
                nat_quot(a2348, a2349, a2350)
            }), List::cons(f33({
                let a2351 = v1;
                let a2352 = 10u64;
                let a2353 = 0u64;
                nat_rem(a2351, a2352, a2353)
            }), List::<Str>::nil()));
            let a2355 = Str::lit("");
            join(a2354, a2355)
        }
    }
}

pub fn f33(v0: u64) -> Str {
    let a2356 = v0;
    let a2357 = 0u64;
    if nat_eq(a2356, a2357) {
        Str::lit("0")
    } else {
        let a2358 = v0;
        let a2359 = 1u64;
        if nat_eq(a2358, a2359) {
            Str::lit("1")
        } else {
            let a2360 = v0;
            let a2361 = 2u64;
            if nat_eq(a2360, a2361) {
                Str::lit("2")
            } else {
                let a2362 = v0;
                let a2363 = 3u64;
                if nat_eq(a2362, a2363) {
                    Str::lit("3")
                } else {
                    let a2364 = v0;
                    let a2365 = 4u64;
                    if nat_eq(a2364, a2365) {
                        Str::lit("4")
                    } else {
                        let a2366 = v0;
                        let a2367 = 5u64;
                        if nat_eq(a2366, a2367) {
                            Str::lit("5")
                        } else {
                            let a2368 = v0;
                            let a2369 = 6u64;
                            if nat_eq(a2368, a2369) {
                                Str::lit("6")
                            } else {
                                let a2370 = v0;
                                let a2371 = 7u64;
                                if nat_eq(a2370, a2371) {
                                    Str::lit("7")
                                } else {
                                    let a2372 = v0;
                                    let a2373 = 8u64;
                                    if nat_eq(a2372, a2373) {
                                        Str::lit("8")
                                    } else {
                                        Str::lit("9")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn run(p0: Adt0) -> R<Adt61> {
    f0(p0)
}
