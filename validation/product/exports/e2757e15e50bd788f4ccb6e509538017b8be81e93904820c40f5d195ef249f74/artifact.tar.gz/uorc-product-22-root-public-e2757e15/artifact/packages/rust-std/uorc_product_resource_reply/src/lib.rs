#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt53, u64, Option<Adt55>, Adt56, List<Adt58>, Option<Adt60>),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, Adt2, Adt5, Adt8, Option<Adt9>, Option<Adt22>, Adt40, Option<Adt11>, bool, bool, Option<Adt41>, Option<Adt47>, Option<Adt11>, bool, bool, Adt48, Adt49, bool, Adt50, Option<Adt23>, List<Adt51>),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u64, u64, bool, bool, Adt3, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Adt6, bool, u64, bool, Adt7),
}

#[derive(Clone)]
pub enum Adt6 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt7 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, bool, bool, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(Adt10),
    C1(Adt15),
    C2(Adt15),
    C3(Adt16),
    C4(Adt17),
    C5(Adt18),
    C6(Adt19),
    C7(Adt20),
    C8(Adt21),
    C9(Adt21),
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt11 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt12 {
    C0(Adt13, Option<Adt11>),
}

#[derive(Clone)]
pub enum Adt13 {
    C0(u64, u64, u64, u64, Option<u64>, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt15 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt11, Option<Adt11>, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt17 {
    C0(Adt11, Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt19 {
    C0(Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt11, Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt23, Adt28, bool, bool, Adt29, Adt30, Adt32, bool, Option<Adt11>, Option<Adt33>),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, Adt24, Option<Adt26>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(Adt25, Adt25, u64, u64),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt26 {
    C0(Option<u64>, Option<u64>, Adt27, u64),
}

#[derive(Clone)]
pub enum Adt27 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt28 {
    C0(bool, bool, bool, bool, bool),
}

#[derive(Clone)]
pub enum Adt29 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt30 {
    C0,
    C1(Adt31),
    C2(Adt31),
    C3(Adt31),
    C4(Adt31),
}

#[derive(Clone)]
pub enum Adt31 {
    C0(Bytes, Adt11, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt32 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt33 {
    C0(Adt34),
    C1(Adt34),
    C2(Adt34),
    C3(u64),
    C4(Adt35),
    C5(Adt36),
    C6(Adt37),
    C7(Adt39),
}

#[derive(Clone)]
pub enum Adt34 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt35 {
    C0(Bytes, u64, u64),
}

#[derive(Clone)]
pub enum Adt36 {
    C0(Adt11, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt37 {
    C0(Adt38, Adt38, bool),
}

#[derive(Clone)]
pub enum Adt38 {
    C0(Adt23, Adt28, bool, Adt30),
}

#[derive(Clone)]
pub enum Adt39 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt40 {
    C0(u64, u64, u64, u64, u64, Str),
}

#[derive(Clone)]
pub enum Adt41 {
    C0(u64, Str),
    C1(u64, Str),
    C2(Bytes),
    C3(Bytes),
    C4,
    C5,
    C6(Adt42, u64),
    C7,
    C8(Str),
    C9(Adt7, Str),
    C10(Adt43),
    C11(Adt44),
    C12,
    C13,
    C14(Str),
    C15(Str),
    C16(Adt45),
}

#[derive(Clone)]
pub enum Adt42 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt43 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
    C12,
    C13,
    C14,
    C15,
    C16,
    C17,
}

#[derive(Clone)]
pub enum Adt44 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt45 {
    C0(u64, u64, u64),
    C1(Adt46, u64, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64, u64),
}

#[derive(Clone)]
pub enum Adt46 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt47 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt48 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt49 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt50 {
    C0(Adt24, Option<Adt45>),
}

#[derive(Clone)]
pub enum Adt51 {
    C0(Adt52, Adt14, Adt50, Option<Adt23>),
}

#[derive(Clone)]
pub enum Adt52 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt53 {
    C0(Adt54, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt54 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
}

#[derive(Clone)]
pub enum Adt55 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt56 {
    C0(u64, Adt57),
}

#[derive(Clone)]
pub enum Adt57 {
    C0(Adt55),
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt58 {
    C0(Adt55, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt59 {
    C0(u64, Str, Option<u64>),
}

#[derive(Clone)]
pub enum Adt60 {
    C0(Adt55, Adt52, u64, Adt11, List<Adt59>, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt61 {
    C0(Adt54),
    C1(Adt55),
    C2(Adt55, Adt52, u64, Adt11, List<Adt59>),
    C3(Adt55),
    C4(Adt13),
    C5,
    C6(Adt62),
    C7(u64),
    C8(Adt55, u64),
    C9(Adt55, u64, u64),
    C10(Adt52, u64, Adt11, List<Adt59>),
    C11(Adt52, u64, Str),
}

#[derive(Clone)]
pub enum Adt62 {
    C0,
    C1(Adt48),
    C2,
    C3,
    C4,
    C5,
    C6,
    C7(u64),
    C8,
}

#[derive(Clone)]
pub enum Adt63 {
    C0(Adt0, List<Adt64>),
}

#[derive(Clone)]
pub enum Adt64 {
    C0(Adt65),
    C1(Adt55, Adt52, u64),
    C2(Adt60),
    C3(Adt60),
}

#[derive(Clone)]
pub enum Adt65 {
    C0(Adt52, Adt9),
    C1(Adt52, Adt66),
    C2(Adt52, u64),
    C3(Adt52, u64),
    C4(Adt52),
    C5(Adt52),
    C6(Adt11),
    C7(Adt52, Adt11),
    C8(u64),
    C9(Adt52),
}

#[derive(Clone)]
pub enum Adt66 {
    C0(u64),
    C1(Adt67),
    C2(u64),
    C3,
}

#[derive(Clone)]
pub enum Adt67 {
    C0(Adt11, u64, u64),
}

#[derive(Clone)]
pub enum Adt68 {
    C0(Adt9),
    C1,
    C2,
    C3(Adt48),
    C4,
    C5,
    C6,
    C7,
    C8(u64),
    C9(Adt52),
    C10(Adt52, Adt66),
    C11(u64),
    C12(Adt52, Adt40),
    C13(Adt52, Adt11),
    C14(u64),
    C15(Adt52, Adt22),
    C16(Adt52, Adt69),
    C17(Adt52, Adt47),
    C18,
    C19(Adt52, Adt7),
    C20,
    C21(Adt52, u64),
    C22(Adt52, Adt70),
    C23(Adt52, Adt70),
    C24(Adt52),
}

#[derive(Clone)]
pub enum Adt69 {
    C0(Adt41, Adt23, Adt7),
}

#[derive(Clone)]
pub enum Adt70 {
    C0(Adt46, u64),
    C1(Adt46, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64),
    C4(Adt46, u64),
}

#[derive(Clone)]
pub enum Adt71 {
    C0(Adt1, List<Adt65>),
}

#[derive(Clone)]
pub enum Adt72 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt73 {
    C0(Adt74, Adt5),
    C1(Adt44),
}

#[derive(Clone)]
pub enum Adt74 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt75 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt76 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt77 {
    C0,
    C1,
    C2,
    C3,
}

pub fn f0(v0: Adt0, v1: Adt61) -> R<Adt63> {
    if f1(v1.clone()) {
        Ok(Adt63::C0({
            let m4 = f2({
                let m3 = f3(v0.clone())?;
                match m3 {
                    Adt63::C0(h2, _) => {
                        h2
                    }
                }
            }, v1.clone())?;
            match m4 {
                Adt63::C0(h1, _) => {
                    h1
                }
            }
        }, f4({
            let m6 = f3(v0.clone())?;
            match m6 {
                Adt63::C0(_, h5) => {
                    h5
                }
            }
        }, {
            let m10 = f2({
                let m9 = f3(v0)?;
                match m9 {
                    Adt63::C0(h8, _) => {
                        h8
                    }
                }
            }, v1)?;
            match m10 {
                Adt63::C0(_, h7) => {
                    h7
                }
            }
        })))
    } else {
        f2(v0, v1)
    }
}

pub fn f1(v0: Adt61) -> bool {
    let m11 = v0;
    match m11 {
        Adt61::C0(_) => {
            true
        }
        Adt61::C1(_) => {
            true
        }
        Adt61::C2(_, _, _, _, _) => {
            false
        }
        Adt61::C3(_) => {
            true
        }
        Adt61::C4(_) => {
            true
        }
        Adt61::C5 => {
            false
        }
        Adt61::C6(v10) => {
            let m12 = v10;
            match m12 {
                Adt62::C0 => {
                    true
                }
                Adt62::C1(_) => {
                    false
                }
                Adt62::C2 => {
                    false
                }
                Adt62::C3 => {
                    false
                }
                Adt62::C4 => {
                    false
                }
                Adt62::C5 => {
                    false
                }
                Adt62::C6 => {
                    false
                }
                Adt62::C7(_) => {
                    false
                }
                Adt62::C8 => {
                    false
                }
            }
        }
        Adt61::C7(_) => {
            false
        }
        Adt61::C8(_, _) => {
            false
        }
        Adt61::C9(_, _, _) => {
            false
        }
        Adt61::C10(_, _, _, _) => {
            false
        }
        Adt61::C11(_, _, _) => {
            false
        }
    }
}

pub fn f2(v0: Adt0, v1: Adt61) -> R<Adt63> {
    f5(v0.clone(), v1.clone(), {
        let m13 = v1;
        match m13 {
            Adt61::C0(v2) => {
                f6(v0.clone(), match v0 {
                    Adt0::C0(_, h14, _, _, _, _, _) => {
                        h14
                    }
                }, v2)?
            }
            Adt61::C1(v3) => {
                f7(v0, v3)?
            }
            Adt61::C2(v4, v5, v6, v7, v8) => {
                if if f8(v0.clone(), v4.clone(), v5, v6, v7.clone()) {
                    f9(v8.clone())
                } else {
                    false
                } {
                    f10(v0, v4, v7, v8)?
                } else {
                    Adt63::C0(v0, List::cons(Adt64::C0(Adt65::C6(v7)), List::<Adt64>::nil()))
                }
            }
            Adt61::C3(v9) => {
                Adt63::C0(Adt0::C0({
                    let m18 = {
                        let m17 = f11(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m17 {
                            Adt63::C0(h16, _) => {
                                h16
                            }
                        }
                    };
                    match m18 {
                        Adt0::C0(h15, _, _, _, _, _, _) => {
                            h15
                        }
                    }
                }, {
                    let m22 = {
                        let m21 = f11(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m21 {
                            Adt63::C0(h20, _) => {
                                h20
                            }
                        }
                    };
                    match m22 {
                        Adt0::C0(_, h19, _, _, _, _, _) => {
                            h19
                        }
                    }
                }, {
                    let m26 = {
                        let m25 = f11(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m25 {
                            Adt63::C0(h24, _) => {
                                h24
                            }
                        }
                    };
                    match m26 {
                        Adt0::C0(_, _, h23, _, _, _, _) => {
                            h23
                        }
                    }
                }, {
                    let m30 = {
                        let m29 = f11(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m29 {
                            Adt63::C0(h28, _) => {
                                h28
                            }
                        }
                    };
                    match m30 {
                        Adt0::C0(_, _, _, h27, _, _, _) => {
                            h27
                        }
                    }
                }, {
                    let m34 = {
                        let m33 = f11(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m33 {
                            Adt63::C0(h32, _) => {
                                h32
                            }
                        }
                    };
                    match m34 {
                        Adt0::C0(_, _, _, _, h31, _, _) => {
                            h31
                        }
                    }
                }, f12(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h35, _) => {
                        h35
                    }
                }, v9.clone(), List::<Adt59>::nil()), {
                    let m39 = {
                        let m38 = f11(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m38 {
                            Adt63::C0(h37, _) => {
                                h37
                            }
                        }
                    };
                    match m39 {
                        Adt0::C0(_, _, _, _, _, _, h36) => {
                            h36
                        }
                    }
                }), {
                    let m41 = f11(v0, v9, None::<Adt11>)?;
                    match m41 {
                        Adt63::C0(_, h40) => {
                            h40
                        }
                    }
                })
            }
            Adt61::C4(v10) => {
                f13(v0.clone(), match v0 {
                    Adt0::C0(_, h42, _, _, _, _, _) => {
                        h42
                    }
                }, v10)?
            }
            Adt61::C5 => {
                let m44 = f14(match v0.clone() {
                    Adt0::C0(_, h43, _, _, _, _, _) => {
                        h43
                    }
                });
                match m44 {
                    Ok(v12) => {
                        f15(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h47, _, _, _, _, _) => {
                                h47
                            }
                        }, f17(match v0 {
                            Adt0::C0(h48, _, _, _, _, _, _) => {
                                h48
                            }
                        }, v12)?)
                    }
                    Err(v11) => {
                        f15(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h45, _, _, _, _, _) => {
                                h45
                            }
                        }, f16(match v0 {
                            Adt0::C0(h46, _, _, _, _, _, _) => {
                                h46
                            }
                        }, Adt41::C10(v11)))
                    }
                }
            }
            Adt61::C6(v13) => {
                f18(v0, v13)?
            }
            Adt61::C7(v14) => {
                f19(v0, v14)?
            }
            Adt61::C8(v15, v16) => {
                f20(v0.clone(), v15.clone(), f21(f22(match v0 {
                    Adt0::C0(_, _, _, _, _, h49, _) => {
                        h49
                    }
                }, v15), v16))?
            }
            Adt61::C9(v17, v18, v19) => {
                f20(v0.clone(), v17.clone(), f23(f22(match v0 {
                    Adt0::C0(_, _, _, _, _, h50, _) => {
                        h50
                    }
                }, v17), v18, v19))?
            }
            Adt61::C10(v20, v21, v22, v23) => {
                f24(v0, v20, v21, v22, v23)?
            }
            Adt61::C11(v24, v25, v26) => {
                f25(v0, v24, v25, v26)?
            }
        }
    })
}

pub fn f3(v0: Adt0) -> R<Adt63> {
    let m52 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h51) => {
            h51
        }
    };
    match m52 {
        None => {
            Ok(Adt63::C0(v0, List::<Adt64>::nil()))
        }
        Some(v1) => {
            Ok(Adt63::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h53, _, _, _, _, _, _) => {
                    h53
                }
            }, f26(match v0.clone() {
                Adt0::C0(_, h54, _, _, _, _, _) => {
                    h54
                }
            }, match v1.clone() {
                Adt60::C0(h55, _, _, _, _, _) => {
                    h55
                }
            }, Some(match v1.clone() {
                Adt60::C0(_, _, _, h56, _, _) => {
                    h56
                }
            })), {
                let a58 = match v0.clone() {
                    Adt0::C0(_, _, h57, _, _, _, _) => {
                        h57
                    }
                };
                let a59 = 1u64;
                nat_add(a58, a59)?
            }, match v0.clone() {
                Adt0::C0(_, _, _, h60, _, _, _) => {
                    h60
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h61, _, _) => {
                    h61
                }
            }, f12(match v0 {
                Adt0::C0(_, _, _, _, _, h62, _) => {
                    h62
                }
            }, match v1.clone() {
                Adt60::C0(h63, _, _, _, _, _) => {
                    h63
                }
            }, match v1.clone() {
                Adt60::C0(_, _, _, _, _, h64) => {
                    h64
                }
            }), None::<Adt60>), List::cons(Adt64::C3(v1), List::<Adt64>::nil())))
        }
    }
}

pub fn f4(v0: List<Adt64>, v1: List<Adt64>) -> List<Adt64> {
    let m65 = v0;
    match m65.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f4(v3, v1))
        }
    }
}

pub fn f5(v0: Adt0, v1: Adt61, v2: Adt63) -> R<Adt63> {
    let m71 = {
        let m70 = {
            let m69 = match v2.clone() {
                Adt63::C0(h68, _) => {
                    h68
                }
            };
            match m69 {
                Adt0::C0(h67, _, _, _, _, _, _) => {
                    h67
                }
            }
        };
        match m70 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h66, _, _, _, _, _, _, _, _, _, _) => {
                h66
            }
        }
    };
    if match m71 {
        None => {
            let m77 = {
                let m76 = {
                    let m75 = match v2.clone() {
                        Adt63::C0(h74, _) => {
                            h74
                        }
                    };
                    match m75 {
                        Adt0::C0(h73, _, _, _, _, _, _) => {
                            h73
                        }
                    }
                };
                match m76 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h72, _, _, _, _, _, _, _, _, _) => {
                        h72
                    }
                }
            };
            match m77 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Some(_) => {
            true
        }
    } {
        f27(v0, v2, Adt57::C4)
    } else {
        let m78 = v1;
        match m78 {
            Adt61::C0(_) => {
                f27(v0, v2, Adt57::C1)
            }
            Adt61::C1(_) => {
                Ok(v2)
            }
            Adt61::C2(v7, _, _, _, _) => {
                f27(v0, v2, Adt57::C0(v7))
            }
            Adt61::C3(v12) => {
                f27(v0, v2, Adt57::C0(v12))
            }
            Adt61::C4(_) => {
                Ok(v2)
            }
            Adt61::C5 => {
                f27(v0, v2, Adt57::C2)
            }
            Adt61::C6(v14) => {
                let m79 = v14;
                match m79 {
                    Adt62::C0 => {
                        f27(v0, v2, Adt57::C2)
                    }
                    Adt62::C1(_) => {
                        f27(v0, v2, Adt57::C5)
                    }
                    Adt62::C2 => {
                        f27(v0, v2, Adt57::C5)
                    }
                    Adt62::C3 => {
                        Ok(v2)
                    }
                    Adt62::C4 => {
                        Ok(v2)
                    }
                    Adt62::C5 => {
                        Ok(v2)
                    }
                    Adt62::C6 => {
                        f27(v0, v2, Adt57::C2)
                    }
                    Adt62::C7(_) => {
                        f27(v0, v2, Adt57::C2)
                    }
                    Adt62::C8 => {
                        f27(v0, v2, Adt57::C2)
                    }
                }
            }
            Adt61::C7(_) => {
                f27(v0, v2, Adt57::C2)
            }
            Adt61::C8(v18, _) => {
                f27(v0, v2, Adt57::C0(v18))
            }
            Adt61::C9(v20, _, _) => {
                f27(v0, v2, Adt57::C0(v20))
            }
            Adt61::C10(_, _, _, _) => {
                Ok(v2)
            }
            Adt61::C11(_, _, _) => {
                Ok(v2)
            }
        }
    }
}

pub fn f6(v0: Adt0, v1: Adt53, v2: Adt54) -> R<Adt63> {
    f28(v0, Adt53::C0(v2, match v1.clone() {
        Adt53::C0(_, h80, _, _, _, _, _, _) => {
            h80
        }
    }, match v1.clone() {
        Adt53::C0(_, _, h81, _, _, _, _, _) => {
            h81
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, h82, _, _, _, _) => {
            h82
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, h83, _, _, _) => {
            h83
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, h84, _, _) => {
            h84
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, _, h85, _) => {
            h85
        }
    }, match v1 {
        Adt53::C0(_, _, _, _, _, _, _, h86) => {
            h86
        }
    }))
}

pub fn f7(v0: Adt0, v1: Adt55) -> R<Adt63> {
    let m89 = match v0.clone() {
        Adt0::C0(h88, _, _, _, _, _, _) => {
            h88
        }
    };
    if if match m89 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h87, _, _, _, _, _, _, _) => {
            h87
        }
    } {
        let a93 = {
            let m92 = match v0.clone() {
                Adt0::C0(h91, _, _, _, _, _, _) => {
                    h91
                }
            };
            match m92 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h90, _, _, _, _, _, _) => {
                    h90
                }
            }
        };
        bool_not(a93)
    } else {
        false
    } {
        Ok(Adt63::C0(Adt0::C0(match v0.clone() {
            Adt0::C0(h94, _, _, _, _, _, _) => {
                h94
            }
        }, match v0.clone() {
            Adt0::C0(_, h95, _, _, _, _, _) => {
                h95
            }
        }, {
            let a97 = match v0.clone() {
                Adt0::C0(_, _, h96, _, _, _, _) => {
                    h96
                }
            };
            let a98 = 1u64;
            nat_add(a97, a98)?
        }, Some(v1.clone()), match v0.clone() {
            Adt0::C0(_, _, _, _, h99, _, _) => {
                h99
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, h100, _) => {
                h100
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, h101) => {
                h101
            }
        }), List::cons(Adt64::C1(v1, f29(match v0.clone() {
            Adt0::C0(h102, _, _, _, _, _, _) => {
                h102
            }
        }), {
            let a104 = match v0 {
                Adt0::C0(_, _, h103, _, _, _, _) => {
                    h103
                }
            };
            let a105 = 1u64;
            nat_add(a104, a105)?
        }), List::<Adt64>::nil())))
    } else {
        Ok(Adt63::C0(v0, List::<Adt64>::nil()))
    }
}

pub fn f8(v0: Adt0, v1: Adt55, v2: Adt52, v3: u64, v4: Adt11) -> bool {
    if f30(match v0.clone() {
        Adt0::C0(h106, _, _, _, _, _, _) => {
            h106
        }
    }, v2) {
        let a108 = match v0.clone() {
            Adt0::C0(_, _, h107, _, _, _, _) => {
                h107
            }
        };
        let a109 = v3;
        if nat_eq(a108, a109) {
            let a114 = match v4 {
                Adt11::C0(h110, _, _) => {
                    h110
                }
            };
            let a115 = {
                let m113 = match v0.clone() {
                    Adt0::C0(h112, _, _, _, _, _, _) => {
                        h112
                    }
                };
                match m113 {
                    Adt1::C0(h111, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h111
                    }
                }
            };
            if nat_eq(a114, a115) {
                let m117 = match v0 {
                    Adt0::C0(_, _, _, h116, _, _, _) => {
                        h116
                    }
                };
                match m117 {
                    None => {
                        false
                    }
                    Some(v5) => {
                        f31(v5, v1)
                    }
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f9(p121: List<Adt59>) -> bool {
    let m120 = p121;
    {
        let mut m120 = m120;
        loop {
            let step = {
                let v0 = m120;
                let m118 = v0;
                match m118.uncons() {
                    None => {
                        Err::<List<Adt59>, bool>(true)
                    }
                    Some((v1, v2)) => {
                        if f32(v2.clone(), match v1 {
                            Adt59::C0(h119, _, _) => {
                                h119
                            }
                        }) {
                            Err::<List<Adt59>, bool>(false)
                        } else {
                            Ok::<List<Adt59>, bool>(v2)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m120 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f10(v0: Adt0, v1: Adt55, v2: Adt11, v3: List<Adt59>) -> R<Adt63> {
    Ok(Adt63::C0(Adt0::C0({
        let m125 = {
            let m124 = f11(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m124 {
                Adt63::C0(h123, _) => {
                    h123
                }
            }
        };
        match m125 {
            Adt0::C0(h122, _, _, _, _, _, _) => {
                h122
            }
        }
    }, {
        let m129 = {
            let m128 = f11(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m128 {
                Adt63::C0(h127, _) => {
                    h127
                }
            }
        };
        match m129 {
            Adt0::C0(_, h126, _, _, _, _, _) => {
                h126
            }
        }
    }, {
        let m133 = {
            let m132 = f11(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m132 {
                Adt63::C0(h131, _) => {
                    h131
                }
            }
        };
        match m133 {
            Adt0::C0(_, _, h130, _, _, _, _) => {
                h130
            }
        }
    }, {
        let m137 = {
            let m136 = f11(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m136 {
                Adt63::C0(h135, _) => {
                    h135
                }
            }
        };
        match m137 {
            Adt0::C0(_, _, _, h134, _, _, _) => {
                h134
            }
        }
    }, {
        let m141 = {
            let m140 = f11(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m140 {
                Adt63::C0(h139, _) => {
                    h139
                }
            }
        };
        match m141 {
            Adt0::C0(_, _, _, _, h138, _, _) => {
                h138
            }
        }
    }, f12(match v0.clone() {
        Adt0::C0(_, _, _, _, _, h142, _) => {
            h142
        }
    }, v1.clone(), v3), {
        let m146 = {
            let m145 = f11(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m145 {
                Adt63::C0(h144, _) => {
                    h144
                }
            }
        };
        match m146 {
            Adt0::C0(_, _, _, _, _, _, h143) => {
                h143
            }
        }
    }), {
        let m148 = f11(v0, v1, Some(v2))?;
        match m148 {
            Adt63::C0(_, h147) => {
                h147
            }
        }
    }))
}

pub fn f11(v0: Adt0, v1: Adt55, v2: Option<Adt11>) -> R<Adt63> {
    Ok(Adt63::C0({
        let m151 = f28(v0.clone(), f26(match v0.clone() {
            Adt0::C0(_, h150, _, _, _, _, _) => {
                h150
            }
        }, v1.clone(), v2.clone()))?;
        match m151 {
            Adt63::C0(h149, _) => {
                h149
            }
        }
    }, f33(f34(f35(f36(match v0.clone() {
        Adt0::C0(_, h152, _, _, _, _, _) => {
            h152
        }
    }, v1), v2), {
        let m155 = f37(match v0 {
            Adt0::C0(h154, _, _, _, _, _, _) => {
                h154
            }
        }, Adt68::C1)?;
        match m155 {
            Adt71::C0(_, h153) => {
                h153
            }
        }
    }))))
}

pub fn f12(v0: List<Adt58>, v1: Adt55, v2: List<Adt59>) -> List<Adt58> {
    let m156 = v0;
    match m156.uncons() {
        None => {
            List::cons(Adt58::C0(v1, v2), List::<Adt58>::nil())
        }
        Some((v3, v4)) => {
            if f31(match v3.clone() {
                Adt58::C0(h157, _) => {
                    h157
                }
            }, v1.clone()) {
                List::cons(Adt58::C0(v1, v2), v4)
            } else {
                List::cons(v3, f12(v4, v1, v2))
            }
        }
    }
}

pub fn f13(v0: Adt0, v1: Adt53, v2: Adt13) -> R<Adt63> {
    f28(v0, Adt53::C0(match v1.clone() {
        Adt53::C0(h158, _, _, _, _, _, _, _) => {
            h158
        }
    }, match v1.clone() {
        Adt53::C0(_, h159, _, _, _, _, _, _) => {
            h159
        }
    }, match v1.clone() {
        Adt53::C0(_, _, h160, _, _, _, _, _) => {
            h160
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, h161, _, _, _, _) => {
            h161
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, h162, _, _, _) => {
            h162
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, h163, _, _) => {
            h163
        }
    }, match v1 {
        Adt53::C0(_, _, _, _, _, _, h164, _) => {
            h164
        }
    }, v2))
}

pub fn f14(v0: Adt53) -> Result<Adt9, Adt43> {
    let m166 = match v0.clone() {
        Adt53::C0(h165, _, _, _, _, _, _, _) => {
            h165
        }
    };
    match m166 {
        Adt54::C0 => {
            let m168 = match v0.clone() {
                Adt53::C0(_, h167, _, _, _, _, _, _) => {
                    h167
                }
            };
            match m168 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v1) => {
                    Ok::<Adt9, Adt43>(Adt9::C0(Adt10::C0(v1, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h169) => {
                            h169
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h170, _, _, _, _) => {
                            h170
                        }
                    }))))
                }
            }
        }
        Adt54::C1 => {
            let m172 = match v0.clone() {
                Adt53::C0(_, _, h171, _, _, _, _, _) => {
                    h171
                }
            };
            match m172 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v2) => {
                    Ok::<Adt9, Adt43>(Adt9::C1(Adt15::C0(v2, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h173) => {
                            h173
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h174, _, _, _, _) => {
                            h174
                        }
                    }))))
                }
            }
        }
        Adt54::C2 => {
            let m176 = match v0.clone() {
                Adt53::C0(_, _, h175, _, _, _, _, _) => {
                    h175
                }
            };
            match m176 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v3) => {
                    Ok::<Adt9, Adt43>(Adt9::C2(Adt15::C0(v3, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h177) => {
                            h177
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h178, _, _, _, _) => {
                            h178
                        }
                    }))))
                }
            }
        }
        Adt54::C3 => {
            let m180 = match v0.clone() {
                Adt53::C0(_, _, h179, _, _, _, _, _) => {
                    h179
                }
            };
            match m180 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v4) => {
                    Ok::<Adt9, Adt43>(Adt9::C3(Adt16::C0(v4, match v0.clone() {
                        Adt53::C0(_, _, _, _, h181, _, _, _) => {
                            h181
                        }
                    }, None::<Adt11>, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h182) => {
                            h182
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h183, _, _, _, _) => {
                            h183
                        }
                    }))))
                }
            }
        }
        Adt54::C4 => {
            let m185 = match v0.clone() {
                Adt53::C0(_, h184, _, _, _, _, _, _) => {
                    h184
                }
            };
            match m185 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v5) => {
                    let m187 = match v0.clone() {
                        Adt53::C0(_, _, _, _, _, h186, _, _) => {
                            h186
                        }
                    };
                    match m187 {
                        None => {
                            Err::<Adt9, Adt43>(Adt43::C4)
                        }
                        Some(v6) => {
                            Ok::<Adt9, Adt43>(Adt9::C4(Adt17::C0(v5, v6, Adt12::C0(match v0.clone() {
                                Adt53::C0(_, _, _, _, _, _, _, h188) => {
                                    h188
                                }
                            }, match v0 {
                                Adt53::C0(_, _, _, h189, _, _, _, _) => {
                                    h189
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt54::C5 => {
            let m191 = match v0.clone() {
                Adt53::C0(_, h190, _, _, _, _, _, _) => {
                    h190
                }
            };
            match m191 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v7) => {
                    Ok::<Adt9, Adt43>(Adt9::C5(Adt18::C0(v7, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h192) => {
                            h192
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h193, _, _, _, _) => {
                            h193
                        }
                    }))))
                }
            }
        }
        Adt54::C6 => {
            let m195 = match v0.clone() {
                Adt53::C0(_, h194, _, _, _, _, _, _) => {
                    h194
                }
            };
            match m195 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v8) => {
                    Ok::<Adt9, Adt43>(Adt9::C6(Adt19::C0(v8, match v0.clone() {
                        Adt53::C0(_, _, h196, _, _, _, _, _) => {
                            h196
                        }
                    }, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h197) => {
                            h197
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h198, _, _, _, _) => {
                            h198
                        }
                    }))))
                }
            }
        }
        Adt54::C7 => {
            let m200 = match v0.clone() {
                Adt53::C0(_, _, h199, _, _, _, _, _) => {
                    h199
                }
            };
            match m200 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v9) => {
                    let m202 = match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, h201, _) => {
                            h201
                        }
                    };
                    match m202 {
                        None => {
                            Err::<Adt9, Adt43>(Adt43::C16)
                        }
                        Some(v10) => {
                            Ok::<Adt9, Adt43>(Adt9::C7(Adt20::C0(v9, v10, match v0.clone() {
                                Adt53::C0(_, _, _, _, h203, _, _, _) => {
                                    h203
                                }
                            }, Adt12::C0(match v0.clone() {
                                Adt53::C0(_, _, _, _, _, _, _, h204) => {
                                    h204
                                }
                            }, match v0 {
                                Adt53::C0(_, _, _, h205, _, _, _, _) => {
                                    h205
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt54::C8 => {
            let m207 = match v0.clone() {
                Adt53::C0(_, h206, _, _, _, _, _, _) => {
                    h206
                }
            };
            match m207 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v11) => {
                    Ok::<Adt9, Adt43>(Adt9::C8(Adt21::C0(v11, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h208) => {
                            h208
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h209, _, _, _, _) => {
                            h209
                        }
                    }))))
                }
            }
        }
        Adt54::C9 => {
            let m211 = match v0.clone() {
                Adt53::C0(_, h210, _, _, _, _, _, _) => {
                    h210
                }
            };
            match m211 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v12) => {
                    Ok::<Adt9, Adt43>(Adt9::C9(Adt21::C0(v12, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h212) => {
                            h212
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h213, _, _, _, _) => {
                            h213
                        }
                    }))))
                }
            }
        }
    }
}

pub fn f15(v0: Adt0, v1: Adt53, v2: Adt71) -> Adt63 {
    Adt63::C0(Adt0::C0(match v2.clone() {
        Adt71::C0(h214, _) => {
            h214
        }
    }, v1, match v0.clone() {
        Adt0::C0(_, _, h215, _, _, _, _) => {
            h215
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, h216, _, _, _) => {
            h216
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, h217, _, _) => {
            h217
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, _, h218, _) => {
            h218
        }
    }, match v0 {
        Adt0::C0(_, _, _, _, _, _, h219) => {
            h219
        }
    }), f33(match v2 {
        Adt71::C0(_, h220) => {
            h220
        }
    }))
}

pub fn f16(v0: Adt1, v1: Adt41) -> Adt71 {
    Adt71::C0(Adt1::C0(match v0.clone() {
        Adt1::C0(h221, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h221
        }
    }, match v0.clone() {
        Adt1::C0(_, h222, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h222
        }
    }, match v0.clone() {
        Adt1::C0(_, _, h223, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h223
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, h224, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h224
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, h225, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h225
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, h226, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h226
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h227, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h227
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, h228, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h228
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, h229, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h229
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, h230, _, _, _, _, _, _, _, _, _, _, _) => {
            h230
        }
    }, Some(v1), match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h231, _, _, _, _, _, _, _, _, _) => {
            h231
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h232, _, _, _, _, _, _, _, _) => {
            h232
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h233, _, _, _, _, _, _, _) => {
            h233
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h234, _, _, _, _, _, _) => {
            h234
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h235, _, _, _, _, _) => {
            h235
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h236, _, _, _, _) => {
            h236
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h237, _, _, _) => {
            h237
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h238, _, _) => {
            h238
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h239, _) => {
            h239
        }
    }, match v0 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h240) => {
            h240
        }
    }), List::<Adt65>::nil())
}

pub fn f17(v0: Adt1, v1: Adt9) -> R<Adt71> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h241, _, _, _, _, _, _) => {
            h241
        }
    } {
        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h242, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h242
            }
        }, match v0.clone() {
            Adt1::C0(_, h243, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h243
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h244, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h244
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h245, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h245
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h246, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h246
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h247, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h247
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h248, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h248
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h249, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h249
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h250, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h250
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h251, _, _, _, _, _, _, _, _, _, _, _) => {
                h251
            }
        }, Some(Adt41::C10(Adt43::C1)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h252, _, _, _, _, _, _, _, _, _) => {
                h252
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h253, _, _, _, _, _, _, _, _) => {
                h253
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h254, _, _, _, _, _, _, _) => {
                h254
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h255, _, _, _, _, _, _) => {
                h255
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h256, _, _, _, _, _) => {
                h256
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h257, _, _, _, _) => {
                h257
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h258, _, _, _) => {
                h258
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h259, _, _) => {
                h259
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h260, _) => {
                h260
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h261) => {
                h261
            }
        }), List::<Adt65>::nil()))
    } else {
        let a263 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h262, _, _, _, _, _, _, _) => {
                h262
            }
        };
        if bool_not(a263) {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h264, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h264
                }
            }, match v0.clone() {
                Adt1::C0(_, h265, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h265
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h266, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h266
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h267, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h267
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h268, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h268
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h269, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h269
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h270, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h270
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h271, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h271
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h272, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h272
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h273, _, _, _, _, _, _, _, _, _, _, _) => {
                    h273
                }
            }, Some(Adt41::C10(Adt43::C2)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h274, _, _, _, _, _, _, _, _, _) => {
                    h274
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h275, _, _, _, _, _, _, _, _) => {
                    h275
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h276, _, _, _, _, _, _, _) => {
                    h276
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h277, _, _, _, _, _, _) => {
                    h277
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h278, _, _, _, _, _) => {
                    h278
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h279, _, _, _, _) => {
                    h279
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h280, _, _, _) => {
                    h280
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h281, _, _) => {
                    h281
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h282, _) => {
                    h282
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h283) => {
                    h283
                }
            }), List::<Adt65>::nil()))
        } else {
            let m286 = match v0.clone() {
                Adt1::C0(_, h285, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h285
                }
            };
            if match m286 {
                Adt2::C0(_, _, h284, _, _, _) => {
                    h284
                }
            } {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h287, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h287
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h288, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h288
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h289, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h289
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h290, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h290
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h291, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h291
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h292, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h292
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h293, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h293
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h294, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h294
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h295, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h295
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h296, _, _, _, _, _, _, _, _, _, _, _) => {
                        h296
                    }
                }, Some(Adt41::C10(Adt43::C0)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h297, _, _, _, _, _, _, _, _, _) => {
                        h297
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h298, _, _, _, _, _, _, _, _) => {
                        h298
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h299, _, _, _, _, _, _, _) => {
                        h299
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h300, _, _, _, _, _, _) => {
                        h300
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h301, _, _, _, _, _) => {
                        h301
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h302, _, _, _, _) => {
                        h302
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h303, _, _, _) => {
                        h303
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h304, _, _) => {
                        h304
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h305, _) => {
                        h305
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h306) => {
                        h306
                    }
                }), List::<Adt65>::nil()))
            } else {
                if match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h307, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h307
                    }
                } {
                    Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h308, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h308
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, h309, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h309
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, h310, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h310
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h311, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h311
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h312, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h312
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h313, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h313
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h314, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h314
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h315, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h315
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, h316, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h316
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, h317, _, _, _, _, _, _, _, _, _, _, _) => {
                            h317
                        }
                    }, Some(Adt41::C10(Adt43::C6)), match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h318, _, _, _, _, _, _, _, _, _) => {
                            h318
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h319, _, _, _, _, _, _, _, _) => {
                            h319
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h320, _, _, _, _, _, _, _) => {
                            h320
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h321, _, _, _, _, _, _) => {
                            h321
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h322, _, _, _, _, _) => {
                            h322
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h323, _, _, _, _) => {
                            h323
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h324, _, _, _) => {
                            h324
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h325, _, _) => {
                            h325
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h326, _) => {
                            h326
                        }
                    }, match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h327) => {
                            h327
                        }
                    }), List::<Adt65>::nil()))
                } else {
                    Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h328, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h328
                        }
                    }, f38(match v0.clone() {
                        Adt1::C0(_, h329, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h329
                        }
                    })?, f39(), f40(), Some(v1.clone()), None::<Adt22>, Adt40::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h330, _, _, _, _, _, _, _) => {
                            h330
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h331, _, _, _, _, _, _) => {
                            h331
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h332, _, _, _, _, _) => {
                            h332
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h333, _, _, _, _) => {
                            h333
                        }
                    }, true, f41(), None::<Adt23>, f42(v0.clone())), f34(List::cons(Adt65::C0(f29(Adt1::C0(match v0.clone() {
                        Adt1::C0(h334, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h334
                        }
                    }, f38(match v0.clone() {
                        Adt1::C0(_, h335, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h335
                        }
                    })?, f39(), f40(), Some(v1.clone()), None::<Adt22>, Adt40::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h336, _, _, _, _, _, _, _) => {
                            h336
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h337, _, _, _, _, _, _) => {
                            h337
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h338, _, _, _, _, _) => {
                            h338
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h339, _, _, _, _) => {
                            h339
                        }
                    }, true, f41(), None::<Adt23>, f42(v0.clone()))), v1), List::<Adt65>::nil()), f43(v0))))
                }
            }
        }
    }
}

pub fn f18(v0: Adt0, v1: Adt62) -> R<Adt63> {
    let m340 = v1;
    match m340 {
        Adt62::C0 => {
            Ok(f15(v0.clone(), match v0.clone() {
                Adt0::C0(_, h341, _, _, _, _, _) => {
                    h341
                }
            }, f37(match v0 {
                Adt0::C0(h342, _, _, _, _, _, _) => {
                    h342
                }
            }, Adt68::C2)?))
        }
        Adt62::C1(v2) => {
            Ok(f15(v0.clone(), match v0.clone() {
                Adt0::C0(_, h343, _, _, _, _, _) => {
                    h343
                }
            }, f37(match v0 {
                Adt0::C0(h344, _, _, _, _, _, _) => {
                    h344
                }
            }, Adt68::C3(v2))?))
        }
        Adt62::C2 => {
            Ok(f15(v0.clone(), match v0.clone() {
                Adt0::C0(_, h345, _, _, _, _, _) => {
                    h345
                }
            }, f37(match v0 {
                Adt0::C0(h346, _, _, _, _, _, _) => {
                    h346
                }
            }, Adt68::C4)?))
        }
        Adt62::C3 => {
            f44(v0)
        }
        Adt62::C4 => {
            f44(v0)
        }
        Adt62::C5 => {
            f44(v0)
        }
        Adt62::C6 => {
            Ok(f15(v0.clone(), match v0.clone() {
                Adt0::C0(_, h347, _, _, _, _, _) => {
                    h347
                }
            }, f37(match v0 {
                Adt0::C0(h348, _, _, _, _, _, _) => {
                    h348
                }
            }, Adt68::C18)?))
        }
        Adt62::C7(v3) => {
            Ok(f15(v0.clone(), match v0.clone() {
                Adt0::C0(_, h349, _, _, _, _, _) => {
                    h349
                }
            }, f37(match v0 {
                Adt0::C0(h350, _, _, _, _, _, _) => {
                    h350
                }
            }, Adt68::C14(v3))?))
        }
        Adt62::C8 => {
            Ok(f15(v0.clone(), match v0.clone() {
                Adt0::C0(_, h351, _, _, _, _, _) => {
                    h351
                }
            }, f37(match v0 {
                Adt0::C0(h352, _, _, _, _, _, _) => {
                    h352
                }
            }, Adt68::C20)?))
        }
    }
}

pub fn f19(v0: Adt0, v1: u64) -> R<Adt63> {
    let m357 = {
        let m356 = match v0.clone() {
            Adt0::C0(h355, _, _, _, _, _, _) => {
                h355
            }
        };
        match m356 {
            Adt1::C0(_, h354, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h354
            }
        }
    };
    if match m357 {
        Adt2::C0(_, _, h353, _, _, _) => {
            h353
        }
    } {
        Ok(f15(v0.clone(), match v0.clone() {
            Adt0::C0(_, h358, _, _, _, _, _) => {
                h358
            }
        }, f45(match v0 {
            Adt0::C0(h359, _, _, _, _, _, _) => {
                h359
            }
        }, v1)))
    } else {
        let m363 = {
            let m362 = match v0.clone() {
                Adt0::C0(h361, _, _, _, _, _, _) => {
                    h361
                }
            };
            match m362 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h360, _, _, _, _, _, _, _, _) => {
                    h360
                }
            }
        };
        match m363 {
            None => {
                Ok(f15(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h364, _, _, _, _, _) => {
                        h364
                    }
                }, f16(match v0 {
                    Adt0::C0(h365, _, _, _, _, _, _) => {
                        h365
                    }
                }, Adt41::C10(Adt43::C4))))
            }
            Some(v2) => {
                let m369 = {
                    let m368 = match v0.clone() {
                        Adt0::C0(_, h367, _, _, _, _, _) => {
                            h367
                        }
                    };
                    match m368 {
                        Adt53::C0(_, h366, _, _, _, _, _, _) => {
                            h366
                        }
                    }
                };
                match m369 {
                    None => {
                        Ok(f15(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h370, _, _, _, _, _) => {
                                h370
                            }
                        }, f16(match v0 {
                            Adt0::C0(h371, _, _, _, _, _, _) => {
                                h371
                            }
                        }, Adt41::C10(Adt43::C14))))
                    }
                    Some(v3) => {
                        Ok(f15(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h372, _, _, _, _, _) => {
                                h372
                            }
                        }, f46(match v0.clone() {
                            Adt0::C0(h373, _, _, _, _, _, _) => {
                                h373
                            }
                        }, Adt17::C0(v3, v2, Adt12::C0(Adt13::C0({
                            let m378 = {
                                let m377 = match v0.clone() {
                                    Adt0::C0(_, h376, _, _, _, _, _) => {
                                        h376
                                    }
                                };
                                match m377 {
                                    Adt53::C0(_, _, _, _, _, _, _, h375) => {
                                        h375
                                    }
                                }
                            };
                            match m378 {
                                Adt13::C0(h374, _, _, _, _, _, _) => {
                                    h374
                                }
                            }
                        }, {
                            let m383 = {
                                let m382 = match v0.clone() {
                                    Adt0::C0(_, h381, _, _, _, _, _) => {
                                        h381
                                    }
                                };
                                match m382 {
                                    Adt53::C0(_, _, _, _, _, _, _, h380) => {
                                        h380
                                    }
                                }
                            };
                            match m383 {
                                Adt13::C0(_, h379, _, _, _, _, _) => {
                                    h379
                                }
                            }
                        }, {
                            let m388 = {
                                let m387 = match v0.clone() {
                                    Adt0::C0(_, h386, _, _, _, _, _) => {
                                        h386
                                    }
                                };
                                match m387 {
                                    Adt53::C0(_, _, _, _, _, _, _, h385) => {
                                        h385
                                    }
                                }
                            };
                            match m388 {
                                Adt13::C0(_, _, h384, _, _, _, _) => {
                                    h384
                                }
                            }
                        }, {
                            let a394 = {
                                let m393 = {
                                    let m392 = match v0.clone() {
                                        Adt0::C0(_, h391, _, _, _, _, _) => {
                                            h391
                                        }
                                    };
                                    match m392 {
                                        Adt53::C0(_, _, _, _, _, _, _, h390) => {
                                            h390
                                        }
                                    }
                                };
                                match m393 {
                                    Adt13::C0(_, _, _, h389, _, _, _) => {
                                        h389
                                    }
                                }
                            };
                            let a395 = v1;
                            nat_add(a394, a395)?
                        }, {
                            let m400 = {
                                let m399 = match v0.clone() {
                                    Adt0::C0(_, h398, _, _, _, _, _) => {
                                        h398
                                    }
                                };
                                match m399 {
                                    Adt53::C0(_, _, _, _, _, _, _, h397) => {
                                        h397
                                    }
                                }
                            };
                            match m400 {
                                Adt13::C0(_, _, _, _, h396, _, _) => {
                                    h396
                                }
                            }
                        }, {
                            let m405 = {
                                let m404 = match v0.clone() {
                                    Adt0::C0(_, h403, _, _, _, _, _) => {
                                        h403
                                    }
                                };
                                match m404 {
                                    Adt53::C0(_, _, _, _, _, _, _, h402) => {
                                        h402
                                    }
                                }
                            };
                            match m405 {
                                Adt13::C0(_, _, _, _, _, h401, _) => {
                                    h401
                                }
                            }
                        }, {
                            let m410 = {
                                let m409 = match v0.clone() {
                                    Adt0::C0(_, h408, _, _, _, _, _) => {
                                        h408
                                    }
                                };
                                match m409 {
                                    Adt53::C0(_, _, _, _, _, _, _, h407) => {
                                        h407
                                    }
                                }
                            };
                            match m410 {
                                Adt13::C0(_, _, _, _, _, _, h406) => {
                                    h406
                                }
                            }
                        }), {
                            let m413 = match v0 {
                                Adt0::C0(_, h412, _, _, _, _, _) => {
                                    h412
                                }
                            };
                            match m413 {
                                Adt53::C0(_, _, _, h411, _, _, _, _) => {
                                    h411
                                }
                            }
                        })))?))
                    }
                }
            }
        }
    }
}

pub fn f20(v0: Adt0, v1: Adt55, v2: List<Adt59>) -> R<Adt63> {
    let m415 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h414) => {
            h414
        }
    };
    match m415 {
        None => {
            let m417 = f36(match v0.clone() {
                Adt0::C0(_, h416, _, _, _, _, _) => {
                    h416
                }
            }, v1.clone());
            match m417 {
                None => {
                    Ok(Adt63::C0(v0, List::<Adt64>::nil()))
                }
                Some(v4) => {
                    Ok(Adt63::C0(Adt0::C0({
                        let m420 = f37(match v0.clone() {
                            Adt0::C0(h419, _, _, _, _, _, _) => {
                                h419
                            }
                        }, Adt68::C1)?;
                        match m420 {
                            Adt71::C0(h418, _) => {
                                h418
                            }
                        }
                    }, f26(match v0.clone() {
                        Adt0::C0(_, h421, _, _, _, _, _) => {
                            h421
                        }
                    }, v1.clone(), None::<Adt11>), {
                        let a423 = match v0.clone() {
                            Adt0::C0(_, _, h422, _, _, _, _) => {
                                h422
                            }
                        };
                        let a424 = 1u64;
                        nat_add(a423, a424)?
                    }, None::<Adt55>, match v0.clone() {
                        Adt0::C0(_, _, _, _, h425, _, _) => {
                            h425
                        }
                    }, f12(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h426, _) => {
                            h426
                        }
                    }, v1.clone(), v2.clone()), Some(Adt60::C0(v1.clone(), f29({
                        let m429 = f37(match v0.clone() {
                            Adt0::C0(h428, _, _, _, _, _, _) => {
                                h428
                            }
                        }, Adt68::C1)?;
                        match m429 {
                            Adt71::C0(h427, _) => {
                                h427
                            }
                        }
                    }), {
                        let a431 = match v0.clone() {
                            Adt0::C0(_, _, h430, _, _, _, _) => {
                                h430
                            }
                        };
                        let a432 = 1u64;
                        nat_add(a431, a432)?
                    }, v4.clone(), v2.clone(), f22(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h433, _) => {
                            h433
                        }
                    }, v1.clone())))), List::cons(Adt64::C2(Adt60::C0(v1.clone(), f29({
                        let m436 = f37(match v0.clone() {
                            Adt0::C0(h435, _, _, _, _, _, _) => {
                                h435
                            }
                        }, Adt68::C1)?;
                        match m436 {
                            Adt71::C0(h434, _) => {
                                h434
                            }
                        }
                    }), {
                        let a438 = match v0.clone() {
                            Adt0::C0(_, _, h437, _, _, _, _) => {
                                h437
                            }
                        };
                        let a439 = 1u64;
                        nat_add(a438, a439)?
                    }, v4, v2, f22(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h440, _) => {
                            h440
                        }
                    }, v1))), f33({
                        let m443 = f37(match v0 {
                            Adt0::C0(h442, _, _, _, _, _, _) => {
                                h442
                            }
                        }, Adt68::C1)?;
                        match m443 {
                            Adt71::C0(_, h441) => {
                                h441
                            }
                        }
                    }))))
                }
            }
        }
        Some(_) => {
            Ok(Adt63::C0(v0, List::<Adt64>::nil()))
        }
    }
}

pub fn f21(v0: List<Adt59>, v1: u64) -> List<Adt59> {
    let m444 = v0;
    match m444.uncons() {
        None => {
            List::<Adt59>::nil()
        }
        Some((v2, v3)) => {
            let a446 = match v2.clone() {
                Adt59::C0(h445, _, _) => {
                    h445
                }
            };
            let a447 = v1;
            if nat_eq(a446, a447) {
                v3
            } else {
                List::cons(v2, f21(v3, v1))
            }
        }
    }
}

pub fn f22(p452: List<Adt58>, v1: Adt55) -> List<Adt59> {
    let m451 = p452;
    {
        let mut m451 = m451;
        loop {
            let step = {
                let v0 = m451;
                let m448 = v0;
                match m448.uncons() {
                    None => {
                        Err::<List<Adt58>, List<Adt59>>(List::<Adt59>::nil())
                    }
                    Some((v2, v3)) => {
                        if f31(match v2.clone() {
                            Adt58::C0(h449, _) => {
                                h449
                            }
                        }, v1.clone()) {
                            match v2 {
                                Adt58::C0(_, h450) => {
                                    Err::<List<Adt58>, List<Adt59>>(h450)
                                }
                            }
                        } else {
                            Ok::<List<Adt58>, List<Adt59>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m451 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f23(v0: List<Adt59>, v1: u64, v2: u64) -> List<Adt59> {
    let m453 = f47(v0.clone(), v1);
    match m453 {
        None => {
            v0
        }
        Some(v3) => {
            f48(f21(v0, v1), v2, v3)
        }
    }
}

pub fn f24(v0: Adt0, v1: Adt52, v2: u64, v3: Adt11, v4: List<Adt59>) -> R<Adt63> {
    let m455 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h454) => {
            h454
        }
    };
    match m455 {
        None => {
            Ok(Adt63::C0(v0, List::cons(Adt64::C0(Adt65::C6(v3)), List::<Adt64>::nil())))
        }
        Some(v5) => {
            if if f30(match v0.clone() {
                Adt0::C0(h456, _, _, _, _, _, _) => {
                    h456
                }
            }, v1) {
                let a458 = match v5.clone() {
                    Adt60::C0(_, _, h457, _, _, _) => {
                        h457
                    }
                };
                let a459 = v2;
                if nat_eq(a458, a459) {
                    let a464 = match v3.clone() {
                        Adt11::C0(h460, _, _) => {
                            h460
                        }
                    };
                    let a465 = {
                        let m463 = match v0.clone() {
                            Adt0::C0(h462, _, _, _, _, _, _) => {
                                h462
                            }
                        };
                        match m463 {
                            Adt1::C0(h461, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h461
                            }
                        }
                    };
                    if nat_eq(a464, a465) {
                        if f9(v4.clone()) {
                            f49(match v5.clone() {
                                Adt60::C0(_, _, _, _, h466, _) => {
                                    h466
                                }
                            }, v4.clone())
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(Adt63::C0(Adt0::C0({
                    let m471 = {
                        let m470 = f10(v0.clone(), match v5.clone() {
                            Adt60::C0(h469, _, _, _, _, _) => {
                                h469
                            }
                        }, v3.clone(), v4.clone())?;
                        match m470 {
                            Adt63::C0(h468, _) => {
                                h468
                            }
                        }
                    };
                    match m471 {
                        Adt0::C0(h467, _, _, _, _, _, _) => {
                            h467
                        }
                    }
                }, {
                    let m476 = {
                        let m475 = f10(v0.clone(), match v5.clone() {
                            Adt60::C0(h474, _, _, _, _, _) => {
                                h474
                            }
                        }, v3.clone(), v4.clone())?;
                        match m475 {
                            Adt63::C0(h473, _) => {
                                h473
                            }
                        }
                    };
                    match m476 {
                        Adt0::C0(_, h472, _, _, _, _, _) => {
                            h472
                        }
                    }
                }, {
                    let m481 = {
                        let m480 = f10(v0.clone(), match v5.clone() {
                            Adt60::C0(h479, _, _, _, _, _) => {
                                h479
                            }
                        }, v3.clone(), v4.clone())?;
                        match m480 {
                            Adt63::C0(h478, _) => {
                                h478
                            }
                        }
                    };
                    match m481 {
                        Adt0::C0(_, _, h477, _, _, _, _) => {
                            h477
                        }
                    }
                }, {
                    let m486 = {
                        let m485 = f10(v0.clone(), match v5.clone() {
                            Adt60::C0(h484, _, _, _, _, _) => {
                                h484
                            }
                        }, v3.clone(), v4.clone())?;
                        match m485 {
                            Adt63::C0(h483, _) => {
                                h483
                            }
                        }
                    };
                    match m486 {
                        Adt0::C0(_, _, _, h482, _, _, _) => {
                            h482
                        }
                    }
                }, {
                    let m491 = {
                        let m490 = f10(v0.clone(), match v5.clone() {
                            Adt60::C0(h489, _, _, _, _, _) => {
                                h489
                            }
                        }, v3.clone(), v4.clone())?;
                        match m490 {
                            Adt63::C0(h488, _) => {
                                h488
                            }
                        }
                    };
                    match m491 {
                        Adt0::C0(_, _, _, _, h487, _, _) => {
                            h487
                        }
                    }
                }, {
                    let m496 = {
                        let m495 = f10(v0.clone(), match v5.clone() {
                            Adt60::C0(h494, _, _, _, _, _) => {
                                h494
                            }
                        }, v3.clone(), v4.clone())?;
                        match m495 {
                            Adt63::C0(h493, _) => {
                                h493
                            }
                        }
                    };
                    match m496 {
                        Adt0::C0(_, _, _, _, _, h492, _) => {
                            h492
                        }
                    }
                }, None::<Adt60>), List::cons(Adt64::C0(Adt65::C6(match v5.clone() {
                    Adt60::C0(_, _, _, h497, _, _) => {
                        h497
                    }
                })), {
                    let m500 = f10(v0, match v5 {
                        Adt60::C0(h499, _, _, _, _, _) => {
                            h499
                        }
                    }, v3, v4)?;
                    match m500 {
                        Adt63::C0(_, h498) => {
                            h498
                        }
                    }
                })))
            } else {
                Ok(Adt63::C0(v0, List::cons(Adt64::C0(Adt65::C6(v3)), List::<Adt64>::nil())))
            }
        }
    }
}

pub fn f25(v0: Adt0, v1: Adt52, v2: u64, v3: Str) -> R<Adt63> {
    let m502 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h501) => {
            h501
        }
    };
    match m502 {
        None => {
            Ok(Adt63::C0(v0, List::<Adt64>::nil()))
        }
        Some(v4) => {
            if if f30(match v0.clone() {
                Adt0::C0(h503, _, _, _, _, _, _) => {
                    h503
                }
            }, v1) {
                let a505 = match v4.clone() {
                    Adt60::C0(_, _, h504, _, _, _) => {
                        h504
                    }
                };
                let a506 = v2;
                nat_eq(a505, a506)
            } else {
                false
            } {
                Ok(Adt63::C0(Adt0::C0({
                    let m509 = f16(match v0.clone() {
                        Adt0::C0(h508, _, _, _, _, _, _) => {
                            h508
                        }
                    }, Adt41::C8(v3));
                    match m509 {
                        Adt71::C0(h507, _) => {
                            h507
                        }
                    }
                }, {
                    let m523 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h511, _, _, _, _, _, _) => {
                            h511
                        }
                    }, f26(match v0.clone() {
                        Adt0::C0(_, h512, _, _, _, _, _) => {
                            h512
                        }
                    }, match v4.clone() {
                        Adt60::C0(h513, _, _, _, _, _) => {
                            h513
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h514, _, _) => {
                            h514
                        }
                    })), {
                        let a516 = match v0.clone() {
                            Adt0::C0(_, _, h515, _, _, _, _) => {
                                h515
                            }
                        };
                        let a517 = 1u64;
                        nat_add(a516, a517)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h518, _, _, _) => {
                            h518
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h519, _, _) => {
                            h519
                        }
                    }, f12(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h520, _) => {
                            h520
                        }
                    }, match v4.clone() {
                        Adt60::C0(h521, _, _, _, _, _) => {
                            h521
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h522) => {
                            h522
                        }
                    }), None::<Adt60>);
                    match m523 {
                        Adt0::C0(_, h510, _, _, _, _, _) => {
                            h510
                        }
                    }
                }, {
                    let m537 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h525, _, _, _, _, _, _) => {
                            h525
                        }
                    }, f26(match v0.clone() {
                        Adt0::C0(_, h526, _, _, _, _, _) => {
                            h526
                        }
                    }, match v4.clone() {
                        Adt60::C0(h527, _, _, _, _, _) => {
                            h527
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h528, _, _) => {
                            h528
                        }
                    })), {
                        let a530 = match v0.clone() {
                            Adt0::C0(_, _, h529, _, _, _, _) => {
                                h529
                            }
                        };
                        let a531 = 1u64;
                        nat_add(a530, a531)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h532, _, _, _) => {
                            h532
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h533, _, _) => {
                            h533
                        }
                    }, f12(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h534, _) => {
                            h534
                        }
                    }, match v4.clone() {
                        Adt60::C0(h535, _, _, _, _, _) => {
                            h535
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h536) => {
                            h536
                        }
                    }), None::<Adt60>);
                    match m537 {
                        Adt0::C0(_, _, h524, _, _, _, _) => {
                            h524
                        }
                    }
                }, {
                    let m551 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h539, _, _, _, _, _, _) => {
                            h539
                        }
                    }, f26(match v0.clone() {
                        Adt0::C0(_, h540, _, _, _, _, _) => {
                            h540
                        }
                    }, match v4.clone() {
                        Adt60::C0(h541, _, _, _, _, _) => {
                            h541
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h542, _, _) => {
                            h542
                        }
                    })), {
                        let a544 = match v0.clone() {
                            Adt0::C0(_, _, h543, _, _, _, _) => {
                                h543
                            }
                        };
                        let a545 = 1u64;
                        nat_add(a544, a545)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h546, _, _, _) => {
                            h546
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h547, _, _) => {
                            h547
                        }
                    }, f12(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h548, _) => {
                            h548
                        }
                    }, match v4.clone() {
                        Adt60::C0(h549, _, _, _, _, _) => {
                            h549
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h550) => {
                            h550
                        }
                    }), None::<Adt60>);
                    match m551 {
                        Adt0::C0(_, _, _, h538, _, _, _) => {
                            h538
                        }
                    }
                }, {
                    let m565 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h553, _, _, _, _, _, _) => {
                            h553
                        }
                    }, f26(match v0.clone() {
                        Adt0::C0(_, h554, _, _, _, _, _) => {
                            h554
                        }
                    }, match v4.clone() {
                        Adt60::C0(h555, _, _, _, _, _) => {
                            h555
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h556, _, _) => {
                            h556
                        }
                    })), {
                        let a558 = match v0.clone() {
                            Adt0::C0(_, _, h557, _, _, _, _) => {
                                h557
                            }
                        };
                        let a559 = 1u64;
                        nat_add(a558, a559)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h560, _, _, _) => {
                            h560
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h561, _, _) => {
                            h561
                        }
                    }, f12(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h562, _) => {
                            h562
                        }
                    }, match v4.clone() {
                        Adt60::C0(h563, _, _, _, _, _) => {
                            h563
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h564) => {
                            h564
                        }
                    }), None::<Adt60>);
                    match m565 {
                        Adt0::C0(_, _, _, _, h552, _, _) => {
                            h552
                        }
                    }
                }, {
                    let m579 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h567, _, _, _, _, _, _) => {
                            h567
                        }
                    }, f26(match v0.clone() {
                        Adt0::C0(_, h568, _, _, _, _, _) => {
                            h568
                        }
                    }, match v4.clone() {
                        Adt60::C0(h569, _, _, _, _, _) => {
                            h569
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h570, _, _) => {
                            h570
                        }
                    })), {
                        let a572 = match v0.clone() {
                            Adt0::C0(_, _, h571, _, _, _, _) => {
                                h571
                            }
                        };
                        let a573 = 1u64;
                        nat_add(a572, a573)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h574, _, _, _) => {
                            h574
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h575, _, _) => {
                            h575
                        }
                    }, f12(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h576, _) => {
                            h576
                        }
                    }, match v4.clone() {
                        Adt60::C0(h577, _, _, _, _, _) => {
                            h577
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h578) => {
                            h578
                        }
                    }), None::<Adt60>);
                    match m579 {
                        Adt0::C0(_, _, _, _, _, h566, _) => {
                            h566
                        }
                    }
                }, {
                    let m593 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h581, _, _, _, _, _, _) => {
                            h581
                        }
                    }, f26(match v0.clone() {
                        Adt0::C0(_, h582, _, _, _, _, _) => {
                            h582
                        }
                    }, match v4.clone() {
                        Adt60::C0(h583, _, _, _, _, _) => {
                            h583
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h584, _, _) => {
                            h584
                        }
                    })), {
                        let a586 = match v0.clone() {
                            Adt0::C0(_, _, h585, _, _, _, _) => {
                                h585
                            }
                        };
                        let a587 = 1u64;
                        nat_add(a586, a587)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h588, _, _, _) => {
                            h588
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h589, _, _) => {
                            h589
                        }
                    }, f12(match v0 {
                        Adt0::C0(_, _, _, _, _, h590, _) => {
                            h590
                        }
                    }, match v4.clone() {
                        Adt60::C0(h591, _, _, _, _, _) => {
                            h591
                        }
                    }, match v4 {
                        Adt60::C0(_, _, _, _, _, h592) => {
                            h592
                        }
                    }), None::<Adt60>);
                    match m593 {
                        Adt0::C0(_, _, _, _, _, _, h580) => {
                            h580
                        }
                    }
                }), List::<Adt64>::nil()))
            } else {
                Ok(Adt63::C0(v0, List::<Adt64>::nil()))
            }
        }
    }
}

pub fn f26(v0: Adt53, v1: Adt55, v2: Option<Adt11>) -> Adt53 {
    let m594 = v1;
    match m594 {
        Adt55::C0 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h595, _, _, _, _, _, _, _) => {
                    h595
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, h596, _, _, _, _, _) => {
                    h596
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h597, _, _, _, _) => {
                    h597
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h598, _, _, _) => {
                    h598
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h599, _, _) => {
                    h599
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h600, _) => {
                    h600
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h601) => {
                    h601
                }
            })
        }
        Adt55::C1 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h602, _, _, _, _, _, _, _) => {
                    h602
                }
            }, match v0.clone() {
                Adt53::C0(_, h603, _, _, _, _, _, _) => {
                    h603
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, h604, _, _, _, _) => {
                    h604
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h605, _, _, _) => {
                    h605
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h606, _, _) => {
                    h606
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h607, _) => {
                    h607
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h608) => {
                    h608
                }
            })
        }
        Adt55::C2 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h609, _, _, _, _, _, _, _) => {
                    h609
                }
            }, match v0.clone() {
                Adt53::C0(_, h610, _, _, _, _, _, _) => {
                    h610
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h611, _, _, _, _, _) => {
                    h611
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, h612, _, _, _) => {
                    h612
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h613, _, _) => {
                    h613
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h614, _) => {
                    h614
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h615) => {
                    h615
                }
            })
        }
        Adt55::C3 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h616, _, _, _, _, _, _, _) => {
                    h616
                }
            }, match v0.clone() {
                Adt53::C0(_, h617, _, _, _, _, _, _) => {
                    h617
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h618, _, _, _, _, _) => {
                    h618
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h619, _, _, _, _) => {
                    h619
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h620, _, _) => {
                    h620
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h621, _) => {
                    h621
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h622) => {
                    h622
                }
            })
        }
        Adt55::C4 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h623, _, _, _, _, _, _, _) => {
                    h623
                }
            }, match v0.clone() {
                Adt53::C0(_, h624, _, _, _, _, _, _) => {
                    h624
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h625, _, _, _, _, _) => {
                    h625
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h626, _, _, _, _) => {
                    h626
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h627, _, _, _) => {
                    h627
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h628, _) => {
                    h628
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h629) => {
                    h629
                }
            })
        }
        Adt55::C5 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h630, _, _, _, _, _, _, _) => {
                    h630
                }
            }, match v0.clone() {
                Adt53::C0(_, h631, _, _, _, _, _, _) => {
                    h631
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h632, _, _, _, _, _) => {
                    h632
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h633, _, _, _, _) => {
                    h633
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h634, _, _, _) => {
                    h634
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h635, _, _) => {
                    h635
                }
            }, v2, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h636) => {
                    h636
                }
            })
        }
    }
}

pub fn f27(v0: Adt0, v1: Adt63, v2: Adt57) -> R<Adt63> {
    Ok(Adt63::C0(Adt0::C0({
        let m639 = match v1.clone() {
            Adt63::C0(h638, _) => {
                h638
            }
        };
        match m639 {
            Adt0::C0(h637, _, _, _, _, _, _) => {
                h637
            }
        }
    }, {
        let m642 = match v1.clone() {
            Adt63::C0(h641, _) => {
                h641
            }
        };
        match m642 {
            Adt0::C0(_, h640, _, _, _, _, _) => {
                h640
            }
        }
    }, {
        let m645 = match v1.clone() {
            Adt63::C0(h644, _) => {
                h644
            }
        };
        match m645 {
            Adt0::C0(_, _, h643, _, _, _, _) => {
                h643
            }
        }
    }, {
        let m648 = match v1.clone() {
            Adt63::C0(h647, _) => {
                h647
            }
        };
        match m648 {
            Adt0::C0(_, _, _, h646, _, _, _) => {
                h646
            }
        }
    }, Adt56::C0({
        let a652 = {
            let m651 = match v0 {
                Adt0::C0(_, _, _, _, h650, _, _) => {
                    h650
                }
            };
            match m651 {
                Adt56::C0(h649, _) => {
                    h649
                }
            }
        };
        let a653 = 1u64;
        nat_add(a652, a653)?
    }, v2), {
        let m656 = match v1.clone() {
            Adt63::C0(h655, _) => {
                h655
            }
        };
        match m656 {
            Adt0::C0(_, _, _, _, _, h654, _) => {
                h654
            }
        }
    }, {
        let m659 = match v1.clone() {
            Adt63::C0(h658, _) => {
                h658
            }
        };
        match m659 {
            Adt0::C0(_, _, _, _, _, _, h657) => {
                h657
            }
        }
    }), match v1 {
        Adt63::C0(_, h660) => {
            h660
        }
    }))
}

pub fn f28(v0: Adt0, v1: Adt53) -> R<Adt63> {
    Ok(f15(v0.clone(), v1, f37(match v0 {
        Adt0::C0(h661, _, _, _, _, _, _) => {
            h661
        }
    }, Adt68::C1)?))
}

pub fn f29(v0: Adt1) -> Adt52 {
    Adt52::C0(match v0.clone() {
        Adt1::C0(h662, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h662
        }
    }, {
        let m665 = match v0.clone() {
            Adt1::C0(_, h664, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h664
            }
        };
        match m665 {
            Adt2::C0(_, h663, _, _, _, _) => {
                h663
            }
        }
    }, {
        let m668 = match v0 {
            Adt1::C0(_, h667, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h667
            }
        };
        match m668 {
            Adt2::C0(h666, _, _, _, _, _) => {
                h666
            }
        }
    })
}

pub fn f30(v0: Adt1, v1: Adt52) -> bool {
    let a671 = match v0.clone() {
        Adt1::C0(h669, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h669
        }
    };
    let a672 = match v1.clone() {
        Adt52::C0(h670, _, _) => {
            h670
        }
    };
    if nat_eq(a671, a672) {
        let a677 = {
            let m675 = match v0.clone() {
                Adt1::C0(_, h674, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h674
                }
            };
            match m675 {
                Adt2::C0(_, h673, _, _, _, _) => {
                    h673
                }
            }
        };
        let a678 = match v1.clone() {
            Adt52::C0(_, h676, _) => {
                h676
            }
        };
        if nat_eq(a677, a678) {
            let a683 = {
                let m681 = match v0.clone() {
                    Adt1::C0(_, h680, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h680
                    }
                };
                match m681 {
                    Adt2::C0(h679, _, _, _, _, _) => {
                        h679
                    }
                }
            };
            let a684 = match v1 {
                Adt52::C0(_, _, h682) => {
                    h682
                }
            };
            if nat_eq(a683, a684) {
                if match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h685, _, _, _, _, _, _, _) => {
                        h685
                    }
                } {
                    let a687 = match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h686, _, _, _, _, _, _) => {
                            h686
                        }
                    };
                    bool_not(a687)
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f31(v0: Adt55, v1: Adt55) -> bool {
    let m688 = v0;
    match m688 {
        Adt55::C0 => {
            let m689 = v1;
            match m689 {
                Adt55::C0 => {
                    true
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C1 => {
            let m690 = v1;
            match m690 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    true
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C2 => {
            let m691 = v1;
            match m691 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    true
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C3 => {
            let m692 = v1;
            match m692 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    true
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C4 => {
            let m693 = v1;
            match m693 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    true
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C5 => {
            let m694 = v1;
            match m694 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    true
                }
            }
        }
    }
}

pub fn f32(p700: List<Adt59>, v1: u64) -> bool {
    let m699 = p700;
    {
        let mut m699 = m699;
        loop {
            let step = {
                let v0 = m699;
                let m695 = v0;
                match m695.uncons() {
                    None => {
                        Err::<List<Adt59>, bool>(false)
                    }
                    Some((v2, v3)) => {
                        let a697 = match v2 {
                            Adt59::C0(h696, _, _) => {
                                h696
                            }
                        };
                        let a698 = v1;
                        if nat_eq(a697, a698) {
                            Err::<List<Adt59>, bool>(true)
                        } else {
                            Ok::<List<Adt59>, bool>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m699 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f33(v0: List<Adt65>) -> List<Adt64> {
    let m701 = v0;
    match m701.uncons() {
        None => {
            List::<Adt64>::nil()
        }
        Some((v1, v2)) => {
            List::cons(Adt64::C0(v1), f33(v2))
        }
    }
}

pub fn f34(v0: List<Adt65>, v1: List<Adt65>) -> List<Adt65> {
    let m702 = v0;
    match m702.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f34(v3, v1))
        }
    }
}

pub fn f35(v0: Option<Adt11>, v1: Option<Adt11>) -> List<Adt65> {
    let m703 = v0;
    match m703 {
        None => {
            List::<Adt65>::nil()
        }
        Some(v2) => {
            let m704 = v1;
            match m704 {
                None => {
                    List::cons(Adt65::C6(v2), List::<Adt65>::nil())
                }
                Some(v3) => {
                    if f50(v2.clone(), v3) {
                        List::<Adt65>::nil()
                    } else {
                        List::cons(Adt65::C6(v2), List::<Adt65>::nil())
                    }
                }
            }
        }
    }
}

pub fn f36(v0: Adt53, v1: Adt55) -> Option<Adt11> {
    let m705 = v1;
    match m705 {
        Adt55::C0 => {
            match v0 {
                Adt53::C0(_, h706, _, _, _, _, _, _) => {
                    h706
                }
            }
        }
        Adt55::C1 => {
            match v0 {
                Adt53::C0(_, _, h707, _, _, _, _, _) => {
                    h707
                }
            }
        }
        Adt55::C2 => {
            match v0 {
                Adt53::C0(_, _, _, h708, _, _, _, _) => {
                    h708
                }
            }
        }
        Adt55::C3 => {
            match v0 {
                Adt53::C0(_, _, _, _, h709, _, _, _) => {
                    h709
                }
            }
        }
        Adt55::C4 => {
            match v0 {
                Adt53::C0(_, _, _, _, _, h710, _, _) => {
                    h710
                }
            }
        }
        Adt55::C5 => {
            match v0 {
                Adt53::C0(_, _, _, _, _, _, h711, _) => {
                    h711
                }
            }
        }
    }
}

pub fn f37(v0: Adt1, v1: Adt68) -> R<Adt71> {
    let m712 = v1;
    match m712 {
        Adt68::C0(v2) => {
            f17(v0, v2)
        }
        Adt68::C1 => {
            f51(v0.clone(), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h713, _, _, _, _, _, _, _) => {
                    h713
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h714, _, _, _, _, _, _) => {
                    h714
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h715, _, _, _, _, _) => {
                    h715
                }
            })
        }
        Adt68::C2 => {
            f52(v0)
        }
        Adt68::C3(v3) => {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h716, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h716
                }
            }, match v0.clone() {
                Adt1::C0(_, h717, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h717
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h718, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h718
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h719, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h719
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h720, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h720
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h721, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h721
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h722, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h722
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h723, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h723
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h724, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h724
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h725, _, _, _, _, _, _, _, _, _, _, _) => {
                    h725
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h726, _, _, _, _, _, _, _, _, _, _) => {
                    h726
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h727, _, _, _, _, _, _, _, _, _) => {
                    h727
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h728, _, _, _, _, _, _, _, _) => {
                    h728
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h729, _, _, _, _, _, _, _) => {
                    h729
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h730, _, _, _, _, _, _) => {
                    h730
                }
            }, v3, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h731, _, _, _, _) => {
                    h731
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h732, _, _, _) => {
                    h732
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h733, _, _) => {
                    h733
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h734, _) => {
                    h734
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h735) => {
                    h735
                }
            }), List::<Adt65>::nil()))
        }
        Adt68::C4 => {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h736, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h736
                }
            }, match v0.clone() {
                Adt1::C0(_, h737, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h737
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h738, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h738
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h739, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h739
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h740, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h740
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h741, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h741
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h742, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h742
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h743, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h743
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h744, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h744
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h745, _, _, _, _, _, _, _, _, _, _, _) => {
                    h745
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h746, _, _, _, _, _, _, _, _, _, _) => {
                    h746
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h747, _, _, _, _, _, _, _, _, _) => {
                    h747
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h748, _, _, _, _, _, _, _, _) => {
                    h748
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h749, _, _, _, _, _, _, _) => {
                    h749
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h750, _, _, _, _, _, _) => {
                    h750
                }
            }, Adt48::C0, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h751, _, _, _, _) => {
                    h751
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h752, _, _, _) => {
                    h752
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h753, _, _) => {
                    h753
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h754, _) => {
                    h754
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h755) => {
                    h755
                }
            }), List::<Adt65>::nil()))
        }
        Adt68::C5 => {
            if match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h756, _, _, _, _, _, _, _) => {
                    h756
                }
            } {
                f51(v0.clone(), false, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h757, _, _, _, _, _, _) => {
                        h757
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h758, _, _, _, _, _) => {
                        h758
                    }
                })
            } else {
                Ok(Adt71::C0(v0, List::<Adt65>::nil()))
            }
        }
        Adt68::C6 => {
            f53(v0)
        }
        Adt68::C7 => {
            f53(v0)
        }
        Adt68::C8(v4) => {
            let a760 = match v0.clone() {
                Adt1::C0(h759, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h759
                }
            };
            let a761 = v4;
            if nat_eq(a760, a761) {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h762, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h762
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h763, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h763
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h764, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h764
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h765, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h765
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h766, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h766
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h767, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h767
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h768, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h768
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h769, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h769
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h770, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h770
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h771, _, _, _, _, _, _, _, _, _, _, _) => {
                        h771
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h772, _, _, _, _, _, _, _, _, _, _) => {
                        h772
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h773, _, _, _, _, _, _, _, _, _) => {
                        h773
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h774, _, _, _, _, _, _, _, _) => {
                        h774
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h775, _, _, _, _, _, _, _) => {
                        h775
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h776, _, _, _, _, _, _) => {
                        h776
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h777, _, _, _, _, _) => {
                        h777
                    }
                }, Adt49::C2, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h778, _, _, _) => {
                        h778
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h779, _, _) => {
                        h779
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h780, _) => {
                        h780
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h781) => {
                        h781
                    }
                }), List::<Adt65>::nil()))
            } else {
                Ok(Adt71::C0(v0, List::<Adt65>::nil()))
            }
        }
        Adt68::C9(v5) => {
            Ok(f54(v0, v5))
        }
        Adt68::C10(v6, v7) => {
            f55(v0, v6, v7)
        }
        Adt68::C11(v8) => {
            let m784 = match v0.clone() {
                Adt1::C0(_, h783, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h783
                }
            };
            if match m784 {
                Adt2::C0(_, _, h782, _, _, _) => {
                    h782
                }
            } {
                Ok(Adt71::C0(v0.clone(), List::cons(Adt65::C2(f29(v0), v8), List::<Adt65>::nil())))
            } else {
                Ok(Adt71::C0(v0, List::<Adt65>::nil()))
            }
        }
        Adt68::C12(v9, v10) => {
            if f56(v0.clone(), v9) {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h785, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h785
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h786, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h786
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h787, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h787
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h788, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h788
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h789, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h789
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h790, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h790
                    }
                }, v10, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h791, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h791
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h792, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h792
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h793, _, _, _, _, _, _, _, _, _, _, _) => {
                        h793
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h794, _, _, _, _, _, _, _, _, _, _) => {
                        h794
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h795, _, _, _, _, _, _, _, _, _) => {
                        h795
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h796, _, _, _, _, _, _, _, _) => {
                        h796
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h797, _, _, _, _, _, _, _) => {
                        h797
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h798, _, _, _, _, _, _) => {
                        h798
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h799, _, _, _, _, _) => {
                        h799
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h800, _, _, _, _) => {
                        h800
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h801, _, _, _) => {
                        h801
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h802, _, _) => {
                        h802
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h803, _) => {
                        h803
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h804) => {
                        h804
                    }
                }), List::<Adt65>::nil()))
            } else {
                Ok(Adt71::C0(v0, List::<Adt65>::nil()))
            }
        }
        Adt68::C13(v11, v12) => {
            if if f56(v0.clone(), v11) {
                let a807 = match v12.clone() {
                    Adt11::C0(h805, _, _) => {
                        h805
                    }
                };
                let a808 = match v0.clone() {
                    Adt1::C0(h806, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h806
                    }
                };
                nat_eq(a807, a808)
            } else {
                false
            } {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h809, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h809
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h810, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h810
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h811, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h811
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h812, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h812
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h813, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h813
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h814, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h814
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h815, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h815
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h816, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h816
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h817, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h817
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h818, _, _, _, _, _, _, _, _, _, _, _) => {
                        h818
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h819, _, _, _, _, _, _, _, _, _, _) => {
                        h819
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h820, _, _, _, _, _, _, _, _, _) => {
                        h820
                    }
                }, Some(v12), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h821, _, _, _, _, _, _, _) => {
                        h821
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h822, _, _, _, _, _, _) => {
                        h822
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h823, _, _, _, _, _) => {
                        h823
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h824, _, _, _, _) => {
                        h824
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h825, _, _, _) => {
                        h825
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h826, _, _) => {
                        h826
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h827, _) => {
                        h827
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h828) => {
                        h828
                    }
                }), f57(match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h829, _, _, _, _, _, _, _, _) => {
                        h829
                    }
                })))
            } else {
                Ok(Adt71::C0(v0, List::cons(Adt65::C6(v12), List::<Adt65>::nil())))
            }
        }
        Adt68::C14(v13) => {
            Ok(f45(v0, v13))
        }
        Adt68::C15(v14, v15) => {
            f58(v0, v14, v15)
        }
        Adt68::C16(v16, v17) => {
            Ok(f59(v0, v16, v17))
        }
        Adt68::C17(v18, v19) => {
            if f56(v0.clone(), v18.clone()) {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h830, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h830
                    }
                }, f60(match v0.clone() {
                    Adt1::C0(_, h831, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h831
                    }
                }), f61(match v0.clone() {
                    Adt1::C0(_, _, h832, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h832
                    }
                }, Adt7::C3), match v0.clone() {
                    Adt1::C0(_, _, _, h833, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h833
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h834, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h834
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h835, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h835
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h836, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h836
                    }
                }, None::<Adt11>, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h837, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h837
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h838, _, _, _, _, _, _, _, _, _, _, _) => {
                        h838
                    }
                }, None::<Adt41>, Some(v19), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h839, _, _, _, _, _, _, _, _) => {
                        h839
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h840, _, _, _, _, _, _, _) => {
                        h840
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h841, _, _, _, _, _, _) => {
                        h841
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h842, _, _, _, _, _) => {
                        h842
                    }
                }, Adt49::C1, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h843, _, _, _) => {
                        h843
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h844, _, _) => {
                        h844
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h845, _) => {
                        h845
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h846) => {
                        h846
                    }
                }), List::cons(Adt65::C4(v18.clone()), List::cons(Adt65::C5(v18), List::<Adt65>::nil()))))
            } else {
                Ok(Adt71::C0(v0, List::<Adt65>::nil()))
            }
        }
        Adt68::C18 => {
            Ok(f62(v0))
        }
        Adt68::C19(v20, v21) => {
            Ok(f63(v0, v20, v21))
        }
        Adt68::C20 => {
            Ok(f62(v0))
        }
        Adt68::C21(v22, v23) => {
            f64(v0, v22, v23)
        }
        Adt68::C22(v24, v25) => {
            f65(v0, v24, v25)
        }
        Adt68::C23(v26, v27) => {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h847, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h847
                }
            }, match v0.clone() {
                Adt1::C0(_, h848, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h848
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h849, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h849
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h850, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h850
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h851, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h851
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h852, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h852
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h853, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h853
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h854, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h854
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h855, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h855
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h856, _, _, _, _, _, _, _, _, _, _, _) => {
                    h856
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h857, _, _, _, _, _, _, _, _, _, _) => {
                    h857
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h858, _, _, _, _, _, _, _, _, _) => {
                    h858
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h859, _, _, _, _, _, _, _, _) => {
                    h859
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h860, _, _, _, _, _, _, _) => {
                    h860
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h861, _, _, _, _, _, _) => {
                    h861
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h862, _, _, _, _, _) => {
                    h862
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h863, _, _, _, _) => {
                    h863
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h864, _, _, _) => {
                    h864
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h865, _, _) => {
                    h865
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h866, _) => {
                    h866
                }
            }, f66(match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h867) => {
                    h867
                }
            }, v26, v27)?), List::<Adt65>::nil()))
        }
        Adt68::C24(v28) => {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h868, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h868
                }
            }, match v0.clone() {
                Adt1::C0(_, h869, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h869
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h870, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h870
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h871, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h871
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h872, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h872
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h873, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h873
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h874, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h874
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h875, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h875
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h876, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h876
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h877, _, _, _, _, _, _, _, _, _, _, _) => {
                    h877
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h878, _, _, _, _, _, _, _, _, _, _) => {
                    h878
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h879, _, _, _, _, _, _, _, _, _) => {
                    h879
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h880, _, _, _, _, _, _, _, _) => {
                    h880
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h881, _, _, _, _, _, _, _) => {
                    h881
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h882, _, _, _, _, _, _) => {
                    h882
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h883, _, _, _, _, _) => {
                    h883
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h884, _, _, _, _) => {
                    h884
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h885, _, _, _) => {
                    h885
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h886, _, _) => {
                    h886
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h887, _) => {
                    h887
                }
            }, f67(match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h888) => {
                    h888
                }
            }, v28)?), List::<Adt65>::nil()))
        }
    }
}

pub fn f38(v0: Adt2) -> R<Adt2> {
    Ok(Adt2::C0(match v0.clone() {
        Adt2::C0(h889, _, _, _, _, _) => {
            h889
        }
    }, {
        let a891 = match v0 {
            Adt2::C0(_, h890, _, _, _, _) => {
                h890
            }
        };
        let a892 = 1u64;
        nat_add(a891, a892)?
    }, true, false, Adt3::C1, Adt4::C0))
}

pub fn f39() -> Adt5 {
    Adt5::C0(Adt6::C0, false, 0u64, false, Adt7::C0)
}

pub fn f40() -> Adt8 {
    Adt8::C0(0u64, false, false, 0u64)
}

pub fn f41() -> Adt50 {
    Adt50::C0(f68(), None::<Adt45>)
}

pub fn f42(v0: Adt1) -> List<Adt51> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h893, _, _, _) => {
            h893
        }
    } {
        List::cons(Adt51::C0(f29(v0.clone()), {
            let m895 = match v0.clone() {
                Adt1::C0(_, _, _, _, h894, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h894
                }
            };
            match m895 {
                None => {
                    f69()
                }
                Some(v1) => {
                    let m899 = {
                        let m898 = f70(v1);
                        match m898 {
                            Adt12::C0(h897, _) => {
                                h897
                            }
                        }
                    };
                    match m899 {
                        Adt13::C0(_, _, _, _, _, _, h896) => {
                            h896
                        }
                    }
                }
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h900, _, _) => {
                h900
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h901, _) => {
                h901
            }
        }), match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h902) => {
                h902
            }
        })
    } else {
        match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h903) => {
                h903
            }
        }
    }
}

pub fn f43(v0: Adt1) -> List<Adt65> {
    f34(if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, h904, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h904
        }
    } {
        List::cons(Adt65::C9(f29(v0.clone())), List::<Adt65>::nil())
    } else {
        List::<Adt65>::nil()
    }, f34(if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h905, _, _, _) => {
            h905
        }
    } {
        let m908 = match v0.clone() {
            Adt1::C0(_, h907, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h907
            }
        };
        if match m908 {
            Adt2::C0(_, _, h906, _, _, _) => {
                h906
            }
        } {
            List::cons(Adt65::C4(f29(v0.clone())), List::cons(Adt65::C5(f29(v0.clone())), List::<Adt65>::nil()))
        } else {
            List::cons(Adt65::C5(f29(v0.clone())), List::<Adt65>::nil())
        }
    } else {
        List::<Adt65>::nil()
    }, f34(f57(match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, h909, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h909
        }
    }), f57(match v0 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h910, _, _, _, _, _, _, _, _) => {
            h910
        }
    }))))
}

pub fn f44(v0: Adt0) -> R<Adt63> {
    let m912 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h911) => {
            h911
        }
    };
    match m912 {
        None => {
            let m915 = match v0.clone() {
                Adt0::C0(h914, _, _, _, _, _, _) => {
                    h914
                }
            };
            if match m915 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h913, _, _, _, _, _, _) => {
                    h913
                }
            } {
                Ok(f15(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h916, _, _, _, _, _) => {
                        h916
                    }
                }, f53(match v0 {
                    Adt0::C0(h917, _, _, _, _, _, _) => {
                        h917
                    }
                })?))
            } else {
                Ok(Adt63::C0(Adt0::C0({
                    let m920 = f53(match v0.clone() {
                        Adt0::C0(h919, _, _, _, _, _, _) => {
                            h919
                        }
                    })?;
                    match m920 {
                        Adt71::C0(h918, _) => {
                            h918
                        }
                    }
                }, Adt53::C0({
                    let m923 = match v0.clone() {
                        Adt0::C0(_, h922, _, _, _, _, _) => {
                            h922
                        }
                    };
                    match m923 {
                        Adt53::C0(h921, _, _, _, _, _, _, _) => {
                            h921
                        }
                    }
                }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                    let m926 = match v0.clone() {
                        Adt0::C0(_, h925, _, _, _, _, _) => {
                            h925
                        }
                    };
                    match m926 {
                        Adt53::C0(_, _, _, _, _, _, _, h924) => {
                            h924
                        }
                    }
                }), match v0.clone() {
                    Adt0::C0(_, _, h927, _, _, _, _) => {
                        h927
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, h928, _, _, _) => {
                        h928
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, h929, _, _) => {
                        h929
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h930, _) => {
                        h930
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h931) => {
                        h931
                    }
                }), f33(f34(f71(match v0.clone() {
                    Adt0::C0(_, h932, _, _, _, _, _) => {
                        h932
                    }
                }), {
                    let m935 = f53(match v0 {
                        Adt0::C0(h934, _, _, _, _, _, _) => {
                            h934
                        }
                    })?;
                    match m935 {
                        Adt71::C0(_, h933) => {
                            h933
                        }
                    }
                }))))
            }
        }
        Some(v1) => {
            Ok(Adt63::C0(Adt0::C0({
                let m962 = {
                    let m961 = {
                        let m940 = match v0.clone() {
                            Adt0::C0(h939, _, _, _, _, _, _) => {
                                h939
                            }
                        };
                        if match m940 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h938, _, _, _, _, _, _) => {
                                h938
                            }
                        } {
                            f15(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h941, _, _, _, _, _) => {
                                    h941
                                }
                            }, f53(match v0.clone() {
                                Adt0::C0(h942, _, _, _, _, _, _) => {
                                    h942
                                }
                            })?)
                        } else {
                            Adt63::C0(Adt0::C0({
                                let m945 = f53(match v0.clone() {
                                    Adt0::C0(h944, _, _, _, _, _, _) => {
                                        h944
                                    }
                                })?;
                                match m945 {
                                    Adt71::C0(h943, _) => {
                                        h943
                                    }
                                }
                            }, Adt53::C0({
                                let m948 = match v0.clone() {
                                    Adt0::C0(_, h947, _, _, _, _, _) => {
                                        h947
                                    }
                                };
                                match m948 {
                                    Adt53::C0(h946, _, _, _, _, _, _, _) => {
                                        h946
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m951 = match v0.clone() {
                                    Adt0::C0(_, h950, _, _, _, _, _) => {
                                        h950
                                    }
                                };
                                match m951 {
                                    Adt53::C0(_, _, _, _, _, _, _, h949) => {
                                        h949
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h952, _, _, _, _) => {
                                    h952
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h953, _, _, _) => {
                                    h953
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h954, _, _) => {
                                    h954
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h955, _) => {
                                    h955
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h956) => {
                                    h956
                                }
                            }), f33(f34(f71(match v0.clone() {
                                Adt0::C0(_, h957, _, _, _, _, _) => {
                                    h957
                                }
                            }), {
                                let m960 = f53(match v0.clone() {
                                    Adt0::C0(h959, _, _, _, _, _, _) => {
                                        h959
                                    }
                                })?;
                                match m960 {
                                    Adt71::C0(_, h958) => {
                                        h958
                                    }
                                }
                            })))
                        }
                    };
                    match m961 {
                        Adt63::C0(h937, _) => {
                            h937
                        }
                    }
                };
                match m962 {
                    Adt0::C0(h936, _, _, _, _, _, _) => {
                        h936
                    }
                }
            }, {
                let m989 = {
                    let m988 = {
                        let m967 = match v0.clone() {
                            Adt0::C0(h966, _, _, _, _, _, _) => {
                                h966
                            }
                        };
                        if match m967 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h965, _, _, _, _, _, _) => {
                                h965
                            }
                        } {
                            f15(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h968, _, _, _, _, _) => {
                                    h968
                                }
                            }, f53(match v0.clone() {
                                Adt0::C0(h969, _, _, _, _, _, _) => {
                                    h969
                                }
                            })?)
                        } else {
                            Adt63::C0(Adt0::C0({
                                let m972 = f53(match v0.clone() {
                                    Adt0::C0(h971, _, _, _, _, _, _) => {
                                        h971
                                    }
                                })?;
                                match m972 {
                                    Adt71::C0(h970, _) => {
                                        h970
                                    }
                                }
                            }, Adt53::C0({
                                let m975 = match v0.clone() {
                                    Adt0::C0(_, h974, _, _, _, _, _) => {
                                        h974
                                    }
                                };
                                match m975 {
                                    Adt53::C0(h973, _, _, _, _, _, _, _) => {
                                        h973
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m978 = match v0.clone() {
                                    Adt0::C0(_, h977, _, _, _, _, _) => {
                                        h977
                                    }
                                };
                                match m978 {
                                    Adt53::C0(_, _, _, _, _, _, _, h976) => {
                                        h976
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h979, _, _, _, _) => {
                                    h979
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h980, _, _, _) => {
                                    h980
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h981, _, _) => {
                                    h981
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h982, _) => {
                                    h982
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h983) => {
                                    h983
                                }
                            }), f33(f34(f71(match v0.clone() {
                                Adt0::C0(_, h984, _, _, _, _, _) => {
                                    h984
                                }
                            }), {
                                let m987 = f53(match v0.clone() {
                                    Adt0::C0(h986, _, _, _, _, _, _) => {
                                        h986
                                    }
                                })?;
                                match m987 {
                                    Adt71::C0(_, h985) => {
                                        h985
                                    }
                                }
                            })))
                        }
                    };
                    match m988 {
                        Adt63::C0(h964, _) => {
                            h964
                        }
                    }
                };
                match m989 {
                    Adt0::C0(_, h963, _, _, _, _, _) => {
                        h963
                    }
                }
            }, {
                let m1016 = {
                    let m1015 = {
                        let m994 = match v0.clone() {
                            Adt0::C0(h993, _, _, _, _, _, _) => {
                                h993
                            }
                        };
                        if match m994 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h992, _, _, _, _, _, _) => {
                                h992
                            }
                        } {
                            f15(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h995, _, _, _, _, _) => {
                                    h995
                                }
                            }, f53(match v0.clone() {
                                Adt0::C0(h996, _, _, _, _, _, _) => {
                                    h996
                                }
                            })?)
                        } else {
                            Adt63::C0(Adt0::C0({
                                let m999 = f53(match v0.clone() {
                                    Adt0::C0(h998, _, _, _, _, _, _) => {
                                        h998
                                    }
                                })?;
                                match m999 {
                                    Adt71::C0(h997, _) => {
                                        h997
                                    }
                                }
                            }, Adt53::C0({
                                let m1002 = match v0.clone() {
                                    Adt0::C0(_, h1001, _, _, _, _, _) => {
                                        h1001
                                    }
                                };
                                match m1002 {
                                    Adt53::C0(h1000, _, _, _, _, _, _, _) => {
                                        h1000
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1005 = match v0.clone() {
                                    Adt0::C0(_, h1004, _, _, _, _, _) => {
                                        h1004
                                    }
                                };
                                match m1005 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1003) => {
                                        h1003
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1006, _, _, _, _) => {
                                    h1006
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1007, _, _, _) => {
                                    h1007
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1008, _, _) => {
                                    h1008
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1009, _) => {
                                    h1009
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1010) => {
                                    h1010
                                }
                            }), f33(f34(f71(match v0.clone() {
                                Adt0::C0(_, h1011, _, _, _, _, _) => {
                                    h1011
                                }
                            }), {
                                let m1014 = f53(match v0.clone() {
                                    Adt0::C0(h1013, _, _, _, _, _, _) => {
                                        h1013
                                    }
                                })?;
                                match m1014 {
                                    Adt71::C0(_, h1012) => {
                                        h1012
                                    }
                                }
                            })))
                        }
                    };
                    match m1015 {
                        Adt63::C0(h991, _) => {
                            h991
                        }
                    }
                };
                match m1016 {
                    Adt0::C0(_, _, h990, _, _, _, _) => {
                        h990
                    }
                }
            }, {
                let m1043 = {
                    let m1042 = {
                        let m1021 = match v0.clone() {
                            Adt0::C0(h1020, _, _, _, _, _, _) => {
                                h1020
                            }
                        };
                        if match m1021 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1019, _, _, _, _, _, _) => {
                                h1019
                            }
                        } {
                            f15(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1022, _, _, _, _, _) => {
                                    h1022
                                }
                            }, f53(match v0.clone() {
                                Adt0::C0(h1023, _, _, _, _, _, _) => {
                                    h1023
                                }
                            })?)
                        } else {
                            Adt63::C0(Adt0::C0({
                                let m1026 = f53(match v0.clone() {
                                    Adt0::C0(h1025, _, _, _, _, _, _) => {
                                        h1025
                                    }
                                })?;
                                match m1026 {
                                    Adt71::C0(h1024, _) => {
                                        h1024
                                    }
                                }
                            }, Adt53::C0({
                                let m1029 = match v0.clone() {
                                    Adt0::C0(_, h1028, _, _, _, _, _) => {
                                        h1028
                                    }
                                };
                                match m1029 {
                                    Adt53::C0(h1027, _, _, _, _, _, _, _) => {
                                        h1027
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1032 = match v0.clone() {
                                    Adt0::C0(_, h1031, _, _, _, _, _) => {
                                        h1031
                                    }
                                };
                                match m1032 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1030) => {
                                        h1030
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1033, _, _, _, _) => {
                                    h1033
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1034, _, _, _) => {
                                    h1034
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1035, _, _) => {
                                    h1035
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1036, _) => {
                                    h1036
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1037) => {
                                    h1037
                                }
                            }), f33(f34(f71(match v0.clone() {
                                Adt0::C0(_, h1038, _, _, _, _, _) => {
                                    h1038
                                }
                            }), {
                                let m1041 = f53(match v0.clone() {
                                    Adt0::C0(h1040, _, _, _, _, _, _) => {
                                        h1040
                                    }
                                })?;
                                match m1041 {
                                    Adt71::C0(_, h1039) => {
                                        h1039
                                    }
                                }
                            })))
                        }
                    };
                    match m1042 {
                        Adt63::C0(h1018, _) => {
                            h1018
                        }
                    }
                };
                match m1043 {
                    Adt0::C0(_, _, _, h1017, _, _, _) => {
                        h1017
                    }
                }
            }, {
                let m1070 = {
                    let m1069 = {
                        let m1048 = match v0.clone() {
                            Adt0::C0(h1047, _, _, _, _, _, _) => {
                                h1047
                            }
                        };
                        if match m1048 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1046, _, _, _, _, _, _) => {
                                h1046
                            }
                        } {
                            f15(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1049, _, _, _, _, _) => {
                                    h1049
                                }
                            }, f53(match v0.clone() {
                                Adt0::C0(h1050, _, _, _, _, _, _) => {
                                    h1050
                                }
                            })?)
                        } else {
                            Adt63::C0(Adt0::C0({
                                let m1053 = f53(match v0.clone() {
                                    Adt0::C0(h1052, _, _, _, _, _, _) => {
                                        h1052
                                    }
                                })?;
                                match m1053 {
                                    Adt71::C0(h1051, _) => {
                                        h1051
                                    }
                                }
                            }, Adt53::C0({
                                let m1056 = match v0.clone() {
                                    Adt0::C0(_, h1055, _, _, _, _, _) => {
                                        h1055
                                    }
                                };
                                match m1056 {
                                    Adt53::C0(h1054, _, _, _, _, _, _, _) => {
                                        h1054
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1059 = match v0.clone() {
                                    Adt0::C0(_, h1058, _, _, _, _, _) => {
                                        h1058
                                    }
                                };
                                match m1059 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1057) => {
                                        h1057
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1060, _, _, _, _) => {
                                    h1060
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1061, _, _, _) => {
                                    h1061
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1062, _, _) => {
                                    h1062
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1063, _) => {
                                    h1063
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1064) => {
                                    h1064
                                }
                            }), f33(f34(f71(match v0.clone() {
                                Adt0::C0(_, h1065, _, _, _, _, _) => {
                                    h1065
                                }
                            }), {
                                let m1068 = f53(match v0.clone() {
                                    Adt0::C0(h1067, _, _, _, _, _, _) => {
                                        h1067
                                    }
                                })?;
                                match m1068 {
                                    Adt71::C0(_, h1066) => {
                                        h1066
                                    }
                                }
                            })))
                        }
                    };
                    match m1069 {
                        Adt63::C0(h1045, _) => {
                            h1045
                        }
                    }
                };
                match m1070 {
                    Adt0::C0(_, _, _, _, h1044, _, _) => {
                        h1044
                    }
                }
            }, {
                let m1097 = {
                    let m1096 = {
                        let m1075 = match v0.clone() {
                            Adt0::C0(h1074, _, _, _, _, _, _) => {
                                h1074
                            }
                        };
                        if match m1075 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1073, _, _, _, _, _, _) => {
                                h1073
                            }
                        } {
                            f15(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1076, _, _, _, _, _) => {
                                    h1076
                                }
                            }, f53(match v0.clone() {
                                Adt0::C0(h1077, _, _, _, _, _, _) => {
                                    h1077
                                }
                            })?)
                        } else {
                            Adt63::C0(Adt0::C0({
                                let m1080 = f53(match v0.clone() {
                                    Adt0::C0(h1079, _, _, _, _, _, _) => {
                                        h1079
                                    }
                                })?;
                                match m1080 {
                                    Adt71::C0(h1078, _) => {
                                        h1078
                                    }
                                }
                            }, Adt53::C0({
                                let m1083 = match v0.clone() {
                                    Adt0::C0(_, h1082, _, _, _, _, _) => {
                                        h1082
                                    }
                                };
                                match m1083 {
                                    Adt53::C0(h1081, _, _, _, _, _, _, _) => {
                                        h1081
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1086 = match v0.clone() {
                                    Adt0::C0(_, h1085, _, _, _, _, _) => {
                                        h1085
                                    }
                                };
                                match m1086 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1084) => {
                                        h1084
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1087, _, _, _, _) => {
                                    h1087
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1088, _, _, _) => {
                                    h1088
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1089, _, _) => {
                                    h1089
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1090, _) => {
                                    h1090
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1091) => {
                                    h1091
                                }
                            }), f33(f34(f71(match v0.clone() {
                                Adt0::C0(_, h1092, _, _, _, _, _) => {
                                    h1092
                                }
                            }), {
                                let m1095 = f53(match v0.clone() {
                                    Adt0::C0(h1094, _, _, _, _, _, _) => {
                                        h1094
                                    }
                                })?;
                                match m1095 {
                                    Adt71::C0(_, h1093) => {
                                        h1093
                                    }
                                }
                            })))
                        }
                    };
                    match m1096 {
                        Adt63::C0(h1072, _) => {
                            h1072
                        }
                    }
                };
                match m1097 {
                    Adt0::C0(_, _, _, _, _, h1071, _) => {
                        h1071
                    }
                }
            }, None::<Adt60>), List::cons(Adt64::C3(v1.clone()), List::cons(Adt64::C0(Adt65::C6(match v1 {
                Adt60::C0(_, _, _, h1098, _, _) => {
                    h1098
                }
            })), {
                let m1123 = {
                    let m1102 = match v0.clone() {
                        Adt0::C0(h1101, _, _, _, _, _, _) => {
                            h1101
                        }
                    };
                    if match m1102 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1100, _, _, _, _, _, _) => {
                            h1100
                        }
                    } {
                        f15(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h1103, _, _, _, _, _) => {
                                h1103
                            }
                        }, f53(match v0 {
                            Adt0::C0(h1104, _, _, _, _, _, _) => {
                                h1104
                            }
                        })?)
                    } else {
                        Adt63::C0(Adt0::C0({
                            let m1107 = f53(match v0.clone() {
                                Adt0::C0(h1106, _, _, _, _, _, _) => {
                                    h1106
                                }
                            })?;
                            match m1107 {
                                Adt71::C0(h1105, _) => {
                                    h1105
                                }
                            }
                        }, Adt53::C0({
                            let m1110 = match v0.clone() {
                                Adt0::C0(_, h1109, _, _, _, _, _) => {
                                    h1109
                                }
                            };
                            match m1110 {
                                Adt53::C0(h1108, _, _, _, _, _, _, _) => {
                                    h1108
                                }
                            }
                        }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                            let m1113 = match v0.clone() {
                                Adt0::C0(_, h1112, _, _, _, _, _) => {
                                    h1112
                                }
                            };
                            match m1113 {
                                Adt53::C0(_, _, _, _, _, _, _, h1111) => {
                                    h1111
                                }
                            }
                        }), match v0.clone() {
                            Adt0::C0(_, _, h1114, _, _, _, _) => {
                                h1114
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h1115, _, _, _) => {
                                h1115
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h1116, _, _) => {
                                h1116
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h1117, _) => {
                                h1117
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1118) => {
                                h1118
                            }
                        }), f33(f34(f71(match v0.clone() {
                            Adt0::C0(_, h1119, _, _, _, _, _) => {
                                h1119
                            }
                        }), {
                            let m1122 = f53(match v0 {
                                Adt0::C0(h1121, _, _, _, _, _, _) => {
                                    h1121
                                }
                            })?;
                            match m1122 {
                                Adt71::C0(_, h1120) => {
                                    h1120
                                }
                            }
                        })))
                    }
                };
                match m1123 {
                    Adt63::C0(_, h1099) => {
                        h1099
                    }
                }
            }))))
        }
    }
}

pub fn f45(v0: Adt1, v1: u64) -> Adt71 {
    let a1124 = v1;
    let a1125 = 0u64;
    if nat_eq(a1124, a1125) {
        Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1126, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1126
            }
        }, match v0.clone() {
            Adt1::C0(_, h1127, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1127
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1128, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1128
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1129, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1129
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1130, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1130
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1131, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1131
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1132, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1132
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1133, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1133
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1134, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1134
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1135, _, _, _, _, _, _, _, _, _, _, _) => {
                h1135
            }
        }, Some(Adt41::C10(Adt43::C12)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1136, _, _, _, _, _, _, _, _, _) => {
                h1136
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1137, _, _, _, _, _, _, _, _) => {
                h1137
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1138, _, _, _, _, _, _, _) => {
                h1138
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1139, _, _, _, _, _, _) => {
                h1139
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1140, _, _, _, _, _) => {
                h1140
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1141, _, _, _, _) => {
                h1141
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1142, _, _, _) => {
                h1142
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1143, _, _) => {
                h1143
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1144, _) => {
                h1144
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1145) => {
                h1145
            }
        }), List::<Adt65>::nil())
    } else {
        let m1148 = match v0.clone() {
            Adt1::C0(_, h1147, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1147
            }
        };
        if match m1148 {
            Adt2::C0(_, _, h1146, _, _, _) => {
                h1146
            }
        } {
            Adt71::C0(v0.clone(), List::cons(Adt65::C3(f29(v0), v1), List::<Adt65>::nil()))
        } else {
            Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1149, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1149
                }
            }, match v0.clone() {
                Adt1::C0(_, h1150, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1150
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1151, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1151
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1152, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1152
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1153, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1153
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1154, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1154
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1155, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1155
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1156, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1156
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1157, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1157
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1158, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1158
                }
            }, Some(Adt41::C10(Adt43::C3)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1159, _, _, _, _, _, _, _, _, _) => {
                    h1159
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1160, _, _, _, _, _, _, _, _) => {
                    h1160
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1161, _, _, _, _, _, _, _) => {
                    h1161
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1162, _, _, _, _, _, _) => {
                    h1162
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1163, _, _, _, _, _) => {
                    h1163
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1164, _, _, _, _) => {
                    h1164
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1165, _, _, _) => {
                    h1165
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1166, _, _) => {
                    h1166
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1167, _) => {
                    h1167
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1168) => {
                    h1168
                }
            }), List::<Adt65>::nil())
        }
    }
}

pub fn f46(v0: Adt1, v1: Adt17) -> R<Adt71> {
    f17(v0, Adt9::C4(v1))
}

pub fn f47(p1174: List<Adt59>, v1: u64) -> Option<Adt59> {
    let m1173 = p1174;
    {
        let mut m1173 = m1173;
        loop {
            let step = {
                let v0 = m1173;
                let m1169 = v0;
                match m1169.uncons() {
                    None => {
                        Err::<List<Adt59>, Option<Adt59>>(None::<Adt59>)
                    }
                    Some((v2, v3)) => {
                        let a1171 = match v2.clone() {
                            Adt59::C0(h1170, _, _) => {
                                h1170
                            }
                        };
                        let a1172 = v1;
                        if nat_eq(a1171, a1172) {
                            Err::<List<Adt59>, Option<Adt59>>(Some(v2))
                        } else {
                            Ok::<List<Adt59>, Option<Adt59>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m1173 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f48(v0: List<Adt59>, v1: u64, v2: Adt59) -> List<Adt59> {
    let m1175 = v0;
    match m1175.uncons() {
        None => {
            List::cons(v2, List::<Adt59>::nil())
        }
        Some((v3, v4)) => {
            let a1176 = v1;
            let a1177 = 0u64;
            if nat_eq(a1176, a1177) {
                List::cons(v2, List::cons(v3, v4))
            } else {
                List::cons(v3, f48(v4, {
                    let a1178 = v1;
                    let a1179 = 1u64;
                    nat_sub(a1178, a1179)
                }, v2))
            }
        }
    }
}

pub fn f49(p1188: List<Adt59>, p1189: List<Adt59>) -> bool {
    let m1187 = (p1188, p1189);
    {
        let mut m1187 = m1187;
        loop {
            let step = {
                let (v0, v1) = m1187;
                let m1180 = v0;
                match m1180.uncons() {
                    None => {
                        let m1181 = v1;
                        match m1181.uncons() {
                            None => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(true)
                            }
                            Some((_, _)) => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(false)
                            }
                        }
                    }
                    Some((v4, v5)) => {
                        let m1182 = v1;
                        match m1182.uncons() {
                            None => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(false)
                            }
                            Some((v6, v7)) => {
                                let a1185 = match v4 {
                                    Adt59::C0(h1183, _, _) => {
                                        h1183
                                    }
                                };
                                let a1186 = match v6 {
                                    Adt59::C0(h1184, _, _) => {
                                        h1184
                                    }
                                };
                                if nat_eq(a1185, a1186) {
                                    Ok::<(List<Adt59>, List<Adt59>), bool>((v5, v7))
                                } else {
                                    Err::<(List<Adt59>, List<Adt59>), bool>(false)
                                }
                            }
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m1187 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f50(v0: Adt11, v1: Adt11) -> bool {
    let a1192 = match v0.clone() {
        Adt11::C0(h1190, _, _) => {
            h1190
        }
    };
    let a1193 = match v1.clone() {
        Adt11::C0(h1191, _, _) => {
            h1191
        }
    };
    if nat_eq(a1192, a1193) {
        let a1196 = match v0.clone() {
            Adt11::C0(_, h1194, _) => {
                h1194
            }
        };
        let a1197 = match v1.clone() {
            Adt11::C0(_, h1195, _) => {
                h1195
            }
        };
        if nat_eq(a1196, a1197) {
            let a1200 = match v0 {
                Adt11::C0(_, _, h1198) => {
                    h1198
                }
            };
            let a1201 = match v1 {
                Adt11::C0(_, _, h1199) => {
                    h1199
                }
            };
            nat_eq(a1200, a1201)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f51(v0: Adt1, v1: bool, v2: bool, v3: Adt48) -> R<Adt71> {
    Ok(Adt71::C0(Adt1::C0(match v0.clone() {
        Adt1::C0(h1202, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1202
        }
    }, f72(match v0.clone() {
        Adt1::C0(_, h1203, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1203
        }
    })?, f39(), f40(), None::<Adt9>, None::<Adt22>, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h1204, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1204
        }
    }, None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, v1, v2, v3, Adt49::C1, false, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1205, _, _) => {
            h1205
        }
    }, None::<Adt23>, f42(v0.clone())), f43(v0)))
}

pub fn f52(v0: Adt1) -> R<Adt71> {
    let m1208 = match v0.clone() {
        Adt1::C0(_, h1207, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1207
        }
    };
    if match m1208 {
        Adt2::C0(_, _, h1206, _, _, _) => {
            h1206
        }
    } {
        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1209, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1209
            }
        }, f60(match v0.clone() {
            Adt1::C0(_, h1210, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1210
            }
        }), f61(match v0.clone() {
            Adt1::C0(_, _, h1211, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1211
            }
        }, Adt7::C2), match v0.clone() {
            Adt1::C0(_, _, _, h1212, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1212
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1213, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1213
            }
        }, None::<Adt22>, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1214, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1214
            }
        }, None::<Adt11>, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1215, _, _, _, _, _, _, _, _, _, _, _) => {
                h1215
            }
        }, Some(Adt41::C7), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1216, _, _, _, _, _, _, _, _, _) => {
                h1216
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1217, _, _, _, _, _, _, _, _) => {
                h1217
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1218, _, _, _, _, _, _, _) => {
                h1218
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1219, _, _, _, _, _, _) => {
                h1219
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1220, _, _, _, _, _) => {
                h1220
            }
        }, Adt49::C1, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1221, _, _) => {
                h1221
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1222, _) => {
                h1222
            }
        }, f42(v0.clone())), List::cons(Adt65::C4(f29(v0.clone())), List::cons(Adt65::C5(f29(v0)), List::<Adt65>::nil()))))
    } else {
        if match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1223, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1223
            }
        } {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1224, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1224
                }
            }, f72(match v0.clone() {
                Adt1::C0(_, h1225, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1225
                }
            })?, f61(match v0.clone() {
                Adt1::C0(_, _, h1226, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1226
                }
            }, Adt7::C3), match v0.clone() {
                Adt1::C0(_, _, _, h1227, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1227
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1228, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1228
                }
            }, None::<Adt22>, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1229, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1229
                }
            }, None::<Adt11>, false, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1230, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1230
                }
            }, Some(Adt41::C7), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1231, _, _, _, _, _, _, _, _, _) => {
                    h1231
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1232, _, _, _, _, _, _, _, _) => {
                    h1232
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1233, _, _, _, _, _, _, _) => {
                    h1233
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1234, _, _, _, _, _, _) => {
                    h1234
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1235, _, _, _, _, _) => {
                    h1235
                }
            }, Adt49::C1, false, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1236, _, _) => {
                    h1236
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1237, _) => {
                    h1237
                }
            }, f42(v0.clone())), f43(v0)))
        } else {
            Ok(Adt71::C0(v0, List::<Adt65>::nil()))
        }
    }
}

pub fn f53(v0: Adt1) -> R<Adt71> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1238, _, _, _, _, _, _) => {
            h1238
        }
    } {
        Ok(Adt71::C0(v0, List::<Adt65>::nil()))
    } else {
        Ok(Adt71::C0({
            let m1241 = f51(v0.clone(), false, true, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1240, _, _, _, _, _) => {
                    h1240
                }
            })?;
            match m1241 {
                Adt71::C0(h1239, _) => {
                    h1239
                }
            }
        }, f34(f43(v0.clone()), List::cons(Adt65::C8(match v0 {
            Adt1::C0(h1242, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1242
            }
        }), List::<Adt65>::nil()))))
    }
}

pub fn f54(v0: Adt1, v1: Adt52) -> Adt71 {
    if f56(v0.clone(), v1) {
        let m1244 = f73(match v0.clone() {
            Adt1::C0(_, _, h1243, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1243
            }
        });
        match m1244 {
            Ok(v3) => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1265, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1265
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1266, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1266
                    }
                }, v3, match v0.clone() {
                    Adt1::C0(_, _, _, h1267, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1267
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1268, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1268
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1269, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1269
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1270, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1270
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1271, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1271
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1272, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1272
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1273, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1273
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1274, _, _, _, _, _, _, _, _, _, _) => {
                        h1274
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1275, _, _, _, _, _, _, _, _, _) => {
                        h1275
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1276, _, _, _, _, _, _, _, _) => {
                        h1276
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1277, _, _, _, _, _, _, _) => {
                        h1277
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1278, _, _, _, _, _, _) => {
                        h1278
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1279, _, _, _, _, _) => {
                        h1279
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1280, _, _, _, _) => {
                        h1280
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1281, _, _, _) => {
                        h1281
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1282, _, _) => {
                        h1282
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1283, _) => {
                        h1283
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1284) => {
                        h1284
                    }
                }), List::<Adt65>::nil())
            }
            Err(v2) => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1245, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1245
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1246, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1246
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1247, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1247
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1248, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1248
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1249, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1249
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1250, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1250
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1251, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1251
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1252, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1252
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1253, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1253
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1254, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1254
                    }
                }, Some(Adt41::C11(v2)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1255, _, _, _, _, _, _, _, _, _) => {
                        h1255
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1256, _, _, _, _, _, _, _, _) => {
                        h1256
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1257, _, _, _, _, _, _, _) => {
                        h1257
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1258, _, _, _, _, _, _) => {
                        h1258
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1259, _, _, _, _, _) => {
                        h1259
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1260, _, _, _, _) => {
                        h1260
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1261, _, _, _) => {
                        h1261
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1262, _, _) => {
                        h1262
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1263, _) => {
                        h1263
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1264) => {
                        h1264
                    }
                }), List::<Adt65>::nil())
            }
        }
    } else {
        Adt71::C0(v0, List::<Adt65>::nil())
    }
}

pub fn f55(v0: Adt1, v1: Adt52, v2: Adt66) -> R<Adt71> {
    if f56(v0.clone(), v1.clone()) {
        if f74(v0.clone(), v2.clone()) {
            let m1286 = f75(match v0.clone() {
                Adt1::C0(_, _, h1285, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1285
                }
            }, f76(v2.clone()));
            match m1286 {
                Adt73::C0(_, v5) => {
                    let m1308 = f77(match v0.clone() {
                        Adt1::C0(_, _, _, h1307, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1307
                        }
                    }, v2.clone())?;
                    match m1308 {
                        Ok(v7) => {
                            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                                Adt1::C0(h1329, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1329
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, h1330, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1330
                                }
                            }, v5, v7, match v0.clone() {
                                Adt1::C0(_, _, _, _, h1331, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1331
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h1332, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1332
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h1333, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1333
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, h1334, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1334
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, h1335, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1335
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, h1336, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1336
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1337, _, _, _, _, _, _, _, _, _, _) => {
                                    h1337
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1338, _, _, _, _, _, _, _, _, _) => {
                                    h1338
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1339, _, _, _, _, _, _, _, _) => {
                                    h1339
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1340, _, _, _, _, _, _, _) => {
                                    h1340
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1341, _, _, _, _, _, _) => {
                                    h1341
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1342, _, _, _, _, _) => {
                                    h1342
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1343, _, _, _, _) => {
                                    h1343
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1344, _, _, _) => {
                                    h1344
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1345, _, _) => {
                                    h1345
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1346, _) => {
                                    h1346
                                }
                            }, match v0 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1347) => {
                                    h1347
                                }
                            }), List::cons(Adt65::C1(v1, v2), List::<Adt65>::nil())))
                        }
                        Err(_) => {
                            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                                Adt1::C0(h1309, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1309
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, h1310, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1310
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, h1311, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1311
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h1312, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1312
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h1313, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1313
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h1314, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1314
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h1315, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1315
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, h1316, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1316
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, h1317, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1317
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, h1318, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1318
                                }
                            }, Some(Adt41::C10(Adt43::C8)), match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1319, _, _, _, _, _, _, _, _, _) => {
                                    h1319
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1320, _, _, _, _, _, _, _, _) => {
                                    h1320
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1321, _, _, _, _, _, _, _) => {
                                    h1321
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1322, _, _, _, _, _, _) => {
                                    h1322
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1323, _, _, _, _, _) => {
                                    h1323
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1324, _, _, _, _) => {
                                    h1324
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1325, _, _, _) => {
                                    h1325
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1326, _, _) => {
                                    h1326
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1327, _) => {
                                    h1327
                                }
                            }, match v0 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1328) => {
                                    h1328
                                }
                            }), List::<Adt65>::nil()))
                        }
                    }
                }
                Adt73::C1(v3) => {
                    Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h1287, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1287
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, h1288, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1288
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, h1289, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1289
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h1290, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1290
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h1291, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1291
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h1292, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1292
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1293, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1293
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h1294, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1294
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, h1295, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1295
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, h1296, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1296
                        }
                    }, Some(Adt41::C11(v3)), match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1297, _, _, _, _, _, _, _, _, _) => {
                            h1297
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1298, _, _, _, _, _, _, _, _) => {
                            h1298
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1299, _, _, _, _, _, _, _) => {
                            h1299
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1300, _, _, _, _, _, _) => {
                            h1300
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1301, _, _, _, _, _) => {
                            h1301
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1302, _, _, _, _) => {
                            h1302
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1303, _, _, _) => {
                            h1303
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1304, _, _) => {
                            h1304
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1305, _) => {
                            h1305
                        }
                    }, match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1306) => {
                            h1306
                        }
                    }), List::<Adt65>::nil()))
                }
            }
        } else {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1348, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1348
                }
            }, match v0.clone() {
                Adt1::C0(_, h1349, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1349
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1350, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1350
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1351, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1351
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1352, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1352
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1353, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1353
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1354, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1354
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1355, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1355
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1356, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1356
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1357, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1357
                }
            }, Some(Adt41::C10(Adt43::C11)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1358, _, _, _, _, _, _, _, _, _) => {
                    h1358
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1359, _, _, _, _, _, _, _, _) => {
                    h1359
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1360, _, _, _, _, _, _, _) => {
                    h1360
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1361, _, _, _, _, _, _) => {
                    h1361
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1362, _, _, _, _, _) => {
                    h1362
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1363, _, _, _, _) => {
                    h1363
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1364, _, _, _) => {
                    h1364
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1365, _, _) => {
                    h1365
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1366, _) => {
                    h1366
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1367) => {
                    h1367
                }
            }), List::<Adt65>::nil()))
        }
    } else {
        Ok(Adt71::C0(v0, List::<Adt65>::nil()))
    }
}

pub fn f56(v0: Adt1, v1: Adt52) -> bool {
    let a1370 = match v0.clone() {
        Adt1::C0(h1368, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1368
        }
    };
    let a1371 = match v1.clone() {
        Adt52::C0(h1369, _, _) => {
            h1369
        }
    };
    if nat_eq(a1370, a1371) {
        if match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1372, _, _, _, _, _, _, _) => {
                h1372
            }
        } {
            let a1374 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1373, _, _, _, _, _, _) => {
                    h1373
                }
            };
            if bool_not(a1374) {
                f78(match v0 {
                    Adt1::C0(_, h1375, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1375
                    }
                }, match v1.clone() {
                    Adt52::C0(_, h1376, _) => {
                        h1376
                    }
                }, match v1 {
                    Adt52::C0(_, _, h1377) => {
                        h1377
                    }
                })
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f57(v0: Option<Adt11>) -> List<Adt65> {
    let m1378 = v0;
    match m1378 {
        None => {
            List::<Adt65>::nil()
        }
        Some(v1) => {
            List::cons(Adt65::C6(v1), List::<Adt65>::nil())
        }
    }
}

pub fn f58(v0: Adt1, v1: Adt52, v2: Adt22) -> R<Adt71> {
    f79(v0.clone(), v1.clone(), v2, f56(v0, v1))
}

pub fn f59(v0: Adt1, v1: Adt52, v2: Adt69) -> Adt71 {
    if if f30(v0.clone(), v1.clone()) {
        match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1379, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1379
            }
        }
    } else {
        false
    } {
        Adt71::C0(Adt1::C0({
            let m1384 = {
                let m1383 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1382) => {
                        h1382
                    }
                });
                match m1383 {
                    Adt71::C0(h1381, _) => {
                        h1381
                    }
                }
            };
            match m1384 {
                Adt1::C0(h1380, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1380
                }
            }
        }, {
            let m1389 = {
                let m1388 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1387) => {
                        h1387
                    }
                });
                match m1388 {
                    Adt71::C0(h1386, _) => {
                        h1386
                    }
                }
            };
            match m1389 {
                Adt1::C0(_, h1385, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1385
                }
            }
        }, {
            let m1394 = {
                let m1393 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1392) => {
                        h1392
                    }
                });
                match m1393 {
                    Adt71::C0(h1391, _) => {
                        h1391
                    }
                }
            };
            match m1394 {
                Adt1::C0(_, _, h1390, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1390
                }
            }
        }, {
            let m1399 = {
                let m1398 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1397) => {
                        h1397
                    }
                });
                match m1398 {
                    Adt71::C0(h1396, _) => {
                        h1396
                    }
                }
            };
            match m1399 {
                Adt1::C0(_, _, _, h1395, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1395
                }
            }
        }, {
            let m1404 = {
                let m1403 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1402) => {
                        h1402
                    }
                });
                match m1403 {
                    Adt71::C0(h1401, _) => {
                        h1401
                    }
                }
            };
            match m1404 {
                Adt1::C0(_, _, _, _, h1400, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1400
                }
            }
        }, {
            let m1409 = {
                let m1408 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1407) => {
                        h1407
                    }
                });
                match m1408 {
                    Adt71::C0(h1406, _) => {
                        h1406
                    }
                }
            };
            match m1409 {
                Adt1::C0(_, _, _, _, _, h1405, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1405
                }
            }
        }, {
            let m1414 = {
                let m1413 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1412) => {
                        h1412
                    }
                });
                match m1413 {
                    Adt71::C0(h1411, _) => {
                        h1411
                    }
                }
            };
            match m1414 {
                Adt1::C0(_, _, _, _, _, _, h1410, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1410
                }
            }
        }, {
            let m1419 = {
                let m1418 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1417) => {
                        h1417
                    }
                });
                match m1418 {
                    Adt71::C0(h1416, _) => {
                        h1416
                    }
                }
            };
            match m1419 {
                Adt1::C0(_, _, _, _, _, _, _, h1415, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1415
                }
            }
        }, {
            let m1424 = {
                let m1423 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1422) => {
                        h1422
                    }
                });
                match m1423 {
                    Adt71::C0(h1421, _) => {
                        h1421
                    }
                }
            };
            match m1424 {
                Adt1::C0(_, _, _, _, _, _, _, _, h1420, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1420
                }
            }
        }, {
            let m1429 = {
                let m1428 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1427) => {
                        h1427
                    }
                });
                match m1428 {
                    Adt71::C0(h1426, _) => {
                        h1426
                    }
                }
            };
            match m1429 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1425, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1425
                }
            }
        }, Some(match v2.clone() {
            Adt69::C0(h1430, _, _) => {
                h1430
            }
        }), {
            let m1435 = {
                let m1434 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1433) => {
                        h1433
                    }
                });
                match m1434 {
                    Adt71::C0(h1432, _) => {
                        h1432
                    }
                }
            };
            match m1435 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1431, _, _, _, _, _, _, _, _, _) => {
                    h1431
                }
            }
        }, {
            let m1440 = {
                let m1439 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1438) => {
                        h1438
                    }
                });
                match m1439 {
                    Adt71::C0(h1437, _) => {
                        h1437
                    }
                }
            };
            match m1440 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1436, _, _, _, _, _, _, _, _) => {
                    h1436
                }
            }
        }, {
            let m1445 = {
                let m1444 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1443) => {
                        h1443
                    }
                });
                match m1444 {
                    Adt71::C0(h1442, _) => {
                        h1442
                    }
                }
            };
            match m1445 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1441, _, _, _, _, _, _, _) => {
                    h1441
                }
            }
        }, {
            let m1450 = {
                let m1449 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1448) => {
                        h1448
                    }
                });
                match m1449 {
                    Adt71::C0(h1447, _) => {
                        h1447
                    }
                }
            };
            match m1450 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1446, _, _, _, _, _, _) => {
                    h1446
                }
            }
        }, {
            let m1455 = {
                let m1454 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1453) => {
                        h1453
                    }
                });
                match m1454 {
                    Adt71::C0(h1452, _) => {
                        h1452
                    }
                }
            };
            match m1455 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1451, _, _, _, _, _) => {
                    h1451
                }
            }
        }, {
            let m1460 = {
                let m1459 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1458) => {
                        h1458
                    }
                });
                match m1459 {
                    Adt71::C0(h1457, _) => {
                        h1457
                    }
                }
            };
            match m1460 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1456, _, _, _, _) => {
                    h1456
                }
            }
        }, {
            let m1465 = {
                let m1464 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1463) => {
                        h1463
                    }
                });
                match m1464 {
                    Adt71::C0(h1462, _) => {
                        h1462
                    }
                }
            };
            match m1465 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1461, _, _, _) => {
                    h1461
                }
            }
        }, {
            let m1470 = {
                let m1469 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1468) => {
                        h1468
                    }
                });
                match m1469 {
                    Adt71::C0(h1467, _) => {
                        h1467
                    }
                }
            };
            match m1470 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1466, _, _) => {
                    h1466
                }
            }
        }, Some(match v2.clone() {
            Adt69::C0(_, h1471, _) => {
                h1471
            }
        }), {
            let m1476 = {
                let m1475 = f63(v0.clone(), v1.clone(), match v2.clone() {
                    Adt69::C0(_, _, h1474) => {
                        h1474
                    }
                });
                match m1475 {
                    Adt71::C0(h1473, _) => {
                        h1473
                    }
                }
            };
            match m1476 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1472) => {
                    h1472
                }
            }
        }), {
            let m1479 = f63(v0, v1, match v2 {
                Adt69::C0(_, _, h1478) => {
                    h1478
                }
            });
            match m1479 {
                Adt71::C0(_, h1477) => {
                    h1477
                }
            }
        })
    } else {
        if f56(v0.clone(), v1.clone()) {
            Adt71::C0(Adt1::C0({
                let m1484 = {
                    let m1483 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1482, _, _) => {
                            h1482
                        }
                    });
                    match m1483 {
                        Adt71::C0(h1481, _) => {
                            h1481
                        }
                    }
                };
                match m1484 {
                    Adt1::C0(h1480, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1480
                    }
                }
            }, {
                let m1489 = {
                    let m1488 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1487, _, _) => {
                            h1487
                        }
                    });
                    match m1488 {
                        Adt71::C0(h1486, _) => {
                            h1486
                        }
                    }
                };
                match m1489 {
                    Adt1::C0(_, h1485, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1485
                    }
                }
            }, f61(match v0.clone() {
                Adt1::C0(_, _, h1490, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1490
                }
            }, match v2.clone() {
                Adt69::C0(_, _, h1491) => {
                    h1491
                }
            }), {
                let m1496 = {
                    let m1495 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1494, _, _) => {
                            h1494
                        }
                    });
                    match m1495 {
                        Adt71::C0(h1493, _) => {
                            h1493
                        }
                    }
                };
                match m1496 {
                    Adt1::C0(_, _, _, h1492, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1492
                    }
                }
            }, {
                let m1501 = {
                    let m1500 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1499, _, _) => {
                            h1499
                        }
                    });
                    match m1500 {
                        Adt71::C0(h1498, _) => {
                            h1498
                        }
                    }
                };
                match m1501 {
                    Adt1::C0(_, _, _, _, h1497, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1497
                    }
                }
            }, {
                let m1506 = {
                    let m1505 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1504, _, _) => {
                            h1504
                        }
                    });
                    match m1505 {
                        Adt71::C0(h1503, _) => {
                            h1503
                        }
                    }
                };
                match m1506 {
                    Adt1::C0(_, _, _, _, _, h1502, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1502
                    }
                }
            }, {
                let m1511 = {
                    let m1510 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1509, _, _) => {
                            h1509
                        }
                    });
                    match m1510 {
                        Adt71::C0(h1508, _) => {
                            h1508
                        }
                    }
                };
                match m1511 {
                    Adt1::C0(_, _, _, _, _, _, h1507, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1507
                    }
                }
            }, {
                let m1516 = {
                    let m1515 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1514, _, _) => {
                            h1514
                        }
                    });
                    match m1515 {
                        Adt71::C0(h1513, _) => {
                            h1513
                        }
                    }
                };
                match m1516 {
                    Adt1::C0(_, _, _, _, _, _, _, h1512, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1512
                    }
                }
            }, {
                let m1521 = {
                    let m1520 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1519, _, _) => {
                            h1519
                        }
                    });
                    match m1520 {
                        Adt71::C0(h1518, _) => {
                            h1518
                        }
                    }
                };
                match m1521 {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1517, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1517
                    }
                }
            }, {
                let m1526 = {
                    let m1525 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1524, _, _) => {
                            h1524
                        }
                    });
                    match m1525 {
                        Adt71::C0(h1523, _) => {
                            h1523
                        }
                    }
                };
                match m1526 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1522, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1522
                    }
                }
            }, {
                let m1531 = {
                    let m1530 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1529, _, _) => {
                            h1529
                        }
                    });
                    match m1530 {
                        Adt71::C0(h1528, _) => {
                            h1528
                        }
                    }
                };
                match m1531 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1527, _, _, _, _, _, _, _, _, _, _) => {
                        h1527
                    }
                }
            }, {
                let m1536 = {
                    let m1535 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1534, _, _) => {
                            h1534
                        }
                    });
                    match m1535 {
                        Adt71::C0(h1533, _) => {
                            h1533
                        }
                    }
                };
                match m1536 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1532, _, _, _, _, _, _, _, _, _) => {
                        h1532
                    }
                }
            }, {
                let m1541 = {
                    let m1540 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1539, _, _) => {
                            h1539
                        }
                    });
                    match m1540 {
                        Adt71::C0(h1538, _) => {
                            h1538
                        }
                    }
                };
                match m1541 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1537, _, _, _, _, _, _, _, _) => {
                        h1537
                    }
                }
            }, {
                let m1546 = {
                    let m1545 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1544, _, _) => {
                            h1544
                        }
                    });
                    match m1545 {
                        Adt71::C0(h1543, _) => {
                            h1543
                        }
                    }
                };
                match m1546 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1542, _, _, _, _, _, _, _) => {
                        h1542
                    }
                }
            }, {
                let m1551 = {
                    let m1550 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1549, _, _) => {
                            h1549
                        }
                    });
                    match m1550 {
                        Adt71::C0(h1548, _) => {
                            h1548
                        }
                    }
                };
                match m1551 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1547, _, _, _, _, _, _) => {
                        h1547
                    }
                }
            }, {
                let m1556 = {
                    let m1555 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1554, _, _) => {
                            h1554
                        }
                    });
                    match m1555 {
                        Adt71::C0(h1553, _) => {
                            h1553
                        }
                    }
                };
                match m1556 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1552, _, _, _, _, _) => {
                        h1552
                    }
                }
            }, {
                let m1561 = {
                    let m1560 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1559, _, _) => {
                            h1559
                        }
                    });
                    match m1560 {
                        Adt71::C0(h1558, _) => {
                            h1558
                        }
                    }
                };
                match m1561 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1557, _, _, _, _) => {
                        h1557
                    }
                }
            }, {
                let m1566 = {
                    let m1565 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1564, _, _) => {
                            h1564
                        }
                    });
                    match m1565 {
                        Adt71::C0(h1563, _) => {
                            h1563
                        }
                    }
                };
                match m1566 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1562, _, _, _) => {
                        h1562
                    }
                }
            }, {
                let m1571 = {
                    let m1570 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1569, _, _) => {
                            h1569
                        }
                    });
                    match m1570 {
                        Adt71::C0(h1568, _) => {
                            h1568
                        }
                    }
                };
                match m1571 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1567, _, _) => {
                        h1567
                    }
                }
            }, Some(match v2.clone() {
                Adt69::C0(_, h1572, _) => {
                    h1572
                }
            }), {
                let m1577 = {
                    let m1576 = f80(v0.clone(), v1.clone(), match v2.clone() {
                        Adt69::C0(h1575, _, _) => {
                            h1575
                        }
                    });
                    match m1576 {
                        Adt71::C0(h1574, _) => {
                            h1574
                        }
                    }
                };
                match m1577 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1573) => {
                        h1573
                    }
                }
            }), {
                let m1580 = f80(v0, v1, match v2 {
                    Adt69::C0(h1579, _, _) => {
                        h1579
                    }
                });
                match m1580 {
                    Adt71::C0(_, h1578) => {
                        h1578
                    }
                }
            })
        } else {
            Adt71::C0(v0, List::<Adt65>::nil())
        }
    }
}

pub fn f60(v0: Adt2) -> Adt2 {
    if match v0.clone() {
        Adt2::C0(_, _, h1581, _, _, _) => {
            h1581
        }
    } {
        Adt2::C0(match v0.clone() {
            Adt2::C0(h1582, _, _, _, _, _) => {
                h1582
            }
        }, match v0 {
            Adt2::C0(_, h1583, _, _, _, _) => {
                h1583
            }
        }, false, false, Adt3::C5, Adt4::C0)
    } else {
        v0
    }
}

pub fn f61(v0: Adt5, v1: Adt7) -> Adt5 {
    Adt5::C0(Adt6::C4, match v0.clone() {
        Adt5::C0(_, h1584, _, _, _) => {
            h1584
        }
    }, match v0 {
        Adt5::C0(_, _, h1585, _, _) => {
            h1585
        }
    }, false, v1)
}

pub fn f62(v0: Adt1) -> Adt71 {
    if f81(v0.clone()) {
        let m1587 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1586, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1586
            }
        };
        match m1587 {
            None => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1588, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1588
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1589, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1589
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1590, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1590
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1591, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1591
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1592, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1592
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1593, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1593
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1594, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1594
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1595, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1595
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1596, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1596
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1597, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1597
                    }
                }, Some(Adt41::C10(Adt43::C5)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1598, _, _, _, _, _, _, _, _, _) => {
                        h1598
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1599, _, _, _, _, _, _, _, _) => {
                        h1599
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1600, _, _, _, _, _, _, _) => {
                        h1600
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1601, _, _, _, _, _, _) => {
                        h1601
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1602, _, _, _, _, _) => {
                        h1602
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1603, _, _, _, _) => {
                        h1603
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1604, _, _, _) => {
                        h1604
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1605, _, _) => {
                        h1605
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1606, _) => {
                        h1606
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1607) => {
                        h1607
                    }
                }), List::<Adt65>::nil())
            }
            Some(v1) => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1608, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1608
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1609, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1609
                    }
                }, f82(match v0.clone() {
                    Adt1::C0(_, _, h1610, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1610
                    }
                }), match v0.clone() {
                    Adt1::C0(_, _, _, h1611, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1611
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1612, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1612
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1613, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1613
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1614, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1614
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1615, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1615
                    }
                }, true, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1616, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1616
                    }
                }, None::<Adt41>, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1617, _, _, _, _, _, _, _, _, _) => {
                        h1617
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1618, _, _, _, _, _, _, _, _) => {
                        h1618
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1619, _, _, _, _, _, _, _) => {
                        h1619
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1620, _, _, _, _, _, _) => {
                        h1620
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1621, _, _, _, _, _) => {
                        h1621
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1622, _, _, _, _) => {
                        h1622
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1623, _, _, _) => {
                        h1623
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1624, _, _) => {
                        h1624
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1625, _) => {
                        h1625
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1626) => {
                        h1626
                    }
                }), List::cons(Adt65::C7(f29(v0), v1), List::<Adt65>::nil()))
            }
        }
    } else {
        Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1627, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1627
            }
        }, match v0.clone() {
            Adt1::C0(_, h1628, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1628
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1629, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1629
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1630, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1630
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1631, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1631
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1632, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1632
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1633, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1633
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1634, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1634
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1635, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1635
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1636, _, _, _, _, _, _, _, _, _, _, _) => {
                h1636
            }
        }, Some(Adt41::C10(Adt43::C5)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1637, _, _, _, _, _, _, _, _, _) => {
                h1637
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1638, _, _, _, _, _, _, _, _) => {
                h1638
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1639, _, _, _, _, _, _, _) => {
                h1639
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1640, _, _, _, _, _, _) => {
                h1640
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1641, _, _, _, _, _) => {
                h1641
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1642, _, _, _, _) => {
                h1642
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1643, _, _, _) => {
                h1643
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1644, _, _) => {
                h1644
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1645, _) => {
                h1645
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1646) => {
                h1646
            }
        }), List::<Adt65>::nil())
    }
}

pub fn f63(v0: Adt1, v1: Adt52, v2: Adt7) -> Adt71 {
    if if f30(v0.clone(), v1) {
        match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1647, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1647
            }
        }
    } else {
        false
    } {
        let m1649 = f83(match v0.clone() {
            Adt1::C0(_, _, h1648, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1648
            }
        }, v2.clone());
        match m1649 {
            Ok(v4) => {
                let m1670 = v2.clone();
                match m1670 {
                    Adt7::C0 => {
                        Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1671, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1671
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1672, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1672
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, h1673, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1673
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, h1674, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1674
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1675, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1675
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1676, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1676
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1677, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1677
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1678, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1678
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h1679, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1679
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1680, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1680
                            }
                        }, Some(Adt41::C10(Adt43::C13)), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1681, _, _, _, _, _, _, _, _, _) => {
                                h1681
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1682, _, _, _, _, _, _, _, _) => {
                                h1682
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1683, _, _, _, _, _, _, _) => {
                                h1683
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1684, _, _, _, _, _, _) => {
                                h1684
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1685, _, _, _, _, _) => {
                                h1685
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1686, _, _, _, _) => {
                                h1686
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1687, _, _, _) => {
                                h1687
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1688, _, _) => {
                                h1688
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1689, _) => {
                                h1689
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1690) => {
                                h1690
                            }
                        }), List::<Adt65>::nil())
                    }
                    Adt7::C1 => {
                        Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1691, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1691
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1692, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1692
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1693, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1693
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1694, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1694
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1695, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1695
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1696, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1696
                            }
                        }, None::<Adt11>, false, true, None::<Adt41>, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1697, _, _, _, _, _, _, _, _, _) => {
                                h1697
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1698, _, _, _, _, _, _, _, _) => {
                                h1698
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1699, _, _, _, _, _, _, _) => {
                                h1699
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1700, _, _, _, _, _, _) => {
                                h1700
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1701, _, _, _, _, _) => {
                                h1701
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1702, _, _, _, _) => {
                                h1702
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1703, _, _, _) => {
                                h1703
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1704, _, _) => {
                                h1704
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1705, _) => {
                                h1705
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1706) => {
                                h1706
                            }
                        }), List::<Adt65>::nil())
                    }
                    Adt7::C2 => {
                        Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1707, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1707
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1708, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1708
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1709, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1709
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1710, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1710
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1711, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1711
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1712, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1712
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1713, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1713
                            }
                        }, false, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1714, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1714
                            }
                        }, Some(Adt41::C9(v2, Str::lit("Output was not published; the staged result is retained."))), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1715, _, _, _, _, _, _, _, _, _) => {
                                h1715
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1716, _, _, _, _, _, _, _, _) => {
                                h1716
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1717, _, _, _, _, _, _, _) => {
                                h1717
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1718, _, _, _, _, _, _) => {
                                h1718
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1719, _, _, _, _, _) => {
                                h1719
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1720, _, _, _, _) => {
                                h1720
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1721, _, _, _) => {
                                h1721
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1722, _, _) => {
                                h1722
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1723, _) => {
                                h1723
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1724) => {
                                h1724
                            }
                        }), List::<Adt65>::nil())
                    }
                    Adt7::C3 => {
                        Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1725, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1725
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1726, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1726
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1727, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1727
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1728, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1728
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1729, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1729
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1730, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1730
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1731, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1731
                            }
                        }, false, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1732, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1732
                            }
                        }, Some(Adt41::C9(v2, Str::lit("Publication outcome is unknown; reconcile with the destination before retrying."))), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1733, _, _, _, _, _, _, _, _, _) => {
                                h1733
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1734, _, _, _, _, _, _, _, _) => {
                                h1734
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1735, _, _, _, _, _, _, _) => {
                                h1735
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1736, _, _, _, _, _, _) => {
                                h1736
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1737, _, _, _, _, _) => {
                                h1737
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1738, _, _, _, _) => {
                                h1738
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1739, _, _, _) => {
                                h1739
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1740, _, _) => {
                                h1740
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1741, _) => {
                                h1741
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1742) => {
                                h1742
                            }
                        }), List::<Adt65>::nil())
                    }
                }
            }
            Err(v3) => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1650, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1650
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1651, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1651
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1652, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1652
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1653, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1653
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1654, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1654
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1655, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1655
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1656, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1656
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1657, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1657
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1658, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1658
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1659, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1659
                    }
                }, Some(Adt41::C11(v3)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1660, _, _, _, _, _, _, _, _, _) => {
                        h1660
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1661, _, _, _, _, _, _, _, _) => {
                        h1661
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1662, _, _, _, _, _, _, _) => {
                        h1662
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1663, _, _, _, _, _, _) => {
                        h1663
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1664, _, _, _, _, _) => {
                        h1664
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1665, _, _, _, _) => {
                        h1665
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1666, _, _, _) => {
                        h1666
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1667, _, _) => {
                        h1667
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1668, _) => {
                        h1668
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1669) => {
                        h1669
                    }
                }), List::<Adt65>::nil())
            }
        }
    } else {
        Adt71::C0(v0, List::<Adt65>::nil())
    }
}

pub fn f64(v0: Adt1, v1: Adt52, v2: u64) -> R<Adt71> {
    if f56(v0.clone(), v1.clone()) {
        let m1744 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1743, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1743
            }
        };
        match m1744 {
            None => {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1745, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1745
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1746, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1746
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1747, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1747
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1748, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1748
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1749, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1749
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1750, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1750
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1751, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1751
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1752, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1752
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1753, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1753
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1754, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1754
                    }
                }, Some(Adt41::C10(Adt43::C3)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1755, _, _, _, _, _, _, _, _, _) => {
                        h1755
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1756, _, _, _, _, _, _, _, _) => {
                        h1756
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1757, _, _, _, _, _, _, _) => {
                        h1757
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1758, _, _, _, _, _, _) => {
                        h1758
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1759, _, _, _, _, _) => {
                        h1759
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1760, _, _, _, _) => {
                        h1760
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1761, _, _, _) => {
                        h1761
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1762, _, _) => {
                        h1762
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1763, _) => {
                        h1763
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1764) => {
                        h1764
                    }
                }), List::<Adt65>::nil()))
            }
            Some(v3) => {
                let m1776 = f84(match v0.clone() {
                    Adt1::C0(_, _, h1765, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1765
                    }
                }, v2, {
                    let m1770 = {
                        let m1769 = {
                            let m1768 = f70(v3);
                            match m1768 {
                                Adt12::C0(h1767, _) => {
                                    h1767
                                }
                            }
                        };
                        match m1769 {
                            Adt13::C0(_, _, _, _, h1766, _, _) => {
                                h1766
                            }
                        }
                    };
                    match m1770 {
                        None => {
                            let a1774 = {
                                let m1773 = match v0.clone() {
                                    Adt1::C0(_, _, h1772, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                        h1772
                                    }
                                };
                                match m1773 {
                                    Adt5::C0(_, _, h1771, _, _) => {
                                        h1771
                                    }
                                }
                            };
                            let a1775 = v2;
                            nat_add(a1774, a1775)?
                        }
                        Some(v4) => {
                            v4
                        }
                    }
                })?;
                match m1776 {
                    Ok(v6) => {
                        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1777, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1777
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1778, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1778
                            }
                        }, v6, match v0.clone() {
                            Adt1::C0(_, _, _, h1779, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1779
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1780, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1780
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1781, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1781
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1782, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1782
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1783, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1783
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h1784, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1784
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1785, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1785
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1786, _, _, _, _, _, _, _, _, _, _) => {
                                h1786
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1787, _, _, _, _, _, _, _, _, _) => {
                                h1787
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1788, _, _, _, _, _, _, _, _) => {
                                h1788
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1789, _, _, _, _, _, _, _) => {
                                h1789
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1790, _, _, _, _, _, _) => {
                                h1790
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1791, _, _, _, _, _) => {
                                h1791
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1792, _, _, _, _) => {
                                h1792
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1793, _, _, _) => {
                                h1793
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1794, _, _) => {
                                h1794
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1795, _) => {
                                h1795
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1796) => {
                                h1796
                            }
                        }), List::<Adt65>::nil()))
                    }
                    Err(v5) => {
                        Ok(f80(v0, v1, Adt41::C11(v5)))
                    }
                }
            }
        }
    } else {
        Ok(Adt71::C0(v0, List::<Adt65>::nil()))
    }
}

pub fn f65(v0: Adt1, v1: Adt52, v2: Adt70) -> R<Adt71> {
    if f30(v0.clone(), v1.clone()) {
        let m1798 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1797, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1797
            }
        };
        match m1798 {
            None => {
                Ok(Adt71::C0(v0, List::<Adt65>::nil()))
            }
            Some(v3) => {
                Ok(f85(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1799, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1799
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1800, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1800
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1801, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1801
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1802, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1802
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1803, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1803
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1804, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1804
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1805, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1805
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1806, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1806
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1807, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1807
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1808, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1808
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1809, _, _, _, _, _, _, _, _, _, _) => {
                        h1809
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1810, _, _, _, _, _, _, _, _, _) => {
                        h1810
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1811, _, _, _, _, _, _, _, _) => {
                        h1811
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1812, _, _, _, _, _, _, _) => {
                        h1812
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1813, _, _, _, _, _, _) => {
                        h1813
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1814, _, _, _, _, _) => {
                        h1814
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1815, _, _, _, _) => {
                        h1815
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1816, _, _, _) => {
                        h1816
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1817, _, _) => {
                        h1817
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1818, _) => {
                        h1818
                    }
                }, f66(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1819) => {
                        h1819
                    }
                }, v1, v2.clone())?), f86({
                    let m1823 = {
                        let m1822 = f70(v3);
                        match m1822 {
                            Adt12::C0(h1821, _) => {
                                h1821
                            }
                        }
                    };
                    match m1823 {
                        Adt13::C0(_, _, _, _, _, _, h1820) => {
                            h1820
                        }
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1824, _, _) => {
                        h1824
                    }
                }, v2)?))
            }
        }
    } else {
        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1825, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1825
            }
        }, match v0.clone() {
            Adt1::C0(_, h1826, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1826
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1827, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1827
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1828, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1828
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1829, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1829
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1830, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1830
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1831, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1831
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1832, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1832
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1833, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1833
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1834, _, _, _, _, _, _, _, _, _, _, _) => {
                h1834
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1835, _, _, _, _, _, _, _, _, _, _) => {
                h1835
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1836, _, _, _, _, _, _, _, _, _) => {
                h1836
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1837, _, _, _, _, _, _, _, _) => {
                h1837
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1838, _, _, _, _, _, _, _) => {
                h1838
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1839, _, _, _, _, _, _) => {
                h1839
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1840, _, _, _, _, _) => {
                h1840
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1841, _, _, _, _) => {
                h1841
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1842, _, _, _) => {
                h1842
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1843, _, _) => {
                h1843
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1844, _) => {
                h1844
            }
        }, f66(match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1845) => {
                h1845
            }
        }, v1, v2)?), List::<Adt65>::nil()))
    }
}

pub fn f66(v0: List<Adt51>, v1: Adt52, v2: Adt70) -> R<List<Adt51>> {
    let m1846 = v0;
    match m1846.uncons() {
        None => {
            Ok(List::<Adt51>::nil())
        }
        Some((v3, v4)) => {
            Ok(List::cons(if f87(match v3.clone() {
                Adt51::C0(h1847, _, _, _) => {
                    h1847
                }
            }, v1.clone()) {
                Adt51::C0(match v3.clone() {
                    Adt51::C0(h1848, _, _, _) => {
                        h1848
                    }
                }, match v3.clone() {
                    Adt51::C0(_, h1849, _, _) => {
                        h1849
                    }
                }, f86(match v3.clone() {
                    Adt51::C0(_, h1850, _, _) => {
                        h1850
                    }
                }, match v3.clone() {
                    Adt51::C0(_, _, h1851, _) => {
                        h1851
                    }
                }, v2.clone())?, match v3 {
                    Adt51::C0(_, _, _, h1852) => {
                        h1852
                    }
                })
            } else {
                v3
            }, f66(v4, v1, v2)?))
        }
    }
}

pub fn f67(v0: List<Adt51>, v1: Adt52) -> R<List<Adt51>> {
    let m1853 = v0;
    match m1853.uncons() {
        None => {
            Ok(List::<Adt51>::nil())
        }
        Some((v2, v3)) => {
            if if f87(match v2.clone() {
                Adt51::C0(h1854, _, _, _) => {
                    h1854
                }
            }, v1.clone()) {
                let a1858 = f88({
                    let m1857 = match v2.clone() {
                        Adt51::C0(_, _, h1856, _) => {
                            h1856
                        }
                    };
                    match m1857 {
                        Adt50::C0(h1855, _) => {
                            h1855
                        }
                    }
                })?;
                let a1859 = 0u64;
                if nat_eq(a1858, a1859) {
                    let a1863 = f89({
                        let m1862 = match v2.clone() {
                            Adt51::C0(_, _, h1861, _) => {
                                h1861
                            }
                        };
                        match m1862 {
                            Adt50::C0(h1860, _) => {
                                h1860
                            }
                        }
                    })?;
                    let a1864 = 0u64;
                    nat_eq(a1863, a1864)
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(v3)
            } else {
                Ok(List::cons(v2, f67(v3, v1)?))
            }
        }
    }
}

pub fn f68() -> Adt24 {
    Adt24::C0(f90(), f90(), 0u64, 0u64)
}

pub fn f69() -> Adt14 {
    Adt14::C0(None::<u64>, None::<u64>, None::<u64>, None::<u64>, None::<u64>)
}

pub fn f70(v0: Adt9) -> Adt12 {
    let m1865 = v0;
    match m1865 {
        Adt9::C0(v1) => {
            match v1 {
                Adt10::C0(_, h1866) => {
                    h1866
                }
            }
        }
        Adt9::C1(v2) => {
            match v2 {
                Adt15::C0(_, h1867) => {
                    h1867
                }
            }
        }
        Adt9::C2(v3) => {
            match v3 {
                Adt15::C0(_, h1868) => {
                    h1868
                }
            }
        }
        Adt9::C3(v4) => {
            match v4 {
                Adt16::C0(_, _, _, h1869) => {
                    h1869
                }
            }
        }
        Adt9::C4(v5) => {
            match v5 {
                Adt17::C0(_, _, h1870) => {
                    h1870
                }
            }
        }
        Adt9::C5(v6) => {
            match v6 {
                Adt18::C0(_, h1871) => {
                    h1871
                }
            }
        }
        Adt9::C6(v7) => {
            match v7 {
                Adt19::C0(_, _, h1872) => {
                    h1872
                }
            }
        }
        Adt9::C7(v8) => {
            match v8 {
                Adt20::C0(_, _, _, h1873) => {
                    h1873
                }
            }
        }
        Adt9::C8(v9) => {
            match v9 {
                Adt21::C0(_, h1874) => {
                    h1874
                }
            }
        }
        Adt9::C9(v10) => {
            match v10 {
                Adt21::C0(_, h1875) => {
                    h1875
                }
            }
        }
    }
}

pub fn f71(v0: Adt53) -> List<Adt65> {
    f34(f57(match v0.clone() {
        Adt53::C0(_, h1876, _, _, _, _, _, _) => {
            h1876
        }
    }), f34(f57(match v0.clone() {
        Adt53::C0(_, _, h1877, _, _, _, _, _) => {
            h1877
        }
    }), f34(f57(match v0.clone() {
        Adt53::C0(_, _, _, h1878, _, _, _, _) => {
            h1878
        }
    }), f34(f57(match v0.clone() {
        Adt53::C0(_, _, _, _, h1879, _, _, _) => {
            h1879
        }
    }), f34(f57(match v0.clone() {
        Adt53::C0(_, _, _, _, _, h1880, _, _) => {
            h1880
        }
    }), f34(f57(match v0 {
        Adt53::C0(_, _, _, _, _, _, h1881, _) => {
            h1881
        }
    }), List::<Adt65>::nil()))))))
}

pub fn f72(v0: Adt2) -> R<Adt2> {
    Ok(Adt2::C0({
        let a1883 = match v0.clone() {
            Adt2::C0(h1882, _, _, _, _, _) => {
                h1882
            }
        };
        let a1884 = 1u64;
        nat_add(a1883, a1884)?
    }, match v0 {
        Adt2::C0(_, h1885, _, _, _, _) => {
            h1885
        }
    }, false, false, Adt3::C0, Adt4::C0))
}

pub fn f73(v0: Adt5) -> Result<Adt5, Adt44> {
    let m1887 = match v0.clone() {
        Adt5::C0(h1886, _, _, _, _) => {
            h1886
        }
    };
    match m1887 {
        Adt6::C0 => {
            if match v0.clone() {
                Adt5::C0(_, h1888, _, _, _) => {
                    h1888
                }
            } {
                Err::<Adt5, Adt44>(Adt44::C1)
            } else {
                Ok::<Adt5, Adt44>(Adt5::C0(Adt6::C1, match v0.clone() {
                    Adt5::C0(_, h1889, _, _, _) => {
                        h1889
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h1890, _, _) => {
                        h1890
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, _, h1891, _) => {
                        h1891
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, _, h1892) => {
                        h1892
                    }
                }))
            }
        }
        Adt6::C1 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C2 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C3 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C4 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
    }
}

pub fn f74(v0: Adt1, v1: Adt66) -> bool {
    let m1893 = v1;
    match m1893 {
        Adt66::C0(_) => {
            true
        }
        Adt66::C1(v3) => {
            let a1898 = {
                let m1896 = match v3 {
                    Adt67::C0(h1895, _, _) => {
                        h1895
                    }
                };
                match m1896 {
                    Adt11::C0(h1894, _, _) => {
                        h1894
                    }
                }
            };
            let a1899 = match v0 {
                Adt1::C0(h1897, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1897
                }
            };
            nat_eq(a1898, a1899)
        }
        Adt66::C2(_) => {
            true
        }
        Adt66::C3 => {
            true
        }
    }
}

pub fn f75(v0: Adt5, v1: Adt72) -> Adt73 {
    let m1900 = v1;
    match m1900 {
        Adt72::C0 => {
            let m1902 = match v0.clone() {
                Adt5::C0(h1901, _, _, _, _) => {
                    h1901
                }
            };
            match m1902 {
                Adt6::C0 => {
                    Adt73::C0(Adt74::C0, v0)
                }
                Adt6::C1 => {
                    Adt73::C1(Adt44::C2)
                }
                Adt6::C2 => {
                    Adt73::C1(Adt44::C2)
                }
                Adt6::C3 => {
                    Adt73::C1(Adt44::C2)
                }
                Adt6::C4 => {
                    Adt73::C1(Adt44::C2)
                }
            }
        }
        Adt72::C1 => {
            let m1904 = match v0.clone() {
                Adt5::C0(h1903, _, _, _, _) => {
                    h1903
                }
            };
            match m1904 {
                Adt6::C0 => {
                    Adt73::C1(Adt44::C0)
                }
                Adt6::C1 => {
                    if match v0.clone() {
                        Adt5::C0(_, h1905, _, _, _) => {
                            h1905
                        }
                    } {
                        Adt73::C1(Adt44::C1)
                    } else {
                        Adt73::C0(Adt74::C1, Adt5::C0(Adt6::C0, match v0.clone() {
                            Adt5::C0(_, h1906, _, _, _) => {
                                h1906
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, h1907, _, _) => {
                                h1907
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, _, h1908, _) => {
                                h1908
                            }
                        }, match v0 {
                            Adt5::C0(_, _, _, _, h1909) => {
                                h1909
                            }
                        }))
                    }
                }
                Adt6::C2 => {
                    Adt73::C1(Adt44::C0)
                }
                Adt6::C3 => {
                    Adt73::C1(Adt44::C0)
                }
                Adt6::C4 => {
                    Adt73::C1(Adt44::C0)
                }
            }
        }
        Adt72::C2 => {
            let m1911 = match v0.clone() {
                Adt5::C0(h1910, _, _, _, _) => {
                    h1910
                }
            };
            match m1911 {
                Adt6::C0 => {
                    Adt73::C1(Adt44::C0)
                }
                Adt6::C1 => {
                    if match v0.clone() {
                        Adt5::C0(_, h1912, _, _, _) => {
                            h1912
                        }
                    } {
                        Adt73::C1(Adt44::C1)
                    } else {
                        Adt73::C0(Adt74::C2, Adt5::C0(Adt6::C0, true, match v0.clone() {
                            Adt5::C0(_, _, h1913, _, _) => {
                                h1913
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, _, h1914, _) => {
                                h1914
                            }
                        }, match v0 {
                            Adt5::C0(_, _, _, _, h1915) => {
                                h1915
                            }
                        }))
                    }
                }
                Adt6::C2 => {
                    Adt73::C1(Adt44::C0)
                }
                Adt6::C3 => {
                    Adt73::C1(Adt44::C0)
                }
                Adt6::C4 => {
                    Adt73::C1(Adt44::C0)
                }
            }
        }
        Adt72::C3 => {
            let m1917 = match v0.clone() {
                Adt5::C0(h1916, _, _, _, _) => {
                    h1916
                }
            };
            match m1917 {
                Adt6::C0 => {
                    Adt73::C0(Adt74::C3, Adt5::C0(Adt6::C3, match v0.clone() {
                        Adt5::C0(_, h1918, _, _, _) => {
                            h1918
                        }
                    }, match v0 {
                        Adt5::C0(_, _, h1919, _, _) => {
                            h1919
                        }
                    }, false, Adt7::C2))
                }
                Adt6::C1 => {
                    Adt73::C0(Adt74::C3, Adt5::C0(Adt6::C3, match v0.clone() {
                        Adt5::C0(_, h1920, _, _, _) => {
                            h1920
                        }
                    }, match v0 {
                        Adt5::C0(_, _, h1921, _, _) => {
                            h1921
                        }
                    }, false, Adt7::C2))
                }
                Adt6::C2 => {
                    Adt73::C0(Adt74::C4, v0)
                }
                Adt6::C3 => {
                    Adt73::C0(Adt74::C4, v0)
                }
                Adt6::C4 => {
                    Adt73::C0(Adt74::C4, v0)
                }
            }
        }
    }
}

pub fn f76(v0: Adt66) -> Adt72 {
    let m1922 = v0;
    match m1922 {
        Adt66::C0(_) => {
            Adt72::C1
        }
        Adt66::C1(_) => {
            Adt72::C1
        }
        Adt66::C2(_) => {
            Adt72::C1
        }
        Adt66::C3 => {
            Adt72::C2
        }
    }
}

pub fn f77(v0: Adt8, v1: Adt66) -> R<Result<Adt8, Adt75>> {
    if match v0.clone() {
        Adt8::C0(_, _, h1923, _) => {
            h1923
        }
    } {
        Ok(Err::<Adt8, Adt75>(Adt75::C0))
    } else {
        let m1924 = v1;
        match m1924 {
            Adt66::C0(v2) => {
                if match v0.clone() {
                    Adt8::C0(_, h1925, _, _) => {
                        h1925
                    }
                } {
                    Ok(Err::<Adt8, Adt75>(Adt75::C1))
                } else {
                    let a1927 = v2;
                    let a1928 = match v0.clone() {
                        Adt8::C0(h1926, _, _, _) => {
                            h1926
                        }
                    };
                    if nat_eq(a1927, a1928) {
                        Ok(Ok::<Adt8, Adt75>(Adt8::C0(match v0.clone() {
                            Adt8::C0(h1929, _, _, _) => {
                                h1929
                            }
                        }, true, match v0.clone() {
                            Adt8::C0(_, _, h1930, _) => {
                                h1930
                            }
                        }, match v0 {
                            Adt8::C0(_, _, _, h1931) => {
                                h1931
                            }
                        })))
                    } else {
                        Ok(Err::<Adt8, Adt75>(Adt75::C3))
                    }
                }
            }
            Adt66::C1(v3) => {
                if match v0.clone() {
                    Adt8::C0(_, h1932, _, _) => {
                        h1932
                    }
                } {
                    Ok(Ok::<Adt8, Adt75>(Adt8::C0(match v0.clone() {
                        Adt8::C0(h1933, _, _, _) => {
                            h1933
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, h1934, _, _) => {
                            h1934
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, _, h1935, _) => {
                            h1935
                        }
                    }, {
                        let a1938 = match v0 {
                            Adt8::C0(_, _, _, h1936) => {
                                h1936
                            }
                        };
                        let a1939 = match v3 {
                            Adt67::C0(_, _, h1937) => {
                                h1937
                            }
                        };
                        nat_add(a1938, a1939)?
                    })))
                } else {
                    Ok(Err::<Adt8, Adt75>(Adt75::C2))
                }
            }
            Adt66::C2(v4) => {
                if match v0.clone() {
                    Adt8::C0(_, h1940, _, _) => {
                        h1940
                    }
                } {
                    let a1942 = v4;
                    let a1943 = match v0.clone() {
                        Adt8::C0(h1941, _, _, _) => {
                            h1941
                        }
                    };
                    if nat_eq(a1942, a1943) {
                        Ok(Ok::<Adt8, Adt75>(Adt8::C0({
                            let a1945 = match v0.clone() {
                                Adt8::C0(h1944, _, _, _) => {
                                    h1944
                                }
                            };
                            let a1946 = 1u64;
                            nat_add(a1945, a1946)?
                        }, false, match v0.clone() {
                            Adt8::C0(_, _, h1947, _) => {
                                h1947
                            }
                        }, match v0 {
                            Adt8::C0(_, _, _, h1948) => {
                                h1948
                            }
                        })))
                    } else {
                        Ok(Err::<Adt8, Adt75>(Adt75::C3))
                    }
                } else {
                    Ok(Err::<Adt8, Adt75>(Adt75::C2))
                }
            }
            Adt66::C3 => {
                if match v0.clone() {
                    Adt8::C0(_, h1949, _, _) => {
                        h1949
                    }
                } {
                    Ok(Err::<Adt8, Adt75>(Adt75::C4))
                } else {
                    Ok(Ok::<Adt8, Adt75>(Adt8::C0(match v0.clone() {
                        Adt8::C0(h1950, _, _, _) => {
                            h1950
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, h1951, _, _) => {
                            h1951
                        }
                    }, true, match v0 {
                        Adt8::C0(_, _, _, h1952) => {
                            h1952
                        }
                    })))
                }
            }
        }
    }
}

pub fn f78(v0: Adt2, v1: u64, v2: u64) -> bool {
    if match v0.clone() {
        Adt2::C0(_, _, h1953, _, _, _) => {
            h1953
        }
    } {
        let a1955 = match v0.clone() {
            Adt2::C0(_, h1954, _, _, _, _) => {
                h1954
            }
        };
        let a1956 = v1;
        if nat_eq(a1955, a1956) {
            let a1958 = match v0 {
                Adt2::C0(h1957, _, _, _, _, _) => {
                    h1957
                }
            };
            let a1959 = v2;
            nat_eq(a1958, a1959)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f79(v0: Adt1, v1: Adt52, v2: Adt22, v3: bool) -> R<Adt71> {
    if v3 {
        let m1961 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1960, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1960
            }
        };
        match m1961 {
            None => {
                Ok(f91(v0, v2))
            }
            Some(v4) => {
                f92(v0, v1, f93(v4.clone()), f94(v4, v2))
            }
        }
    } else {
        Ok(f91(v0, v2))
    }
}

pub fn f80(v0: Adt1, v1: Adt52, v2: Adt41) -> Adt71 {
    if f56(v0.clone(), v1.clone()) {
        Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1962, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1962
            }
        }, f95(match v0.clone() {
            Adt1::C0(_, h1963, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1963
            }
        }, match v1.clone() {
            Adt52::C0(_, h1964, _) => {
                h1964
            }
        }, match v1.clone() {
            Adt52::C0(_, _, h1965) => {
                h1965
            }
        }, Adt4::C5), f61(match v0.clone() {
            Adt1::C0(_, _, h1966, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1966
            }
        }, Adt7::C2), match v0.clone() {
            Adt1::C0(_, _, _, h1967, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1967
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1968, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1968
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1969, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1969
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1970, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1970
            }
        }, None::<Adt11>, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1971, _, _, _, _, _, _, _, _, _, _, _) => {
                h1971
            }
        }, Some(v2), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1972, _, _, _, _, _, _, _, _, _) => {
                h1972
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1973, _, _, _, _, _, _, _, _) => {
                h1973
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1974, _, _, _, _, _, _, _) => {
                h1974
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1975, _, _, _, _, _, _) => {
                h1975
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1976, _, _, _, _, _) => {
                h1976
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1977, _, _, _, _) => {
                h1977
            }
        }, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1978, _, _) => {
                h1978
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1979, _) => {
                h1979
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1980) => {
                h1980
            }
        }), List::cons(Adt65::C5(v1), List::<Adt65>::nil()))
    } else {
        Adt71::C0(v0, List::<Adt65>::nil())
    }
}

pub fn f81(v0: Adt1) -> bool {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1981, _, _, _, _, _, _, _) => {
            h1981
        }
    } {
        let a1983 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1982, _, _, _, _, _, _) => {
                h1982
            }
        };
        if bool_not(a1983) {
            let a1985 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1984, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1984
                }
            };
            if bool_not(a1985) {
                let m1988 = match v0.clone() {
                    Adt1::C0(_, _, h1987, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1987
                    }
                };
                if match m1988 {
                    Adt5::C0(_, _, _, h1986, _) => {
                        h1986
                    }
                } {
                    let m1990 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h1989, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1989
                        }
                    };
                    if match m1990 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    } {
                        let m1994 = {
                            let m1993 = match v0 {
                                Adt1::C0(_, _, h1992, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1992
                                }
                            };
                            match m1993 {
                                Adt5::C0(_, _, _, _, h1991) => {
                                    h1991
                                }
                            }
                        };
                        match m1994 {
                            Adt7::C0 => {
                                true
                            }
                            Adt7::C1 => {
                                false
                            }
                            Adt7::C2 => {
                                true
                            }
                            Adt7::C3 => {
                                false
                            }
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f82(v0: Adt5) -> Adt5 {
    Adt5::C0(match v0.clone() {
        Adt5::C0(h1995, _, _, _, _) => {
            h1995
        }
    }, match v0.clone() {
        Adt5::C0(_, h1996, _, _, _) => {
            h1996
        }
    }, match v0.clone() {
        Adt5::C0(_, _, h1997, _, _) => {
            h1997
        }
    }, match v0 {
        Adt5::C0(_, _, _, h1998, _) => {
            h1998
        }
    }, Adt7::C0)
}

pub fn f83(v0: Adt5, v1: Adt7) -> Result<Adt5, Adt44> {
    if f96(v0.clone()) {
        let m1999 = v1;
        match m1999 {
            Adt7::C0 => {
                Err::<Adt5, Adt44>(Adt44::C3)
            }
            Adt7::C1 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2000, _, _, _, _) => {
                        h2000
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2001, _, _, _) => {
                        h2001
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2002, _, _) => {
                        h2002
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2003, _) => {
                        h2003
                    }
                }, Adt7::C1))
            }
            Adt7::C2 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2004, _, _, _, _) => {
                        h2004
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2005, _, _, _) => {
                        h2005
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2006, _, _) => {
                        h2006
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2007, _) => {
                        h2007
                    }
                }, Adt7::C2))
            }
            Adt7::C3 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2008, _, _, _, _) => {
                        h2008
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2009, _, _, _) => {
                        h2009
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2010, _, _) => {
                        h2010
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2011, _) => {
                        h2011
                    }
                }, Adt7::C3))
            }
        }
    } else {
        Err::<Adt5, Adt44>(Adt44::C3)
    }
}

pub fn f84(v0: Adt5, v1: u64, v2: u64) -> R<Result<Adt5, Adt44>> {
    let m2013 = match v0.clone() {
        Adt5::C0(h2012, _, _, _, _) => {
            h2012
        }
    };
    match m2013 {
        Adt6::C0 => {
            let a2015 = match v0.clone() {
                Adt5::C0(_, _, h2014, _, _) => {
                    h2014
                }
            };
            let a2016 = v2;
            if if nat_le(a2015, a2016) {
                let a2020 = v1;
                let a2021 = {
                    let a2018 = v2;
                    let a2019 = match v0.clone() {
                        Adt5::C0(_, _, h2017, _, _) => {
                            h2017
                        }
                    };
                    nat_sub(a2018, a2019)
                };
                nat_le(a2020, a2021)
            } else {
                false
            } {
                Ok(Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2022, _, _, _, _) => {
                        h2022
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2023, _, _, _) => {
                        h2023
                    }
                }, {
                    let a2025 = match v0.clone() {
                        Adt5::C0(_, _, h2024, _, _) => {
                            h2024
                        }
                    };
                    let a2026 = v1;
                    nat_add(a2025, a2026)?
                }, match v0.clone() {
                    Adt5::C0(_, _, _, h2027, _) => {
                        h2027
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, _, h2028) => {
                        h2028
                    }
                })))
            } else {
                Ok(Err::<Adt5, Adt44>(Adt44::C4))
            }
        }
        Adt6::C1 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C2 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C3 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C4 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
    }
}

pub fn f85(v0: Adt1, v1: Adt50) -> Adt71 {
    let m2030 = match v1.clone() {
        Adt50::C0(_, h2029) => {
            h2029
        }
    };
    match m2030 {
        None => {
            Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h2031, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2031
                }
            }, match v0.clone() {
                Adt1::C0(_, h2032, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2032
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h2033, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2033
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h2034, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2034
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h2035, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2035
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h2036, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2036
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h2037, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2037
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2038, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2038
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h2039, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2039
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h2040, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2040
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h2041, _, _, _, _, _, _, _, _, _, _) => {
                    h2041
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2042, _, _, _, _, _, _, _, _, _) => {
                    h2042
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2043, _, _, _, _, _, _, _, _) => {
                    h2043
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2044, _, _, _, _, _, _, _) => {
                    h2044
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2045, _, _, _, _, _, _) => {
                    h2045
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2046, _, _, _, _, _) => {
                    h2046
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2047, _, _, _, _) => {
                    h2047
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2048, _, _, _) => {
                    h2048
                }
            }, v1, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2049, _) => {
                    h2049
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2050) => {
                    h2050
                }
            }), List::<Adt65>::nil())
        }
        Some(v2) => {
            Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h2051, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2051
                }
            }, match v0.clone() {
                Adt1::C0(_, h2052, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2052
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h2053, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2053
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h2054, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2054
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h2055, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2055
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h2056, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2056
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h2057, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2057
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2058, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2058
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h2059, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2059
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h2060, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2060
                }
            }, Some(Adt41::C16(v2)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2061, _, _, _, _, _, _, _, _, _) => {
                    h2061
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2062, _, _, _, _, _, _, _, _) => {
                    h2062
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2063, _, _, _, _, _, _, _) => {
                    h2063
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2064, _, _, _, _, _, _) => {
                    h2064
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2065, _, _, _, _, _) => {
                    h2065
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2066, _, _, _, _) => {
                    h2066
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2067, _, _, _) => {
                    h2067
                }
            }, v1, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2068, _) => {
                    h2068
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2069) => {
                    h2069
                }
            }), List::<Adt65>::nil())
        }
    }
}

pub fn f86(v0: Adt14, v1: Adt50, v2: Adt70) -> R<Adt50> {
    let m2070 = v2;
    match m2070 {
        Adt70::C0(v3, v4) => {
            let m2072 = f97(v0, match v1.clone() {
                Adt50::C0(h2071, _) => {
                    h2071
                }
            }, v3, v4)?;
            match m2072 {
                Ok(v6) => {
                    Ok(Adt50::C0(v6, None::<Adt45>))
                }
                Err(v5) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2073, _) => {
                            h2073
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt70::C1(v7, v8, v9) => {
            let m2075 = f98(match v1.clone() {
                Adt50::C0(h2074, _) => {
                    h2074
                }
            }, v7, v8, v9)?;
            match m2075 {
                Ok(v11) => {
                    Ok(Adt50::C0(v11, None::<Adt45>))
                }
                Err(v10) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2076, _) => {
                            h2076
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt70::C2(v12, v13, v14) => {
            let m2078 = f98(match v1.clone() {
                Adt50::C0(h2077, _) => {
                    h2077
                }
            }, v12, v13, v14)?;
            match m2078 {
                Ok(v16) => {
                    Ok(Adt50::C0(v16, None::<Adt45>))
                }
                Err(v15) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2079, _) => {
                            h2079
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt70::C3(v17, v18) => {
            let m2081 = f99(match v1.clone() {
                Adt50::C0(h2080, _) => {
                    h2080
                }
            }, v17, v18)?;
            match m2081 {
                Ok(v20) => {
                    Ok(Adt50::C0(v20, None::<Adt45>))
                }
                Err(v19) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2082, _) => {
                            h2082
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt70::C4(v21, v22) => {
            let m2084 = f99(match v1.clone() {
                Adt50::C0(h2083, _) => {
                    h2083
                }
            }, v21, v22)?;
            match m2084 {
                Ok(v24) => {
                    Ok(Adt50::C0(v24, None::<Adt45>))
                }
                Err(v23) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2085, _) => {
                            h2085
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f87(v0: Adt52, v1: Adt52) -> bool {
    let a2088 = match v0.clone() {
        Adt52::C0(h2086, _, _) => {
            h2086
        }
    };
    let a2089 = match v1.clone() {
        Adt52::C0(h2087, _, _) => {
            h2087
        }
    };
    if nat_eq(a2088, a2089) {
        let a2092 = match v0.clone() {
            Adt52::C0(_, h2090, _) => {
                h2090
            }
        };
        let a2093 = match v1.clone() {
            Adt52::C0(_, h2091, _) => {
                h2091
            }
        };
        if nat_eq(a2092, a2093) {
            let a2096 = match v0 {
                Adt52::C0(_, _, h2094) => {
                    h2094
                }
            };
            let a2097 = match v1 {
                Adt52::C0(_, _, h2095) => {
                    h2095
                }
            };
            nat_eq(a2096, a2097)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f88(v0: Adt24) -> R<u64> {
    f100(match v0 {
        Adt24::C0(h2098, _, _, _) => {
            h2098
        }
    })
}

pub fn f89(v0: Adt24) -> R<u64> {
    f100(match v0 {
        Adt24::C0(_, h2099, _, _) => {
            h2099
        }
    })
}

pub fn f90() -> Adt25 {
    Adt25::C0(0u64, 0u64, 0u64, 0u64)
}

pub fn f91(v0: Adt1, v1: Adt22) -> Adt71 {
    Adt71::C0(v0.clone(), {
        let m2106 = {
            let m2102 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2101, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2101
                }
            };
            match m2102 {
                None => {
                    Adt71::C0(v0, f57(match v1 {
                        Adt22::C0(_, _, _, _, _, _, _, _, h2103, _) => {
                            h2103
                        }
                    }))
                }
                Some(v2) => {
                    let m2105 = match v1 {
                        Adt22::C0(_, _, _, _, _, _, _, _, h2104, _) => {
                            h2104
                        }
                    };
                    match m2105 {
                        None => {
                            Adt71::C0(v0, List::<Adt65>::nil())
                        }
                        Some(v3) => {
                            if f50(v2, v3.clone()) {
                                Adt71::C0(v0, List::<Adt65>::nil())
                            } else {
                                Adt71::C0(v0, List::cons(Adt65::C6(v3), List::<Adt65>::nil()))
                            }
                        }
                    }
                }
            }
        };
        match m2106 {
            Adt71::C0(_, h2100) => {
                h2100
            }
        }
    })
}

pub fn f92(v0: Adt1, v1: Adt52, v2: Adt54, v3: Adt22) -> R<Adt71> {
    if f101(v0.clone(), v2.clone(), v3.clone())? {
        let m2107 = f102(v2.clone(), v3.clone());
        match m2107 {
            Adt76::C0 => {
                let m2109 = f103(match v0.clone() {
                    Adt1::C0(_, _, h2108, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2108
                    }
                });
                match m2109 {
                    Ok(v5) => {
                        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h2110, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2110
                            }
                        }, f95(match v0.clone() {
                            Adt1::C0(_, h2111, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2111
                            }
                        }, match v1.clone() {
                            Adt52::C0(_, h2112, _) => {
                                h2112
                            }
                        }, match v1 {
                            Adt52::C0(_, _, h2113) => {
                                h2113
                            }
                        }, {
                            let m2114 = v2;
                            match m2114 {
                                Adt54::C0 => {
                                    Adt4::C2
                                }
                                Adt54::C1 => {
                                    Adt4::C3
                                }
                                Adt54::C2 => {
                                    Adt4::C1
                                }
                                Adt54::C3 => {
                                    Adt4::C1
                                }
                                Adt54::C4 => {
                                    Adt4::C2
                                }
                                Adt54::C5 => {
                                    Adt4::C2
                                }
                                Adt54::C6 => {
                                    Adt4::C1
                                }
                                Adt54::C7 => {
                                    Adt4::C1
                                }
                                Adt54::C8 => {
                                    Adt4::C1
                                }
                                Adt54::C9 => {
                                    Adt4::C1
                                }
                            }
                        }), v5, match v0.clone() {
                            Adt1::C0(_, _, _, h2115, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2115
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h2116, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2116
                            }
                        }, Some(v3.clone()), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2117, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2117
                            }
                        }, match v3.clone() {
                            Adt22::C0(_, _, _, _, _, _, _, _, h2118, _) => {
                                h2118
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h2119, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2119
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h2120, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2120
                            }
                        }, None::<Adt41>, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2121, _, _, _, _, _, _, _, _, _) => {
                                h2121
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2122, _, _, _, _, _, _, _, _) => {
                                h2122
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2123, _, _, _, _, _, _, _) => {
                                h2123
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2124, _, _, _, _, _, _) => {
                                h2124
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2125, _, _, _, _, _) => {
                                h2125
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2126, _, _, _, _) => {
                                h2126
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2127, _, _, _) => {
                                h2127
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2128, _, _) => {
                                h2128
                            }
                        }, Some(match v3 {
                            Adt22::C0(h2129, _, _, _, _, _, _, _, _, _) => {
                                h2129
                            }
                        }), match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2130) => {
                                h2130
                            }
                        }), List::<Adt65>::nil()))
                    }
                    Err(v4) => {
                        Ok(f80(v0, v1, Adt41::C11(v4)))
                    }
                }
            }
            Adt76::C1 => {
                Ok(f80(v0, v1, Adt41::C12))
            }
            Adt76::C2 => {
                Ok(f80(v0, v1, Adt41::C13))
            }
            Adt76::C3 => {
                Ok(f80(v0, v1, Adt41::C7))
            }
            Adt76::C4 => {
                Ok(f80(v0, v1, Adt41::C5))
            }
        }
    } else {
        Ok(f80(v0, v1, Adt41::C15(Str::lit("Staged output ownership or byte count does not match the operation."))))
    }
}

pub fn f93(v0: Adt9) -> Adt54 {
    let m2131 = v0;
    match m2131 {
        Adt9::C0(_) => {
            Adt54::C0
        }
        Adt9::C1(_) => {
            Adt54::C1
        }
        Adt9::C2(_) => {
            Adt54::C2
        }
        Adt9::C3(_) => {
            Adt54::C3
        }
        Adt9::C4(_) => {
            Adt54::C4
        }
        Adt9::C5(_) => {
            Adt54::C5
        }
        Adt9::C6(_) => {
            Adt54::C6
        }
        Adt9::C7(_) => {
            Adt54::C7
        }
        Adt9::C8(_) => {
            Adt54::C8
        }
        Adt9::C9(_) => {
            Adt54::C9
        }
    }
}

pub fn f94(v0: Adt9, v1: Adt22) -> Adt22 {
    Adt22::C0(match v1.clone() {
        Adt22::C0(h2132, _, _, _, _, _, _, _, _, _) => {
            h2132
        }
    }, match v1.clone() {
        Adt22::C0(_, h2133, _, _, _, _, _, _, _, _) => {
            h2133
        }
    }, match v1.clone() {
        Adt22::C0(_, _, h2134, _, _, _, _, _, _, _) => {
            h2134
        }
    }, f104(v0), match v1.clone() {
        Adt22::C0(_, _, _, _, h2135, _, _, _, _, _) => {
            h2135
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, h2136, _, _, _, _) => {
            h2136
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, h2137, _, _, _) => {
            h2137
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, _, h2138, _, _) => {
            h2138
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, _, _, h2139, _) => {
            h2139
        }
    }, match v1 {
        Adt22::C0(_, _, _, _, _, _, _, _, _, h2140) => {
            h2140
        }
    })
}

pub fn f95(v0: Adt2, v1: u64, v2: u64, v3: Adt4) -> Adt2 {
    if f78(v0.clone(), v1, v2) {
        Adt2::C0(match v0.clone() {
            Adt2::C0(h2141, _, _, _, _, _) => {
                h2141
            }
        }, match v0 {
            Adt2::C0(_, h2142, _, _, _, _) => {
                h2142
            }
        }, false, true, {
            let m2143 = v3.clone();
            match m2143 {
                Adt4::C0 => {
                    Adt3::C6
                }
                Adt4::C1 => {
                    Adt3::C4
                }
                Adt4::C2 => {
                    Adt3::C4
                }
                Adt4::C3 => {
                    Adt3::C4
                }
                Adt4::C4 => {
                    Adt3::C4
                }
                Adt4::C5 => {
                    Adt3::C6
                }
            }
        }, v3)
    } else {
        v0
    }
}

pub fn f96(v0: Adt5) -> bool {
    let m2145 = match v0.clone() {
        Adt5::C0(h2144, _, _, _, _) => {
            h2144
        }
    };
    match m2145 {
        Adt6::C0 => {
            false
        }
        Adt6::C1 => {
            false
        }
        Adt6::C2 => {
            if match v0.clone() {
                Adt5::C0(_, _, _, h2146, _) => {
                    h2146
                }
            } {
                let m2148 = match v0 {
                    Adt5::C0(_, _, _, _, h2147) => {
                        h2147
                    }
                };
                match m2148 {
                    Adt7::C0 => {
                        true
                    }
                    Adt7::C1 => {
                        false
                    }
                    Adt7::C2 => {
                        false
                    }
                    Adt7::C3 => {
                        false
                    }
                }
            } else {
                false
            }
        }
        Adt6::C3 => {
            false
        }
        Adt6::C4 => {
            false
        }
    }
}

pub fn f97(v0: Adt14, v1: Adt24, v2: Adt46, v3: u64) -> R<Result<Adt24, Adt45>> {
    if f105(match v0.clone() {
        Adt14::C0(h2149, _, _, _, _) => {
            h2149
        }
    }, f106(v1.clone())?, v3)? {
        if f105(f107(v0.clone(), v2.clone()), {
            let a2152 = f108(match v1.clone() {
                Adt24::C0(h2150, _, _, _) => {
                    h2150
                }
            }, v2.clone());
            let a2153 = f108(match v1.clone() {
                Adt24::C0(_, h2151, _, _) => {
                    h2151
                }
            }, v2.clone());
            nat_add(a2152, a2153)?
        }, v3)? {
            Ok(Ok::<Adt24, Adt45>(Adt24::C0(match v1.clone() {
                Adt24::C0(h2154, _, _, _) => {
                    h2154
                }
            }, f109(match v1.clone() {
                Adt24::C0(_, h2155, _, _) => {
                    h2155
                }
            }, v2.clone(), {
                let a2157 = f108(match v1.clone() {
                    Adt24::C0(_, h2156, _, _) => {
                        h2156
                    }
                }, v2.clone());
                let a2158 = v3;
                nat_add(a2157, a2158)?
            }), f110(match v1.clone() {
                Adt24::C0(_, _, h2159, _) => {
                    h2159
                }
            }, f100(match v1.clone() {
                Adt24::C0(h2160, _, _, _) => {
                    h2160
                }
            })?), f110(match v1.clone() {
                Adt24::C0(_, _, _, h2161) => {
                    h2161
                }
            }, {
                let a2167 = f100(match v1.clone() {
                    Adt24::C0(h2162, _, _, _) => {
                        h2162
                    }
                })?;
                let a2168 = f100(f109(match v1.clone() {
                    Adt24::C0(_, h2163, _, _) => {
                        h2163
                    }
                }, v2.clone(), {
                    let a2165 = f108(match v1 {
                        Adt24::C0(_, h2164, _, _) => {
                            h2164
                        }
                    }, v2);
                    let a2166 = v3;
                    nat_add(a2165, a2166)?
                }))?;
                nat_add(a2167, a2168)?
            }))))
        } else {
            Ok(Err::<Adt24, Adt45>(Adt45::C1(v2.clone(), {
                let a2171 = f108(match v1.clone() {
                    Adt24::C0(h2169, _, _, _) => {
                        h2169
                    }
                }, v2.clone());
                let a2172 = f108(match v1 {
                    Adt24::C0(_, h2170, _, _) => {
                        h2170
                    }
                }, v2.clone());
                nat_add(a2171, a2172)?
            }, v3, {
                let m2173 = f107(v0, v2);
                match m2173 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C0(f106(v1)?, v3, {
            let m2175 = match v0 {
                Adt14::C0(h2174, _, _, _, _) => {
                    h2174
                }
            };
            match m2175 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f98(v0: Adt24, v1: Adt46, v2: u64, v3: u64) -> R<Result<Adt24, Adt45>> {
    let a2179 = {
        let a2177 = f108(match v0.clone() {
            Adt24::C0(_, h2176, _, _) => {
                h2176
            }
        }, v1.clone());
        let a2178 = v2;
        nat_lt(a2177, a2178)
    };
    if if bool_not(a2179) {
        let a2182 = {
            let a2180 = v2;
            let a2181 = v3;
            nat_lt(a2180, a2181)
        };
        bool_not(a2182)
    } else {
        false
    } {
        Ok(Ok::<Adt24, Adt45>(Adt24::C0(f109(match v0.clone() {
            Adt24::C0(h2183, _, _, _) => {
                h2183
            }
        }, v1.clone(), {
            let a2185 = f108(match v0.clone() {
                Adt24::C0(h2184, _, _, _) => {
                    h2184
                }
            }, v1.clone());
            let a2186 = v3;
            nat_add(a2185, a2186)?
        }), f109(match v0.clone() {
            Adt24::C0(_, h2187, _, _) => {
                h2187
            }
        }, v1.clone(), {
            let a2189 = f108(match v0.clone() {
                Adt24::C0(_, h2188, _, _) => {
                    h2188
                }
            }, v1.clone());
            let a2190 = v2;
            nat_sub(a2189, a2190)
        }), f110(match v0.clone() {
            Adt24::C0(_, _, h2191, _) => {
                h2191
            }
        }, f100(f109(match v0.clone() {
            Adt24::C0(h2192, _, _, _) => {
                h2192
            }
        }, v1.clone(), {
            let a2194 = f108(match v0.clone() {
                Adt24::C0(h2193, _, _, _) => {
                    h2193
                }
            }, v1.clone());
            let a2195 = v3;
            nat_add(a2194, a2195)?
        }))?), f110(match v0.clone() {
            Adt24::C0(_, _, _, h2196) => {
                h2196
            }
        }, {
            let a2205 = f100(f109(match v0.clone() {
                Adt24::C0(h2197, _, _, _) => {
                    h2197
                }
            }, v1.clone(), {
                let a2199 = f108(match v0.clone() {
                    Adt24::C0(h2198, _, _, _) => {
                        h2198
                    }
                }, v1.clone());
                let a2200 = v3;
                nat_add(a2199, a2200)?
            }))?;
            let a2206 = f100(f109(match v0.clone() {
                Adt24::C0(_, h2201, _, _) => {
                    h2201
                }
            }, v1.clone(), {
                let a2203 = f108(match v0 {
                    Adt24::C0(_, h2202, _, _) => {
                        h2202
                    }
                }, v1);
                let a2204 = v2;
                nat_sub(a2203, a2204)
            }))?;
            nat_add(a2205, a2206)?
        }))))
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C2(v1, v2, v3)))
    }
}

pub fn f99(v0: Adt24, v1: Adt46, v2: u64) -> R<Result<Adt24, Adt45>> {
    let a2210 = {
        let a2208 = f108(match v0.clone() {
            Adt24::C0(h2207, _, _, _) => {
                h2207
            }
        }, v1.clone());
        let a2209 = v2;
        nat_lt(a2208, a2209)
    };
    if bool_not(a2210) {
        Ok(Ok::<Adt24, Adt45>(Adt24::C0(f109(match v0.clone() {
            Adt24::C0(h2211, _, _, _) => {
                h2211
            }
        }, v1.clone(), {
            let a2213 = f108(match v0.clone() {
                Adt24::C0(h2212, _, _, _) => {
                    h2212
                }
            }, v1.clone());
            let a2214 = v2;
            nat_sub(a2213, a2214)
        }), match v0.clone() {
            Adt24::C0(_, h2215, _, _) => {
                h2215
            }
        }, f110(match v0.clone() {
            Adt24::C0(_, _, h2216, _) => {
                h2216
            }
        }, f100(f109(match v0.clone() {
            Adt24::C0(h2217, _, _, _) => {
                h2217
            }
        }, v1.clone(), {
            let a2219 = f108(match v0.clone() {
                Adt24::C0(h2218, _, _, _) => {
                    h2218
                }
            }, v1.clone());
            let a2220 = v2;
            nat_sub(a2219, a2220)
        }))?), f110(match v0.clone() {
            Adt24::C0(_, _, _, h2221) => {
                h2221
            }
        }, {
            let a2227 = f100(f109(match v0.clone() {
                Adt24::C0(h2222, _, _, _) => {
                    h2222
                }
            }, v1.clone(), {
                let a2224 = f108(match v0.clone() {
                    Adt24::C0(h2223, _, _, _) => {
                        h2223
                    }
                }, v1);
                let a2225 = v2;
                nat_sub(a2224, a2225)
            }))?;
            let a2228 = f100(match v0 {
                Adt24::C0(_, h2226, _, _) => {
                    h2226
                }
            })?;
            nat_add(a2227, a2228)?
        }))))
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C3(v1.clone(), f108(match v0 {
            Adt24::C0(h2229, _, _, _) => {
                h2229
            }
        }, v1), v2)))
    }
}

pub fn f100(v0: Adt25) -> R<u64> {
    let a2240 = {
        let a2237 = {
            let a2234 = {
                let a2231 = 0u64;
                let a2232 = match v0.clone() {
                    Adt25::C0(h2230, _, _, _) => {
                        h2230
                    }
                };
                nat_add(a2231, a2232)?
            };
            let a2235 = match v0.clone() {
                Adt25::C0(_, h2233, _, _) => {
                    h2233
                }
            };
            nat_add(a2234, a2235)?
        };
        let a2238 = match v0.clone() {
            Adt25::C0(_, _, h2236, _) => {
                h2236
            }
        };
        nat_add(a2237, a2238)?
    };
    let a2241 = match v0 {
        Adt25::C0(_, _, _, h2239) => {
            h2239
        }
    };
    nat_add(a2240, a2241)
}

pub fn f101(v0: Adt1, v1: Adt54, v2: Adt22) -> R<bool> {
    let a2248 = {
        let m2244 = match v2.clone() {
            Adt22::C0(h2243, _, _, _, _, _, _, _, _, _) => {
                h2243
            }
        };
        match m2244 {
            Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, h2242, _, _) => {
                h2242
            }
        }
    };
    let a2249 = {
        let m2247 = match v0.clone() {
            Adt1::C0(_, _, h2246, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2246
            }
        };
        match m2247 {
            Adt5::C0(_, _, h2245, _, _) => {
                h2245
            }
        }
    };
    if if nat_eq(a2248, a2249) {
        let m2251 = match v2.clone() {
            Adt22::C0(_, _, _, _, _, _, _, _, h2250, _) => {
                h2250
            }
        };
        match m2251 {
            None => {
                let m2252 = v1;
                match m2252 {
                    Adt54::C0 => {
                        false
                    }
                    Adt54::C1 => {
                        false
                    }
                    Adt54::C2 => {
                        true
                    }
                    Adt54::C3 => {
                        true
                    }
                    Adt54::C4 => {
                        false
                    }
                    Adt54::C5 => {
                        false
                    }
                    Adt54::C6 => {
                        true
                    }
                    Adt54::C7 => {
                        true
                    }
                    Adt54::C8 => {
                        true
                    }
                    Adt54::C9 => {
                        true
                    }
                }
            }
            Some(v3) => {
                let a2255 = match v3 {
                    Adt11::C0(h2253, _, _) => {
                        h2253
                    }
                };
                let a2256 = match v0.clone() {
                    Adt1::C0(h2254, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2254
                    }
                };
                if nat_eq(a2255, a2256) {
                    let m2257 = v1;
                    match m2257 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                } else {
                    false
                }
            }
        }
    } else {
        false
    } {
        if f111({
            let m2260 = match v2 {
                Adt22::C0(h2259, _, _, _, _, _, _, _, _, _) => {
                    h2259
                }
            };
            match m2260 {
                Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2258, _) => {
                    h2258
                }
            }
        }, {
            let m2263 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2262, _, _) => {
                    h2262
                }
            };
            match m2263 {
                Adt50::C0(h2261, _) => {
                    h2261
                }
            }
        }) {
            let a2267 = f89({
                let m2266 = match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2265, _, _) => {
                        h2265
                    }
                };
                match m2266 {
                    Adt50::C0(h2264, _) => {
                        h2264
                    }
                }
            })?;
            let a2268 = 0u64;
            if nat_eq(a2267, a2268) {
                let m2272 = {
                    let m2271 = match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2270, _, _) => {
                            h2270
                        }
                    };
                    match m2271 {
                        Adt50::C0(_, h2269) => {
                            h2269
                        }
                    }
                };
                match m2272 {
                    None => {
                        Ok(true)
                    }
                    Some(_) => {
                        Ok(false)
                    }
                }
            } else {
                Ok(false)
            }
        } else {
            Ok(false)
        }
    } else {
        Ok(false)
    }
}

pub fn f102(v0: Adt54, v1: Adt22) -> Adt76 {
    let m2273 = v0;
    match m2273 {
        Adt54::C0 => {
            let m2276 = match v1.clone() {
                Adt22::C0(_, h2275, _, _, _, _, _, _, _, _) => {
                    h2275
                }
            };
            if if match m2276 {
                Adt28::C0(h2274, _, _, _, _) => {
                    h2274
                }
            } {
                let m2279 = match v1.clone() {
                    Adt22::C0(_, h2278, _, _, _, _, _, _, _, _) => {
                        h2278
                    }
                };
                if match m2279 {
                    Adt28::C0(_, h2277, _, _, _) => {
                        h2277
                    }
                } {
                    let m2282 = match v1.clone() {
                        Adt22::C0(_, h2281, _, _, _, _, _, _, _, _) => {
                            h2281
                        }
                    };
                    if match m2282 {
                        Adt28::C0(_, _, h2280, _, _) => {
                            h2280
                        }
                    } {
                        if match v1.clone() {
                            Adt22::C0(_, _, h2283, _, _, _, _, _, _, _) => {
                                h2283
                            }
                        } {
                            if match v1.clone() {
                                Adt22::C0(_, _, _, h2284, _, _, _, _, _, _) => {
                                    h2284
                                }
                            } {
                                let m2287 = match v1.clone() {
                                    Adt22::C0(_, h2286, _, _, _, _, _, _, _, _) => {
                                        h2286
                                    }
                                };
                                match m2287 {
                                    Adt28::C0(_, _, _, h2285, _) => {
                                        h2285
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f112(match v1.clone() {
                    Adt22::C0(_, _, _, _, h2288, _, _, _, _, _) => {
                        h2288
                    }
                }, false, f113(match v1 {
                    Adt22::C0(_, _, _, _, _, h2289, _, _, _, _) => {
                        h2289
                    }
                }))
            } else {
                Adt76::C2
            }
        }
        Adt54::C1 => {
            f114({
                let m2292 = match v1.clone() {
                    Adt22::C0(_, h2291, _, _, _, _, _, _, _, _) => {
                        h2291
                    }
                };
                match m2292 {
                    Adt28::C0(h2290, _, _, _, _) => {
                        h2290
                    }
                }
            }, {
                let m2295 = match v1.clone() {
                    Adt22::C0(_, h2294, _, _, _, _, _, _, _, _) => {
                        h2294
                    }
                };
                match m2295 {
                    Adt28::C0(_, h2293, _, _, _) => {
                        h2293
                    }
                }
            }, {
                let m2298 = match v1.clone() {
                    Adt22::C0(_, h2297, _, _, _, _, _, _, _, _) => {
                        h2297
                    }
                };
                match m2298 {
                    Adt28::C0(_, _, h2296, _, _) => {
                        h2296
                    }
                }
            }, match v1 {
                Adt22::C0(_, _, h2299, _, _, _, _, _, _, _) => {
                    h2299
                }
            }, false)
        }
        Adt54::C2 => {
            let m2302 = match v1 {
                Adt22::C0(_, h2301, _, _, _, _, _, _, _, _) => {
                    h2301
                }
            };
            if match m2302 {
                Adt28::C0(h2300, _, _, _, _) => {
                    h2300
                }
            } {
                Adt76::C0
            } else {
                Adt76::C2
            }
        }
        Adt54::C3 => {
            if match v1.clone() {
                Adt22::C0(_, _, _, h2303, _, _, _, _, _, _) => {
                    h2303
                }
            } {
                let m2306 = match v1.clone() {
                    Adt22::C0(_, h2305, _, _, _, _, _, _, _, _) => {
                        h2305
                    }
                };
                if if match m2306 {
                    Adt28::C0(h2304, _, _, _, _) => {
                        h2304
                    }
                } {
                    let m2309 = match v1.clone() {
                        Adt22::C0(_, h2308, _, _, _, _, _, _, _, _) => {
                            h2308
                        }
                    };
                    if match m2309 {
                        Adt28::C0(_, h2307, _, _, _) => {
                            h2307
                        }
                    } {
                        let m2312 = match v1.clone() {
                            Adt22::C0(_, h2311, _, _, _, _, _, _, _, _) => {
                                h2311
                            }
                        };
                        if match m2312 {
                            Adt28::C0(_, _, h2310, _, _) => {
                                h2310
                            }
                        } {
                            let m2315 = match v1.clone() {
                                Adt22::C0(_, h2314, _, _, _, _, _, _, _, _) => {
                                    h2314
                                }
                            };
                            if match m2315 {
                                Adt28::C0(_, _, _, h2313, _) => {
                                    h2313
                                }
                            } {
                                match v1.clone() {
                                    Adt22::C0(_, _, h2316, _, _, _, _, _, _, _) => {
                                        h2316
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                } {
                    f112(match v1.clone() {
                        Adt22::C0(_, _, _, _, h2317, _, _, _, _, _) => {
                            h2317
                        }
                    }, false, f113(match v1 {
                        Adt22::C0(_, _, _, _, _, h2318, _, _, _, _) => {
                            h2318
                        }
                    }))
                } else {
                    Adt76::C2
                }
            } else {
                f114({
                    let m2321 = match v1.clone() {
                        Adt22::C0(_, h2320, _, _, _, _, _, _, _, _) => {
                            h2320
                        }
                    };
                    match m2321 {
                        Adt28::C0(h2319, _, _, _, _) => {
                            h2319
                        }
                    }
                }, {
                    let m2324 = match v1.clone() {
                        Adt22::C0(_, h2323, _, _, _, _, _, _, _, _) => {
                            h2323
                        }
                    };
                    match m2324 {
                        Adt28::C0(_, h2322, _, _, _) => {
                            h2322
                        }
                    }
                }, {
                    let m2327 = match v1.clone() {
                        Adt22::C0(_, h2326, _, _, _, _, _, _, _, _) => {
                            h2326
                        }
                    };
                    match m2327 {
                        Adt28::C0(_, _, h2325, _, _) => {
                            h2325
                        }
                    }
                }, match v1 {
                    Adt22::C0(_, _, h2328, _, _, _, _, _, _, _) => {
                        h2328
                    }
                }, false)
            }
        }
        Adt54::C4 => {
            let m2331 = match v1.clone() {
                Adt22::C0(_, h2330, _, _, _, _, _, _, _, _) => {
                    h2330
                }
            };
            if if match m2331 {
                Adt28::C0(h2329, _, _, _, _) => {
                    h2329
                }
            } {
                let m2334 = match v1.clone() {
                    Adt22::C0(_, h2333, _, _, _, _, _, _, _, _) => {
                        h2333
                    }
                };
                if match m2334 {
                    Adt28::C0(_, h2332, _, _, _) => {
                        h2332
                    }
                } {
                    let m2337 = match v1.clone() {
                        Adt22::C0(_, h2336, _, _, _, _, _, _, _, _) => {
                            h2336
                        }
                    };
                    if match m2337 {
                        Adt28::C0(_, _, h2335, _, _) => {
                            h2335
                        }
                    } {
                        if match v1.clone() {
                            Adt22::C0(_, _, h2338, _, _, _, _, _, _, _) => {
                                h2338
                            }
                        } {
                            if match v1.clone() {
                                Adt22::C0(_, _, _, h2339, _, _, _, _, _, _) => {
                                    h2339
                                }
                            } {
                                let m2342 = match v1.clone() {
                                    Adt22::C0(_, h2341, _, _, _, _, _, _, _, _) => {
                                        h2341
                                    }
                                };
                                match m2342 {
                                    Adt28::C0(_, _, _, h2340, _) => {
                                        h2340
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f112(match v1.clone() {
                    Adt22::C0(_, _, _, _, h2343, _, _, _, _, _) => {
                        h2343
                    }
                }, false, f113(match v1 {
                    Adt22::C0(_, _, _, _, _, h2344, _, _, _, _) => {
                        h2344
                    }
                }))
            } else {
                Adt76::C2
            }
        }
        Adt54::C5 => {
            if match v1 {
                Adt22::C0(_, _, _, _, _, _, _, h2345, _, _) => {
                    h2345
                }
            } {
                Adt76::C0
            } else {
                Adt76::C2
            }
        }
        Adt54::C6 => {
            Adt76::C0
        }
        Adt54::C7 => {
            Adt76::C0
        }
        Adt54::C8 => {
            Adt76::C0
        }
        Adt54::C9 => {
            Adt76::C0
        }
    }
}

pub fn f103(v0: Adt5) -> Result<Adt5, Adt44> {
    let m2347 = match v0.clone() {
        Adt5::C0(h2346, _, _, _, _) => {
            h2346
        }
    };
    match m2347 {
        Adt6::C0 => {
            if match v0.clone() {
                Adt5::C0(_, h2348, _, _, _) => {
                    h2348
                }
            } {
                Ok::<Adt5, Adt44>(Adt5::C0(Adt6::C2, match v0.clone() {
                    Adt5::C0(_, h2349, _, _, _) => {
                        h2349
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2350, _, _) => {
                        h2350
                    }
                }, true, match v0 {
                    Adt5::C0(_, _, _, _, h2351) => {
                        h2351
                    }
                }))
            } else {
                Err::<Adt5, Adt44>(Adt44::C3)
            }
        }
        Adt6::C1 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C2 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C3 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C4 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
    }
}

pub fn f104(v0: Adt9) -> bool {
    let m2352 = v0;
    match m2352 {
        Adt9::C0(_) => {
            true
        }
        Adt9::C1(_) => {
            false
        }
        Adt9::C2(_) => {
            false
        }
        Adt9::C3(v4) => {
            let m2354 = match v4 {
                Adt16::C0(_, h2353, _, _) => {
                    h2353
                }
            };
            match m2354 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt9::C4(_) => {
            true
        }
        Adt9::C5(_) => {
            false
        }
        Adt9::C6(_) => {
            false
        }
        Adt9::C7(v9) => {
            let m2356 = match v9 {
                Adt20::C0(_, _, h2355, _) => {
                    h2355
                }
            };
            match m2356 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt9::C8(_) => {
            false
        }
        Adt9::C9(_) => {
            false
        }
    }
}

pub fn f105(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m2357 = v0;
    match m2357 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a2362 = {
                let a2360 = v3;
                let a2361 = {
                    let a2358 = v1;
                    let a2359 = v2;
                    nat_add(a2358, a2359)?
                };
                nat_lt(a2360, a2361)
            };
            Ok(bool_not(a2362))
        }
    }
}

pub fn f106(v0: Adt24) -> R<u64> {
    let a2363 = f88(v0.clone())?;
    let a2364 = f89(v0)?;
    nat_add(a2363, a2364)
}

pub fn f107(v0: Adt14, v1: Adt46) -> Option<u64> {
    let m2365 = v1;
    match m2365 {
        Adt46::C0 => {
            match v0 {
                Adt14::C0(_, h2366, _, _, _) => {
                    h2366
                }
            }
        }
        Adt46::C1 => {
            match v0 {
                Adt14::C0(_, _, h2367, _, _) => {
                    h2367
                }
            }
        }
        Adt46::C2 => {
            match v0 {
                Adt14::C0(_, _, _, h2368, _) => {
                    h2368
                }
            }
        }
        Adt46::C3 => {
            match v0 {
                Adt14::C0(_, _, _, _, h2369) => {
                    h2369
                }
            }
        }
    }
}

pub fn f108(v0: Adt25, v1: Adt46) -> u64 {
    let m2370 = v1;
    match m2370 {
        Adt46::C0 => {
            match v0 {
                Adt25::C0(h2371, _, _, _) => {
                    h2371
                }
            }
        }
        Adt46::C1 => {
            match v0 {
                Adt25::C0(_, h2372, _, _) => {
                    h2372
                }
            }
        }
        Adt46::C2 => {
            match v0 {
                Adt25::C0(_, _, h2373, _) => {
                    h2373
                }
            }
        }
        Adt46::C3 => {
            match v0 {
                Adt25::C0(_, _, _, h2374) => {
                    h2374
                }
            }
        }
    }
}

pub fn f109(v0: Adt25, v1: Adt46, v2: u64) -> Adt25 {
    let m2375 = v1;
    match m2375 {
        Adt46::C0 => {
            Adt25::C0(v2, match v0.clone() {
                Adt25::C0(_, h2376, _, _) => {
                    h2376
                }
            }, match v0.clone() {
                Adt25::C0(_, _, h2377, _) => {
                    h2377
                }
            }, match v0 {
                Adt25::C0(_, _, _, h2378) => {
                    h2378
                }
            })
        }
        Adt46::C1 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2379, _, _, _) => {
                    h2379
                }
            }, v2, match v0.clone() {
                Adt25::C0(_, _, h2380, _) => {
                    h2380
                }
            }, match v0 {
                Adt25::C0(_, _, _, h2381) => {
                    h2381
                }
            })
        }
        Adt46::C2 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2382, _, _, _) => {
                    h2382
                }
            }, match v0.clone() {
                Adt25::C0(_, h2383, _, _) => {
                    h2383
                }
            }, v2, match v0 {
                Adt25::C0(_, _, _, h2384) => {
                    h2384
                }
            })
        }
        Adt46::C3 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2385, _, _, _) => {
                    h2385
                }
            }, match v0.clone() {
                Adt25::C0(_, h2386, _, _) => {
                    h2386
                }
            }, match v0 {
                Adt25::C0(_, _, h2387, _) => {
                    h2387
                }
            }, v2)
        }
    }
}

pub fn f110(v0: u64, v1: u64) -> u64 {
    let a2388 = v0;
    let a2389 = v1;
    if nat_lt(a2388, a2389) {
        v1
    } else {
        v0
    }
}

pub fn f111(v0: Adt24, v1: Adt24) -> bool {
    let a2396 = {
        let m2392 = match v0.clone() {
            Adt24::C0(h2391, _, _, _) => {
                h2391
            }
        };
        match m2392 {
            Adt25::C0(h2390, _, _, _) => {
                h2390
            }
        }
    };
    let a2397 = {
        let m2395 = match v1.clone() {
            Adt24::C0(h2394, _, _, _) => {
                h2394
            }
        };
        match m2395 {
            Adt25::C0(h2393, _, _, _) => {
                h2393
            }
        }
    };
    if nat_eq(a2396, a2397) {
        let a2404 = {
            let m2400 = match v0.clone() {
                Adt24::C0(h2399, _, _, _) => {
                    h2399
                }
            };
            match m2400 {
                Adt25::C0(_, h2398, _, _) => {
                    h2398
                }
            }
        };
        let a2405 = {
            let m2403 = match v1.clone() {
                Adt24::C0(h2402, _, _, _) => {
                    h2402
                }
            };
            match m2403 {
                Adt25::C0(_, h2401, _, _) => {
                    h2401
                }
            }
        };
        if nat_eq(a2404, a2405) {
            let a2412 = {
                let m2408 = match v0.clone() {
                    Adt24::C0(h2407, _, _, _) => {
                        h2407
                    }
                };
                match m2408 {
                    Adt25::C0(_, _, h2406, _) => {
                        h2406
                    }
                }
            };
            let a2413 = {
                let m2411 = match v1.clone() {
                    Adt24::C0(h2410, _, _, _) => {
                        h2410
                    }
                };
                match m2411 {
                    Adt25::C0(_, _, h2409, _) => {
                        h2409
                    }
                }
            };
            if nat_eq(a2412, a2413) {
                let a2420 = {
                    let m2416 = match v0.clone() {
                        Adt24::C0(h2415, _, _, _) => {
                            h2415
                        }
                    };
                    match m2416 {
                        Adt25::C0(_, _, _, h2414) => {
                            h2414
                        }
                    }
                };
                let a2421 = {
                    let m2419 = match v1.clone() {
                        Adt24::C0(h2418, _, _, _) => {
                            h2418
                        }
                    };
                    match m2419 {
                        Adt25::C0(_, _, _, h2417) => {
                            h2417
                        }
                    }
                };
                if nat_eq(a2420, a2421) {
                    let a2428 = {
                        let m2424 = match v0.clone() {
                            Adt24::C0(_, h2423, _, _) => {
                                h2423
                            }
                        };
                        match m2424 {
                            Adt25::C0(h2422, _, _, _) => {
                                h2422
                            }
                        }
                    };
                    let a2429 = {
                        let m2427 = match v1.clone() {
                            Adt24::C0(_, h2426, _, _) => {
                                h2426
                            }
                        };
                        match m2427 {
                            Adt25::C0(h2425, _, _, _) => {
                                h2425
                            }
                        }
                    };
                    if nat_eq(a2428, a2429) {
                        let a2436 = {
                            let m2432 = match v0.clone() {
                                Adt24::C0(_, h2431, _, _) => {
                                    h2431
                                }
                            };
                            match m2432 {
                                Adt25::C0(_, h2430, _, _) => {
                                    h2430
                                }
                            }
                        };
                        let a2437 = {
                            let m2435 = match v1.clone() {
                                Adt24::C0(_, h2434, _, _) => {
                                    h2434
                                }
                            };
                            match m2435 {
                                Adt25::C0(_, h2433, _, _) => {
                                    h2433
                                }
                            }
                        };
                        if nat_eq(a2436, a2437) {
                            let a2444 = {
                                let m2440 = match v0.clone() {
                                    Adt24::C0(_, h2439, _, _) => {
                                        h2439
                                    }
                                };
                                match m2440 {
                                    Adt25::C0(_, _, h2438, _) => {
                                        h2438
                                    }
                                }
                            };
                            let a2445 = {
                                let m2443 = match v1.clone() {
                                    Adt24::C0(_, h2442, _, _) => {
                                        h2442
                                    }
                                };
                                match m2443 {
                                    Adt25::C0(_, _, h2441, _) => {
                                        h2441
                                    }
                                }
                            };
                            if nat_eq(a2444, a2445) {
                                let a2452 = {
                                    let m2448 = match v0.clone() {
                                        Adt24::C0(_, h2447, _, _) => {
                                            h2447
                                        }
                                    };
                                    match m2448 {
                                        Adt25::C0(_, _, _, h2446) => {
                                            h2446
                                        }
                                    }
                                };
                                let a2453 = {
                                    let m2451 = match v1.clone() {
                                        Adt24::C0(_, h2450, _, _) => {
                                            h2450
                                        }
                                    };
                                    match m2451 {
                                        Adt25::C0(_, _, _, h2449) => {
                                            h2449
                                        }
                                    }
                                };
                                if nat_eq(a2452, a2453) {
                                    let a2456 = match v0.clone() {
                                        Adt24::C0(_, _, h2454, _) => {
                                            h2454
                                        }
                                    };
                                    let a2457 = match v1.clone() {
                                        Adt24::C0(_, _, h2455, _) => {
                                            h2455
                                        }
                                    };
                                    if nat_eq(a2456, a2457) {
                                        let a2460 = match v0 {
                                            Adt24::C0(_, _, _, h2458) => {
                                                h2458
                                            }
                                        };
                                        let a2461 = match v1 {
                                            Adt24::C0(_, _, _, h2459) => {
                                                h2459
                                            }
                                        };
                                        nat_eq(a2460, a2461)
                                    } else {
                                        false
                                    }
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f112(v0: Adt29, v1: bool, v2: Adt77) -> Adt76 {
    let m2462 = v0;
    match m2462 {
        Adt29::C0 => {
            if v1 {
                let m2463 = v2;
                if match m2463 {
                    Adt77::C0 => {
                        false
                    }
                    Adt77::C1 => {
                        true
                    }
                    Adt77::C2 => {
                        false
                    }
                    Adt77::C3 => {
                        false
                    }
                } {
                    Adt76::C0
                } else {
                    Adt76::C4
                }
            } else {
                Adt76::C0
            }
        }
        Adt29::C1 => {
            Adt76::C1
        }
        Adt29::C2 => {
            Adt76::C2
        }
        Adt29::C3 => {
            Adt76::C3
        }
    }
}

pub fn f113(v0: Adt30) -> Adt77 {
    let m2464 = v0;
    match m2464 {
        Adt30::C0 => {
            Adt77::C0
        }
        Adt30::C1(_) => {
            Adt77::C3
        }
        Adt30::C2(_) => {
            Adt77::C2
        }
        Adt30::C3(_) => {
            Adt77::C3
        }
        Adt30::C4(_) => {
            Adt77::C1
        }
    }
}

pub fn f114(v0: bool, v1: bool, v2: bool, v3: bool, v4: bool) -> Adt76 {
    if v4 {
        Adt76::C3
    } else {
        if if v0 {
            if v1 {
                if v2 {
                    if v3 {
                        let a2465 = v4;
                        bool_not(a2465)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        } {
            Adt76::C0
        } else {
            Adt76::C2
        }
    }
}

pub fn run(p0: Adt0, p1: Adt61) -> R<Adt63> {
    f0(p0, p1)
}
