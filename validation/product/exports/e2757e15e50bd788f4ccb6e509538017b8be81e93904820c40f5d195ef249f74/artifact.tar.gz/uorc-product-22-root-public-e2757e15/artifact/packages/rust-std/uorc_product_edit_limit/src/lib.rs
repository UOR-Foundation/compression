#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt53, u64, Option<Adt55>, Adt56, List<Adt58>, Option<Adt60>),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, Adt2, Adt5, Adt8, Option<Adt9>, Option<Adt22>, Adt40, Option<Adt11>, bool, bool, Option<Adt41>, Option<Adt47>, Option<Adt11>, bool, bool, Adt48, Adt49, bool, Adt50, Option<Adt23>, List<Adt51>),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u64, u64, bool, bool, Adt3, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Adt6, bool, u64, bool, Adt7),
}

#[derive(Clone)]
pub enum Adt6 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt7 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, bool, bool, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(Adt10),
    C1(Adt15),
    C2(Adt15),
    C3(Adt16),
    C4(Adt17),
    C5(Adt18),
    C6(Adt19),
    C7(Adt20),
    C8(Adt21),
    C9(Adt21),
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt11 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt12 {
    C0(Adt13, Option<Adt11>),
}

#[derive(Clone)]
pub enum Adt13 {
    C0(u64, u64, u64, u64, Option<u64>, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt15 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt11, Option<Adt11>, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt17 {
    C0(Adt11, Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt19 {
    C0(Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt11, Adt11, Option<Adt11>, Adt12),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt11, Adt12),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt23, Adt28, bool, bool, Adt29, Adt30, Adt32, bool, Option<Adt11>, Option<Adt33>),
}

#[derive(Clone)]
pub enum Adt23 {
    C0(u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, u64, Adt24, Option<Adt26>),
}

#[derive(Clone)]
pub enum Adt24 {
    C0(Adt25, Adt25, u64, u64),
}

#[derive(Clone)]
pub enum Adt25 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt26 {
    C0(Option<u64>, Option<u64>, Adt27, u64),
}

#[derive(Clone)]
pub enum Adt27 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt28 {
    C0(bool, bool, bool, bool, bool),
}

#[derive(Clone)]
pub enum Adt29 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt30 {
    C0,
    C1(Adt31),
    C2(Adt31),
    C3(Adt31),
    C4(Adt31),
}

#[derive(Clone)]
pub enum Adt31 {
    C0(Bytes, Adt11, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt32 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt33 {
    C0(Adt34),
    C1(Adt34),
    C2(Adt34),
    C3(u64),
    C4(Adt35),
    C5(Adt36),
    C6(Adt37),
    C7(Adt39),
}

#[derive(Clone)]
pub enum Adt34 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt35 {
    C0(Bytes, u64, u64),
}

#[derive(Clone)]
pub enum Adt36 {
    C0(Adt11, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt37 {
    C0(Adt38, Adt38, bool),
}

#[derive(Clone)]
pub enum Adt38 {
    C0(Adt23, Adt28, bool, Adt30),
}

#[derive(Clone)]
pub enum Adt39 {
    C0(Bytes, Bytes, Bytes, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt40 {
    C0(u64, u64, u64, u64, u64, Str),
}

#[derive(Clone)]
pub enum Adt41 {
    C0(u64, Str),
    C1(u64, Str),
    C2(Bytes),
    C3(Bytes),
    C4,
    C5,
    C6(Adt42, u64),
    C7,
    C8(Str),
    C9(Adt7, Str),
    C10(Adt43),
    C11(Adt44),
    C12,
    C13,
    C14(Str),
    C15(Str),
    C16(Adt45),
}

#[derive(Clone)]
pub enum Adt42 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt43 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
    C12,
    C13,
    C14,
    C15,
    C16,
    C17,
}

#[derive(Clone)]
pub enum Adt44 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt45 {
    C0(u64, u64, u64),
    C1(Adt46, u64, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64, u64),
}

#[derive(Clone)]
pub enum Adt46 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt47 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt48 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt49 {
    C0,
    C1,
    C2,
}

#[derive(Clone)]
pub enum Adt50 {
    C0(Adt24, Option<Adt45>),
}

#[derive(Clone)]
pub enum Adt51 {
    C0(Adt52, Adt14, Adt50, Option<Adt23>),
}

#[derive(Clone)]
pub enum Adt52 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt53 {
    C0(Adt54, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Option<Adt11>, Adt13),
}

#[derive(Clone)]
pub enum Adt54 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
}

#[derive(Clone)]
pub enum Adt55 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt56 {
    C0(u64, Adt57),
}

#[derive(Clone)]
pub enum Adt57 {
    C0(Adt55),
    C1,
    C2,
    C3,
    C4,
    C5,
}

#[derive(Clone)]
pub enum Adt58 {
    C0(Adt55, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt59 {
    C0(u64, Str, Option<u64>),
}

#[derive(Clone)]
pub enum Adt60 {
    C0(Adt55, Adt52, u64, Adt11, List<Adt59>, List<Adt59>),
}

#[derive(Clone)]
pub enum Adt61 {
    C0(Adt52, u64, Adt62),
}

#[derive(Clone)]
pub enum Adt62 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
}

#[derive(Clone)]
pub enum Adt63 {
    C0(Adt64, bool, Str),
}

#[derive(Clone)]
pub enum Adt64 {
    C0(Adt0, List<Adt65>),
}

#[derive(Clone)]
pub enum Adt65 {
    C0(Adt66),
    C1(Adt55, Adt52, u64),
    C2(Adt60),
    C3(Adt60),
}

#[derive(Clone)]
pub enum Adt66 {
    C0(Adt52, Adt9),
    C1(Adt52, Adt67),
    C2(Adt52, u64),
    C3(Adt52, u64),
    C4(Adt52),
    C5(Adt52),
    C6(Adt11),
    C7(Adt52, Adt11),
    C8(u64),
    C9(Adt52),
}

#[derive(Clone)]
pub enum Adt67 {
    C0(u64),
    C1(Adt68),
    C2(u64),
    C3,
}

#[derive(Clone)]
pub enum Adt68 {
    C0(Adt11, u64, u64),
}

#[derive(Clone)]
pub enum Adt69 {
    C0(Adt54),
    C1(Adt55),
    C2(Adt55, Adt52, u64, Adt11, List<Adt59>),
    C3(Adt55),
    C4(Adt13),
    C5,
    C6(Adt70),
    C7(u64),
    C8(Adt55, u64),
    C9(Adt55, u64, u64),
    C10(Adt52, u64, Adt11, List<Adt59>),
    C11(Adt52, u64, Str),
}

#[derive(Clone)]
pub enum Adt70 {
    C0,
    C1(Adt48),
    C2,
    C3,
    C4,
    C5,
    C6,
    C7(u64),
    C8,
}

#[derive(Clone)]
pub enum Adt71 {
    C0(Adt1, List<Adt66>),
}

#[derive(Clone)]
pub enum Adt72 {
    C0(Adt9),
    C1,
    C2,
    C3(Adt48),
    C4,
    C5,
    C6,
    C7,
    C8(u64),
    C9(Adt52),
    C10(Adt52, Adt67),
    C11(u64),
    C12(Adt52, Adt40),
    C13(Adt52, Adt11),
    C14(u64),
    C15(Adt52, Adt22),
    C16(Adt52, Adt73),
    C17(Adt52, Adt47),
    C18,
    C19(Adt52, Adt7),
    C20,
    C21(Adt52, u64),
    C22(Adt52, Adt74),
    C23(Adt52, Adt74),
    C24(Adt52),
}

#[derive(Clone)]
pub enum Adt73 {
    C0(Adt41, Adt23, Adt7),
}

#[derive(Clone)]
pub enum Adt74 {
    C0(Adt46, u64),
    C1(Adt46, u64, u64),
    C2(Adt46, u64, u64),
    C3(Adt46, u64),
    C4(Adt46, u64),
}

#[derive(Clone)]
pub enum Adt75 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt76 {
    C0(Adt77, Adt5),
    C1(Adt44),
}

#[derive(Clone)]
pub enum Adt77 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt78 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt79 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt80 {
    C0,
    C1,
    C2,
    C3,
}

pub fn f0(v0: Adt0, v1: Adt61, v2: Str) -> R<Adt63> {
    let a7 = if f1(match v0.clone() {
        Adt0::C0(h1, _, _, _, _, _, _) => {
            h1
        }
    }, match v1.clone() {
        Adt61::C0(h2, _, _) => {
            h2
        }
    }) {
        let a5 = match v0.clone() {
            Adt0::C0(_, _, h3, _, _, _, _) => {
                h3
            }
        };
        let a6 = match v1.clone() {
            Adt61::C0(_, h4, _) => {
                h4
            }
        };
        nat_eq(a5, a6)
    } else {
        false
    };
    if bool_not(a7) {
        Ok(Adt63::C0(Adt64::C0(v0, List::<Adt65>::nil()), false, Str::lit("The selection or operation changed; this setting was not applied.")))
    } else {
        let a25 = {
            let m10 = match v0.clone() {
                Adt0::C0(h9, _, _, _, _, _, _) => {
                    h9
                }
            };
            if match m10 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h8, _, _, _, _, _, _, _) => {
                    h8
                }
            } {
                let a14 = {
                    let m13 = match v0.clone() {
                        Adt0::C0(h12, _, _, _, _, _, _) => {
                            h12
                        }
                    };
                    match m13 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h11, _, _, _, _, _, _) => {
                            h11
                        }
                    }
                };
                if bool_not(a14) {
                    let a20 = {
                        let m19 = {
                            let m18 = match v0.clone() {
                                Adt0::C0(h17, _, _, _, _, _, _) => {
                                    h17
                                }
                            };
                            match m18 {
                                Adt1::C0(_, h16, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h16
                                }
                            }
                        };
                        match m19 {
                            Adt2::C0(_, _, h15, _, _, _) => {
                                h15
                            }
                        }
                    };
                    if bool_not(a20) {
                        let a24 = {
                            let m23 = match v0.clone() {
                                Adt0::C0(h22, _, _, _, _, _, _) => {
                                    h22
                                }
                            };
                            match m23 {
                                Adt1::C0(_, _, _, _, _, _, _, _, h21, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h21
                                }
                            }
                        };
                        bool_not(a24)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        };
        if bool_not(a25) {
            Ok(Adt63::C0(Adt64::C0(v0, List::<Adt65>::nil()), false, Str::lit("Stop the current operation before changing its requested limits.")))
        } else {
            let a26 = v2.clone();
            let a27 = Str::lit("");
            if equal(a26, a27) {
                if f2(match v1.clone() {
                    Adt61::C0(_, _, h28) => {
                        h28
                    }
                }) {
                    Ok(Adt63::C0(f3(v0.clone(), Adt69::C4(f4({
                        let m31 = match v0 {
                            Adt0::C0(_, h30, _, _, _, _, _) => {
                                h30
                            }
                        };
                        match m31 {
                            Adt53::C0(_, _, _, _, _, _, _, h29) => {
                                h29
                            }
                        }
                    }, match v1 {
                        Adt61::C0(_, _, h32) => {
                            h32
                        }
                    }, None::<u64>)))?, true, Str::lit("")))
                } else {
                    Ok(Adt63::C0(f5(v0.clone(), f6(v0.clone(), match v0.clone() {
                        Adt0::C0(_, h33, _, _, _, _, _) => {
                            h33
                        }
                    }, f7(match v0 {
                        Adt0::C0(h34, _, _, _, _, _, _) => {
                            h34
                        }
                    }, Adt41::C10(Adt43::C17))), Adt57::C4)?, false, Str::lit("Enter a nonnegative whole number. Clear only an optional quota to request no additional limit.")))
                }
            } else {
                let m35 = f8(v2)?;
                match m35 {
                    None => {
                        Ok(Adt63::C0(f5(v0.clone(), f6(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h36, _, _, _, _, _) => {
                                h36
                            }
                        }, f7(match v0 {
                            Adt0::C0(h37, _, _, _, _, _, _) => {
                                h37
                            }
                        }, Adt41::C10(Adt43::C17))), Adt57::C4)?, false, Str::lit("Enter a nonnegative whole number. Clear only an optional quota to request no additional limit.")))
                    }
                    Some(v3) => {
                        Ok(Adt63::C0(f3(v0.clone(), Adt69::C4(f4({
                            let m40 = match v0 {
                                Adt0::C0(_, h39, _, _, _, _, _) => {
                                    h39
                                }
                            };
                            match m40 {
                                Adt53::C0(_, _, _, _, _, _, _, h38) => {
                                    h38
                                }
                            }
                        }, match v1 {
                            Adt61::C0(_, _, h41) => {
                                h41
                            }
                        }, Some(v3))))?, true, Str::lit("")))
                    }
                }
            }
        }
    }
}

pub fn f1(v0: Adt1, v1: Adt52) -> bool {
    let a44 = match v0.clone() {
        Adt1::C0(h42, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h42
        }
    };
    let a45 = match v1.clone() {
        Adt52::C0(h43, _, _) => {
            h43
        }
    };
    if nat_eq(a44, a45) {
        let a50 = {
            let m48 = match v0.clone() {
                Adt1::C0(_, h47, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h47
                }
            };
            match m48 {
                Adt2::C0(_, h46, _, _, _, _) => {
                    h46
                }
            }
        };
        let a51 = match v1.clone() {
            Adt52::C0(_, h49, _) => {
                h49
            }
        };
        if nat_eq(a50, a51) {
            let a56 = {
                let m54 = match v0.clone() {
                    Adt1::C0(_, h53, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h53
                    }
                };
                match m54 {
                    Adt2::C0(h52, _, _, _, _, _) => {
                        h52
                    }
                }
            };
            let a57 = match v1 {
                Adt52::C0(_, _, h55) => {
                    h55
                }
            };
            if nat_eq(a56, a57) {
                if match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h58, _, _, _, _, _, _, _) => {
                        h58
                    }
                } {
                    let a60 = match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h59, _, _, _, _, _, _) => {
                            h59
                        }
                    };
                    bool_not(a60)
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f2(v0: Adt62) -> bool {
    let m61 = v0;
    match m61 {
        Adt62::C0 => {
            false
        }
        Adt62::C1 => {
            false
        }
        Adt62::C2 => {
            false
        }
        Adt62::C3 => {
            false
        }
        Adt62::C4 => {
            true
        }
        Adt62::C5 => {
            false
        }
        Adt62::C6 => {
            true
        }
        Adt62::C7 => {
            true
        }
        Adt62::C8 => {
            true
        }
        Adt62::C9 => {
            true
        }
        Adt62::C10 => {
            true
        }
    }
}

pub fn f3(v0: Adt0, v1: Adt69) -> R<Adt64> {
    if f9(v1.clone()) {
        Ok(Adt64::C0({
            let m65 = f10({
                let m64 = f11(v0.clone())?;
                match m64 {
                    Adt64::C0(h63, _) => {
                        h63
                    }
                }
            }, v1.clone())?;
            match m65 {
                Adt64::C0(h62, _) => {
                    h62
                }
            }
        }, f12({
            let m67 = f11(v0.clone())?;
            match m67 {
                Adt64::C0(_, h66) => {
                    h66
                }
            }
        }, {
            let m71 = f10({
                let m70 = f11(v0)?;
                match m70 {
                    Adt64::C0(h69, _) => {
                        h69
                    }
                }
            }, v1)?;
            match m71 {
                Adt64::C0(_, h68) => {
                    h68
                }
            }
        })))
    } else {
        f10(v0, v1)
    }
}

pub fn f4(v0: Adt13, v1: Adt62, v2: Option<u64>) -> Adt13 {
    let m72 = v1;
    match m72 {
        Adt62::C0 => {
            Adt13::C0({
                let m73 = v2;
                match m73 {
                    None => {
                        0u64
                    }
                    Some(v3) => {
                        v3
                    }
                }
            }, match v0.clone() {
                Adt13::C0(_, h74, _, _, _, _, _) => {
                    h74
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h75, _, _, _, _) => {
                    h75
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h76, _, _, _) => {
                    h76
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h77, _, _) => {
                    h77
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h78, _) => {
                    h78
                }
            }, match v0 {
                Adt13::C0(_, _, _, _, _, _, h79) => {
                    h79
                }
            })
        }
        Adt62::C1 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h80, _, _, _, _, _, _) => {
                    h80
                }
            }, {
                let m81 = v2;
                match m81 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h82, _, _, _, _) => {
                    h82
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h83, _, _, _) => {
                    h83
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h84, _, _) => {
                    h84
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h85, _) => {
                    h85
                }
            }, match v0 {
                Adt13::C0(_, _, _, _, _, _, h86) => {
                    h86
                }
            })
        }
        Adt62::C2 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h87, _, _, _, _, _, _) => {
                    h87
                }
            }, match v0.clone() {
                Adt13::C0(_, h88, _, _, _, _, _) => {
                    h88
                }
            }, {
                let m89 = v2;
                match m89 {
                    None => {
                        0u64
                    }
                    Some(v5) => {
                        v5
                    }
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h90, _, _, _) => {
                    h90
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h91, _, _) => {
                    h91
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h92, _) => {
                    h92
                }
            }, match v0 {
                Adt13::C0(_, _, _, _, _, _, h93) => {
                    h93
                }
            })
        }
        Adt62::C3 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h94, _, _, _, _, _, _) => {
                    h94
                }
            }, match v0.clone() {
                Adt13::C0(_, h95, _, _, _, _, _) => {
                    h95
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h96, _, _, _, _) => {
                    h96
                }
            }, {
                let m97 = v2;
                match m97 {
                    None => {
                        0u64
                    }
                    Some(v6) => {
                        v6
                    }
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h98, _, _) => {
                    h98
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h99, _) => {
                    h99
                }
            }, match v0 {
                Adt13::C0(_, _, _, _, _, _, h100) => {
                    h100
                }
            })
        }
        Adt62::C4 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h101, _, _, _, _, _, _) => {
                    h101
                }
            }, match v0.clone() {
                Adt13::C0(_, h102, _, _, _, _, _) => {
                    h102
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h103, _, _, _, _) => {
                    h103
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h104, _, _, _) => {
                    h104
                }
            }, v2, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h105, _) => {
                    h105
                }
            }, match v0 {
                Adt13::C0(_, _, _, _, _, _, h106) => {
                    h106
                }
            })
        }
        Adt62::C5 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h107, _, _, _, _, _, _) => {
                    h107
                }
            }, match v0.clone() {
                Adt13::C0(_, h108, _, _, _, _, _) => {
                    h108
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h109, _, _, _, _) => {
                    h109
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h110, _, _, _) => {
                    h110
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h111, _, _) => {
                    h111
                }
            }, {
                let m112 = v2;
                match m112 {
                    None => {
                        0u64
                    }
                    Some(v7) => {
                        v7
                    }
                }
            }, match v0 {
                Adt13::C0(_, _, _, _, _, _, h113) => {
                    h113
                }
            })
        }
        Adt62::C6 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h114, _, _, _, _, _, _) => {
                    h114
                }
            }, match v0.clone() {
                Adt13::C0(_, h115, _, _, _, _, _) => {
                    h115
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h116, _, _, _, _) => {
                    h116
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h117, _, _, _) => {
                    h117
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h118, _, _) => {
                    h118
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h119, _) => {
                    h119
                }
            }, Adt14::C0(v2, {
                let m122 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h121) => {
                        h121
                    }
                };
                match m122 {
                    Adt14::C0(_, h120, _, _, _) => {
                        h120
                    }
                }
            }, {
                let m125 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h124) => {
                        h124
                    }
                };
                match m125 {
                    Adt14::C0(_, _, h123, _, _) => {
                        h123
                    }
                }
            }, {
                let m128 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h127) => {
                        h127
                    }
                };
                match m128 {
                    Adt14::C0(_, _, _, h126, _) => {
                        h126
                    }
                }
            }, {
                let m131 = match v0 {
                    Adt13::C0(_, _, _, _, _, _, h130) => {
                        h130
                    }
                };
                match m131 {
                    Adt14::C0(_, _, _, _, h129) => {
                        h129
                    }
                }
            }))
        }
        Adt62::C7 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h132, _, _, _, _, _, _) => {
                    h132
                }
            }, match v0.clone() {
                Adt13::C0(_, h133, _, _, _, _, _) => {
                    h133
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h134, _, _, _, _) => {
                    h134
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h135, _, _, _) => {
                    h135
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h136, _, _) => {
                    h136
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h137, _) => {
                    h137
                }
            }, Adt14::C0({
                let m140 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h139) => {
                        h139
                    }
                };
                match m140 {
                    Adt14::C0(h138, _, _, _, _) => {
                        h138
                    }
                }
            }, v2, {
                let m143 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h142) => {
                        h142
                    }
                };
                match m143 {
                    Adt14::C0(_, _, h141, _, _) => {
                        h141
                    }
                }
            }, {
                let m146 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h145) => {
                        h145
                    }
                };
                match m146 {
                    Adt14::C0(_, _, _, h144, _) => {
                        h144
                    }
                }
            }, {
                let m149 = match v0 {
                    Adt13::C0(_, _, _, _, _, _, h148) => {
                        h148
                    }
                };
                match m149 {
                    Adt14::C0(_, _, _, _, h147) => {
                        h147
                    }
                }
            }))
        }
        Adt62::C8 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h150, _, _, _, _, _, _) => {
                    h150
                }
            }, match v0.clone() {
                Adt13::C0(_, h151, _, _, _, _, _) => {
                    h151
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h152, _, _, _, _) => {
                    h152
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h153, _, _, _) => {
                    h153
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h154, _, _) => {
                    h154
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h155, _) => {
                    h155
                }
            }, Adt14::C0({
                let m158 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h157) => {
                        h157
                    }
                };
                match m158 {
                    Adt14::C0(h156, _, _, _, _) => {
                        h156
                    }
                }
            }, {
                let m161 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h160) => {
                        h160
                    }
                };
                match m161 {
                    Adt14::C0(_, h159, _, _, _) => {
                        h159
                    }
                }
            }, v2, {
                let m164 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h163) => {
                        h163
                    }
                };
                match m164 {
                    Adt14::C0(_, _, _, h162, _) => {
                        h162
                    }
                }
            }, {
                let m167 = match v0 {
                    Adt13::C0(_, _, _, _, _, _, h166) => {
                        h166
                    }
                };
                match m167 {
                    Adt14::C0(_, _, _, _, h165) => {
                        h165
                    }
                }
            }))
        }
        Adt62::C9 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h168, _, _, _, _, _, _) => {
                    h168
                }
            }, match v0.clone() {
                Adt13::C0(_, h169, _, _, _, _, _) => {
                    h169
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h170, _, _, _, _) => {
                    h170
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h171, _, _, _) => {
                    h171
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h172, _, _) => {
                    h172
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h173, _) => {
                    h173
                }
            }, Adt14::C0({
                let m176 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h175) => {
                        h175
                    }
                };
                match m176 {
                    Adt14::C0(h174, _, _, _, _) => {
                        h174
                    }
                }
            }, {
                let m179 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h178) => {
                        h178
                    }
                };
                match m179 {
                    Adt14::C0(_, h177, _, _, _) => {
                        h177
                    }
                }
            }, {
                let m182 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h181) => {
                        h181
                    }
                };
                match m182 {
                    Adt14::C0(_, _, h180, _, _) => {
                        h180
                    }
                }
            }, v2, {
                let m185 = match v0 {
                    Adt13::C0(_, _, _, _, _, _, h184) => {
                        h184
                    }
                };
                match m185 {
                    Adt14::C0(_, _, _, _, h183) => {
                        h183
                    }
                }
            }))
        }
        Adt62::C10 => {
            Adt13::C0(match v0.clone() {
                Adt13::C0(h186, _, _, _, _, _, _) => {
                    h186
                }
            }, match v0.clone() {
                Adt13::C0(_, h187, _, _, _, _, _) => {
                    h187
                }
            }, match v0.clone() {
                Adt13::C0(_, _, h188, _, _, _, _) => {
                    h188
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, h189, _, _, _) => {
                    h189
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, h190, _, _) => {
                    h190
                }
            }, match v0.clone() {
                Adt13::C0(_, _, _, _, _, h191, _) => {
                    h191
                }
            }, Adt14::C0({
                let m194 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h193) => {
                        h193
                    }
                };
                match m194 {
                    Adt14::C0(h192, _, _, _, _) => {
                        h192
                    }
                }
            }, {
                let m197 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h196) => {
                        h196
                    }
                };
                match m197 {
                    Adt14::C0(_, h195, _, _, _) => {
                        h195
                    }
                }
            }, {
                let m200 = match v0.clone() {
                    Adt13::C0(_, _, _, _, _, _, h199) => {
                        h199
                    }
                };
                match m200 {
                    Adt14::C0(_, _, h198, _, _) => {
                        h198
                    }
                }
            }, {
                let m203 = match v0 {
                    Adt13::C0(_, _, _, _, _, _, h202) => {
                        h202
                    }
                };
                match m203 {
                    Adt14::C0(_, _, _, h201, _) => {
                        h201
                    }
                }
            }, v2))
        }
    }
}

pub fn f5(v0: Adt0, v1: Adt64, v2: Adt57) -> R<Adt64> {
    Ok(Adt64::C0(Adt0::C0({
        let m206 = match v1.clone() {
            Adt64::C0(h205, _) => {
                h205
            }
        };
        match m206 {
            Adt0::C0(h204, _, _, _, _, _, _) => {
                h204
            }
        }
    }, {
        let m209 = match v1.clone() {
            Adt64::C0(h208, _) => {
                h208
            }
        };
        match m209 {
            Adt0::C0(_, h207, _, _, _, _, _) => {
                h207
            }
        }
    }, {
        let m212 = match v1.clone() {
            Adt64::C0(h211, _) => {
                h211
            }
        };
        match m212 {
            Adt0::C0(_, _, h210, _, _, _, _) => {
                h210
            }
        }
    }, {
        let m215 = match v1.clone() {
            Adt64::C0(h214, _) => {
                h214
            }
        };
        match m215 {
            Adt0::C0(_, _, _, h213, _, _, _) => {
                h213
            }
        }
    }, Adt56::C0({
        let a219 = {
            let m218 = match v0 {
                Adt0::C0(_, _, _, _, h217, _, _) => {
                    h217
                }
            };
            match m218 {
                Adt56::C0(h216, _) => {
                    h216
                }
            }
        };
        let a220 = 1u64;
        nat_add(a219, a220)?
    }, v2), {
        let m223 = match v1.clone() {
            Adt64::C0(h222, _) => {
                h222
            }
        };
        match m223 {
            Adt0::C0(_, _, _, _, _, h221, _) => {
                h221
            }
        }
    }, {
        let m226 = match v1.clone() {
            Adt64::C0(h225, _) => {
                h225
            }
        };
        match m226 {
            Adt0::C0(_, _, _, _, _, _, h224) => {
                h224
            }
        }
    }), match v1 {
        Adt64::C0(_, h227) => {
            h227
        }
    }))
}

pub fn f6(v0: Adt0, v1: Adt53, v2: Adt71) -> Adt64 {
    Adt64::C0(Adt0::C0(match v2.clone() {
        Adt71::C0(h228, _) => {
            h228
        }
    }, v1, match v0.clone() {
        Adt0::C0(_, _, h229, _, _, _, _) => {
            h229
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, h230, _, _, _) => {
            h230
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, h231, _, _) => {
            h231
        }
    }, match v0.clone() {
        Adt0::C0(_, _, _, _, _, h232, _) => {
            h232
        }
    }, match v0 {
        Adt0::C0(_, _, _, _, _, _, h233) => {
            h233
        }
    }), f13(match v2 {
        Adt71::C0(_, h234) => {
            h234
        }
    }))
}

pub fn f7(v0: Adt1, v1: Adt41) -> Adt71 {
    Adt71::C0(Adt1::C0(match v0.clone() {
        Adt1::C0(h235, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h235
        }
    }, match v0.clone() {
        Adt1::C0(_, h236, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h236
        }
    }, match v0.clone() {
        Adt1::C0(_, _, h237, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h237
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, h238, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h238
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, h239, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h239
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, h240, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h240
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h241, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h241
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, h242, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h242
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, h243, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h243
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, h244, _, _, _, _, _, _, _, _, _, _, _) => {
            h244
        }
    }, Some(v1), match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h245, _, _, _, _, _, _, _, _, _) => {
            h245
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h246, _, _, _, _, _, _, _, _) => {
            h246
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h247, _, _, _, _, _, _, _) => {
            h247
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h248, _, _, _, _, _, _) => {
            h248
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h249, _, _, _, _, _) => {
            h249
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h250, _, _, _, _) => {
            h250
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h251, _, _, _) => {
            h251
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h252, _, _) => {
            h252
        }
    }, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h253, _) => {
            h253
        }
    }, match v0 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h254) => {
            h254
        }
    }), List::<Adt66>::nil())
}

pub fn f8(v0: Str) -> R<Option<u64>> {
    f14({
        let a255 = v0.clone();
        utf8_encode(a255)
    }, {
        let a257 = {
            let a256 = v0;
            utf8_encode(a256)
        };
        length_bytes(a257)
    }, 0u64, 0u64)
}

pub fn f9(v0: Adt69) -> bool {
    let m258 = v0;
    match m258 {
        Adt69::C0(_) => {
            true
        }
        Adt69::C1(_) => {
            true
        }
        Adt69::C2(_, _, _, _, _) => {
            false
        }
        Adt69::C3(_) => {
            true
        }
        Adt69::C4(_) => {
            true
        }
        Adt69::C5 => {
            false
        }
        Adt69::C6(v10) => {
            let m259 = v10;
            match m259 {
                Adt70::C0 => {
                    true
                }
                Adt70::C1(_) => {
                    false
                }
                Adt70::C2 => {
                    false
                }
                Adt70::C3 => {
                    false
                }
                Adt70::C4 => {
                    false
                }
                Adt70::C5 => {
                    false
                }
                Adt70::C6 => {
                    false
                }
                Adt70::C7(_) => {
                    false
                }
                Adt70::C8 => {
                    false
                }
            }
        }
        Adt69::C7(_) => {
            false
        }
        Adt69::C8(_, _) => {
            false
        }
        Adt69::C9(_, _, _) => {
            false
        }
        Adt69::C10(_, _, _, _) => {
            false
        }
        Adt69::C11(_, _, _) => {
            false
        }
    }
}

pub fn f10(v0: Adt0, v1: Adt69) -> R<Adt64> {
    f15(v0.clone(), v1.clone(), {
        let m260 = v1;
        match m260 {
            Adt69::C0(v2) => {
                f16(v0.clone(), match v0 {
                    Adt0::C0(_, h261, _, _, _, _, _) => {
                        h261
                    }
                }, v2)?
            }
            Adt69::C1(v3) => {
                f17(v0, v3)?
            }
            Adt69::C2(v4, v5, v6, v7, v8) => {
                if if f18(v0.clone(), v4.clone(), v5, v6, v7.clone()) {
                    f19(v8.clone())
                } else {
                    false
                } {
                    f20(v0, v4, v7, v8)?
                } else {
                    Adt64::C0(v0, List::cons(Adt65::C0(Adt66::C6(v7)), List::<Adt65>::nil()))
                }
            }
            Adt69::C3(v9) => {
                Adt64::C0(Adt0::C0({
                    let m265 = {
                        let m264 = f21(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m264 {
                            Adt64::C0(h263, _) => {
                                h263
                            }
                        }
                    };
                    match m265 {
                        Adt0::C0(h262, _, _, _, _, _, _) => {
                            h262
                        }
                    }
                }, {
                    let m269 = {
                        let m268 = f21(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m268 {
                            Adt64::C0(h267, _) => {
                                h267
                            }
                        }
                    };
                    match m269 {
                        Adt0::C0(_, h266, _, _, _, _, _) => {
                            h266
                        }
                    }
                }, {
                    let m273 = {
                        let m272 = f21(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m272 {
                            Adt64::C0(h271, _) => {
                                h271
                            }
                        }
                    };
                    match m273 {
                        Adt0::C0(_, _, h270, _, _, _, _) => {
                            h270
                        }
                    }
                }, {
                    let m277 = {
                        let m276 = f21(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m276 {
                            Adt64::C0(h275, _) => {
                                h275
                            }
                        }
                    };
                    match m277 {
                        Adt0::C0(_, _, _, h274, _, _, _) => {
                            h274
                        }
                    }
                }, {
                    let m281 = {
                        let m280 = f21(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m280 {
                            Adt64::C0(h279, _) => {
                                h279
                            }
                        }
                    };
                    match m281 {
                        Adt0::C0(_, _, _, _, h278, _, _) => {
                            h278
                        }
                    }
                }, f22(match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h282, _) => {
                        h282
                    }
                }, v9.clone(), List::<Adt59>::nil()), {
                    let m286 = {
                        let m285 = f21(v0.clone(), v9.clone(), None::<Adt11>)?;
                        match m285 {
                            Adt64::C0(h284, _) => {
                                h284
                            }
                        }
                    };
                    match m286 {
                        Adt0::C0(_, _, _, _, _, _, h283) => {
                            h283
                        }
                    }
                }), {
                    let m288 = f21(v0, v9, None::<Adt11>)?;
                    match m288 {
                        Adt64::C0(_, h287) => {
                            h287
                        }
                    }
                })
            }
            Adt69::C4(v10) => {
                f23(v0.clone(), match v0 {
                    Adt0::C0(_, h289, _, _, _, _, _) => {
                        h289
                    }
                }, v10)?
            }
            Adt69::C5 => {
                let m291 = f24(match v0.clone() {
                    Adt0::C0(_, h290, _, _, _, _, _) => {
                        h290
                    }
                });
                match m291 {
                    Ok(v12) => {
                        f6(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h294, _, _, _, _, _) => {
                                h294
                            }
                        }, f25(match v0 {
                            Adt0::C0(h295, _, _, _, _, _, _) => {
                                h295
                            }
                        }, v12)?)
                    }
                    Err(v11) => {
                        f6(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h292, _, _, _, _, _) => {
                                h292
                            }
                        }, f7(match v0 {
                            Adt0::C0(h293, _, _, _, _, _, _) => {
                                h293
                            }
                        }, Adt41::C10(v11)))
                    }
                }
            }
            Adt69::C6(v13) => {
                f26(v0, v13)?
            }
            Adt69::C7(v14) => {
                f27(v0, v14)?
            }
            Adt69::C8(v15, v16) => {
                f28(v0.clone(), v15.clone(), f29(f30(match v0 {
                    Adt0::C0(_, _, _, _, _, h296, _) => {
                        h296
                    }
                }, v15), v16))?
            }
            Adt69::C9(v17, v18, v19) => {
                f28(v0.clone(), v17.clone(), f31(f30(match v0 {
                    Adt0::C0(_, _, _, _, _, h297, _) => {
                        h297
                    }
                }, v17), v18, v19))?
            }
            Adt69::C10(v20, v21, v22, v23) => {
                f32(v0, v20, v21, v22, v23)?
            }
            Adt69::C11(v24, v25, v26) => {
                f33(v0, v24, v25, v26)?
            }
        }
    })
}

pub fn f11(v0: Adt0) -> R<Adt64> {
    let m299 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h298) => {
            h298
        }
    };
    match m299 {
        None => {
            Ok(Adt64::C0(v0, List::<Adt65>::nil()))
        }
        Some(v1) => {
            Ok(Adt64::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h300, _, _, _, _, _, _) => {
                    h300
                }
            }, f34(match v0.clone() {
                Adt0::C0(_, h301, _, _, _, _, _) => {
                    h301
                }
            }, match v1.clone() {
                Adt60::C0(h302, _, _, _, _, _) => {
                    h302
                }
            }, Some(match v1.clone() {
                Adt60::C0(_, _, _, h303, _, _) => {
                    h303
                }
            })), {
                let a305 = match v0.clone() {
                    Adt0::C0(_, _, h304, _, _, _, _) => {
                        h304
                    }
                };
                let a306 = 1u64;
                nat_add(a305, a306)?
            }, match v0.clone() {
                Adt0::C0(_, _, _, h307, _, _, _) => {
                    h307
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h308, _, _) => {
                    h308
                }
            }, f22(match v0 {
                Adt0::C0(_, _, _, _, _, h309, _) => {
                    h309
                }
            }, match v1.clone() {
                Adt60::C0(h310, _, _, _, _, _) => {
                    h310
                }
            }, match v1.clone() {
                Adt60::C0(_, _, _, _, _, h311) => {
                    h311
                }
            }), None::<Adt60>), List::cons(Adt65::C3(v1), List::<Adt65>::nil())))
        }
    }
}

pub fn f12(v0: List<Adt65>, v1: List<Adt65>) -> List<Adt65> {
    let m312 = v0;
    match m312.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f12(v3, v1))
        }
    }
}

pub fn f13(v0: List<Adt66>) -> List<Adt65> {
    let m313 = v0;
    match m313.uncons() {
        None => {
            List::<Adt65>::nil()
        }
        Some((v1, v2)) => {
            List::cons(Adt65::C0(v1), f13(v2))
        }
    }
}

pub fn f14(v0: Bytes, p326: u64, p327: u64, p328: u64) -> R<Option<u64>> {
    let m325 = (p326, (p327, p328));
    {
        let mut m325 = m325;
        loop {
            let step = {
                let (v1, (v2, v3)) = m325;
                let m314 = v1;
                if m314 == 0 {
                    Err::<(u64, (u64, u64)), R<Option<u64>>>(Ok(Some(v3)))
                } else {
                    let v4 = m314 - 1;
                    let m317 = {
                        let a315 = v0.clone();
                        let a316 = v2;
                        index_bytes(a315, a316)
                    };
                    match m317 {
                        None => {
                            Err::<(u64, (u64, u64)), R<Option<u64>>>(Ok(None::<u64>))
                        }
                        Some(v5) => {
                            let m318 = f35(v5);
                            match m318 {
                                None => {
                                    Err::<(u64, (u64, u64)), R<Option<u64>>>(Ok(None::<u64>))
                                }
                                Some(v6) => {
                                    Ok::<(u64, (u64, u64)), R<Option<u64>>>((v4, ({
                                        let a319 = v2;
                                        let a320 = 1u64;
                                        nat_add(a319, a320)?
                                    }, {
                                        let a323 = {
                                            let a321 = v3;
                                            let a322 = 10u64;
                                            nat_mul(a321, a322)?
                                        };
                                        let a324 = v6;
                                        nat_add(a323, a324)?
                                    })))
                                }
                            }
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m325 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f15(v0: Adt0, v1: Adt69, v2: Adt64) -> R<Adt64> {
    let m334 = {
        let m333 = {
            let m332 = match v2.clone() {
                Adt64::C0(h331, _) => {
                    h331
                }
            };
            match m332 {
                Adt0::C0(h330, _, _, _, _, _, _) => {
                    h330
                }
            }
        };
        match m333 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h329, _, _, _, _, _, _, _, _, _, _) => {
                h329
            }
        }
    };
    if match m334 {
        None => {
            let m340 = {
                let m339 = {
                    let m338 = match v2.clone() {
                        Adt64::C0(h337, _) => {
                            h337
                        }
                    };
                    match m338 {
                        Adt0::C0(h336, _, _, _, _, _, _) => {
                            h336
                        }
                    }
                };
                match m339 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h335, _, _, _, _, _, _, _, _, _) => {
                        h335
                    }
                }
            };
            match m340 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Some(_) => {
            true
        }
    } {
        f5(v0, v2, Adt57::C4)
    } else {
        let m341 = v1;
        match m341 {
            Adt69::C0(_) => {
                f5(v0, v2, Adt57::C1)
            }
            Adt69::C1(_) => {
                Ok(v2)
            }
            Adt69::C2(v7, _, _, _, _) => {
                f5(v0, v2, Adt57::C0(v7))
            }
            Adt69::C3(v12) => {
                f5(v0, v2, Adt57::C0(v12))
            }
            Adt69::C4(_) => {
                Ok(v2)
            }
            Adt69::C5 => {
                f5(v0, v2, Adt57::C2)
            }
            Adt69::C6(v14) => {
                let m342 = v14;
                match m342 {
                    Adt70::C0 => {
                        f5(v0, v2, Adt57::C2)
                    }
                    Adt70::C1(_) => {
                        f5(v0, v2, Adt57::C5)
                    }
                    Adt70::C2 => {
                        f5(v0, v2, Adt57::C5)
                    }
                    Adt70::C3 => {
                        Ok(v2)
                    }
                    Adt70::C4 => {
                        Ok(v2)
                    }
                    Adt70::C5 => {
                        Ok(v2)
                    }
                    Adt70::C6 => {
                        f5(v0, v2, Adt57::C2)
                    }
                    Adt70::C7(_) => {
                        f5(v0, v2, Adt57::C2)
                    }
                    Adt70::C8 => {
                        f5(v0, v2, Adt57::C2)
                    }
                }
            }
            Adt69::C7(_) => {
                f5(v0, v2, Adt57::C2)
            }
            Adt69::C8(v18, _) => {
                f5(v0, v2, Adt57::C0(v18))
            }
            Adt69::C9(v20, _, _) => {
                f5(v0, v2, Adt57::C0(v20))
            }
            Adt69::C10(_, _, _, _) => {
                Ok(v2)
            }
            Adt69::C11(_, _, _) => {
                Ok(v2)
            }
        }
    }
}

pub fn f16(v0: Adt0, v1: Adt53, v2: Adt54) -> R<Adt64> {
    f36(v0, Adt53::C0(v2, match v1.clone() {
        Adt53::C0(_, h343, _, _, _, _, _, _) => {
            h343
        }
    }, match v1.clone() {
        Adt53::C0(_, _, h344, _, _, _, _, _) => {
            h344
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, h345, _, _, _, _) => {
            h345
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, h346, _, _, _) => {
            h346
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, h347, _, _) => {
            h347
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, _, h348, _) => {
            h348
        }
    }, match v1 {
        Adt53::C0(_, _, _, _, _, _, _, h349) => {
            h349
        }
    }))
}

pub fn f17(v0: Adt0, v1: Adt55) -> R<Adt64> {
    let m352 = match v0.clone() {
        Adt0::C0(h351, _, _, _, _, _, _) => {
            h351
        }
    };
    if if match m352 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h350, _, _, _, _, _, _, _) => {
            h350
        }
    } {
        let a356 = {
            let m355 = match v0.clone() {
                Adt0::C0(h354, _, _, _, _, _, _) => {
                    h354
                }
            };
            match m355 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h353, _, _, _, _, _, _) => {
                    h353
                }
            }
        };
        bool_not(a356)
    } else {
        false
    } {
        Ok(Adt64::C0(Adt0::C0(match v0.clone() {
            Adt0::C0(h357, _, _, _, _, _, _) => {
                h357
            }
        }, match v0.clone() {
            Adt0::C0(_, h358, _, _, _, _, _) => {
                h358
            }
        }, {
            let a360 = match v0.clone() {
                Adt0::C0(_, _, h359, _, _, _, _) => {
                    h359
                }
            };
            let a361 = 1u64;
            nat_add(a360, a361)?
        }, Some(v1.clone()), match v0.clone() {
            Adt0::C0(_, _, _, _, h362, _, _) => {
                h362
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, h363, _) => {
                h363
            }
        }, match v0.clone() {
            Adt0::C0(_, _, _, _, _, _, h364) => {
                h364
            }
        }), List::cons(Adt65::C1(v1, f37(match v0.clone() {
            Adt0::C0(h365, _, _, _, _, _, _) => {
                h365
            }
        }), {
            let a367 = match v0 {
                Adt0::C0(_, _, h366, _, _, _, _) => {
                    h366
                }
            };
            let a368 = 1u64;
            nat_add(a367, a368)?
        }), List::<Adt65>::nil())))
    } else {
        Ok(Adt64::C0(v0, List::<Adt65>::nil()))
    }
}

pub fn f18(v0: Adt0, v1: Adt55, v2: Adt52, v3: u64, v4: Adt11) -> bool {
    if f1(match v0.clone() {
        Adt0::C0(h369, _, _, _, _, _, _) => {
            h369
        }
    }, v2) {
        let a371 = match v0.clone() {
            Adt0::C0(_, _, h370, _, _, _, _) => {
                h370
            }
        };
        let a372 = v3;
        if nat_eq(a371, a372) {
            let a377 = match v4 {
                Adt11::C0(h373, _, _) => {
                    h373
                }
            };
            let a378 = {
                let m376 = match v0.clone() {
                    Adt0::C0(h375, _, _, _, _, _, _) => {
                        h375
                    }
                };
                match m376 {
                    Adt1::C0(h374, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h374
                    }
                }
            };
            if nat_eq(a377, a378) {
                let m380 = match v0 {
                    Adt0::C0(_, _, _, h379, _, _, _) => {
                        h379
                    }
                };
                match m380 {
                    None => {
                        false
                    }
                    Some(v5) => {
                        f38(v5, v1)
                    }
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f19(p384: List<Adt59>) -> bool {
    let m383 = p384;
    {
        let mut m383 = m383;
        loop {
            let step = {
                let v0 = m383;
                let m381 = v0;
                match m381.uncons() {
                    None => {
                        Err::<List<Adt59>, bool>(true)
                    }
                    Some((v1, v2)) => {
                        if f39(v2.clone(), match v1 {
                            Adt59::C0(h382, _, _) => {
                                h382
                            }
                        }) {
                            Err::<List<Adt59>, bool>(false)
                        } else {
                            Ok::<List<Adt59>, bool>(v2)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m383 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f20(v0: Adt0, v1: Adt55, v2: Adt11, v3: List<Adt59>) -> R<Adt64> {
    Ok(Adt64::C0(Adt0::C0({
        let m388 = {
            let m387 = f21(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m387 {
                Adt64::C0(h386, _) => {
                    h386
                }
            }
        };
        match m388 {
            Adt0::C0(h385, _, _, _, _, _, _) => {
                h385
            }
        }
    }, {
        let m392 = {
            let m391 = f21(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m391 {
                Adt64::C0(h390, _) => {
                    h390
                }
            }
        };
        match m392 {
            Adt0::C0(_, h389, _, _, _, _, _) => {
                h389
            }
        }
    }, {
        let m396 = {
            let m395 = f21(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m395 {
                Adt64::C0(h394, _) => {
                    h394
                }
            }
        };
        match m396 {
            Adt0::C0(_, _, h393, _, _, _, _) => {
                h393
            }
        }
    }, {
        let m400 = {
            let m399 = f21(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m399 {
                Adt64::C0(h398, _) => {
                    h398
                }
            }
        };
        match m400 {
            Adt0::C0(_, _, _, h397, _, _, _) => {
                h397
            }
        }
    }, {
        let m404 = {
            let m403 = f21(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m403 {
                Adt64::C0(h402, _) => {
                    h402
                }
            }
        };
        match m404 {
            Adt0::C0(_, _, _, _, h401, _, _) => {
                h401
            }
        }
    }, f22(match v0.clone() {
        Adt0::C0(_, _, _, _, _, h405, _) => {
            h405
        }
    }, v1.clone(), v3), {
        let m409 = {
            let m408 = f21(v0.clone(), v1.clone(), Some(v2.clone()))?;
            match m408 {
                Adt64::C0(h407, _) => {
                    h407
                }
            }
        };
        match m409 {
            Adt0::C0(_, _, _, _, _, _, h406) => {
                h406
            }
        }
    }), {
        let m411 = f21(v0, v1, Some(v2))?;
        match m411 {
            Adt64::C0(_, h410) => {
                h410
            }
        }
    }))
}

pub fn f21(v0: Adt0, v1: Adt55, v2: Option<Adt11>) -> R<Adt64> {
    Ok(Adt64::C0({
        let m414 = f36(v0.clone(), f34(match v0.clone() {
            Adt0::C0(_, h413, _, _, _, _, _) => {
                h413
            }
        }, v1.clone(), v2.clone()))?;
        match m414 {
            Adt64::C0(h412, _) => {
                h412
            }
        }
    }, f13(f40(f41(f42(match v0.clone() {
        Adt0::C0(_, h415, _, _, _, _, _) => {
            h415
        }
    }, v1), v2), {
        let m418 = f43(match v0 {
            Adt0::C0(h417, _, _, _, _, _, _) => {
                h417
            }
        }, Adt72::C1)?;
        match m418 {
            Adt71::C0(_, h416) => {
                h416
            }
        }
    }))))
}

pub fn f22(v0: List<Adt58>, v1: Adt55, v2: List<Adt59>) -> List<Adt58> {
    let m419 = v0;
    match m419.uncons() {
        None => {
            List::cons(Adt58::C0(v1, v2), List::<Adt58>::nil())
        }
        Some((v3, v4)) => {
            if f38(match v3.clone() {
                Adt58::C0(h420, _) => {
                    h420
                }
            }, v1.clone()) {
                List::cons(Adt58::C0(v1, v2), v4)
            } else {
                List::cons(v3, f22(v4, v1, v2))
            }
        }
    }
}

pub fn f23(v0: Adt0, v1: Adt53, v2: Adt13) -> R<Adt64> {
    f36(v0, Adt53::C0(match v1.clone() {
        Adt53::C0(h421, _, _, _, _, _, _, _) => {
            h421
        }
    }, match v1.clone() {
        Adt53::C0(_, h422, _, _, _, _, _, _) => {
            h422
        }
    }, match v1.clone() {
        Adt53::C0(_, _, h423, _, _, _, _, _) => {
            h423
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, h424, _, _, _, _) => {
            h424
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, h425, _, _, _) => {
            h425
        }
    }, match v1.clone() {
        Adt53::C0(_, _, _, _, _, h426, _, _) => {
            h426
        }
    }, match v1 {
        Adt53::C0(_, _, _, _, _, _, h427, _) => {
            h427
        }
    }, v2))
}

pub fn f24(v0: Adt53) -> Result<Adt9, Adt43> {
    let m429 = match v0.clone() {
        Adt53::C0(h428, _, _, _, _, _, _, _) => {
            h428
        }
    };
    match m429 {
        Adt54::C0 => {
            let m431 = match v0.clone() {
                Adt53::C0(_, h430, _, _, _, _, _, _) => {
                    h430
                }
            };
            match m431 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v1) => {
                    Ok::<Adt9, Adt43>(Adt9::C0(Adt10::C0(v1, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h432) => {
                            h432
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h433, _, _, _, _) => {
                            h433
                        }
                    }))))
                }
            }
        }
        Adt54::C1 => {
            let m435 = match v0.clone() {
                Adt53::C0(_, _, h434, _, _, _, _, _) => {
                    h434
                }
            };
            match m435 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v2) => {
                    Ok::<Adt9, Adt43>(Adt9::C1(Adt15::C0(v2, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h436) => {
                            h436
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h437, _, _, _, _) => {
                            h437
                        }
                    }))))
                }
            }
        }
        Adt54::C2 => {
            let m439 = match v0.clone() {
                Adt53::C0(_, _, h438, _, _, _, _, _) => {
                    h438
                }
            };
            match m439 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v3) => {
                    Ok::<Adt9, Adt43>(Adt9::C2(Adt15::C0(v3, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h440) => {
                            h440
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h441, _, _, _, _) => {
                            h441
                        }
                    }))))
                }
            }
        }
        Adt54::C3 => {
            let m443 = match v0.clone() {
                Adt53::C0(_, _, h442, _, _, _, _, _) => {
                    h442
                }
            };
            match m443 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v4) => {
                    Ok::<Adt9, Adt43>(Adt9::C3(Adt16::C0(v4, match v0.clone() {
                        Adt53::C0(_, _, _, _, h444, _, _, _) => {
                            h444
                        }
                    }, None::<Adt11>, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h445) => {
                            h445
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h446, _, _, _, _) => {
                            h446
                        }
                    }))))
                }
            }
        }
        Adt54::C4 => {
            let m448 = match v0.clone() {
                Adt53::C0(_, h447, _, _, _, _, _, _) => {
                    h447
                }
            };
            match m448 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v5) => {
                    let m450 = match v0.clone() {
                        Adt53::C0(_, _, _, _, _, h449, _, _) => {
                            h449
                        }
                    };
                    match m450 {
                        None => {
                            Err::<Adt9, Adt43>(Adt43::C4)
                        }
                        Some(v6) => {
                            Ok::<Adt9, Adt43>(Adt9::C4(Adt17::C0(v5, v6, Adt12::C0(match v0.clone() {
                                Adt53::C0(_, _, _, _, _, _, _, h451) => {
                                    h451
                                }
                            }, match v0 {
                                Adt53::C0(_, _, _, h452, _, _, _, _) => {
                                    h452
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt54::C5 => {
            let m454 = match v0.clone() {
                Adt53::C0(_, h453, _, _, _, _, _, _) => {
                    h453
                }
            };
            match m454 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v7) => {
                    Ok::<Adt9, Adt43>(Adt9::C5(Adt18::C0(v7, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h455) => {
                            h455
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h456, _, _, _, _) => {
                            h456
                        }
                    }))))
                }
            }
        }
        Adt54::C6 => {
            let m458 = match v0.clone() {
                Adt53::C0(_, h457, _, _, _, _, _, _) => {
                    h457
                }
            };
            match m458 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v8) => {
                    Ok::<Adt9, Adt43>(Adt9::C6(Adt19::C0(v8, match v0.clone() {
                        Adt53::C0(_, _, h459, _, _, _, _, _) => {
                            h459
                        }
                    }, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h460) => {
                            h460
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h461, _, _, _, _) => {
                            h461
                        }
                    }))))
                }
            }
        }
        Adt54::C7 => {
            let m463 = match v0.clone() {
                Adt53::C0(_, _, h462, _, _, _, _, _) => {
                    h462
                }
            };
            match m463 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C15)
                }
                Some(v9) => {
                    let m465 = match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, h464, _) => {
                            h464
                        }
                    };
                    match m465 {
                        None => {
                            Err::<Adt9, Adt43>(Adt43::C16)
                        }
                        Some(v10) => {
                            Ok::<Adt9, Adt43>(Adt9::C7(Adt20::C0(v9, v10, match v0.clone() {
                                Adt53::C0(_, _, _, _, h466, _, _, _) => {
                                    h466
                                }
                            }, Adt12::C0(match v0.clone() {
                                Adt53::C0(_, _, _, _, _, _, _, h467) => {
                                    h467
                                }
                            }, match v0 {
                                Adt53::C0(_, _, _, h468, _, _, _, _) => {
                                    h468
                                }
                            }))))
                        }
                    }
                }
            }
        }
        Adt54::C8 => {
            let m470 = match v0.clone() {
                Adt53::C0(_, h469, _, _, _, _, _, _) => {
                    h469
                }
            };
            match m470 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v11) => {
                    Ok::<Adt9, Adt43>(Adt9::C8(Adt21::C0(v11, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h471) => {
                            h471
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h472, _, _, _, _) => {
                            h472
                        }
                    }))))
                }
            }
        }
        Adt54::C9 => {
            let m474 = match v0.clone() {
                Adt53::C0(_, h473, _, _, _, _, _, _) => {
                    h473
                }
            };
            match m474 {
                None => {
                    Err::<Adt9, Adt43>(Adt43::C14)
                }
                Some(v12) => {
                    Ok::<Adt9, Adt43>(Adt9::C9(Adt21::C0(v12, Adt12::C0(match v0.clone() {
                        Adt53::C0(_, _, _, _, _, _, _, h475) => {
                            h475
                        }
                    }, match v0 {
                        Adt53::C0(_, _, _, h476, _, _, _, _) => {
                            h476
                        }
                    }))))
                }
            }
        }
    }
}

pub fn f25(v0: Adt1, v1: Adt9) -> R<Adt71> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h477, _, _, _, _, _, _) => {
            h477
        }
    } {
        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h478, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h478
            }
        }, match v0.clone() {
            Adt1::C0(_, h479, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h479
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h480, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h480
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h481, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h481
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h482, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h482
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h483, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h483
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h484, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h484
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h485, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h485
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h486, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h486
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h487, _, _, _, _, _, _, _, _, _, _, _) => {
                h487
            }
        }, Some(Adt41::C10(Adt43::C1)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h488, _, _, _, _, _, _, _, _, _) => {
                h488
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h489, _, _, _, _, _, _, _, _) => {
                h489
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h490, _, _, _, _, _, _, _) => {
                h490
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h491, _, _, _, _, _, _) => {
                h491
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h492, _, _, _, _, _) => {
                h492
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h493, _, _, _, _) => {
                h493
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h494, _, _, _) => {
                h494
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h495, _, _) => {
                h495
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h496, _) => {
                h496
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h497) => {
                h497
            }
        }), List::<Adt66>::nil()))
    } else {
        let a499 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h498, _, _, _, _, _, _, _) => {
                h498
            }
        };
        if bool_not(a499) {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h500, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h500
                }
            }, match v0.clone() {
                Adt1::C0(_, h501, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h501
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h502, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h502
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h503, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h503
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h504, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h504
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h505, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h505
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h506, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h506
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h507, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h507
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h508, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h508
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h509, _, _, _, _, _, _, _, _, _, _, _) => {
                    h509
                }
            }, Some(Adt41::C10(Adt43::C2)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h510, _, _, _, _, _, _, _, _, _) => {
                    h510
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h511, _, _, _, _, _, _, _, _) => {
                    h511
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h512, _, _, _, _, _, _, _) => {
                    h512
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h513, _, _, _, _, _, _) => {
                    h513
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h514, _, _, _, _, _) => {
                    h514
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h515, _, _, _, _) => {
                    h515
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h516, _, _, _) => {
                    h516
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h517, _, _) => {
                    h517
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h518, _) => {
                    h518
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h519) => {
                    h519
                }
            }), List::<Adt66>::nil()))
        } else {
            let m522 = match v0.clone() {
                Adt1::C0(_, h521, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h521
                }
            };
            if match m522 {
                Adt2::C0(_, _, h520, _, _, _) => {
                    h520
                }
            } {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h523, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h523
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h524, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h524
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h525, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h525
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h526, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h526
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h527, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h527
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h528, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h528
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h529, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h529
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h530, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h530
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h531, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h531
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h532, _, _, _, _, _, _, _, _, _, _, _) => {
                        h532
                    }
                }, Some(Adt41::C10(Adt43::C0)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h533, _, _, _, _, _, _, _, _, _) => {
                        h533
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h534, _, _, _, _, _, _, _, _) => {
                        h534
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h535, _, _, _, _, _, _, _) => {
                        h535
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h536, _, _, _, _, _, _) => {
                        h536
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h537, _, _, _, _, _) => {
                        h537
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h538, _, _, _, _) => {
                        h538
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h539, _, _, _) => {
                        h539
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h540, _, _) => {
                        h540
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h541, _) => {
                        h541
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h542) => {
                        h542
                    }
                }), List::<Adt66>::nil()))
            } else {
                if match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h543, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h543
                    }
                } {
                    Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h544, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h544
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, h545, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h545
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, h546, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h546
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h547, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h547
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h548, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h548
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h549, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h549
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h550, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h550
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h551, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h551
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, h552, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h552
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, h553, _, _, _, _, _, _, _, _, _, _, _) => {
                            h553
                        }
                    }, Some(Adt41::C10(Adt43::C6)), match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h554, _, _, _, _, _, _, _, _, _) => {
                            h554
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h555, _, _, _, _, _, _, _, _) => {
                            h555
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h556, _, _, _, _, _, _, _) => {
                            h556
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h557, _, _, _, _, _, _) => {
                            h557
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h558, _, _, _, _, _) => {
                            h558
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h559, _, _, _, _) => {
                            h559
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h560, _, _, _) => {
                            h560
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h561, _, _) => {
                            h561
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h562, _) => {
                            h562
                        }
                    }, match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h563) => {
                            h563
                        }
                    }), List::<Adt66>::nil()))
                } else {
                    Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h564, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h564
                        }
                    }, f44(match v0.clone() {
                        Adt1::C0(_, h565, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h565
                        }
                    })?, f45(), f46(), Some(v1.clone()), None::<Adt22>, Adt40::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h566, _, _, _, _, _, _, _) => {
                            h566
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h567, _, _, _, _, _, _) => {
                            h567
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h568, _, _, _, _, _) => {
                            h568
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h569, _, _, _, _) => {
                            h569
                        }
                    }, true, f47(), None::<Adt23>, f48(v0.clone())), f40(List::cons(Adt66::C0(f37(Adt1::C0(match v0.clone() {
                        Adt1::C0(h570, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h570
                        }
                    }, f44(match v0.clone() {
                        Adt1::C0(_, h571, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h571
                        }
                    })?, f45(), f46(), Some(v1.clone()), None::<Adt22>, Adt40::C0(0u64, 0u64, 0u64, 0u64, 0u64, Str::lit("Ready")), None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h572, _, _, _, _, _, _, _) => {
                            h572
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h573, _, _, _, _, _, _) => {
                            h573
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h574, _, _, _, _, _) => {
                            h574
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h575, _, _, _, _) => {
                            h575
                        }
                    }, true, f47(), None::<Adt23>, f48(v0.clone()))), v1), List::<Adt66>::nil()), f49(v0))))
                }
            }
        }
    }
}

pub fn f26(v0: Adt0, v1: Adt70) -> R<Adt64> {
    let m576 = v1;
    match m576 {
        Adt70::C0 => {
            Ok(f6(v0.clone(), match v0.clone() {
                Adt0::C0(_, h577, _, _, _, _, _) => {
                    h577
                }
            }, f43(match v0 {
                Adt0::C0(h578, _, _, _, _, _, _) => {
                    h578
                }
            }, Adt72::C2)?))
        }
        Adt70::C1(v2) => {
            Ok(f6(v0.clone(), match v0.clone() {
                Adt0::C0(_, h579, _, _, _, _, _) => {
                    h579
                }
            }, f43(match v0 {
                Adt0::C0(h580, _, _, _, _, _, _) => {
                    h580
                }
            }, Adt72::C3(v2))?))
        }
        Adt70::C2 => {
            Ok(f6(v0.clone(), match v0.clone() {
                Adt0::C0(_, h581, _, _, _, _, _) => {
                    h581
                }
            }, f43(match v0 {
                Adt0::C0(h582, _, _, _, _, _, _) => {
                    h582
                }
            }, Adt72::C4)?))
        }
        Adt70::C3 => {
            f50(v0)
        }
        Adt70::C4 => {
            f50(v0)
        }
        Adt70::C5 => {
            f50(v0)
        }
        Adt70::C6 => {
            Ok(f6(v0.clone(), match v0.clone() {
                Adt0::C0(_, h583, _, _, _, _, _) => {
                    h583
                }
            }, f43(match v0 {
                Adt0::C0(h584, _, _, _, _, _, _) => {
                    h584
                }
            }, Adt72::C18)?))
        }
        Adt70::C7(v3) => {
            Ok(f6(v0.clone(), match v0.clone() {
                Adt0::C0(_, h585, _, _, _, _, _) => {
                    h585
                }
            }, f43(match v0 {
                Adt0::C0(h586, _, _, _, _, _, _) => {
                    h586
                }
            }, Adt72::C14(v3))?))
        }
        Adt70::C8 => {
            Ok(f6(v0.clone(), match v0.clone() {
                Adt0::C0(_, h587, _, _, _, _, _) => {
                    h587
                }
            }, f43(match v0 {
                Adt0::C0(h588, _, _, _, _, _, _) => {
                    h588
                }
            }, Adt72::C20)?))
        }
    }
}

pub fn f27(v0: Adt0, v1: u64) -> R<Adt64> {
    let m593 = {
        let m592 = match v0.clone() {
            Adt0::C0(h591, _, _, _, _, _, _) => {
                h591
            }
        };
        match m592 {
            Adt1::C0(_, h590, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h590
            }
        }
    };
    if match m593 {
        Adt2::C0(_, _, h589, _, _, _) => {
            h589
        }
    } {
        Ok(f6(v0.clone(), match v0.clone() {
            Adt0::C0(_, h594, _, _, _, _, _) => {
                h594
            }
        }, f51(match v0 {
            Adt0::C0(h595, _, _, _, _, _, _) => {
                h595
            }
        }, v1)))
    } else {
        let m599 = {
            let m598 = match v0.clone() {
                Adt0::C0(h597, _, _, _, _, _, _) => {
                    h597
                }
            };
            match m598 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h596, _, _, _, _, _, _, _, _) => {
                    h596
                }
            }
        };
        match m599 {
            None => {
                Ok(f6(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h600, _, _, _, _, _) => {
                        h600
                    }
                }, f7(match v0 {
                    Adt0::C0(h601, _, _, _, _, _, _) => {
                        h601
                    }
                }, Adt41::C10(Adt43::C4))))
            }
            Some(v2) => {
                let m605 = {
                    let m604 = match v0.clone() {
                        Adt0::C0(_, h603, _, _, _, _, _) => {
                            h603
                        }
                    };
                    match m604 {
                        Adt53::C0(_, h602, _, _, _, _, _, _) => {
                            h602
                        }
                    }
                };
                match m605 {
                    None => {
                        Ok(f6(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h606, _, _, _, _, _) => {
                                h606
                            }
                        }, f7(match v0 {
                            Adt0::C0(h607, _, _, _, _, _, _) => {
                                h607
                            }
                        }, Adt41::C10(Adt43::C14))))
                    }
                    Some(v3) => {
                        Ok(f6(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h608, _, _, _, _, _) => {
                                h608
                            }
                        }, f52(match v0.clone() {
                            Adt0::C0(h609, _, _, _, _, _, _) => {
                                h609
                            }
                        }, Adt17::C0(v3, v2, Adt12::C0(Adt13::C0({
                            let m614 = {
                                let m613 = match v0.clone() {
                                    Adt0::C0(_, h612, _, _, _, _, _) => {
                                        h612
                                    }
                                };
                                match m613 {
                                    Adt53::C0(_, _, _, _, _, _, _, h611) => {
                                        h611
                                    }
                                }
                            };
                            match m614 {
                                Adt13::C0(h610, _, _, _, _, _, _) => {
                                    h610
                                }
                            }
                        }, {
                            let m619 = {
                                let m618 = match v0.clone() {
                                    Adt0::C0(_, h617, _, _, _, _, _) => {
                                        h617
                                    }
                                };
                                match m618 {
                                    Adt53::C0(_, _, _, _, _, _, _, h616) => {
                                        h616
                                    }
                                }
                            };
                            match m619 {
                                Adt13::C0(_, h615, _, _, _, _, _) => {
                                    h615
                                }
                            }
                        }, {
                            let m624 = {
                                let m623 = match v0.clone() {
                                    Adt0::C0(_, h622, _, _, _, _, _) => {
                                        h622
                                    }
                                };
                                match m623 {
                                    Adt53::C0(_, _, _, _, _, _, _, h621) => {
                                        h621
                                    }
                                }
                            };
                            match m624 {
                                Adt13::C0(_, _, h620, _, _, _, _) => {
                                    h620
                                }
                            }
                        }, {
                            let a630 = {
                                let m629 = {
                                    let m628 = match v0.clone() {
                                        Adt0::C0(_, h627, _, _, _, _, _) => {
                                            h627
                                        }
                                    };
                                    match m628 {
                                        Adt53::C0(_, _, _, _, _, _, _, h626) => {
                                            h626
                                        }
                                    }
                                };
                                match m629 {
                                    Adt13::C0(_, _, _, h625, _, _, _) => {
                                        h625
                                    }
                                }
                            };
                            let a631 = v1;
                            nat_add(a630, a631)?
                        }, {
                            let m636 = {
                                let m635 = match v0.clone() {
                                    Adt0::C0(_, h634, _, _, _, _, _) => {
                                        h634
                                    }
                                };
                                match m635 {
                                    Adt53::C0(_, _, _, _, _, _, _, h633) => {
                                        h633
                                    }
                                }
                            };
                            match m636 {
                                Adt13::C0(_, _, _, _, h632, _, _) => {
                                    h632
                                }
                            }
                        }, {
                            let m641 = {
                                let m640 = match v0.clone() {
                                    Adt0::C0(_, h639, _, _, _, _, _) => {
                                        h639
                                    }
                                };
                                match m640 {
                                    Adt53::C0(_, _, _, _, _, _, _, h638) => {
                                        h638
                                    }
                                }
                            };
                            match m641 {
                                Adt13::C0(_, _, _, _, _, h637, _) => {
                                    h637
                                }
                            }
                        }, {
                            let m646 = {
                                let m645 = match v0.clone() {
                                    Adt0::C0(_, h644, _, _, _, _, _) => {
                                        h644
                                    }
                                };
                                match m645 {
                                    Adt53::C0(_, _, _, _, _, _, _, h643) => {
                                        h643
                                    }
                                }
                            };
                            match m646 {
                                Adt13::C0(_, _, _, _, _, _, h642) => {
                                    h642
                                }
                            }
                        }), {
                            let m649 = match v0 {
                                Adt0::C0(_, h648, _, _, _, _, _) => {
                                    h648
                                }
                            };
                            match m649 {
                                Adt53::C0(_, _, _, h647, _, _, _, _) => {
                                    h647
                                }
                            }
                        })))?))
                    }
                }
            }
        }
    }
}

pub fn f28(v0: Adt0, v1: Adt55, v2: List<Adt59>) -> R<Adt64> {
    let m651 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h650) => {
            h650
        }
    };
    match m651 {
        None => {
            let m653 = f42(match v0.clone() {
                Adt0::C0(_, h652, _, _, _, _, _) => {
                    h652
                }
            }, v1.clone());
            match m653 {
                None => {
                    Ok(Adt64::C0(v0, List::<Adt65>::nil()))
                }
                Some(v4) => {
                    Ok(Adt64::C0(Adt0::C0({
                        let m656 = f43(match v0.clone() {
                            Adt0::C0(h655, _, _, _, _, _, _) => {
                                h655
                            }
                        }, Adt72::C1)?;
                        match m656 {
                            Adt71::C0(h654, _) => {
                                h654
                            }
                        }
                    }, f34(match v0.clone() {
                        Adt0::C0(_, h657, _, _, _, _, _) => {
                            h657
                        }
                    }, v1.clone(), None::<Adt11>), {
                        let a659 = match v0.clone() {
                            Adt0::C0(_, _, h658, _, _, _, _) => {
                                h658
                            }
                        };
                        let a660 = 1u64;
                        nat_add(a659, a660)?
                    }, None::<Adt55>, match v0.clone() {
                        Adt0::C0(_, _, _, _, h661, _, _) => {
                            h661
                        }
                    }, f22(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h662, _) => {
                            h662
                        }
                    }, v1.clone(), v2.clone()), Some(Adt60::C0(v1.clone(), f37({
                        let m665 = f43(match v0.clone() {
                            Adt0::C0(h664, _, _, _, _, _, _) => {
                                h664
                            }
                        }, Adt72::C1)?;
                        match m665 {
                            Adt71::C0(h663, _) => {
                                h663
                            }
                        }
                    }), {
                        let a667 = match v0.clone() {
                            Adt0::C0(_, _, h666, _, _, _, _) => {
                                h666
                            }
                        };
                        let a668 = 1u64;
                        nat_add(a667, a668)?
                    }, v4.clone(), v2.clone(), f30(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h669, _) => {
                            h669
                        }
                    }, v1.clone())))), List::cons(Adt65::C2(Adt60::C0(v1.clone(), f37({
                        let m672 = f43(match v0.clone() {
                            Adt0::C0(h671, _, _, _, _, _, _) => {
                                h671
                            }
                        }, Adt72::C1)?;
                        match m672 {
                            Adt71::C0(h670, _) => {
                                h670
                            }
                        }
                    }), {
                        let a674 = match v0.clone() {
                            Adt0::C0(_, _, h673, _, _, _, _) => {
                                h673
                            }
                        };
                        let a675 = 1u64;
                        nat_add(a674, a675)?
                    }, v4, v2, f30(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h676, _) => {
                            h676
                        }
                    }, v1))), f13({
                        let m679 = f43(match v0 {
                            Adt0::C0(h678, _, _, _, _, _, _) => {
                                h678
                            }
                        }, Adt72::C1)?;
                        match m679 {
                            Adt71::C0(_, h677) => {
                                h677
                            }
                        }
                    }))))
                }
            }
        }
        Some(_) => {
            Ok(Adt64::C0(v0, List::<Adt65>::nil()))
        }
    }
}

pub fn f29(v0: List<Adt59>, v1: u64) -> List<Adt59> {
    let m680 = v0;
    match m680.uncons() {
        None => {
            List::<Adt59>::nil()
        }
        Some((v2, v3)) => {
            let a682 = match v2.clone() {
                Adt59::C0(h681, _, _) => {
                    h681
                }
            };
            let a683 = v1;
            if nat_eq(a682, a683) {
                v3
            } else {
                List::cons(v2, f29(v3, v1))
            }
        }
    }
}

pub fn f30(p688: List<Adt58>, v1: Adt55) -> List<Adt59> {
    let m687 = p688;
    {
        let mut m687 = m687;
        loop {
            let step = {
                let v0 = m687;
                let m684 = v0;
                match m684.uncons() {
                    None => {
                        Err::<List<Adt58>, List<Adt59>>(List::<Adt59>::nil())
                    }
                    Some((v2, v3)) => {
                        if f38(match v2.clone() {
                            Adt58::C0(h685, _) => {
                                h685
                            }
                        }, v1.clone()) {
                            match v2 {
                                Adt58::C0(_, h686) => {
                                    Err::<List<Adt58>, List<Adt59>>(h686)
                                }
                            }
                        } else {
                            Ok::<List<Adt58>, List<Adt59>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m687 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f31(v0: List<Adt59>, v1: u64, v2: u64) -> List<Adt59> {
    let m689 = f53(v0.clone(), v1);
    match m689 {
        None => {
            v0
        }
        Some(v3) => {
            f54(f29(v0, v1), v2, v3)
        }
    }
}

pub fn f32(v0: Adt0, v1: Adt52, v2: u64, v3: Adt11, v4: List<Adt59>) -> R<Adt64> {
    let m691 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h690) => {
            h690
        }
    };
    match m691 {
        None => {
            Ok(Adt64::C0(v0, List::cons(Adt65::C0(Adt66::C6(v3)), List::<Adt65>::nil())))
        }
        Some(v5) => {
            if if f1(match v0.clone() {
                Adt0::C0(h692, _, _, _, _, _, _) => {
                    h692
                }
            }, v1) {
                let a694 = match v5.clone() {
                    Adt60::C0(_, _, h693, _, _, _) => {
                        h693
                    }
                };
                let a695 = v2;
                if nat_eq(a694, a695) {
                    let a700 = match v3.clone() {
                        Adt11::C0(h696, _, _) => {
                            h696
                        }
                    };
                    let a701 = {
                        let m699 = match v0.clone() {
                            Adt0::C0(h698, _, _, _, _, _, _) => {
                                h698
                            }
                        };
                        match m699 {
                            Adt1::C0(h697, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h697
                            }
                        }
                    };
                    if nat_eq(a700, a701) {
                        if f19(v4.clone()) {
                            f55(match v5.clone() {
                                Adt60::C0(_, _, _, _, h702, _) => {
                                    h702
                                }
                            }, v4.clone())
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(Adt64::C0(Adt0::C0({
                    let m707 = {
                        let m706 = f20(v0.clone(), match v5.clone() {
                            Adt60::C0(h705, _, _, _, _, _) => {
                                h705
                            }
                        }, v3.clone(), v4.clone())?;
                        match m706 {
                            Adt64::C0(h704, _) => {
                                h704
                            }
                        }
                    };
                    match m707 {
                        Adt0::C0(h703, _, _, _, _, _, _) => {
                            h703
                        }
                    }
                }, {
                    let m712 = {
                        let m711 = f20(v0.clone(), match v5.clone() {
                            Adt60::C0(h710, _, _, _, _, _) => {
                                h710
                            }
                        }, v3.clone(), v4.clone())?;
                        match m711 {
                            Adt64::C0(h709, _) => {
                                h709
                            }
                        }
                    };
                    match m712 {
                        Adt0::C0(_, h708, _, _, _, _, _) => {
                            h708
                        }
                    }
                }, {
                    let m717 = {
                        let m716 = f20(v0.clone(), match v5.clone() {
                            Adt60::C0(h715, _, _, _, _, _) => {
                                h715
                            }
                        }, v3.clone(), v4.clone())?;
                        match m716 {
                            Adt64::C0(h714, _) => {
                                h714
                            }
                        }
                    };
                    match m717 {
                        Adt0::C0(_, _, h713, _, _, _, _) => {
                            h713
                        }
                    }
                }, {
                    let m722 = {
                        let m721 = f20(v0.clone(), match v5.clone() {
                            Adt60::C0(h720, _, _, _, _, _) => {
                                h720
                            }
                        }, v3.clone(), v4.clone())?;
                        match m721 {
                            Adt64::C0(h719, _) => {
                                h719
                            }
                        }
                    };
                    match m722 {
                        Adt0::C0(_, _, _, h718, _, _, _) => {
                            h718
                        }
                    }
                }, {
                    let m727 = {
                        let m726 = f20(v0.clone(), match v5.clone() {
                            Adt60::C0(h725, _, _, _, _, _) => {
                                h725
                            }
                        }, v3.clone(), v4.clone())?;
                        match m726 {
                            Adt64::C0(h724, _) => {
                                h724
                            }
                        }
                    };
                    match m727 {
                        Adt0::C0(_, _, _, _, h723, _, _) => {
                            h723
                        }
                    }
                }, {
                    let m732 = {
                        let m731 = f20(v0.clone(), match v5.clone() {
                            Adt60::C0(h730, _, _, _, _, _) => {
                                h730
                            }
                        }, v3.clone(), v4.clone())?;
                        match m731 {
                            Adt64::C0(h729, _) => {
                                h729
                            }
                        }
                    };
                    match m732 {
                        Adt0::C0(_, _, _, _, _, h728, _) => {
                            h728
                        }
                    }
                }, None::<Adt60>), List::cons(Adt65::C0(Adt66::C6(match v5.clone() {
                    Adt60::C0(_, _, _, h733, _, _) => {
                        h733
                    }
                })), {
                    let m736 = f20(v0, match v5 {
                        Adt60::C0(h735, _, _, _, _, _) => {
                            h735
                        }
                    }, v3, v4)?;
                    match m736 {
                        Adt64::C0(_, h734) => {
                            h734
                        }
                    }
                })))
            } else {
                Ok(Adt64::C0(v0, List::cons(Adt65::C0(Adt66::C6(v3)), List::<Adt65>::nil())))
            }
        }
    }
}

pub fn f33(v0: Adt0, v1: Adt52, v2: u64, v3: Str) -> R<Adt64> {
    let m738 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h737) => {
            h737
        }
    };
    match m738 {
        None => {
            Ok(Adt64::C0(v0, List::<Adt65>::nil()))
        }
        Some(v4) => {
            if if f1(match v0.clone() {
                Adt0::C0(h739, _, _, _, _, _, _) => {
                    h739
                }
            }, v1) {
                let a741 = match v4.clone() {
                    Adt60::C0(_, _, h740, _, _, _) => {
                        h740
                    }
                };
                let a742 = v2;
                nat_eq(a741, a742)
            } else {
                false
            } {
                Ok(Adt64::C0(Adt0::C0({
                    let m745 = f7(match v0.clone() {
                        Adt0::C0(h744, _, _, _, _, _, _) => {
                            h744
                        }
                    }, Adt41::C8(v3));
                    match m745 {
                        Adt71::C0(h743, _) => {
                            h743
                        }
                    }
                }, {
                    let m759 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h747, _, _, _, _, _, _) => {
                            h747
                        }
                    }, f34(match v0.clone() {
                        Adt0::C0(_, h748, _, _, _, _, _) => {
                            h748
                        }
                    }, match v4.clone() {
                        Adt60::C0(h749, _, _, _, _, _) => {
                            h749
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h750, _, _) => {
                            h750
                        }
                    })), {
                        let a752 = match v0.clone() {
                            Adt0::C0(_, _, h751, _, _, _, _) => {
                                h751
                            }
                        };
                        let a753 = 1u64;
                        nat_add(a752, a753)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h754, _, _, _) => {
                            h754
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h755, _, _) => {
                            h755
                        }
                    }, f22(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h756, _) => {
                            h756
                        }
                    }, match v4.clone() {
                        Adt60::C0(h757, _, _, _, _, _) => {
                            h757
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h758) => {
                            h758
                        }
                    }), None::<Adt60>);
                    match m759 {
                        Adt0::C0(_, h746, _, _, _, _, _) => {
                            h746
                        }
                    }
                }, {
                    let m773 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h761, _, _, _, _, _, _) => {
                            h761
                        }
                    }, f34(match v0.clone() {
                        Adt0::C0(_, h762, _, _, _, _, _) => {
                            h762
                        }
                    }, match v4.clone() {
                        Adt60::C0(h763, _, _, _, _, _) => {
                            h763
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h764, _, _) => {
                            h764
                        }
                    })), {
                        let a766 = match v0.clone() {
                            Adt0::C0(_, _, h765, _, _, _, _) => {
                                h765
                            }
                        };
                        let a767 = 1u64;
                        nat_add(a766, a767)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h768, _, _, _) => {
                            h768
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h769, _, _) => {
                            h769
                        }
                    }, f22(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h770, _) => {
                            h770
                        }
                    }, match v4.clone() {
                        Adt60::C0(h771, _, _, _, _, _) => {
                            h771
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h772) => {
                            h772
                        }
                    }), None::<Adt60>);
                    match m773 {
                        Adt0::C0(_, _, h760, _, _, _, _) => {
                            h760
                        }
                    }
                }, {
                    let m787 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h775, _, _, _, _, _, _) => {
                            h775
                        }
                    }, f34(match v0.clone() {
                        Adt0::C0(_, h776, _, _, _, _, _) => {
                            h776
                        }
                    }, match v4.clone() {
                        Adt60::C0(h777, _, _, _, _, _) => {
                            h777
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h778, _, _) => {
                            h778
                        }
                    })), {
                        let a780 = match v0.clone() {
                            Adt0::C0(_, _, h779, _, _, _, _) => {
                                h779
                            }
                        };
                        let a781 = 1u64;
                        nat_add(a780, a781)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h782, _, _, _) => {
                            h782
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h783, _, _) => {
                            h783
                        }
                    }, f22(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h784, _) => {
                            h784
                        }
                    }, match v4.clone() {
                        Adt60::C0(h785, _, _, _, _, _) => {
                            h785
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h786) => {
                            h786
                        }
                    }), None::<Adt60>);
                    match m787 {
                        Adt0::C0(_, _, _, h774, _, _, _) => {
                            h774
                        }
                    }
                }, {
                    let m801 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h789, _, _, _, _, _, _) => {
                            h789
                        }
                    }, f34(match v0.clone() {
                        Adt0::C0(_, h790, _, _, _, _, _) => {
                            h790
                        }
                    }, match v4.clone() {
                        Adt60::C0(h791, _, _, _, _, _) => {
                            h791
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h792, _, _) => {
                            h792
                        }
                    })), {
                        let a794 = match v0.clone() {
                            Adt0::C0(_, _, h793, _, _, _, _) => {
                                h793
                            }
                        };
                        let a795 = 1u64;
                        nat_add(a794, a795)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h796, _, _, _) => {
                            h796
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h797, _, _) => {
                            h797
                        }
                    }, f22(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h798, _) => {
                            h798
                        }
                    }, match v4.clone() {
                        Adt60::C0(h799, _, _, _, _, _) => {
                            h799
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h800) => {
                            h800
                        }
                    }), None::<Adt60>);
                    match m801 {
                        Adt0::C0(_, _, _, _, h788, _, _) => {
                            h788
                        }
                    }
                }, {
                    let m815 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h803, _, _, _, _, _, _) => {
                            h803
                        }
                    }, f34(match v0.clone() {
                        Adt0::C0(_, h804, _, _, _, _, _) => {
                            h804
                        }
                    }, match v4.clone() {
                        Adt60::C0(h805, _, _, _, _, _) => {
                            h805
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h806, _, _) => {
                            h806
                        }
                    })), {
                        let a808 = match v0.clone() {
                            Adt0::C0(_, _, h807, _, _, _, _) => {
                                h807
                            }
                        };
                        let a809 = 1u64;
                        nat_add(a808, a809)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h810, _, _, _) => {
                            h810
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h811, _, _) => {
                            h811
                        }
                    }, f22(match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h812, _) => {
                            h812
                        }
                    }, match v4.clone() {
                        Adt60::C0(h813, _, _, _, _, _) => {
                            h813
                        }
                    }, match v4.clone() {
                        Adt60::C0(_, _, _, _, _, h814) => {
                            h814
                        }
                    }), None::<Adt60>);
                    match m815 {
                        Adt0::C0(_, _, _, _, _, h802, _) => {
                            h802
                        }
                    }
                }, {
                    let m829 = Adt0::C0(match v0.clone() {
                        Adt0::C0(h817, _, _, _, _, _, _) => {
                            h817
                        }
                    }, f34(match v0.clone() {
                        Adt0::C0(_, h818, _, _, _, _, _) => {
                            h818
                        }
                    }, match v4.clone() {
                        Adt60::C0(h819, _, _, _, _, _) => {
                            h819
                        }
                    }, Some(match v4.clone() {
                        Adt60::C0(_, _, _, h820, _, _) => {
                            h820
                        }
                    })), {
                        let a822 = match v0.clone() {
                            Adt0::C0(_, _, h821, _, _, _, _) => {
                                h821
                            }
                        };
                        let a823 = 1u64;
                        nat_add(a822, a823)?
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h824, _, _, _) => {
                            h824
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h825, _, _) => {
                            h825
                        }
                    }, f22(match v0 {
                        Adt0::C0(_, _, _, _, _, h826, _) => {
                            h826
                        }
                    }, match v4.clone() {
                        Adt60::C0(h827, _, _, _, _, _) => {
                            h827
                        }
                    }, match v4 {
                        Adt60::C0(_, _, _, _, _, h828) => {
                            h828
                        }
                    }), None::<Adt60>);
                    match m829 {
                        Adt0::C0(_, _, _, _, _, _, h816) => {
                            h816
                        }
                    }
                }), List::<Adt65>::nil()))
            } else {
                Ok(Adt64::C0(v0, List::<Adt65>::nil()))
            }
        }
    }
}

pub fn f34(v0: Adt53, v1: Adt55, v2: Option<Adt11>) -> Adt53 {
    let m830 = v1;
    match m830 {
        Adt55::C0 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h831, _, _, _, _, _, _, _) => {
                    h831
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, h832, _, _, _, _, _) => {
                    h832
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h833, _, _, _, _) => {
                    h833
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h834, _, _, _) => {
                    h834
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h835, _, _) => {
                    h835
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h836, _) => {
                    h836
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h837) => {
                    h837
                }
            })
        }
        Adt55::C1 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h838, _, _, _, _, _, _, _) => {
                    h838
                }
            }, match v0.clone() {
                Adt53::C0(_, h839, _, _, _, _, _, _) => {
                    h839
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, h840, _, _, _, _) => {
                    h840
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h841, _, _, _) => {
                    h841
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h842, _, _) => {
                    h842
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h843, _) => {
                    h843
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h844) => {
                    h844
                }
            })
        }
        Adt55::C2 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h845, _, _, _, _, _, _, _) => {
                    h845
                }
            }, match v0.clone() {
                Adt53::C0(_, h846, _, _, _, _, _, _) => {
                    h846
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h847, _, _, _, _, _) => {
                    h847
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, h848, _, _, _) => {
                    h848
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h849, _, _) => {
                    h849
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h850, _) => {
                    h850
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h851) => {
                    h851
                }
            })
        }
        Adt55::C3 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h852, _, _, _, _, _, _, _) => {
                    h852
                }
            }, match v0.clone() {
                Adt53::C0(_, h853, _, _, _, _, _, _) => {
                    h853
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h854, _, _, _, _, _) => {
                    h854
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h855, _, _, _, _) => {
                    h855
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h856, _, _) => {
                    h856
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h857, _) => {
                    h857
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h858) => {
                    h858
                }
            })
        }
        Adt55::C4 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h859, _, _, _, _, _, _, _) => {
                    h859
                }
            }, match v0.clone() {
                Adt53::C0(_, h860, _, _, _, _, _, _) => {
                    h860
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h861, _, _, _, _, _) => {
                    h861
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h862, _, _, _, _) => {
                    h862
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h863, _, _, _) => {
                    h863
                }
            }, v2, match v0.clone() {
                Adt53::C0(_, _, _, _, _, _, h864, _) => {
                    h864
                }
            }, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h865) => {
                    h865
                }
            })
        }
        Adt55::C5 => {
            Adt53::C0(match v0.clone() {
                Adt53::C0(h866, _, _, _, _, _, _, _) => {
                    h866
                }
            }, match v0.clone() {
                Adt53::C0(_, h867, _, _, _, _, _, _) => {
                    h867
                }
            }, match v0.clone() {
                Adt53::C0(_, _, h868, _, _, _, _, _) => {
                    h868
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, h869, _, _, _, _) => {
                    h869
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, h870, _, _, _) => {
                    h870
                }
            }, match v0.clone() {
                Adt53::C0(_, _, _, _, _, h871, _, _) => {
                    h871
                }
            }, v2, match v0 {
                Adt53::C0(_, _, _, _, _, _, _, h872) => {
                    h872
                }
            })
        }
    }
}

pub fn f35(v0: u8) -> Option<u64> {
    let a873 = v0;
    let a874 = 48u8;
    if equal(a873, a874) {
        Some(0u64)
    } else {
        let a875 = v0;
        let a876 = 49u8;
        if equal(a875, a876) {
            Some(1u64)
        } else {
            let a877 = v0;
            let a878 = 50u8;
            if equal(a877, a878) {
                Some(2u64)
            } else {
                let a879 = v0;
                let a880 = 51u8;
                if equal(a879, a880) {
                    Some(3u64)
                } else {
                    let a881 = v0;
                    let a882 = 52u8;
                    if equal(a881, a882) {
                        Some(4u64)
                    } else {
                        let a883 = v0;
                        let a884 = 53u8;
                        if equal(a883, a884) {
                            Some(5u64)
                        } else {
                            let a885 = v0;
                            let a886 = 54u8;
                            if equal(a885, a886) {
                                Some(6u64)
                            } else {
                                let a887 = v0;
                                let a888 = 55u8;
                                if equal(a887, a888) {
                                    Some(7u64)
                                } else {
                                    let a889 = v0;
                                    let a890 = 56u8;
                                    if equal(a889, a890) {
                                        Some(8u64)
                                    } else {
                                        let a891 = v0;
                                        let a892 = 57u8;
                                        if equal(a891, a892) {
                                            Some(9u64)
                                        } else {
                                            None::<u64>
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn f36(v0: Adt0, v1: Adt53) -> R<Adt64> {
    Ok(f6(v0.clone(), v1, f43(match v0 {
        Adt0::C0(h893, _, _, _, _, _, _) => {
            h893
        }
    }, Adt72::C1)?))
}

pub fn f37(v0: Adt1) -> Adt52 {
    Adt52::C0(match v0.clone() {
        Adt1::C0(h894, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h894
        }
    }, {
        let m897 = match v0.clone() {
            Adt1::C0(_, h896, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h896
            }
        };
        match m897 {
            Adt2::C0(_, h895, _, _, _, _) => {
                h895
            }
        }
    }, {
        let m900 = match v0 {
            Adt1::C0(_, h899, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h899
            }
        };
        match m900 {
            Adt2::C0(h898, _, _, _, _, _) => {
                h898
            }
        }
    })
}

pub fn f38(v0: Adt55, v1: Adt55) -> bool {
    let m901 = v0;
    match m901 {
        Adt55::C0 => {
            let m902 = v1;
            match m902 {
                Adt55::C0 => {
                    true
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C1 => {
            let m903 = v1;
            match m903 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    true
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C2 => {
            let m904 = v1;
            match m904 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    true
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C3 => {
            let m905 = v1;
            match m905 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    true
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C4 => {
            let m906 = v1;
            match m906 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    true
                }
                Adt55::C5 => {
                    false
                }
            }
        }
        Adt55::C5 => {
            let m907 = v1;
            match m907 {
                Adt55::C0 => {
                    false
                }
                Adt55::C1 => {
                    false
                }
                Adt55::C2 => {
                    false
                }
                Adt55::C3 => {
                    false
                }
                Adt55::C4 => {
                    false
                }
                Adt55::C5 => {
                    true
                }
            }
        }
    }
}

pub fn f39(p913: List<Adt59>, v1: u64) -> bool {
    let m912 = p913;
    {
        let mut m912 = m912;
        loop {
            let step = {
                let v0 = m912;
                let m908 = v0;
                match m908.uncons() {
                    None => {
                        Err::<List<Adt59>, bool>(false)
                    }
                    Some((v2, v3)) => {
                        let a910 = match v2 {
                            Adt59::C0(h909, _, _) => {
                                h909
                            }
                        };
                        let a911 = v1;
                        if nat_eq(a910, a911) {
                            Err::<List<Adt59>, bool>(true)
                        } else {
                            Ok::<List<Adt59>, bool>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m912 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f40(v0: List<Adt66>, v1: List<Adt66>) -> List<Adt66> {
    let m914 = v0;
    match m914.uncons() {
        None => {
            v1
        }
        Some((v2, v3)) => {
            List::cons(v2, f40(v3, v1))
        }
    }
}

pub fn f41(v0: Option<Adt11>, v1: Option<Adt11>) -> List<Adt66> {
    let m915 = v0;
    match m915 {
        None => {
            List::<Adt66>::nil()
        }
        Some(v2) => {
            let m916 = v1;
            match m916 {
                None => {
                    List::cons(Adt66::C6(v2), List::<Adt66>::nil())
                }
                Some(v3) => {
                    if f56(v2.clone(), v3) {
                        List::<Adt66>::nil()
                    } else {
                        List::cons(Adt66::C6(v2), List::<Adt66>::nil())
                    }
                }
            }
        }
    }
}

pub fn f42(v0: Adt53, v1: Adt55) -> Option<Adt11> {
    let m917 = v1;
    match m917 {
        Adt55::C0 => {
            match v0 {
                Adt53::C0(_, h918, _, _, _, _, _, _) => {
                    h918
                }
            }
        }
        Adt55::C1 => {
            match v0 {
                Adt53::C0(_, _, h919, _, _, _, _, _) => {
                    h919
                }
            }
        }
        Adt55::C2 => {
            match v0 {
                Adt53::C0(_, _, _, h920, _, _, _, _) => {
                    h920
                }
            }
        }
        Adt55::C3 => {
            match v0 {
                Adt53::C0(_, _, _, _, h921, _, _, _) => {
                    h921
                }
            }
        }
        Adt55::C4 => {
            match v0 {
                Adt53::C0(_, _, _, _, _, h922, _, _) => {
                    h922
                }
            }
        }
        Adt55::C5 => {
            match v0 {
                Adt53::C0(_, _, _, _, _, _, h923, _) => {
                    h923
                }
            }
        }
    }
}

pub fn f43(v0: Adt1, v1: Adt72) -> R<Adt71> {
    let m924 = v1;
    match m924 {
        Adt72::C0(v2) => {
            f25(v0, v2)
        }
        Adt72::C1 => {
            f57(v0.clone(), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h925, _, _, _, _, _, _, _) => {
                    h925
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h926, _, _, _, _, _, _) => {
                    h926
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h927, _, _, _, _, _) => {
                    h927
                }
            })
        }
        Adt72::C2 => {
            f58(v0)
        }
        Adt72::C3(v3) => {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h928, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h928
                }
            }, match v0.clone() {
                Adt1::C0(_, h929, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h929
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h930, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h930
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h931, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h931
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h932, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h932
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h933, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h933
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h934, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h934
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h935, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h935
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h936, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h936
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h937, _, _, _, _, _, _, _, _, _, _, _) => {
                    h937
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h938, _, _, _, _, _, _, _, _, _, _) => {
                    h938
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h939, _, _, _, _, _, _, _, _, _) => {
                    h939
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h940, _, _, _, _, _, _, _, _) => {
                    h940
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h941, _, _, _, _, _, _, _) => {
                    h941
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h942, _, _, _, _, _, _) => {
                    h942
                }
            }, v3, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h943, _, _, _, _) => {
                    h943
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h944, _, _, _) => {
                    h944
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h945, _, _) => {
                    h945
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h946, _) => {
                    h946
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h947) => {
                    h947
                }
            }), List::<Adt66>::nil()))
        }
        Adt72::C4 => {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h948, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h948
                }
            }, match v0.clone() {
                Adt1::C0(_, h949, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h949
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h950, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h950
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h951, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h951
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h952, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h952
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h953, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h953
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h954, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h954
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h955, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h955
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h956, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h956
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h957, _, _, _, _, _, _, _, _, _, _, _) => {
                    h957
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h958, _, _, _, _, _, _, _, _, _, _) => {
                    h958
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h959, _, _, _, _, _, _, _, _, _) => {
                    h959
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h960, _, _, _, _, _, _, _, _) => {
                    h960
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h961, _, _, _, _, _, _, _) => {
                    h961
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h962, _, _, _, _, _, _) => {
                    h962
                }
            }, Adt48::C0, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h963, _, _, _, _) => {
                    h963
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h964, _, _, _) => {
                    h964
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h965, _, _) => {
                    h965
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h966, _) => {
                    h966
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h967) => {
                    h967
                }
            }), List::<Adt66>::nil()))
        }
        Adt72::C5 => {
            if match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h968, _, _, _, _, _, _, _) => {
                    h968
                }
            } {
                f57(v0.clone(), false, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h969, _, _, _, _, _, _) => {
                        h969
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h970, _, _, _, _, _) => {
                        h970
                    }
                })
            } else {
                Ok(Adt71::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt72::C6 => {
            f59(v0)
        }
        Adt72::C7 => {
            f59(v0)
        }
        Adt72::C8(v4) => {
            let a972 = match v0.clone() {
                Adt1::C0(h971, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h971
                }
            };
            let a973 = v4;
            if nat_eq(a972, a973) {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h974, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h974
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h975, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h975
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h976, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h976
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h977, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h977
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h978, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h978
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h979, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h979
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h980, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h980
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h981, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h981
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h982, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h982
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h983, _, _, _, _, _, _, _, _, _, _, _) => {
                        h983
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h984, _, _, _, _, _, _, _, _, _, _) => {
                        h984
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h985, _, _, _, _, _, _, _, _, _) => {
                        h985
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h986, _, _, _, _, _, _, _, _) => {
                        h986
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h987, _, _, _, _, _, _, _) => {
                        h987
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h988, _, _, _, _, _, _) => {
                        h988
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h989, _, _, _, _, _) => {
                        h989
                    }
                }, Adt49::C2, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h990, _, _, _) => {
                        h990
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h991, _, _) => {
                        h991
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h992, _) => {
                        h992
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h993) => {
                        h993
                    }
                }), List::<Adt66>::nil()))
            } else {
                Ok(Adt71::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt72::C9(v5) => {
            Ok(f60(v0, v5))
        }
        Adt72::C10(v6, v7) => {
            f61(v0, v6, v7)
        }
        Adt72::C11(v8) => {
            let m996 = match v0.clone() {
                Adt1::C0(_, h995, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h995
                }
            };
            if match m996 {
                Adt2::C0(_, _, h994, _, _, _) => {
                    h994
                }
            } {
                Ok(Adt71::C0(v0.clone(), List::cons(Adt66::C2(f37(v0), v8), List::<Adt66>::nil())))
            } else {
                Ok(Adt71::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt72::C12(v9, v10) => {
            if f62(v0.clone(), v9) {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h997, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h997
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h998, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h998
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h999, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h999
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1000, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1000
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1001, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1001
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1002, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1002
                    }
                }, v10, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1003, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1003
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1004, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1004
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1005, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1005
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1006, _, _, _, _, _, _, _, _, _, _) => {
                        h1006
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1007, _, _, _, _, _, _, _, _, _) => {
                        h1007
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1008, _, _, _, _, _, _, _, _) => {
                        h1008
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1009, _, _, _, _, _, _, _) => {
                        h1009
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1010, _, _, _, _, _, _) => {
                        h1010
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1011, _, _, _, _, _) => {
                        h1011
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1012, _, _, _, _) => {
                        h1012
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1013, _, _, _) => {
                        h1013
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1014, _, _) => {
                        h1014
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1015, _) => {
                        h1015
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1016) => {
                        h1016
                    }
                }), List::<Adt66>::nil()))
            } else {
                Ok(Adt71::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt72::C13(v11, v12) => {
            if if f62(v0.clone(), v11) {
                let a1019 = match v12.clone() {
                    Adt11::C0(h1017, _, _) => {
                        h1017
                    }
                };
                let a1020 = match v0.clone() {
                    Adt1::C0(h1018, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1018
                    }
                };
                nat_eq(a1019, a1020)
            } else {
                false
            } {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1021, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1021
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1022, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1022
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1023, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1023
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1024, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1024
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1025, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1025
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1026, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1026
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1027, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1027
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1028, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1028
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1029, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1029
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1030, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1030
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1031, _, _, _, _, _, _, _, _, _, _) => {
                        h1031
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1032, _, _, _, _, _, _, _, _, _) => {
                        h1032
                    }
                }, Some(v12), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1033, _, _, _, _, _, _, _) => {
                        h1033
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1034, _, _, _, _, _, _) => {
                        h1034
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1035, _, _, _, _, _) => {
                        h1035
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1036, _, _, _, _) => {
                        h1036
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1037, _, _, _) => {
                        h1037
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1038, _, _) => {
                        h1038
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1039, _) => {
                        h1039
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1040) => {
                        h1040
                    }
                }), f63(match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1041, _, _, _, _, _, _, _, _) => {
                        h1041
                    }
                })))
            } else {
                Ok(Adt71::C0(v0, List::cons(Adt66::C6(v12), List::<Adt66>::nil())))
            }
        }
        Adt72::C14(v13) => {
            Ok(f51(v0, v13))
        }
        Adt72::C15(v14, v15) => {
            f64(v0, v14, v15)
        }
        Adt72::C16(v16, v17) => {
            Ok(f65(v0, v16, v17))
        }
        Adt72::C17(v18, v19) => {
            if f62(v0.clone(), v18.clone()) {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1042, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1042
                    }
                }, f66(match v0.clone() {
                    Adt1::C0(_, h1043, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1043
                    }
                }), f67(match v0.clone() {
                    Adt1::C0(_, _, h1044, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1044
                    }
                }, Adt7::C3), match v0.clone() {
                    Adt1::C0(_, _, _, h1045, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1045
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1046, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1046
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1047, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1047
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1048, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1048
                    }
                }, None::<Adt11>, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1049, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1049
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1050, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1050
                    }
                }, None::<Adt41>, Some(v19), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1051, _, _, _, _, _, _, _, _) => {
                        h1051
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1052, _, _, _, _, _, _, _) => {
                        h1052
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1053, _, _, _, _, _, _) => {
                        h1053
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1054, _, _, _, _, _) => {
                        h1054
                    }
                }, Adt49::C1, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1055, _, _, _) => {
                        h1055
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1056, _, _) => {
                        h1056
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1057, _) => {
                        h1057
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1058) => {
                        h1058
                    }
                }), List::cons(Adt66::C4(v18.clone()), List::cons(Adt66::C5(v18), List::<Adt66>::nil()))))
            } else {
                Ok(Adt71::C0(v0, List::<Adt66>::nil()))
            }
        }
        Adt72::C18 => {
            Ok(f68(v0))
        }
        Adt72::C19(v20, v21) => {
            Ok(f69(v0, v20, v21))
        }
        Adt72::C20 => {
            Ok(f68(v0))
        }
        Adt72::C21(v22, v23) => {
            f70(v0, v22, v23)
        }
        Adt72::C22(v24, v25) => {
            f71(v0, v24, v25)
        }
        Adt72::C23(v26, v27) => {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1059, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1059
                }
            }, match v0.clone() {
                Adt1::C0(_, h1060, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1060
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1061, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1061
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1062, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1062
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1063, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1063
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1064, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1064
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1065, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1065
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1066, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1066
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1067, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1067
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1068, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1068
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1069, _, _, _, _, _, _, _, _, _, _) => {
                    h1069
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1070, _, _, _, _, _, _, _, _, _) => {
                    h1070
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1071, _, _, _, _, _, _, _, _) => {
                    h1071
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1072, _, _, _, _, _, _, _) => {
                    h1072
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1073, _, _, _, _, _, _) => {
                    h1073
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1074, _, _, _, _, _) => {
                    h1074
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1075, _, _, _, _) => {
                    h1075
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1076, _, _, _) => {
                    h1076
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1077, _, _) => {
                    h1077
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1078, _) => {
                    h1078
                }
            }, f72(match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1079) => {
                    h1079
                }
            }, v26, v27)?), List::<Adt66>::nil()))
        }
        Adt72::C24(v28) => {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1080, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1080
                }
            }, match v0.clone() {
                Adt1::C0(_, h1081, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1081
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1082, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1082
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1083, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1083
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1084, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1084
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1085, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1085
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1086, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1086
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1087, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1087
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1088, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1088
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1089, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1089
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1090, _, _, _, _, _, _, _, _, _, _) => {
                    h1090
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1091, _, _, _, _, _, _, _, _, _) => {
                    h1091
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1092, _, _, _, _, _, _, _, _) => {
                    h1092
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1093, _, _, _, _, _, _, _) => {
                    h1093
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1094, _, _, _, _, _, _) => {
                    h1094
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1095, _, _, _, _, _) => {
                    h1095
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1096, _, _, _, _) => {
                    h1096
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1097, _, _, _) => {
                    h1097
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1098, _, _) => {
                    h1098
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1099, _) => {
                    h1099
                }
            }, f73(match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1100) => {
                    h1100
                }
            }, v28)?), List::<Adt66>::nil()))
        }
    }
}

pub fn f44(v0: Adt2) -> R<Adt2> {
    Ok(Adt2::C0(match v0.clone() {
        Adt2::C0(h1101, _, _, _, _, _) => {
            h1101
        }
    }, {
        let a1103 = match v0 {
            Adt2::C0(_, h1102, _, _, _, _) => {
                h1102
            }
        };
        let a1104 = 1u64;
        nat_add(a1103, a1104)?
    }, true, false, Adt3::C1, Adt4::C0))
}

pub fn f45() -> Adt5 {
    Adt5::C0(Adt6::C0, false, 0u64, false, Adt7::C0)
}

pub fn f46() -> Adt8 {
    Adt8::C0(0u64, false, false, 0u64)
}

pub fn f47() -> Adt50 {
    Adt50::C0(f74(), None::<Adt45>)
}

pub fn f48(v0: Adt1) -> List<Adt51> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1105, _, _, _) => {
            h1105
        }
    } {
        List::cons(Adt51::C0(f37(v0.clone()), {
            let m1107 = match v0.clone() {
                Adt1::C0(_, _, _, _, h1106, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1106
                }
            };
            match m1107 {
                None => {
                    f75()
                }
                Some(v1) => {
                    let m1111 = {
                        let m1110 = f76(v1);
                        match m1110 {
                            Adt12::C0(h1109, _) => {
                                h1109
                            }
                        }
                    };
                    match m1111 {
                        Adt13::C0(_, _, _, _, _, _, h1108) => {
                            h1108
                        }
                    }
                }
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1112, _, _) => {
                h1112
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1113, _) => {
                h1113
            }
        }), match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1114) => {
                h1114
            }
        })
    } else {
        match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1115) => {
                h1115
            }
        }
    }
}

pub fn f49(v0: Adt1) -> List<Adt66> {
    f40(if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, h1116, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1116
        }
    } {
        List::cons(Adt66::C9(f37(v0.clone())), List::<Adt66>::nil())
    } else {
        List::<Adt66>::nil()
    }, f40(if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1117, _, _, _) => {
            h1117
        }
    } {
        let m1120 = match v0.clone() {
            Adt1::C0(_, h1119, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1119
            }
        };
        if match m1120 {
            Adt2::C0(_, _, h1118, _, _, _) => {
                h1118
            }
        } {
            List::cons(Adt66::C4(f37(v0.clone())), List::cons(Adt66::C5(f37(v0.clone())), List::<Adt66>::nil()))
        } else {
            List::cons(Adt66::C5(f37(v0.clone())), List::<Adt66>::nil())
        }
    } else {
        List::<Adt66>::nil()
    }, f40(f63(match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, h1121, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1121
        }
    }), f63(match v0 {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1122, _, _, _, _, _, _, _, _) => {
            h1122
        }
    }))))
}

pub fn f50(v0: Adt0) -> R<Adt64> {
    let m1124 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, h1123) => {
            h1123
        }
    };
    match m1124 {
        None => {
            let m1127 = match v0.clone() {
                Adt0::C0(h1126, _, _, _, _, _, _) => {
                    h1126
                }
            };
            if match m1127 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1125, _, _, _, _, _, _) => {
                    h1125
                }
            } {
                Ok(f6(v0.clone(), match v0.clone() {
                    Adt0::C0(_, h1128, _, _, _, _, _) => {
                        h1128
                    }
                }, f59(match v0 {
                    Adt0::C0(h1129, _, _, _, _, _, _) => {
                        h1129
                    }
                })?))
            } else {
                Ok(Adt64::C0(Adt0::C0({
                    let m1132 = f59(match v0.clone() {
                        Adt0::C0(h1131, _, _, _, _, _, _) => {
                            h1131
                        }
                    })?;
                    match m1132 {
                        Adt71::C0(h1130, _) => {
                            h1130
                        }
                    }
                }, Adt53::C0({
                    let m1135 = match v0.clone() {
                        Adt0::C0(_, h1134, _, _, _, _, _) => {
                            h1134
                        }
                    };
                    match m1135 {
                        Adt53::C0(h1133, _, _, _, _, _, _, _) => {
                            h1133
                        }
                    }
                }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                    let m1138 = match v0.clone() {
                        Adt0::C0(_, h1137, _, _, _, _, _) => {
                            h1137
                        }
                    };
                    match m1138 {
                        Adt53::C0(_, _, _, _, _, _, _, h1136) => {
                            h1136
                        }
                    }
                }), match v0.clone() {
                    Adt0::C0(_, _, h1139, _, _, _, _) => {
                        h1139
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, h1140, _, _, _) => {
                        h1140
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, h1141, _, _) => {
                        h1141
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, _, h1142, _) => {
                        h1142
                    }
                }, match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h1143) => {
                        h1143
                    }
                }), f13(f40(f77(match v0.clone() {
                    Adt0::C0(_, h1144, _, _, _, _, _) => {
                        h1144
                    }
                }), {
                    let m1147 = f59(match v0 {
                        Adt0::C0(h1146, _, _, _, _, _, _) => {
                            h1146
                        }
                    })?;
                    match m1147 {
                        Adt71::C0(_, h1145) => {
                            h1145
                        }
                    }
                }))))
            }
        }
        Some(v1) => {
            Ok(Adt64::C0(Adt0::C0({
                let m1174 = {
                    let m1173 = {
                        let m1152 = match v0.clone() {
                            Adt0::C0(h1151, _, _, _, _, _, _) => {
                                h1151
                            }
                        };
                        if match m1152 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1150, _, _, _, _, _, _) => {
                                h1150
                            }
                        } {
                            f6(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1153, _, _, _, _, _) => {
                                    h1153
                                }
                            }, f59(match v0.clone() {
                                Adt0::C0(h1154, _, _, _, _, _, _) => {
                                    h1154
                                }
                            })?)
                        } else {
                            Adt64::C0(Adt0::C0({
                                let m1157 = f59(match v0.clone() {
                                    Adt0::C0(h1156, _, _, _, _, _, _) => {
                                        h1156
                                    }
                                })?;
                                match m1157 {
                                    Adt71::C0(h1155, _) => {
                                        h1155
                                    }
                                }
                            }, Adt53::C0({
                                let m1160 = match v0.clone() {
                                    Adt0::C0(_, h1159, _, _, _, _, _) => {
                                        h1159
                                    }
                                };
                                match m1160 {
                                    Adt53::C0(h1158, _, _, _, _, _, _, _) => {
                                        h1158
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1163 = match v0.clone() {
                                    Adt0::C0(_, h1162, _, _, _, _, _) => {
                                        h1162
                                    }
                                };
                                match m1163 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1161) => {
                                        h1161
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1164, _, _, _, _) => {
                                    h1164
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1165, _, _, _) => {
                                    h1165
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1166, _, _) => {
                                    h1166
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1167, _) => {
                                    h1167
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1168) => {
                                    h1168
                                }
                            }), f13(f40(f77(match v0.clone() {
                                Adt0::C0(_, h1169, _, _, _, _, _) => {
                                    h1169
                                }
                            }), {
                                let m1172 = f59(match v0.clone() {
                                    Adt0::C0(h1171, _, _, _, _, _, _) => {
                                        h1171
                                    }
                                })?;
                                match m1172 {
                                    Adt71::C0(_, h1170) => {
                                        h1170
                                    }
                                }
                            })))
                        }
                    };
                    match m1173 {
                        Adt64::C0(h1149, _) => {
                            h1149
                        }
                    }
                };
                match m1174 {
                    Adt0::C0(h1148, _, _, _, _, _, _) => {
                        h1148
                    }
                }
            }, {
                let m1201 = {
                    let m1200 = {
                        let m1179 = match v0.clone() {
                            Adt0::C0(h1178, _, _, _, _, _, _) => {
                                h1178
                            }
                        };
                        if match m1179 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1177, _, _, _, _, _, _) => {
                                h1177
                            }
                        } {
                            f6(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1180, _, _, _, _, _) => {
                                    h1180
                                }
                            }, f59(match v0.clone() {
                                Adt0::C0(h1181, _, _, _, _, _, _) => {
                                    h1181
                                }
                            })?)
                        } else {
                            Adt64::C0(Adt0::C0({
                                let m1184 = f59(match v0.clone() {
                                    Adt0::C0(h1183, _, _, _, _, _, _) => {
                                        h1183
                                    }
                                })?;
                                match m1184 {
                                    Adt71::C0(h1182, _) => {
                                        h1182
                                    }
                                }
                            }, Adt53::C0({
                                let m1187 = match v0.clone() {
                                    Adt0::C0(_, h1186, _, _, _, _, _) => {
                                        h1186
                                    }
                                };
                                match m1187 {
                                    Adt53::C0(h1185, _, _, _, _, _, _, _) => {
                                        h1185
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1190 = match v0.clone() {
                                    Adt0::C0(_, h1189, _, _, _, _, _) => {
                                        h1189
                                    }
                                };
                                match m1190 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1188) => {
                                        h1188
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1191, _, _, _, _) => {
                                    h1191
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1192, _, _, _) => {
                                    h1192
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1193, _, _) => {
                                    h1193
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1194, _) => {
                                    h1194
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1195) => {
                                    h1195
                                }
                            }), f13(f40(f77(match v0.clone() {
                                Adt0::C0(_, h1196, _, _, _, _, _) => {
                                    h1196
                                }
                            }), {
                                let m1199 = f59(match v0.clone() {
                                    Adt0::C0(h1198, _, _, _, _, _, _) => {
                                        h1198
                                    }
                                })?;
                                match m1199 {
                                    Adt71::C0(_, h1197) => {
                                        h1197
                                    }
                                }
                            })))
                        }
                    };
                    match m1200 {
                        Adt64::C0(h1176, _) => {
                            h1176
                        }
                    }
                };
                match m1201 {
                    Adt0::C0(_, h1175, _, _, _, _, _) => {
                        h1175
                    }
                }
            }, {
                let m1228 = {
                    let m1227 = {
                        let m1206 = match v0.clone() {
                            Adt0::C0(h1205, _, _, _, _, _, _) => {
                                h1205
                            }
                        };
                        if match m1206 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1204, _, _, _, _, _, _) => {
                                h1204
                            }
                        } {
                            f6(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1207, _, _, _, _, _) => {
                                    h1207
                                }
                            }, f59(match v0.clone() {
                                Adt0::C0(h1208, _, _, _, _, _, _) => {
                                    h1208
                                }
                            })?)
                        } else {
                            Adt64::C0(Adt0::C0({
                                let m1211 = f59(match v0.clone() {
                                    Adt0::C0(h1210, _, _, _, _, _, _) => {
                                        h1210
                                    }
                                })?;
                                match m1211 {
                                    Adt71::C0(h1209, _) => {
                                        h1209
                                    }
                                }
                            }, Adt53::C0({
                                let m1214 = match v0.clone() {
                                    Adt0::C0(_, h1213, _, _, _, _, _) => {
                                        h1213
                                    }
                                };
                                match m1214 {
                                    Adt53::C0(h1212, _, _, _, _, _, _, _) => {
                                        h1212
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1217 = match v0.clone() {
                                    Adt0::C0(_, h1216, _, _, _, _, _) => {
                                        h1216
                                    }
                                };
                                match m1217 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1215) => {
                                        h1215
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1218, _, _, _, _) => {
                                    h1218
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1219, _, _, _) => {
                                    h1219
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1220, _, _) => {
                                    h1220
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1221, _) => {
                                    h1221
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1222) => {
                                    h1222
                                }
                            }), f13(f40(f77(match v0.clone() {
                                Adt0::C0(_, h1223, _, _, _, _, _) => {
                                    h1223
                                }
                            }), {
                                let m1226 = f59(match v0.clone() {
                                    Adt0::C0(h1225, _, _, _, _, _, _) => {
                                        h1225
                                    }
                                })?;
                                match m1226 {
                                    Adt71::C0(_, h1224) => {
                                        h1224
                                    }
                                }
                            })))
                        }
                    };
                    match m1227 {
                        Adt64::C0(h1203, _) => {
                            h1203
                        }
                    }
                };
                match m1228 {
                    Adt0::C0(_, _, h1202, _, _, _, _) => {
                        h1202
                    }
                }
            }, {
                let m1255 = {
                    let m1254 = {
                        let m1233 = match v0.clone() {
                            Adt0::C0(h1232, _, _, _, _, _, _) => {
                                h1232
                            }
                        };
                        if match m1233 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1231, _, _, _, _, _, _) => {
                                h1231
                            }
                        } {
                            f6(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1234, _, _, _, _, _) => {
                                    h1234
                                }
                            }, f59(match v0.clone() {
                                Adt0::C0(h1235, _, _, _, _, _, _) => {
                                    h1235
                                }
                            })?)
                        } else {
                            Adt64::C0(Adt0::C0({
                                let m1238 = f59(match v0.clone() {
                                    Adt0::C0(h1237, _, _, _, _, _, _) => {
                                        h1237
                                    }
                                })?;
                                match m1238 {
                                    Adt71::C0(h1236, _) => {
                                        h1236
                                    }
                                }
                            }, Adt53::C0({
                                let m1241 = match v0.clone() {
                                    Adt0::C0(_, h1240, _, _, _, _, _) => {
                                        h1240
                                    }
                                };
                                match m1241 {
                                    Adt53::C0(h1239, _, _, _, _, _, _, _) => {
                                        h1239
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1244 = match v0.clone() {
                                    Adt0::C0(_, h1243, _, _, _, _, _) => {
                                        h1243
                                    }
                                };
                                match m1244 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1242) => {
                                        h1242
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1245, _, _, _, _) => {
                                    h1245
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1246, _, _, _) => {
                                    h1246
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1247, _, _) => {
                                    h1247
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1248, _) => {
                                    h1248
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1249) => {
                                    h1249
                                }
                            }), f13(f40(f77(match v0.clone() {
                                Adt0::C0(_, h1250, _, _, _, _, _) => {
                                    h1250
                                }
                            }), {
                                let m1253 = f59(match v0.clone() {
                                    Adt0::C0(h1252, _, _, _, _, _, _) => {
                                        h1252
                                    }
                                })?;
                                match m1253 {
                                    Adt71::C0(_, h1251) => {
                                        h1251
                                    }
                                }
                            })))
                        }
                    };
                    match m1254 {
                        Adt64::C0(h1230, _) => {
                            h1230
                        }
                    }
                };
                match m1255 {
                    Adt0::C0(_, _, _, h1229, _, _, _) => {
                        h1229
                    }
                }
            }, {
                let m1282 = {
                    let m1281 = {
                        let m1260 = match v0.clone() {
                            Adt0::C0(h1259, _, _, _, _, _, _) => {
                                h1259
                            }
                        };
                        if match m1260 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1258, _, _, _, _, _, _) => {
                                h1258
                            }
                        } {
                            f6(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1261, _, _, _, _, _) => {
                                    h1261
                                }
                            }, f59(match v0.clone() {
                                Adt0::C0(h1262, _, _, _, _, _, _) => {
                                    h1262
                                }
                            })?)
                        } else {
                            Adt64::C0(Adt0::C0({
                                let m1265 = f59(match v0.clone() {
                                    Adt0::C0(h1264, _, _, _, _, _, _) => {
                                        h1264
                                    }
                                })?;
                                match m1265 {
                                    Adt71::C0(h1263, _) => {
                                        h1263
                                    }
                                }
                            }, Adt53::C0({
                                let m1268 = match v0.clone() {
                                    Adt0::C0(_, h1267, _, _, _, _, _) => {
                                        h1267
                                    }
                                };
                                match m1268 {
                                    Adt53::C0(h1266, _, _, _, _, _, _, _) => {
                                        h1266
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1271 = match v0.clone() {
                                    Adt0::C0(_, h1270, _, _, _, _, _) => {
                                        h1270
                                    }
                                };
                                match m1271 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1269) => {
                                        h1269
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1272, _, _, _, _) => {
                                    h1272
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1273, _, _, _) => {
                                    h1273
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1274, _, _) => {
                                    h1274
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1275, _) => {
                                    h1275
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1276) => {
                                    h1276
                                }
                            }), f13(f40(f77(match v0.clone() {
                                Adt0::C0(_, h1277, _, _, _, _, _) => {
                                    h1277
                                }
                            }), {
                                let m1280 = f59(match v0.clone() {
                                    Adt0::C0(h1279, _, _, _, _, _, _) => {
                                        h1279
                                    }
                                })?;
                                match m1280 {
                                    Adt71::C0(_, h1278) => {
                                        h1278
                                    }
                                }
                            })))
                        }
                    };
                    match m1281 {
                        Adt64::C0(h1257, _) => {
                            h1257
                        }
                    }
                };
                match m1282 {
                    Adt0::C0(_, _, _, _, h1256, _, _) => {
                        h1256
                    }
                }
            }, {
                let m1309 = {
                    let m1308 = {
                        let m1287 = match v0.clone() {
                            Adt0::C0(h1286, _, _, _, _, _, _) => {
                                h1286
                            }
                        };
                        if match m1287 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1285, _, _, _, _, _, _) => {
                                h1285
                            }
                        } {
                            f6(v0.clone(), match v0.clone() {
                                Adt0::C0(_, h1288, _, _, _, _, _) => {
                                    h1288
                                }
                            }, f59(match v0.clone() {
                                Adt0::C0(h1289, _, _, _, _, _, _) => {
                                    h1289
                                }
                            })?)
                        } else {
                            Adt64::C0(Adt0::C0({
                                let m1292 = f59(match v0.clone() {
                                    Adt0::C0(h1291, _, _, _, _, _, _) => {
                                        h1291
                                    }
                                })?;
                                match m1292 {
                                    Adt71::C0(h1290, _) => {
                                        h1290
                                    }
                                }
                            }, Adt53::C0({
                                let m1295 = match v0.clone() {
                                    Adt0::C0(_, h1294, _, _, _, _, _) => {
                                        h1294
                                    }
                                };
                                match m1295 {
                                    Adt53::C0(h1293, _, _, _, _, _, _, _) => {
                                        h1293
                                    }
                                }
                            }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                                let m1298 = match v0.clone() {
                                    Adt0::C0(_, h1297, _, _, _, _, _) => {
                                        h1297
                                    }
                                };
                                match m1298 {
                                    Adt53::C0(_, _, _, _, _, _, _, h1296) => {
                                        h1296
                                    }
                                }
                            }), match v0.clone() {
                                Adt0::C0(_, _, h1299, _, _, _, _) => {
                                    h1299
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, h1300, _, _, _) => {
                                    h1300
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, h1301, _, _) => {
                                    h1301
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, h1302, _) => {
                                    h1302
                                }
                            }, match v0.clone() {
                                Adt0::C0(_, _, _, _, _, _, h1303) => {
                                    h1303
                                }
                            }), f13(f40(f77(match v0.clone() {
                                Adt0::C0(_, h1304, _, _, _, _, _) => {
                                    h1304
                                }
                            }), {
                                let m1307 = f59(match v0.clone() {
                                    Adt0::C0(h1306, _, _, _, _, _, _) => {
                                        h1306
                                    }
                                })?;
                                match m1307 {
                                    Adt71::C0(_, h1305) => {
                                        h1305
                                    }
                                }
                            })))
                        }
                    };
                    match m1308 {
                        Adt64::C0(h1284, _) => {
                            h1284
                        }
                    }
                };
                match m1309 {
                    Adt0::C0(_, _, _, _, _, h1283, _) => {
                        h1283
                    }
                }
            }, None::<Adt60>), List::cons(Adt65::C3(v1.clone()), List::cons(Adt65::C0(Adt66::C6(match v1 {
                Adt60::C0(_, _, _, h1310, _, _) => {
                    h1310
                }
            })), {
                let m1335 = {
                    let m1314 = match v0.clone() {
                        Adt0::C0(h1313, _, _, _, _, _, _) => {
                            h1313
                        }
                    };
                    if match m1314 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1312, _, _, _, _, _, _) => {
                            h1312
                        }
                    } {
                        f6(v0.clone(), match v0.clone() {
                            Adt0::C0(_, h1315, _, _, _, _, _) => {
                                h1315
                            }
                        }, f59(match v0 {
                            Adt0::C0(h1316, _, _, _, _, _, _) => {
                                h1316
                            }
                        })?)
                    } else {
                        Adt64::C0(Adt0::C0({
                            let m1319 = f59(match v0.clone() {
                                Adt0::C0(h1318, _, _, _, _, _, _) => {
                                    h1318
                                }
                            })?;
                            match m1319 {
                                Adt71::C0(h1317, _) => {
                                    h1317
                                }
                            }
                        }, Adt53::C0({
                            let m1322 = match v0.clone() {
                                Adt0::C0(_, h1321, _, _, _, _, _) => {
                                    h1321
                                }
                            };
                            match m1322 {
                                Adt53::C0(h1320, _, _, _, _, _, _, _) => {
                                    h1320
                                }
                            }
                        }, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, None::<Adt11>, {
                            let m1325 = match v0.clone() {
                                Adt0::C0(_, h1324, _, _, _, _, _) => {
                                    h1324
                                }
                            };
                            match m1325 {
                                Adt53::C0(_, _, _, _, _, _, _, h1323) => {
                                    h1323
                                }
                            }
                        }), match v0.clone() {
                            Adt0::C0(_, _, h1326, _, _, _, _) => {
                                h1326
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h1327, _, _, _) => {
                                h1327
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h1328, _, _) => {
                                h1328
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h1329, _) => {
                                h1329
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, h1330) => {
                                h1330
                            }
                        }), f13(f40(f77(match v0.clone() {
                            Adt0::C0(_, h1331, _, _, _, _, _) => {
                                h1331
                            }
                        }), {
                            let m1334 = f59(match v0 {
                                Adt0::C0(h1333, _, _, _, _, _, _) => {
                                    h1333
                                }
                            })?;
                            match m1334 {
                                Adt71::C0(_, h1332) => {
                                    h1332
                                }
                            }
                        })))
                    }
                };
                match m1335 {
                    Adt64::C0(_, h1311) => {
                        h1311
                    }
                }
            }))))
        }
    }
}

pub fn f51(v0: Adt1, v1: u64) -> Adt71 {
    let a1336 = v1;
    let a1337 = 0u64;
    if nat_eq(a1336, a1337) {
        Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1338, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1338
            }
        }, match v0.clone() {
            Adt1::C0(_, h1339, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1339
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1340, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1340
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1341, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1341
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1342, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1342
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1343, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1343
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1344, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1344
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1345, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1345
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1346, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1346
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1347, _, _, _, _, _, _, _, _, _, _, _) => {
                h1347
            }
        }, Some(Adt41::C10(Adt43::C12)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1348, _, _, _, _, _, _, _, _, _) => {
                h1348
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1349, _, _, _, _, _, _, _, _) => {
                h1349
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1350, _, _, _, _, _, _, _) => {
                h1350
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1351, _, _, _, _, _, _) => {
                h1351
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1352, _, _, _, _, _) => {
                h1352
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1353, _, _, _, _) => {
                h1353
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1354, _, _, _) => {
                h1354
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1355, _, _) => {
                h1355
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1356, _) => {
                h1356
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1357) => {
                h1357
            }
        }), List::<Adt66>::nil())
    } else {
        let m1360 = match v0.clone() {
            Adt1::C0(_, h1359, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1359
            }
        };
        if match m1360 {
            Adt2::C0(_, _, h1358, _, _, _) => {
                h1358
            }
        } {
            Adt71::C0(v0.clone(), List::cons(Adt66::C3(f37(v0), v1), List::<Adt66>::nil()))
        } else {
            Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1361, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1361
                }
            }, match v0.clone() {
                Adt1::C0(_, h1362, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1362
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1363, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1363
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1364, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1364
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1365, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1365
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1366, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1366
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1367, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1367
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1368, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1368
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1369, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1369
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1370, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1370
                }
            }, Some(Adt41::C10(Adt43::C3)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1371, _, _, _, _, _, _, _, _, _) => {
                    h1371
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1372, _, _, _, _, _, _, _, _) => {
                    h1372
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1373, _, _, _, _, _, _, _) => {
                    h1373
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1374, _, _, _, _, _, _) => {
                    h1374
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1375, _, _, _, _, _) => {
                    h1375
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1376, _, _, _, _) => {
                    h1376
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1377, _, _, _) => {
                    h1377
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1378, _, _) => {
                    h1378
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1379, _) => {
                    h1379
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1380) => {
                    h1380
                }
            }), List::<Adt66>::nil())
        }
    }
}

pub fn f52(v0: Adt1, v1: Adt17) -> R<Adt71> {
    f25(v0, Adt9::C4(v1))
}

pub fn f53(p1386: List<Adt59>, v1: u64) -> Option<Adt59> {
    let m1385 = p1386;
    {
        let mut m1385 = m1385;
        loop {
            let step = {
                let v0 = m1385;
                let m1381 = v0;
                match m1381.uncons() {
                    None => {
                        Err::<List<Adt59>, Option<Adt59>>(None::<Adt59>)
                    }
                    Some((v2, v3)) => {
                        let a1383 = match v2.clone() {
                            Adt59::C0(h1382, _, _) => {
                                h1382
                            }
                        };
                        let a1384 = v1;
                        if nat_eq(a1383, a1384) {
                            Err::<List<Adt59>, Option<Adt59>>(Some(v2))
                        } else {
                            Ok::<List<Adt59>, Option<Adt59>>(v3)
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m1385 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f54(v0: List<Adt59>, v1: u64, v2: Adt59) -> List<Adt59> {
    let m1387 = v0;
    match m1387.uncons() {
        None => {
            List::cons(v2, List::<Adt59>::nil())
        }
        Some((v3, v4)) => {
            let a1388 = v1;
            let a1389 = 0u64;
            if nat_eq(a1388, a1389) {
                List::cons(v2, List::cons(v3, v4))
            } else {
                List::cons(v3, f54(v4, {
                    let a1390 = v1;
                    let a1391 = 1u64;
                    nat_sub(a1390, a1391)
                }, v2))
            }
        }
    }
}

pub fn f55(p1400: List<Adt59>, p1401: List<Adt59>) -> bool {
    let m1399 = (p1400, p1401);
    {
        let mut m1399 = m1399;
        loop {
            let step = {
                let (v0, v1) = m1399;
                let m1392 = v0;
                match m1392.uncons() {
                    None => {
                        let m1393 = v1;
                        match m1393.uncons() {
                            None => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(true)
                            }
                            Some((_, _)) => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(false)
                            }
                        }
                    }
                    Some((v4, v5)) => {
                        let m1394 = v1;
                        match m1394.uncons() {
                            None => {
                                Err::<(List<Adt59>, List<Adt59>), bool>(false)
                            }
                            Some((v6, v7)) => {
                                let a1397 = match v4 {
                                    Adt59::C0(h1395, _, _) => {
                                        h1395
                                    }
                                };
                                let a1398 = match v6 {
                                    Adt59::C0(h1396, _, _) => {
                                        h1396
                                    }
                                };
                                if nat_eq(a1397, a1398) {
                                    Ok::<(List<Adt59>, List<Adt59>), bool>((v5, v7))
                                } else {
                                    Err::<(List<Adt59>, List<Adt59>), bool>(false)
                                }
                            }
                        }
                    }
                }
            };
            match step {
                Ok(next) => { m1399 = next; }
                Err(done) => break done,
            }
        }
    }
}

pub fn f56(v0: Adt11, v1: Adt11) -> bool {
    let a1404 = match v0.clone() {
        Adt11::C0(h1402, _, _) => {
            h1402
        }
    };
    let a1405 = match v1.clone() {
        Adt11::C0(h1403, _, _) => {
            h1403
        }
    };
    if nat_eq(a1404, a1405) {
        let a1408 = match v0.clone() {
            Adt11::C0(_, h1406, _) => {
                h1406
            }
        };
        let a1409 = match v1.clone() {
            Adt11::C0(_, h1407, _) => {
                h1407
            }
        };
        if nat_eq(a1408, a1409) {
            let a1412 = match v0 {
                Adt11::C0(_, _, h1410) => {
                    h1410
                }
            };
            let a1413 = match v1 {
                Adt11::C0(_, _, h1411) => {
                    h1411
                }
            };
            nat_eq(a1412, a1413)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f57(v0: Adt1, v1: bool, v2: bool, v3: Adt48) -> R<Adt71> {
    Ok(Adt71::C0(Adt1::C0(match v0.clone() {
        Adt1::C0(h1414, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1414
        }
    }, f78(match v0.clone() {
        Adt1::C0(_, h1415, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1415
        }
    })?, f45(), f46(), None::<Adt9>, None::<Adt22>, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, h1416, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1416
        }
    }, None::<Adt11>, false, false, None::<Adt41>, None::<Adt47>, None::<Adt11>, v1, v2, v3, Adt49::C1, false, match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1417, _, _) => {
            h1417
        }
    }, None::<Adt23>, f48(v0.clone())), f49(v0)))
}

pub fn f58(v0: Adt1) -> R<Adt71> {
    let m1420 = match v0.clone() {
        Adt1::C0(_, h1419, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1419
        }
    };
    if match m1420 {
        Adt2::C0(_, _, h1418, _, _, _) => {
            h1418
        }
    } {
        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1421, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1421
            }
        }, f66(match v0.clone() {
            Adt1::C0(_, h1422, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1422
            }
        }), f67(match v0.clone() {
            Adt1::C0(_, _, h1423, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1423
            }
        }, Adt7::C2), match v0.clone() {
            Adt1::C0(_, _, _, h1424, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1424
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1425, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1425
            }
        }, None::<Adt22>, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1426, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1426
            }
        }, None::<Adt11>, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1427, _, _, _, _, _, _, _, _, _, _, _) => {
                h1427
            }
        }, Some(Adt41::C7), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1428, _, _, _, _, _, _, _, _, _) => {
                h1428
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1429, _, _, _, _, _, _, _, _) => {
                h1429
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1430, _, _, _, _, _, _, _) => {
                h1430
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1431, _, _, _, _, _, _) => {
                h1431
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1432, _, _, _, _, _) => {
                h1432
            }
        }, Adt49::C1, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1433, _, _) => {
                h1433
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1434, _) => {
                h1434
            }
        }, f48(v0.clone())), List::cons(Adt66::C4(f37(v0.clone())), List::cons(Adt66::C5(f37(v0)), List::<Adt66>::nil()))))
    } else {
        if match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1435, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1435
            }
        } {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1436, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1436
                }
            }, f78(match v0.clone() {
                Adt1::C0(_, h1437, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1437
                }
            })?, f67(match v0.clone() {
                Adt1::C0(_, _, h1438, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1438
                }
            }, Adt7::C3), match v0.clone() {
                Adt1::C0(_, _, _, h1439, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1439
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1440, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1440
                }
            }, None::<Adt22>, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1441, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1441
                }
            }, None::<Adt11>, false, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1442, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1442
                }
            }, Some(Adt41::C7), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1443, _, _, _, _, _, _, _, _, _) => {
                    h1443
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1444, _, _, _, _, _, _, _, _) => {
                    h1444
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1445, _, _, _, _, _, _, _) => {
                    h1445
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1446, _, _, _, _, _, _) => {
                    h1446
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1447, _, _, _, _, _) => {
                    h1447
                }
            }, Adt49::C1, false, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1448, _, _) => {
                    h1448
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1449, _) => {
                    h1449
                }
            }, f48(v0.clone())), f49(v0)))
        } else {
            Ok(Adt71::C0(v0, List::<Adt66>::nil()))
        }
    }
}

pub fn f59(v0: Adt1) -> R<Adt71> {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1450, _, _, _, _, _, _) => {
            h1450
        }
    } {
        Ok(Adt71::C0(v0, List::<Adt66>::nil()))
    } else {
        Ok(Adt71::C0({
            let m1453 = f57(v0.clone(), false, true, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1452, _, _, _, _, _) => {
                    h1452
                }
            })?;
            match m1453 {
                Adt71::C0(h1451, _) => {
                    h1451
                }
            }
        }, f40(f49(v0.clone()), List::cons(Adt66::C8(match v0 {
            Adt1::C0(h1454, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1454
            }
        }), List::<Adt66>::nil()))))
    }
}

pub fn f60(v0: Adt1, v1: Adt52) -> Adt71 {
    if f62(v0.clone(), v1) {
        let m1456 = f79(match v0.clone() {
            Adt1::C0(_, _, h1455, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1455
            }
        });
        match m1456 {
            Ok(v3) => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1477, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1477
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1478, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1478
                    }
                }, v3, match v0.clone() {
                    Adt1::C0(_, _, _, h1479, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1479
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1480, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1480
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1481, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1481
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1482, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1482
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1483, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1483
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1484, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1484
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1485, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1485
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1486, _, _, _, _, _, _, _, _, _, _) => {
                        h1486
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1487, _, _, _, _, _, _, _, _, _) => {
                        h1487
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1488, _, _, _, _, _, _, _, _) => {
                        h1488
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1489, _, _, _, _, _, _, _) => {
                        h1489
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1490, _, _, _, _, _, _) => {
                        h1490
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1491, _, _, _, _, _) => {
                        h1491
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1492, _, _, _, _) => {
                        h1492
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1493, _, _, _) => {
                        h1493
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1494, _, _) => {
                        h1494
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1495, _) => {
                        h1495
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1496) => {
                        h1496
                    }
                }), List::<Adt66>::nil())
            }
            Err(v2) => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1457, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1457
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1458, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1458
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1459, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1459
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1460, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1460
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1461, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1461
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1462, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1462
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1463, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1463
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1464, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1464
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1465, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1465
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1466, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1466
                    }
                }, Some(Adt41::C11(v2)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1467, _, _, _, _, _, _, _, _, _) => {
                        h1467
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1468, _, _, _, _, _, _, _, _) => {
                        h1468
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1469, _, _, _, _, _, _, _) => {
                        h1469
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1470, _, _, _, _, _, _) => {
                        h1470
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1471, _, _, _, _, _) => {
                        h1471
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1472, _, _, _, _) => {
                        h1472
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1473, _, _, _) => {
                        h1473
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1474, _, _) => {
                        h1474
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1475, _) => {
                        h1475
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1476) => {
                        h1476
                    }
                }), List::<Adt66>::nil())
            }
        }
    } else {
        Adt71::C0(v0, List::<Adt66>::nil())
    }
}

pub fn f61(v0: Adt1, v1: Adt52, v2: Adt67) -> R<Adt71> {
    if f62(v0.clone(), v1.clone()) {
        if f80(v0.clone(), v2.clone()) {
            let m1498 = f81(match v0.clone() {
                Adt1::C0(_, _, h1497, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1497
                }
            }, f82(v2.clone()));
            match m1498 {
                Adt76::C0(_, v5) => {
                    let m1520 = f83(match v0.clone() {
                        Adt1::C0(_, _, _, h1519, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1519
                        }
                    }, v2.clone())?;
                    match m1520 {
                        Ok(v7) => {
                            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                                Adt1::C0(h1541, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1541
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, h1542, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1542
                                }
                            }, v5, v7, match v0.clone() {
                                Adt1::C0(_, _, _, _, h1543, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1543
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h1544, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1544
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h1545, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1545
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, h1546, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1546
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, h1547, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1547
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, h1548, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1548
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1549, _, _, _, _, _, _, _, _, _, _) => {
                                    h1549
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1550, _, _, _, _, _, _, _, _, _) => {
                                    h1550
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1551, _, _, _, _, _, _, _, _) => {
                                    h1551
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1552, _, _, _, _, _, _, _) => {
                                    h1552
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1553, _, _, _, _, _, _) => {
                                    h1553
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1554, _, _, _, _, _) => {
                                    h1554
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1555, _, _, _, _) => {
                                    h1555
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1556, _, _, _) => {
                                    h1556
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1557, _, _) => {
                                    h1557
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1558, _) => {
                                    h1558
                                }
                            }, match v0 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1559) => {
                                    h1559
                                }
                            }), List::cons(Adt66::C1(v1, v2), List::<Adt66>::nil())))
                        }
                        Err(_) => {
                            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                                Adt1::C0(h1521, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1521
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, h1522, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1522
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, h1523, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1523
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, h1524, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1524
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, h1525, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1525
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, h1526, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1526
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, h1527, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1527
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, h1528, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1528
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, h1529, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1529
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, h1530, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h1530
                                }
                            }, Some(Adt41::C10(Adt43::C8)), match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1531, _, _, _, _, _, _, _, _, _) => {
                                    h1531
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1532, _, _, _, _, _, _, _, _) => {
                                    h1532
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1533, _, _, _, _, _, _, _) => {
                                    h1533
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1534, _, _, _, _, _, _) => {
                                    h1534
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1535, _, _, _, _, _) => {
                                    h1535
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1536, _, _, _, _) => {
                                    h1536
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1537, _, _, _) => {
                                    h1537
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1538, _, _) => {
                                    h1538
                                }
                            }, match v0.clone() {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1539, _) => {
                                    h1539
                                }
                            }, match v0 {
                                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1540) => {
                                    h1540
                                }
                            }), List::<Adt66>::nil()))
                        }
                    }
                }
                Adt76::C1(v3) => {
                    Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                        Adt1::C0(h1499, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1499
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, h1500, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1500
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, h1501, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1501
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, h1502, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1502
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, h1503, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1503
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, h1504, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1504
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, h1505, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1505
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h1506, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1506
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, h1507, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1507
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, h1508, _, _, _, _, _, _, _, _, _, _, _) => {
                            h1508
                        }
                    }, Some(Adt41::C11(v3)), match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1509, _, _, _, _, _, _, _, _, _) => {
                            h1509
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1510, _, _, _, _, _, _, _, _) => {
                            h1510
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1511, _, _, _, _, _, _, _) => {
                            h1511
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1512, _, _, _, _, _, _) => {
                            h1512
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1513, _, _, _, _, _) => {
                            h1513
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1514, _, _, _, _) => {
                            h1514
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1515, _, _, _) => {
                            h1515
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1516, _, _) => {
                            h1516
                        }
                    }, match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1517, _) => {
                            h1517
                        }
                    }, match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1518) => {
                            h1518
                        }
                    }), List::<Adt66>::nil()))
                }
            }
        } else {
            Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h1560, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1560
                }
            }, match v0.clone() {
                Adt1::C0(_, h1561, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1561
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h1562, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1562
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h1563, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1563
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h1564, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1564
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h1565, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1565
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h1566, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1566
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h1567, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1567
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h1568, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1568
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1569, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1569
                }
            }, Some(Adt41::C10(Adt43::C11)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1570, _, _, _, _, _, _, _, _, _) => {
                    h1570
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1571, _, _, _, _, _, _, _, _) => {
                    h1571
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1572, _, _, _, _, _, _, _) => {
                    h1572
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1573, _, _, _, _, _, _) => {
                    h1573
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1574, _, _, _, _, _) => {
                    h1574
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1575, _, _, _, _) => {
                    h1575
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1576, _, _, _) => {
                    h1576
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1577, _, _) => {
                    h1577
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1578, _) => {
                    h1578
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1579) => {
                    h1579
                }
            }), List::<Adt66>::nil()))
        }
    } else {
        Ok(Adt71::C0(v0, List::<Adt66>::nil()))
    }
}

pub fn f62(v0: Adt1, v1: Adt52) -> bool {
    let a1582 = match v0.clone() {
        Adt1::C0(h1580, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
            h1580
        }
    };
    let a1583 = match v1.clone() {
        Adt52::C0(h1581, _, _) => {
            h1581
        }
    };
    if nat_eq(a1582, a1583) {
        if match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1584, _, _, _, _, _, _, _) => {
                h1584
            }
        } {
            let a1586 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1585, _, _, _, _, _, _) => {
                    h1585
                }
            };
            if bool_not(a1586) {
                f84(match v0 {
                    Adt1::C0(_, h1587, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1587
                    }
                }, match v1.clone() {
                    Adt52::C0(_, h1588, _) => {
                        h1588
                    }
                }, match v1 {
                    Adt52::C0(_, _, h1589) => {
                        h1589
                    }
                })
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f63(v0: Option<Adt11>) -> List<Adt66> {
    let m1590 = v0;
    match m1590 {
        None => {
            List::<Adt66>::nil()
        }
        Some(v1) => {
            List::cons(Adt66::C6(v1), List::<Adt66>::nil())
        }
    }
}

pub fn f64(v0: Adt1, v1: Adt52, v2: Adt22) -> R<Adt71> {
    f85(v0.clone(), v1.clone(), v2, f62(v0, v1))
}

pub fn f65(v0: Adt1, v1: Adt52, v2: Adt73) -> Adt71 {
    if if f1(v0.clone(), v1.clone()) {
        match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1591, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1591
            }
        }
    } else {
        false
    } {
        Adt71::C0(Adt1::C0({
            let m1596 = {
                let m1595 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1594) => {
                        h1594
                    }
                });
                match m1595 {
                    Adt71::C0(h1593, _) => {
                        h1593
                    }
                }
            };
            match m1596 {
                Adt1::C0(h1592, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1592
                }
            }
        }, {
            let m1601 = {
                let m1600 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1599) => {
                        h1599
                    }
                });
                match m1600 {
                    Adt71::C0(h1598, _) => {
                        h1598
                    }
                }
            };
            match m1601 {
                Adt1::C0(_, h1597, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1597
                }
            }
        }, {
            let m1606 = {
                let m1605 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1604) => {
                        h1604
                    }
                });
                match m1605 {
                    Adt71::C0(h1603, _) => {
                        h1603
                    }
                }
            };
            match m1606 {
                Adt1::C0(_, _, h1602, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1602
                }
            }
        }, {
            let m1611 = {
                let m1610 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1609) => {
                        h1609
                    }
                });
                match m1610 {
                    Adt71::C0(h1608, _) => {
                        h1608
                    }
                }
            };
            match m1611 {
                Adt1::C0(_, _, _, h1607, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1607
                }
            }
        }, {
            let m1616 = {
                let m1615 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1614) => {
                        h1614
                    }
                });
                match m1615 {
                    Adt71::C0(h1613, _) => {
                        h1613
                    }
                }
            };
            match m1616 {
                Adt1::C0(_, _, _, _, h1612, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1612
                }
            }
        }, {
            let m1621 = {
                let m1620 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1619) => {
                        h1619
                    }
                });
                match m1620 {
                    Adt71::C0(h1618, _) => {
                        h1618
                    }
                }
            };
            match m1621 {
                Adt1::C0(_, _, _, _, _, h1617, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1617
                }
            }
        }, {
            let m1626 = {
                let m1625 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1624) => {
                        h1624
                    }
                });
                match m1625 {
                    Adt71::C0(h1623, _) => {
                        h1623
                    }
                }
            };
            match m1626 {
                Adt1::C0(_, _, _, _, _, _, h1622, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1622
                }
            }
        }, {
            let m1631 = {
                let m1630 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1629) => {
                        h1629
                    }
                });
                match m1630 {
                    Adt71::C0(h1628, _) => {
                        h1628
                    }
                }
            };
            match m1631 {
                Adt1::C0(_, _, _, _, _, _, _, h1627, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1627
                }
            }
        }, {
            let m1636 = {
                let m1635 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1634) => {
                        h1634
                    }
                });
                match m1635 {
                    Adt71::C0(h1633, _) => {
                        h1633
                    }
                }
            };
            match m1636 {
                Adt1::C0(_, _, _, _, _, _, _, _, h1632, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1632
                }
            }
        }, {
            let m1641 = {
                let m1640 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1639) => {
                        h1639
                    }
                });
                match m1640 {
                    Adt71::C0(h1638, _) => {
                        h1638
                    }
                }
            };
            match m1641 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h1637, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1637
                }
            }
        }, Some(match v2.clone() {
            Adt73::C0(h1642, _, _) => {
                h1642
            }
        }), {
            let m1647 = {
                let m1646 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1645) => {
                        h1645
                    }
                });
                match m1646 {
                    Adt71::C0(h1644, _) => {
                        h1644
                    }
                }
            };
            match m1647 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1643, _, _, _, _, _, _, _, _, _) => {
                    h1643
                }
            }
        }, {
            let m1652 = {
                let m1651 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1650) => {
                        h1650
                    }
                });
                match m1651 {
                    Adt71::C0(h1649, _) => {
                        h1649
                    }
                }
            };
            match m1652 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1648, _, _, _, _, _, _, _, _) => {
                    h1648
                }
            }
        }, {
            let m1657 = {
                let m1656 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1655) => {
                        h1655
                    }
                });
                match m1656 {
                    Adt71::C0(h1654, _) => {
                        h1654
                    }
                }
            };
            match m1657 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1653, _, _, _, _, _, _, _) => {
                    h1653
                }
            }
        }, {
            let m1662 = {
                let m1661 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1660) => {
                        h1660
                    }
                });
                match m1661 {
                    Adt71::C0(h1659, _) => {
                        h1659
                    }
                }
            };
            match m1662 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1658, _, _, _, _, _, _) => {
                    h1658
                }
            }
        }, {
            let m1667 = {
                let m1666 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1665) => {
                        h1665
                    }
                });
                match m1666 {
                    Adt71::C0(h1664, _) => {
                        h1664
                    }
                }
            };
            match m1667 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1663, _, _, _, _, _) => {
                    h1663
                }
            }
        }, {
            let m1672 = {
                let m1671 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1670) => {
                        h1670
                    }
                });
                match m1671 {
                    Adt71::C0(h1669, _) => {
                        h1669
                    }
                }
            };
            match m1672 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1668, _, _, _, _) => {
                    h1668
                }
            }
        }, {
            let m1677 = {
                let m1676 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1675) => {
                        h1675
                    }
                });
                match m1676 {
                    Adt71::C0(h1674, _) => {
                        h1674
                    }
                }
            };
            match m1677 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1673, _, _, _) => {
                    h1673
                }
            }
        }, {
            let m1682 = {
                let m1681 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1680) => {
                        h1680
                    }
                });
                match m1681 {
                    Adt71::C0(h1679, _) => {
                        h1679
                    }
                }
            };
            match m1682 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1678, _, _) => {
                    h1678
                }
            }
        }, Some(match v2.clone() {
            Adt73::C0(_, h1683, _) => {
                h1683
            }
        }), {
            let m1688 = {
                let m1687 = f69(v0.clone(), v1.clone(), match v2.clone() {
                    Adt73::C0(_, _, h1686) => {
                        h1686
                    }
                });
                match m1687 {
                    Adt71::C0(h1685, _) => {
                        h1685
                    }
                }
            };
            match m1688 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1684) => {
                    h1684
                }
            }
        }), {
            let m1691 = f69(v0, v1, match v2 {
                Adt73::C0(_, _, h1690) => {
                    h1690
                }
            });
            match m1691 {
                Adt71::C0(_, h1689) => {
                    h1689
                }
            }
        })
    } else {
        if f62(v0.clone(), v1.clone()) {
            Adt71::C0(Adt1::C0({
                let m1696 = {
                    let m1695 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1694, _, _) => {
                            h1694
                        }
                    });
                    match m1695 {
                        Adt71::C0(h1693, _) => {
                            h1693
                        }
                    }
                };
                match m1696 {
                    Adt1::C0(h1692, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1692
                    }
                }
            }, {
                let m1701 = {
                    let m1700 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1699, _, _) => {
                            h1699
                        }
                    });
                    match m1700 {
                        Adt71::C0(h1698, _) => {
                            h1698
                        }
                    }
                };
                match m1701 {
                    Adt1::C0(_, h1697, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1697
                    }
                }
            }, f67(match v0.clone() {
                Adt1::C0(_, _, h1702, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h1702
                }
            }, match v2.clone() {
                Adt73::C0(_, _, h1703) => {
                    h1703
                }
            }), {
                let m1708 = {
                    let m1707 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1706, _, _) => {
                            h1706
                        }
                    });
                    match m1707 {
                        Adt71::C0(h1705, _) => {
                            h1705
                        }
                    }
                };
                match m1708 {
                    Adt1::C0(_, _, _, h1704, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1704
                    }
                }
            }, {
                let m1713 = {
                    let m1712 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1711, _, _) => {
                            h1711
                        }
                    });
                    match m1712 {
                        Adt71::C0(h1710, _) => {
                            h1710
                        }
                    }
                };
                match m1713 {
                    Adt1::C0(_, _, _, _, h1709, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1709
                    }
                }
            }, {
                let m1718 = {
                    let m1717 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1716, _, _) => {
                            h1716
                        }
                    });
                    match m1717 {
                        Adt71::C0(h1715, _) => {
                            h1715
                        }
                    }
                };
                match m1718 {
                    Adt1::C0(_, _, _, _, _, h1714, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1714
                    }
                }
            }, {
                let m1723 = {
                    let m1722 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1721, _, _) => {
                            h1721
                        }
                    });
                    match m1722 {
                        Adt71::C0(h1720, _) => {
                            h1720
                        }
                    }
                };
                match m1723 {
                    Adt1::C0(_, _, _, _, _, _, h1719, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1719
                    }
                }
            }, {
                let m1728 = {
                    let m1727 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1726, _, _) => {
                            h1726
                        }
                    });
                    match m1727 {
                        Adt71::C0(h1725, _) => {
                            h1725
                        }
                    }
                };
                match m1728 {
                    Adt1::C0(_, _, _, _, _, _, _, h1724, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1724
                    }
                }
            }, {
                let m1733 = {
                    let m1732 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1731, _, _) => {
                            h1731
                        }
                    });
                    match m1732 {
                        Adt71::C0(h1730, _) => {
                            h1730
                        }
                    }
                };
                match m1733 {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1729, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1729
                    }
                }
            }, {
                let m1738 = {
                    let m1737 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1736, _, _) => {
                            h1736
                        }
                    });
                    match m1737 {
                        Adt71::C0(h1735, _) => {
                            h1735
                        }
                    }
                };
                match m1738 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1734, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1734
                    }
                }
            }, {
                let m1743 = {
                    let m1742 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1741, _, _) => {
                            h1741
                        }
                    });
                    match m1742 {
                        Adt71::C0(h1740, _) => {
                            h1740
                        }
                    }
                };
                match m1743 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1739, _, _, _, _, _, _, _, _, _, _) => {
                        h1739
                    }
                }
            }, {
                let m1748 = {
                    let m1747 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1746, _, _) => {
                            h1746
                        }
                    });
                    match m1747 {
                        Adt71::C0(h1745, _) => {
                            h1745
                        }
                    }
                };
                match m1748 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1744, _, _, _, _, _, _, _, _, _) => {
                        h1744
                    }
                }
            }, {
                let m1753 = {
                    let m1752 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1751, _, _) => {
                            h1751
                        }
                    });
                    match m1752 {
                        Adt71::C0(h1750, _) => {
                            h1750
                        }
                    }
                };
                match m1753 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1749, _, _, _, _, _, _, _, _) => {
                        h1749
                    }
                }
            }, {
                let m1758 = {
                    let m1757 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1756, _, _) => {
                            h1756
                        }
                    });
                    match m1757 {
                        Adt71::C0(h1755, _) => {
                            h1755
                        }
                    }
                };
                match m1758 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1754, _, _, _, _, _, _, _) => {
                        h1754
                    }
                }
            }, {
                let m1763 = {
                    let m1762 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1761, _, _) => {
                            h1761
                        }
                    });
                    match m1762 {
                        Adt71::C0(h1760, _) => {
                            h1760
                        }
                    }
                };
                match m1763 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1759, _, _, _, _, _, _) => {
                        h1759
                    }
                }
            }, {
                let m1768 = {
                    let m1767 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1766, _, _) => {
                            h1766
                        }
                    });
                    match m1767 {
                        Adt71::C0(h1765, _) => {
                            h1765
                        }
                    }
                };
                match m1768 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1764, _, _, _, _, _) => {
                        h1764
                    }
                }
            }, {
                let m1773 = {
                    let m1772 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1771, _, _) => {
                            h1771
                        }
                    });
                    match m1772 {
                        Adt71::C0(h1770, _) => {
                            h1770
                        }
                    }
                };
                match m1773 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1769, _, _, _, _) => {
                        h1769
                    }
                }
            }, {
                let m1778 = {
                    let m1777 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1776, _, _) => {
                            h1776
                        }
                    });
                    match m1777 {
                        Adt71::C0(h1775, _) => {
                            h1775
                        }
                    }
                };
                match m1778 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1774, _, _, _) => {
                        h1774
                    }
                }
            }, {
                let m1783 = {
                    let m1782 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1781, _, _) => {
                            h1781
                        }
                    });
                    match m1782 {
                        Adt71::C0(h1780, _) => {
                            h1780
                        }
                    }
                };
                match m1783 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1779, _, _) => {
                        h1779
                    }
                }
            }, Some(match v2.clone() {
                Adt73::C0(_, h1784, _) => {
                    h1784
                }
            }), {
                let m1789 = {
                    let m1788 = f86(v0.clone(), v1.clone(), match v2.clone() {
                        Adt73::C0(h1787, _, _) => {
                            h1787
                        }
                    });
                    match m1788 {
                        Adt71::C0(h1786, _) => {
                            h1786
                        }
                    }
                };
                match m1789 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1785) => {
                        h1785
                    }
                }
            }), {
                let m1792 = f86(v0, v1, match v2 {
                    Adt73::C0(h1791, _, _) => {
                        h1791
                    }
                });
                match m1792 {
                    Adt71::C0(_, h1790) => {
                        h1790
                    }
                }
            })
        } else {
            Adt71::C0(v0, List::<Adt66>::nil())
        }
    }
}

pub fn f66(v0: Adt2) -> Adt2 {
    if match v0.clone() {
        Adt2::C0(_, _, h1793, _, _, _) => {
            h1793
        }
    } {
        Adt2::C0(match v0.clone() {
            Adt2::C0(h1794, _, _, _, _, _) => {
                h1794
            }
        }, match v0 {
            Adt2::C0(_, h1795, _, _, _, _) => {
                h1795
            }
        }, false, false, Adt3::C5, Adt4::C0)
    } else {
        v0
    }
}

pub fn f67(v0: Adt5, v1: Adt7) -> Adt5 {
    Adt5::C0(Adt6::C4, match v0.clone() {
        Adt5::C0(_, h1796, _, _, _) => {
            h1796
        }
    }, match v0 {
        Adt5::C0(_, _, h1797, _, _) => {
            h1797
        }
    }, false, v1)
}

pub fn f68(v0: Adt1) -> Adt71 {
    if f87(v0.clone()) {
        let m1799 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1798, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1798
            }
        };
        match m1799 {
            None => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1800, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1800
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1801, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1801
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1802, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1802
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1803, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1803
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1804, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1804
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1805, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1805
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1806, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1806
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1807, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1807
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1808, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1808
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1809, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1809
                    }
                }, Some(Adt41::C10(Adt43::C5)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1810, _, _, _, _, _, _, _, _, _) => {
                        h1810
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1811, _, _, _, _, _, _, _, _) => {
                        h1811
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1812, _, _, _, _, _, _, _) => {
                        h1812
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1813, _, _, _, _, _, _) => {
                        h1813
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1814, _, _, _, _, _) => {
                        h1814
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1815, _, _, _, _) => {
                        h1815
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1816, _, _, _) => {
                        h1816
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1817, _, _) => {
                        h1817
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1818, _) => {
                        h1818
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1819) => {
                        h1819
                    }
                }), List::<Adt66>::nil())
            }
            Some(v1) => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1820, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1820
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1821, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1821
                    }
                }, f88(match v0.clone() {
                    Adt1::C0(_, _, h1822, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1822
                    }
                }), match v0.clone() {
                    Adt1::C0(_, _, _, h1823, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1823
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1824, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1824
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1825, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1825
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1826, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1826
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1827, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1827
                    }
                }, true, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1828, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1828
                    }
                }, None::<Adt41>, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1829, _, _, _, _, _, _, _, _, _) => {
                        h1829
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1830, _, _, _, _, _, _, _, _) => {
                        h1830
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1831, _, _, _, _, _, _, _) => {
                        h1831
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1832, _, _, _, _, _, _) => {
                        h1832
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1833, _, _, _, _, _) => {
                        h1833
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1834, _, _, _, _) => {
                        h1834
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1835, _, _, _) => {
                        h1835
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1836, _, _) => {
                        h1836
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1837, _) => {
                        h1837
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1838) => {
                        h1838
                    }
                }), List::cons(Adt66::C7(f37(v0), v1), List::<Adt66>::nil()))
            }
        }
    } else {
        Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h1839, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1839
            }
        }, match v0.clone() {
            Adt1::C0(_, h1840, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1840
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h1841, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1841
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h1842, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1842
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h1843, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1843
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h1844, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1844
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h1845, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1845
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h1846, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1846
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1847, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1847
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h1848, _, _, _, _, _, _, _, _, _, _, _) => {
                h1848
            }
        }, Some(Adt41::C10(Adt43::C5)), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1849, _, _, _, _, _, _, _, _, _) => {
                h1849
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1850, _, _, _, _, _, _, _, _) => {
                h1850
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1851, _, _, _, _, _, _, _) => {
                h1851
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1852, _, _, _, _, _, _) => {
                h1852
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1853, _, _, _, _, _) => {
                h1853
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1854, _, _, _, _) => {
                h1854
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1855, _, _, _) => {
                h1855
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1856, _, _) => {
                h1856
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1857, _) => {
                h1857
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1858) => {
                h1858
            }
        }), List::<Adt66>::nil())
    }
}

pub fn f69(v0: Adt1, v1: Adt52, v2: Adt7) -> Adt71 {
    if if f1(v0.clone(), v1) {
        match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h1859, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1859
            }
        }
    } else {
        false
    } {
        let m1861 = f89(match v0.clone() {
            Adt1::C0(_, _, h1860, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1860
            }
        }, v2.clone());
        match m1861 {
            Ok(v4) => {
                let m1882 = v2.clone();
                match m1882 {
                    Adt7::C0 => {
                        Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1883, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1883
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1884, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1884
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, h1885, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1885
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, h1886, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1886
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1887, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1887
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1888, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1888
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1889, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1889
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1890, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1890
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h1891, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1891
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1892, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1892
                            }
                        }, Some(Adt41::C10(Adt43::C13)), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1893, _, _, _, _, _, _, _, _, _) => {
                                h1893
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1894, _, _, _, _, _, _, _, _) => {
                                h1894
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1895, _, _, _, _, _, _, _) => {
                                h1895
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1896, _, _, _, _, _, _) => {
                                h1896
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1897, _, _, _, _, _) => {
                                h1897
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1898, _, _, _, _) => {
                                h1898
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1899, _, _, _) => {
                                h1899
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1900, _, _) => {
                                h1900
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1901, _) => {
                                h1901
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1902) => {
                                h1902
                            }
                        }), List::<Adt66>::nil())
                    }
                    Adt7::C1 => {
                        Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1903, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1903
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1904, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1904
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1905, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1905
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1906, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1906
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1907, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1907
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1908, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1908
                            }
                        }, None::<Adt11>, false, true, None::<Adt41>, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1909, _, _, _, _, _, _, _, _, _) => {
                                h1909
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1910, _, _, _, _, _, _, _, _) => {
                                h1910
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1911, _, _, _, _, _, _, _) => {
                                h1911
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1912, _, _, _, _, _, _) => {
                                h1912
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1913, _, _, _, _, _) => {
                                h1913
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1914, _, _, _, _) => {
                                h1914
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1915, _, _, _) => {
                                h1915
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1916, _, _) => {
                                h1916
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1917, _) => {
                                h1917
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1918) => {
                                h1918
                            }
                        }), List::<Adt66>::nil())
                    }
                    Adt7::C2 => {
                        Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1919, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1919
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1920, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1920
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1921, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1921
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1922, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1922
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1923, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1923
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1924, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1924
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1925, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1925
                            }
                        }, false, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1926, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1926
                            }
                        }, Some(Adt41::C9(v2, Str::lit("Output was not published; the staged result is retained."))), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1927, _, _, _, _, _, _, _, _, _) => {
                                h1927
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1928, _, _, _, _, _, _, _, _) => {
                                h1928
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1929, _, _, _, _, _, _, _) => {
                                h1929
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1930, _, _, _, _, _, _) => {
                                h1930
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1931, _, _, _, _, _) => {
                                h1931
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1932, _, _, _, _) => {
                                h1932
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1933, _, _, _) => {
                                h1933
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1934, _, _) => {
                                h1934
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1935, _) => {
                                h1935
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1936) => {
                                h1936
                            }
                        }), List::<Adt66>::nil())
                    }
                    Adt7::C3 => {
                        Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1937, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1937
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1938, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1938
                            }
                        }, v4, match v0.clone() {
                            Adt1::C0(_, _, _, h1939, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1939
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1940, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1940
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1941, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1941
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1942, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1942
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1943, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1943
                            }
                        }, false, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1944, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1944
                            }
                        }, Some(Adt41::C9(v2, Str::lit("Publication outcome is unknown; reconcile with the destination before retrying."))), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1945, _, _, _, _, _, _, _, _, _) => {
                                h1945
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1946, _, _, _, _, _, _, _, _) => {
                                h1946
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1947, _, _, _, _, _, _, _) => {
                                h1947
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1948, _, _, _, _, _, _) => {
                                h1948
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1949, _, _, _, _, _) => {
                                h1949
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1950, _, _, _, _) => {
                                h1950
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1951, _, _, _) => {
                                h1951
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1952, _, _) => {
                                h1952
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1953, _) => {
                                h1953
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1954) => {
                                h1954
                            }
                        }), List::<Adt66>::nil())
                    }
                }
            }
            Err(v3) => {
                Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1862, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1862
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1863, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1863
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1864, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1864
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1865, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1865
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1866, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1866
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1867, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1867
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1868, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1868
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1869, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1869
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1870, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1870
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1871, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1871
                    }
                }, Some(Adt41::C11(v3)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1872, _, _, _, _, _, _, _, _, _) => {
                        h1872
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1873, _, _, _, _, _, _, _, _) => {
                        h1873
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1874, _, _, _, _, _, _, _) => {
                        h1874
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1875, _, _, _, _, _, _) => {
                        h1875
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1876, _, _, _, _, _) => {
                        h1876
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1877, _, _, _, _) => {
                        h1877
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1878, _, _, _) => {
                        h1878
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1879, _, _) => {
                        h1879
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1880, _) => {
                        h1880
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1881) => {
                        h1881
                    }
                }), List::<Adt66>::nil())
            }
        }
    } else {
        Adt71::C0(v0, List::<Adt66>::nil())
    }
}

pub fn f70(v0: Adt1, v1: Adt52, v2: u64) -> R<Adt71> {
    if f62(v0.clone(), v1.clone()) {
        let m1956 = match v0.clone() {
            Adt1::C0(_, _, _, _, h1955, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h1955
            }
        };
        match m1956 {
            None => {
                Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                    Adt1::C0(h1957, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1957
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h1958, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1958
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h1959, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1959
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h1960, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1960
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h1961, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1961
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h1962, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1962
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h1963, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1963
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h1964, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1964
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h1965, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1965
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h1966, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1966
                    }
                }, Some(Adt41::C10(Adt43::C3)), match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1967, _, _, _, _, _, _, _, _, _) => {
                        h1967
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h1968, _, _, _, _, _, _, _, _) => {
                        h1968
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h1969, _, _, _, _, _, _, _) => {
                        h1969
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h1970, _, _, _, _, _, _) => {
                        h1970
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1971, _, _, _, _, _) => {
                        h1971
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1972, _, _, _, _) => {
                        h1972
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1973, _, _, _) => {
                        h1973
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1974, _, _) => {
                        h1974
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1975, _) => {
                        h1975
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h1976) => {
                        h1976
                    }
                }), List::<Adt66>::nil()))
            }
            Some(v3) => {
                let m1988 = f90(match v0.clone() {
                    Adt1::C0(_, _, h1977, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h1977
                    }
                }, v2, {
                    let m1982 = {
                        let m1981 = {
                            let m1980 = f76(v3);
                            match m1980 {
                                Adt12::C0(h1979, _) => {
                                    h1979
                                }
                            }
                        };
                        match m1981 {
                            Adt13::C0(_, _, _, _, h1978, _, _) => {
                                h1978
                            }
                        }
                    };
                    match m1982 {
                        None => {
                            let a1986 = {
                                let m1985 = match v0.clone() {
                                    Adt1::C0(_, _, h1984, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                        h1984
                                    }
                                };
                                match m1985 {
                                    Adt5::C0(_, _, h1983, _, _) => {
                                        h1983
                                    }
                                }
                            };
                            let a1987 = v2;
                            nat_add(a1986, a1987)?
                        }
                        Some(v4) => {
                            v4
                        }
                    }
                })?;
                match m1988 {
                    Ok(v6) => {
                        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h1989, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1989
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, h1990, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1990
                            }
                        }, v6, match v0.clone() {
                            Adt1::C0(_, _, _, h1991, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1991
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h1992, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1992
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, h1993, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1993
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h1994, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1994
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, h1995, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1995
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h1996, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1996
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h1997, _, _, _, _, _, _, _, _, _, _, _) => {
                                h1997
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h1998, _, _, _, _, _, _, _, _, _, _) => {
                                h1998
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h1999, _, _, _, _, _, _, _, _, _) => {
                                h1999
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2000, _, _, _, _, _, _, _, _) => {
                                h2000
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2001, _, _, _, _, _, _, _) => {
                                h2001
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2002, _, _, _, _, _, _) => {
                                h2002
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2003, _, _, _, _, _) => {
                                h2003
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2004, _, _, _, _) => {
                                h2004
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2005, _, _, _) => {
                                h2005
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2006, _, _) => {
                                h2006
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2007, _) => {
                                h2007
                            }
                        }, match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2008) => {
                                h2008
                            }
                        }), List::<Adt66>::nil()))
                    }
                    Err(v5) => {
                        Ok(f86(v0, v1, Adt41::C11(v5)))
                    }
                }
            }
        }
    } else {
        Ok(Adt71::C0(v0, List::<Adt66>::nil()))
    }
}

pub fn f71(v0: Adt1, v1: Adt52, v2: Adt74) -> R<Adt71> {
    if f1(v0.clone(), v1.clone()) {
        let m2010 = match v0.clone() {
            Adt1::C0(_, _, _, _, h2009, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2009
            }
        };
        match m2010 {
            None => {
                Ok(Adt71::C0(v0, List::<Adt66>::nil()))
            }
            Some(v3) => {
                Ok(f91(Adt1::C0(match v0.clone() {
                    Adt1::C0(h2011, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2011
                    }
                }, match v0.clone() {
                    Adt1::C0(_, h2012, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2012
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, h2013, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2013
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, h2014, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2014
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, h2015, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2015
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, h2016, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2016
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, h2017, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2017
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, h2018, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2018
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, h2019, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2019
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, h2020, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2020
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, h2021, _, _, _, _, _, _, _, _, _, _) => {
                        h2021
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2022, _, _, _, _, _, _, _, _, _) => {
                        h2022
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2023, _, _, _, _, _, _, _, _) => {
                        h2023
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2024, _, _, _, _, _, _, _) => {
                        h2024
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2025, _, _, _, _, _, _) => {
                        h2025
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2026, _, _, _, _, _) => {
                        h2026
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2027, _, _, _, _) => {
                        h2027
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2028, _, _, _) => {
                        h2028
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2029, _, _) => {
                        h2029
                    }
                }, match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2030, _) => {
                        h2030
                    }
                }, f72(match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2031) => {
                        h2031
                    }
                }, v1, v2.clone())?), f92({
                    let m2035 = {
                        let m2034 = f76(v3);
                        match m2034 {
                            Adt12::C0(h2033, _) => {
                                h2033
                            }
                        }
                    };
                    match m2035 {
                        Adt13::C0(_, _, _, _, _, _, h2032) => {
                            h2032
                        }
                    }
                }, match v0 {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2036, _, _) => {
                        h2036
                    }
                }, v2)?))
            }
        }
    } else {
        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h2037, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2037
            }
        }, match v0.clone() {
            Adt1::C0(_, h2038, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2038
            }
        }, match v0.clone() {
            Adt1::C0(_, _, h2039, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2039
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, h2040, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2040
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h2041, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2041
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h2042, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2042
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h2043, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2043
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, h2044, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2044
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, h2045, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2045
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h2046, _, _, _, _, _, _, _, _, _, _, _) => {
                h2046
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, h2047, _, _, _, _, _, _, _, _, _, _) => {
                h2047
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2048, _, _, _, _, _, _, _, _, _) => {
                h2048
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2049, _, _, _, _, _, _, _, _) => {
                h2049
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2050, _, _, _, _, _, _, _) => {
                h2050
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2051, _, _, _, _, _, _) => {
                h2051
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2052, _, _, _, _, _) => {
                h2052
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2053, _, _, _, _) => {
                h2053
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2054, _, _, _) => {
                h2054
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2055, _, _) => {
                h2055
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2056, _) => {
                h2056
            }
        }, f72(match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2057) => {
                h2057
            }
        }, v1, v2)?), List::<Adt66>::nil()))
    }
}

pub fn f72(v0: List<Adt51>, v1: Adt52, v2: Adt74) -> R<List<Adt51>> {
    let m2058 = v0;
    match m2058.uncons() {
        None => {
            Ok(List::<Adt51>::nil())
        }
        Some((v3, v4)) => {
            Ok(List::cons(if f93(match v3.clone() {
                Adt51::C0(h2059, _, _, _) => {
                    h2059
                }
            }, v1.clone()) {
                Adt51::C0(match v3.clone() {
                    Adt51::C0(h2060, _, _, _) => {
                        h2060
                    }
                }, match v3.clone() {
                    Adt51::C0(_, h2061, _, _) => {
                        h2061
                    }
                }, f92(match v3.clone() {
                    Adt51::C0(_, h2062, _, _) => {
                        h2062
                    }
                }, match v3.clone() {
                    Adt51::C0(_, _, h2063, _) => {
                        h2063
                    }
                }, v2.clone())?, match v3 {
                    Adt51::C0(_, _, _, h2064) => {
                        h2064
                    }
                })
            } else {
                v3
            }, f72(v4, v1, v2)?))
        }
    }
}

pub fn f73(v0: List<Adt51>, v1: Adt52) -> R<List<Adt51>> {
    let m2065 = v0;
    match m2065.uncons() {
        None => {
            Ok(List::<Adt51>::nil())
        }
        Some((v2, v3)) => {
            if if f93(match v2.clone() {
                Adt51::C0(h2066, _, _, _) => {
                    h2066
                }
            }, v1.clone()) {
                let a2070 = f94({
                    let m2069 = match v2.clone() {
                        Adt51::C0(_, _, h2068, _) => {
                            h2068
                        }
                    };
                    match m2069 {
                        Adt50::C0(h2067, _) => {
                            h2067
                        }
                    }
                })?;
                let a2071 = 0u64;
                if nat_eq(a2070, a2071) {
                    let a2075 = f95({
                        let m2074 = match v2.clone() {
                            Adt51::C0(_, _, h2073, _) => {
                                h2073
                            }
                        };
                        match m2074 {
                            Adt50::C0(h2072, _) => {
                                h2072
                            }
                        }
                    })?;
                    let a2076 = 0u64;
                    nat_eq(a2075, a2076)
                } else {
                    false
                }
            } else {
                false
            } {
                Ok(v3)
            } else {
                Ok(List::cons(v2, f73(v3, v1)?))
            }
        }
    }
}

pub fn f74() -> Adt24 {
    Adt24::C0(f96(), f96(), 0u64, 0u64)
}

pub fn f75() -> Adt14 {
    Adt14::C0(None::<u64>, None::<u64>, None::<u64>, None::<u64>, None::<u64>)
}

pub fn f76(v0: Adt9) -> Adt12 {
    let m2077 = v0;
    match m2077 {
        Adt9::C0(v1) => {
            match v1 {
                Adt10::C0(_, h2078) => {
                    h2078
                }
            }
        }
        Adt9::C1(v2) => {
            match v2 {
                Adt15::C0(_, h2079) => {
                    h2079
                }
            }
        }
        Adt9::C2(v3) => {
            match v3 {
                Adt15::C0(_, h2080) => {
                    h2080
                }
            }
        }
        Adt9::C3(v4) => {
            match v4 {
                Adt16::C0(_, _, _, h2081) => {
                    h2081
                }
            }
        }
        Adt9::C4(v5) => {
            match v5 {
                Adt17::C0(_, _, h2082) => {
                    h2082
                }
            }
        }
        Adt9::C5(v6) => {
            match v6 {
                Adt18::C0(_, h2083) => {
                    h2083
                }
            }
        }
        Adt9::C6(v7) => {
            match v7 {
                Adt19::C0(_, _, h2084) => {
                    h2084
                }
            }
        }
        Adt9::C7(v8) => {
            match v8 {
                Adt20::C0(_, _, _, h2085) => {
                    h2085
                }
            }
        }
        Adt9::C8(v9) => {
            match v9 {
                Adt21::C0(_, h2086) => {
                    h2086
                }
            }
        }
        Adt9::C9(v10) => {
            match v10 {
                Adt21::C0(_, h2087) => {
                    h2087
                }
            }
        }
    }
}

pub fn f77(v0: Adt53) -> List<Adt66> {
    f40(f63(match v0.clone() {
        Adt53::C0(_, h2088, _, _, _, _, _, _) => {
            h2088
        }
    }), f40(f63(match v0.clone() {
        Adt53::C0(_, _, h2089, _, _, _, _, _) => {
            h2089
        }
    }), f40(f63(match v0.clone() {
        Adt53::C0(_, _, _, h2090, _, _, _, _) => {
            h2090
        }
    }), f40(f63(match v0.clone() {
        Adt53::C0(_, _, _, _, h2091, _, _, _) => {
            h2091
        }
    }), f40(f63(match v0.clone() {
        Adt53::C0(_, _, _, _, _, h2092, _, _) => {
            h2092
        }
    }), f40(f63(match v0 {
        Adt53::C0(_, _, _, _, _, _, h2093, _) => {
            h2093
        }
    }), List::<Adt66>::nil()))))))
}

pub fn f78(v0: Adt2) -> R<Adt2> {
    Ok(Adt2::C0({
        let a2095 = match v0.clone() {
            Adt2::C0(h2094, _, _, _, _, _) => {
                h2094
            }
        };
        let a2096 = 1u64;
        nat_add(a2095, a2096)?
    }, match v0 {
        Adt2::C0(_, h2097, _, _, _, _) => {
            h2097
        }
    }, false, false, Adt3::C0, Adt4::C0))
}

pub fn f79(v0: Adt5) -> Result<Adt5, Adt44> {
    let m2099 = match v0.clone() {
        Adt5::C0(h2098, _, _, _, _) => {
            h2098
        }
    };
    match m2099 {
        Adt6::C0 => {
            if match v0.clone() {
                Adt5::C0(_, h2100, _, _, _) => {
                    h2100
                }
            } {
                Err::<Adt5, Adt44>(Adt44::C1)
            } else {
                Ok::<Adt5, Adt44>(Adt5::C0(Adt6::C1, match v0.clone() {
                    Adt5::C0(_, h2101, _, _, _) => {
                        h2101
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2102, _, _) => {
                        h2102
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, _, h2103, _) => {
                        h2103
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, _, h2104) => {
                        h2104
                    }
                }))
            }
        }
        Adt6::C1 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C2 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C3 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C4 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
    }
}

pub fn f80(v0: Adt1, v1: Adt67) -> bool {
    let m2105 = v1;
    match m2105 {
        Adt67::C0(_) => {
            true
        }
        Adt67::C1(v3) => {
            let a2110 = {
                let m2108 = match v3 {
                    Adt68::C0(h2107, _, _) => {
                        h2107
                    }
                };
                match m2108 {
                    Adt11::C0(h2106, _, _) => {
                        h2106
                    }
                }
            };
            let a2111 = match v0 {
                Adt1::C0(h2109, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2109
                }
            };
            nat_eq(a2110, a2111)
        }
        Adt67::C2(_) => {
            true
        }
        Adt67::C3 => {
            true
        }
    }
}

pub fn f81(v0: Adt5, v1: Adt75) -> Adt76 {
    let m2112 = v1;
    match m2112 {
        Adt75::C0 => {
            let m2114 = match v0.clone() {
                Adt5::C0(h2113, _, _, _, _) => {
                    h2113
                }
            };
            match m2114 {
                Adt6::C0 => {
                    Adt76::C0(Adt77::C0, v0)
                }
                Adt6::C1 => {
                    Adt76::C1(Adt44::C2)
                }
                Adt6::C2 => {
                    Adt76::C1(Adt44::C2)
                }
                Adt6::C3 => {
                    Adt76::C1(Adt44::C2)
                }
                Adt6::C4 => {
                    Adt76::C1(Adt44::C2)
                }
            }
        }
        Adt75::C1 => {
            let m2116 = match v0.clone() {
                Adt5::C0(h2115, _, _, _, _) => {
                    h2115
                }
            };
            match m2116 {
                Adt6::C0 => {
                    Adt76::C1(Adt44::C0)
                }
                Adt6::C1 => {
                    if match v0.clone() {
                        Adt5::C0(_, h2117, _, _, _) => {
                            h2117
                        }
                    } {
                        Adt76::C1(Adt44::C1)
                    } else {
                        Adt76::C0(Adt77::C1, Adt5::C0(Adt6::C0, match v0.clone() {
                            Adt5::C0(_, h2118, _, _, _) => {
                                h2118
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, h2119, _, _) => {
                                h2119
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, _, h2120, _) => {
                                h2120
                            }
                        }, match v0 {
                            Adt5::C0(_, _, _, _, h2121) => {
                                h2121
                            }
                        }))
                    }
                }
                Adt6::C2 => {
                    Adt76::C1(Adt44::C0)
                }
                Adt6::C3 => {
                    Adt76::C1(Adt44::C0)
                }
                Adt6::C4 => {
                    Adt76::C1(Adt44::C0)
                }
            }
        }
        Adt75::C2 => {
            let m2123 = match v0.clone() {
                Adt5::C0(h2122, _, _, _, _) => {
                    h2122
                }
            };
            match m2123 {
                Adt6::C0 => {
                    Adt76::C1(Adt44::C0)
                }
                Adt6::C1 => {
                    if match v0.clone() {
                        Adt5::C0(_, h2124, _, _, _) => {
                            h2124
                        }
                    } {
                        Adt76::C1(Adt44::C1)
                    } else {
                        Adt76::C0(Adt77::C2, Adt5::C0(Adt6::C0, true, match v0.clone() {
                            Adt5::C0(_, _, h2125, _, _) => {
                                h2125
                            }
                        }, match v0.clone() {
                            Adt5::C0(_, _, _, h2126, _) => {
                                h2126
                            }
                        }, match v0 {
                            Adt5::C0(_, _, _, _, h2127) => {
                                h2127
                            }
                        }))
                    }
                }
                Adt6::C2 => {
                    Adt76::C1(Adt44::C0)
                }
                Adt6::C3 => {
                    Adt76::C1(Adt44::C0)
                }
                Adt6::C4 => {
                    Adt76::C1(Adt44::C0)
                }
            }
        }
        Adt75::C3 => {
            let m2129 = match v0.clone() {
                Adt5::C0(h2128, _, _, _, _) => {
                    h2128
                }
            };
            match m2129 {
                Adt6::C0 => {
                    Adt76::C0(Adt77::C3, Adt5::C0(Adt6::C3, match v0.clone() {
                        Adt5::C0(_, h2130, _, _, _) => {
                            h2130
                        }
                    }, match v0 {
                        Adt5::C0(_, _, h2131, _, _) => {
                            h2131
                        }
                    }, false, Adt7::C2))
                }
                Adt6::C1 => {
                    Adt76::C0(Adt77::C3, Adt5::C0(Adt6::C3, match v0.clone() {
                        Adt5::C0(_, h2132, _, _, _) => {
                            h2132
                        }
                    }, match v0 {
                        Adt5::C0(_, _, h2133, _, _) => {
                            h2133
                        }
                    }, false, Adt7::C2))
                }
                Adt6::C2 => {
                    Adt76::C0(Adt77::C4, v0)
                }
                Adt6::C3 => {
                    Adt76::C0(Adt77::C4, v0)
                }
                Adt6::C4 => {
                    Adt76::C0(Adt77::C4, v0)
                }
            }
        }
    }
}

pub fn f82(v0: Adt67) -> Adt75 {
    let m2134 = v0;
    match m2134 {
        Adt67::C0(_) => {
            Adt75::C1
        }
        Adt67::C1(_) => {
            Adt75::C1
        }
        Adt67::C2(_) => {
            Adt75::C1
        }
        Adt67::C3 => {
            Adt75::C2
        }
    }
}

pub fn f83(v0: Adt8, v1: Adt67) -> R<Result<Adt8, Adt78>> {
    if match v0.clone() {
        Adt8::C0(_, _, h2135, _) => {
            h2135
        }
    } {
        Ok(Err::<Adt8, Adt78>(Adt78::C0))
    } else {
        let m2136 = v1;
        match m2136 {
            Adt67::C0(v2) => {
                if match v0.clone() {
                    Adt8::C0(_, h2137, _, _) => {
                        h2137
                    }
                } {
                    Ok(Err::<Adt8, Adt78>(Adt78::C1))
                } else {
                    let a2139 = v2;
                    let a2140 = match v0.clone() {
                        Adt8::C0(h2138, _, _, _) => {
                            h2138
                        }
                    };
                    if nat_eq(a2139, a2140) {
                        Ok(Ok::<Adt8, Adt78>(Adt8::C0(match v0.clone() {
                            Adt8::C0(h2141, _, _, _) => {
                                h2141
                            }
                        }, true, match v0.clone() {
                            Adt8::C0(_, _, h2142, _) => {
                                h2142
                            }
                        }, match v0 {
                            Adt8::C0(_, _, _, h2143) => {
                                h2143
                            }
                        })))
                    } else {
                        Ok(Err::<Adt8, Adt78>(Adt78::C3))
                    }
                }
            }
            Adt67::C1(v3) => {
                if match v0.clone() {
                    Adt8::C0(_, h2144, _, _) => {
                        h2144
                    }
                } {
                    Ok(Ok::<Adt8, Adt78>(Adt8::C0(match v0.clone() {
                        Adt8::C0(h2145, _, _, _) => {
                            h2145
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, h2146, _, _) => {
                            h2146
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, _, h2147, _) => {
                            h2147
                        }
                    }, {
                        let a2150 = match v0 {
                            Adt8::C0(_, _, _, h2148) => {
                                h2148
                            }
                        };
                        let a2151 = match v3 {
                            Adt68::C0(_, _, h2149) => {
                                h2149
                            }
                        };
                        nat_add(a2150, a2151)?
                    })))
                } else {
                    Ok(Err::<Adt8, Adt78>(Adt78::C2))
                }
            }
            Adt67::C2(v4) => {
                if match v0.clone() {
                    Adt8::C0(_, h2152, _, _) => {
                        h2152
                    }
                } {
                    let a2154 = v4;
                    let a2155 = match v0.clone() {
                        Adt8::C0(h2153, _, _, _) => {
                            h2153
                        }
                    };
                    if nat_eq(a2154, a2155) {
                        Ok(Ok::<Adt8, Adt78>(Adt8::C0({
                            let a2157 = match v0.clone() {
                                Adt8::C0(h2156, _, _, _) => {
                                    h2156
                                }
                            };
                            let a2158 = 1u64;
                            nat_add(a2157, a2158)?
                        }, false, match v0.clone() {
                            Adt8::C0(_, _, h2159, _) => {
                                h2159
                            }
                        }, match v0 {
                            Adt8::C0(_, _, _, h2160) => {
                                h2160
                            }
                        })))
                    } else {
                        Ok(Err::<Adt8, Adt78>(Adt78::C3))
                    }
                } else {
                    Ok(Err::<Adt8, Adt78>(Adt78::C2))
                }
            }
            Adt67::C3 => {
                if match v0.clone() {
                    Adt8::C0(_, h2161, _, _) => {
                        h2161
                    }
                } {
                    Ok(Err::<Adt8, Adt78>(Adt78::C4))
                } else {
                    Ok(Ok::<Adt8, Adt78>(Adt8::C0(match v0.clone() {
                        Adt8::C0(h2162, _, _, _) => {
                            h2162
                        }
                    }, match v0.clone() {
                        Adt8::C0(_, h2163, _, _) => {
                            h2163
                        }
                    }, true, match v0 {
                        Adt8::C0(_, _, _, h2164) => {
                            h2164
                        }
                    })))
                }
            }
        }
    }
}

pub fn f84(v0: Adt2, v1: u64, v2: u64) -> bool {
    if match v0.clone() {
        Adt2::C0(_, _, h2165, _, _, _) => {
            h2165
        }
    } {
        let a2167 = match v0.clone() {
            Adt2::C0(_, h2166, _, _, _, _) => {
                h2166
            }
        };
        let a2168 = v1;
        if nat_eq(a2167, a2168) {
            let a2170 = match v0 {
                Adt2::C0(h2169, _, _, _, _, _) => {
                    h2169
                }
            };
            let a2171 = v2;
            nat_eq(a2170, a2171)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f85(v0: Adt1, v1: Adt52, v2: Adt22, v3: bool) -> R<Adt71> {
    if v3 {
        let m2173 = match v0.clone() {
            Adt1::C0(_, _, _, _, h2172, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2172
            }
        };
        match m2173 {
            None => {
                Ok(f97(v0, v2))
            }
            Some(v4) => {
                f98(v0, v1, f99(v4.clone()), f100(v4, v2))
            }
        }
    } else {
        Ok(f97(v0, v2))
    }
}

pub fn f86(v0: Adt1, v1: Adt52, v2: Adt41) -> Adt71 {
    if f62(v0.clone(), v1.clone()) {
        Adt71::C0(Adt1::C0(match v0.clone() {
            Adt1::C0(h2174, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2174
            }
        }, f101(match v0.clone() {
            Adt1::C0(_, h2175, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2175
            }
        }, match v1.clone() {
            Adt52::C0(_, h2176, _) => {
                h2176
            }
        }, match v1.clone() {
            Adt52::C0(_, _, h2177) => {
                h2177
            }
        }, Adt4::C5), f67(match v0.clone() {
            Adt1::C0(_, _, h2178, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2178
            }
        }, Adt7::C2), match v0.clone() {
            Adt1::C0(_, _, _, h2179, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2179
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, h2180, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2180
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, h2181, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2181
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, h2182, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2182
            }
        }, None::<Adt11>, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, h2183, _, _, _, _, _, _, _, _, _, _, _) => {
                h2183
            }
        }, Some(v2), match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2184, _, _, _, _, _, _, _, _, _) => {
                h2184
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2185, _, _, _, _, _, _, _, _) => {
                h2185
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2186, _, _, _, _, _, _, _) => {
                h2186
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2187, _, _, _, _, _, _) => {
                h2187
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2188, _, _, _, _, _) => {
                h2188
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2189, _, _, _, _) => {
                h2189
            }
        }, false, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2190, _, _) => {
                h2190
            }
        }, match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2191, _) => {
                h2191
            }
        }, match v0 {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2192) => {
                h2192
            }
        }), List::cons(Adt66::C5(v1), List::<Adt66>::nil()))
    } else {
        Adt71::C0(v0, List::<Adt66>::nil())
    }
}

pub fn f87(v0: Adt1) -> bool {
    if match v0.clone() {
        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2193, _, _, _, _, _, _, _) => {
            h2193
        }
    } {
        let a2195 = match v0.clone() {
            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2194, _, _, _, _, _, _) => {
                h2194
            }
        };
        if bool_not(a2195) {
            let a2197 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h2196, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2196
                }
            };
            if bool_not(a2197) {
                let m2200 = match v0.clone() {
                    Adt1::C0(_, _, h2199, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2199
                    }
                };
                if match m2200 {
                    Adt5::C0(_, _, _, h2198, _) => {
                        h2198
                    }
                } {
                    let m2202 = match v0.clone() {
                        Adt1::C0(_, _, _, _, _, _, _, h2201, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                            h2201
                        }
                    };
                    if match m2202 {
                        None => {
                            false
                        }
                        Some(_) => {
                            true
                        }
                    } {
                        let m2206 = {
                            let m2205 = match v0 {
                                Adt1::C0(_, _, h2204, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                    h2204
                                }
                            };
                            match m2205 {
                                Adt5::C0(_, _, _, _, h2203) => {
                                    h2203
                                }
                            }
                        };
                        match m2206 {
                            Adt7::C0 => {
                                true
                            }
                            Adt7::C1 => {
                                false
                            }
                            Adt7::C2 => {
                                true
                            }
                            Adt7::C3 => {
                                false
                            }
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f88(v0: Adt5) -> Adt5 {
    Adt5::C0(match v0.clone() {
        Adt5::C0(h2207, _, _, _, _) => {
            h2207
        }
    }, match v0.clone() {
        Adt5::C0(_, h2208, _, _, _) => {
            h2208
        }
    }, match v0.clone() {
        Adt5::C0(_, _, h2209, _, _) => {
            h2209
        }
    }, match v0 {
        Adt5::C0(_, _, _, h2210, _) => {
            h2210
        }
    }, Adt7::C0)
}

pub fn f89(v0: Adt5, v1: Adt7) -> Result<Adt5, Adt44> {
    if f102(v0.clone()) {
        let m2211 = v1;
        match m2211 {
            Adt7::C0 => {
                Err::<Adt5, Adt44>(Adt44::C3)
            }
            Adt7::C1 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2212, _, _, _, _) => {
                        h2212
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2213, _, _, _) => {
                        h2213
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2214, _, _) => {
                        h2214
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2215, _) => {
                        h2215
                    }
                }, Adt7::C1))
            }
            Adt7::C2 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2216, _, _, _, _) => {
                        h2216
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2217, _, _, _) => {
                        h2217
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2218, _, _) => {
                        h2218
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2219, _) => {
                        h2219
                    }
                }, Adt7::C2))
            }
            Adt7::C3 => {
                Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2220, _, _, _, _) => {
                        h2220
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2221, _, _, _) => {
                        h2221
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2222, _, _) => {
                        h2222
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, h2223, _) => {
                        h2223
                    }
                }, Adt7::C3))
            }
        }
    } else {
        Err::<Adt5, Adt44>(Adt44::C3)
    }
}

pub fn f90(v0: Adt5, v1: u64, v2: u64) -> R<Result<Adt5, Adt44>> {
    let m2225 = match v0.clone() {
        Adt5::C0(h2224, _, _, _, _) => {
            h2224
        }
    };
    match m2225 {
        Adt6::C0 => {
            let a2227 = match v0.clone() {
                Adt5::C0(_, _, h2226, _, _) => {
                    h2226
                }
            };
            let a2228 = v2;
            if if nat_le(a2227, a2228) {
                let a2232 = v1;
                let a2233 = {
                    let a2230 = v2;
                    let a2231 = match v0.clone() {
                        Adt5::C0(_, _, h2229, _, _) => {
                            h2229
                        }
                    };
                    nat_sub(a2230, a2231)
                };
                nat_le(a2232, a2233)
            } else {
                false
            } {
                Ok(Ok::<Adt5, Adt44>(Adt5::C0(match v0.clone() {
                    Adt5::C0(h2234, _, _, _, _) => {
                        h2234
                    }
                }, match v0.clone() {
                    Adt5::C0(_, h2235, _, _, _) => {
                        h2235
                    }
                }, {
                    let a2237 = match v0.clone() {
                        Adt5::C0(_, _, h2236, _, _) => {
                            h2236
                        }
                    };
                    let a2238 = v1;
                    nat_add(a2237, a2238)?
                }, match v0.clone() {
                    Adt5::C0(_, _, _, h2239, _) => {
                        h2239
                    }
                }, match v0 {
                    Adt5::C0(_, _, _, _, h2240) => {
                        h2240
                    }
                })))
            } else {
                Ok(Err::<Adt5, Adt44>(Adt44::C4))
            }
        }
        Adt6::C1 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C2 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C3 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
        Adt6::C4 => {
            Ok(Err::<Adt5, Adt44>(Adt44::C2))
        }
    }
}

pub fn f91(v0: Adt1, v1: Adt50) -> Adt71 {
    let m2242 = match v1.clone() {
        Adt50::C0(_, h2241) => {
            h2241
        }
    };
    match m2242 {
        None => {
            Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h2243, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2243
                }
            }, match v0.clone() {
                Adt1::C0(_, h2244, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2244
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h2245, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2245
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h2246, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2246
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h2247, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2247
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h2248, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2248
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h2249, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2249
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2250, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2250
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h2251, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2251
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h2252, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2252
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, h2253, _, _, _, _, _, _, _, _, _, _) => {
                    h2253
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2254, _, _, _, _, _, _, _, _, _) => {
                    h2254
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2255, _, _, _, _, _, _, _, _) => {
                    h2255
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2256, _, _, _, _, _, _, _) => {
                    h2256
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2257, _, _, _, _, _, _) => {
                    h2257
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2258, _, _, _, _, _) => {
                    h2258
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2259, _, _, _, _) => {
                    h2259
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2260, _, _, _) => {
                    h2260
                }
            }, v1, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2261, _) => {
                    h2261
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2262) => {
                    h2262
                }
            }), List::<Adt66>::nil())
        }
        Some(v2) => {
            Adt71::C0(Adt1::C0(match v0.clone() {
                Adt1::C0(h2263, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2263
                }
            }, match v0.clone() {
                Adt1::C0(_, h2264, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2264
                }
            }, match v0.clone() {
                Adt1::C0(_, _, h2265, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2265
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, h2266, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2266
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, h2267, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2267
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, h2268, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2268
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, h2269, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2269
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2270, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2270
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, h2271, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2271
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, h2272, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2272
                }
            }, Some(Adt41::C16(v2)), match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2273, _, _, _, _, _, _, _, _, _) => {
                    h2273
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2274, _, _, _, _, _, _, _, _) => {
                    h2274
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2275, _, _, _, _, _, _, _) => {
                    h2275
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2276, _, _, _, _, _, _) => {
                    h2276
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2277, _, _, _, _, _) => {
                    h2277
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2278, _, _, _, _) => {
                    h2278
                }
            }, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2279, _, _, _) => {
                    h2279
                }
            }, v1, match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2280, _) => {
                    h2280
                }
            }, match v0 {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2281) => {
                    h2281
                }
            }), List::<Adt66>::nil())
        }
    }
}

pub fn f92(v0: Adt14, v1: Adt50, v2: Adt74) -> R<Adt50> {
    let m2282 = v2;
    match m2282 {
        Adt74::C0(v3, v4) => {
            let m2284 = f103(v0, match v1.clone() {
                Adt50::C0(h2283, _) => {
                    h2283
                }
            }, v3, v4)?;
            match m2284 {
                Ok(v6) => {
                    Ok(Adt50::C0(v6, None::<Adt45>))
                }
                Err(v5) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2285, _) => {
                            h2285
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt74::C1(v7, v8, v9) => {
            let m2287 = f104(match v1.clone() {
                Adt50::C0(h2286, _) => {
                    h2286
                }
            }, v7, v8, v9)?;
            match m2287 {
                Ok(v11) => {
                    Ok(Adt50::C0(v11, None::<Adt45>))
                }
                Err(v10) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2288, _) => {
                            h2288
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt74::C2(v12, v13, v14) => {
            let m2290 = f104(match v1.clone() {
                Adt50::C0(h2289, _) => {
                    h2289
                }
            }, v12, v13, v14)?;
            match m2290 {
                Ok(v16) => {
                    Ok(Adt50::C0(v16, None::<Adt45>))
                }
                Err(v15) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2291, _) => {
                            h2291
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt74::C3(v17, v18) => {
            let m2293 = f105(match v1.clone() {
                Adt50::C0(h2292, _) => {
                    h2292
                }
            }, v17, v18)?;
            match m2293 {
                Ok(v20) => {
                    Ok(Adt50::C0(v20, None::<Adt45>))
                }
                Err(v19) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2294, _) => {
                            h2294
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt74::C4(v21, v22) => {
            let m2296 = f105(match v1.clone() {
                Adt50::C0(h2295, _) => {
                    h2295
                }
            }, v21, v22)?;
            match m2296 {
                Ok(v24) => {
                    Ok(Adt50::C0(v24, None::<Adt45>))
                }
                Err(v23) => {
                    Ok(Adt50::C0(match v1 {
                        Adt50::C0(h2297, _) => {
                            h2297
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f93(v0: Adt52, v1: Adt52) -> bool {
    let a2300 = match v0.clone() {
        Adt52::C0(h2298, _, _) => {
            h2298
        }
    };
    let a2301 = match v1.clone() {
        Adt52::C0(h2299, _, _) => {
            h2299
        }
    };
    if nat_eq(a2300, a2301) {
        let a2304 = match v0.clone() {
            Adt52::C0(_, h2302, _) => {
                h2302
            }
        };
        let a2305 = match v1.clone() {
            Adt52::C0(_, h2303, _) => {
                h2303
            }
        };
        if nat_eq(a2304, a2305) {
            let a2308 = match v0 {
                Adt52::C0(_, _, h2306) => {
                    h2306
                }
            };
            let a2309 = match v1 {
                Adt52::C0(_, _, h2307) => {
                    h2307
                }
            };
            nat_eq(a2308, a2309)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f94(v0: Adt24) -> R<u64> {
    f106(match v0 {
        Adt24::C0(h2310, _, _, _) => {
            h2310
        }
    })
}

pub fn f95(v0: Adt24) -> R<u64> {
    f106(match v0 {
        Adt24::C0(_, h2311, _, _) => {
            h2311
        }
    })
}

pub fn f96() -> Adt25 {
    Adt25::C0(0u64, 0u64, 0u64, 0u64)
}

pub fn f97(v0: Adt1, v1: Adt22) -> Adt71 {
    Adt71::C0(v0.clone(), {
        let m2318 = {
            let m2314 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, h2313, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                    h2313
                }
            };
            match m2314 {
                None => {
                    Adt71::C0(v0, f63(match v1 {
                        Adt22::C0(_, _, _, _, _, _, _, _, h2315, _) => {
                            h2315
                        }
                    }))
                }
                Some(v2) => {
                    let m2317 = match v1 {
                        Adt22::C0(_, _, _, _, _, _, _, _, h2316, _) => {
                            h2316
                        }
                    };
                    match m2317 {
                        None => {
                            Adt71::C0(v0, List::<Adt66>::nil())
                        }
                        Some(v3) => {
                            if f56(v2, v3.clone()) {
                                Adt71::C0(v0, List::<Adt66>::nil())
                            } else {
                                Adt71::C0(v0, List::cons(Adt66::C6(v3), List::<Adt66>::nil()))
                            }
                        }
                    }
                }
            }
        };
        match m2318 {
            Adt71::C0(_, h2312) => {
                h2312
            }
        }
    })
}

pub fn f98(v0: Adt1, v1: Adt52, v2: Adt54, v3: Adt22) -> R<Adt71> {
    if f107(v0.clone(), v2.clone(), v3.clone())? {
        let m2319 = f108(v2.clone(), v3.clone());
        match m2319 {
            Adt79::C0 => {
                let m2321 = f109(match v0.clone() {
                    Adt1::C0(_, _, h2320, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2320
                    }
                });
                match m2321 {
                    Ok(v5) => {
                        Ok(Adt71::C0(Adt1::C0(match v0.clone() {
                            Adt1::C0(h2322, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2322
                            }
                        }, f101(match v0.clone() {
                            Adt1::C0(_, h2323, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2323
                            }
                        }, match v1.clone() {
                            Adt52::C0(_, h2324, _) => {
                                h2324
                            }
                        }, match v1 {
                            Adt52::C0(_, _, h2325) => {
                                h2325
                            }
                        }, {
                            let m2326 = v2;
                            match m2326 {
                                Adt54::C0 => {
                                    Adt4::C2
                                }
                                Adt54::C1 => {
                                    Adt4::C3
                                }
                                Adt54::C2 => {
                                    Adt4::C1
                                }
                                Adt54::C3 => {
                                    Adt4::C1
                                }
                                Adt54::C4 => {
                                    Adt4::C2
                                }
                                Adt54::C5 => {
                                    Adt4::C2
                                }
                                Adt54::C6 => {
                                    Adt4::C1
                                }
                                Adt54::C7 => {
                                    Adt4::C1
                                }
                                Adt54::C8 => {
                                    Adt4::C1
                                }
                                Adt54::C9 => {
                                    Adt4::C1
                                }
                            }
                        }), v5, match v0.clone() {
                            Adt1::C0(_, _, _, h2327, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2327
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, h2328, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2328
                            }
                        }, Some(v3.clone()), match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, h2329, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2329
                            }
                        }, match v3.clone() {
                            Adt22::C0(_, _, _, _, _, _, _, _, h2330, _) => {
                                h2330
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, h2331, _, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2331
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, h2332, _, _, _, _, _, _, _, _, _, _, _) => {
                                h2332
                            }
                        }, None::<Adt41>, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, h2333, _, _, _, _, _, _, _, _, _) => {
                                h2333
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2334, _, _, _, _, _, _, _, _) => {
                                h2334
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, h2335, _, _, _, _, _, _, _) => {
                                h2335
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, h2336, _, _, _, _, _, _) => {
                                h2336
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2337, _, _, _, _, _) => {
                                h2337
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2338, _, _, _, _) => {
                                h2338
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2339, _, _, _) => {
                                h2339
                            }
                        }, match v0.clone() {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2340, _, _) => {
                                h2340
                            }
                        }, Some(match v3 {
                            Adt22::C0(h2341, _, _, _, _, _, _, _, _, _) => {
                                h2341
                            }
                        }), match v0 {
                            Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2342) => {
                                h2342
                            }
                        }), List::<Adt66>::nil()))
                    }
                    Err(v4) => {
                        Ok(f86(v0, v1, Adt41::C11(v4)))
                    }
                }
            }
            Adt79::C1 => {
                Ok(f86(v0, v1, Adt41::C12))
            }
            Adt79::C2 => {
                Ok(f86(v0, v1, Adt41::C13))
            }
            Adt79::C3 => {
                Ok(f86(v0, v1, Adt41::C7))
            }
            Adt79::C4 => {
                Ok(f86(v0, v1, Adt41::C5))
            }
        }
    } else {
        Ok(f86(v0, v1, Adt41::C15(Str::lit("Staged output ownership or byte count does not match the operation."))))
    }
}

pub fn f99(v0: Adt9) -> Adt54 {
    let m2343 = v0;
    match m2343 {
        Adt9::C0(_) => {
            Adt54::C0
        }
        Adt9::C1(_) => {
            Adt54::C1
        }
        Adt9::C2(_) => {
            Adt54::C2
        }
        Adt9::C3(_) => {
            Adt54::C3
        }
        Adt9::C4(_) => {
            Adt54::C4
        }
        Adt9::C5(_) => {
            Adt54::C5
        }
        Adt9::C6(_) => {
            Adt54::C6
        }
        Adt9::C7(_) => {
            Adt54::C7
        }
        Adt9::C8(_) => {
            Adt54::C8
        }
        Adt9::C9(_) => {
            Adt54::C9
        }
    }
}

pub fn f100(v0: Adt9, v1: Adt22) -> Adt22 {
    Adt22::C0(match v1.clone() {
        Adt22::C0(h2344, _, _, _, _, _, _, _, _, _) => {
            h2344
        }
    }, match v1.clone() {
        Adt22::C0(_, h2345, _, _, _, _, _, _, _, _) => {
            h2345
        }
    }, match v1.clone() {
        Adt22::C0(_, _, h2346, _, _, _, _, _, _, _) => {
            h2346
        }
    }, f110(v0), match v1.clone() {
        Adt22::C0(_, _, _, _, h2347, _, _, _, _, _) => {
            h2347
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, h2348, _, _, _, _) => {
            h2348
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, h2349, _, _, _) => {
            h2349
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, _, h2350, _, _) => {
            h2350
        }
    }, match v1.clone() {
        Adt22::C0(_, _, _, _, _, _, _, _, h2351, _) => {
            h2351
        }
    }, match v1 {
        Adt22::C0(_, _, _, _, _, _, _, _, _, h2352) => {
            h2352
        }
    })
}

pub fn f101(v0: Adt2, v1: u64, v2: u64, v3: Adt4) -> Adt2 {
    if f84(v0.clone(), v1, v2) {
        Adt2::C0(match v0.clone() {
            Adt2::C0(h2353, _, _, _, _, _) => {
                h2353
            }
        }, match v0 {
            Adt2::C0(_, h2354, _, _, _, _) => {
                h2354
            }
        }, false, true, {
            let m2355 = v3.clone();
            match m2355 {
                Adt4::C0 => {
                    Adt3::C6
                }
                Adt4::C1 => {
                    Adt3::C4
                }
                Adt4::C2 => {
                    Adt3::C4
                }
                Adt4::C3 => {
                    Adt3::C4
                }
                Adt4::C4 => {
                    Adt3::C4
                }
                Adt4::C5 => {
                    Adt3::C6
                }
            }
        }, v3)
    } else {
        v0
    }
}

pub fn f102(v0: Adt5) -> bool {
    let m2357 = match v0.clone() {
        Adt5::C0(h2356, _, _, _, _) => {
            h2356
        }
    };
    match m2357 {
        Adt6::C0 => {
            false
        }
        Adt6::C1 => {
            false
        }
        Adt6::C2 => {
            if match v0.clone() {
                Adt5::C0(_, _, _, h2358, _) => {
                    h2358
                }
            } {
                let m2360 = match v0 {
                    Adt5::C0(_, _, _, _, h2359) => {
                        h2359
                    }
                };
                match m2360 {
                    Adt7::C0 => {
                        true
                    }
                    Adt7::C1 => {
                        false
                    }
                    Adt7::C2 => {
                        false
                    }
                    Adt7::C3 => {
                        false
                    }
                }
            } else {
                false
            }
        }
        Adt6::C3 => {
            false
        }
        Adt6::C4 => {
            false
        }
    }
}

pub fn f103(v0: Adt14, v1: Adt24, v2: Adt46, v3: u64) -> R<Result<Adt24, Adt45>> {
    if f111(match v0.clone() {
        Adt14::C0(h2361, _, _, _, _) => {
            h2361
        }
    }, f112(v1.clone())?, v3)? {
        if f111(f113(v0.clone(), v2.clone()), {
            let a2364 = f114(match v1.clone() {
                Adt24::C0(h2362, _, _, _) => {
                    h2362
                }
            }, v2.clone());
            let a2365 = f114(match v1.clone() {
                Adt24::C0(_, h2363, _, _) => {
                    h2363
                }
            }, v2.clone());
            nat_add(a2364, a2365)?
        }, v3)? {
            Ok(Ok::<Adt24, Adt45>(Adt24::C0(match v1.clone() {
                Adt24::C0(h2366, _, _, _) => {
                    h2366
                }
            }, f115(match v1.clone() {
                Adt24::C0(_, h2367, _, _) => {
                    h2367
                }
            }, v2.clone(), {
                let a2369 = f114(match v1.clone() {
                    Adt24::C0(_, h2368, _, _) => {
                        h2368
                    }
                }, v2.clone());
                let a2370 = v3;
                nat_add(a2369, a2370)?
            }), f116(match v1.clone() {
                Adt24::C0(_, _, h2371, _) => {
                    h2371
                }
            }, f106(match v1.clone() {
                Adt24::C0(h2372, _, _, _) => {
                    h2372
                }
            })?), f116(match v1.clone() {
                Adt24::C0(_, _, _, h2373) => {
                    h2373
                }
            }, {
                let a2379 = f106(match v1.clone() {
                    Adt24::C0(h2374, _, _, _) => {
                        h2374
                    }
                })?;
                let a2380 = f106(f115(match v1.clone() {
                    Adt24::C0(_, h2375, _, _) => {
                        h2375
                    }
                }, v2.clone(), {
                    let a2377 = f114(match v1 {
                        Adt24::C0(_, h2376, _, _) => {
                            h2376
                        }
                    }, v2);
                    let a2378 = v3;
                    nat_add(a2377, a2378)?
                }))?;
                nat_add(a2379, a2380)?
            }))))
        } else {
            Ok(Err::<Adt24, Adt45>(Adt45::C1(v2.clone(), {
                let a2383 = f114(match v1.clone() {
                    Adt24::C0(h2381, _, _, _) => {
                        h2381
                    }
                }, v2.clone());
                let a2384 = f114(match v1 {
                    Adt24::C0(_, h2382, _, _) => {
                        h2382
                    }
                }, v2.clone());
                nat_add(a2383, a2384)?
            }, v3, {
                let m2385 = f113(v0, v2);
                match m2385 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C0(f112(v1)?, v3, {
            let m2387 = match v0 {
                Adt14::C0(h2386, _, _, _, _) => {
                    h2386
                }
            };
            match m2387 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f104(v0: Adt24, v1: Adt46, v2: u64, v3: u64) -> R<Result<Adt24, Adt45>> {
    let a2391 = {
        let a2389 = f114(match v0.clone() {
            Adt24::C0(_, h2388, _, _) => {
                h2388
            }
        }, v1.clone());
        let a2390 = v2;
        nat_lt(a2389, a2390)
    };
    if if bool_not(a2391) {
        let a2394 = {
            let a2392 = v2;
            let a2393 = v3;
            nat_lt(a2392, a2393)
        };
        bool_not(a2394)
    } else {
        false
    } {
        Ok(Ok::<Adt24, Adt45>(Adt24::C0(f115(match v0.clone() {
            Adt24::C0(h2395, _, _, _) => {
                h2395
            }
        }, v1.clone(), {
            let a2397 = f114(match v0.clone() {
                Adt24::C0(h2396, _, _, _) => {
                    h2396
                }
            }, v1.clone());
            let a2398 = v3;
            nat_add(a2397, a2398)?
        }), f115(match v0.clone() {
            Adt24::C0(_, h2399, _, _) => {
                h2399
            }
        }, v1.clone(), {
            let a2401 = f114(match v0.clone() {
                Adt24::C0(_, h2400, _, _) => {
                    h2400
                }
            }, v1.clone());
            let a2402 = v2;
            nat_sub(a2401, a2402)
        }), f116(match v0.clone() {
            Adt24::C0(_, _, h2403, _) => {
                h2403
            }
        }, f106(f115(match v0.clone() {
            Adt24::C0(h2404, _, _, _) => {
                h2404
            }
        }, v1.clone(), {
            let a2406 = f114(match v0.clone() {
                Adt24::C0(h2405, _, _, _) => {
                    h2405
                }
            }, v1.clone());
            let a2407 = v3;
            nat_add(a2406, a2407)?
        }))?), f116(match v0.clone() {
            Adt24::C0(_, _, _, h2408) => {
                h2408
            }
        }, {
            let a2417 = f106(f115(match v0.clone() {
                Adt24::C0(h2409, _, _, _) => {
                    h2409
                }
            }, v1.clone(), {
                let a2411 = f114(match v0.clone() {
                    Adt24::C0(h2410, _, _, _) => {
                        h2410
                    }
                }, v1.clone());
                let a2412 = v3;
                nat_add(a2411, a2412)?
            }))?;
            let a2418 = f106(f115(match v0.clone() {
                Adt24::C0(_, h2413, _, _) => {
                    h2413
                }
            }, v1.clone(), {
                let a2415 = f114(match v0 {
                    Adt24::C0(_, h2414, _, _) => {
                        h2414
                    }
                }, v1);
                let a2416 = v2;
                nat_sub(a2415, a2416)
            }))?;
            nat_add(a2417, a2418)?
        }))))
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C2(v1, v2, v3)))
    }
}

pub fn f105(v0: Adt24, v1: Adt46, v2: u64) -> R<Result<Adt24, Adt45>> {
    let a2422 = {
        let a2420 = f114(match v0.clone() {
            Adt24::C0(h2419, _, _, _) => {
                h2419
            }
        }, v1.clone());
        let a2421 = v2;
        nat_lt(a2420, a2421)
    };
    if bool_not(a2422) {
        Ok(Ok::<Adt24, Adt45>(Adt24::C0(f115(match v0.clone() {
            Adt24::C0(h2423, _, _, _) => {
                h2423
            }
        }, v1.clone(), {
            let a2425 = f114(match v0.clone() {
                Adt24::C0(h2424, _, _, _) => {
                    h2424
                }
            }, v1.clone());
            let a2426 = v2;
            nat_sub(a2425, a2426)
        }), match v0.clone() {
            Adt24::C0(_, h2427, _, _) => {
                h2427
            }
        }, f116(match v0.clone() {
            Adt24::C0(_, _, h2428, _) => {
                h2428
            }
        }, f106(f115(match v0.clone() {
            Adt24::C0(h2429, _, _, _) => {
                h2429
            }
        }, v1.clone(), {
            let a2431 = f114(match v0.clone() {
                Adt24::C0(h2430, _, _, _) => {
                    h2430
                }
            }, v1.clone());
            let a2432 = v2;
            nat_sub(a2431, a2432)
        }))?), f116(match v0.clone() {
            Adt24::C0(_, _, _, h2433) => {
                h2433
            }
        }, {
            let a2439 = f106(f115(match v0.clone() {
                Adt24::C0(h2434, _, _, _) => {
                    h2434
                }
            }, v1.clone(), {
                let a2436 = f114(match v0.clone() {
                    Adt24::C0(h2435, _, _, _) => {
                        h2435
                    }
                }, v1);
                let a2437 = v2;
                nat_sub(a2436, a2437)
            }))?;
            let a2440 = f106(match v0 {
                Adt24::C0(_, h2438, _, _) => {
                    h2438
                }
            })?;
            nat_add(a2439, a2440)?
        }))))
    } else {
        Ok(Err::<Adt24, Adt45>(Adt45::C3(v1.clone(), f114(match v0 {
            Adt24::C0(h2441, _, _, _) => {
                h2441
            }
        }, v1), v2)))
    }
}

pub fn f106(v0: Adt25) -> R<u64> {
    let a2452 = {
        let a2449 = {
            let a2446 = {
                let a2443 = 0u64;
                let a2444 = match v0.clone() {
                    Adt25::C0(h2442, _, _, _) => {
                        h2442
                    }
                };
                nat_add(a2443, a2444)?
            };
            let a2447 = match v0.clone() {
                Adt25::C0(_, h2445, _, _) => {
                    h2445
                }
            };
            nat_add(a2446, a2447)?
        };
        let a2450 = match v0.clone() {
            Adt25::C0(_, _, h2448, _) => {
                h2448
            }
        };
        nat_add(a2449, a2450)?
    };
    let a2453 = match v0 {
        Adt25::C0(_, _, _, h2451) => {
            h2451
        }
    };
    nat_add(a2452, a2453)
}

pub fn f107(v0: Adt1, v1: Adt54, v2: Adt22) -> R<bool> {
    let a2460 = {
        let m2456 = match v2.clone() {
            Adt22::C0(h2455, _, _, _, _, _, _, _, _, _) => {
                h2455
            }
        };
        match m2456 {
            Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, h2454, _, _) => {
                h2454
            }
        }
    };
    let a2461 = {
        let m2459 = match v0.clone() {
            Adt1::C0(_, _, h2458, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                h2458
            }
        };
        match m2459 {
            Adt5::C0(_, _, h2457, _, _) => {
                h2457
            }
        }
    };
    if if nat_eq(a2460, a2461) {
        let m2463 = match v2.clone() {
            Adt22::C0(_, _, _, _, _, _, _, _, h2462, _) => {
                h2462
            }
        };
        match m2463 {
            None => {
                let m2464 = v1;
                match m2464 {
                    Adt54::C0 => {
                        false
                    }
                    Adt54::C1 => {
                        false
                    }
                    Adt54::C2 => {
                        true
                    }
                    Adt54::C3 => {
                        true
                    }
                    Adt54::C4 => {
                        false
                    }
                    Adt54::C5 => {
                        false
                    }
                    Adt54::C6 => {
                        true
                    }
                    Adt54::C7 => {
                        true
                    }
                    Adt54::C8 => {
                        true
                    }
                    Adt54::C9 => {
                        true
                    }
                }
            }
            Some(v3) => {
                let a2467 = match v3 {
                    Adt11::C0(h2465, _, _) => {
                        h2465
                    }
                };
                let a2468 = match v0.clone() {
                    Adt1::C0(h2466, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _) => {
                        h2466
                    }
                };
                if nat_eq(a2467, a2468) {
                    let m2469 = v1;
                    match m2469 {
                        Adt54::C0 => {
                            true
                        }
                        Adt54::C1 => {
                            true
                        }
                        Adt54::C2 => {
                            false
                        }
                        Adt54::C3 => {
                            false
                        }
                        Adt54::C4 => {
                            true
                        }
                        Adt54::C5 => {
                            true
                        }
                        Adt54::C6 => {
                            false
                        }
                        Adt54::C7 => {
                            false
                        }
                        Adt54::C8 => {
                            false
                        }
                        Adt54::C9 => {
                            false
                        }
                    }
                } else {
                    false
                }
            }
        }
    } else {
        false
    } {
        if f117({
            let m2472 = match v2 {
                Adt22::C0(h2471, _, _, _, _, _, _, _, _, _) => {
                    h2471
                }
            };
            match m2472 {
                Adt23::C0(_, _, _, _, _, _, _, _, _, _, _, _, h2470, _) => {
                    h2470
                }
            }
        }, {
            let m2475 = match v0.clone() {
                Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2474, _, _) => {
                    h2474
                }
            };
            match m2475 {
                Adt50::C0(h2473, _) => {
                    h2473
                }
            }
        }) {
            let a2479 = f95({
                let m2478 = match v0.clone() {
                    Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2477, _, _) => {
                        h2477
                    }
                };
                match m2478 {
                    Adt50::C0(h2476, _) => {
                        h2476
                    }
                }
            })?;
            let a2480 = 0u64;
            if nat_eq(a2479, a2480) {
                let m2484 = {
                    let m2483 = match v0 {
                        Adt1::C0(_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, h2482, _, _) => {
                            h2482
                        }
                    };
                    match m2483 {
                        Adt50::C0(_, h2481) => {
                            h2481
                        }
                    }
                };
                match m2484 {
                    None => {
                        Ok(true)
                    }
                    Some(_) => {
                        Ok(false)
                    }
                }
            } else {
                Ok(false)
            }
        } else {
            Ok(false)
        }
    } else {
        Ok(false)
    }
}

pub fn f108(v0: Adt54, v1: Adt22) -> Adt79 {
    let m2485 = v0;
    match m2485 {
        Adt54::C0 => {
            let m2488 = match v1.clone() {
                Adt22::C0(_, h2487, _, _, _, _, _, _, _, _) => {
                    h2487
                }
            };
            if if match m2488 {
                Adt28::C0(h2486, _, _, _, _) => {
                    h2486
                }
            } {
                let m2491 = match v1.clone() {
                    Adt22::C0(_, h2490, _, _, _, _, _, _, _, _) => {
                        h2490
                    }
                };
                if match m2491 {
                    Adt28::C0(_, h2489, _, _, _) => {
                        h2489
                    }
                } {
                    let m2494 = match v1.clone() {
                        Adt22::C0(_, h2493, _, _, _, _, _, _, _, _) => {
                            h2493
                        }
                    };
                    if match m2494 {
                        Adt28::C0(_, _, h2492, _, _) => {
                            h2492
                        }
                    } {
                        if match v1.clone() {
                            Adt22::C0(_, _, h2495, _, _, _, _, _, _, _) => {
                                h2495
                            }
                        } {
                            if match v1.clone() {
                                Adt22::C0(_, _, _, h2496, _, _, _, _, _, _) => {
                                    h2496
                                }
                            } {
                                let m2499 = match v1.clone() {
                                    Adt22::C0(_, h2498, _, _, _, _, _, _, _, _) => {
                                        h2498
                                    }
                                };
                                match m2499 {
                                    Adt28::C0(_, _, _, h2497, _) => {
                                        h2497
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f118(match v1.clone() {
                    Adt22::C0(_, _, _, _, h2500, _, _, _, _, _) => {
                        h2500
                    }
                }, false, f119(match v1 {
                    Adt22::C0(_, _, _, _, _, h2501, _, _, _, _) => {
                        h2501
                    }
                }))
            } else {
                Adt79::C2
            }
        }
        Adt54::C1 => {
            f120({
                let m2504 = match v1.clone() {
                    Adt22::C0(_, h2503, _, _, _, _, _, _, _, _) => {
                        h2503
                    }
                };
                match m2504 {
                    Adt28::C0(h2502, _, _, _, _) => {
                        h2502
                    }
                }
            }, {
                let m2507 = match v1.clone() {
                    Adt22::C0(_, h2506, _, _, _, _, _, _, _, _) => {
                        h2506
                    }
                };
                match m2507 {
                    Adt28::C0(_, h2505, _, _, _) => {
                        h2505
                    }
                }
            }, {
                let m2510 = match v1.clone() {
                    Adt22::C0(_, h2509, _, _, _, _, _, _, _, _) => {
                        h2509
                    }
                };
                match m2510 {
                    Adt28::C0(_, _, h2508, _, _) => {
                        h2508
                    }
                }
            }, match v1 {
                Adt22::C0(_, _, h2511, _, _, _, _, _, _, _) => {
                    h2511
                }
            }, false)
        }
        Adt54::C2 => {
            let m2514 = match v1 {
                Adt22::C0(_, h2513, _, _, _, _, _, _, _, _) => {
                    h2513
                }
            };
            if match m2514 {
                Adt28::C0(h2512, _, _, _, _) => {
                    h2512
                }
            } {
                Adt79::C0
            } else {
                Adt79::C2
            }
        }
        Adt54::C3 => {
            if match v1.clone() {
                Adt22::C0(_, _, _, h2515, _, _, _, _, _, _) => {
                    h2515
                }
            } {
                let m2518 = match v1.clone() {
                    Adt22::C0(_, h2517, _, _, _, _, _, _, _, _) => {
                        h2517
                    }
                };
                if if match m2518 {
                    Adt28::C0(h2516, _, _, _, _) => {
                        h2516
                    }
                } {
                    let m2521 = match v1.clone() {
                        Adt22::C0(_, h2520, _, _, _, _, _, _, _, _) => {
                            h2520
                        }
                    };
                    if match m2521 {
                        Adt28::C0(_, h2519, _, _, _) => {
                            h2519
                        }
                    } {
                        let m2524 = match v1.clone() {
                            Adt22::C0(_, h2523, _, _, _, _, _, _, _, _) => {
                                h2523
                            }
                        };
                        if match m2524 {
                            Adt28::C0(_, _, h2522, _, _) => {
                                h2522
                            }
                        } {
                            let m2527 = match v1.clone() {
                                Adt22::C0(_, h2526, _, _, _, _, _, _, _, _) => {
                                    h2526
                                }
                            };
                            if match m2527 {
                                Adt28::C0(_, _, _, h2525, _) => {
                                    h2525
                                }
                            } {
                                match v1.clone() {
                                    Adt22::C0(_, _, h2528, _, _, _, _, _, _, _) => {
                                        h2528
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                } {
                    f118(match v1.clone() {
                        Adt22::C0(_, _, _, _, h2529, _, _, _, _, _) => {
                            h2529
                        }
                    }, false, f119(match v1 {
                        Adt22::C0(_, _, _, _, _, h2530, _, _, _, _) => {
                            h2530
                        }
                    }))
                } else {
                    Adt79::C2
                }
            } else {
                f120({
                    let m2533 = match v1.clone() {
                        Adt22::C0(_, h2532, _, _, _, _, _, _, _, _) => {
                            h2532
                        }
                    };
                    match m2533 {
                        Adt28::C0(h2531, _, _, _, _) => {
                            h2531
                        }
                    }
                }, {
                    let m2536 = match v1.clone() {
                        Adt22::C0(_, h2535, _, _, _, _, _, _, _, _) => {
                            h2535
                        }
                    };
                    match m2536 {
                        Adt28::C0(_, h2534, _, _, _) => {
                            h2534
                        }
                    }
                }, {
                    let m2539 = match v1.clone() {
                        Adt22::C0(_, h2538, _, _, _, _, _, _, _, _) => {
                            h2538
                        }
                    };
                    match m2539 {
                        Adt28::C0(_, _, h2537, _, _) => {
                            h2537
                        }
                    }
                }, match v1 {
                    Adt22::C0(_, _, h2540, _, _, _, _, _, _, _) => {
                        h2540
                    }
                }, false)
            }
        }
        Adt54::C4 => {
            let m2543 = match v1.clone() {
                Adt22::C0(_, h2542, _, _, _, _, _, _, _, _) => {
                    h2542
                }
            };
            if if match m2543 {
                Adt28::C0(h2541, _, _, _, _) => {
                    h2541
                }
            } {
                let m2546 = match v1.clone() {
                    Adt22::C0(_, h2545, _, _, _, _, _, _, _, _) => {
                        h2545
                    }
                };
                if match m2546 {
                    Adt28::C0(_, h2544, _, _, _) => {
                        h2544
                    }
                } {
                    let m2549 = match v1.clone() {
                        Adt22::C0(_, h2548, _, _, _, _, _, _, _, _) => {
                            h2548
                        }
                    };
                    if match m2549 {
                        Adt28::C0(_, _, h2547, _, _) => {
                            h2547
                        }
                    } {
                        if match v1.clone() {
                            Adt22::C0(_, _, h2550, _, _, _, _, _, _, _) => {
                                h2550
                            }
                        } {
                            if match v1.clone() {
                                Adt22::C0(_, _, _, h2551, _, _, _, _, _, _) => {
                                    h2551
                                }
                            } {
                                let m2554 = match v1.clone() {
                                    Adt22::C0(_, h2553, _, _, _, _, _, _, _, _) => {
                                        h2553
                                    }
                                };
                                match m2554 {
                                    Adt28::C0(_, _, _, h2552, _) => {
                                        h2552
                                    }
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            } {
                f118(match v1.clone() {
                    Adt22::C0(_, _, _, _, h2555, _, _, _, _, _) => {
                        h2555
                    }
                }, false, f119(match v1 {
                    Adt22::C0(_, _, _, _, _, h2556, _, _, _, _) => {
                        h2556
                    }
                }))
            } else {
                Adt79::C2
            }
        }
        Adt54::C5 => {
            if match v1 {
                Adt22::C0(_, _, _, _, _, _, _, h2557, _, _) => {
                    h2557
                }
            } {
                Adt79::C0
            } else {
                Adt79::C2
            }
        }
        Adt54::C6 => {
            Adt79::C0
        }
        Adt54::C7 => {
            Adt79::C0
        }
        Adt54::C8 => {
            Adt79::C0
        }
        Adt54::C9 => {
            Adt79::C0
        }
    }
}

pub fn f109(v0: Adt5) -> Result<Adt5, Adt44> {
    let m2559 = match v0.clone() {
        Adt5::C0(h2558, _, _, _, _) => {
            h2558
        }
    };
    match m2559 {
        Adt6::C0 => {
            if match v0.clone() {
                Adt5::C0(_, h2560, _, _, _) => {
                    h2560
                }
            } {
                Ok::<Adt5, Adt44>(Adt5::C0(Adt6::C2, match v0.clone() {
                    Adt5::C0(_, h2561, _, _, _) => {
                        h2561
                    }
                }, match v0.clone() {
                    Adt5::C0(_, _, h2562, _, _) => {
                        h2562
                    }
                }, true, match v0 {
                    Adt5::C0(_, _, _, _, h2563) => {
                        h2563
                    }
                }))
            } else {
                Err::<Adt5, Adt44>(Adt44::C3)
            }
        }
        Adt6::C1 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C2 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C3 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
        Adt6::C4 => {
            Err::<Adt5, Adt44>(Adt44::C2)
        }
    }
}

pub fn f110(v0: Adt9) -> bool {
    let m2564 = v0;
    match m2564 {
        Adt9::C0(_) => {
            true
        }
        Adt9::C1(_) => {
            false
        }
        Adt9::C2(_) => {
            false
        }
        Adt9::C3(v4) => {
            let m2566 = match v4 {
                Adt16::C0(_, h2565, _, _) => {
                    h2565
                }
            };
            match m2566 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt9::C4(_) => {
            true
        }
        Adt9::C5(_) => {
            false
        }
        Adt9::C6(_) => {
            false
        }
        Adt9::C7(v9) => {
            let m2568 = match v9 {
                Adt20::C0(_, _, h2567, _) => {
                    h2567
                }
            };
            match m2568 {
                None => {
                    false
                }
                Some(_) => {
                    true
                }
            }
        }
        Adt9::C8(_) => {
            false
        }
        Adt9::C9(_) => {
            false
        }
    }
}

pub fn f111(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m2569 = v0;
    match m2569 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a2574 = {
                let a2572 = v3;
                let a2573 = {
                    let a2570 = v1;
                    let a2571 = v2;
                    nat_add(a2570, a2571)?
                };
                nat_lt(a2572, a2573)
            };
            Ok(bool_not(a2574))
        }
    }
}

pub fn f112(v0: Adt24) -> R<u64> {
    let a2575 = f94(v0.clone())?;
    let a2576 = f95(v0)?;
    nat_add(a2575, a2576)
}

pub fn f113(v0: Adt14, v1: Adt46) -> Option<u64> {
    let m2577 = v1;
    match m2577 {
        Adt46::C0 => {
            match v0 {
                Adt14::C0(_, h2578, _, _, _) => {
                    h2578
                }
            }
        }
        Adt46::C1 => {
            match v0 {
                Adt14::C0(_, _, h2579, _, _) => {
                    h2579
                }
            }
        }
        Adt46::C2 => {
            match v0 {
                Adt14::C0(_, _, _, h2580, _) => {
                    h2580
                }
            }
        }
        Adt46::C3 => {
            match v0 {
                Adt14::C0(_, _, _, _, h2581) => {
                    h2581
                }
            }
        }
    }
}

pub fn f114(v0: Adt25, v1: Adt46) -> u64 {
    let m2582 = v1;
    match m2582 {
        Adt46::C0 => {
            match v0 {
                Adt25::C0(h2583, _, _, _) => {
                    h2583
                }
            }
        }
        Adt46::C1 => {
            match v0 {
                Adt25::C0(_, h2584, _, _) => {
                    h2584
                }
            }
        }
        Adt46::C2 => {
            match v0 {
                Adt25::C0(_, _, h2585, _) => {
                    h2585
                }
            }
        }
        Adt46::C3 => {
            match v0 {
                Adt25::C0(_, _, _, h2586) => {
                    h2586
                }
            }
        }
    }
}

pub fn f115(v0: Adt25, v1: Adt46, v2: u64) -> Adt25 {
    let m2587 = v1;
    match m2587 {
        Adt46::C0 => {
            Adt25::C0(v2, match v0.clone() {
                Adt25::C0(_, h2588, _, _) => {
                    h2588
                }
            }, match v0.clone() {
                Adt25::C0(_, _, h2589, _) => {
                    h2589
                }
            }, match v0 {
                Adt25::C0(_, _, _, h2590) => {
                    h2590
                }
            })
        }
        Adt46::C1 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2591, _, _, _) => {
                    h2591
                }
            }, v2, match v0.clone() {
                Adt25::C0(_, _, h2592, _) => {
                    h2592
                }
            }, match v0 {
                Adt25::C0(_, _, _, h2593) => {
                    h2593
                }
            })
        }
        Adt46::C2 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2594, _, _, _) => {
                    h2594
                }
            }, match v0.clone() {
                Adt25::C0(_, h2595, _, _) => {
                    h2595
                }
            }, v2, match v0 {
                Adt25::C0(_, _, _, h2596) => {
                    h2596
                }
            })
        }
        Adt46::C3 => {
            Adt25::C0(match v0.clone() {
                Adt25::C0(h2597, _, _, _) => {
                    h2597
                }
            }, match v0.clone() {
                Adt25::C0(_, h2598, _, _) => {
                    h2598
                }
            }, match v0 {
                Adt25::C0(_, _, h2599, _) => {
                    h2599
                }
            }, v2)
        }
    }
}

pub fn f116(v0: u64, v1: u64) -> u64 {
    let a2600 = v0;
    let a2601 = v1;
    if nat_lt(a2600, a2601) {
        v1
    } else {
        v0
    }
}

pub fn f117(v0: Adt24, v1: Adt24) -> bool {
    let a2608 = {
        let m2604 = match v0.clone() {
            Adt24::C0(h2603, _, _, _) => {
                h2603
            }
        };
        match m2604 {
            Adt25::C0(h2602, _, _, _) => {
                h2602
            }
        }
    };
    let a2609 = {
        let m2607 = match v1.clone() {
            Adt24::C0(h2606, _, _, _) => {
                h2606
            }
        };
        match m2607 {
            Adt25::C0(h2605, _, _, _) => {
                h2605
            }
        }
    };
    if nat_eq(a2608, a2609) {
        let a2616 = {
            let m2612 = match v0.clone() {
                Adt24::C0(h2611, _, _, _) => {
                    h2611
                }
            };
            match m2612 {
                Adt25::C0(_, h2610, _, _) => {
                    h2610
                }
            }
        };
        let a2617 = {
            let m2615 = match v1.clone() {
                Adt24::C0(h2614, _, _, _) => {
                    h2614
                }
            };
            match m2615 {
                Adt25::C0(_, h2613, _, _) => {
                    h2613
                }
            }
        };
        if nat_eq(a2616, a2617) {
            let a2624 = {
                let m2620 = match v0.clone() {
                    Adt24::C0(h2619, _, _, _) => {
                        h2619
                    }
                };
                match m2620 {
                    Adt25::C0(_, _, h2618, _) => {
                        h2618
                    }
                }
            };
            let a2625 = {
                let m2623 = match v1.clone() {
                    Adt24::C0(h2622, _, _, _) => {
                        h2622
                    }
                };
                match m2623 {
                    Adt25::C0(_, _, h2621, _) => {
                        h2621
                    }
                }
            };
            if nat_eq(a2624, a2625) {
                let a2632 = {
                    let m2628 = match v0.clone() {
                        Adt24::C0(h2627, _, _, _) => {
                            h2627
                        }
                    };
                    match m2628 {
                        Adt25::C0(_, _, _, h2626) => {
                            h2626
                        }
                    }
                };
                let a2633 = {
                    let m2631 = match v1.clone() {
                        Adt24::C0(h2630, _, _, _) => {
                            h2630
                        }
                    };
                    match m2631 {
                        Adt25::C0(_, _, _, h2629) => {
                            h2629
                        }
                    }
                };
                if nat_eq(a2632, a2633) {
                    let a2640 = {
                        let m2636 = match v0.clone() {
                            Adt24::C0(_, h2635, _, _) => {
                                h2635
                            }
                        };
                        match m2636 {
                            Adt25::C0(h2634, _, _, _) => {
                                h2634
                            }
                        }
                    };
                    let a2641 = {
                        let m2639 = match v1.clone() {
                            Adt24::C0(_, h2638, _, _) => {
                                h2638
                            }
                        };
                        match m2639 {
                            Adt25::C0(h2637, _, _, _) => {
                                h2637
                            }
                        }
                    };
                    if nat_eq(a2640, a2641) {
                        let a2648 = {
                            let m2644 = match v0.clone() {
                                Adt24::C0(_, h2643, _, _) => {
                                    h2643
                                }
                            };
                            match m2644 {
                                Adt25::C0(_, h2642, _, _) => {
                                    h2642
                                }
                            }
                        };
                        let a2649 = {
                            let m2647 = match v1.clone() {
                                Adt24::C0(_, h2646, _, _) => {
                                    h2646
                                }
                            };
                            match m2647 {
                                Adt25::C0(_, h2645, _, _) => {
                                    h2645
                                }
                            }
                        };
                        if nat_eq(a2648, a2649) {
                            let a2656 = {
                                let m2652 = match v0.clone() {
                                    Adt24::C0(_, h2651, _, _) => {
                                        h2651
                                    }
                                };
                                match m2652 {
                                    Adt25::C0(_, _, h2650, _) => {
                                        h2650
                                    }
                                }
                            };
                            let a2657 = {
                                let m2655 = match v1.clone() {
                                    Adt24::C0(_, h2654, _, _) => {
                                        h2654
                                    }
                                };
                                match m2655 {
                                    Adt25::C0(_, _, h2653, _) => {
                                        h2653
                                    }
                                }
                            };
                            if nat_eq(a2656, a2657) {
                                let a2664 = {
                                    let m2660 = match v0.clone() {
                                        Adt24::C0(_, h2659, _, _) => {
                                            h2659
                                        }
                                    };
                                    match m2660 {
                                        Adt25::C0(_, _, _, h2658) => {
                                            h2658
                                        }
                                    }
                                };
                                let a2665 = {
                                    let m2663 = match v1.clone() {
                                        Adt24::C0(_, h2662, _, _) => {
                                            h2662
                                        }
                                    };
                                    match m2663 {
                                        Adt25::C0(_, _, _, h2661) => {
                                            h2661
                                        }
                                    }
                                };
                                if nat_eq(a2664, a2665) {
                                    let a2668 = match v0.clone() {
                                        Adt24::C0(_, _, h2666, _) => {
                                            h2666
                                        }
                                    };
                                    let a2669 = match v1.clone() {
                                        Adt24::C0(_, _, h2667, _) => {
                                            h2667
                                        }
                                    };
                                    if nat_eq(a2668, a2669) {
                                        let a2672 = match v0 {
                                            Adt24::C0(_, _, _, h2670) => {
                                                h2670
                                            }
                                        };
                                        let a2673 = match v1 {
                                            Adt24::C0(_, _, _, h2671) => {
                                                h2671
                                            }
                                        };
                                        nat_eq(a2672, a2673)
                                    } else {
                                        false
                                    }
                                } else {
                                    false
                                }
                            } else {
                                false
                            }
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f118(v0: Adt29, v1: bool, v2: Adt80) -> Adt79 {
    let m2674 = v0;
    match m2674 {
        Adt29::C0 => {
            if v1 {
                let m2675 = v2;
                if match m2675 {
                    Adt80::C0 => {
                        false
                    }
                    Adt80::C1 => {
                        true
                    }
                    Adt80::C2 => {
                        false
                    }
                    Adt80::C3 => {
                        false
                    }
                } {
                    Adt79::C0
                } else {
                    Adt79::C4
                }
            } else {
                Adt79::C0
            }
        }
        Adt29::C1 => {
            Adt79::C1
        }
        Adt29::C2 => {
            Adt79::C2
        }
        Adt29::C3 => {
            Adt79::C3
        }
    }
}

pub fn f119(v0: Adt30) -> Adt80 {
    let m2676 = v0;
    match m2676 {
        Adt30::C0 => {
            Adt80::C0
        }
        Adt30::C1(_) => {
            Adt80::C3
        }
        Adt30::C2(_) => {
            Adt80::C2
        }
        Adt30::C3(_) => {
            Adt80::C3
        }
        Adt30::C4(_) => {
            Adt80::C1
        }
    }
}

pub fn f120(v0: bool, v1: bool, v2: bool, v3: bool, v4: bool) -> Adt79 {
    if v4 {
        Adt79::C3
    } else {
        if if v0 {
            if v1 {
                if v2 {
                    if v3 {
                        let a2677 = v4;
                        bool_not(a2677)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        } {
            Adt79::C0
        } else {
            Adt79::C2
        }
    }
}

pub fn run(p0: Adt0, p1: Adt61, p2: Str) -> R<Adt63> {
    f0(p0, p1, p2)
}
