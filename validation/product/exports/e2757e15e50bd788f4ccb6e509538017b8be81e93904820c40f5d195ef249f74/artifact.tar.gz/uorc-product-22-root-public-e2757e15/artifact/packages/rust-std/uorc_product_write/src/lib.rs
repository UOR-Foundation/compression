#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt2, Adt3, Adt4, Adt5, u64, u64, Adt9, Option<Adt10>, Option<Adt11>, Option<Adt12>),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt3 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt4 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Adt6, Option<Adt8>),
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt7, Adt7, u64, u64),
}

#[derive(Clone)]
pub enum Adt7 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, u64, u64),
    C1(Adt3, u64, u64, u64),
    C2(Adt3, u64, u64),
    C3(Adt3, u64, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt1, Adt2, u64, u64, Adt11),
}

#[derive(Clone)]
pub enum Adt11 {
    C0(Adt2, u64, u64),
}

#[derive(Clone)]
pub enum Adt12 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
}

#[derive(Clone)]
pub enum Adt13 {
    C0(Adt0, Option<Adt10>, Option<Adt2>),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Adt3, u64),
    C1(Adt3, u64, u64),
    C2(Adt3, u64, u64),
    C3(Adt3, u64),
    C4(Adt3, u64),
}

pub fn f0(v0: Adt0, v1: Adt11) -> R<Adt13> {
    let m2 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, h1, _, _, _) => {
            h1
        }
    };
    match m2 {
        Adt9::C0 => {
            f1(v0.clone(), v1.clone(), f2(match v0.clone() {
                Adt0::C0(_, _, _, h3, _, _, _, _, _, _, _) => {
                    h3
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, h4, _, _, _, _, _, _) => {
                    h4
                }
            }, Adt14::C0(match v0 {
                Adt0::C0(_, _, h5, _, _, _, _, _, _, _, _) => {
                    h5
                }
            }, match v1 {
                Adt11::C0(_, _, h6) => {
                    h6
                }
            }))?)
        }
        Adt9::C1 => {
            Ok(Adt13::C0(v0, None::<Adt10>, None::<Adt2>))
        }
        Adt9::C2 => {
            Ok(Adt13::C0(v0, None::<Adt10>, None::<Adt2>))
        }
        Adt9::C3 => {
            Ok(Adt13::C0(v0, None::<Adt10>, None::<Adt2>))
        }
        Adt9::C4 => {
            Ok(Adt13::C0(v0, None::<Adt10>, None::<Adt2>))
        }
    }
}

pub fn f1(v0: Adt0, v1: Adt11, v2: Adt5) -> R<Adt13> {
    let m8 = match v2.clone() {
        Adt5::C0(_, h7) => {
            h7
        }
    };
    match m8 {
        None => {
            Ok(Adt13::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h17, _, _, _, _, _, _, _, _, _, _) => {
                    h17
                }
            }, match v0.clone() {
                Adt0::C0(_, h18, _, _, _, _, _, _, _, _, _) => {
                    h18
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h19, _, _, _, _, _, _, _, _) => {
                    h19
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h20, _, _, _, _, _, _, _) => {
                    h20
                }
            }, v2, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h21, _, _, _, _, _) => {
                    h21
                }
            }, {
                let a23 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h22, _, _, _, _) => {
                        h22
                    }
                };
                let a24 = 1u64;
                nat_add(a23, a24)?
            }, Adt9::C1, Some(Adt10::C0(match v0.clone() {
                Adt0::C0(h25, _, _, _, _, _, _, _, _, _, _) => {
                    h25
                }
            }, match v0.clone() {
                Adt0::C0(_, h26, _, _, _, _, _, _, _, _, _) => {
                    h26
                }
            }, {
                let a28 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h27, _, _, _, _) => {
                        h27
                    }
                };
                let a29 = 1u64;
                nat_add(a28, a29)?
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h30, _, _, _, _, _) => {
                    h30
                }
            }, v1.clone())), Some(v1.clone()), match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h31) => {
                    h31
                }
            }), Some(Adt10::C0(match v0.clone() {
                Adt0::C0(h32, _, _, _, _, _, _, _, _, _, _) => {
                    h32
                }
            }, match v0.clone() {
                Adt0::C0(_, h33, _, _, _, _, _, _, _, _, _) => {
                    h33
                }
            }, {
                let a35 = match v0.clone() {
                    Adt0::C0(_, _, _, _, _, _, h34, _, _, _, _) => {
                        h34
                    }
                };
                let a36 = 1u64;
                nat_add(a35, a36)?
            }, match v0 {
                Adt0::C0(_, _, _, _, _, h37, _, _, _, _, _) => {
                    h37
                }
            }, v1)), None::<Adt2>))
        }
        Some(_) => {
            Ok(Adt13::C0(Adt0::C0(match v0.clone() {
                Adt0::C0(h9, _, _, _, _, _, _, _, _, _, _) => {
                    h9
                }
            }, match v0.clone() {
                Adt0::C0(_, h10, _, _, _, _, _, _, _, _, _) => {
                    h10
                }
            }, match v0.clone() {
                Adt0::C0(_, _, h11, _, _, _, _, _, _, _, _) => {
                    h11
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, h12, _, _, _, _, _, _, _) => {
                    h12
                }
            }, v2, match v0.clone() {
                Adt0::C0(_, _, _, _, _, h13, _, _, _, _, _) => {
                    h13
                }
            }, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h14, _, _, _, _) => {
                    h14
                }
            }, Adt9::C4, match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, _, _, h15, _, _) => {
                    h15
                }
            }, Some(v1), match v0 {
                Adt0::C0(_, _, _, _, _, _, _, _, _, _, h16) => {
                    h16
                }
            }), None::<Adt10>, None::<Adt2>))
        }
    }
}

pub fn f2(v0: Adt4, v1: Adt5, v2: Adt14) -> R<Adt5> {
    let m38 = v2;
    match m38 {
        Adt14::C0(v3, v4) => {
            let m40 = f3(v0, match v1.clone() {
                Adt5::C0(h39, _) => {
                    h39
                }
            }, v3, v4)?;
            match m40 {
                Ok(v6) => {
                    Ok(Adt5::C0(v6, None::<Adt8>))
                }
                Err(v5) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h41, _) => {
                            h41
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt14::C1(v7, v8, v9) => {
            let m43 = f4(match v1.clone() {
                Adt5::C0(h42, _) => {
                    h42
                }
            }, v7, v8, v9)?;
            match m43 {
                Ok(v11) => {
                    Ok(Adt5::C0(v11, None::<Adt8>))
                }
                Err(v10) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h44, _) => {
                            h44
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt14::C2(v12, v13, v14) => {
            let m46 = f4(match v1.clone() {
                Adt5::C0(h45, _) => {
                    h45
                }
            }, v12, v13, v14)?;
            match m46 {
                Ok(v16) => {
                    Ok(Adt5::C0(v16, None::<Adt8>))
                }
                Err(v15) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h47, _) => {
                            h47
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt14::C3(v17, v18) => {
            let m49 = f5(match v1.clone() {
                Adt5::C0(h48, _) => {
                    h48
                }
            }, v17, v18)?;
            match m49 {
                Ok(v20) => {
                    Ok(Adt5::C0(v20, None::<Adt8>))
                }
                Err(v19) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h50, _) => {
                            h50
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt14::C4(v21, v22) => {
            let m52 = f5(match v1.clone() {
                Adt5::C0(h51, _) => {
                    h51
                }
            }, v21, v22)?;
            match m52 {
                Ok(v24) => {
                    Ok(Adt5::C0(v24, None::<Adt8>))
                }
                Err(v23) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h53, _) => {
                            h53
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f3(v0: Adt4, v1: Adt6, v2: Adt3, v3: u64) -> R<Result<Adt6, Adt8>> {
    if f6(match v0.clone() {
        Adt4::C0(h54, _, _, _, _) => {
            h54
        }
    }, f7(v1.clone())?, v3)? {
        if f6(f8(v0.clone(), v2.clone()), {
            let a57 = f9(match v1.clone() {
                Adt6::C0(h55, _, _, _) => {
                    h55
                }
            }, v2.clone());
            let a58 = f9(match v1.clone() {
                Adt6::C0(_, h56, _, _) => {
                    h56
                }
            }, v2.clone());
            nat_add(a57, a58)?
        }, v3)? {
            Ok(Ok::<Adt6, Adt8>(Adt6::C0(match v1.clone() {
                Adt6::C0(h59, _, _, _) => {
                    h59
                }
            }, f10(match v1.clone() {
                Adt6::C0(_, h60, _, _) => {
                    h60
                }
            }, v2.clone(), {
                let a62 = f9(match v1.clone() {
                    Adt6::C0(_, h61, _, _) => {
                        h61
                    }
                }, v2.clone());
                let a63 = v3;
                nat_add(a62, a63)?
            }), f11(match v1.clone() {
                Adt6::C0(_, _, h64, _) => {
                    h64
                }
            }, f12(match v1.clone() {
                Adt6::C0(h65, _, _, _) => {
                    h65
                }
            })?), f11(match v1.clone() {
                Adt6::C0(_, _, _, h66) => {
                    h66
                }
            }, {
                let a72 = f12(match v1.clone() {
                    Adt6::C0(h67, _, _, _) => {
                        h67
                    }
                })?;
                let a73 = f12(f10(match v1.clone() {
                    Adt6::C0(_, h68, _, _) => {
                        h68
                    }
                }, v2.clone(), {
                    let a70 = f9(match v1 {
                        Adt6::C0(_, h69, _, _) => {
                            h69
                        }
                    }, v2);
                    let a71 = v3;
                    nat_add(a70, a71)?
                }))?;
                nat_add(a72, a73)?
            }))))
        } else {
            Ok(Err::<Adt6, Adt8>(Adt8::C1(v2.clone(), {
                let a76 = f9(match v1.clone() {
                    Adt6::C0(h74, _, _, _) => {
                        h74
                    }
                }, v2.clone());
                let a77 = f9(match v1 {
                    Adt6::C0(_, h75, _, _) => {
                        h75
                    }
                }, v2.clone());
                nat_add(a76, a77)?
            }, v3, {
                let m78 = f8(v0, v2);
                match m78 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt6, Adt8>(Adt8::C0(f7(v1)?, v3, {
            let m80 = match v0 {
                Adt4::C0(h79, _, _, _, _) => {
                    h79
                }
            };
            match m80 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f4(v0: Adt6, v1: Adt3, v2: u64, v3: u64) -> R<Result<Adt6, Adt8>> {
    let a84 = {
        let a82 = f9(match v0.clone() {
            Adt6::C0(_, h81, _, _) => {
                h81
            }
        }, v1.clone());
        let a83 = v2;
        nat_lt(a82, a83)
    };
    if if bool_not(a84) {
        let a87 = {
            let a85 = v2;
            let a86 = v3;
            nat_lt(a85, a86)
        };
        bool_not(a87)
    } else {
        false
    } {
        Ok(Ok::<Adt6, Adt8>(Adt6::C0(f10(match v0.clone() {
            Adt6::C0(h88, _, _, _) => {
                h88
            }
        }, v1.clone(), {
            let a90 = f9(match v0.clone() {
                Adt6::C0(h89, _, _, _) => {
                    h89
                }
            }, v1.clone());
            let a91 = v3;
            nat_add(a90, a91)?
        }), f10(match v0.clone() {
            Adt6::C0(_, h92, _, _) => {
                h92
            }
        }, v1.clone(), {
            let a94 = f9(match v0.clone() {
                Adt6::C0(_, h93, _, _) => {
                    h93
                }
            }, v1.clone());
            let a95 = v2;
            nat_sub(a94, a95)
        }), f11(match v0.clone() {
            Adt6::C0(_, _, h96, _) => {
                h96
            }
        }, f12(f10(match v0.clone() {
            Adt6::C0(h97, _, _, _) => {
                h97
            }
        }, v1.clone(), {
            let a99 = f9(match v0.clone() {
                Adt6::C0(h98, _, _, _) => {
                    h98
                }
            }, v1.clone());
            let a100 = v3;
            nat_add(a99, a100)?
        }))?), f11(match v0.clone() {
            Adt6::C0(_, _, _, h101) => {
                h101
            }
        }, {
            let a110 = f12(f10(match v0.clone() {
                Adt6::C0(h102, _, _, _) => {
                    h102
                }
            }, v1.clone(), {
                let a104 = f9(match v0.clone() {
                    Adt6::C0(h103, _, _, _) => {
                        h103
                    }
                }, v1.clone());
                let a105 = v3;
                nat_add(a104, a105)?
            }))?;
            let a111 = f12(f10(match v0.clone() {
                Adt6::C0(_, h106, _, _) => {
                    h106
                }
            }, v1.clone(), {
                let a108 = f9(match v0 {
                    Adt6::C0(_, h107, _, _) => {
                        h107
                    }
                }, v1);
                let a109 = v2;
                nat_sub(a108, a109)
            }))?;
            nat_add(a110, a111)?
        }))))
    } else {
        Ok(Err::<Adt6, Adt8>(Adt8::C2(v1, v2, v3)))
    }
}

pub fn f5(v0: Adt6, v1: Adt3, v2: u64) -> R<Result<Adt6, Adt8>> {
    let a115 = {
        let a113 = f9(match v0.clone() {
            Adt6::C0(h112, _, _, _) => {
                h112
            }
        }, v1.clone());
        let a114 = v2;
        nat_lt(a113, a114)
    };
    if bool_not(a115) {
        Ok(Ok::<Adt6, Adt8>(Adt6::C0(f10(match v0.clone() {
            Adt6::C0(h116, _, _, _) => {
                h116
            }
        }, v1.clone(), {
            let a118 = f9(match v0.clone() {
                Adt6::C0(h117, _, _, _) => {
                    h117
                }
            }, v1.clone());
            let a119 = v2;
            nat_sub(a118, a119)
        }), match v0.clone() {
            Adt6::C0(_, h120, _, _) => {
                h120
            }
        }, f11(match v0.clone() {
            Adt6::C0(_, _, h121, _) => {
                h121
            }
        }, f12(f10(match v0.clone() {
            Adt6::C0(h122, _, _, _) => {
                h122
            }
        }, v1.clone(), {
            let a124 = f9(match v0.clone() {
                Adt6::C0(h123, _, _, _) => {
                    h123
                }
            }, v1.clone());
            let a125 = v2;
            nat_sub(a124, a125)
        }))?), f11(match v0.clone() {
            Adt6::C0(_, _, _, h126) => {
                h126
            }
        }, {
            let a132 = f12(f10(match v0.clone() {
                Adt6::C0(h127, _, _, _) => {
                    h127
                }
            }, v1.clone(), {
                let a129 = f9(match v0.clone() {
                    Adt6::C0(h128, _, _, _) => {
                        h128
                    }
                }, v1);
                let a130 = v2;
                nat_sub(a129, a130)
            }))?;
            let a133 = f12(match v0 {
                Adt6::C0(_, h131, _, _) => {
                    h131
                }
            })?;
            nat_add(a132, a133)?
        }))))
    } else {
        Ok(Err::<Adt6, Adt8>(Adt8::C3(v1.clone(), f9(match v0 {
            Adt6::C0(h134, _, _, _) => {
                h134
            }
        }, v1), v2)))
    }
}

pub fn f6(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m135 = v0;
    match m135 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a140 = {
                let a138 = v3;
                let a139 = {
                    let a136 = v1;
                    let a137 = v2;
                    nat_add(a136, a137)?
                };
                nat_lt(a138, a139)
            };
            Ok(bool_not(a140))
        }
    }
}

pub fn f7(v0: Adt6) -> R<u64> {
    let a141 = f13(v0.clone())?;
    let a142 = f14(v0)?;
    nat_add(a141, a142)
}

pub fn f8(v0: Adt4, v1: Adt3) -> Option<u64> {
    let m143 = v1;
    match m143 {
        Adt3::C0 => {
            match v0 {
                Adt4::C0(_, h144, _, _, _) => {
                    h144
                }
            }
        }
        Adt3::C1 => {
            match v0 {
                Adt4::C0(_, _, h145, _, _) => {
                    h145
                }
            }
        }
        Adt3::C2 => {
            match v0 {
                Adt4::C0(_, _, _, h146, _) => {
                    h146
                }
            }
        }
        Adt3::C3 => {
            match v0 {
                Adt4::C0(_, _, _, _, h147) => {
                    h147
                }
            }
        }
    }
}

pub fn f9(v0: Adt7, v1: Adt3) -> u64 {
    let m148 = v1;
    match m148 {
        Adt3::C0 => {
            match v0 {
                Adt7::C0(h149, _, _, _) => {
                    h149
                }
            }
        }
        Adt3::C1 => {
            match v0 {
                Adt7::C0(_, h150, _, _) => {
                    h150
                }
            }
        }
        Adt3::C2 => {
            match v0 {
                Adt7::C0(_, _, h151, _) => {
                    h151
                }
            }
        }
        Adt3::C3 => {
            match v0 {
                Adt7::C0(_, _, _, h152) => {
                    h152
                }
            }
        }
    }
}

pub fn f10(v0: Adt7, v1: Adt3, v2: u64) -> Adt7 {
    let m153 = v1;
    match m153 {
        Adt3::C0 => {
            Adt7::C0(v2, match v0.clone() {
                Adt7::C0(_, h154, _, _) => {
                    h154
                }
            }, match v0.clone() {
                Adt7::C0(_, _, h155, _) => {
                    h155
                }
            }, match v0 {
                Adt7::C0(_, _, _, h156) => {
                    h156
                }
            })
        }
        Adt3::C1 => {
            Adt7::C0(match v0.clone() {
                Adt7::C0(h157, _, _, _) => {
                    h157
                }
            }, v2, match v0.clone() {
                Adt7::C0(_, _, h158, _) => {
                    h158
                }
            }, match v0 {
                Adt7::C0(_, _, _, h159) => {
                    h159
                }
            })
        }
        Adt3::C2 => {
            Adt7::C0(match v0.clone() {
                Adt7::C0(h160, _, _, _) => {
                    h160
                }
            }, match v0.clone() {
                Adt7::C0(_, h161, _, _) => {
                    h161
                }
            }, v2, match v0 {
                Adt7::C0(_, _, _, h162) => {
                    h162
                }
            })
        }
        Adt3::C3 => {
            Adt7::C0(match v0.clone() {
                Adt7::C0(h163, _, _, _) => {
                    h163
                }
            }, match v0.clone() {
                Adt7::C0(_, h164, _, _) => {
                    h164
                }
            }, match v0 {
                Adt7::C0(_, _, h165, _) => {
                    h165
                }
            }, v2)
        }
    }
}

pub fn f11(v0: u64, v1: u64) -> u64 {
    let a166 = v0;
    let a167 = v1;
    if nat_lt(a166, a167) {
        v1
    } else {
        v0
    }
}

pub fn f12(v0: Adt7) -> R<u64> {
    let a178 = {
        let a175 = {
            let a172 = {
                let a169 = 0u64;
                let a170 = match v0.clone() {
                    Adt7::C0(h168, _, _, _) => {
                        h168
                    }
                };
                nat_add(a169, a170)?
            };
            let a173 = match v0.clone() {
                Adt7::C0(_, h171, _, _) => {
                    h171
                }
            };
            nat_add(a172, a173)?
        };
        let a176 = match v0.clone() {
            Adt7::C0(_, _, h174, _) => {
                h174
            }
        };
        nat_add(a175, a176)?
    };
    let a179 = match v0 {
        Adt7::C0(_, _, _, h177) => {
            h177
        }
    };
    nat_add(a178, a179)
}

pub fn f13(v0: Adt6) -> R<u64> {
    f12(match v0 {
        Adt6::C0(h180, _, _, _) => {
            h180
        }
    })
}

pub fn f14(v0: Adt6) -> R<u64> {
    f12(match v0 {
        Adt6::C0(_, h181, _, _) => {
            h181
        }
    })
}

pub fn run(p0: Adt0, p1: Adt11) -> R<Adt13> {
    f0(p0, p1)
}
