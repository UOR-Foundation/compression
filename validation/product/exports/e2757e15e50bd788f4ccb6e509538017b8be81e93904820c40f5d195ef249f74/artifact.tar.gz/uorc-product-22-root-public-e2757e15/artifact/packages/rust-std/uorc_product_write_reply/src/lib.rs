#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt2, Adt3, Adt4, Adt5, u64, u64, Adt9, Option<Adt10>, Option<Adt11>, Option<Adt12>),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt3 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt4 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Adt6, Option<Adt8>),
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt7, Adt7, u64, u64),
}

#[derive(Clone)]
pub enum Adt7 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, u64, u64),
    C1(Adt3, u64, u64, u64),
    C2(Adt3, u64, u64),
    C3(Adt3, u64, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt10 {
    C0(Adt1, Adt2, u64, u64, Adt11),
}

#[derive(Clone)]
pub enum Adt11 {
    C0(Adt2, u64, u64),
}

#[derive(Clone)]
pub enum Adt12 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
}

#[derive(Clone)]
pub enum Adt13 {
    C0(Adt1, Adt2, u64, u64, u64, bool),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Adt0, Option<Adt10>, Option<Adt2>),
}

#[derive(Clone)]
pub enum Adt15 {
    C0(Adt3, u64),
    C1(Adt3, u64, u64),
    C2(Adt3, u64, u64),
    C3(Adt3, u64),
    C4(Adt3, u64),
}

pub fn f0(v0: Adt0, v1: Adt13) -> R<Adt14> {
    let m2 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, _, h1, _, _) => {
            h1
        }
    };
    match m2 {
        None => {
            Ok(Adt14::C0(v0, None::<Adt10>, None::<Adt2>))
        }
        Some(v2) => {
            if f1(v0.clone(), v1.clone()) {
                let a9 = {
                    let a7 = {
                        let m5 = match v2.clone() {
                            Adt10::C0(_, _, _, _, h4) => {
                                h4
                            }
                        };
                        match m5 {
                            Adt11::C0(_, _, h3) => {
                                h3
                            }
                        }
                    };
                    let a8 = match v1.clone() {
                        Adt13::C0(_, _, _, _, h6, _) => {
                            h6
                        }
                    };
                    nat_lt(a7, a8)
                };
                if bool_not(a9) {
                    Ok(Adt14::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h10, _, _, _, _, _, _, _, _, _, _) => {
                            h10
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h11, _, _, _, _, _, _, _, _, _) => {
                            h11
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h12, _, _, _, _, _, _, _, _) => {
                            h12
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h13, _, _, _, _, _, _, _) => {
                            h13
                        }
                    }, f2(match v0.clone() {
                        Adt0::C0(_, _, _, h14, _, _, _, _, _, _, _) => {
                            h14
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h15, _, _, _, _, _, _) => {
                            h15
                        }
                    }, Adt15::C2(match v0.clone() {
                        Adt0::C0(_, _, h16, _, _, _, _, _, _, _, _) => {
                            h16
                        }
                    }, {
                        let m19 = match v2.clone() {
                            Adt10::C0(_, _, _, _, h18) => {
                                h18
                            }
                        };
                        match m19 {
                            Adt11::C0(_, _, h17) => {
                                h17
                            }
                        }
                    }, match v1.clone() {
                        Adt13::C0(_, _, _, _, h20, _) => {
                            h20
                        }
                    }))?, {
                        let a23 = match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h21, _, _, _, _, _) => {
                                h21
                            }
                        };
                        let a24 = match v1.clone() {
                            Adt13::C0(_, _, _, _, h22, _) => {
                                h22
                            }
                        };
                        nat_add(a23, a24)?
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, h25, _, _, _, _) => {
                            h25
                        }
                    }, if if match v1.clone() {
                        Adt13::C0(_, _, _, _, _, h26) => {
                            h26
                        }
                    } {
                        true
                    } else {
                        let a28 = match v1.clone() {
                            Adt13::C0(_, _, _, _, h27, _) => {
                                h27
                            }
                        };
                        let a29 = 0u64;
                        if nat_eq(a28, a29) {
                            let a35 = {
                                let a33 = {
                                    let m32 = match v2.clone() {
                                        Adt10::C0(_, _, _, _, h31) => {
                                            h31
                                        }
                                    };
                                    match m32 {
                                        Adt11::C0(_, _, h30) => {
                                            h30
                                        }
                                    }
                                };
                                let a34 = 0u64;
                                nat_eq(a33, a34)
                            };
                            bool_not(a35)
                        } else {
                            false
                        }
                    } {
                        Adt9::C4
                    } else {
                        Adt9::C0
                    }, None::<Adt10>, {
                        let a40 = match v1.clone() {
                            Adt13::C0(_, _, _, _, h36, _) => {
                                h36
                            }
                        };
                        let a41 = {
                            let m39 = match v2.clone() {
                                Adt10::C0(_, _, _, _, h38) => {
                                    h38
                                }
                            };
                            match m39 {
                                Adt11::C0(_, _, h37) => {
                                    h37
                                }
                            }
                        };
                        if nat_eq(a40, a41) {
                            None::<Adt11>
                        } else {
                            Some(Adt11::C0({
                                let m44 = match v2.clone() {
                                    Adt10::C0(_, _, _, _, h43) => {
                                        h43
                                    }
                                };
                                match m44 {
                                    Adt11::C0(h42, _, _) => {
                                        h42
                                    }
                                }
                            }, {
                                let a49 = {
                                    let m47 = match v2.clone() {
                                        Adt10::C0(_, _, _, _, h46) => {
                                            h46
                                        }
                                    };
                                    match m47 {
                                        Adt11::C0(_, h45, _) => {
                                            h45
                                        }
                                    }
                                };
                                let a50 = match v1.clone() {
                                    Adt13::C0(_, _, _, _, h48, _) => {
                                        h48
                                    }
                                };
                                nat_add(a49, a50)?
                            }, {
                                let a55 = {
                                    let m53 = match v2.clone() {
                                        Adt10::C0(_, _, _, _, h52) => {
                                            h52
                                        }
                                    };
                                    match m53 {
                                        Adt11::C0(_, _, h51) => {
                                            h51
                                        }
                                    }
                                };
                                let a56 = match v1.clone() {
                                    Adt13::C0(_, _, _, _, h54, _) => {
                                        h54
                                    }
                                };
                                nat_sub(a55, a56)
                            }))
                        }
                    }, if if match v1.clone() {
                        Adt13::C0(_, _, _, _, _, h57) => {
                            h57
                        }
                    } {
                        true
                    } else {
                        let a59 = match v1.clone() {
                            Adt13::C0(_, _, _, _, h58, _) => {
                                h58
                            }
                        };
                        let a60 = 0u64;
                        if nat_eq(a59, a60) {
                            let a66 = {
                                let a64 = {
                                    let m63 = match v2.clone() {
                                        Adt10::C0(_, _, _, _, h62) => {
                                            h62
                                        }
                                    };
                                    match m63 {
                                        Adt11::C0(_, _, h61) => {
                                            h61
                                        }
                                    }
                                };
                                let a65 = 0u64;
                                nat_eq(a64, a65)
                            };
                            bool_not(a66)
                        } else {
                            false
                        }
                    } {
                        Some(Adt12::C8)
                    } else {
                        None::<Adt12>
                    }), None::<Adt10>, {
                        let a71 = match v1 {
                            Adt13::C0(_, _, _, _, h67, _) => {
                                h67
                            }
                        };
                        let a72 = {
                            let m70 = match v2.clone() {
                                Adt10::C0(_, _, _, _, h69) => {
                                    h69
                                }
                            };
                            match m70 {
                                Adt11::C0(_, _, h68) => {
                                    h68
                                }
                            }
                        };
                        if nat_eq(a71, a72) {
                            Some({
                                let m75 = match v2 {
                                    Adt10::C0(_, _, _, _, h74) => {
                                        h74
                                    }
                                };
                                match m75 {
                                    Adt11::C0(h73, _, _) => {
                                        h73
                                    }
                                }
                            })
                        } else {
                            None::<Adt2>
                        }
                    }))
                } else {
                    Ok(Adt14::C0(Adt0::C0(match v0.clone() {
                        Adt0::C0(h76, _, _, _, _, _, _, _, _, _, _) => {
                            h76
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, h77, _, _, _, _, _, _, _, _, _) => {
                            h77
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, h78, _, _, _, _, _, _, _, _) => {
                            h78
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, h79, _, _, _, _, _, _, _) => {
                            h79
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, h80, _, _, _, _, _, _) => {
                            h80
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, h81, _, _, _, _, _) => {
                            h81
                        }
                    }, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, h82, _, _, _, _) => {
                            h82
                        }
                    }, Adt9::C4, match v0.clone() {
                        Adt0::C0(_, _, _, _, _, _, _, _, h83, _, _) => {
                            h83
                        }
                    }, match v0 {
                        Adt0::C0(_, _, _, _, _, _, _, _, _, h84, _) => {
                            h84
                        }
                    }, Some(Adt12::C9)), None::<Adt10>, None::<Adt2>))
                }
            } else {
                Ok(Adt14::C0(v0, None::<Adt10>, None::<Adt2>))
            }
        }
    }
}

pub fn f1(v0: Adt0, v1: Adt13) -> bool {
    let m86 = match v0 {
        Adt0::C0(_, _, _, _, _, _, _, _, h85, _, _) => {
            h85
        }
    };
    match m86 {
        None => {
            false
        }
        Some(v2) => {
            if f3(match v2.clone() {
                Adt10::C0(h87, _, _, _, _) => {
                    h87
                }
            }, match v1.clone() {
                Adt13::C0(h88, _, _, _, _, _) => {
                    h88
                }
            }) {
                if f4(match v2.clone() {
                    Adt10::C0(_, h89, _, _, _) => {
                        h89
                    }
                }, match v1.clone() {
                    Adt13::C0(_, h90, _, _, _, _) => {
                        h90
                    }
                }) {
                    let a93 = match v2.clone() {
                        Adt10::C0(_, _, h91, _, _) => {
                            h91
                        }
                    };
                    let a94 = match v1.clone() {
                        Adt13::C0(_, _, h92, _, _, _) => {
                            h92
                        }
                    };
                    if nat_eq(a93, a94) {
                        let a97 = match v2 {
                            Adt10::C0(_, _, _, h95, _) => {
                                h95
                            }
                        };
                        let a98 = match v1 {
                            Adt13::C0(_, _, _, h96, _, _) => {
                                h96
                            }
                        };
                        nat_eq(a97, a98)
                    } else {
                        false
                    }
                } else {
                    false
                }
            } else {
                false
            }
        }
    }
}

pub fn f2(v0: Adt4, v1: Adt5, v2: Adt15) -> R<Adt5> {
    let m99 = v2;
    match m99 {
        Adt15::C0(v3, v4) => {
            let m101 = f5(v0, match v1.clone() {
                Adt5::C0(h100, _) => {
                    h100
                }
            }, v3, v4)?;
            match m101 {
                Ok(v6) => {
                    Ok(Adt5::C0(v6, None::<Adt8>))
                }
                Err(v5) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h102, _) => {
                            h102
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt15::C1(v7, v8, v9) => {
            let m104 = f6(match v1.clone() {
                Adt5::C0(h103, _) => {
                    h103
                }
            }, v7, v8, v9)?;
            match m104 {
                Ok(v11) => {
                    Ok(Adt5::C0(v11, None::<Adt8>))
                }
                Err(v10) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h105, _) => {
                            h105
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt15::C2(v12, v13, v14) => {
            let m107 = f6(match v1.clone() {
                Adt5::C0(h106, _) => {
                    h106
                }
            }, v12, v13, v14)?;
            match m107 {
                Ok(v16) => {
                    Ok(Adt5::C0(v16, None::<Adt8>))
                }
                Err(v15) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h108, _) => {
                            h108
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt15::C3(v17, v18) => {
            let m110 = f7(match v1.clone() {
                Adt5::C0(h109, _) => {
                    h109
                }
            }, v17, v18)?;
            match m110 {
                Ok(v20) => {
                    Ok(Adt5::C0(v20, None::<Adt8>))
                }
                Err(v19) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h111, _) => {
                            h111
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt15::C4(v21, v22) => {
            let m113 = f7(match v1.clone() {
                Adt5::C0(h112, _) => {
                    h112
                }
            }, v21, v22)?;
            match m113 {
                Ok(v24) => {
                    Ok(Adt5::C0(v24, None::<Adt8>))
                }
                Err(v23) => {
                    Ok(Adt5::C0(match v1 {
                        Adt5::C0(h114, _) => {
                            h114
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f3(v0: Adt1, v1: Adt1) -> bool {
    let a117 = match v0.clone() {
        Adt1::C0(h115, _, _) => {
            h115
        }
    };
    let a118 = match v1.clone() {
        Adt1::C0(h116, _, _) => {
            h116
        }
    };
    if nat_eq(a117, a118) {
        let a121 = match v0.clone() {
            Adt1::C0(_, h119, _) => {
                h119
            }
        };
        let a122 = match v1.clone() {
            Adt1::C0(_, h120, _) => {
                h120
            }
        };
        if nat_eq(a121, a122) {
            let a125 = match v0 {
                Adt1::C0(_, _, h123) => {
                    h123
                }
            };
            let a126 = match v1 {
                Adt1::C0(_, _, h124) => {
                    h124
                }
            };
            nat_eq(a125, a126)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f4(v0: Adt2, v1: Adt2) -> bool {
    let a129 = match v0.clone() {
        Adt2::C0(h127, _, _) => {
            h127
        }
    };
    let a130 = match v1.clone() {
        Adt2::C0(h128, _, _) => {
            h128
        }
    };
    if nat_eq(a129, a130) {
        let a133 = match v0.clone() {
            Adt2::C0(_, h131, _) => {
                h131
            }
        };
        let a134 = match v1.clone() {
            Adt2::C0(_, h132, _) => {
                h132
            }
        };
        if nat_eq(a133, a134) {
            let a137 = match v0 {
                Adt2::C0(_, _, h135) => {
                    h135
                }
            };
            let a138 = match v1 {
                Adt2::C0(_, _, h136) => {
                    h136
                }
            };
            nat_eq(a137, a138)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f5(v0: Adt4, v1: Adt6, v2: Adt3, v3: u64) -> R<Result<Adt6, Adt8>> {
    if f8(match v0.clone() {
        Adt4::C0(h139, _, _, _, _) => {
            h139
        }
    }, f9(v1.clone())?, v3)? {
        if f8(f10(v0.clone(), v2.clone()), {
            let a142 = f11(match v1.clone() {
                Adt6::C0(h140, _, _, _) => {
                    h140
                }
            }, v2.clone());
            let a143 = f11(match v1.clone() {
                Adt6::C0(_, h141, _, _) => {
                    h141
                }
            }, v2.clone());
            nat_add(a142, a143)?
        }, v3)? {
            Ok(Ok::<Adt6, Adt8>(Adt6::C0(match v1.clone() {
                Adt6::C0(h144, _, _, _) => {
                    h144
                }
            }, f12(match v1.clone() {
                Adt6::C0(_, h145, _, _) => {
                    h145
                }
            }, v2.clone(), {
                let a147 = f11(match v1.clone() {
                    Adt6::C0(_, h146, _, _) => {
                        h146
                    }
                }, v2.clone());
                let a148 = v3;
                nat_add(a147, a148)?
            }), f13(match v1.clone() {
                Adt6::C0(_, _, h149, _) => {
                    h149
                }
            }, f14(match v1.clone() {
                Adt6::C0(h150, _, _, _) => {
                    h150
                }
            })?), f13(match v1.clone() {
                Adt6::C0(_, _, _, h151) => {
                    h151
                }
            }, {
                let a157 = f14(match v1.clone() {
                    Adt6::C0(h152, _, _, _) => {
                        h152
                    }
                })?;
                let a158 = f14(f12(match v1.clone() {
                    Adt6::C0(_, h153, _, _) => {
                        h153
                    }
                }, v2.clone(), {
                    let a155 = f11(match v1 {
                        Adt6::C0(_, h154, _, _) => {
                            h154
                        }
                    }, v2);
                    let a156 = v3;
                    nat_add(a155, a156)?
                }))?;
                nat_add(a157, a158)?
            }))))
        } else {
            Ok(Err::<Adt6, Adt8>(Adt8::C1(v2.clone(), {
                let a161 = f11(match v1.clone() {
                    Adt6::C0(h159, _, _, _) => {
                        h159
                    }
                }, v2.clone());
                let a162 = f11(match v1 {
                    Adt6::C0(_, h160, _, _) => {
                        h160
                    }
                }, v2.clone());
                nat_add(a161, a162)?
            }, v3, {
                let m163 = f10(v0, v2);
                match m163 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt6, Adt8>(Adt8::C0(f9(v1)?, v3, {
            let m165 = match v0 {
                Adt4::C0(h164, _, _, _, _) => {
                    h164
                }
            };
            match m165 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f6(v0: Adt6, v1: Adt3, v2: u64, v3: u64) -> R<Result<Adt6, Adt8>> {
    let a169 = {
        let a167 = f11(match v0.clone() {
            Adt6::C0(_, h166, _, _) => {
                h166
            }
        }, v1.clone());
        let a168 = v2;
        nat_lt(a167, a168)
    };
    if if bool_not(a169) {
        let a172 = {
            let a170 = v2;
            let a171 = v3;
            nat_lt(a170, a171)
        };
        bool_not(a172)
    } else {
        false
    } {
        Ok(Ok::<Adt6, Adt8>(Adt6::C0(f12(match v0.clone() {
            Adt6::C0(h173, _, _, _) => {
                h173
            }
        }, v1.clone(), {
            let a175 = f11(match v0.clone() {
                Adt6::C0(h174, _, _, _) => {
                    h174
                }
            }, v1.clone());
            let a176 = v3;
            nat_add(a175, a176)?
        }), f12(match v0.clone() {
            Adt6::C0(_, h177, _, _) => {
                h177
            }
        }, v1.clone(), {
            let a179 = f11(match v0.clone() {
                Adt6::C0(_, h178, _, _) => {
                    h178
                }
            }, v1.clone());
            let a180 = v2;
            nat_sub(a179, a180)
        }), f13(match v0.clone() {
            Adt6::C0(_, _, h181, _) => {
                h181
            }
        }, f14(f12(match v0.clone() {
            Adt6::C0(h182, _, _, _) => {
                h182
            }
        }, v1.clone(), {
            let a184 = f11(match v0.clone() {
                Adt6::C0(h183, _, _, _) => {
                    h183
                }
            }, v1.clone());
            let a185 = v3;
            nat_add(a184, a185)?
        }))?), f13(match v0.clone() {
            Adt6::C0(_, _, _, h186) => {
                h186
            }
        }, {
            let a195 = f14(f12(match v0.clone() {
                Adt6::C0(h187, _, _, _) => {
                    h187
                }
            }, v1.clone(), {
                let a189 = f11(match v0.clone() {
                    Adt6::C0(h188, _, _, _) => {
                        h188
                    }
                }, v1.clone());
                let a190 = v3;
                nat_add(a189, a190)?
            }))?;
            let a196 = f14(f12(match v0.clone() {
                Adt6::C0(_, h191, _, _) => {
                    h191
                }
            }, v1.clone(), {
                let a193 = f11(match v0 {
                    Adt6::C0(_, h192, _, _) => {
                        h192
                    }
                }, v1);
                let a194 = v2;
                nat_sub(a193, a194)
            }))?;
            nat_add(a195, a196)?
        }))))
    } else {
        Ok(Err::<Adt6, Adt8>(Adt8::C2(v1, v2, v3)))
    }
}

pub fn f7(v0: Adt6, v1: Adt3, v2: u64) -> R<Result<Adt6, Adt8>> {
    let a200 = {
        let a198 = f11(match v0.clone() {
            Adt6::C0(h197, _, _, _) => {
                h197
            }
        }, v1.clone());
        let a199 = v2;
        nat_lt(a198, a199)
    };
    if bool_not(a200) {
        Ok(Ok::<Adt6, Adt8>(Adt6::C0(f12(match v0.clone() {
            Adt6::C0(h201, _, _, _) => {
                h201
            }
        }, v1.clone(), {
            let a203 = f11(match v0.clone() {
                Adt6::C0(h202, _, _, _) => {
                    h202
                }
            }, v1.clone());
            let a204 = v2;
            nat_sub(a203, a204)
        }), match v0.clone() {
            Adt6::C0(_, h205, _, _) => {
                h205
            }
        }, f13(match v0.clone() {
            Adt6::C0(_, _, h206, _) => {
                h206
            }
        }, f14(f12(match v0.clone() {
            Adt6::C0(h207, _, _, _) => {
                h207
            }
        }, v1.clone(), {
            let a209 = f11(match v0.clone() {
                Adt6::C0(h208, _, _, _) => {
                    h208
                }
            }, v1.clone());
            let a210 = v2;
            nat_sub(a209, a210)
        }))?), f13(match v0.clone() {
            Adt6::C0(_, _, _, h211) => {
                h211
            }
        }, {
            let a217 = f14(f12(match v0.clone() {
                Adt6::C0(h212, _, _, _) => {
                    h212
                }
            }, v1.clone(), {
                let a214 = f11(match v0.clone() {
                    Adt6::C0(h213, _, _, _) => {
                        h213
                    }
                }, v1);
                let a215 = v2;
                nat_sub(a214, a215)
            }))?;
            let a218 = f14(match v0 {
                Adt6::C0(_, h216, _, _) => {
                    h216
                }
            })?;
            nat_add(a217, a218)?
        }))))
    } else {
        Ok(Err::<Adt6, Adt8>(Adt8::C3(v1.clone(), f11(match v0 {
            Adt6::C0(h219, _, _, _) => {
                h219
            }
        }, v1), v2)))
    }
}

pub fn f8(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m220 = v0;
    match m220 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a225 = {
                let a223 = v3;
                let a224 = {
                    let a221 = v1;
                    let a222 = v2;
                    nat_add(a221, a222)?
                };
                nat_lt(a223, a224)
            };
            Ok(bool_not(a225))
        }
    }
}

pub fn f9(v0: Adt6) -> R<u64> {
    let a226 = f15(v0.clone())?;
    let a227 = f16(v0)?;
    nat_add(a226, a227)
}

pub fn f10(v0: Adt4, v1: Adt3) -> Option<u64> {
    let m228 = v1;
    match m228 {
        Adt3::C0 => {
            match v0 {
                Adt4::C0(_, h229, _, _, _) => {
                    h229
                }
            }
        }
        Adt3::C1 => {
            match v0 {
                Adt4::C0(_, _, h230, _, _) => {
                    h230
                }
            }
        }
        Adt3::C2 => {
            match v0 {
                Adt4::C0(_, _, _, h231, _) => {
                    h231
                }
            }
        }
        Adt3::C3 => {
            match v0 {
                Adt4::C0(_, _, _, _, h232) => {
                    h232
                }
            }
        }
    }
}

pub fn f11(v0: Adt7, v1: Adt3) -> u64 {
    let m233 = v1;
    match m233 {
        Adt3::C0 => {
            match v0 {
                Adt7::C0(h234, _, _, _) => {
                    h234
                }
            }
        }
        Adt3::C1 => {
            match v0 {
                Adt7::C0(_, h235, _, _) => {
                    h235
                }
            }
        }
        Adt3::C2 => {
            match v0 {
                Adt7::C0(_, _, h236, _) => {
                    h236
                }
            }
        }
        Adt3::C3 => {
            match v0 {
                Adt7::C0(_, _, _, h237) => {
                    h237
                }
            }
        }
    }
}

pub fn f12(v0: Adt7, v1: Adt3, v2: u64) -> Adt7 {
    let m238 = v1;
    match m238 {
        Adt3::C0 => {
            Adt7::C0(v2, match v0.clone() {
                Adt7::C0(_, h239, _, _) => {
                    h239
                }
            }, match v0.clone() {
                Adt7::C0(_, _, h240, _) => {
                    h240
                }
            }, match v0 {
                Adt7::C0(_, _, _, h241) => {
                    h241
                }
            })
        }
        Adt3::C1 => {
            Adt7::C0(match v0.clone() {
                Adt7::C0(h242, _, _, _) => {
                    h242
                }
            }, v2, match v0.clone() {
                Adt7::C0(_, _, h243, _) => {
                    h243
                }
            }, match v0 {
                Adt7::C0(_, _, _, h244) => {
                    h244
                }
            })
        }
        Adt3::C2 => {
            Adt7::C0(match v0.clone() {
                Adt7::C0(h245, _, _, _) => {
                    h245
                }
            }, match v0.clone() {
                Adt7::C0(_, h246, _, _) => {
                    h246
                }
            }, v2, match v0 {
                Adt7::C0(_, _, _, h247) => {
                    h247
                }
            })
        }
        Adt3::C3 => {
            Adt7::C0(match v0.clone() {
                Adt7::C0(h248, _, _, _) => {
                    h248
                }
            }, match v0.clone() {
                Adt7::C0(_, h249, _, _) => {
                    h249
                }
            }, match v0 {
                Adt7::C0(_, _, h250, _) => {
                    h250
                }
            }, v2)
        }
    }
}

pub fn f13(v0: u64, v1: u64) -> u64 {
    let a251 = v0;
    let a252 = v1;
    if nat_lt(a251, a252) {
        v1
    } else {
        v0
    }
}

pub fn f14(v0: Adt7) -> R<u64> {
    let a263 = {
        let a260 = {
            let a257 = {
                let a254 = 0u64;
                let a255 = match v0.clone() {
                    Adt7::C0(h253, _, _, _) => {
                        h253
                    }
                };
                nat_add(a254, a255)?
            };
            let a258 = match v0.clone() {
                Adt7::C0(_, h256, _, _) => {
                    h256
                }
            };
            nat_add(a257, a258)?
        };
        let a261 = match v0.clone() {
            Adt7::C0(_, _, h259, _) => {
                h259
            }
        };
        nat_add(a260, a261)?
    };
    let a264 = match v0 {
        Adt7::C0(_, _, _, h262) => {
            h262
        }
    };
    nat_add(a263, a264)
}

pub fn f15(v0: Adt6) -> R<u64> {
    f14(match v0 {
        Adt6::C0(h265, _, _, _) => {
            h265
        }
    })
}

pub fn f16(v0: Adt6) -> R<u64> {
    f14(match v0 {
        Adt6::C0(_, h266, _, _) => {
            h266
        }
    })
}

pub fn run(p0: Adt0, p1: Adt13) -> R<Adt14> {
    f0(p0, p1)
}
