#![forbid(unsafe_code)]
use core::cmp::Ordering;

use core::sync::atomic::{AtomicU64, Ordering as Memory};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Overflow;

pub type R<T> = Result<T, Overflow>;

static WORK: AtomicU64 = AtomicU64::new(0);

pub fn tick(units: u64) { WORK.fetch_add(units, Memory::Relaxed); }

pub fn work() -> u64 { WORK.load(Memory::Relaxed) }

pub trait Same {
    fn same(&self, other: &Self) -> bool;
}

pub trait Key {
    fn key(&self, other: &Self) -> Ordering;
}

impl Same for bool {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for bool {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for u64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for u64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i8 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i8 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i16 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i16 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i32 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i32 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for i64 {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl Key for i64 {
    fn key(&self, other: &Self) -> Ordering { self.cmp(other) }
}

impl Same for Ordering {
    fn same(&self, other: &Self) -> bool { self == other }
}

impl<A: Key, B: Key> Key for (A, B) {
    fn key(&self, other: &Self) -> Ordering { match self.0.key(&other.0) { Ordering::Equal => self.1.key(&other.1), decided => decided, } }
}

pub fn equal<T: Same>(a: T, b: T) -> bool { a.same(&b) }

pub fn compare<T: Key>(a: T, b: T) -> Ordering { a.key(&b) }

pub fn nat_add(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_sub(p0: u64, p1: u64) -> u64 {
    u64::saturating_sub(p0, p1)
}

pub fn nat_mul(p0: u64, p1: u64) -> R<u64> {
    match u64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn nat_quot(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_div(p0, p1).unwrap_or(p2)
}

pub fn nat_rem(p0: u64, p1: u64, p2: u64) -> u64 {
    u64::checked_rem(p0, p1).unwrap_or(p2)
}

pub fn nat_eq(p0: u64, p1: u64) -> bool {
    core::cmp::PartialEq::eq(&p0, &p1)
}

pub fn nat_le(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::le(&p0, &p1)
}

pub fn nat_lt(p0: u64, p1: u64) -> bool {
    core::cmp::PartialOrd::lt(&p0, &p1)
}

pub fn nat_succ(p0: u64) -> R<u64> {
    match u64::checked_add(p0, 1u64) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<u64, Overflow>(Overflow)
        }
    }
}

pub fn int_add(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_add(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_sub(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_sub(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_mul(p0: i64, p1: i64) -> R<i64> {
    match i64::checked_mul(p0, p1) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_neg(p0: i64) -> R<i64> {
    match i64::checked_neg(p0) {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    }
}

pub fn int_quot(p0: i64, p1: i64, p2: i64) -> R<i64> {
    { let value = { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { Some(z) } else { a.checked_div(b) } }; match value {
        Some(v0) => {
            Ok(v0)
        }
        None => {
            Err::<i64, Overflow>(Overflow)
        }
    } }
}

pub fn int_rem(p0: i64, p1: i64, p2: i64) -> i64 {
    { let (a, b, z): (i64, i64, i64) = (p0, p1, p2); if b == 0 { z } else { a.wrapping_rem(b) } }
}

pub fn bool_not(p0: bool) -> bool {
    !p0
}

pub fn bool_and(p0: bool, p1: bool) -> bool {
    if p0 {
        p1
    } else {
        false
    }
}

pub fn bool_or(p0: bool, p1: bool) -> bool {
    if p0 {
        true
    } else {
        p1
    }
}

pub mod fixed_u8 {
    pub fn checked_add(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u8, p1: u8) -> Option<u8> {
        u8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u8, p1: u8) -> u8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u8, p1: u8) -> u8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u8, p1: u8) -> u8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u8) -> u8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u8, p1: u32) -> Option<u8> {
        u8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u8> {
        u8::try_from(p0).ok()
    }
}

pub mod fixed_u16 {
    pub fn checked_add(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u16, p1: u16) -> Option<u16> {
        u16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u16, p1: u16) -> u16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u16, p1: u16) -> u16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u16, p1: u16) -> u16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u16) -> u16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u16, p1: u32) -> Option<u16> {
        u16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u16> {
        u16::try_from(p0).ok()
    }
}

pub mod fixed_u32 {
    pub fn checked_add(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u32, p1: u32) -> u32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u32, p1: u32) -> u32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u32, p1: u32) -> u32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u32) -> u32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u32, p1: u32) -> Option<u32> {
        u32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u32> {
        u32::try_from(p0).ok()
    }
}

pub mod fixed_u64 {
    pub fn checked_add(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: u64, p1: u64) -> Option<u64> {
        u64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: u64, p1: u64) -> u64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: u64, p1: u64) -> u64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: u64, p1: u64) -> u64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: u64) -> u64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: u64, p1: u32) -> Option<u64> {
        u64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<u64> {
        u64::try_from(p0).ok()
    }
}

pub mod fixed_i8 {
    pub fn checked_add(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i8, p1: i8) -> Option<i8> {
        i8::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i8, p1: i8) -> i8 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i8, p1: i8) -> i8 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i8, p1: i8) -> i8 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i8) -> i8 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i8, p1: u32) -> Option<i8> {
        i8::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i8> {
        i8::try_from(p0).ok()
    }
}

pub fn checked_neg_i8(p0: i8) -> Option<i8> {
    i8::checked_neg(p0)
}

pub mod fixed_i16 {
    pub fn checked_add(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i16, p1: i16) -> Option<i16> {
        i16::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i16, p1: i16) -> i16 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i16, p1: i16) -> i16 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i16, p1: i16) -> i16 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i16) -> i16 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i16, p1: u32) -> Option<i16> {
        i16::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i16> {
        i16::try_from(p0).ok()
    }
}

pub fn checked_neg_i16(p0: i16) -> Option<i16> {
    i16::checked_neg(p0)
}

pub mod fixed_i32 {
    pub fn checked_add(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i32, p1: i32) -> Option<i32> {
        i32::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i32, p1: i32) -> i32 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i32, p1: i32) -> i32 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i32, p1: i32) -> i32 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i32) -> i32 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i32, p1: u32) -> Option<i32> {
        i32::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i32> {
        i32::try_from(p0).ok()
    }
}

pub fn checked_neg_i32(p0: i32) -> Option<i32> {
    i32::checked_neg(p0)
}

pub mod fixed_i64 {
    pub fn checked_add(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_add(p0, p1)
    }

    pub fn checked_sub(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_sub(p0, p1)
    }

    pub fn checked_mul(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_mul(p0, p1)
    }

    pub fn checked_quot(p0: i64, p1: i64) -> Option<i64> {
        i64::checked_div(p0, p1)
    }

    pub fn bit_and(p0: i64, p1: i64) -> i64 {
        core::ops::BitAnd::bitand(p0, p1)
    }

    pub fn bit_or(p0: i64, p1: i64) -> i64 {
        core::ops::BitOr::bitor(p0, p1)
    }

    pub fn bit_xor(p0: i64, p1: i64) -> i64 {
        core::ops::BitXor::bitxor(p0, p1)
    }

    pub fn bit_not(p0: i64) -> i64 {
        core::ops::Not::not(p0)
    }

    pub fn shift_left(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shl(p0, p1)
    }

    pub fn shift_right(p0: i64, p1: u32) -> Option<i64> {
        i64::checked_shr(p0, p1)
    }

    pub fn convert(p0: i128) -> Option<i64> {
        i64::try_from(p0).ok()
    }
}

pub fn checked_neg_i64(p0: i64) -> Option<i64> {
    i64::checked_neg(p0)
}
use core::str;

use std::mem;

use std::rc::Rc;

#[derive(Clone)]
pub struct Str(Rc<str>);

impl Str {
    pub fn lit(text: &str) -> Str { Str(Rc::from(text)) }
    pub fn text(&self) -> &str { &self.0 }
    pub fn length(&self) -> u64 { chars(&self.0) }
    pub fn utf8_encode(&self) -> Bytes { tick(self.0.len() as u64); Bytes::lit(self.0.as_bytes()) }
    pub fn split_exact(&self, delimiter: &Str, maximum: u32) -> Option<List<Str>> { if delimiter.0.is_empty() { return None; }; chars(&self.0); let mut fields: Vec<Str> = Vec::new(); for piece in self.0.split(&*delimiter.0) { fields.push(Str::lit(piece)); }; if fields.len() as u128 > u128::from(maximum) { return None; }; Some(List::onto(fields, List::nil())) }
    pub fn join(texts: List<Str>, delimiter: &Str) -> Str { let mut out = String::new(); let mut first = true; let mut cursor = &texts; while let Repr::Cell(cell) = &cursor.0 { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&cell.head.0); out.push_str(&cell.head.0); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for text in buffer[..*len].iter().rev() { tick(1); if !first { chars(&delimiter.0); out.push_str(&delimiter.0); }; first = false; chars(&text.0); out.push_str(&text.0); } }, _ => { }, }; Str::lit(&out) }
}

#[derive(Clone)]
pub struct Bytes(Rc<[u8]>);

impl Bytes {
    pub fn lit(octets: &[u8]) -> Bytes { Bytes(Rc::from(octets)) }
    pub fn octets(&self) -> &[u8] { &self.0 }
    pub fn append(a: Bytes, b: Bytes) -> Bytes { tick((a.0.len() + b.0.len()) as u64); let mut out = Vec::with_capacity(a.0.len() + b.0.len()); out.extend_from_slice(&a.0); out.extend_from_slice(&b.0); Bytes(Rc::from(out)) }
    pub fn length(&self) -> u64 { self.0.len() as u64 }
    pub fn index(&self, i: u64) -> Option<u8> { match usize::try_from(i) { Ok(at) => self.0.get(at).copied(), Err(_) => None, } }
    pub fn slice(&self, start: u64, count: u64) -> Option<Bytes> { let end = u128::from(start) + u128::from(count); if end > self.0.len() as u128 { return None; }; tick(count); Some(Bytes::lit(&self.0[start as usize..end as usize])) }
    pub fn utf8_decode(&self) -> Option<Str> { tick(self.0.len() as u64); match str::from_utf8(&self.0) { Ok(text) => Some(Str::lit(text)), Err(_) => None, } }
    pub fn compare(&self, other: &Bytes) -> Ordering { tick(1 + self.0.len().min(other.0.len()) as u64); self.0.cmp(&other.0) }
}

pub struct Node<T> { head: T, tail: List<T> }

pub enum Repr<T> { Nil, Run { buffer: Rc<Vec<T>>, len: usize }, Cell(Rc<Node<T>>) }

pub struct List<T>(Repr<T>);

impl<T> Clone for List<T> {
    fn clone(&self) -> Self { List(match &self.0 { Repr::Nil => Repr::Nil, Repr::Run { buffer, len } => Repr::Run { buffer: buffer.clone(), len: *len }, Repr::Cell(cell) => Repr::Cell(cell.clone()), }) }
}

impl<T> List<T> {
    fn take(&mut self) -> Repr<T> { mem::replace(&mut self.0, Repr::Nil) }
}

impl<T> Drop for Node<T> {
    fn drop(&mut self) { let mut next = match self.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }; while let Some(cell) = next { match Rc::try_unwrap(cell) { Ok(mut node) => next = match node.tail.take() { Repr::Cell(cell) => Some(cell), _ => None, }, Err(_) => break, } } }
}

impl<T: Clone> List<T> {
    pub fn nil() -> Self { List(Repr::Nil) }
    pub fn cons(head: T, mut tail: List<T>) -> Self { List(match tail.take() { Repr::Nil => { let mut buffer = Vec::with_capacity(16); buffer.push(head); Repr::Run { buffer: Rc::new(buffer), len: 1 } }, Repr::Run { mut buffer, len } => { match Rc::get_mut(&mut buffer) { Some(cells) => { cells.truncate(len); cells.push(head); Repr::Run { buffer, len: len + 1 } }, None => Repr::Cell(Rc::new(Node { head, tail: List(Repr::Run { buffer, len }) })), } }, rest => Repr::Cell(Rc::new(Node { head, tail: List(rest) })), }) }
    pub fn uncons(&self) -> Option<(T, List<T>)> { match &self.0 { Repr::Nil => None, Repr::Run { buffer, len } => { let head = buffer[len - 1].clone(); Some((head, List(if *len == 1 { Repr::Nil } else { Repr::Run { buffer: buffer.clone(), len: len - 1 } }))) }, Repr::Cell(cell) => Some((cell.head.clone(), cell.tail.clone())), } }
    pub fn length(&self) -> u64 { let mut count = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); count += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for _ in buffer[..*len].iter().rev() { tick(1); count += 1; } }, _ => { }, }; count }
    pub fn append(a: List<T>, b: List<T>) -> List<T> { List::onto(a.items(), b) }
    pub fn index(&self, i: u64) -> Option<T> { let mut position = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position == i { return Some(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position == i { return Some(item.clone()); }; position += 1; } }, _ => { }, }; None }
    pub fn slice(&self, start: u64, count: u64) -> Option<List<T>> { let end = u128::from(start) + u128::from(count); let mut part = Vec::new(); let mut position: u128 = 0; let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(cell.head.clone()); }; position += 1; cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); if position >= end { return Some(List::onto(part, List::nil())); }; if position >= u128::from(start) { part.push(item.clone()); }; position += 1; } }, _ => { }, }; if position < end { None } else { Some(List::onto(part, List::nil())) } }
    fn items(&self) -> Vec<T> { let mut out = Vec::new(); let mut cursor = self; while let Repr::Cell(cell) = &cursor.0 { tick(1); out.push(cell.head.clone()); cursor = &cell.tail; }; match &cursor.0 { Repr::Run { buffer, len } => { for item in buffer[..*len].iter().rev() { tick(1); out.push(item.clone()); } }, _ => { }, }; out }
    fn onto(mut items: Vec<T>, tail: List<T>) -> List<T> { let mut out = tail; while let Some(item) = items.pop() { tick(1); out = List::cons(item, out); }; out }
}

pub fn chars(text: &str) -> u64 { let mut count = 0; for _ in text.chars() { tick(1); count += 1; }; count }

impl Same for Str {
    fn same(&self, other: &Self) -> bool { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return true, (a, b) if a != b => return false, _ => { }, } } }
}

impl Same for Bytes {
    fn same(&self, other: &Self) -> bool { tick(1 + self.0.len().min(other.0.len()) as u64); self.0 == other.0 }
}

impl Key for Str {
    fn key(&self, other: &Self) -> Ordering { let mut left = self.0.chars(); let mut right = other.0.chars(); loop { tick(1); match (left.next(), right.next()) { (None, None) => return Ordering::Equal, (None, Some(_)) => return Ordering::Less, (Some(_), None) => return Ordering::Greater, (Some(a), Some(b)) => match a.cmp(&b) { Ordering::Equal => { }, decided => return decided, }, } } }
}

pub fn canonical_decimal(text: &str) -> Option<Option<i128>> { let digits = match text.strip_prefix('-') { Some(rest) => rest, None => text, }; let mut canonical = !digits.is_empty() && (digits == "0" || !digits.starts_with('0')) && text != "-0"; for c in digits.chars() { tick(1); canonical = canonical && c.is_ascii_digit(); }; if !canonical { return None; }; Some(text.parse::<i128>().ok()) }

pub fn parse_int(text: Str) -> R<Option<i64>> { match canonical_decimal(&text.0) { None => Ok(None), Some(Some(n)) => match i64::try_from(n) { Ok(value) => Ok(Some(value)), Err(_) => Err(Overflow), }, Some(None) => Err(Overflow), } }

pub fn format_u8(a: u8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u8(text: Str) -> Option<u8> { match canonical_decimal(&text.0) { Some(Some(n)) => u8::try_from(n).ok(), _ => None, } }

pub fn format_u16(a: u16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u16(text: Str) -> Option<u16> { match canonical_decimal(&text.0) { Some(Some(n)) => u16::try_from(n).ok(), _ => None, } }

pub fn format_u32(a: u32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u32(text: Str) -> Option<u32> { match canonical_decimal(&text.0) { Some(Some(n)) => u32::try_from(n).ok(), _ => None, } }

pub fn format_u64(a: u64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_u64(text: Str) -> Option<u64> { match canonical_decimal(&text.0) { Some(Some(n)) => u64::try_from(n).ok(), _ => None, } }

pub fn format_i8(a: i8) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i8(text: Str) -> Option<i8> { match canonical_decimal(&text.0) { Some(Some(n)) => i8::try_from(n).ok(), _ => None, } }

pub fn format_i16(a: i16) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i16(text: Str) -> Option<i16> { match canonical_decimal(&text.0) { Some(Some(n)) => i16::try_from(n).ok(), _ => None, } }

pub fn format_i32(a: i32) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i32(text: Str) -> Option<i32> { match canonical_decimal(&text.0) { Some(Some(n)) => i32::try_from(n).ok(), _ => None, } }

pub fn format_i64(a: i64) -> Str { let text = a.to_string(); tick(text.len() as u64); Str::lit(&text) }

pub fn parse_i64(text: Str) -> Option<i64> { match canonical_decimal(&text.0) { Some(Some(n)) => i64::try_from(n).ok(), _ => None, } }

pub fn append_list<T: Clone>(p0: List<T>, p1: List<T>) -> List<T> {
    List::append(p0, p1)
}

pub fn length_list<T: Clone>(p0: List<T>) -> u64 {
    List::length(&p0)
}

pub fn index_list<T: Clone>(p0: List<T>, p1: u64) -> Option<T> {
    List::index(&p0, p1)
}

pub fn slice_list<T: Clone>(p0: List<T>, p1: u64, p2: u64) -> Option<List<T>> {
    List::slice(&p0, p1, p2)
}

pub fn append_bytes(p0: Bytes, p1: Bytes) -> Bytes {
    Bytes::append(p0, p1)
}

pub fn length_bytes(p0: Bytes) -> u64 {
    Bytes::length(&p0)
}

pub fn length_string(p0: Str) -> u64 {
    Str::length(&p0)
}

pub fn index_bytes(p0: Bytes, p1: u64) -> Option<u8> {
    Bytes::index(&p0, p1)
}

pub fn slice_bytes(p0: Bytes, p1: u64, p2: u64) -> Option<Bytes> {
    Bytes::slice(&p0, p1, p2)
}

pub fn utf8_encode(p0: Str) -> Bytes {
    Str::utf8_encode(&p0)
}

pub fn utf8_decode(p0: Bytes) -> Option<Str> {
    Bytes::utf8_decode(&p0)
}

pub fn compare_bytes(p0: Bytes, p1: Bytes) -> Ordering {
    Bytes::compare(&p0, &p1)
}

pub fn split_exact(p0: Str, p1: Str, p2: u32) -> Option<List<Str>> {
    Str::split_exact(&p0, &p1, p2)
}

pub fn join(p0: List<Str>, p1: Str) -> Str {
    Str::join(p0, &p1)
}

#[derive(Clone)]
pub enum Adt0 {
    C0(Adt1, Adt2, u64, Adt5, Adt6, Adt11, Option<Adt16>, Adt19, Option<Adt2>, bool, bool),
}

#[derive(Clone)]
pub enum Adt1 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt2 {
    C0(Adt3, Option<u64>, Adt4),
}

#[derive(Clone)]
pub enum Adt3 {
    C0(u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt4 {
    C0,
    C1,
}

#[derive(Clone)]
pub enum Adt5 {
    C0(Option<u64>, Option<u64>, Option<u64>, Option<u64>, Option<u64>),
}

#[derive(Clone)]
pub enum Adt6 {
    C0(Adt7, Option<Adt9>),
}

#[derive(Clone)]
pub enum Adt7 {
    C0(Adt8, Adt8, u64, u64),
}

#[derive(Clone)]
pub enum Adt8 {
    C0(u64, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt9 {
    C0(u64, u64, u64),
    C1(Adt10, u64, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64, u64),
}

#[derive(Clone)]
pub enum Adt10 {
    C0,
    C1,
    C2,
    C3,
}

#[derive(Clone)]
pub enum Adt11 {
    C0(Adt1, Adt2, u64, u64, u64, Adt12, Option<Adt13>, Option<Adt14>, bool, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt12 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
}

#[derive(Clone)]
pub enum Adt13 {
    C0(Adt1, Adt3, u64, u64, u64),
}

#[derive(Clone)]
pub enum Adt14 {
    C0(Adt3, u64, u64),
}

#[derive(Clone)]
pub enum Adt15 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
    C9,
    C10,
    C11,
}

#[derive(Clone)]
pub enum Adt16 {
    C0(Adt1, Adt3, Adt10, Adt5, Adt6, u64, u64, Adt17, Option<Adt18>, Option<Adt14>, Option<Adt15>),
}

#[derive(Clone)]
pub enum Adt17 {
    C0,
    C1,
    C2,
    C3,
    C4,
}

#[derive(Clone)]
pub enum Adt18 {
    C0(Adt1, Adt3, u64, u64, Adt14),
}

#[derive(Clone)]
pub enum Adt19 {
    C0,
    C1,
    C2,
    C3,
    C4,
    C5,
    C6,
    C7,
    C8,
}

#[derive(Clone)]
pub enum Adt20 {
    C0(Adt0, List<Adt21>),
}

#[derive(Clone)]
pub enum Adt21 {
    C0(Adt1),
    C1(Adt13),
    C2(Adt18),
    C3(Adt3, u64),
    C4(Adt3),
    C5(Adt1),
    C6(Adt1, Adt3, u64),
    C7(Adt13),
}

#[derive(Clone)]
pub enum Adt22 {
    C0(Adt10, u64),
    C1(Adt10, u64, u64),
    C2(Adt10, u64, u64),
    C3(Adt10, u64),
    C4(Adt10, u64),
}

pub fn f0(v0: Adt0, v1: Adt1, v2: Adt3, v3: u64) -> R<Adt20> {
    let m2 = match v0.clone() {
        Adt0::C0(_, _, _, _, _, _, _, h1, _, _, _) => {
            h1
        }
    };
    match m2 {
        Adt19::C0 => {
            Ok(Adt20::C0(v0, List::<Adt21>::nil()))
        }
        Adt19::C1 => {
            Ok(Adt20::C0(v0, List::<Adt21>::nil()))
        }
        Adt19::C2 => {
            Ok(Adt20::C0(v0, List::<Adt21>::nil()))
        }
        Adt19::C3 => {
            Ok(Adt20::C0(v0, List::<Adt21>::nil()))
        }
        Adt19::C4 => {
            Ok(Adt20::C0(v0, List::<Adt21>::nil()))
        }
        Adt19::C5 => {
            Ok(Adt20::C0(v0, List::<Adt21>::nil()))
        }
        Adt19::C6 => {
            let m4 = match v0.clone() {
                Adt0::C0(_, _, _, _, _, _, h3, _, _, _, _) => {
                    h3
                }
            };
            match m4 {
                None => {
                    Ok(Adt20::C0(v0, List::<Adt21>::nil()))
                }
                Some(v4) => {
                    if if f1(match v0.clone() {
                        Adt0::C0(h5, _, _, _, _, _, _, _, _, _, _) => {
                            h5
                        }
                    }, v1) {
                        if f2(match v4.clone() {
                            Adt16::C0(_, h6, _, _, _, _, _, _, _, _, _) => {
                                h6
                            }
                        }, v2) {
                            let a10 = {
                                let a8 = match v4.clone() {
                                    Adt16::C0(_, _, _, _, _, h7, _, _, _, _, _) => {
                                        h7
                                    }
                                };
                                let a9 = v3;
                                nat_lt(a8, a9)
                            };
                            bool_not(a10)
                        } else {
                            false
                        }
                    } else {
                        false
                    } {
                        Ok(Adt20::C0(Adt0::C0(match v0.clone() {
                            Adt0::C0(h11, _, _, _, _, _, _, _, _, _, _) => {
                                h11
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, h12, _, _, _, _, _, _, _, _, _) => {
                                h12
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, h13, _, _, _, _, _, _, _, _) => {
                                h13
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, h14, _, _, _, _, _, _, _) => {
                                h14
                            }
                        }, f3(match v0.clone() {
                            Adt0::C0(_, _, _, h15, _, _, _, _, _, _, _) => {
                                h15
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, h16, _, _, _, _, _, _) => {
                                h16
                            }
                        }, Adt22::C3(Adt10::C1, v3))?, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, h17, _, _, _, _, _) => {
                                h17
                            }
                        }, {
                            let a19 = match v4.clone() {
                                Adt16::C0(_, _, _, _, _, h18, _, _, _, _, _) => {
                                    h18
                                }
                            };
                            let a20 = v3;
                            if nat_eq(a19, a20) {
                                None::<Adt16>
                            } else {
                                Some(Adt16::C0(match v4.clone() {
                                    Adt16::C0(h21, _, _, _, _, _, _, _, _, _, _) => {
                                        h21
                                    }
                                }, match v4.clone() {
                                    Adt16::C0(_, h22, _, _, _, _, _, _, _, _, _) => {
                                        h22
                                    }
                                }, match v4.clone() {
                                    Adt16::C0(_, _, h23, _, _, _, _, _, _, _, _) => {
                                        h23
                                    }
                                }, match v4.clone() {
                                    Adt16::C0(_, _, _, h24, _, _, _, _, _, _, _) => {
                                        h24
                                    }
                                }, f3(match v0.clone() {
                                    Adt0::C0(_, _, _, h25, _, _, _, _, _, _, _) => {
                                        h25
                                    }
                                }, match v0.clone() {
                                    Adt0::C0(_, _, _, _, h26, _, _, _, _, _, _) => {
                                        h26
                                    }
                                }, Adt22::C3(Adt10::C1, v3))?, {
                                    let a28 = match v4.clone() {
                                        Adt16::C0(_, _, _, _, _, h27, _, _, _, _, _) => {
                                            h27
                                        }
                                    };
                                    let a29 = v3;
                                    nat_sub(a28, a29)
                                }, match v4.clone() {
                                    Adt16::C0(_, _, _, _, _, _, h30, _, _, _, _) => {
                                        h30
                                    }
                                }, match v4.clone() {
                                    Adt16::C0(_, _, _, _, _, _, _, h31, _, _, _) => {
                                        h31
                                    }
                                }, match v4.clone() {
                                    Adt16::C0(_, _, _, _, _, _, _, _, h32, _, _) => {
                                        h32
                                    }
                                }, match v4.clone() {
                                    Adt16::C0(_, _, _, _, _, _, _, _, _, h33, _) => {
                                        h33
                                    }
                                }, match v4.clone() {
                                    Adt16::C0(_, _, _, _, _, _, _, _, _, _, h34) => {
                                        h34
                                    }
                                }))
                            }
                        }, {
                            let a36 = match v4 {
                                Adt16::C0(_, _, _, _, _, h35, _, _, _, _, _) => {
                                    h35
                                }
                            };
                            let a37 = v3;
                            if nat_eq(a36, a37) {
                                Adt19::C7
                            } else {
                                Adt19::C8
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, h38, _, _) => {
                                h38
                            }
                        }, match v0.clone() {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, h39, _) => {
                                h39
                            }
                        }, match v0 {
                            Adt0::C0(_, _, _, _, _, _, _, _, _, _, h40) => {
                                h40
                            }
                        }), List::<Adt21>::nil()))
                    } else {
                        Ok(Adt20::C0(v0, List::<Adt21>::nil()))
                    }
                }
            }
        }
        Adt19::C7 => {
            Ok(Adt20::C0(v0, List::<Adt21>::nil()))
        }
        Adt19::C8 => {
            Ok(Adt20::C0(v0, List::<Adt21>::nil()))
        }
    }
}

pub fn f1(v0: Adt1, v1: Adt1) -> bool {
    let a43 = match v0.clone() {
        Adt1::C0(h41, _, _) => {
            h41
        }
    };
    let a44 = match v1.clone() {
        Adt1::C0(h42, _, _) => {
            h42
        }
    };
    if nat_eq(a43, a44) {
        let a47 = match v0.clone() {
            Adt1::C0(_, h45, _) => {
                h45
            }
        };
        let a48 = match v1.clone() {
            Adt1::C0(_, h46, _) => {
                h46
            }
        };
        if nat_eq(a47, a48) {
            let a51 = match v0 {
                Adt1::C0(_, _, h49) => {
                    h49
                }
            };
            let a52 = match v1 {
                Adt1::C0(_, _, h50) => {
                    h50
                }
            };
            nat_eq(a51, a52)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f2(v0: Adt3, v1: Adt3) -> bool {
    let a55 = match v0.clone() {
        Adt3::C0(h53, _, _) => {
            h53
        }
    };
    let a56 = match v1.clone() {
        Adt3::C0(h54, _, _) => {
            h54
        }
    };
    if nat_eq(a55, a56) {
        let a59 = match v0.clone() {
            Adt3::C0(_, h57, _) => {
                h57
            }
        };
        let a60 = match v1.clone() {
            Adt3::C0(_, h58, _) => {
                h58
            }
        };
        if nat_eq(a59, a60) {
            let a63 = match v0 {
                Adt3::C0(_, _, h61) => {
                    h61
                }
            };
            let a64 = match v1 {
                Adt3::C0(_, _, h62) => {
                    h62
                }
            };
            nat_eq(a63, a64)
        } else {
            false
        }
    } else {
        false
    }
}

pub fn f3(v0: Adt5, v1: Adt6, v2: Adt22) -> R<Adt6> {
    let m65 = v2;
    match m65 {
        Adt22::C0(v3, v4) => {
            let m67 = f4(v0, match v1.clone() {
                Adt6::C0(h66, _) => {
                    h66
                }
            }, v3, v4)?;
            match m67 {
                Ok(v6) => {
                    Ok(Adt6::C0(v6, None::<Adt9>))
                }
                Err(v5) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h68, _) => {
                            h68
                        }
                    }, Some(v5)))
                }
            }
        }
        Adt22::C1(v7, v8, v9) => {
            let m70 = f5(match v1.clone() {
                Adt6::C0(h69, _) => {
                    h69
                }
            }, v7, v8, v9)?;
            match m70 {
                Ok(v11) => {
                    Ok(Adt6::C0(v11, None::<Adt9>))
                }
                Err(v10) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h71, _) => {
                            h71
                        }
                    }, Some(v10)))
                }
            }
        }
        Adt22::C2(v12, v13, v14) => {
            let m73 = f5(match v1.clone() {
                Adt6::C0(h72, _) => {
                    h72
                }
            }, v12, v13, v14)?;
            match m73 {
                Ok(v16) => {
                    Ok(Adt6::C0(v16, None::<Adt9>))
                }
                Err(v15) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h74, _) => {
                            h74
                        }
                    }, Some(v15)))
                }
            }
        }
        Adt22::C3(v17, v18) => {
            let m76 = f6(match v1.clone() {
                Adt6::C0(h75, _) => {
                    h75
                }
            }, v17, v18)?;
            match m76 {
                Ok(v20) => {
                    Ok(Adt6::C0(v20, None::<Adt9>))
                }
                Err(v19) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h77, _) => {
                            h77
                        }
                    }, Some(v19)))
                }
            }
        }
        Adt22::C4(v21, v22) => {
            let m79 = f6(match v1.clone() {
                Adt6::C0(h78, _) => {
                    h78
                }
            }, v21, v22)?;
            match m79 {
                Ok(v24) => {
                    Ok(Adt6::C0(v24, None::<Adt9>))
                }
                Err(v23) => {
                    Ok(Adt6::C0(match v1 {
                        Adt6::C0(h80, _) => {
                            h80
                        }
                    }, Some(v23)))
                }
            }
        }
    }
}

pub fn f4(v0: Adt5, v1: Adt7, v2: Adt10, v3: u64) -> R<Result<Adt7, Adt9>> {
    if f7(match v0.clone() {
        Adt5::C0(h81, _, _, _, _) => {
            h81
        }
    }, f8(v1.clone())?, v3)? {
        if f7(f9(v0.clone(), v2.clone()), {
            let a84 = f10(match v1.clone() {
                Adt7::C0(h82, _, _, _) => {
                    h82
                }
            }, v2.clone());
            let a85 = f10(match v1.clone() {
                Adt7::C0(_, h83, _, _) => {
                    h83
                }
            }, v2.clone());
            nat_add(a84, a85)?
        }, v3)? {
            Ok(Ok::<Adt7, Adt9>(Adt7::C0(match v1.clone() {
                Adt7::C0(h86, _, _, _) => {
                    h86
                }
            }, f11(match v1.clone() {
                Adt7::C0(_, h87, _, _) => {
                    h87
                }
            }, v2.clone(), {
                let a89 = f10(match v1.clone() {
                    Adt7::C0(_, h88, _, _) => {
                        h88
                    }
                }, v2.clone());
                let a90 = v3;
                nat_add(a89, a90)?
            }), f12(match v1.clone() {
                Adt7::C0(_, _, h91, _) => {
                    h91
                }
            }, f13(match v1.clone() {
                Adt7::C0(h92, _, _, _) => {
                    h92
                }
            })?), f12(match v1.clone() {
                Adt7::C0(_, _, _, h93) => {
                    h93
                }
            }, {
                let a99 = f13(match v1.clone() {
                    Adt7::C0(h94, _, _, _) => {
                        h94
                    }
                })?;
                let a100 = f13(f11(match v1.clone() {
                    Adt7::C0(_, h95, _, _) => {
                        h95
                    }
                }, v2.clone(), {
                    let a97 = f10(match v1 {
                        Adt7::C0(_, h96, _, _) => {
                            h96
                        }
                    }, v2);
                    let a98 = v3;
                    nat_add(a97, a98)?
                }))?;
                nat_add(a99, a100)?
            }))))
        } else {
            Ok(Err::<Adt7, Adt9>(Adt9::C1(v2.clone(), {
                let a103 = f10(match v1.clone() {
                    Adt7::C0(h101, _, _, _) => {
                        h101
                    }
                }, v2.clone());
                let a104 = f10(match v1 {
                    Adt7::C0(_, h102, _, _) => {
                        h102
                    }
                }, v2.clone());
                nat_add(a103, a104)?
            }, v3, {
                let m105 = f9(v0, v2);
                match m105 {
                    None => {
                        0u64
                    }
                    Some(v4) => {
                        v4
                    }
                }
            })))
        }
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C0(f8(v1)?, v3, {
            let m107 = match v0 {
                Adt5::C0(h106, _, _, _, _) => {
                    h106
                }
            };
            match m107 {
                None => {
                    0u64
                }
                Some(v5) => {
                    v5
                }
            }
        })))
    }
}

pub fn f5(v0: Adt7, v1: Adt10, v2: u64, v3: u64) -> R<Result<Adt7, Adt9>> {
    let a111 = {
        let a109 = f10(match v0.clone() {
            Adt7::C0(_, h108, _, _) => {
                h108
            }
        }, v1.clone());
        let a110 = v2;
        nat_lt(a109, a110)
    };
    if if bool_not(a111) {
        let a114 = {
            let a112 = v2;
            let a113 = v3;
            nat_lt(a112, a113)
        };
        bool_not(a114)
    } else {
        false
    } {
        Ok(Ok::<Adt7, Adt9>(Adt7::C0(f11(match v0.clone() {
            Adt7::C0(h115, _, _, _) => {
                h115
            }
        }, v1.clone(), {
            let a117 = f10(match v0.clone() {
                Adt7::C0(h116, _, _, _) => {
                    h116
                }
            }, v1.clone());
            let a118 = v3;
            nat_add(a117, a118)?
        }), f11(match v0.clone() {
            Adt7::C0(_, h119, _, _) => {
                h119
            }
        }, v1.clone(), {
            let a121 = f10(match v0.clone() {
                Adt7::C0(_, h120, _, _) => {
                    h120
                }
            }, v1.clone());
            let a122 = v2;
            nat_sub(a121, a122)
        }), f12(match v0.clone() {
            Adt7::C0(_, _, h123, _) => {
                h123
            }
        }, f13(f11(match v0.clone() {
            Adt7::C0(h124, _, _, _) => {
                h124
            }
        }, v1.clone(), {
            let a126 = f10(match v0.clone() {
                Adt7::C0(h125, _, _, _) => {
                    h125
                }
            }, v1.clone());
            let a127 = v3;
            nat_add(a126, a127)?
        }))?), f12(match v0.clone() {
            Adt7::C0(_, _, _, h128) => {
                h128
            }
        }, {
            let a137 = f13(f11(match v0.clone() {
                Adt7::C0(h129, _, _, _) => {
                    h129
                }
            }, v1.clone(), {
                let a131 = f10(match v0.clone() {
                    Adt7::C0(h130, _, _, _) => {
                        h130
                    }
                }, v1.clone());
                let a132 = v3;
                nat_add(a131, a132)?
            }))?;
            let a138 = f13(f11(match v0.clone() {
                Adt7::C0(_, h133, _, _) => {
                    h133
                }
            }, v1.clone(), {
                let a135 = f10(match v0 {
                    Adt7::C0(_, h134, _, _) => {
                        h134
                    }
                }, v1);
                let a136 = v2;
                nat_sub(a135, a136)
            }))?;
            nat_add(a137, a138)?
        }))))
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C2(v1, v2, v3)))
    }
}

pub fn f6(v0: Adt7, v1: Adt10, v2: u64) -> R<Result<Adt7, Adt9>> {
    let a142 = {
        let a140 = f10(match v0.clone() {
            Adt7::C0(h139, _, _, _) => {
                h139
            }
        }, v1.clone());
        let a141 = v2;
        nat_lt(a140, a141)
    };
    if bool_not(a142) {
        Ok(Ok::<Adt7, Adt9>(Adt7::C0(f11(match v0.clone() {
            Adt7::C0(h143, _, _, _) => {
                h143
            }
        }, v1.clone(), {
            let a145 = f10(match v0.clone() {
                Adt7::C0(h144, _, _, _) => {
                    h144
                }
            }, v1.clone());
            let a146 = v2;
            nat_sub(a145, a146)
        }), match v0.clone() {
            Adt7::C0(_, h147, _, _) => {
                h147
            }
        }, f12(match v0.clone() {
            Adt7::C0(_, _, h148, _) => {
                h148
            }
        }, f13(f11(match v0.clone() {
            Adt7::C0(h149, _, _, _) => {
                h149
            }
        }, v1.clone(), {
            let a151 = f10(match v0.clone() {
                Adt7::C0(h150, _, _, _) => {
                    h150
                }
            }, v1.clone());
            let a152 = v2;
            nat_sub(a151, a152)
        }))?), f12(match v0.clone() {
            Adt7::C0(_, _, _, h153) => {
                h153
            }
        }, {
            let a159 = f13(f11(match v0.clone() {
                Adt7::C0(h154, _, _, _) => {
                    h154
                }
            }, v1.clone(), {
                let a156 = f10(match v0.clone() {
                    Adt7::C0(h155, _, _, _) => {
                        h155
                    }
                }, v1);
                let a157 = v2;
                nat_sub(a156, a157)
            }))?;
            let a160 = f13(match v0 {
                Adt7::C0(_, h158, _, _) => {
                    h158
                }
            })?;
            nat_add(a159, a160)?
        }))))
    } else {
        Ok(Err::<Adt7, Adt9>(Adt9::C3(v1.clone(), f10(match v0 {
            Adt7::C0(h161, _, _, _) => {
                h161
            }
        }, v1), v2)))
    }
}

pub fn f7(v0: Option<u64>, v1: u64, v2: u64) -> R<bool> {
    let m162 = v0;
    match m162 {
        None => {
            Ok(true)
        }
        Some(v3) => {
            let a167 = {
                let a165 = v3;
                let a166 = {
                    let a163 = v1;
                    let a164 = v2;
                    nat_add(a163, a164)?
                };
                nat_lt(a165, a166)
            };
            Ok(bool_not(a167))
        }
    }
}

pub fn f8(v0: Adt7) -> R<u64> {
    let a168 = f14(v0.clone())?;
    let a169 = f15(v0)?;
    nat_add(a168, a169)
}

pub fn f9(v0: Adt5, v1: Adt10) -> Option<u64> {
    let m170 = v1;
    match m170 {
        Adt10::C0 => {
            match v0 {
                Adt5::C0(_, h171, _, _, _) => {
                    h171
                }
            }
        }
        Adt10::C1 => {
            match v0 {
                Adt5::C0(_, _, h172, _, _) => {
                    h172
                }
            }
        }
        Adt10::C2 => {
            match v0 {
                Adt5::C0(_, _, _, h173, _) => {
                    h173
                }
            }
        }
        Adt10::C3 => {
            match v0 {
                Adt5::C0(_, _, _, _, h174) => {
                    h174
                }
            }
        }
    }
}

pub fn f10(v0: Adt8, v1: Adt10) -> u64 {
    let m175 = v1;
    match m175 {
        Adt10::C0 => {
            match v0 {
                Adt8::C0(h176, _, _, _) => {
                    h176
                }
            }
        }
        Adt10::C1 => {
            match v0 {
                Adt8::C0(_, h177, _, _) => {
                    h177
                }
            }
        }
        Adt10::C2 => {
            match v0 {
                Adt8::C0(_, _, h178, _) => {
                    h178
                }
            }
        }
        Adt10::C3 => {
            match v0 {
                Adt8::C0(_, _, _, h179) => {
                    h179
                }
            }
        }
    }
}

pub fn f11(v0: Adt8, v1: Adt10, v2: u64) -> Adt8 {
    let m180 = v1;
    match m180 {
        Adt10::C0 => {
            Adt8::C0(v2, match v0.clone() {
                Adt8::C0(_, h181, _, _) => {
                    h181
                }
            }, match v0.clone() {
                Adt8::C0(_, _, h182, _) => {
                    h182
                }
            }, match v0 {
                Adt8::C0(_, _, _, h183) => {
                    h183
                }
            })
        }
        Adt10::C1 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h184, _, _, _) => {
                    h184
                }
            }, v2, match v0.clone() {
                Adt8::C0(_, _, h185, _) => {
                    h185
                }
            }, match v0 {
                Adt8::C0(_, _, _, h186) => {
                    h186
                }
            })
        }
        Adt10::C2 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h187, _, _, _) => {
                    h187
                }
            }, match v0.clone() {
                Adt8::C0(_, h188, _, _) => {
                    h188
                }
            }, v2, match v0 {
                Adt8::C0(_, _, _, h189) => {
                    h189
                }
            })
        }
        Adt10::C3 => {
            Adt8::C0(match v0.clone() {
                Adt8::C0(h190, _, _, _) => {
                    h190
                }
            }, match v0.clone() {
                Adt8::C0(_, h191, _, _) => {
                    h191
                }
            }, match v0 {
                Adt8::C0(_, _, h192, _) => {
                    h192
                }
            }, v2)
        }
    }
}

pub fn f12(v0: u64, v1: u64) -> u64 {
    let a193 = v0;
    let a194 = v1;
    if nat_lt(a193, a194) {
        v1
    } else {
        v0
    }
}

pub fn f13(v0: Adt8) -> R<u64> {
    let a205 = {
        let a202 = {
            let a199 = {
                let a196 = 0u64;
                let a197 = match v0.clone() {
                    Adt8::C0(h195, _, _, _) => {
                        h195
                    }
                };
                nat_add(a196, a197)?
            };
            let a200 = match v0.clone() {
                Adt8::C0(_, h198, _, _) => {
                    h198
                }
            };
            nat_add(a199, a200)?
        };
        let a203 = match v0.clone() {
            Adt8::C0(_, _, h201, _) => {
                h201
            }
        };
        nat_add(a202, a203)?
    };
    let a206 = match v0 {
        Adt8::C0(_, _, _, h204) => {
            h204
        }
    };
    nat_add(a205, a206)
}

pub fn f14(v0: Adt7) -> R<u64> {
    f13(match v0 {
        Adt7::C0(h207, _, _, _) => {
            h207
        }
    })
}

pub fn f15(v0: Adt7) -> R<u64> {
    f13(match v0 {
        Adt7::C0(_, h208, _, _) => {
            h208
        }
    })
}

pub fn run(p0: Adt0, p1: Adt1, p2: Adt3, p3: u64) -> R<Adt20> {
    f0(p0, p1, p2, p3)
}
