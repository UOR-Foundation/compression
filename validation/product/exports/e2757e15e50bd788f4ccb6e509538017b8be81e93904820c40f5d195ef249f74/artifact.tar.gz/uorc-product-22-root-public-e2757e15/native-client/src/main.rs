use uorc_product_create as create;
use uorc_product_focus_id as focus;
fn main() {
    for instance in [0, 1, 17, u64::MAX] {
        let create::Adt0::C0(control, _, serial, _, _, _, edit) = create::run(instance);
        let create::Adt1::C0(actual, _, _, _, request, report, _, staged, pending, transferred, _, _, checkpoint, attached, closed, _, _, retained, _, _, _) = control;
        assert_eq!(actual, instance);
        assert_eq!(serial, 0);
        assert!(request.is_none() && report.is_none() && staged.is_none() && checkpoint.is_none() && edit.is_none());
        assert!(attached && !closed && !pending && !transferred && !retained);
    }
    assert!(focus::equal(focus::run(focus::Adt0::C2), focus::Str::lit("status")));
    assert!(focus::equal(focus::run(focus::Adt0::C0(focus::Adt1::C0)), focus::Str::lit("file-input")));
    println!("4 generated native Workspace constructors and 2 generated focus roots passed; all 22 packages compiled");
}
