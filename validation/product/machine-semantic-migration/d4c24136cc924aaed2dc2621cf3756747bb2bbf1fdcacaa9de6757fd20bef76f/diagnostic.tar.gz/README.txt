Source-only Machine semantic migration checkpoint

Both exact45-source projections, configuration/locks, every declared generated output, official SDK runtime Lean inputs, existing source check/build results, raw public7cf dependencies and frozen raw Product inputs are retained. Minimal and shared projection identities are separate. Comparison evidence reverses only carrier shape and alpha-normalizes binders, ignoring axiom metadata.

The51 typed controls are SOURCE-CHECKED ONLY and UNEXECUTED. New broad axiom annotations are UNAUDITED. The earlier kernel compilation fails at Core.ReferenceSemantics.leaf_index_step_refines_independent_sequence; failing source and generated module match final shared build exactly. No final kernel rerun, VM, native/ABI, pinned SDK, accepted export or current whole-integration acceptance is asserted. No dataStreamer or source implementation was added by packaging.
