from pathlib import Path
import json,subprocess,re,shutil,sys
repo=Path('captured-inputs/compression-product');root=Path('captured-inputs/product-binding-semantic');root.mkdir(exist_ok=True);base=Path('captured-inputs/product-read-image-diagnostic');mode=sys.argv[1] if len(sys.argv)>1 else 'exact';root=root if mode=='exact' else Path('captured-inputs/product-binding-semantic-shared' if mode=='shared' else 'captured-inputs/product-binding-semantic-minimal');root.mkdir(exist_ok=True)
for n in ['lakefile.toml','lean-toolchain']:shutil.copyfile(base/n,root/n)
(root/'lexlean.toml').write_text((base/'lexlean.toml').read_text().replace('product-read-image-diagnostic',root.name).replace('ReadImageScenarios.lex.tex','MachineBindingScenarios.lex.tex'))
core=set(json.load(open('tooling/machine-7cf-dependencies.json'))['modules']);todo=['Uorc.Product.MachineBindingScenarios'];seen=set();paths=[];manifest=[]
while todo:
 m=todo.pop()
 if m in seen:continue
 seen.add(m);rel=Path('src',*m.split('.')).with_suffix('.lex.tex')
 external=m in core if mode=='exact' else m in ['Uorc.Core.RuntimeMachineEngine','Uorc.Core.RuntimeMachineSemantic']
 if external:
  s=subprocess.run(['git','show','7cf135da579abb7f3012184ccc9c253496259f99:'+str(rel)],cwd=repo,capture_output=True,text=True,check=True).stdout
 elif mode=='shared' and m.startswith('Uorc.Core.'):
  shared=subprocess.run(['git','show','29d25233a2565157dc0bd39acc497f620c567788:'+str(rel)],cwd=repo,capture_output=True,text=True)
  s=shared.stdout if shared.returncode==0 else (repo/rel).read_text()
 else:s=(repo/rel).read_text()
 todo+=re.findall(r'\\importmodule\{([^}]+)\}',s);q=root/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s);paths.append(str(q));manifest.append(dict(module=m,path=str(rel),authority='public Machine7cf135da' if external else 'public shared29d25233 Core' if mode!='exact' and m.startswith('Uorc.Core.') else 'current product checkout'))
subprocess.run(['product-notation-conversion',*paths],check=True)
(root/'composition.json').write_text(json.dumps(manifest,indent=2,sort_keys=True));print('Synced',len(paths),mode,'source modules')
