from pathlib import Path
import json,re
repo=Path('captured-inputs/compression-product');old=json.load(open('tooling/ComparisonOwner-pre-semantic.json'));p=repo/'src/Uorc/Product/ComparisonOwner.lex.tex';new=json.loads(re.search(r'\\semanticdata\{(.*)\}',p.read_text()).group(1))
def reverse(x):
 if isinstance(x,list):return [reverse(v) for v in x]
 if not isinstance(x,dict):return x
 x={k:reverse(v) for k,v in x.items()}
 if x.get('kind')=='project' and x.get('field')=='ready' and x.get('value',{}).get('kind')=='project' and x['value'].get('field')=='transfer':return {**x,'value':x['value']['value']}
 if x.get('kind')=='record' and x.get('type')=={'module':'Uorc.Product.MachineBinding','name':'Terminal'}:
  fs=[]
  for f in x['fields']:
   if f['field']=='semanticRefusal':continue
   if f['field']=='transfer':f={'field':'ready','value':next(z['value'] for z in f['value']['fields'] if z['field']=='ready')}
   fs.append(f)
  x['fields']=fs
 return x
def canonical(d):
 counter=[0]
 def fresh():counter[0]+=1;return 'b'+str(counter[0])
 env={p['name']:fresh() for p in d.get('parameters',[])}
 def go(x,e):
  if isinstance(x,list):return [go(y,e) for y in x]
  if not isinstance(x,dict):return x
  if x.get('kind')=='var':return {**x,'name':e.get(x['name'],x['name'])}
  if x.get('kind')=='let':
   n=fresh();return {**x,'binder':{**x['binder'],'name':n},'value':go(x['value'],e),'body':go(x['body'],e|{x['binder']['name']:n})}
  if x.get('kind')=='match':
   bs=[]
   for b in x['branches']:
    ns={n:fresh() for n in b['binders']};bs.append({**b,'binders':list(ns.values()),'body':go(b['body'],e|ns)})
   return {**x,'scrutinee':go(x['scrutinee'],e),'branches':bs}
  return {k:go(v,e) for k,v in x.items()}
 result={k:v for k,v in d.items() if k!='axioms'}
 result['parameters']=[{**p,'name':env[p['name']]} for p in d.get('parameters',[])]
 if 'body' in d:result['body']=go(d['body'],env)
 if 'statement' in d:result['statement']=go(d['statement'],env)
 return result
by={d['name']:d for d in reverse(new)['declarations']};rows=[dict(name=d['name'],equal_after_reversing_only_carrier_change=canonical(d)==canonical(by[d['name']])) for d in old['declarations']];Path('tooling/machine-semantic-comparison-review.json').write_text(json.dumps(rows,sort_keys=True,indent=2));print(len(rows),all(x['equal_after_reversing_only_carrier_change'] for x in rows));print([r['name'] for r in rows if not r['equal_after_reversing_only_carrier_change']])
