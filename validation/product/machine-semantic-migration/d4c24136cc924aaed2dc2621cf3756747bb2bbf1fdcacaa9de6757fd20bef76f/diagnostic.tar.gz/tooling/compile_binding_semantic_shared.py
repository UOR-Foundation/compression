import pathlib,re,subprocess,os,sys,json,time,shutil,hashlib
project=pathlib.Path('captured-inputs/product-binding-semantic-shared');build=sys.argv[1];runtime=pathlib.Path('captured-inputs/product-binding-semantic-shared-runtime')/build;runtime.mkdir(parents=True,exist_ok=True)
modules=project/'.lexlean/build'/build/'modules';files={'.'.join(p.relative_to(modules).with_suffix('').parts):p for p in modules.rglob('*.lean')}
r=pathlib.Path('captured-inputs/product-sdk-runtime/.lexlean/build/4b164081a64cc0d9ac76982a25dac16e4943e4cb44eb25496d61c28089fd0186/modules')
for p in r.rglob('*.lean'):files['.'.join(p.relative_to(r).with_suffix('').parts)]=p
lean='lean';env=dict(os.environ,LEAN_PATH=str(runtime));done=set();logs=[]
previous=json.loads((runtime/'compilation.json').read_text()) if (runtime/'compilation.json').exists() else []
completed_before={x['module'] for x in previous if x['exit']==0}
while files:
 ready=next(((n,p) for n,p in files.items() if set(re.findall(r'(?:public )?import ([A-Za-z0-9_.]+)',p.read_text()))&set(files)==set()),None)
 if ready is None:raise RuntimeError('Generated dependency cycle')
 name,p=ready;target=runtime/pathlib.Path(*name.split('.')).with_suffix('.olean');target.parent.mkdir(parents=True,exist_ok=True)
 if name in completed_before and target.exists():
  logs.append(next(x for x in previous if x['module']==name));done.add(name);del files[name];continue
 cached=False
 for previous_runtime in runtime.parent.iterdir():
  if previous_runtime==runtime or not (previous_runtime/'compilation.json').is_file():continue
  candidate=previous_runtime/pathlib.Path(*name.split('.')).with_suffix('.olean')
  candidate_source=project/'.lexlean/build'/previous_runtime.name/'modules'/pathlib.Path(*name.split('.')).with_suffix('.lean')
  if name.startswith('LexLeanRuntime.'):candidate_source=p
  if not candidate.exists() or not candidate_source.exists() or candidate_source.read_bytes()!=p.read_bytes():continue
  imports=re.findall(r'(?:public )?import ([A-Za-z0-9_.]+)',p.read_text())
  compatible=True
  for imported in imports:
   now=runtime/pathlib.Path(*imported.split('.')).with_suffix('.olean')
   before=previous_runtime/pathlib.Path(*imported.split('.')).with_suffix('.olean')
   if now.exists() and (not before.exists() or hashlib.sha256(now.read_bytes()).digest()!=hashlib.sha256(before.read_bytes()).digest()):compatible=False;break
  if compatible:
   
   for artifact in candidate.parent.glob(candidate.stem+'.*'):
    shutil.copyfile(artifact,target.parent/artifact.name)
   logs.append(dict(module=name,exit=0,seconds=0,stdout='',stderr='',reused_from=previous_runtime.name,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),olean_sha256=hashlib.sha256(target.read_bytes()).hexdigest()));cached=True;break
 if cached:done.add(name);del files[name];continue
 t=time.time();r=subprocess.run([lean,'-o',str(target),str(p)],cwd=p.parents[len(name.split('.'))-1],env=env,capture_output=True,text=True)
 logs.append(dict(module=name,exit=r.returncode,seconds=time.time()-t,stdout=r.stdout,stderr=r.stderr))
 if r.returncode:
  print(name,r.stdout+r.stderr,flush=True);(runtime/'compilation.json').write_text(json.dumps(logs,sort_keys=True,indent=2));raise SystemExit(r.returncode)
 print('compiled',name,flush=True);done.add(name);del files[name]
(runtime/'compilation.json').write_text(json.dumps(logs,sort_keys=True,indent=2))
if len(sys.argv)>2 and sys.argv[2]=='compile-only':raise SystemExit(0)
harness=runtime/'RunMachineBinding.lean';harness.write_text('''import Uorc.Uorc.Product.MachineBindingScenarios
open Uorc.Uorc.Product
\ndef main : IO Unit := do
  let mut passed : Nat := 0
  let mut total : Nat := 0
  for observation in MachineBindingScenarios.observations do
    total := total + 1
    if observation.passed then passed := passed + 1 else IO.println s!"FAIL {observation.id}"
  IO.println s!"{passed}/{total} actual product-machine binding controls passed"
  if total == 0 || passed != total then throw (IO.userError "binding controls failed")
''')
r=subprocess.run([lean,'--run',str(harness)],env=env,capture_output=True,text=True);print(r.stdout+r.stderr,flush=True);(runtime/'execution.json').write_text(json.dumps(dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr),sort_keys=True,indent=2));raise SystemExit(r.returncode)
