module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Bytes
public import Uorc.Uorc.Core.Types
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.Graph

public inductive Instruction where
  | naturalConstant (_ : UInt64)
  | byteConstant (_ : UInt8)
  | predicateConstant (_ : Bool)
  | sequenceConstant (_ : ByteArray)
  | naturalAdd (_ : Nat) (_ : Nat)
  | naturalSubtract (_ : Nat) (_ : Nat)
  | naturalMultiply (_ : Nat) (_ : Nat)
  | naturalDivide (_ : Nat) (_ : Nat)
  | naturalRemainder (_ : Nat) (_ : Nat)
  | naturalAnd (_ : Nat) (_ : Nat)
  | naturalOr (_ : Nat) (_ : Nat)
  | naturalXor (_ : Nat) (_ : Nat)
  | naturalNot (_ : Nat)
  | naturalShiftLeft (_ : Nat) (_ : Nat)
  | naturalShiftRight (_ : Nat) (_ : Nat)
  | naturalEqual (_ : Nat) (_ : Nat)
  | naturalLess (_ : Nat) (_ : Nat)
  | byteEqual (_ : Nat) (_ : Nat)
  | byteLess (_ : Nat) (_ : Nat)
  | naturalToByte (_ : Nat)
  | byteToNatural (_ : Nat)
  | predicateNot (_ : Nat)
  | predicateAnd (_ : Nat) (_ : Nat)
  | predicateOr (_ : Nat) (_ : Nat)
  | sequenceLength (_ : Nat)
  | sequenceIndex (_ : Nat) (_ : Nat)
  | sequenceSlice (_ : Nat) (_ : Nat) (_ : Nat)
  | sequenceConcat (_ : Nat) (_ : Nat)
  | sequenceEqual (_ : Nat) (_ : Nat)
  | singletonSequence (_ : Nat)
  | basisGet (_ : Nat)
  | storeNew (_ : Nat)
  | storeRead (_ : Nat) (_ : Nat)
  | storeWrite (_ : Nat) (_ : Nat) (_ : Nat)
  | choose (_ : Nat) (_ : Nat) (_ : Nat)
  | apply (_ : Nat) (_ : List (Nat))
  | tabulate (_ : Nat) (_ : Nat) (_ : List (Nat))
  | fold (_ : Nat) (_ : Nat) (_ : Nat) (_ : List (Nat))
  | scan (_ : Nat) (_ : Nat) (_ : Nat) (_ : List (Nat)) (_ : Nat) (_ : List (Nat))
  | sequenceRopeConstant (_ : Uorc.Uorc.Core.Bytes.Rope)

public structure Block where
  parameters : List (Uorc.Uorc.Core.Types.ValueType)
  result : Uorc.Uorc.Core.Types.ValueType
  instructions : List (Instruction)
  returnDistance : Nat

public structure Graph where
  blocks : List (Block)
  entry : Nat

@[expose] public def sameTypes : (left : List (Uorc.Uorc.Core.Types.ValueType)) -> (right : List (Uorc.Uorc.Core.Types.ValueType)) -> Bool
  | List.nil, right => (match right with | List.nil => true | List.cons _ _ => false)
  | List.cons leftHead leftTail, right => (match right with | List.nil => false | List.cons rightHead rightTail => (Uorc.Uorc.Core.Types.sameType (leftHead) (rightHead) && sameTypes (leftTail) (rightTail)))

@[expose] public def expectType (actual : Uorc.Uorc.Core.Types.ValueType) (expected : Uorc.Uorc.Core.Types.ValueType) : Except (Uorc.Uorc.Core.Types.StaticError) (Unit) := (if Uorc.Uorc.Core.Types.sameType (actual) (expected) then Except.ok (()) else Except.error (Uorc.Uorc.Core.Types.StaticError.typeMismatch))

@[expose] public def localType (slots : List (Uorc.Uorc.Core.Types.ValueType)) (distance : Nat) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (if (Nat.beq (distance) (0)) then Except.error (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference) else (if (Nat.blt ((LexLeanRuntime.length (slots) : Nat)) (distance)) then Except.error (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference) else (match (LexLeanRuntime.index (slots) ((LexLeanRuntime.subtract ((LexLeanRuntime.length (slots) : Nat)) (distance) : Nat)) : Option (Uorc.Uorc.Core.Types.ValueType)) with | Option.none => Except.error (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference) | Option.some selected => Except.ok (selected))))

@[expose] public def priorBlock (prior : List (Block)) (distance : Nat) : Except (Uorc.Uorc.Core.Types.StaticError) (Block) := (if (Nat.beq (distance) (0)) then Except.error (Uorc.Uorc.Core.Types.StaticError.invalidBlockReference) else (if (Nat.blt ((LexLeanRuntime.length (prior) : Nat)) (distance)) then Except.error (Uorc.Uorc.Core.Types.StaticError.invalidBlockReference) else (match (LexLeanRuntime.index (prior) ((LexLeanRuntime.subtract ((LexLeanRuntime.length (prior) : Nat)) (distance) : Nat)) : Option (Block)) with | Option.none => Except.error (Uorc.Uorc.Core.Types.StaticError.invalidBlockReference) | Option.some selected => Except.ok (selected))))

@[expose] public def checkReferences : (references : List (Nat)) -> (slots : List (Uorc.Uorc.Core.Types.ValueType)) -> (expected : List (Uorc.Uorc.Core.Types.ValueType)) -> Except (Uorc.Uorc.Core.Types.StaticError) (Unit)
  | List.nil, _slots, expected => (match expected with | List.nil => Except.ok (()) | List.cons _ _ => Except.error (Uorc.Uorc.Core.Types.StaticError.arityMismatch))
  | List.cons reference rest, slots, expected => (match expected with | List.nil => Except.error (Uorc.Uorc.Core.Types.StaticError.arityMismatch) | List.cons expectedHead expectedTail => (match localType (slots) (reference) with | Except.error referenceError => Except.error (referenceError) | Except.ok actualType => (match expectType (actualType) (expectedHead) with | Except.error typeError => Except.error (typeError) | Except.ok _ => checkReferences (rest) (slots) (expectedTail))))

@[expose] public def inferReferences : (references : List (Nat)) -> (slots : List (Uorc.Uorc.Core.Types.ValueType)) -> Except (Uorc.Uorc.Core.Types.StaticError) (List (Uorc.Uorc.Core.Types.ValueType))
  | List.nil, _slots => Except.ok (([] : List (Uorc.Uorc.Core.Types.ValueType)))
  | List.cons reference rest, slots => (match localType (slots) (reference) with | Except.error referenceError => Except.error (referenceError) | Except.ok actualType => (match inferReferences (rest) (slots) with | Except.error tailError => Except.error (tailError) | Except.ok tailTypes => Except.ok ((actualType :: tailTypes))))

@[expose] public def inferFixed (references : List (Nat)) (slots : List (Uorc.Uorc.Core.Types.ValueType)) (expected : List (Uorc.Uorc.Core.Types.ValueType)) (output : Uorc.Uorc.Core.Types.ValueType) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (match checkReferences (references) (slots) (expected) with | Except.error error => Except.error (error) | Except.ok _ => Except.ok (output))

@[expose] public def inferApply (prior : List (Block)) (slots : List (Uorc.Uorc.Core.Types.ValueType)) (distance : Nat) (arguments : List (Nat)) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (match priorBlock (prior) (distance) with | Except.error error => Except.error (error) | Except.ok called => (match checkReferences (arguments) (slots) ((called).parameters) with | Except.error argumentError => Except.error (argumentError) | Except.ok _ => Except.ok ((called).result)))

@[expose] public def checkSignature (block : Block) (parameters : List (Uorc.Uorc.Core.Types.ValueType)) (output : Uorc.Uorc.Core.Types.ValueType) : Except (Uorc.Uorc.Core.Types.StaticError) (Unit) := (if (sameTypes ((block).parameters) (parameters) && Uorc.Uorc.Core.Types.sameType ((block).result) (output)) then Except.ok (()) else Except.error (Uorc.Uorc.Core.Types.StaticError.typeMismatch))

@[expose] public def inferIterator (prior : List (Block)) (slots : List (Uorc.Uorc.Core.Types.ValueType)) (distance : Nat) (captures : List (Nat)) («prefix» : List (Uorc.Uorc.Core.Types.ValueType)) (blockResult : Uorc.Uorc.Core.Types.ValueType) (output : Uorc.Uorc.Core.Types.ValueType) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (match priorBlock (prior) (distance) with | Except.error blockError => Except.error (blockError) | Except.ok called => (match inferReferences (captures) (slots) with | Except.error captureError => Except.error (captureError) | Except.ok captureTypes => (match checkSignature (called) ((LexLeanRuntime.append («prefix») (captureTypes) : List (Uorc.Uorc.Core.Types.ValueType))) (blockResult) with | Except.error signatureError => Except.error (signatureError) | Except.ok _ => Except.ok (output))))

@[expose] public def inferTabulate (prior : List (Block)) (slots : List (Uorc.Uorc.Core.Types.ValueType)) (count : Nat) (distance : Nat) (captures : List (Nat)) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (match checkReferences ((count :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) with | Except.error error => Except.error (error) | Except.ok _ => inferIterator (prior) (slots) (distance) (captures) ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.byte) (Uorc.Uorc.Core.Types.ValueType.sequence))

@[expose] public def inferFold (prior : List (Block)) (slots : List (Uorc.Uorc.Core.Types.ValueType)) (count : Nat) (initial : Nat) (distance : Nat) (captures : List (Nat)) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (match checkReferences ((count :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) with | Except.error countError => Except.error (countError) | Except.ok _ => (match localType (slots) (initial) with | Except.error initialError => Except.error (initialError) | Except.ok stateType => inferIterator (prior) (slots) (distance) (captures) ((Uorc.Uorc.Core.Types.ValueType.natural :: (stateType :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (stateType) (stateType)))

@[expose] public def inferScan (prior : List (Block)) (slots : List (Uorc.Uorc.Core.Types.ValueType)) (count : Nat) (initial : Nat) (observer : Nat) (observerCaptures : List (Nat)) (updater : Nat) (updaterCaptures : List (Nat)) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (match checkReferences ((count :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) with | Except.error countError => Except.error (countError) | Except.ok _ => (match localType (slots) (initial) with | Except.error initialError => Except.error (initialError) | Except.ok stateType => (match inferIterator (prior) (slots) (observer) (observerCaptures) ((Uorc.Uorc.Core.Types.ValueType.natural :: (stateType :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.byte) (Uorc.Uorc.Core.Types.ValueType.sequence) with | Except.error observerError => Except.error (observerError) | Except.ok _ => inferIterator (prior) (slots) (updater) (updaterCaptures) ((Uorc.Uorc.Core.Types.ValueType.natural :: (stateType :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (stateType) (Uorc.Uorc.Core.Types.ValueType.sequence))))

@[expose] public def inferChoose (slots : List (Uorc.Uorc.Core.Types.ValueType)) (condition : Nat) (whenTrue : Nat) (whenFalse : Nat) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (match checkReferences ((condition :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.predicate :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) with | Except.error conditionError => Except.error (conditionError) | Except.ok _ => (match localType (slots) (whenTrue) with | Except.error trueError => Except.error (trueError) | Except.ok trueType => (match localType (slots) (whenFalse) with | Except.error falseError => Except.error (falseError) | Except.ok falseType => (match expectType (falseType) (trueType) with | Except.error mismatch => Except.error (mismatch) | Except.ok _ => Except.ok (trueType)))))

@[expose] public def inferInstruction (prior : List (Block)) (slots : List (Uorc.Uorc.Core.Types.ValueType)) (instruction : Instruction) : Except (Uorc.Uorc.Core.Types.StaticError) (Uorc.Uorc.Core.Types.ValueType) := (match instruction with | Instruction.naturalConstant _ => Except.ok (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.byteConstant _ => Except.ok (Uorc.Uorc.Core.Types.ValueType.byte) | Instruction.predicateConstant _ => Except.ok (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.sequenceConstant _ => Except.ok (Uorc.Uorc.Core.Types.ValueType.sequence) | Instruction.naturalAdd operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalSubtract operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalMultiply operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalDivide operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalRemainder operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalAnd operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalOr operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalXor operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalNot operand0 => inferFixed ((operand0 :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalShiftLeft operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalShiftRight operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.naturalEqual operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.naturalLess operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.byteEqual operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.byte :: (Uorc.Uorc.Core.Types.ValueType.byte :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.byteLess operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.byte :: (Uorc.Uorc.Core.Types.ValueType.byte :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.naturalToByte operand0 => inferFixed ((operand0 :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.byte) | Instruction.byteToNatural operand0 => inferFixed ((operand0 :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.byte :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.predicateNot operand0 => inferFixed ((operand0 :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.predicate :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.predicateAnd operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.predicate :: (Uorc.Uorc.Core.Types.ValueType.predicate :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.predicateOr operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.predicate :: (Uorc.Uorc.Core.Types.ValueType.predicate :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.sequenceLength operand0 => inferFixed ((operand0 :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.sequence :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.natural) | Instruction.sequenceIndex operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.sequence :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.byte) | Instruction.sequenceSlice operand0 operand1 operand2 => inferFixed ((operand0 :: (operand1 :: (operand2 :: ([] : List (Nat)))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.sequence :: (Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))))) (Uorc.Uorc.Core.Types.ValueType.sequence) | Instruction.sequenceConcat operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.sequence :: (Uorc.Uorc.Core.Types.ValueType.sequence :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.sequence) | Instruction.sequenceEqual operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.sequence :: (Uorc.Uorc.Core.Types.ValueType.sequence :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.predicate) | Instruction.singletonSequence operand0 => inferFixed ((operand0 :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.byte :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.sequence) | Instruction.basisGet operand0 => inferFixed ((operand0 :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.sequence) | Instruction.storeNew operand0 => inferFixed ((operand0 :: ([] : List (Nat)))) (slots) ((Uorc.Uorc.Core.Types.ValueType.byte :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Uorc.Uorc.Core.Types.ValueType.store) | Instruction.storeRead operand0 operand1 => inferFixed ((operand0 :: (operand1 :: ([] : List (Nat))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.store :: (Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType))))) (Uorc.Uorc.Core.Types.ValueType.byte) | Instruction.storeWrite operand0 operand1 operand2 => inferFixed ((operand0 :: (operand1 :: (operand2 :: ([] : List (Nat)))))) (slots) ((Uorc.Uorc.Core.Types.ValueType.store :: (Uorc.Uorc.Core.Types.ValueType.natural :: (Uorc.Uorc.Core.Types.ValueType.byte :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))))) (Uorc.Uorc.Core.Types.ValueType.store) | Instruction.choose condition whenTrue whenFalse => inferChoose (slots) (condition) (whenTrue) (whenFalse) | Instruction.apply distance arguments => inferApply (prior) (slots) (distance) (arguments) | Instruction.tabulate count distance captures => inferTabulate (prior) (slots) (count) (distance) (captures) | Instruction.fold count initial distance captures => inferFold (prior) (slots) (count) (initial) (distance) (captures) | Instruction.scan count initial observer observerCaptures updater updaterCaptures => inferScan (prior) (slots) (count) (initial) (observer) (observerCaptures) (updater) (updaterCaptures) | Instruction.sequenceRopeConstant literal => (if Uorc.Uorc.Core.Bytes.valid (literal) then Except.ok (Uorc.Uorc.Core.Types.ValueType.sequence) else Except.error (Uorc.Uorc.Core.Types.StaticError.invalidSequenceRope)))

@[expose] public def validateInstructions : (instructions : List (Instruction)) -> (prior : List (Block)) -> (slots : List (Uorc.Uorc.Core.Types.ValueType)) -> Except (Uorc.Uorc.Core.Types.StaticError) (List (Uorc.Uorc.Core.Types.ValueType))
  | List.nil, _prior, slots => Except.ok (slots)
  | List.cons instruction rest, prior, slots => (match inferInstruction (prior) (slots) (instruction) with | Except.error error => Except.error (error) | Except.ok inferredType => validateInstructions (rest) (prior) ((LexLeanRuntime.append (slots) ((inferredType :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) : List (Uorc.Uorc.Core.Types.ValueType))))

@[expose] public def validateBlock (prior : List (Block)) (block : Block) : Except (Uorc.Uorc.Core.Types.StaticError) (Unit) := (match validateInstructions ((block).instructions) (prior) ((block).parameters) with | Except.error instructionError => Except.error (instructionError) | Except.ok slots => (match localType (slots) ((block).returnDistance) with | Except.error returnError => Except.error (returnError) | Except.ok returnedType => (if Uorc.Uorc.Core.Types.sameType (returnedType) ((block).result) then Except.ok (()) else Except.error (Uorc.Uorc.Core.Types.StaticError.returnMismatch))))

@[expose] public def validateBlocks : (blocks : List (Block)) -> (prior : List (Block)) -> Except (Uorc.Uorc.Core.Types.StaticError) (Unit)
  | List.nil, _prior => Except.ok (())
  | List.cons block rest, prior => (match validateBlock (prior) (block) with | Except.error error => Except.error (error) | Except.ok _ => validateBlocks (rest) ((LexLeanRuntime.append (prior) ((block :: ([] : List (Block)))) : List (Block))))

@[expose] public def validateEntry (graph : Graph) : Except (Uorc.Uorc.Core.Types.StaticError) (Unit) := (match (LexLeanRuntime.index ((graph).blocks) ((graph).entry) : Option (Block)) with | Option.none => Except.error (Uorc.Uorc.Core.Types.StaticError.invalidBlockReference) | Option.some entryBlock => (if ((Nat.beq ((LexLeanRuntime.length ((entryBlock).parameters) : Nat)) (0)) && Uorc.Uorc.Core.Types.sameType ((entryBlock).result) (Uorc.Uorc.Core.Types.ValueType.sequence)) then Except.ok (()) else Except.error (Uorc.Uorc.Core.Types.StaticError.entrySignatureMismatch)))

@[expose] public def validateGraph (graph : Graph) : Except (Uorc.Uorc.Core.Types.StaticError) (Unit) := (if (Nat.beq ((LexLeanRuntime.length ((graph).blocks) : Nat)) (0)) then Except.error (Uorc.Uorc.Core.Types.StaticError.emptyGraph) else (match validateBlocks ((graph).blocks) (([] : List (Block))) with | Except.error error => Except.error (error) | Except.ok _ => validateEntry (graph)))

@[expose] public def literalGraph (bytes : ByteArray) : Graph := ({ blocks := (({ parameters := ([] : List (Uorc.Uorc.Core.Types.ValueType)), result := Uorc.Uorc.Core.Types.ValueType.sequence, instructions := (Instruction.sequenceConstant (bytes) :: ([] : List (Instruction))), returnDistance := 1 } : Block) :: ([] : List (Block))), entry := 0 } : Graph)

public theorem literal_graph_valid (bytes : ByteArray) : (validateGraph (literalGraph (bytes)) = Except.ok (())) := by
  rfl

public theorem empty_graph_rejected : (validateGraph (({ blocks := ([] : List (Block)), entry := 0 } : Graph)) = Except.error (Uorc.Uorc.Core.Types.StaticError.emptyGraph)) := by
  rfl

public theorem zero_local_distance_rejected : (localType ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (0) = Except.error (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) := by
  rfl

public theorem forward_local_distance_rejected : (localType ((Uorc.Uorc.Core.Types.ValueType.natural :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (2) = Except.error (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) := by
  rfl

public theorem local_distance_before_type : (inferInstruction (([] : List (Block))) ((Uorc.Uorc.Core.Types.ValueType.sequence :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Instruction.naturalAdd (2) (1)) = Except.error (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) := by
  rfl

public theorem first_type_before_later_distance : (inferInstruction (([] : List (Block))) ((Uorc.Uorc.Core.Types.ValueType.sequence :: ([] : List (Uorc.Uorc.Core.Types.ValueType)))) (Instruction.naturalAdd (1) (2)) = Except.error (Uorc.Uorc.Core.Types.StaticError.typeMismatch)) := by
  rfl

public theorem zero_block_distance_rejected : (priorBlock ((({ parameters := ([] : List (Uorc.Uorc.Core.Types.ValueType)), result := Uorc.Uorc.Core.Types.ValueType.sequence, instructions := (Instruction.sequenceConstant (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))]) :: ([] : List (Instruction))), returnDistance := 1 } : Block) :: ([] : List (Block)))) (0) = Except.error (Uorc.Uorc.Core.Types.StaticError.invalidBlockReference)) := by
  rfl

public theorem unreachable_invalid_block_rejected : (validateGraph (({ blocks := (({ parameters := ([] : List (Uorc.Uorc.Core.Types.ValueType)), result := Uorc.Uorc.Core.Types.ValueType.sequence, instructions := (Instruction.sequenceConstant (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))]) :: ([] : List (Instruction))), returnDistance := 1 } : Block) :: (({ parameters := ([] : List (Uorc.Uorc.Core.Types.ValueType)), result := Uorc.Uorc.Core.Types.ValueType.sequence, instructions := ([] : List (Instruction)), returnDistance := 1 } : Block) :: ([] : List (Block)))), entry := 0 } : Graph)) = Except.error (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) := by
  rfl

@[expose] public def literalRopeGraph (rope : Uorc.Uorc.Core.Bytes.Rope) : Graph := ({ blocks := (({ parameters := ([] : List (Uorc.Uorc.Core.Types.ValueType)), result := Uorc.Uorc.Core.Types.ValueType.sequence, instructions := (Instruction.sequenceRopeConstant (rope) :: ([] : List (Instruction))), returnDistance := 1 } : Block) :: ([] : List (Block))), entry := 0 } : Graph)

end Uorc.Uorc.Core.Graph
