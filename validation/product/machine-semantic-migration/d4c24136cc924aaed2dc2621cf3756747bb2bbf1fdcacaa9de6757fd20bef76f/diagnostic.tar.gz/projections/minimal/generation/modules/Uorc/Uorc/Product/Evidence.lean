module
public import Init
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Product.Evidence

public inductive Operation where
  | compress
  | decompress
  | inspect
  | verify
  | resume
  | buildBasis
  | analyzeFrontier
  | compare
  | runAcceptance
  | runCoreRequest

public inductive FinalCheck where
  | equal
  | different
  | incomplete
  | cancelled

public inductive CertificateCheck where
  | absent
  | valid
  | invalid
  | incomplete

public inductive PublicationDecision where
  | publish
  | byteMismatch
  | verificationIncomplete
  | cancelled
  | certificateUnmet

public structure EvidenceFacts where
  parsed : Bool
  integrityChecked : Bool
  executed : Bool
  originalCompared : Bool
  certificateChecked : Bool

public structure EvidenceView where
  parsed : Bool
  integrityChecked : Bool
  executed : Bool
  originalCompared : Bool
  scopedMinimum : Bool
  unrestrictedMinimum : Bool
  externalRecord : Bool

@[expose] public def publicationDecision (finalCheck : FinalCheck) (requireCertificate : Bool) (certificate : CertificateCheck) : PublicationDecision := (match finalCheck with | FinalCheck.equal => (if requireCertificate then (if (match certificate with | CertificateCheck.absent => false | CertificateCheck.valid => true | CertificateCheck.invalid => false | CertificateCheck.incomplete => false) then PublicationDecision.publish else PublicationDecision.certificateUnmet) else PublicationDecision.publish) | FinalCheck.different => PublicationDecision.byteMismatch | FinalCheck.incomplete => PublicationDecision.verificationIncomplete | FinalCheck.cancelled => PublicationDecision.cancelled)

@[expose] public def presentEvidence (operation : Operation) (originalAvailable : Bool) (facts : EvidenceFacts) : EvidenceView := (match operation with | Operation.compress => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.decompress => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.inspect => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := false, originalCompared := false, scopedMinimum := false, unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.verify => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.resume => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.buildBasis => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.analyzeFrontier => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.compare => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.runAcceptance => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView) | Operation.runCoreRequest => ({ parsed := (facts).parsed, integrityChecked := ((facts).parsed && ((facts).integrityChecked && true)), executed := (((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)), originalCompared := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && (originalAvailable && ((facts).originalCompared && true))), scopedMinimum := ((((facts).parsed && ((facts).integrityChecked && true)) && ((facts).executed && true)) && ((facts).certificateChecked && true)), unrestrictedMinimum := false, externalRecord := false } : EvidenceView))

public theorem publication_equal_false_absent : (publicationDecision (FinalCheck.equal) (false) (CertificateCheck.absent) = PublicationDecision.publish) := by
  rfl

public theorem publication_equal_false_valid : (publicationDecision (FinalCheck.equal) (false) (CertificateCheck.valid) = PublicationDecision.publish) := by
  rfl

public theorem publication_equal_false_invalid : (publicationDecision (FinalCheck.equal) (false) (CertificateCheck.invalid) = PublicationDecision.publish) := by
  rfl

public theorem publication_equal_false_incomplete : (publicationDecision (FinalCheck.equal) (false) (CertificateCheck.incomplete) = PublicationDecision.publish) := by
  rfl

public theorem publication_equal_true_absent : (publicationDecision (FinalCheck.equal) (true) (CertificateCheck.absent) = PublicationDecision.certificateUnmet) := by
  rfl

public theorem publication_equal_true_valid : (publicationDecision (FinalCheck.equal) (true) (CertificateCheck.valid) = PublicationDecision.publish) := by
  rfl

public theorem publication_equal_true_invalid : (publicationDecision (FinalCheck.equal) (true) (CertificateCheck.invalid) = PublicationDecision.certificateUnmet) := by
  rfl

public theorem publication_equal_true_incomplete : (publicationDecision (FinalCheck.equal) (true) (CertificateCheck.incomplete) = PublicationDecision.certificateUnmet) := by
  rfl

public theorem publication_different_false_absent : (publicationDecision (FinalCheck.different) (false) (CertificateCheck.absent) = PublicationDecision.byteMismatch) := by
  rfl

public theorem publication_different_false_valid : (publicationDecision (FinalCheck.different) (false) (CertificateCheck.valid) = PublicationDecision.byteMismatch) := by
  rfl

public theorem publication_different_false_invalid : (publicationDecision (FinalCheck.different) (false) (CertificateCheck.invalid) = PublicationDecision.byteMismatch) := by
  rfl

public theorem publication_different_false_incomplete : (publicationDecision (FinalCheck.different) (false) (CertificateCheck.incomplete) = PublicationDecision.byteMismatch) := by
  rfl

public theorem publication_different_true_absent : (publicationDecision (FinalCheck.different) (true) (CertificateCheck.absent) = PublicationDecision.byteMismatch) := by
  rfl

public theorem publication_different_true_valid : (publicationDecision (FinalCheck.different) (true) (CertificateCheck.valid) = PublicationDecision.byteMismatch) := by
  rfl

public theorem publication_different_true_invalid : (publicationDecision (FinalCheck.different) (true) (CertificateCheck.invalid) = PublicationDecision.byteMismatch) := by
  rfl

public theorem publication_different_true_incomplete : (publicationDecision (FinalCheck.different) (true) (CertificateCheck.incomplete) = PublicationDecision.byteMismatch) := by
  rfl

public theorem publication_incomplete_false_absent : (publicationDecision (FinalCheck.incomplete) (false) (CertificateCheck.absent) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem publication_incomplete_false_valid : (publicationDecision (FinalCheck.incomplete) (false) (CertificateCheck.valid) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem publication_incomplete_false_invalid : (publicationDecision (FinalCheck.incomplete) (false) (CertificateCheck.invalid) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem publication_incomplete_false_incomplete : (publicationDecision (FinalCheck.incomplete) (false) (CertificateCheck.incomplete) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem publication_incomplete_true_absent : (publicationDecision (FinalCheck.incomplete) (true) (CertificateCheck.absent) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem publication_incomplete_true_valid : (publicationDecision (FinalCheck.incomplete) (true) (CertificateCheck.valid) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem publication_incomplete_true_invalid : (publicationDecision (FinalCheck.incomplete) (true) (CertificateCheck.invalid) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem publication_incomplete_true_incomplete : (publicationDecision (FinalCheck.incomplete) (true) (CertificateCheck.incomplete) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem publication_cancelled_false_absent : (publicationDecision (FinalCheck.cancelled) (false) (CertificateCheck.absent) = PublicationDecision.cancelled) := by
  rfl

public theorem publication_cancelled_false_valid : (publicationDecision (FinalCheck.cancelled) (false) (CertificateCheck.valid) = PublicationDecision.cancelled) := by
  rfl

public theorem publication_cancelled_false_invalid : (publicationDecision (FinalCheck.cancelled) (false) (CertificateCheck.invalid) = PublicationDecision.cancelled) := by
  rfl

public theorem publication_cancelled_false_incomplete : (publicationDecision (FinalCheck.cancelled) (false) (CertificateCheck.incomplete) = PublicationDecision.cancelled) := by
  rfl

public theorem publication_cancelled_true_absent : (publicationDecision (FinalCheck.cancelled) (true) (CertificateCheck.absent) = PublicationDecision.cancelled) := by
  rfl

public theorem publication_cancelled_true_valid : (publicationDecision (FinalCheck.cancelled) (true) (CertificateCheck.valid) = PublicationDecision.cancelled) := by
  rfl

public theorem publication_cancelled_true_invalid : (publicationDecision (FinalCheck.cancelled) (true) (CertificateCheck.invalid) = PublicationDecision.cancelled) := by
  rfl

public theorem publication_cancelled_true_incomplete : (publicationDecision (FinalCheck.cancelled) (true) (CertificateCheck.incomplete) = PublicationDecision.cancelled) := by
  rfl

public theorem equality_compress_false : ((presentEvidence (Operation.compress) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_compress_false : ((presentEvidence (Operation.compress) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_compress_false : ((presentEvidence (Operation.compress) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_compress_true : ((presentEvidence (Operation.compress) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_compress_true : ((presentEvidence (Operation.compress) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_compress_true : ((presentEvidence (Operation.compress) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_decompress_false : ((presentEvidence (Operation.decompress) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_decompress_false : ((presentEvidence (Operation.decompress) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_decompress_false : ((presentEvidence (Operation.decompress) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_decompress_true : ((presentEvidence (Operation.decompress) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_decompress_true : ((presentEvidence (Operation.decompress) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_decompress_true : ((presentEvidence (Operation.decompress) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_inspect_false : ((presentEvidence (Operation.inspect) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_inspect_false : ((presentEvidence (Operation.inspect) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_inspect_false : ((presentEvidence (Operation.inspect) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_inspect_true : ((presentEvidence (Operation.inspect) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_inspect_true : ((presentEvidence (Operation.inspect) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_inspect_true : ((presentEvidence (Operation.inspect) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_verify_false : ((presentEvidence (Operation.verify) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_verify_false : ((presentEvidence (Operation.verify) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_verify_false : ((presentEvidence (Operation.verify) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_verify_true : ((presentEvidence (Operation.verify) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_verify_true : ((presentEvidence (Operation.verify) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_verify_true : ((presentEvidence (Operation.verify) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_resume_false : ((presentEvidence (Operation.resume) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_resume_false : ((presentEvidence (Operation.resume) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_resume_false : ((presentEvidence (Operation.resume) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_resume_true : ((presentEvidence (Operation.resume) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_resume_true : ((presentEvidence (Operation.resume) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_resume_true : ((presentEvidence (Operation.resume) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_buildBasis_false : ((presentEvidence (Operation.buildBasis) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_buildBasis_false : ((presentEvidence (Operation.buildBasis) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_buildBasis_false : ((presentEvidence (Operation.buildBasis) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_buildBasis_true : ((presentEvidence (Operation.buildBasis) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_buildBasis_true : ((presentEvidence (Operation.buildBasis) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_buildBasis_true : ((presentEvidence (Operation.buildBasis) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_analyzeFrontier_false : ((presentEvidence (Operation.analyzeFrontier) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_analyzeFrontier_false : ((presentEvidence (Operation.analyzeFrontier) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_analyzeFrontier_false : ((presentEvidence (Operation.analyzeFrontier) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_analyzeFrontier_true : ((presentEvidence (Operation.analyzeFrontier) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_analyzeFrontier_true : ((presentEvidence (Operation.analyzeFrontier) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_analyzeFrontier_true : ((presentEvidence (Operation.analyzeFrontier) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_compare_false : ((presentEvidence (Operation.compare) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_compare_false : ((presentEvidence (Operation.compare) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_compare_false : ((presentEvidence (Operation.compare) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_compare_true : ((presentEvidence (Operation.compare) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_compare_true : ((presentEvidence (Operation.compare) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_compare_true : ((presentEvidence (Operation.compare) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_runAcceptance_false : ((presentEvidence (Operation.runAcceptance) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_runAcceptance_false : ((presentEvidence (Operation.runAcceptance) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_runAcceptance_false : ((presentEvidence (Operation.runAcceptance) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_runAcceptance_true : ((presentEvidence (Operation.runAcceptance) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_runAcceptance_true : ((presentEvidence (Operation.runAcceptance) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_runAcceptance_true : ((presentEvidence (Operation.runAcceptance) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_runCoreRequest_false : ((presentEvidence (Operation.runCoreRequest) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = false) := by
  rfl

public theorem no_unrestricted_claim_runCoreRequest_false : ((presentEvidence (Operation.runCoreRequest) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_runCoreRequest_false : ((presentEvidence (Operation.runCoreRequest) (false) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem equality_runCoreRequest_true : ((presentEvidence (Operation.runCoreRequest) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).originalCompared = true) := by
  rfl

public theorem no_unrestricted_claim_runCoreRequest_true : ((presentEvidence (Operation.runCoreRequest) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).unrestrictedMinimum = false) := by
  rfl

public theorem no_record_claim_runCoreRequest_true : ((presentEvidence (Operation.runCoreRequest) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).externalRecord = false) := by
  rfl

public theorem inspection_does_not_execute : ((presentEvidence (Operation.inspect) (true) (({ parsed := true, integrityChecked := true, executed := true, originalCompared := true, certificateChecked := true } : EvidenceFacts))).executed = false) := by
  rfl

@[expose] public def evidenceBoundary : String := "EvidenceFacts are observations supplied by the independently checked execution and certificate paths. This presenter validates their display implications, not the truth of an artifact. A release label, search result, transport, digest match, or benchmark cannot create reconstruction or optimality evidence."

@[expose] public def decompressionPublicationDecision (parsed : Bool) (integrityChecked : Bool) (executionComplete : Bool) (boundariesComplete : Bool) (cancelled : Bool) : PublicationDecision := (if cancelled then PublicationDecision.cancelled else (if (parsed && (integrityChecked && (executionComplete && (boundariesComplete && ((!cancelled) && true))))) then PublicationDecision.publish else PublicationDecision.verificationIncomplete))

public theorem decode_publication_0 : (decompressionPublicationDecision (false) (false) (false) (false) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_1 : (decompressionPublicationDecision (true) (false) (false) (false) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_2 : (decompressionPublicationDecision (false) (true) (false) (false) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_3 : (decompressionPublicationDecision (true) (true) (false) (false) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_4 : (decompressionPublicationDecision (false) (false) (true) (false) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_5 : (decompressionPublicationDecision (true) (false) (true) (false) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_6 : (decompressionPublicationDecision (false) (true) (true) (false) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_7 : (decompressionPublicationDecision (true) (true) (true) (false) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_8 : (decompressionPublicationDecision (false) (false) (false) (true) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_9 : (decompressionPublicationDecision (true) (false) (false) (true) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_10 : (decompressionPublicationDecision (false) (true) (false) (true) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_11 : (decompressionPublicationDecision (true) (true) (false) (true) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_12 : (decompressionPublicationDecision (false) (false) (true) (true) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_13 : (decompressionPublicationDecision (true) (false) (true) (true) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_14 : (decompressionPublicationDecision (false) (true) (true) (true) (false) = PublicationDecision.verificationIncomplete) := by
  rfl

public theorem decode_publication_15 : (decompressionPublicationDecision (true) (true) (true) (true) (false) = PublicationDecision.publish) := by
  rfl

public theorem decode_publication_16 : (decompressionPublicationDecision (false) (false) (false) (false) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_17 : (decompressionPublicationDecision (true) (false) (false) (false) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_18 : (decompressionPublicationDecision (false) (true) (false) (false) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_19 : (decompressionPublicationDecision (true) (true) (false) (false) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_20 : (decompressionPublicationDecision (false) (false) (true) (false) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_21 : (decompressionPublicationDecision (true) (false) (true) (false) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_22 : (decompressionPublicationDecision (false) (true) (true) (false) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_23 : (decompressionPublicationDecision (true) (true) (true) (false) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_24 : (decompressionPublicationDecision (false) (false) (false) (true) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_25 : (decompressionPublicationDecision (true) (false) (false) (true) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_26 : (decompressionPublicationDecision (false) (true) (false) (true) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_27 : (decompressionPublicationDecision (true) (true) (false) (true) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_28 : (decompressionPublicationDecision (false) (false) (true) (true) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_29 : (decompressionPublicationDecision (true) (false) (true) (true) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_30 : (decompressionPublicationDecision (false) (true) (true) (true) (true) = PublicationDecision.cancelled) := by
  rfl

public theorem decode_publication_31 : (decompressionPublicationDecision (true) (true) (true) (true) (true) = PublicationDecision.cancelled) := by
  rfl

@[expose] public def decompressionBoundary : String := "Decompression publishes only after complete syntax, integrity, execution and ordered-boundary checks, without requiring the unavailable original source bytes. It does not set originalCompared or claim digest equality proves original-byte identity. The existing publicationDecision is the encoder final round-trip gate; it is not imposed as an original-file requirement on ordinary decompression."

end Uorc.Uorc.Product.Evidence
