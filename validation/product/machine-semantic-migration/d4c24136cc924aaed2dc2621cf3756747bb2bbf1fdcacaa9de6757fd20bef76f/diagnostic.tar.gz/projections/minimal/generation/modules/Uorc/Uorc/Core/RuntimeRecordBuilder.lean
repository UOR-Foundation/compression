module
public import Init
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeMetadata
public import Uorc.Uorc.Core.RuntimeValue
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeRecordBuilder

public inductive Error where
  | metadata (_ : Uorc.Uorc.Core.RuntimeMetadata.Error)
  | heap (_ : Uorc.Uorc.Core.Heap.HeapError)

public inductive Cursor where
  | writing (_ : Uorc.Uorc.Core.RuntimeMetadata.WriteCursor)
  | beginRelease (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : Uorc.Uorc.Core.RuntimeValue.Handle)
  | releasing (_ : Uorc.Uorc.Core.RuntimeValue.Handle)

public inductive Event where
  | advanced (_ : Uorc.Uorc.Core.Heap.Arena) (_ : Cursor) (_ : Uorc.Uorc.Core.Heap.Delta)
  | done (_ : Uorc.Uorc.Core.Heap.Arena) (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : Uorc.Uorc.Core.Heap.Delta)
  | failed (_ : Error) (_ : Uorc.Uorc.Core.Heap.Arena) (_ : Cursor)

@[expose] public def start (oldOwnedRoot : Uorc.Uorc.Core.RuntimeValue.Handle) (kind : UInt64) (key : UInt64) (field : Uorc.Uorc.Core.RuntimeMetadata.Field) : Except (Error) (Cursor) := (match Uorc.Uorc.Core.RuntimeMetadata.startWrite (oldOwnedRoot) (kind) (key) (field) with | Except.error metadataError => Except.error (Error.metadata (metadataError)) | Except.ok writeCursor => Except.ok (Cursor.writing (writeCursor)))

@[expose] public def step (arena : Uorc.Uorc.Core.Heap.Arena) (cursor : Cursor) : Event := (match cursor with | Cursor.writing writeCursor => (match Uorc.Uorc.Core.RuntimeMetadata.writeStep (arena) (writeCursor) with | Uorc.Uorc.Core.RuntimeMetadata.WriteEvent.failed metadataError nextArena nextWrite => Event.failed (Error.metadata (metadataError)) (nextArena) (Cursor.writing (nextWrite)) | Uorc.Uorc.Core.RuntimeMetadata.WriteEvent.advanced nextArena nextWrite delta => Event.advanced (nextArena) (Cursor.writing (nextWrite)) (delta) | Uorc.Uorc.Core.RuntimeMetadata.WriteEvent.done nextArena newRoot delta => (if Uorc.Uorc.Core.RuntimeValue.isNull ((writeCursor).oldRoot) then Event.done (nextArena) (newRoot) (delta) else Event.advanced (nextArena) (Cursor.beginRelease (newRoot) ((writeCursor).oldRoot)) (delta))) | Cursor.beginRelease newRoot oldRoot => (match Uorc.Uorc.Core.Heap.release (arena) (oldRoot) with | Except.error heapError => Event.failed (Error.heap (heapError)) (arena) (cursor) | Except.ok transition => (if (transition).complete then Event.done ((transition).arena) (newRoot) ((transition).delta) else Event.advanced ((transition).arena) (Cursor.releasing (newRoot)) ((transition).delta))) | Cursor.releasing newRoot => (match Uorc.Uorc.Core.Heap.releaseStep (arena) with | Except.error heapError => Event.failed (Error.heap (heapError)) (arena) (cursor) | Except.ok transition => (if (transition).complete then Event.done ((transition).arena) (newRoot) ((transition).delta) else Event.advanced ((transition).arena) (cursor) ((transition).delta))))

@[expose] public def rootInventory (cursor : Cursor) : List (Uorc.Uorc.Core.RuntimeValue.Handle) := (match cursor with | Cursor.writing writeCursor => (if Uorc.Uorc.Core.RuntimeValue.isNull ((writeCursor).oldRoot) then Uorc.Uorc.Core.RuntimeMetadata.temporaryRoots (writeCursor) else ((writeCursor).oldRoot :: Uorc.Uorc.Core.RuntimeMetadata.temporaryRoots (writeCursor))) | Cursor.beginRelease newRoot oldRoot => (if Uorc.Uorc.Core.RuntimeValue.isNull (newRoot) then (if Uorc.Uorc.Core.RuntimeValue.isNull (oldRoot) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else (oldRoot :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else (newRoot :: (if Uorc.Uorc.Core.RuntimeValue.isNull (oldRoot) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else (oldRoot :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))))) | Cursor.releasing newRoot => (if Uorc.Uorc.Core.RuntimeValue.isNull (newRoot) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else (newRoot :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))))

end Uorc.Uorc.Core.RuntimeRecordBuilder
