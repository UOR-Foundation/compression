module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.CanonicalCost
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.ReferenceSemantics
public import Uorc.Uorc.Core.RuntimeOpcode
public import Uorc.Uorc.Core.RuntimeProgram
public import Uorc.Uorc.Core.RuntimeSequence
public import Uorc.Uorc.Core.RuntimeTable
public import Uorc.Uorc.Core.RuntimeValue
public import Uorc.Uorc.Core.Types
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeMachineSemantic

public inductive Event where
  | instruction (_ : Uorc.Uorc.Core.RuntimeOpcode.Opcode)
  | parameterBind
  | referenceRead
  | blockEnter
  | blockLeave
  | loopObserve
  | loopUpdate
  | byteRead
  | byteWrite
  | byteComparison
  | outputBoundary
  | outputByte
  | basisBoundary
  | canonicalEof
  | allocateValueUnits (_ : UInt64)
  | releaseValueUnits (_ : UInt64)

public structure Ledger where
  profile : Uorc.Uorc.Core.CanonicalCost.ProfileId
  semanticWork : UInt64
  semanticStorageUnits : UInt64
  peakSemanticStorageUnits : UInt64
  outputBytes : UInt64
  activeFrames : UInt64
  peakFrames : UInt64
  acceptedArchives : UInt64
  basisObjects : UInt64

public inductive StoragePolicy where
  | unconstrained
  | payloadUnits
  | payloadBytes

public structure Budget where
  profile : Uorc.Uorc.Core.CanonicalCost.ProfileId
  maxSemanticWork : UInt64
  storage : StoragePolicy
  maxStorageUnits : UInt64

public inductive Error where
  | wordOverflow
  | storageUnderflow
  | frameUnderflow
  | workLimit
  | storageLimit
  | invalidUsage
  | unsupportedProfile
  | unsupportedStorage

@[expose] public def profileCompatible (profile : Uorc.Uorc.Core.CanonicalCost.ProfileId) : Bool := Uorc.Uorc.Core.CanonicalCost.profileSupported (profile)

@[expose] public def storageSupported (storage : StoragePolicy) : Bool := (match storage with | StoragePolicy.unconstrained => true | StoragePolicy.payloadUnits => true | StoragePolicy.payloadBytes => false)

@[expose] public def storageBounded (storage : StoragePolicy) : Bool := (match storage with | StoragePolicy.unconstrained => false | StoragePolicy.payloadUnits => true | StoragePolicy.payloadBytes => true)

@[expose] public def zeroLedger : Ledger := ({ profile := Uorc.Uorc.Core.CanonicalCost.currentProfile, semanticWork := (0 : UInt64), semanticStorageUnits := (0 : UInt64), peakSemanticStorageUnits := (0 : UInt64), outputBytes := (0 : UInt64), activeFrames := (0 : UInt64), peakFrames := (0 : UInt64), acceptedArchives := (0 : UInt64), basisObjects := (0 : UInt64) } : Ledger)

@[expose] public def meaning (ledger : Ledger) : Uorc.Uorc.Core.CanonicalCost.Usage := ({ semanticWork := Uorc.Uorc.Core.Types.wordToNat ((ledger).semanticWork), semanticStorageUnits := Uorc.Uorc.Core.Types.wordToNat ((ledger).semanticStorageUnits), peakSemanticStorageUnits := Uorc.Uorc.Core.Types.wordToNat ((ledger).peakSemanticStorageUnits), outputBytes := Uorc.Uorc.Core.Types.wordToNat ((ledger).outputBytes), activeFrames := Uorc.Uorc.Core.Types.wordToNat ((ledger).activeFrames), peakFrames := Uorc.Uorc.Core.Types.wordToNat ((ledger).peakFrames), acceptedArchives := Uorc.Uorc.Core.Types.wordToNat ((ledger).acceptedArchives), basisObjects := Uorc.Uorc.Core.Types.wordToNat ((ledger).basisObjects) } : Uorc.Uorc.Core.CanonicalCost.Usage)

@[expose] public def eventMeaning (event : Event) : Uorc.Uorc.Core.CanonicalCost.SemanticEvent := (match event with | Event.instruction opcode => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.instruction (opcode) | Event.parameterBind => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.parameterBind | Event.referenceRead => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.referenceRead | Event.blockEnter => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.blockEnter | Event.blockLeave => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.blockLeave | Event.loopObserve => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.loopObserve | Event.loopUpdate => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.loopUpdate | Event.byteRead => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.byteRead | Event.byteWrite => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.byteWrite | Event.byteComparison => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.byteComparison | Event.outputBoundary => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.outputBoundary | Event.outputByte => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.outputByte | Event.basisBoundary => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.basisBoundary | Event.canonicalEof => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.canonicalEof | Event.allocateValueUnits units => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.allocateValueUnits (Uorc.Uorc.Core.Types.wordToNat (units)) | Event.releaseValueUnits units => Uorc.Uorc.Core.CanonicalCost.SemanticEvent.releaseValueUnits (Uorc.Uorc.Core.Types.wordToNat (units)))

@[expose] public def instructionWork (opcode : Uorc.Uorc.Core.RuntimeOpcode.Opcode) : UInt64 := (match opcode with | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalConstant => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.byteConstant => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.predicateConstant => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceConstant => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalAdd => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalSubtract => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalMultiply => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalDivide => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalRemainder => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalAnd => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalOr => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalXor => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalNot => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalShiftLeft => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalShiftRight => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalEqual => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalLess => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.byteEqual => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.byteLess => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalToByte => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.byteToNatural => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.predicateNot => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.predicateAnd => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.predicateOr => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceLength => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceIndex => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceSlice => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceConcat => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceEqual => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.singletonSequence => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.basisGet => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.storeNew => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.storeRead => (65 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.storeWrite => (65 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.choose => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.apply => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.tabulate => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.fold => (1 : UInt64) | Uorc.Uorc.Core.RuntimeOpcode.Opcode.scan => (1 : UInt64))

@[expose] public def eventWork (event : Event) : UInt64 := (match event with | Event.instruction opcode => instructionWork (opcode) | Event.parameterBind => (1 : UInt64) | Event.referenceRead => (1 : UInt64) | Event.blockEnter => (1 : UInt64) | Event.blockLeave => (1 : UInt64) | Event.loopObserve => (1 : UInt64) | Event.loopUpdate => (1 : UInt64) | Event.byteRead => (1 : UInt64) | Event.byteWrite => (1 : UInt64) | Event.byteComparison => (1 : UInt64) | Event.outputBoundary => (1 : UInt64) | Event.outputByte => (1 : UInt64) | Event.basisBoundary => (1 : UInt64) | Event.canonicalEof => (1 : UInt64) | Event.allocateValueUnits _ => (1 : UInt64) | Event.releaseValueUnits _ => (1 : UInt64))

@[expose] public def allocatedUnits (event : Event) : UInt64 := (match event with | Event.instruction _ => (0 : UInt64) | Event.parameterBind => (0 : UInt64) | Event.referenceRead => (0 : UInt64) | Event.blockEnter => (0 : UInt64) | Event.blockLeave => (0 : UInt64) | Event.loopObserve => (0 : UInt64) | Event.loopUpdate => (0 : UInt64) | Event.byteRead => (0 : UInt64) | Event.byteWrite => (0 : UInt64) | Event.byteComparison => (0 : UInt64) | Event.outputBoundary => (0 : UInt64) | Event.outputByte => (0 : UInt64) | Event.basisBoundary => (0 : UInt64) | Event.canonicalEof => (0 : UInt64) | Event.allocateValueUnits units => units | Event.releaseValueUnits _ => (0 : UInt64))

@[expose] public def releasedUnits (event : Event) : UInt64 := (match event with | Event.instruction _ => (0 : UInt64) | Event.parameterBind => (0 : UInt64) | Event.referenceRead => (0 : UInt64) | Event.blockEnter => (0 : UInt64) | Event.blockLeave => (0 : UInt64) | Event.loopObserve => (0 : UInt64) | Event.loopUpdate => (0 : UInt64) | Event.byteRead => (0 : UInt64) | Event.byteWrite => (0 : UInt64) | Event.byteComparison => (0 : UInt64) | Event.outputBoundary => (0 : UInt64) | Event.outputByte => (0 : UInt64) | Event.basisBoundary => (0 : UInt64) | Event.canonicalEof => (0 : UInt64) | Event.allocateValueUnits _ => (0 : UInt64) | Event.releaseValueUnits units => units)

@[expose] public def outputCount (event : Event) : UInt64 := (match event with | Event.instruction _ => (0 : UInt64) | Event.parameterBind => (0 : UInt64) | Event.referenceRead => (0 : UInt64) | Event.blockEnter => (0 : UInt64) | Event.blockLeave => (0 : UInt64) | Event.loopObserve => (0 : UInt64) | Event.loopUpdate => (0 : UInt64) | Event.byteRead => (0 : UInt64) | Event.byteWrite => (0 : UInt64) | Event.byteComparison => (0 : UInt64) | Event.outputBoundary => (0 : UInt64) | Event.outputByte => (1 : UInt64) | Event.basisBoundary => (0 : UInt64) | Event.canonicalEof => (0 : UInt64) | Event.allocateValueUnits _ => (0 : UInt64) | Event.releaseValueUnits _ => (0 : UInt64))

@[expose] public def enteredFrames (event : Event) : UInt64 := (match event with | Event.instruction _ => (0 : UInt64) | Event.parameterBind => (0 : UInt64) | Event.referenceRead => (0 : UInt64) | Event.blockEnter => (1 : UInt64) | Event.blockLeave => (0 : UInt64) | Event.loopObserve => (0 : UInt64) | Event.loopUpdate => (0 : UInt64) | Event.byteRead => (0 : UInt64) | Event.byteWrite => (0 : UInt64) | Event.byteComparison => (0 : UInt64) | Event.outputBoundary => (0 : UInt64) | Event.outputByte => (0 : UInt64) | Event.basisBoundary => (0 : UInt64) | Event.canonicalEof => (0 : UInt64) | Event.allocateValueUnits _ => (0 : UInt64) | Event.releaseValueUnits _ => (0 : UInt64))

@[expose] public def leftFrames (event : Event) : UInt64 := (match event with | Event.instruction _ => (0 : UInt64) | Event.parameterBind => (0 : UInt64) | Event.referenceRead => (0 : UInt64) | Event.blockEnter => (0 : UInt64) | Event.blockLeave => (1 : UInt64) | Event.loopObserve => (0 : UInt64) | Event.loopUpdate => (0 : UInt64) | Event.byteRead => (0 : UInt64) | Event.byteWrite => (0 : UInt64) | Event.byteComparison => (0 : UInt64) | Event.outputBoundary => (0 : UInt64) | Event.outputByte => (0 : UInt64) | Event.basisBoundary => (0 : UInt64) | Event.canonicalEof => (0 : UInt64) | Event.allocateValueUnits _ => (0 : UInt64) | Event.releaseValueUnits _ => (0 : UInt64))

@[expose] public def eofCount (event : Event) : UInt64 := (match event with | Event.instruction _ => (0 : UInt64) | Event.parameterBind => (0 : UInt64) | Event.referenceRead => (0 : UInt64) | Event.blockEnter => (0 : UInt64) | Event.blockLeave => (0 : UInt64) | Event.loopObserve => (0 : UInt64) | Event.loopUpdate => (0 : UInt64) | Event.byteRead => (0 : UInt64) | Event.byteWrite => (0 : UInt64) | Event.byteComparison => (0 : UInt64) | Event.outputBoundary => (0 : UInt64) | Event.outputByte => (0 : UInt64) | Event.basisBoundary => (0 : UInt64) | Event.canonicalEof => (1 : UInt64) | Event.allocateValueUnits _ => (0 : UInt64) | Event.releaseValueUnits _ => (0 : UInt64))

@[expose] public def basisCount (event : Event) : UInt64 := (match event with | Event.instruction _ => (0 : UInt64) | Event.parameterBind => (0 : UInt64) | Event.referenceRead => (0 : UInt64) | Event.blockEnter => (0 : UInt64) | Event.blockLeave => (0 : UInt64) | Event.loopObserve => (0 : UInt64) | Event.loopUpdate => (0 : UInt64) | Event.byteRead => (0 : UInt64) | Event.byteWrite => (0 : UInt64) | Event.byteComparison => (0 : UInt64) | Event.outputBoundary => (0 : UInt64) | Event.outputByte => (0 : UInt64) | Event.basisBoundary => (1 : UInt64) | Event.canonicalEof => (0 : UInt64) | Event.allocateValueUnits _ => (0 : UInt64) | Event.releaseValueUnits _ => (0 : UInt64))

@[expose] public def maximum (lowValue : UInt64) (highValue : UInt64) : UInt64 := (if Uorc.Uorc.Core.Heap.less (lowValue) (highValue) then highValue else lowValue)

@[expose] public def checkedAdvance (ledger : Ledger) (event : Event) : Except (Error) (Ledger) := (if profileCompatible ((ledger).profile) then (match (LexLeanRuntime.checkedAdd ((ledger).semanticWork) (eventWork (event)) : Option (UInt64)) with | Option.none => Except.error (Error.wordOverflow) | Option.some work => (match (LexLeanRuntime.checkedAdd ((ledger).semanticStorageUnits) (allocatedUnits (event)) : Option (UInt64)) with | Option.none => Except.error (Error.wordOverflow) | Option.some allocated => (match (LexLeanRuntime.checkedSubtract (allocated) (releasedUnits (event)) : Option (UInt64)) with | Option.none => Except.error (Error.storageUnderflow) | Option.some storage => (match (LexLeanRuntime.checkedAdd ((ledger).activeFrames) (enteredFrames (event)) : Option (UInt64)) with | Option.none => Except.error (Error.wordOverflow) | Option.some entered => (match (LexLeanRuntime.checkedSubtract (entered) (leftFrames (event)) : Option (UInt64)) with | Option.none => Except.error (Error.frameUnderflow) | Option.some frames => (match (LexLeanRuntime.checkedAdd ((ledger).outputBytes) (outputCount (event)) : Option (UInt64)) with | Option.none => Except.error (Error.wordOverflow) | Option.some output => (match (LexLeanRuntime.checkedAdd ((ledger).acceptedArchives) (eofCount (event)) : Option (UInt64)) with | Option.none => Except.error (Error.wordOverflow) | Option.some archives => (match (LexLeanRuntime.checkedAdd ((ledger).basisObjects) (basisCount (event)) : Option (UInt64)) with | Option.none => Except.error (Error.wordOverflow) | Option.some basis => Except.ok (({ profile := (ledger).profile, semanticWork := work, semanticStorageUnits := storage, peakSemanticStorageUnits := maximum ((ledger).peakSemanticStorageUnits) (storage), outputBytes := output, activeFrames := frames, peakFrames := maximum ((ledger).peakFrames) (frames), acceptedArchives := archives, basisObjects := basis } : Ledger)))))))))) else Except.error (Error.unsupportedProfile))

@[expose] public def validLedger (ledger : Ledger) : Bool := (if Uorc.Uorc.Core.Heap.less ((ledger).peakSemanticStorageUnits) ((ledger).semanticStorageUnits) then false else (if Uorc.Uorc.Core.Heap.less ((ledger).peakFrames) ((ledger).activeFrames) then false else true))

public structure Outcome where
  ledger : Ledger
  error : Option (Error)

@[expose] public def charge (budget : Budget) (ledger : Ledger) (event : Event) : Except (Error) (Ledger) := (if profileCompatible ((budget).profile) then (if profileCompatible ((ledger).profile) then (if storageSupported ((budget).storage) then (if validLedger (ledger) then (match checkedAdvance (ledger) (event) with | Except.error failure => Except.error (failure) | Except.ok next => (if Uorc.Uorc.Core.Heap.less ((budget).maxSemanticWork) ((next).semanticWork) then Except.error (Error.workLimit) else (if storageBounded ((budget).storage) then (if Uorc.Uorc.Core.Heap.less ((budget).maxStorageUnits) ((next).peakSemanticStorageUnits) then Except.error (Error.storageLimit) else Except.ok (next)) else Except.ok (next)))) else Except.error (Error.invalidUsage)) else Except.error (Error.unsupportedStorage)) else Except.error (Error.unsupportedProfile)) else Except.error (Error.unsupportedProfile))

public inductive Decision where
  | accepted (_ : Ledger)
  | rejected (_ : Error)

@[expose] public def chargeDecision (budget : Budget) (ledger : Ledger) (event : Event) : Decision := (match charge (budget) (ledger) (event) with | Except.error failure => Decision.rejected (failure) | Except.ok next => Decision.accepted (next))

@[expose] public def commit (budget : Budget) (ledger : Ledger) (event : Event) : Outcome := (match chargeDecision (budget) (ledger) (event) with | Decision.rejected failure => ({ ledger := ledger, error := Option.some (failure) } : Outcome) | Decision.accepted next => ({ ledger := next, error := Option.none } : Outcome))

@[expose] public def isOperational (failure : Error) : Bool := (match failure with | Error.wordOverflow => true | Error.storageUnderflow => true | Error.frameUnderflow => true | Error.workLimit => false | Error.storageLimit => false | Error.invalidUsage => true | Error.unsupportedProfile => true | Error.unsupportedStorage => true)

@[expose, reducible] public def failurePreservesPrefix (previous : Ledger) (outcome : Outcome) : Prop := (match (outcome).error with | Option.none => (((outcome).ledger).semanticWork = ((outcome).ledger).semanticWork) | Option.some _ => ((outcome).ledger = previous))

public theorem commit_preserves_achieved_prefix_on_every_failure (budget : Budget) (ledger : Ledger) (event : Event) : failurePreservesPrefix (ledger) (commit (budget) (ledger) (event)) := by
  set_option linter.unusedSimpArgs false in
  cases llCase : chargeDecision (budget) (ledger) (event) <;>
    simp (config := {decide := true}) only [commit, failurePreservesPrefix, llCase, ite_true, ite_false]

public theorem instruction_work_agrees_with_canonical_schedule (opcode : Uorc.Uorc.Core.RuntimeOpcode.Opcode) : (Uorc.Uorc.Core.Types.wordToNat (instructionWork (opcode)) = Uorc.Uorc.Core.CanonicalCost.instructionWork (opcode)) := by
  set_option linter.unusedSimpArgs false in
  cases llCase : opcode <;>
    simp (config := {decide := true}) only [Uorc.Uorc.Core.CanonicalCost.instructionWork, Uorc.Uorc.Core.Types.wordToNat, instructionWork, llCase, ite_true, ite_false]

public inductive CacheError where
  | missing
  | invalid
  | wordOverflow
  | storageUnderflow
  | heap (_ : Uorc.Uorc.Core.Heap.HeapError)

@[expose] public def emptyUnitsTable : Uorc.Uorc.Core.RuntimeTable.Table := Uorc.Uorc.Core.RuntimeTable.emptyTable (Uorc.Uorc.Core.RuntimeTable.TableKind.slots (Uorc.Uorc.Core.RuntimeValue.RootRole.typeCache))

@[expose] public def isUnitsTable (table : Uorc.Uorc.Core.RuntimeTable.Table) : Bool := (match (table).kind with | Uorc.Uorc.Core.RuntimeTable.TableKind.slots role => (LexLeanRuntime.equal (Uorc.Uorc.Core.RuntimeValue.roleTag (role)) (Uorc.Uorc.Core.RuntimeValue.roleTag (Uorc.Uorc.Core.RuntimeValue.RootRole.typeCache)) : Bool) | Uorc.Uorc.Core.RuntimeTable.TableKind.metadata _ => false)

@[expose] public def unitsAt (arena : Uorc.Uorc.Core.Heap.Arena) (table : Uorc.Uorc.Core.RuntimeTable.Table) (key : UInt64) : Except (CacheError) (UInt64) := (if isUnitsTable (table) then (match Uorc.Uorc.Core.RuntimeTable.lookup (arena) (table) (key) with | Except.error failure => Except.error (CacheError.heap (failure)) | Except.ok leaf => (if Uorc.Uorc.Core.RuntimeValue.isNull (leaf) then Except.error (CacheError.missing) else (match Uorc.Uorc.Core.RuntimeProgram.valueAtLeaf (arena) (leaf) (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) with | Except.error _ => Except.error (CacheError.invalid) | Except.ok value => (match value with | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.natural units => Except.ok (units) | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.byte _ => Except.error (CacheError.invalid) | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.predicate _ => Except.error (CacheError.invalid) | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.sequence _ => Except.error (CacheError.invalid) | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.store _ _ => Except.error (CacheError.invalid))))) else Except.error (CacheError.invalid))

@[expose] public def beginBind (arena : Uorc.Uorc.Core.Heap.Arena) (table : Uorc.Uorc.Core.RuntimeTable.Table) (key : UInt64) (units : UInt64) : Except (Uorc.Uorc.Core.Heap.HeapError) (Uorc.Uorc.Core.RuntimeTable.PutTransition) := (if isUnitsTable (table) then Uorc.Uorc.Core.RuntimeTable.beginPut (arena) (table) (key) (Uorc.Uorc.Core.RuntimeTable.PutLeaf.slot (Uorc.Uorc.Core.RuntimeValue.RootRole.typeCache) (Uorc.Uorc.Core.RuntimeValue.RuntimeValue.natural (units))) else Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode))

@[expose] public def beginErase (arena : Uorc.Uorc.Core.Heap.Arena) (table : Uorc.Uorc.Core.RuntimeTable.Table) (key : UInt64) : Except (Uorc.Uorc.Core.Heap.HeapError) (Uorc.Uorc.Core.RuntimeTable.PutTransition) := (if isUnitsTable (table) then Uorc.Uorc.Core.RuntimeTable.beginErase (arena) (table) (key) else Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode))

@[expose] public def stepBinding (transition : Uorc.Uorc.Core.RuntimeTable.PutTransition) : Uorc.Uorc.Core.RuntimeTable.PutTransition := Uorc.Uorc.Core.RuntimeTable.step (transition)

@[expose] public def cancelBinding (transition : Uorc.Uorc.Core.RuntimeTable.PutTransition) : Uorc.Uorc.Core.RuntimeTable.PutTransition := Uorc.Uorc.Core.RuntimeTable.cancel (transition)

@[expose] public def initialStoreUnits : UInt64 := (1 : UInt64)

@[expose] public def validStoreUnits (units : UInt64) : Bool := (match (LexLeanRuntime.checkedSubtract (units) ((1 : UInt64)) : Option (UInt64)) with | Option.none => false | Option.some payload => (match (LexLeanRuntime.checkedQuotient (payload) ((9 : UInt64)) : Option (UInt64)) with | Option.none => false | Option.some count => (match (LexLeanRuntime.checkedMultiply (count) ((9 : UInt64)) : Option (UInt64)) with | Option.none => false | Option.some represented => (LexLeanRuntime.equal (represented) (payload) : Bool))))

@[expose] public def storeUnitsAfter (previousUnits : UInt64) (defaultByte : UInt8) (observedOld : UInt8) (newByte : UInt8) : Except (CacheError) (UInt64) := (if (if (LexLeanRuntime.equal (observedOld) (defaultByte) : Bool) then false else Uorc.Uorc.Core.Heap.less (previousUnits) ((10 : UInt64))) then Except.error (CacheError.invalid) else (if validStoreUnits (previousUnits) then (if (LexLeanRuntime.equal (observedOld) (defaultByte) : Bool) then (if (LexLeanRuntime.equal (newByte) (defaultByte) : Bool) then Except.ok (previousUnits) else (match (LexLeanRuntime.checkedAdd (previousUnits) ((9 : UInt64)) : Option (UInt64)) with | Option.none => Except.error (CacheError.wordOverflow) | Option.some next => Except.ok (next))) else (if (LexLeanRuntime.equal (newByte) (defaultByte) : Bool) then (match (LexLeanRuntime.checkedSubtract (previousUnits) ((9 : UInt64)) : Option (UInt64)) with | Option.none => Except.error (CacheError.storageUnderflow) | Option.some next => (if validStoreUnits (next) then Except.ok (next) else Except.error (CacheError.storageUnderflow))) else Except.ok (previousUnits))) else Except.error (CacheError.invalid)))

@[expose] public def fixedValueUnits (valueType : Uorc.Uorc.Core.RuntimeValue.RuntimeType) : Option (UInt64) := (match valueType with | Uorc.Uorc.Core.RuntimeValue.RuntimeType.natural => Option.some ((8 : UInt64)) | Uorc.Uorc.Core.RuntimeValue.RuntimeType.byte => Option.some ((1 : UInt64)) | Uorc.Uorc.Core.RuntimeValue.RuntimeType.predicate => Option.some ((1 : UInt64)) | Uorc.Uorc.Core.RuntimeValue.RuntimeType.sequence => Option.none | Uorc.Uorc.Core.RuntimeValue.RuntimeType.store => Option.none)

@[expose, reducible] public def cacheWitnessMatches (units : UInt64) (referenceValue : Uorc.Uorc.Core.ReferenceSemantics.Value) : Prop := (Uorc.Uorc.Core.Types.wordToNat (units) = Uorc.Uorc.Core.CanonicalCost.referenceValueUnits (referenceValue))

@[expose] public def fixedUnitsMeaning (valueType : Uorc.Uorc.Core.RuntimeValue.RuntimeType) : Option (Nat) := (match fixedValueUnits (valueType) with | Option.none => Option.none | Option.some units => Option.some (Uorc.Uorc.Core.Types.wordToNat (units)))

public theorem fixed_natural_units_match_core_measure (word : Nat) : (fixedUnitsMeaning (Uorc.Uorc.Core.RuntimeValue.RuntimeType.natural) = Option.some (Uorc.Uorc.Core.CanonicalCost.referenceValueUnits (Uorc.Uorc.Core.ReferenceSemantics.Value.natural (word)))) := by
  rfl

public theorem fixed_byte_units_match_core_measure (byteValue : Nat) : (fixedUnitsMeaning (Uorc.Uorc.Core.RuntimeValue.RuntimeType.byte) = Option.some (Uorc.Uorc.Core.CanonicalCost.referenceValueUnits (Uorc.Uorc.Core.ReferenceSemantics.Value.byte (byteValue)))) := by
  rfl

public theorem fixed_predicate_units_match_core_measure (predicateValue : Bool) : (fixedUnitsMeaning (Uorc.Uorc.Core.RuntimeValue.RuntimeType.predicate) = Option.some (Uorc.Uorc.Core.CanonicalCost.referenceValueUnits (Uorc.Uorc.Core.ReferenceSemantics.Value.predicate (predicateValue)))) := by
  rfl

@[expose] public def referenceRoleEvent (role : Uorc.Uorc.Core.RuntimeOpcode.OperandRole) : Option (Event) := (match role with | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.absent => Option.none | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.immediateNatural => Option.none | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.immediateByte => Option.none | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.immediatePredicate => Option.none | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.localNatural => Option.some (Event.referenceRead) | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.localByte => Option.some (Event.referenceRead) | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.localPredicate => Option.some (Event.referenceRead) | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.localSequence => Option.some (Event.referenceRead) | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.localStore => Option.some (Event.referenceRead) | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.localAny => Option.some (Event.referenceRead) | Uorc.Uorc.Core.RuntimeOpcode.OperandRole.blockReference => Option.some (Event.referenceRead))

@[expose] public def prefixEvent (opcode : Uorc.Uorc.Core.RuntimeOpcode.Opcode) (position : UInt64) : Except (Error) (Option (Event)) := (if (LexLeanRuntime.equal (position) ((0 : UInt64)) : Bool) then Except.ok (Option.some (Event.instruction (opcode))) else (if Uorc.Uorc.Core.Heap.less (position) ((5 : UInt64)) then (let signature : Uorc.Uorc.Core.RuntimeOpcode.Spec := Uorc.Uorc.Core.RuntimeOpcode.spec (opcode); Except.ok (referenceRoleEvent ((if (LexLeanRuntime.equal (position) ((1 : UInt64)) : Bool) then (signature).operand0 else (if (LexLeanRuntime.equal (position) ((2 : UInt64)) : Bool) then (signature).operand1 else (if (LexLeanRuntime.equal (position) ((3 : UInt64)) : Bool) then (signature).operand2 else (signature).operand3)))))) else (if (LexLeanRuntime.equal (position) ((5 : UInt64)) : Bool) then Except.ok (Option.none) else Except.error (Error.invalidUsage))))

end Uorc.Uorc.Core.RuntimeMachineSemantic
