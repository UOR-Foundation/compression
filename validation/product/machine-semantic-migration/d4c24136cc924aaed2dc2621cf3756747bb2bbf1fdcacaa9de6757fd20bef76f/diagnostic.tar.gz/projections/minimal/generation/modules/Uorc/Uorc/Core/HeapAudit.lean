module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeValue
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.HeapAudit

public structure Row where
  handle : Uorc.Uorc.Core.RuntimeValue.Handle
  entry : Uorc.Uorc.Core.Heap.Entry

public structure Scan where
  rows : List (Row)
  wellFormed : Bool

public structure Audit where
  shape : Bool
  acyclic : Bool
  counts : Bool
  weights : Bool
  totals : Bool
  cursor : Bool
  nodes : Bool

@[expose] public def appendRows : (xs : List (Row)) -> (ys : List (Row)) -> List (Row)
  | List.nil, ys => ys
  | List.cons head tail, ys => (head :: appendRows (tail) (ys))

@[expose] public def scanIndex : (depth : Nat) -> (tree : Uorc.Uorc.Core.Heap.Index) -> (key : UInt64) -> (bit : UInt64) -> Scan
  | Nat.zero, tree, key, _bit => (match tree with | Uorc.Uorc.Core.Heap.Index.empty => ({ rows := ([] : List (Row)), wellFormed := true } : Scan) | Uorc.Uorc.Core.Heap.Index.leaf entry => ({ rows := (({ handle := ({ id := key } : Uorc.Uorc.Core.RuntimeValue.Handle), entry := entry } : Row) :: ([] : List (Row))), wellFormed := true } : Scan) | Uorc.Uorc.Core.Heap.Index.branch _ _ => ({ rows := ([] : List (Row)), wellFormed := false } : Scan))
  | Nat.succ remaining, tree, key, bit => (match tree with | Uorc.Uorc.Core.Heap.Index.empty => ({ rows := ([] : List (Row)), wellFormed := true } : Scan) | Uorc.Uorc.Core.Heap.Index.leaf _ => ({ rows := ([] : List (Row)), wellFormed := false } : Scan) | Uorc.Uorc.Core.Heap.Index.branch left right => (let leftScan : Scan := scanIndex (remaining) (left) (key) (Uorc.Uorc.Core.Heap.nextKey (bit)); (let rightScan : Scan := scanIndex (remaining) (right) ((LexLeanRuntime.bitOr (key) (bit) : UInt64)) (Uorc.Uorc.Core.Heap.nextKey (bit)); ({ rows := appendRows ((leftScan).rows) ((rightScan).rows), wellFormed := (if (leftScan).wellFormed then (rightScan).wellFormed else false) } : Scan))))

@[expose] public def wordToNatAux : (depth : Nat) -> (value : UInt64) -> Nat
  | Nat.zero, _value => 0
  | Nat.succ remaining, value => ((if Uorc.Uorc.Core.Heap.lowBit (value) then 1 else 0) + (LexLeanRuntime.multiply (2) (wordToNatAux (remaining) (Uorc.Uorc.Core.Heap.nextKey (value))) : Nat))

@[expose] public def wordToNat (value : UInt64) : Nat := wordToNatAux (64) (value)

@[expose] public def references (node : Uorc.Uorc.Core.Heap.Node) : List (Uorc.Uorc.Core.RuntimeValue.Handle) := (match node with | Uorc.Uorc.Core.Heap.Node.image _ _ => ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf image _ _ => (image :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ left right => (left :: (right :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) | Uorc.Uorc.Core.Heap.Node.storeBranch left right => (left :: (right :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) | Uorc.Uorc.Core.Heap.Node.slot _ value => (Uorc.Uorc.Core.RuntimeValue.valueHandle (value) :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))) | Uorc.Uorc.Core.Heap.Node.rootBranch _ left right => (left :: (right :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ target => (target :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))) | Uorc.Uorc.Core.Heap.Node.metadataBranch _ left right => (left :: (right :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ target => (target :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))

@[expose] public def occurrences : (handles : List (Uorc.Uorc.Core.RuntimeValue.Handle)) -> (target : Uorc.Uorc.Core.RuntimeValue.Handle) -> Nat
  | List.nil, _target => 0
  | List.cons head tail, target => ((if Uorc.Uorc.Core.RuntimeValue.sameHandle (head) (target) then 1 else 0) + occurrences (tail) (target))

@[expose] public def edgeCount : (rows : List (Row)) -> (target : Uorc.Uorc.Core.RuntimeValue.Handle) -> Nat
  | List.nil, _target => 0
  | List.cons head tail, target => (occurrences (references (((head).entry).node)) (target) + edgeCount (tail) (target))

@[expose] public def lengthHandles : (handles : List (Uorc.Uorc.Core.RuntimeValue.Handle)) -> Nat
  | List.nil => 0
  | List.cons _ tail => (1 + lengthHandles (tail))

@[expose] public def rowCount : (rows : List (Row)) -> Nat
  | List.nil => 0
  | List.cons _ tail => (1 + rowCount (tail))

@[expose] public def referenceWeight (node : Uorc.Uorc.Core.Heap.Node) : Nat := (match node with | Uorc.Uorc.Core.Heap.Node.image _ bytes => (48 + (LexLeanRuntime.length (bytes) : Nat)) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf _ _ _ => 64 | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ _ _ => 72 | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => 40 | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => 48 | Uorc.Uorc.Core.Heap.Node.slot _ _ => 64 | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => 56 | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => 56 | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => 56 | Uorc.Uorc.Core.Heap.Node.metadataBranch _ _ _ => 56 | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => 48 | Uorc.Uorc.Core.Heap.Node.imageReservation _ length => (48 + wordToNat (length)))

@[expose] public def sumWeights : (rows : List (Row)) -> Nat
  | List.nil => 0
  | List.cons head tail => (wordToNat (((head).entry).weight) + sumWeights (tail))

@[expose] public def older : (handles : List (Uorc.Uorc.Core.RuntimeValue.Handle)) -> (parent : Uorc.Uorc.Core.RuntimeValue.Handle) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> Bool
  | List.nil, _parent, _arena => true
  | List.cons head tail, parent, arena => (if (if Uorc.Uorc.Core.RuntimeValue.isNull (head) then true else (if Uorc.Uorc.Core.Heap.less ((head).id) ((parent).id) then (match Uorc.Uorc.Core.Heap.lookup (arena) (head) with | Except.error _ => false | Except.ok _ => true) else false)) then older (tail) (parent) (arena) else false)

@[expose] public def acyclicRows : (rows : List (Row)) -> (all : List (Row)) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> Bool
  | List.nil, _all, _arena => true
  | List.cons head tail, all, arena => (if (if (if Uorc.Uorc.Core.RuntimeValue.isNull ((head).handle) then false else true) then (if (if (arena).exhausted then (if Uorc.Uorc.Core.Heap.less ((arena).nextHandle) (((head).handle).id) then false else true) else Uorc.Uorc.Core.Heap.less (((head).handle).id) ((arena).nextHandle)) then older (references (((head).entry).node)) ((head).handle) (arena) else false) else false) then acyclicRows (tail) (all) (arena) else false)

@[expose] public def countsRows : (rows : List (Row)) -> (all : List (Row)) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> Bool
  | List.nil, _all, _arena => true
  | List.cons head tail, all, arena => (if (if (if (LexLeanRuntime.equal (((head).entry).incoming) ((0 : UInt64)) : Bool) then false else true) then (Nat.beq (wordToNat (((head).entry).incoming)) ((wordToNat (((head).entry).roots) + (edgeCount (all) ((head).handle) + (if ((arena).cursor).rootStep then 0 else occurrences (((arena).cursor).pending) ((head).handle)))))) else false) then countsRows (tail) (all) (arena) else false)

@[expose] public def weightsRows : (rows : List (Row)) -> (all : List (Row)) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> Bool
  | List.nil, _all, _arena => true
  | List.cons head tail, all, arena => (if (Nat.beq (wordToNat (((head).entry).weight)) (referenceWeight (((head).entry).node))) then weightsRows (tail) (all) (arena) else false)

@[expose] public def nodesRows : (rows : List (Row)) -> (all : List (Row)) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> Bool
  | List.nil, _all, _arena => true
  | List.cons head tail, all, arena => (if (if Uorc.Uorc.Core.Heap.validNode (arena) (((head).entry).node) then (if Uorc.Uorc.Core.Heap.isReservation (((head).entry).node) then (if (LexLeanRuntime.equal (((head).entry).incoming) ((1 : UInt64)) : Bool) then (LexLeanRuntime.equal (((head).entry).roots) ((1 : UInt64)) : Bool) else false) else true) else false) then nodesRows (tail) (all) (arena) else false)

@[expose] public def audit (arena : Uorc.Uorc.Core.Heap.Arena) : Audit := (let scan : Scan := scanIndex (64) ((arena).index) ((0 : UInt64)) ((9223372036854775808 : UInt64)); ({ shape := (scan).wellFormed, acyclic := acyclicRows ((scan).rows) ((scan).rows) (arena), counts := countsRows ((scan).rows) ((scan).rows) (arena), weights := weightsRows ((scan).rows) ((scan).rows) (arena), totals := (if (if (Nat.beq (sumWeights ((scan).rows)) (wordToNat ((arena).ownedBytes))) then (Nat.beq (rowCount ((scan).rows)) (wordToNat ((arena).liveEntries))) else false) then (Nat.ble ((sumWeights ((scan).rows) + (if ((arena).cursor).rootStep then 0 else (LexLeanRuntime.multiply (16) (lengthHandles (((arena).cursor).pending)) : Nat)))) (wordToNat ((arena).maxOwnedBytes))) else false), cursor := (if (Nat.beq (lengthHandles (((arena).cursor).pending)) (wordToNat (((arena).cursor).pendingCount))) then (if ((arena).cursor).rootStep then (match ((arena).cursor).pending with | List.nil => false | List.cons head tail => (if (Nat.beq (lengthHandles (tail)) (0)) then (match Uorc.Uorc.Core.Heap.lookup (arena) (head) with | Except.error _ => false | Except.ok entry => (if (LexLeanRuntime.equal ((entry).roots) ((0 : UInt64)) : Bool) then false else true)) else false)) else true) else false), nodes := nodesRows ((scan).rows) ((scan).rows) (arena) } : Audit))

@[expose] public def passed (result : Audit) : Bool := (if (result).shape then (if (result).acyclic then (if (result).counts then (if (result).weights then (if (result).totals then (if (result).cursor then (if (result).nodes then true else false) else false) else false) else false) else false) else false) else false)

@[expose] public def interpretSequence : (fuel : Nat) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> (handle : Uorc.Uorc.Core.RuntimeValue.Handle) -> Except (Uorc.Uorc.Core.Heap.HeapError) (ByteArray)
  | Nat.zero, _arena, _handle => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode)
  | Nat.succ remaining, arena, handle => (if Uorc.Uorc.Core.RuntimeValue.isNull (handle) then Except.ok (_root_.ByteArray.mk #[]) else (match Uorc.Uorc.Core.Heap.lookup (arena) (handle) with | Except.error _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Except.ok entry => (match (entry).node with | Uorc.Uorc.Core.Heap.Node.sequenceLeaf image offset length => (match Uorc.Uorc.Core.Heap.lookup (arena) (image) with | Except.error _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Except.ok imageEntry => (match (imageEntry).node with | Uorc.Uorc.Core.Heap.Node.image _ bs => (match (LexLeanRuntime.slice (bs) (wordToNat (offset)) (wordToNat (length)) : Option (ByteArray)) with | Option.none => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Option.some bytes => Except.ok (bytes)) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.metadataBranch _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode))) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ left right => (match interpretSequence (remaining) (arena) (left) with | Except.error _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Except.ok leftBytes => (match interpretSequence (remaining) (arena) (right) with | Except.error _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Except.ok rightBytes => Except.ok ((LexLeanRuntime.append (leftBytes) (rightBytes) : ByteArray)))) | Uorc.Uorc.Core.Heap.Node.image _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.metadataBranch _ _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Except.error (Uorc.Uorc.Core.Heap.HeapError.invalidNode))))

@[expose] public def rootRows : (rows : List (Row)) -> (roots : List (Uorc.Uorc.Core.RuntimeValue.Handle)) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> Bool
  | List.nil, _roots, _arena => true
  | List.cons head tail, roots, arena => (if (Nat.beq (wordToNat (((head).entry).roots)) ((occurrences (roots) ((head).handle) + (if ((arena).cursor).rootStep then occurrences (((arena).cursor).pending) ((head).handle) else 0)))) then rootRows (tail) (roots) (arena) else false)

@[expose] public def liveRootTickets : (roots : List (Uorc.Uorc.Core.RuntimeValue.Handle)) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> Bool
  | List.nil, _arena => true
  | List.cons head tail, arena => (if (if Uorc.Uorc.Core.RuntimeValue.isNull (head) then false else true) then (if (match Uorc.Uorc.Core.Heap.lookup (arena) (head) with | Except.error _ => false | Except.ok _ => true) then liveRootTickets (tail) (arena) else false) else false)

@[expose] public def auditRoots (arena : Uorc.Uorc.Core.Heap.Arena) (roots : List (Uorc.Uorc.Core.RuntimeValue.Handle)) : Bool := (let scan : Scan := scanIndex (64) ((arena).index) ((0 : UInt64)) ((9223372036854775808 : UInt64)); (if passed (audit (arena)) then (if liveRootTickets (roots) (arena) then rootRows ((scan).rows) (roots) (arena) else false) else false))

end Uorc.Uorc.Core.HeapAudit
