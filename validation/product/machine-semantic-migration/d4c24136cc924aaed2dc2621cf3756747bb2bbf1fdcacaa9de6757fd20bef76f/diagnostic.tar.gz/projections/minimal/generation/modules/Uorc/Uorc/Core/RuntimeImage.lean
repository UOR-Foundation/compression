module
public import Init
public import LexLeanRuntime.Portable
public import LexLeanRuntime.Collections
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeValue
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeImage

public inductive ImageFailure where
  | heap (_ : Uorc.Uorc.Core.Heap.HeapError)
  | invalidShape
  | range
  | lengthOverflow

public structure BorrowedSpan where
  image : Uorc.Uorc.Core.RuntimeValue.Handle
  offset : UInt64
  length : UInt64

@[expose] public def wordToNatAux : (depth : Nat) -> (value : UInt64) -> Nat
  | Nat.zero, _value => 0
  | Nat.succ remaining, value => ((if Uorc.Uorc.Core.Heap.lowBit (value) then 1 else 0) + (LexLeanRuntime.multiply (2) (wordToNatAux (remaining) (Uorc.Uorc.Core.Heap.nextKey (value))) : Nat))

@[expose] public def nodeByte (node : Uorc.Uorc.Core.Heap.Node) (offset : UInt64) : Except (ImageFailure) (UInt8) := (match node with | Uorc.Uorc.Core.Heap.Node.image f0 f1 => (if Uorc.Uorc.Core.Heap.isControlKind (f0) then Except.error (ImageFailure.invalidShape) else (match (LexLeanRuntime.index (f1) (wordToNatAux (64) (offset)) : Option (UInt8)) with | Option.none => Except.error (ImageFailure.range) | Option.some byteValue => Except.ok (byteValue))) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataBranch _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Except.error (ImageFailure.invalidShape))

@[expose] public def nodeLength (node : Uorc.Uorc.Core.Heap.Node) : Except (ImageFailure) (UInt64) := (match node with | Uorc.Uorc.Core.Heap.Node.image f0 f1 => (if Uorc.Uorc.Core.Heap.isControlKind (f0) then Except.error (ImageFailure.invalidShape) else (match Uorc.Uorc.Core.Heap.wordOfNat ((LexLeanRuntime.length (f1) : Nat)) with | Option.none => Except.error (ImageFailure.lengthOverflow) | Option.some size => Except.ok (size))) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataBranch _ _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Except.error (ImageFailure.invalidShape) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Except.error (ImageFailure.invalidShape))

@[expose] public def readByte (arena : Uorc.Uorc.Core.Heap.Arena) (image : Uorc.Uorc.Core.RuntimeValue.Handle) (absoluteOffset : UInt64) : Except (ImageFailure) (UInt8) := (match Uorc.Uorc.Core.Heap.lookup (arena) (image) with | Except.error heapFailure => Except.error (ImageFailure.heap (heapFailure)) | Except.ok entry => nodeByte ((entry).node) (absoluteOffset))

@[expose] public def imageLength (arena : Uorc.Uorc.Core.Heap.Arena) (image : Uorc.Uorc.Core.RuntimeValue.Handle) : Except (ImageFailure) (UInt64) := (match Uorc.Uorc.Core.Heap.lookup (arena) (image) with | Except.error heapFailure => Except.error (ImageFailure.heap (heapFailure)) | Except.ok entry => nodeLength ((entry).node))

@[expose] public def validateRange (image : Uorc.Uorc.Core.RuntimeValue.Handle) (offset : UInt64) (length : UInt64) (size : UInt64) : Except (ImageFailure) (BorrowedSpan) := (match (LexLeanRuntime.checkedAdd (offset) (length) : Option (UInt64)) with | Option.none => Except.error (ImageFailure.lengthOverflow) | Option.some endOffset => (if (LexLeanCollections.lessThan (size) (endOffset) : Bool) then Except.error (ImageFailure.range) else Except.ok (({ image := image, offset := offset, length := length } : BorrowedSpan))))

@[expose] public def validateSpan (arena : Uorc.Uorc.Core.Heap.Arena) (image : Uorc.Uorc.Core.RuntimeValue.Handle) (offset : UInt64) (length : UInt64) : Except (ImageFailure) (BorrowedSpan) := (match imageLength (arena) (image) with | Except.error failure => Except.error (failure) | Except.ok size => validateRange (image) (offset) (length) (size))

@[expose] public def spanOffset (span : BorrowedSpan) (relativeIndex : UInt64) : Except (ImageFailure) (UInt64) := (if (LexLeanCollections.lessThan (relativeIndex) ((span).length) : Bool) then (match (LexLeanRuntime.checkedAdd ((span).offset) (relativeIndex) : Option (UInt64)) with | Option.none => Except.error (ImageFailure.lengthOverflow) | Option.some absoluteOffset => Except.ok (absoluteOffset)) else Except.error (ImageFailure.range))

@[expose] public def readSpanByte (arena : Uorc.Uorc.Core.Heap.Arena) (span : BorrowedSpan) (relativeIndex : UInt64) : Except (ImageFailure) (UInt8) := (match spanOffset (span) (relativeIndex) with | Except.error failure => Except.error (failure) | Except.ok absoluteOffset => readByte (arena) ((span).image) (absoluteOffset))

@[expose] public def readByteCost (_arena : Uorc.Uorc.Core.Heap.Arena) (_image : Uorc.Uorc.Core.RuntimeValue.Handle) (_absoluteOffset : UInt64) : UInt64 := (1 : UInt64)

@[expose] public def imageLengthCost (_arena : Uorc.Uorc.Core.Heap.Arena) (_image : Uorc.Uorc.Core.RuntimeValue.Handle) : UInt64 := (1 : UInt64)

@[expose] public def validateSpanCost (_arena : Uorc.Uorc.Core.Heap.Arena) (_image : Uorc.Uorc.Core.RuntimeValue.Handle) (_offset : UInt64) (_length : UInt64) : UInt64 := (1 : UInt64)

@[expose] public def readSpanByteCost (_arena : Uorc.Uorc.Core.Heap.Arena) (_span : BorrowedSpan) (_relativeIndex : UInt64) : UInt64 := (1 : UInt64)

end Uorc.Uorc.Core.RuntimeImage
