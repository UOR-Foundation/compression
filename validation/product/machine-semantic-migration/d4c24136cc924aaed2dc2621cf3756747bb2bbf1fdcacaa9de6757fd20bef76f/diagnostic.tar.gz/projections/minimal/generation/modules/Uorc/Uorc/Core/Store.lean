module
public import Init
public import LexLeanRuntime.Portable
public import LexLeanRuntime.Laws
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.Store

public inductive Trie where
  | empty
  | leaf (_ : UInt8)
  | branch (_ : Trie) (_ : Trie)

public structure Store where
  defaultByte : UInt8
  root : Trie

public structure ReferenceException where
  key : UInt64
  value : UInt8

public structure ReferenceStore where
  defaultByte : UInt8
  exceptions : List (ReferenceException)

@[expose] public def lowBit (key : UInt64) : Bool := (LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (key) ((1 : UInt64)) : UInt64)) ((1 : UInt64)) : Bool)

@[expose] public def nextKey (key : UInt64) : UInt64 := (match (LexLeanRuntime.shiftRight (key) ((1 : UInt32)) : Option (UInt64)) with | Option.none => (0 : UInt64) | Option.some shifted => shifted)

@[expose] public def trieEmpty (tree : Trie) : Bool := (match tree with | Trie.empty => true | Trie.leaf _ => false | Trie.branch _ _ => false)

@[expose] public def compactBranch (left : Trie) (right : Trie) : Trie := (if (trieEmpty (left) && trieEmpty (right)) then Trie.empty else Trie.branch (left) (right))

@[expose] public def leftChild (tree : Trie) : Trie := (match tree with | Trie.empty => Trie.empty | Trie.leaf _ => Trie.empty | Trie.branch left _ => left)

@[expose] public def rightChild (tree : Trie) : Trie := (match tree with | Trie.empty => Trie.empty | Trie.leaf _ => Trie.empty | Trie.branch _ right => right)

@[expose] public def readTrie : (depth : Nat) -> (tree : Trie) -> (key : UInt64) -> (defaultByte : UInt8) -> UInt8
  | Nat.zero, tree, _key, defaultByte => (match tree with | Trie.empty => defaultByte | Trie.leaf leafByte => leafByte | Trie.branch _ _ => defaultByte)
  | Nat.succ remaining, tree, key, defaultByte => (match tree with | Trie.empty => defaultByte | Trie.leaf _ => defaultByte | Trie.branch left right => readTrie (remaining) ((if lowBit (key) then right else left)) (nextKey (key)) (defaultByte))

@[expose] public def writeTrie : (depth : Nat) -> (tree : Trie) -> (key : UInt64) -> (value : UInt8) -> (defaultByte : UInt8) -> Trie
  | Nat.zero, _tree, _key, value, defaultByte => (if (LexLeanRuntime.equal (value) (defaultByte) : Bool) then Trie.empty else Trie.leaf (value))
  | Nat.succ remaining, tree, key, value, defaultByte => (if lowBit (key) then compactBranch (leftChild (tree)) (writeTrie (remaining) (rightChild (tree)) (nextKey (key)) (value) (defaultByte)) else compactBranch (writeTrie (remaining) (leftChild (tree)) (nextKey (key)) (value) (defaultByte)) (rightChild (tree)))

@[expose] public def validTrie : (depth : Nat) -> (tree : Trie) -> (defaultByte : UInt8) -> Bool
  | Nat.zero, tree, defaultByte => (match tree with | Trie.empty => true | Trie.leaf leafByte => (!(LexLeanRuntime.equal (leafByte) (defaultByte) : Bool)) | Trie.branch _ _ => false)
  | Nat.succ remaining, tree, defaultByte => (match tree with | Trie.empty => true | Trie.leaf _ => false | Trie.branch left right => ((!(trieEmpty (left) && trieEmpty (right))) && (validTrie (remaining) (left) (defaultByte) && validTrie (remaining) (right) (defaultByte))))

@[expose] public def newStore (defaultByte : UInt8) : Store := ({ defaultByte := defaultByte, root := Trie.empty } : Store)

@[expose] public def readStore (store : Store) (key : UInt64) : UInt8 := readTrie (64) ((store).root) (key) ((store).defaultByte)

@[expose] public def writeStore (store : Store) (key : UInt64) (value : UInt8) : Store := (if (LexLeanRuntime.equal (readStore (store) (key)) (value) : Bool) then store else ({ defaultByte := (store).defaultByte, root := writeTrie (64) ((store).root) (key) (value) ((store).defaultByte) } : Store))

@[expose] public def readExceptions : (exceptions : List (ReferenceException)) -> (key : UInt64) -> (defaultByte : UInt8) -> UInt8
  | List.nil, _key, defaultByte => defaultByte
  | List.cons entry rest, key, defaultByte => (if (LexLeanRuntime.equal ((entry).key) (key) : Bool) then (entry).value else readExceptions (rest) (key) (defaultByte))

@[expose] public def eraseException : (exceptions : List (ReferenceException)) -> (key : UInt64) -> List (ReferenceException)
  | List.nil, _key => ([] : List (ReferenceException))
  | List.cons entry rest, key => (if (LexLeanRuntime.equal ((entry).key) (key) : Bool) then eraseException (rest) (key) else (entry :: eraseException (rest) (key)))

@[expose] public def newReferenceStore (defaultByte : UInt8) : ReferenceStore := ({ defaultByte := defaultByte, exceptions := ([] : List (ReferenceException)) } : ReferenceStore)

@[expose] public def readReferenceStore (store : ReferenceStore) (key : UInt64) : UInt8 := readExceptions ((store).exceptions) (key) ((store).defaultByte)

@[expose] public def writeReferenceStore (store : ReferenceStore) (key : UInt64) (value : UInt8) : ReferenceStore := ({ defaultByte := (store).defaultByte, exceptions := (if (LexLeanRuntime.equal (value) ((store).defaultByte) : Bool) then eraseException ((store).exceptions) (key) else (({ key := key, value := value } : ReferenceException) :: eraseException ((store).exceptions) (key))) } : ReferenceStore)

public theorem store_read_written_0 : (readStore (writeStore (newStore ((7 : UInt8))) ((0 : UInt64)) ((13 : UInt8))) ((0 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_0 : (writeStore (writeStore (newStore ((7 : UInt8))) ((0 : UInt64)) ((13 : UInt8))) ((0 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_0 : (readStore (newStore ((7 : UInt8))) ((0 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_read_written_1 : (readStore (writeStore (newStore ((7 : UInt8))) ((1 : UInt64)) ((13 : UInt8))) ((1 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_1 : (writeStore (writeStore (newStore ((7 : UInt8))) ((1 : UInt64)) ((13 : UInt8))) ((1 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_1 : (readStore (newStore ((7 : UInt8))) ((1 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_read_written_2 : (readStore (writeStore (newStore ((7 : UInt8))) ((2 : UInt64)) ((13 : UInt8))) ((2 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_2 : (writeStore (writeStore (newStore ((7 : UInt8))) ((2 : UInt64)) ((13 : UInt8))) ((2 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_2 : (readStore (newStore ((7 : UInt8))) ((2 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_read_written_255 : (readStore (writeStore (newStore ((7 : UInt8))) ((255 : UInt64)) ((13 : UInt8))) ((255 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_255 : (writeStore (writeStore (newStore ((7 : UInt8))) ((255 : UInt64)) ((13 : UInt8))) ((255 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_255 : (readStore (newStore ((7 : UInt8))) ((255 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_read_written_256 : (readStore (writeStore (newStore ((7 : UInt8))) ((256 : UInt64)) ((13 : UInt8))) ((256 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_256 : (writeStore (writeStore (newStore ((7 : UInt8))) ((256 : UInt64)) ((13 : UInt8))) ((256 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_256 : (readStore (newStore ((7 : UInt8))) ((256 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_read_written_4096 : (readStore (writeStore (newStore ((7 : UInt8))) ((4096 : UInt64)) ((13 : UInt8))) ((4096 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_4096 : (writeStore (writeStore (newStore ((7 : UInt8))) ((4096 : UInt64)) ((13 : UInt8))) ((4096 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_4096 : (readStore (newStore ((7 : UInt8))) ((4096 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_read_written_65536 : (readStore (writeStore (newStore ((7 : UInt8))) ((65536 : UInt64)) ((13 : UInt8))) ((65536 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_65536 : (writeStore (writeStore (newStore ((7 : UInt8))) ((65536 : UInt64)) ((13 : UInt8))) ((65536 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_65536 : (readStore (newStore ((7 : UInt8))) ((65536 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_read_written_9223372036854775808 : (readStore (writeStore (newStore ((7 : UInt8))) ((9223372036854775808 : UInt64)) ((13 : UInt8))) ((9223372036854775808 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_9223372036854775808 : (writeStore (writeStore (newStore ((7 : UInt8))) ((9223372036854775808 : UInt64)) ((13 : UInt8))) ((9223372036854775808 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_9223372036854775808 : (readStore (newStore ((7 : UInt8))) ((9223372036854775808 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_read_written_18446744073709551615 : (readStore (writeStore (newStore ((7 : UInt8))) ((18446744073709551615 : UInt64)) ((13 : UInt8))) ((18446744073709551615 : UInt64)) = (13 : UInt8)) := by
  rfl

public theorem store_remove_default_18446744073709551615 : (writeStore (writeStore (newStore ((7 : UInt8))) ((18446744073709551615 : UInt64)) ((13 : UInt8))) ((18446744073709551615 : UInt64)) ((7 : UInt8)) = newStore ((7 : UInt8))) := by
  rfl

public theorem store_preserve_alias_18446744073709551615 : (readStore (newStore ((7 : UInt8))) ((18446744073709551615 : UInt64)) = (7 : UInt8)) := by
  rfl

public theorem store_new_default (defaultByte : UInt8) (key : UInt64) : (readStore (newStore (defaultByte)) (key) = defaultByte) := by
  rfl

public theorem store_unchanged_write (store : Store) (key : UInt64) : (writeStore (store) (key) (readStore (store) (key)) = store) := by
  intros
  subst_vars
  try set_option linter.unusedSimpArgs false in simp only [writeStore, ← Bool.not_eq_true, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', and_true, true_and, Option.some.injEq, Nat.beq_eq, Nat.blt_eq, Nat.ble_eq, LexLeanRuntime.subtract, LexLeanRuntime.multiply, LexLeanRuntime.negate, LexLeanRuntime.equal, beq_iff_eq, decide_eq_true_eq, decide_eq_false_iff_not, Nat.add_assoc, Int.add_assoc, Int.neg_neg, Int.emod_neg, Int.neg_zero, ↓reduceIte, LexLeanLaws.lessThan_nat, LexLeanLaws.lessThan_int, LexLeanLaws.lessThan_int8, LexLeanLaws.lessThan_int16, LexLeanLaws.lessThan_int32, LexLeanLaws.lessThan_int64, LexLeanLaws.lessThan_uint8, LexLeanLaws.lessThan_uint16, LexLeanLaws.lessThan_uint32, LexLeanLaws.lessThan_uint64, LexLeanLaws.quotient_nat, LexLeanLaws.quotient_int, LexLeanLaws.remainder_nat, LexLeanLaws.remainder_int, LexLeanLaws.tdiv_ediv, LexLeanLaws.tmod_emod, LexLeanLaws.length_list, LexLeanLaws.append_list, LexLeanLaws.setFold_listFold, LexLeanLaws.mapFold_listFold, LexLeanLaws.setSize_length, LexLeanLaws.mapSize_length, LexLeanLaws.setElements_self, LexLeanLaws.mapEntries_self, LexLeanLaws.listFold_nil, LexLeanLaws.listFold_append, LexLeanLaws.listFold_prepend, LexLeanLaws.listFold_extend, LexLeanLaws.listFold_add_nat, LexLeanLaws.listFold_add_nat_self, LexLeanLaws.listFold_add_int, LexLeanLaws.listFold_add_int_self, LexLeanLaws.listFold_sub_int, LexLeanLaws.listFold_sub_int_self, LexLeanLaws.sumNat_nil, LexLeanLaws.sumNat_cons, LexLeanLaws.sumInt_nil, LexLeanLaws.sumInt_cons, LexLeanLaws.sumNat_add, LexLeanLaws.sumInt_add, LexLeanLaws.sumInt_sub, LexLeanLaws.sumInt_neg, LexLeanLaws.sumInt_neg_self, LexLeanLaws.sumNat_mul, LexLeanLaws.sumInt_mul, LexLeanLaws.sumNat_mul_self, LexLeanLaws.sumInt_mul_self, LexLeanLaws.sumNat_mul_right, LexLeanLaws.sumInt_mul_right, LexLeanLaws.sumNat_const, LexLeanLaws.sumInt_const, LexLeanLaws.sumNat_append, LexLeanLaws.sumInt_append, LexLeanLaws.sumNat_reverse, LexLeanLaws.sumInt_reverse, UInt8.le_iff_toNat_le, UInt8.lt_iff_toNat_lt, UInt16.le_iff_toNat_le, UInt16.lt_iff_toNat_lt, UInt32.le_iff_toNat_le, UInt32.lt_iff_toNat_lt, UInt64.le_iff_toNat_le, UInt64.lt_iff_toNat_lt, Int8.le_iff_toInt_le, Int8.lt_iff_toInt_lt, Int16.le_iff_toInt_le, Int16.lt_iff_toInt_lt, Int32.le_iff_toInt_le, Int32.lt_iff_toInt_lt, Int64.le_iff_toInt_le, Int64.lt_iff_toInt_lt, UInt8.reduceToNat, ← UInt8.toNat_inj, UInt16.reduceToNat, ← UInt16.toNat_inj, UInt32.reduceToNat, ← UInt32.toNat_inj, UInt64.reduceToNat, ← UInt64.toNat_inj, Int8.reduceToInt, ← Int8.toInt_inj, Int16.reduceToInt, ← Int16.toInt_inj, Int32.reduceToInt, ← Int32.toInt_inj, Int64.reduceToInt, ← Int64.toInt_inj] at *
  try set_option linter.unusedSimpArgs false in simp only [UInt8.toNat, UInt16.toNat, UInt32.toNat, UInt64.toNat, Int8.toInt, Int16.toInt, Int32.toInt, Int64.toInt, BitVec.toInt_eq_toNat_cond] at *
  all_goals (repeat' split)
  all_goals omega

public theorem store_noninterference_vector : (readStore (writeStore (writeStore (newStore ((0 : UInt8))) ((1 : UInt64)) ((17 : UInt8))) ((2 : UInt64)) ((23 : UInt8))) ((1 : UInt64)) = (17 : UInt8)) := by
  rfl

end Uorc.Uorc.Core.Store
