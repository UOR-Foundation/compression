module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeValue
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Wire.OwnedRead

public inductive Failure where
  | heap (_ : Uorc.Uorc.Core.Heap.HeapError)
  | range
  | addressSpaceExhausted
  | invalidShape

public structure Cursor where
  root : Uorc.Uorc.Core.RuntimeValue.Handle
  length : UInt64
  offset : UInt64
  current : Uorc.Uorc.Core.RuntimeValue.Handle
  index : UInt64
  walking : Bool

public inductive Step where
  | advanced (_ : Cursor)
  | borrowedSpan (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : UInt64) (_ : UInt64) (_ : Cursor)
  | complete
  | failed (_ : Failure)

@[expose] public def begin (arena : Uorc.Uorc.Core.Heap.Arena) (root : Uorc.Uorc.Core.RuntimeValue.Handle) : Except (Failure) (Cursor) := (match Uorc.Uorc.Core.Heap.sequenceInfo (arena) (root) with | Except.error eLocal1 => Except.error (Failure.heap (eLocal1)) | Except.ok infoLocal2 => Except.ok (({ root := root, length := (infoLocal2).length, offset := (0 : UInt64), current := root, index := (0 : UInt64), walking := false } : Cursor)))

@[expose] public def step (arena : Uorc.Uorc.Core.Heap.Arena) (cursor : Cursor) : Step := (if (LexLeanRuntime.equal ((cursor).offset) ((cursor).length) : Bool) then Step.complete else (if Uorc.Uorc.Core.Heap.less ((cursor).length) ((cursor).offset) then Step.failed (Failure.range) else (if (cursor).walking then (match Uorc.Uorc.Core.Heap.lookup (arena) ((cursor).current) with | Except.error eLocal3 => Step.failed (Failure.heap (eLocal3)) | Except.ok entryLocal4 => (match (entryLocal4).node with | Uorc.Uorc.Core.Heap.Node.sequenceLeaf imageLocal5 startLocal6 lengthLocal7 => (if Uorc.Uorc.Core.Heap.less ((cursor).index) (lengthLocal7) then (let countLocal8 : UInt64 := (if Uorc.Uorc.Core.Heap.less (Uorc.Uorc.Core.Heap.wordSub (lengthLocal7) ((cursor).index)) (Uorc.Uorc.Core.Heap.wordSub ((cursor).length) ((cursor).offset)) then Uorc.Uorc.Core.Heap.wordSub (lengthLocal7) ((cursor).index) else Uorc.Uorc.Core.Heap.wordSub ((cursor).length) ((cursor).offset)); (match (LexLeanRuntime.checkedAdd (startLocal6) ((cursor).index) : Option (UInt64)) with | Option.none => Step.failed (Failure.addressSpaceExhausted) | Option.some offsetLocal9 => (match (LexLeanRuntime.checkedAdd (offsetLocal9) (countLocal8) : Option (UInt64)) with | Option.none => Step.failed (Failure.addressSpaceExhausted) | Option.some endLocal10 => (match Uorc.Uorc.Core.Heap.lookup (arena) (imageLocal5) with | Except.error eLocal11 => Step.failed (Failure.heap (eLocal11)) | Except.ok entryLocal12 => (match (entryLocal12).node with | Uorc.Uorc.Core.Heap.Node.image _ bytesLocal14 => (match Uorc.Uorc.Core.Heap.wordOfNat ((LexLeanRuntime.length (bytesLocal14) : Nat)) with | Option.none => Step.failed (Failure.addressSpaceExhausted) | Option.some sizeLocal15 => (if Uorc.Uorc.Core.Heap.less (sizeLocal15) (endLocal10) then Step.failed (Failure.range) else Step.borrowedSpan (imageLocal5) (offsetLocal9) (countLocal8) (({ root := (cursor).root, length := (cursor).length, offset := Uorc.Uorc.Core.Heap.wordAdd ((cursor).offset) (countLocal8), current := (cursor).current, index := (cursor).index, walking := false } : Cursor)))) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataBranch _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Step.failed (Failure.invalidShape)))))) else Step.failed (Failure.range)) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ leftLocal46 rightLocal47 => (match Uorc.Uorc.Core.Heap.sequenceInfo (arena) (leftLocal46) with | Except.error eLocal48 => Step.failed (Failure.heap (eLocal48)) | Except.ok leftInfoLocal49 => (let nextLocal50 : Uorc.Uorc.Core.RuntimeValue.Handle := (if Uorc.Uorc.Core.Heap.less ((cursor).index) ((leftInfoLocal49).length) then leftLocal46 else rightLocal47); (if Uorc.Uorc.Core.Heap.less ((nextLocal50).id) (((cursor).current).id) then Step.advanced (({ root := (cursor).root, length := (cursor).length, offset := (cursor).offset, current := nextLocal50, index := (if Uorc.Uorc.Core.Heap.less ((cursor).index) ((leftInfoLocal49).length) then (cursor).index else Uorc.Uorc.Core.Heap.wordSub ((cursor).index) ((leftInfoLocal49).length)), walking := (cursor).walking } : Cursor)) else Step.failed (Failure.invalidShape)))) | Uorc.Uorc.Core.Heap.Node.image _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.metadataBranch _ _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Step.failed (Failure.invalidShape) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Step.failed (Failure.invalidShape))) else Step.advanced (({ root := (cursor).root, length := (cursor).length, offset := (cursor).offset, current := (cursor).root, index := (cursor).offset, walking := true } : Cursor)))))

@[expose] public def boundary : String := "Read-only wire traversal under an already charged enclosing owner. Cursor holds only handles and fixed-width scalars, never Arena, Bytes, Rope or a traversal stack. Each call performs one bounded node descent or reports one borrowed image span. It allocates and retains no ticket. This Step.borrowedSpan is distinct from RuntimeSequence.Outcome.span, whose nonempty result transfers an owned image ticket. A caller of the Core-owned sequence operation must separately inventory that returned ticket; no terminal-cursor normalization is performed here. The wire producer keeps its enclosing owner while a borrowed event is pending and explicitly retains a ticket only on a requested transfer."

end Uorc.Uorc.Wire.OwnedRead
