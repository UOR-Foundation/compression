module
public import Init
public import LexLeanRuntime.Portable
public import LexLeanRuntime.Laws
public import Uorc.Uorc.Core.Resources
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.Bytes

public inductive Rope where
  | empty
  | leaf (_ : ByteArray)
  | branch (_ : Nat) (_ : Nat) (_ : Rope) (_ : Rope)
  | view (_ : ByteArray) (_ : Nat) (_ : Nat)

public inductive RopeError where
  | zeroChunkSize
  | invalidCursor
  | indexOutOfBounds
  | sliceOutOfBounds
  | comparisonFuelExhausted

public structure Cursor where
  pending : List (Rope)
  current : Option (ByteArray)
  offset : Nat
  «end» : Nat

public inductive CursorEvent where
  | advanced (_ : Cursor)
  | produced (_ : ByteArray) (_ : Cursor)
  | done

@[expose] public def length (rope : Rope) : Nat := (match rope with | Rope.empty => 0 | Rope.leaf chunk => (LexLeanRuntime.length (chunk) : Nat) | Rope.branch cachedLength _ _ _ => cachedLength | Rope.view _ _ viewLength => viewLength)

@[expose] public def height (rope : Rope) : Nat := (match rope with | Rope.empty => 0 | Rope.leaf _ => 1 | Rope.branch _ cachedHeight _ _ => cachedHeight | Rope.view _ _ _ => 1)

@[expose] public def fromBytes (chunk : ByteArray) : Rope := (if (Nat.beq ((LexLeanRuntime.length (chunk) : Nat)) (0)) then Rope.empty else Rope.leaf (chunk))

@[expose] public def node (leftNode : Rope) (rightNode : Rope) : Rope := (if (Nat.beq (length (leftNode)) (0)) then rightNode else (if (Nat.beq (length (rightNode)) (0)) then leftNode else Rope.branch ((length (leftNode) + length (rightNode))) ((1 + (if (Nat.ble (height (leftNode)) (height (rightNode))) then height (rightNode) else height (leftNode)))) (leftNode) (rightNode)))

@[expose] public def left (rope : Rope) : Rope := (match rope with | Rope.empty => Rope.empty | Rope.leaf _ => Rope.empty | Rope.branch _ _ leftTree _ => leftTree | Rope.view _ _ _ => Rope.empty)

@[expose] public def right (rope : Rope) : Rope := (match rope with | Rope.empty => Rope.empty | Rope.leaf _ => Rope.empty | Rope.branch _ _ _ rightTree => rightTree | Rope.view _ _ _ => Rope.empty)

@[expose] public def balance (leftTree : Rope) (rightTree : Rope) : Rope := (if (Nat.blt ((height (rightTree) + 1)) (height (leftTree))) then (if (Nat.ble (height (right (leftTree))) (height (left (leftTree)))) then node (left (leftTree)) (node (right (leftTree)) (rightTree)) else node (node (left (leftTree)) (left (right (leftTree)))) (node (right (right (leftTree))) (rightTree))) else (if (Nat.blt ((height (leftTree) + 1)) (height (rightTree))) then (if (Nat.ble (height (left (rightTree))) (height (right (rightTree)))) then node (node (leftTree) (left (rightTree))) (right (rightTree)) else node (node (leftTree) (left (left (rightTree)))) (node (right (left (rightTree))) (right (rightTree)))) else node (leftTree) (rightTree)))

@[expose] public def joinFuel : (fuel : Nat) -> (leftTree : Rope) -> (rightTree : Rope) -> Rope
  | Nat.zero, leftTree, rightTree => node (leftTree) (rightTree)
  | Nat.succ remaining, leftTree, rightTree => (if (Nat.blt ((height (rightTree) + 1)) (height (leftTree))) then balance (left (leftTree)) (joinFuel (remaining) (right (leftTree)) (rightTree)) else (if (Nat.blt ((height (leftTree) + 1)) (height (rightTree))) then balance (joinFuel (remaining) (leftTree) (left (rightTree))) (right (rightTree)) else node (leftTree) (rightTree)))

@[expose] public def join (leftTree : Rope) (rightTree : Rope) : Rope := (if (Nat.beq (length (leftTree)) (0)) then rightTree else (if (Nat.beq (length (rightTree)) (0)) then leftTree else joinFuel (((height (leftTree) + height (rightTree)) + 1)) (leftTree) (rightTree)))

public inductive NodeStatus where
  | valid
  | invalid
  | addressSpaceExhausted

@[expose] public def validNode (rope : Rope) : Bool := (match rope with | Rope.empty => true | Rope.leaf chunk => (Nat.blt (0) ((LexLeanRuntime.length (chunk) : Nat))) | Rope.branch cachedLength cachedHeight leftNode rightNode => (((Nat.blt (0) (length (leftNode))) && (Nat.blt (0) (length (rightNode)))) && (((Nat.beq (cachedLength) ((length (leftNode) + length (rightNode)))) && (Nat.beq (cachedHeight) ((1 + (if (Nat.ble (height (leftNode)) (height (rightNode))) then height (rightNode) else height (leftNode)))))) && ((Nat.ble ((LexLeanRuntime.subtract (height (leftNode)) (height (rightNode)) : Nat)) (1)) && (Nat.ble ((LexLeanRuntime.subtract (height (rightNode)) (height (leftNode)) : Nat)) (1))))) | Rope.view backing viewOffset viewLength => ((Nat.blt (0) (viewLength)) && ((Nat.ble (viewOffset) ((LexLeanRuntime.length (backing) : Nat))) && (Nat.ble (viewLength) ((LexLeanRuntime.subtract ((LexLeanRuntime.length (backing) : Nat)) (viewOffset) : Nat))))))

@[expose] public def checkNode (rope : Rope) : NodeStatus := (match rope with | Rope.empty => (if validNode (rope) then NodeStatus.valid else NodeStatus.invalid) | Rope.leaf _ => (if validNode (rope) then NodeStatus.valid else NodeStatus.invalid) | Rope.branch _ _ leftNode rightNode => (if Uorc.Uorc.Core.Resources.fitsAddition (18446744073709551615) (length (leftNode)) (length (rightNode)) then (if Uorc.Uorc.Core.Resources.fitsAddition (18446744073709551615) ((if (Nat.ble (height (leftNode)) (height (rightNode))) then height (rightNode) else height (leftNode))) (1) then (if validNode (rope) then NodeStatus.valid else NodeStatus.invalid) else NodeStatus.addressSpaceExhausted) else NodeStatus.addressSpaceExhausted) | Rope.view _ _ _ => (if validNode (rope) then NodeStatus.valid else NodeStatus.invalid))

@[expose] public def valid : (rope : Rope) -> Bool
  | Rope.empty => true
  | Rope.leaf chunk => validNode (Rope.leaf (chunk))
  | Rope.branch cachedLength cachedHeight leftNode rightNode => (validNode (Rope.branch (cachedLength) (cachedHeight) (leftNode) (rightNode)) && (valid (leftNode) && valid (rightNode)))
  | Rope.view backing viewOffset viewLength => validNode (Rope.view (backing) (viewOffset) (viewLength))

@[expose] public def cursor (rope : Rope) : Cursor := ({ pending := (rope :: ([] : List (Rope))), current := Option.none, offset := 0, «end» := 0 } : Cursor)

@[expose] public def advancePending (pending : List (Rope)) : CursorEvent := (match pending with | List.nil => CursorEvent.done | List.cons headRope restRopes => (match headRope with | Rope.empty => CursorEvent.advanced (({ pending := restRopes, current := Option.none, offset := 0, «end» := 0 } : Cursor)) | Rope.leaf chunk => CursorEvent.advanced (({ pending := restRopes, current := Option.some (chunk), offset := 0, «end» := (LexLeanRuntime.length (chunk) : Nat) } : Cursor)) | Rope.branch _ _ leftTree rightTree => CursorEvent.advanced (({ pending := (leftTree :: (rightTree :: restRopes)), current := Option.none, offset := 0, «end» := 0 } : Cursor)) | Rope.view backing viewOffset viewLength => CursorEvent.advanced (({ pending := restRopes, current := Option.some (backing), offset := viewOffset, «end» := (viewOffset + viewLength) } : Cursor))))

@[expose] public def emitCurrent (cursorValue : Cursor) (chunk : ByteArray) (count : Nat) : Except (RopeError) (CursorEvent) := (match (LexLeanRuntime.slice (chunk) ((cursorValue).offset) (count) : Option (ByteArray)) with | Option.none => Except.error (RopeError.invalidCursor) | Option.some produced => Except.ok (CursorEvent.produced (produced) (({ pending := (cursorValue).pending, current := Option.some (chunk), offset := ((cursorValue).offset + count), «end» := (cursorValue).«end» } : Cursor))))

@[expose] public def nextChunk (cursorValue : Cursor) (maxChunk : Nat) : Except (RopeError) (CursorEvent) := (if (Nat.beq (maxChunk) (0)) then Except.error (RopeError.zeroChunkSize) else (match (cursorValue).current with | Option.none => Except.ok (advancePending ((cursorValue).pending)) | Option.some chunk => (if ((Nat.blt ((LexLeanRuntime.length (chunk) : Nat)) ((cursorValue).«end»)) || (Nat.blt ((cursorValue).«end») ((cursorValue).offset))) then Except.error (RopeError.invalidCursor) else (if (Nat.beq ((cursorValue).«end») ((cursorValue).offset)) then Except.ok (CursorEvent.advanced (({ pending := (cursorValue).pending, current := Option.none, offset := 0, «end» := 0 } : Cursor))) else emitCurrent (cursorValue) (chunk) ((if (Nat.ble (maxChunk) ((LexLeanRuntime.subtract ((cursorValue).«end») ((cursorValue).offset) : Nat))) then maxChunk else (LexLeanRuntime.subtract ((cursorValue).«end») ((cursorValue).offset) : Nat)))))))

@[expose] public def atUnchecked : (rope : Rope) -> (index : Nat) -> Option (UInt8)
  | Rope.empty, _index => Option.none
  | Rope.leaf chunk, index => (LexLeanRuntime.index (chunk) (index) : Option (UInt8))
  | Rope.branch _ _ leftTree rightTree, index => (if (Nat.blt (index) (length (leftTree))) then atUnchecked (leftTree) (index) else atUnchecked (rightTree) ((LexLeanRuntime.subtract (index) (length (leftTree)) : Nat)))
  | Rope.view backing viewOffset _, index => (LexLeanRuntime.index (backing) ((viewOffset + index)) : Option (UInt8))

@[expose] public def «at» (rope : Rope) (index : Nat) : Except (RopeError) (UInt8) := (if (Nat.blt (index) (length (rope))) then (match atUnchecked (rope) (index) with | Option.none => Except.error (RopeError.invalidCursor) | Option.some selected => Except.ok (selected)) else Except.error (RopeError.indexOutOfBounds))

@[expose] public def viewRange (backing : ByteArray) (start : Nat) (count : Nat) : Except (RopeError) (Rope) := (if ((Nat.ble (start) ((LexLeanRuntime.length (backing) : Nat))) && (Nat.ble (count) ((LexLeanRuntime.subtract ((LexLeanRuntime.length (backing) : Nat)) (start) : Nat)))) then Except.ok ((if (Nat.beq (count) (0)) then Rope.empty else Rope.view (backing) (start) (count))) else Except.error (RopeError.sliceOutOfBounds))

@[expose] public def sliceUnchecked : (rope : Rope) -> (start : Nat) -> (count : Nat) -> Rope
  | Rope.empty, start, count => (if (Nat.beq (count) (0)) then Rope.empty else (if ((Nat.beq (start) (0)) && (Nat.beq (count) (length (Rope.empty)))) then Rope.empty else Rope.empty))
  | Rope.leaf chunk, start, count => (if (Nat.beq (count) (0)) then Rope.empty else (if ((Nat.beq (start) (0)) && (Nat.beq (count) (length (Rope.leaf (chunk))))) then Rope.leaf (chunk) else (if (Nat.beq (count) (0)) then Rope.empty else Rope.view (chunk) (start) (count))))
  | Rope.branch cachedLength cachedHeight leftTree rightTree, start, count => (if (Nat.beq (count) (0)) then Rope.empty else (if ((Nat.beq (start) (0)) && (Nat.beq (count) (length (Rope.branch (cachedLength) (cachedHeight) (leftTree) (rightTree))))) then Rope.branch (cachedLength) (cachedHeight) (leftTree) (rightTree) else (if (Nat.blt (start) (length (leftTree))) then join (sliceUnchecked (leftTree) (start) ((if (Nat.ble (count) ((LexLeanRuntime.subtract (length (leftTree)) (start) : Nat))) then count else (LexLeanRuntime.subtract (length (leftTree)) (start) : Nat)))) (sliceUnchecked (rightTree) (0) ((LexLeanRuntime.subtract (count) ((LexLeanRuntime.subtract (length (leftTree)) (start) : Nat)) : Nat))) else sliceUnchecked (rightTree) ((LexLeanRuntime.subtract (start) (length (leftTree)) : Nat)) (count))))
  | Rope.view backing viewOffset viewLength, start, count => (if (Nat.beq (count) (0)) then Rope.empty else (if ((Nat.beq (start) (0)) && (Nat.beq (count) (length (Rope.view (backing) (viewOffset) (viewLength))))) then Rope.view (backing) (viewOffset) (viewLength) else (if (Nat.beq (count) (0)) then Rope.empty else Rope.view (backing) ((viewOffset + start)) (count))))

@[expose] public def slice (rope : Rope) (start : Nat) (count : Nat) : Except (RopeError) (Rope) := (if ((Nat.ble (start) (length (rope))) && (Nat.ble (count) ((LexLeanRuntime.subtract (length (rope)) (start) : Nat)))) then Except.ok (sliceUnchecked (rope) (start) (count)) else Except.error (RopeError.sliceOutOfBounds))

public theorem rope_join_length : (length (join (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))])) (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 16)), (_root_.UInt8.ofNat (nat_lit 32))]))) = 4) := by
  rfl

public theorem rope_join_valid : (valid (join (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))])) (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 16)), (_root_.UInt8.ofNat (nat_lit 32))]))) = true) := by
  rfl

public theorem rope_index_cross_chunk : («at» (join (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))])) (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 16)), (_root_.UInt8.ofNat (nat_lit 32))]))) (2) = Except.ok ((16 : UInt8))) := by
  rfl

public theorem rope_index_end : («at» (join (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))])) (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 16)), (_root_.UInt8.ofNat (nat_lit 32))]))) (4) = Except.error (RopeError.indexOutOfBounds)) := by
  rfl

public theorem rope_slice_cross_chunk_length : (length (sliceUnchecked (join (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))])) (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 16)), (_root_.UInt8.ofNat (nat_lit 32))]))) (1) (2)) = 2) := by
  rfl

public theorem rope_zero_chunk_rejected : (nextChunk (cursor (join (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))])) (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 16)), (_root_.UInt8.ofNat (nat_lit 32))])))) (0) = Except.error (RopeError.zeroChunkSize)) := by
  rfl

public theorem empty_join_left (rope : Rope) : (join (Rope.empty) (rope) = rope) := by
  rfl

public theorem empty_cursor_done : (advancePending (([] : List (Rope))) = CursorEvent.done) := by
  rfl

public structure Comparison where
  leftCursor : Cursor
  rightCursor : Cursor
  leftByte : Option (UInt8)
  rightByte : Option (UInt8)
  leftDone : Bool
  rightDone : Bool

public inductive ComparisonStep where
  | advanced (_ : Comparison)
  | equal
  | different
  | failed (_ : RopeError)

@[expose] public def startComparison (leftRope : Rope) (rightRope : Rope) : Comparison := ({ leftCursor := cursor (leftRope), rightCursor := cursor (rightRope), leftByte := Option.none, rightByte := Option.none, leftDone := false, rightDone := false } : Comparison)

@[expose] public def readLeftComparison (comparison : Comparison) : ComparisonStep := (match nextChunk ((comparison).leftCursor) (1) with | Except.error error => ComparisonStep.failed (error) | Except.ok event => (match event with | CursorEvent.advanced nextCursor => ComparisonStep.advanced (({ leftCursor := nextCursor, rightCursor := (comparison).rightCursor, leftByte := (comparison).leftByte, rightByte := (comparison).rightByte, leftDone := (comparison).leftDone, rightDone := (comparison).rightDone } : Comparison)) | CursorEvent.produced chunk nextCursor => (match (LexLeanRuntime.index (chunk) (0) : Option (UInt8)) with | Option.none => ComparisonStep.failed (RopeError.invalidCursor) | Option.some selected => ComparisonStep.advanced (({ leftCursor := nextCursor, rightCursor := (comparison).rightCursor, leftByte := Option.some (selected), rightByte := (comparison).rightByte, leftDone := (comparison).leftDone, rightDone := (comparison).rightDone } : Comparison))) | CursorEvent.done => ComparisonStep.advanced (({ leftCursor := (comparison).leftCursor, rightCursor := (comparison).rightCursor, leftByte := (comparison).leftByte, rightByte := (comparison).rightByte, leftDone := true, rightDone := (comparison).rightDone } : Comparison))))

@[expose] public def readRightComparison (comparison : Comparison) : ComparisonStep := (match nextChunk ((comparison).rightCursor) (1) with | Except.error error => ComparisonStep.failed (error) | Except.ok event => (match event with | CursorEvent.advanced nextCursor => ComparisonStep.advanced (({ leftCursor := (comparison).leftCursor, rightCursor := nextCursor, leftByte := (comparison).leftByte, rightByte := (comparison).rightByte, leftDone := (comparison).leftDone, rightDone := (comparison).rightDone } : Comparison)) | CursorEvent.produced chunk nextCursor => (match (LexLeanRuntime.index (chunk) (0) : Option (UInt8)) with | Option.none => ComparisonStep.failed (RopeError.invalidCursor) | Option.some selected => ComparisonStep.advanced (({ leftCursor := (comparison).leftCursor, rightCursor := nextCursor, leftByte := (comparison).leftByte, rightByte := Option.some (selected), leftDone := (comparison).leftDone, rightDone := (comparison).rightDone } : Comparison))) | CursorEvent.done => ComparisonStep.advanced (({ leftCursor := (comparison).leftCursor, rightCursor := (comparison).rightCursor, leftByte := (comparison).leftByte, rightByte := (comparison).rightByte, leftDone := (comparison).leftDone, rightDone := true } : Comparison))))

@[expose] public def compareStep (comparison : Comparison) : ComparisonStep := (match (comparison).leftByte with | Option.none => (if (comparison).leftDone then (match (comparison).rightByte with | Option.none => (if (comparison).rightDone then ComparisonStep.equal else readRightComparison (comparison)) | Option.some _ => ComparisonStep.different) else readLeftComparison (comparison)) | Option.some leftByteValue => (match (comparison).rightByte with | Option.none => (if (comparison).rightDone then ComparisonStep.different else readRightComparison (comparison)) | Option.some rightByteValue => (if (LexLeanRuntime.equal (leftByteValue) (rightByteValue) : Bool) then ComparisonStep.advanced (({ leftCursor := (comparison).leftCursor, rightCursor := (comparison).rightCursor, leftByte := Option.none, rightByte := Option.none, leftDone := (comparison).leftDone, rightDone := (comparison).rightDone } : Comparison)) else ComparisonStep.different)))

@[expose] public def nodeCount : (rope : Rope) -> Nat
  | Rope.empty => 1
  | Rope.leaf _ => 1
  | Rope.branch _ _ leftTree rightTree => (1 + (nodeCount (leftTree) + nodeCount (rightTree)))
  | Rope.view _ _ _ => 1

@[expose] public def compareRun : (fuel : Nat) -> (comparison : Comparison) -> Except (RopeError) (Bool)
  | Nat.zero, _comparison => Except.error (RopeError.comparisonFuelExhausted)
  | Nat.succ remaining, comparison => (match compareStep (comparison) with | ComparisonStep.advanced nextComparison => compareRun (remaining) (nextComparison) | ComparisonStep.equal => Except.ok (true) | ComparisonStep.different => Except.ok (false) | ComparisonStep.failed error => Except.error (error))

@[expose] public def equal (leftRope : Rope) (rightRope : Rope) : Except (RopeError) (Bool) := compareRun ((10 + ((LexLeanRuntime.multiply (4) ((length (leftRope) + length (rightRope))) : Nat) + (LexLeanRuntime.multiply (3) ((nodeCount (leftRope) + nodeCount (rightRope))) : Nat)))) (startComparison (leftRope) (rightRope))

@[expose] public def partitionEqualityFixture (firstPair : ByteArray) : Except (RopeError) (Bool) := equal (join (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))])) (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 255)), (_root_.UInt8.ofNat (nat_lit 16))]))) (join (fromBytes (firstPair)) (fromBytes (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 16))])))

@[expose] public def partition_independent_equality_vector : Bool := (match partitionEqualityFixture (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 255))]) with | Except.error _ => false | Except.ok equalResult => equalResult)

@[expose] public def planted_byte_mutation_is_detected : Bool := (match partitionEqualityFixture (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 254))]) with | Except.error _ => false | Except.ok equalResult => (!equalResult))

public theorem view_reports_logical_length : (length (Rope.view (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 51)), (_root_.UInt8.ofNat (nat_lit 68))]) (1) (3)) = 3) := by
  rfl

public theorem view_indexes_offset_without_copy : («at» (Rope.view (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 51)), (_root_.UInt8.ofNat (nat_lit 68))]) (1) (3)) (0) = Except.ok ((17 : UInt8))) := by
  rfl

public theorem view_rejects_index_past_range : («at» (Rope.view (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 51)), (_root_.UInt8.ofNat (nat_lit 68))]) (1) (3)) (3) = Except.error (RopeError.indexOutOfBounds)) := by
  rfl

public theorem view_rejects_backing_overrun : (viewRange (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 17))]) (1) (2) = Except.error (RopeError.sliceOutOfBounds)) := by
  rfl

public theorem view_overflow_guard_precedes_addition : (viewRange (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 17))]) (18446744073709551615) (2) = Except.error (RopeError.sliceOutOfBounds)) := by
  rfl

public inductive WorkTask where
  | joining (_ : Rope) (_ : Rope)
  | slicing (_ : Rope) (_ : Nat) (_ : Nat)
  | indexing (_ : Rope) (_ : Nat)
  | returning (_ : Rope)

public inductive WorkContinuation where
  | balanceRight (_ : Rope)
  | balanceLeft (_ : Rope)
  | sliceSecond (_ : Rope) (_ : Nat)
  | joinFirst (_ : Rope)

public structure Work where
  task : WorkTask
  continuations : List (WorkContinuation)

public inductive WorkEvent where
  | advanced (_ : Work)
  | sequenceDone (_ : Rope)
  | byteDone (_ : UInt8)
  | failed (_ : RopeError)

@[expose] public def startJoin (leftRope : Rope) (rightRope : Rope) : Work := ({ task := WorkTask.joining (leftRope) (rightRope), continuations := ([] : List (WorkContinuation)) } : Work)

@[expose] public def startSlice (rope : Rope) (start : Nat) (count : Nat) : Except (RopeError) (Work) := (if ((Nat.ble (start) (length (rope))) && (Nat.ble (count) ((LexLeanRuntime.subtract (length (rope)) (start) : Nat)))) then Except.ok (({ task := WorkTask.slicing (rope) (start) (count), continuations := ([] : List (WorkContinuation)) } : Work)) else Except.error (RopeError.sliceOutOfBounds))

@[expose] public def startIndex (rope : Rope) (index : Nat) : Except (RopeError) (Work) := (if (Nat.blt (index) (length (rope))) then Except.ok (({ task := WorkTask.indexing (rope) (index), continuations := ([] : List (WorkContinuation)) } : Work)) else Except.error (RopeError.indexOutOfBounds))

@[expose] public def workStep (workValue : Work) : WorkEvent := (match (workValue).task with | WorkTask.joining leftRope rightRope => (if (Nat.beq (length (leftRope)) (0)) then WorkEvent.advanced (({ task := WorkTask.returning (rightRope), continuations := (workValue).continuations } : Work)) else (if (Nat.beq (length (rightRope)) (0)) then WorkEvent.advanced (({ task := WorkTask.returning (leftRope), continuations := (workValue).continuations } : Work)) else (if (Nat.blt ((height (rightRope) + 1)) (height (leftRope))) then WorkEvent.advanced (({ task := WorkTask.joining (right (leftRope)) (rightRope), continuations := (WorkContinuation.balanceRight (left (leftRope)) :: (workValue).continuations) } : Work)) else (if (Nat.blt ((height (leftRope) + 1)) (height (rightRope))) then WorkEvent.advanced (({ task := WorkTask.joining (leftRope) (left (rightRope)), continuations := (WorkContinuation.balanceLeft (right (rightRope)) :: (workValue).continuations) } : Work)) else WorkEvent.advanced (({ task := WorkTask.returning (node (leftRope) (rightRope)), continuations := (workValue).continuations } : Work)))))) | WorkTask.slicing sourceRope start count => (if (Nat.beq (count) (0)) then WorkEvent.advanced (({ task := WorkTask.returning (Rope.empty), continuations := (workValue).continuations } : Work)) else (if ((Nat.beq (start) (0)) && (Nat.beq (count) (length (sourceRope)))) then WorkEvent.advanced (({ task := WorkTask.returning (sourceRope), continuations := (workValue).continuations } : Work)) else (match sourceRope with | Rope.empty => WorkEvent.failed (RopeError.invalidCursor) | Rope.leaf chunk => WorkEvent.advanced (({ task := WorkTask.returning (Rope.view (chunk) (start) (count)), continuations := (workValue).continuations } : Work)) | Rope.branch _ _ leftNode rightNode => (if (Nat.blt (start) (length (leftNode))) then (if (Nat.ble (count) ((LexLeanRuntime.subtract (length (leftNode)) (start) : Nat))) then WorkEvent.advanced (({ task := WorkTask.slicing (leftNode) (start) (count), continuations := (workValue).continuations } : Work)) else WorkEvent.advanced (({ task := WorkTask.slicing (leftNode) (start) ((LexLeanRuntime.subtract (length (leftNode)) (start) : Nat)), continuations := (WorkContinuation.sliceSecond (rightNode) ((LexLeanRuntime.subtract (count) ((LexLeanRuntime.subtract (length (leftNode)) (start) : Nat)) : Nat)) :: (workValue).continuations) } : Work))) else WorkEvent.advanced (({ task := WorkTask.slicing (rightNode) ((LexLeanRuntime.subtract (start) (length (leftNode)) : Nat)) (count), continuations := (workValue).continuations } : Work))) | Rope.view backing viewOffset _ => WorkEvent.advanced (({ task := WorkTask.returning (Rope.view (backing) ((viewOffset + start)) (count)), continuations := (workValue).continuations } : Work))))) | WorkTask.indexing sourceRope index => (match sourceRope with | Rope.empty => WorkEvent.failed (RopeError.invalidCursor) | Rope.leaf chunk => (match (LexLeanRuntime.index (chunk) (index) : Option (UInt8)) with | Option.none => WorkEvent.failed (RopeError.invalidCursor) | Option.some selectedByte => WorkEvent.byteDone (selectedByte)) | Rope.branch _ _ leftNode rightNode => (if (Nat.blt (index) (length (leftNode))) then WorkEvent.advanced (({ task := WorkTask.indexing (leftNode) (index), continuations := (workValue).continuations } : Work)) else WorkEvent.advanced (({ task := WorkTask.indexing (rightNode) ((LexLeanRuntime.subtract (index) (length (leftNode)) : Nat)), continuations := (workValue).continuations } : Work))) | Rope.view backing viewOffset _ => (match (LexLeanRuntime.index (backing) ((viewOffset + index)) : Option (UInt8)) with | Option.none => WorkEvent.failed (RopeError.invalidCursor) | Option.some selectedByte => WorkEvent.byteDone (selectedByte))) | WorkTask.returning returnedRope => (match (workValue).continuations with | List.nil => WorkEvent.sequenceDone (returnedRope) | List.cons continuation restContinuations => (match continuation with | WorkContinuation.balanceRight leftRope => WorkEvent.advanced (({ task := WorkTask.returning (balance (leftRope) (returnedRope)), continuations := restContinuations } : Work)) | WorkContinuation.balanceLeft rightRope => WorkEvent.advanced (({ task := WorkTask.returning (balance (returnedRope) (rightRope)), continuations := restContinuations } : Work)) | WorkContinuation.sliceSecond rightRope rightCount => WorkEvent.advanced (({ task := WorkTask.slicing (rightRope) (0) (rightCount), continuations := (WorkContinuation.joinFirst (returnedRope) :: restContinuations) } : Work)) | WorkContinuation.joinFirst leftRope => WorkEvent.advanced (({ task := WorkTask.joining (leftRope) (returnedRope), continuations := restContinuations } : Work)))))

@[expose] public def runWorkEvents : (fuel : Nat) -> (workValue : Work) -> WorkEvent
  | Nat.zero, workValue => WorkEvent.advanced (workValue)
  | Nat.succ remaining, workValue => (match workStep (workValue) with | WorkEvent.advanced nextWork => runWorkEvents (remaining) (nextWork) | WorkEvent.sequenceDone resultRope => WorkEvent.sequenceDone (resultRope) | WorkEvent.byteDone resultByte => WorkEvent.byteDone (resultByte) | WorkEvent.failed error => WorkEvent.failed (error))

public theorem zero_rope_work_preserves_cursor (workValue : Work) : (runWorkEvents (0) (workValue) = WorkEvent.advanced (workValue)) := by
  rfl

public theorem view_index_is_single_bounded_work_event : (workStep (({ task := WorkTask.indexing (Rope.view (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 51))]) (1) (2)) (1), continuations := ([] : List (WorkContinuation)) } : Work)) = WorkEvent.byteDone ((34 : UInt8))) := by
  rfl

public theorem slice_returns_backing_view_without_copy : (runWorkEvents (2) (({ task := WorkTask.slicing (Rope.leaf (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 51))])) (1) (2), continuations := ([] : List (WorkContinuation)) } : Work)) = WorkEvent.sequenceDone (Rope.view (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0)), (_root_.UInt8.ofNat (nat_lit 17)), (_root_.UInt8.ofNat (nat_lit 34)), (_root_.UInt8.ofNat (nat_lit 51))]) (1) (2))) := by
  rfl

public theorem malformed_rope_length_overflow_is_invalid : (validNode (Rope.branch (0) (2) (Rope.branch (18446744073709551615) (1) (Rope.empty) (Rope.empty)) (Rope.leaf (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))]))) = false) := by
  rfl

public theorem native_rope_count_exhaustion_is_not_static_invalidity : (checkNode (Rope.branch (0) (2) (Rope.branch (18446744073709551615) (1) (Rope.empty) (Rope.empty)) (Rope.leaf (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))]))) = NodeStatus.addressSpaceExhausted) := by
  rfl

public theorem native_small_bad_cache_is_invalid : (checkNode (Rope.branch (999) (2) (Rope.leaf (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 0))])) (Rope.leaf (_root_.ByteArray.mk #[(_root_.UInt8.ofNat (nat_lit 17))]))) = NodeStatus.invalid) := by
  rfl

@[expose] public def select_work_event (selectedGuard : Bool) (selectedEvent : WorkEvent) (otherEvent : WorkEvent) : WorkEvent := (if selectedGuard then selectedEvent else otherEvent)

public theorem true_guard_selects_work_event (selectedGuard : Bool) (selectedEvent : WorkEvent) (otherEvent : WorkEvent) : (((selectedGuard = true) -> (select_work_event (selectedGuard) (selectedEvent) (otherEvent) = selectedEvent)) <-> (0 = 0)) := by
  constructor
  ·
    intros
    subst_vars
    try set_option linter.unusedSimpArgs false in simp only [select_work_event, ← Bool.not_eq_true, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', and_true, true_and, Option.some.injEq, Nat.beq_eq, Nat.blt_eq, Nat.ble_eq, LexLeanRuntime.subtract, LexLeanRuntime.multiply, LexLeanRuntime.negate, LexLeanRuntime.equal, beq_iff_eq, decide_eq_true_eq, decide_eq_false_iff_not, Nat.add_assoc, Int.add_assoc, Int.neg_neg, Int.emod_neg, Int.neg_zero, ↓reduceIte, LexLeanLaws.lessThan_nat, LexLeanLaws.lessThan_int, LexLeanLaws.lessThan_int8, LexLeanLaws.lessThan_int16, LexLeanLaws.lessThan_int32, LexLeanLaws.lessThan_int64, LexLeanLaws.lessThan_uint8, LexLeanLaws.lessThan_uint16, LexLeanLaws.lessThan_uint32, LexLeanLaws.lessThan_uint64, LexLeanLaws.quotient_nat, LexLeanLaws.quotient_int, LexLeanLaws.remainder_nat, LexLeanLaws.remainder_int, LexLeanLaws.tdiv_ediv, LexLeanLaws.tmod_emod, LexLeanLaws.length_list, LexLeanLaws.append_list, LexLeanLaws.setFold_listFold, LexLeanLaws.mapFold_listFold, LexLeanLaws.setSize_length, LexLeanLaws.mapSize_length, LexLeanLaws.setElements_self, LexLeanLaws.mapEntries_self, LexLeanLaws.listFold_nil, LexLeanLaws.listFold_append, LexLeanLaws.listFold_prepend, LexLeanLaws.listFold_extend, LexLeanLaws.listFold_add_nat, LexLeanLaws.listFold_add_nat_self, LexLeanLaws.listFold_add_int, LexLeanLaws.listFold_add_int_self, LexLeanLaws.listFold_sub_int, LexLeanLaws.listFold_sub_int_self, LexLeanLaws.sumNat_nil, LexLeanLaws.sumNat_cons, LexLeanLaws.sumInt_nil, LexLeanLaws.sumInt_cons, LexLeanLaws.sumNat_add, LexLeanLaws.sumInt_add, LexLeanLaws.sumInt_sub, LexLeanLaws.sumInt_neg, LexLeanLaws.sumInt_neg_self, LexLeanLaws.sumNat_mul, LexLeanLaws.sumInt_mul, LexLeanLaws.sumNat_mul_self, LexLeanLaws.sumInt_mul_self, LexLeanLaws.sumNat_mul_right, LexLeanLaws.sumInt_mul_right, LexLeanLaws.sumNat_const, LexLeanLaws.sumInt_const, LexLeanLaws.sumNat_append, LexLeanLaws.sumInt_append, LexLeanLaws.sumNat_reverse, LexLeanLaws.sumInt_reverse, UInt8.le_iff_toNat_le, UInt8.lt_iff_toNat_lt, UInt16.le_iff_toNat_le, UInt16.lt_iff_toNat_lt, UInt32.le_iff_toNat_le, UInt32.lt_iff_toNat_lt, UInt64.le_iff_toNat_le, UInt64.lt_iff_toNat_lt, Int8.le_iff_toInt_le, Int8.lt_iff_toInt_lt, Int16.le_iff_toInt_le, Int16.lt_iff_toInt_lt, Int32.le_iff_toInt_le, Int32.lt_iff_toInt_lt, Int64.le_iff_toInt_le, Int64.lt_iff_toInt_lt, UInt8.reduceToNat, ← UInt8.toNat_inj, UInt16.reduceToNat, ← UInt16.toNat_inj, UInt32.reduceToNat, ← UInt32.toNat_inj, UInt64.reduceToNat, ← UInt64.toNat_inj, Int8.reduceToInt, ← Int8.toInt_inj, Int16.reduceToInt, ← Int16.toInt_inj, Int32.reduceToInt, ← Int32.toInt_inj, Int64.reduceToInt, ← Int64.toInt_inj] at *
    try set_option linter.unusedSimpArgs false in simp only [UInt8.toNat, UInt16.toNat, UInt32.toNat, UInt64.toNat, Int8.toInt, Int16.toInt, Int32.toInt, Int64.toInt, BitVec.toInt_eq_toNat_cond] at *
    all_goals (repeat' split)
    all_goals omega
  ·
    intros
    subst_vars
    try set_option linter.unusedSimpArgs false in simp only [select_work_event, ← Bool.not_eq_true, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', and_true, true_and, Option.some.injEq, Nat.beq_eq, Nat.blt_eq, Nat.ble_eq, LexLeanRuntime.subtract, LexLeanRuntime.multiply, LexLeanRuntime.negate, LexLeanRuntime.equal, beq_iff_eq, decide_eq_true_eq, decide_eq_false_iff_not, Nat.add_assoc, Int.add_assoc, Int.neg_neg, Int.emod_neg, Int.neg_zero, ↓reduceIte, LexLeanLaws.lessThan_nat, LexLeanLaws.lessThan_int, LexLeanLaws.lessThan_int8, LexLeanLaws.lessThan_int16, LexLeanLaws.lessThan_int32, LexLeanLaws.lessThan_int64, LexLeanLaws.lessThan_uint8, LexLeanLaws.lessThan_uint16, LexLeanLaws.lessThan_uint32, LexLeanLaws.lessThan_uint64, LexLeanLaws.quotient_nat, LexLeanLaws.quotient_int, LexLeanLaws.remainder_nat, LexLeanLaws.remainder_int, LexLeanLaws.tdiv_ediv, LexLeanLaws.tmod_emod, LexLeanLaws.length_list, LexLeanLaws.append_list, LexLeanLaws.setFold_listFold, LexLeanLaws.mapFold_listFold, LexLeanLaws.setSize_length, LexLeanLaws.mapSize_length, LexLeanLaws.setElements_self, LexLeanLaws.mapEntries_self, LexLeanLaws.listFold_nil, LexLeanLaws.listFold_append, LexLeanLaws.listFold_prepend, LexLeanLaws.listFold_extend, LexLeanLaws.listFold_add_nat, LexLeanLaws.listFold_add_nat_self, LexLeanLaws.listFold_add_int, LexLeanLaws.listFold_add_int_self, LexLeanLaws.listFold_sub_int, LexLeanLaws.listFold_sub_int_self, LexLeanLaws.sumNat_nil, LexLeanLaws.sumNat_cons, LexLeanLaws.sumInt_nil, LexLeanLaws.sumInt_cons, LexLeanLaws.sumNat_add, LexLeanLaws.sumInt_add, LexLeanLaws.sumInt_sub, LexLeanLaws.sumInt_neg, LexLeanLaws.sumInt_neg_self, LexLeanLaws.sumNat_mul, LexLeanLaws.sumInt_mul, LexLeanLaws.sumNat_mul_self, LexLeanLaws.sumInt_mul_self, LexLeanLaws.sumNat_mul_right, LexLeanLaws.sumInt_mul_right, LexLeanLaws.sumNat_const, LexLeanLaws.sumInt_const, LexLeanLaws.sumNat_append, LexLeanLaws.sumInt_append, LexLeanLaws.sumNat_reverse, LexLeanLaws.sumInt_reverse, UInt8.le_iff_toNat_le, UInt8.lt_iff_toNat_lt, UInt16.le_iff_toNat_le, UInt16.lt_iff_toNat_lt, UInt32.le_iff_toNat_le, UInt32.lt_iff_toNat_lt, UInt64.le_iff_toNat_le, UInt64.lt_iff_toNat_lt, Int8.le_iff_toInt_le, Int8.lt_iff_toInt_lt, Int16.le_iff_toInt_le, Int16.lt_iff_toInt_lt, Int32.le_iff_toInt_le, Int32.lt_iff_toInt_lt, Int64.le_iff_toInt_le, Int64.lt_iff_toInt_lt, UInt8.reduceToNat, ← UInt8.toNat_inj, UInt16.reduceToNat, ← UInt16.toNat_inj, UInt32.reduceToNat, ← UInt32.toNat_inj, UInt64.reduceToNat, ← UInt64.toNat_inj, Int8.reduceToInt, ← Int8.toInt_inj, Int16.reduceToInt, ← Int16.toInt_inj, Int32.reduceToInt, ← Int32.toInt_inj, Int64.reduceToInt, ← Int64.toInt_inj] at *
    try set_option linter.unusedSimpArgs false in simp only [UInt8.toNat, UInt16.toNat, UInt32.toNat, UInt64.toNat, Int8.toInt, Int16.toInt, Int32.toInt, Int64.toInt, BitVec.toInt_eq_toNat_cond] at *
    all_goals (repeat' split)
    all_goals omega

public theorem guard_selector_expansion (selectedGuard : Bool) (selectedEvent : WorkEvent) (otherEvent : WorkEvent) : ((if selectedGuard then selectedEvent else otherEvent) = select_work_event (selectedGuard) (selectedEvent) (otherEvent)) := by
  rfl

public theorem index_left_branch_is_one_bounded_descent (cachedLength : Nat) (cachedHeight : Nat) (leftRope : Rope) (rightRope : Rope) (index : Nat) (continuations : List (WorkContinuation)) : (((Nat.blt (index) (length (leftRope))) = true) -> (workStep (({ task := WorkTask.indexing (Rope.branch (cachedLength) (cachedHeight) (leftRope) (rightRope)) (index), continuations := continuations } : Work)) = WorkEvent.advanced (({ task := WorkTask.indexing (leftRope) (index), continuations := continuations } : Work)))) := by
  simp only [guard_selector_expansion, true_guard_selects_work_event, workStep]

public theorem returning_rope_with_no_continuations_finishes_exactly (resultRope : Rope) : (workStep (({ task := WorkTask.returning (resultRope), continuations := ([] : List (WorkContinuation)) } : Work)) = WorkEvent.sequenceDone (resultRope)) := by
  rfl

end Uorc.Uorc.Core.Bytes
