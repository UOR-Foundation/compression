module
public import Init
public import LexLeanRuntime.Portable
public import LexLeanRuntime.Collections
public import Uorc.Uorc.Core.Heap
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimePeak

@[expose] public def chooseWord (rightLarger : Bool) (left : UInt64) (right : UInt64) : UInt64 := (if rightLarger then right else left)

@[expose] public def maxWord (left : UInt64) (right : UInt64) : UInt64 := chooseWord ((LexLeanCollections.lessThan (left) (right) : Bool)) (left) (right)

@[expose] public def beginEvent (arena : Uorc.Uorc.Core.Heap.Arena) : Except (Uorc.Uorc.Core.Heap.HeapError) (UInt64) := Uorc.Uorc.Core.Heap.totalOwnedBytes (arena)

@[expose] public def completeEvent (previousPeak : UInt64) (beforeBytes : UInt64) (afterArena : Uorc.Uorc.Core.Heap.Arena) : Except (Uorc.Uorc.Core.Heap.HeapError) (UInt64) := (match Uorc.Uorc.Core.Heap.totalOwnedBytes (afterArena) with | Except.error failure => Except.error (failure) | Except.ok afterBytes => Except.ok (maxWord (maxWord (previousPeak) (beforeBytes)) (afterBytes)))

@[expose] public def failedEvent (previousPeak : UInt64) (beforeBytes : UInt64) : UInt64 := maxWord (previousPeak) (beforeBytes)

end Uorc.Uorc.Core.RuntimePeak
