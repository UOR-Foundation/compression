module
public import Init
public import LexLeanRuntime.Portable
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Product.Storage

public inductive Category where
  | stagedOutput
  | inputSpool
  | spill
  | publicationCopy

public structure Amounts where
  stagedOutput : Nat
  inputSpool : Nat
  spill : Nat
  publicationCopy : Nat

public structure Limits where
  total : Option (Nat)
  stagedOutput : Option (Nat)
  inputSpool : Option (Nat)
  spill : Option (Nat)
  publicationCopy : Option (Nat)

public structure Usage where
  retained : Amounts
  reserved : Amounts
  peakRetainedBytes : Nat
  peakAdmittedBytes : Nat

public inductive Error where
  | quotaTotal (_ : Nat) (_ : Nat) (_ : Nat)
  | quotaCategory (_ : Category) (_ : Nat) (_ : Nat) (_ : Nat)
  | reservationExtent (_ : Category) (_ : Nat) (_ : Nat)
  | releaseExtent (_ : Category) (_ : Nat) (_ : Nat)

public structure State where
  usage : Usage
  error : Option (Error)

public inductive Event where
  | reserve (_ : Category) (_ : Nat)
  | written (_ : Category) (_ : Nat) (_ : Nat)
  | failedWrite (_ : Category) (_ : Nat) (_ : Nat)
  | release (_ : Category) (_ : Nat)
  | transfer (_ : Category) (_ : Nat)

@[expose] public def zeroAmounts : Amounts := ({ stagedOutput := 0, inputSpool := 0, spill := 0, publicationCopy := 0 } : Amounts)

@[expose] public def unlimitedRequest : Limits := ({ total := Option.none, stagedOutput := Option.none, inputSpool := Option.none, spill := Option.none, publicationCopy := Option.none } : Limits)

@[expose] public def zeroUsage : Usage := ({ retained := zeroAmounts, reserved := zeroAmounts, peakRetainedBytes := 0, peakAdmittedBytes := 0 } : Usage)

@[expose] public def initial : State := ({ usage := zeroUsage, error := Option.none } : State)

@[expose] public def totalAmounts (amounts : Amounts) : Nat := ((((0 + (amounts).stagedOutput) + (amounts).inputSpool) + (amounts).spill) + (amounts).publicationCopy)

@[expose] public def retainedBytes (usage : Usage) : Nat := totalAmounts ((usage).retained)

@[expose] public def reservedBytes (usage : Usage) : Nat := totalAmounts ((usage).reserved)

@[expose] public def admittedBytes (usage : Usage) : Nat := (retainedBytes (usage) + reservedBytes (usage))

@[expose] public def amount (amounts : Amounts) (category : Category) : Nat := (match category with | Category.stagedOutput => (amounts).stagedOutput | Category.inputSpool => (amounts).inputSpool | Category.spill => (amounts).spill | Category.publicationCopy => (amounts).publicationCopy)

@[expose] public def limit (limits : Limits) (category : Category) : Option (Nat) := (match category with | Category.stagedOutput => (limits).stagedOutput | Category.inputSpool => (limits).inputSpool | Category.spill => (limits).spill | Category.publicationCopy => (limits).publicationCopy)

@[expose] public def setAmount (amounts : Amounts) (category : Category) (bytes : Nat) : Amounts := (match category with | Category.stagedOutput => ({ stagedOutput := bytes, inputSpool := (amounts).inputSpool, spill := (amounts).spill, publicationCopy := (amounts).publicationCopy } : Amounts) | Category.inputSpool => ({ stagedOutput := (amounts).stagedOutput, inputSpool := bytes, spill := (amounts).spill, publicationCopy := (amounts).publicationCopy } : Amounts) | Category.spill => ({ stagedOutput := (amounts).stagedOutput, inputSpool := (amounts).inputSpool, spill := bytes, publicationCopy := (amounts).publicationCopy } : Amounts) | Category.publicationCopy => ({ stagedOutput := (amounts).stagedOutput, inputSpool := (amounts).inputSpool, spill := (amounts).spill, publicationCopy := bytes } : Amounts))

@[expose] public def maximum (left : Nat) (right : Nat) : Nat := (if (Nat.blt (left) (right)) then right else left)

@[expose] public def fits (argLimit : Option (Nat)) (used : Nat) (increase : Nat) : Bool := (match argLimit with | Option.none => true | Option.some bindingMaximum => (!(Nat.blt (bindingMaximum) ((used + increase)))))

@[expose] public def reserve (limits : Limits) (usage : Usage) (category : Category) (bytes : Nat) : Except (Error) (Usage) := (if fits ((limits).total) (admittedBytes (usage)) (bytes) then (if fits (limit (limits) (category)) ((amount ((usage).retained) (category) + amount ((usage).reserved) (category))) (bytes) then Except.ok (({ retained := (usage).retained, reserved := setAmount ((usage).reserved) (category) ((amount ((usage).reserved) (category) + bytes)), peakRetainedBytes := maximum ((usage).peakRetainedBytes) (totalAmounts ((usage).retained)), peakAdmittedBytes := maximum ((usage).peakAdmittedBytes) ((totalAmounts ((usage).retained) + totalAmounts (setAmount ((usage).reserved) (category) ((amount ((usage).reserved) (category) + bytes))))) } : Usage)) else Except.error (Error.quotaCategory (category) ((amount ((usage).retained) (category) + amount ((usage).reserved) (category))) (bytes) ((match limit (limits) (category) with | Option.none => 0 | Option.some bindingMaximum => bindingMaximum)))) else Except.error (Error.quotaTotal (admittedBytes (usage)) (bytes) ((match (limits).total with | Option.none => 0 | Option.some bindingMaximum => bindingMaximum))))

@[expose] public def recordWrite (usage : Usage) (category : Category) (reservation : Nat) (achieved : Nat) : Except (Error) (Usage) := (if ((!(Nat.blt (amount ((usage).reserved) (category)) (reservation))) && ((!(Nat.blt (reservation) (achieved))) && true)) then Except.ok (({ retained := setAmount ((usage).retained) (category) ((amount ((usage).retained) (category) + achieved)), reserved := setAmount ((usage).reserved) (category) ((LexLeanRuntime.subtract (amount ((usage).reserved) (category)) (reservation) : Nat)), peakRetainedBytes := maximum ((usage).peakRetainedBytes) (totalAmounts (setAmount ((usage).retained) (category) ((amount ((usage).retained) (category) + achieved)))), peakAdmittedBytes := maximum ((usage).peakAdmittedBytes) ((totalAmounts (setAmount ((usage).retained) (category) ((amount ((usage).retained) (category) + achieved))) + totalAmounts (setAmount ((usage).reserved) (category) ((LexLeanRuntime.subtract (amount ((usage).reserved) (category)) (reservation) : Nat))))) } : Usage)) else Except.error (Error.reservationExtent (category) (reservation) (achieved)))

@[expose] public def release (usage : Usage) (category : Category) (bytes : Nat) : Except (Error) (Usage) := (if (!(Nat.blt (amount ((usage).retained) (category)) (bytes))) then Except.ok (({ retained := setAmount ((usage).retained) (category) ((LexLeanRuntime.subtract (amount ((usage).retained) (category)) (bytes) : Nat)), reserved := (usage).reserved, peakRetainedBytes := maximum ((usage).peakRetainedBytes) (totalAmounts (setAmount ((usage).retained) (category) ((LexLeanRuntime.subtract (amount ((usage).retained) (category)) (bytes) : Nat)))), peakAdmittedBytes := maximum ((usage).peakAdmittedBytes) ((totalAmounts (setAmount ((usage).retained) (category) ((LexLeanRuntime.subtract (amount ((usage).retained) (category)) (bytes) : Nat))) + totalAmounts ((usage).reserved))) } : Usage)) else Except.error (Error.releaseExtent (category) (amount ((usage).retained) (category)) (bytes)))

@[expose] public def step (limits : Limits) (state : State) (event : Event) : State := (match event with | Event.reserve category bytes => (match reserve (limits) ((state).usage) (category) (bytes) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)) | Event.written category reservation achieved => (match recordWrite ((state).usage) (category) (reservation) (achieved) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)) | Event.failedWrite category reservation achieved => (match recordWrite ((state).usage) (category) (reservation) (achieved) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)) | Event.release category bytes => (match release ((state).usage) (category) (bytes) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)) | Event.transfer category bytes => (match release ((state).usage) (category) (bytes) with | Except.error error => ({ usage := (state).usage, error := Option.some (error) } : State) | Except.ok usage => ({ usage := usage, error := Option.none } : State)))

@[expose] public def run : (limits : Limits) -> (state : State) -> (events : List (Event)) -> State
  | _limits, state, List.nil => state
  | limits, state, List.cons head tail => run (limits) (step (limits) (state) (head)) (tail)

@[expose] public def controls : Bool := ((Nat.beq (retainedBytes ((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.failedWrite (Category.stagedOutput) (100) (37) :: ([] : List (Event)))))).usage)) (37)) && ((Nat.beq (reservedBytes ((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.failedWrite (Category.stagedOutput) (100) (37) :: ([] : List (Event)))))).usage)) (0)) && ((Nat.beq (((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.failedWrite (Category.stagedOutput) (100) (37) :: ([] : List (Event)))))).usage).peakAdmittedBytes) (100)) && ((Nat.beq (((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.failedWrite (Category.stagedOutput) (100) (37) :: ([] : List (Event)))))).usage).peakRetainedBytes) (37)) && ((match (run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (101) :: ([] : List (Event))))).error with | Option.none => false | Option.some _ => true) && ((Nat.beq (admittedBytes ((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (101) :: ([] : List (Event))))).usage)) (0)) && ((Nat.beq (retainedBytes ((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.written (Category.stagedOutput) (100) (80) :: (Event.transfer (Category.stagedOutput) (80) :: ([] : List (Event))))))).usage)) (0)) && ((Nat.beq (((run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.reserve (Category.stagedOutput) (100) :: (Event.written (Category.stagedOutput) (100) (80) :: (Event.transfer (Category.stagedOutput) (80) :: ([] : List (Event))))))).usage).peakRetainedBytes) (80)) && ((match (run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.release (Category.stagedOutput) (1) :: ([] : List (Event))))).error with | Option.none => false | Option.some _ => true) && ((match (run (({ total := Option.some (100), stagedOutput := Option.some (100), inputSpool := Option.some (100), spill := Option.some (100), publicationCopy := Option.some (100) } : Limits)) (initial) ((Event.written (Category.stagedOutput) (1) (1) :: ([] : List (Event))))).error with | Option.none => false | Option.some _ => true) && true))))))))))

@[expose] public def boundary : String := "This ledger accounts unique product-owned storage allocations and reservations, separately from logical arena bytes. Requested None quotas impose no additional product size ceiling; actual host storage admission is still required. The source-owned adapter validates the reservation lease and exactly-once acknowledgment before applying these counter transitions. A partial failed write records achieved retained bytes and releases only its unused reservation. Custody transfer does not allocate another copy; a copy requires a separately admitted publicationCopy allocation. Physical RSS and physical storage observations are optional measurements, not inferred from these counters."

@[expose] public def sameUsage (left : Usage) (right : Usage) : Bool := ((Nat.beq (((left).retained).stagedOutput) (((right).retained).stagedOutput)) && ((Nat.beq (((left).retained).inputSpool) (((right).retained).inputSpool)) && ((Nat.beq (((left).retained).spill) (((right).retained).spill)) && ((Nat.beq (((left).retained).publicationCopy) (((right).retained).publicationCopy)) && ((Nat.beq (((left).reserved).stagedOutput) (((right).reserved).stagedOutput)) && ((Nat.beq (((left).reserved).inputSpool) (((right).reserved).inputSpool)) && ((Nat.beq (((left).reserved).spill) (((right).reserved).spill)) && ((Nat.beq (((left).reserved).publicationCopy) (((right).reserved).publicationCopy)) && ((Nat.beq ((left).peakRetainedBytes) ((right).peakRetainedBytes)) && ((Nat.beq ((left).peakAdmittedBytes) ((right).peakAdmittedBytes)) && true))))))))))

end Uorc.Uorc.Product.Storage
