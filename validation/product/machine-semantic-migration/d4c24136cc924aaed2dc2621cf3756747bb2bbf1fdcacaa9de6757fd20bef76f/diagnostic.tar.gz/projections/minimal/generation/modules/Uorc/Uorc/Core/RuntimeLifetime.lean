module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.Resources
public import Uorc.Uorc.Core.RuntimeMetadata
public import Uorc.Uorc.Core.RuntimeProgram
public import Uorc.Uorc.Core.RuntimeTable
public import Uorc.Uorc.Core.RuntimeValue
public import Uorc.Uorc.Core.Types
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeLifetime

public structure Cursor where
  parameterCount : UInt64
  instructionCount : UInt64
  slotCount : UInt64
  returnSlot : UInt64
  nextSlot : UInt64

public inductive Bucket where
  | initial
  | after (_ : UInt64)

public inductive Event where
  | assigned (_ : Cursor) (_ : Bucket) (_ : UInt64)
  | skipped (_ : Cursor)
  | done

@[expose] public def readUse (arena : Uorc.Uorc.Core.Heap.Arena) (lastUses : Uorc.Uorc.Core.RuntimeTable.Table) (slot : UInt64) : Except (Uorc.Uorc.Core.RuntimeProgram.Failure) (Option (UInt64)) := (match Uorc.Uorc.Core.RuntimeTable.lookup (arena) (lastUses) (slot) with | Except.error heapError => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.heap (heapError)) | Except.ok leaf => (if Uorc.Uorc.Core.RuntimeValue.isNull (leaf) then Except.ok (Option.none) else (match Uorc.Uorc.Core.RuntimeProgram.valueAtLeaf (arena) (leaf) (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) with | Except.error leafError => Except.error (leafError) | Except.ok value => (match value with | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.natural stamp => Except.ok (Option.some (stamp)) | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.byte _ => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.typeMismatch)) | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.predicate _ => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.typeMismatch)) | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.sequence _ => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.typeMismatch)) | Uorc.Uorc.Core.RuntimeValue.RuntimeValue.store _ _ => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.typeMismatch))))))

@[expose] public def start (parameterCount : UInt64) (instructionCount : UInt64) (returnSlot : UInt64) : Except (Uorc.Uorc.Core.RuntimeProgram.Failure) (Cursor) := (match (LexLeanRuntime.checkedAdd (parameterCount) (instructionCount) : Option (UInt64)) with | Option.none => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.operational (Uorc.Uorc.Core.Resources.OperationalError.addressSpaceExhausted)) | Option.some slotCount => (if Uorc.Uorc.Core.Heap.less (returnSlot) (slotCount) then Except.ok (({ parameterCount := parameterCount, instructionCount := instructionCount, slotCount := slotCount, returnSlot := returnSlot, nextSlot := (0 : UInt64) } : Cursor)) else Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference))))

@[expose] public def step (arena : Uorc.Uorc.Core.Heap.Arena) (lastUses : Uorc.Uorc.Core.RuntimeTable.Table) (cursor : Cursor) : Except (Uorc.Uorc.Core.RuntimeProgram.Failure) (Event) := (if Uorc.Uorc.Core.Heap.less ((cursor).nextSlot) ((cursor).slotCount) then (match (LexLeanRuntime.checkedAdd ((cursor).nextSlot) ((1 : UInt64)) : Option (UInt64)) with | Option.none => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.operational (Uorc.Uorc.Core.Resources.OperationalError.addressSpaceExhausted)) | Option.some following => (if (LexLeanRuntime.equal ((cursor).nextSlot) ((cursor).returnSlot) : Bool) then Except.ok (Event.skipped (({ parameterCount := (cursor).parameterCount, instructionCount := (cursor).instructionCount, slotCount := (cursor).slotCount, returnSlot := (cursor).returnSlot, nextSlot := following } : Cursor))) else (match readUse (arena) (lastUses) ((cursor).nextSlot) with | Except.error readError => Except.error (readError) | Except.ok timestamp => (match timestamp with | Option.none => (if Uorc.Uorc.Core.Heap.less ((cursor).nextSlot) ((cursor).parameterCount) then Except.ok (Event.assigned (({ parameterCount := (cursor).parameterCount, instructionCount := (cursor).instructionCount, slotCount := (cursor).slotCount, returnSlot := (cursor).returnSlot, nextSlot := following } : Cursor)) (Bucket.initial) ((cursor).nextSlot)) else (match (LexLeanRuntime.checkedSubtract ((cursor).nextSlot) ((cursor).parameterCount) : Option (UInt64)) with | Option.none => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) | Option.some creationIndex => Except.ok (Event.assigned (({ parameterCount := (cursor).parameterCount, instructionCount := (cursor).instructionCount, slotCount := (cursor).slotCount, returnSlot := (cursor).returnSlot, nextSlot := following } : Cursor)) (Bucket.after (creationIndex)) ((cursor).nextSlot)))) | Option.some stamp => (if Uorc.Uorc.Core.Heap.less (stamp) ((cursor).instructionCount) then (if Uorc.Uorc.Core.Heap.less ((cursor).nextSlot) ((cursor).parameterCount) then Except.ok (Event.assigned (({ parameterCount := (cursor).parameterCount, instructionCount := (cursor).instructionCount, slotCount := (cursor).slotCount, returnSlot := (cursor).returnSlot, nextSlot := following } : Cursor)) (Bucket.after (stamp)) ((cursor).nextSlot)) else (match (LexLeanRuntime.checkedSubtract ((cursor).nextSlot) ((cursor).parameterCount) : Option (UInt64)) with | Option.none => Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) | Option.some creationIndex => (if Uorc.Uorc.Core.Heap.less (stamp) (creationIndex) then Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference)) else Except.ok (Event.assigned (({ parameterCount := (cursor).parameterCount, instructionCount := (cursor).instructionCount, slotCount := (cursor).slotCount, returnSlot := (cursor).returnSlot, nextSlot := following } : Cursor)) (Bucket.after (stamp)) ((cursor).nextSlot))))) else Except.error (Uorc.Uorc.Core.RuntimeProgram.Failure.static (Uorc.Uorc.Core.Types.StaticError.invalidLocalReference))))))) else Except.ok (Event.done))

end Uorc.Uorc.Core.RuntimeLifetime
