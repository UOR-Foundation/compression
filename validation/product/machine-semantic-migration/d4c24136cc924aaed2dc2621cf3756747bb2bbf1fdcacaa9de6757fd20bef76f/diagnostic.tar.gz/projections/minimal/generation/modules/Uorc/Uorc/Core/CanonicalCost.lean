module
public import Init
public import LexLeanRuntime.Portable
public import LexLeanRuntime.Laws
public import Uorc.Uorc.Core.Bytes
public import Uorc.Uorc.Core.ReferenceSemantics
public import Uorc.Uorc.Core.RuntimeOpcode
public import Uorc.Uorc.Core.Store
public import Uorc.Uorc.Core.Types
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.CanonicalCost

public inductive ProfileId where
  | canonicalReferenceWork1
  | logicalReferenceEvents1

@[expose] public def currentProfile : ProfileId := ProfileId.logicalReferenceEvents1

@[expose] public def sameProfile (first : ProfileId) (second : ProfileId) : Bool := (match first with | ProfileId.canonicalReferenceWork1 => (match second with | ProfileId.canonicalReferenceWork1 => true | ProfileId.logicalReferenceEvents1 => false) | ProfileId.logicalReferenceEvents1 => (match second with | ProfileId.canonicalReferenceWork1 => false | ProfileId.logicalReferenceEvents1 => true))

@[expose] public def profileIdentity : String := "uorc.logical-reference-events/1"

@[expose] public def representationIdentity : String := "uorc.fixed4096-byte-leaves/1"

@[expose] public def refinementIdentity : String := "uorc.logical-reference-owned-binding-bridge/1"

@[expose] public def storageUnitIdentity : String := "uorc.logical-live-binding-payload-units/1"

@[expose] public def scopeIdentity : String := "semantic-execution;parsing-admission-integrity-operational"

@[expose] public def qualificationStatus : String := "logical-schedule-and-binding-spine-authored-full-refinement-unproved"

@[expose] public def profileIdentityFor (profile : ProfileId) : String := (match profile with | ProfileId.canonicalReferenceWork1 => "uorc.canonical-reference-work/1" | ProfileId.logicalReferenceEvents1 => profileIdentity)

@[expose] public def profileSupported (profile : ProfileId) : Bool := (match profile with | ProfileId.canonicalReferenceWork1 => false | ProfileId.logicalReferenceEvents1 => true)

@[expose] public def semanticValueIdentity : String := "uorc.logical-reference-values/1"

public inductive StorageScope where
  | unconstrained
  | liveBindingPayloadBytes (_ : Nat)
  | liveBindingPayloadUnits (_ : Nat)

public structure Budget where
  maxSemanticWork : Nat
  storage : StorageScope

public structure Usage where
  semanticWork : Nat
  semanticStorageUnits : Nat
  peakSemanticStorageUnits : Nat
  outputBytes : Nat
  activeFrames : Nat
  peakFrames : Nat
  acceptedArchives : Nat
  basisObjects : Nat

public inductive SemanticEvent where
  | instruction (_ : Uorc.Uorc.Core.RuntimeOpcode.Opcode)
  | parameterBind
  | referenceRead
  | blockEnter
  | blockLeave
  | loopObserve
  | loopUpdate
  | byteRead
  | byteWrite
  | byteComparison
  | outputBoundary
  | outputByte
  | basisBoundary
  | canonicalEof
  | allocateValueUnits (_ : Nat)
  | releaseValueUnits (_ : Nat)

public inductive Error where
  | invalidUsage
  | workLimit
  | storageLimit
  | storageUnderflow
  | frameUnderflow

@[expose] public def budgetSupported (profile : ProfileId) (budget : Budget) : Bool := (profileSupported (profile) && (match (budget).storage with | StorageScope.unconstrained => true | StorageScope.liveBindingPayloadBytes _ => false | StorageScope.liveBindingPayloadUnits _ => true))

@[expose] public def zeroUsage : Usage := ({ semanticWork := 0, semanticStorageUnits := 0, peakSemanticStorageUnits := 0, outputBytes := 0, activeFrames := 0, peakFrames := 0, acceptedArchives := 0, basisObjects := 0 } : Usage)

@[expose] public def instructionWork (opcode : Uorc.Uorc.Core.RuntimeOpcode.Opcode) : Nat := (match opcode with | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalConstant => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.byteConstant => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.predicateConstant => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceConstant => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalAdd => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalSubtract => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalMultiply => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalDivide => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalRemainder => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalAnd => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalOr => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalXor => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalNot => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalShiftLeft => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalShiftRight => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalEqual => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalLess => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.byteEqual => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.byteLess => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.naturalToByte => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.byteToNatural => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.predicateNot => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.predicateAnd => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.predicateOr => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceLength => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceIndex => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceSlice => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceConcat => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceEqual => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.singletonSequence => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.basisGet => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.storeNew => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.storeRead => 65 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.storeWrite => 65 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.choose => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.apply => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.tabulate => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.fold => 1 | Uorc.Uorc.Core.RuntimeOpcode.Opcode.scan => 1)

@[expose] public def eventWork (event : SemanticEvent) : Nat := (match event with | SemanticEvent.instruction payload => instructionWork (payload) | SemanticEvent.parameterBind => 1 | SemanticEvent.referenceRead => 1 | SemanticEvent.blockEnter => 1 | SemanticEvent.blockLeave => 1 | SemanticEvent.loopObserve => 1 | SemanticEvent.loopUpdate => 1 | SemanticEvent.byteRead => 1 | SemanticEvent.byteWrite => 1 | SemanticEvent.byteComparison => 1 | SemanticEvent.outputBoundary => 1 | SemanticEvent.outputByte => 1 | SemanticEvent.basisBoundary => 1 | SemanticEvent.canonicalEof => 1 | SemanticEvent.allocateValueUnits _ => 1 | SemanticEvent.releaseValueUnits _ => 1)

@[expose] public def allocatedUnits (event : SemanticEvent) : Nat := (match event with | SemanticEvent.instruction _ => 0 | SemanticEvent.parameterBind => 0 | SemanticEvent.referenceRead => 0 | SemanticEvent.blockEnter => 0 | SemanticEvent.blockLeave => 0 | SemanticEvent.loopObserve => 0 | SemanticEvent.loopUpdate => 0 | SemanticEvent.byteRead => 0 | SemanticEvent.byteWrite => 0 | SemanticEvent.byteComparison => 0 | SemanticEvent.outputBoundary => 0 | SemanticEvent.outputByte => 0 | SemanticEvent.basisBoundary => 0 | SemanticEvent.canonicalEof => 0 | SemanticEvent.allocateValueUnits payload => payload | SemanticEvent.releaseValueUnits _ => 0)

@[expose] public def releasedUnits (event : SemanticEvent) : Nat := (match event with | SemanticEvent.instruction _ => 0 | SemanticEvent.parameterBind => 0 | SemanticEvent.referenceRead => 0 | SemanticEvent.blockEnter => 0 | SemanticEvent.blockLeave => 0 | SemanticEvent.loopObserve => 0 | SemanticEvent.loopUpdate => 0 | SemanticEvent.byteRead => 0 | SemanticEvent.byteWrite => 0 | SemanticEvent.byteComparison => 0 | SemanticEvent.outputBoundary => 0 | SemanticEvent.outputByte => 0 | SemanticEvent.basisBoundary => 0 | SemanticEvent.canonicalEof => 0 | SemanticEvent.allocateValueUnits _ => 0 | SemanticEvent.releaseValueUnits payload => payload)

@[expose] public def outputCount (event : SemanticEvent) : Nat := (match event with | SemanticEvent.instruction _ => 0 | SemanticEvent.parameterBind => 0 | SemanticEvent.referenceRead => 0 | SemanticEvent.blockEnter => 0 | SemanticEvent.blockLeave => 0 | SemanticEvent.loopObserve => 0 | SemanticEvent.loopUpdate => 0 | SemanticEvent.byteRead => 0 | SemanticEvent.byteWrite => 0 | SemanticEvent.byteComparison => 0 | SemanticEvent.outputBoundary => 0 | SemanticEvent.outputByte => 1 | SemanticEvent.basisBoundary => 0 | SemanticEvent.canonicalEof => 0 | SemanticEvent.allocateValueUnits _ => 0 | SemanticEvent.releaseValueUnits _ => 0)

@[expose] public def enteredFrames (event : SemanticEvent) : Nat := (match event with | SemanticEvent.instruction _ => 0 | SemanticEvent.parameterBind => 0 | SemanticEvent.referenceRead => 0 | SemanticEvent.blockEnter => 1 | SemanticEvent.blockLeave => 0 | SemanticEvent.loopObserve => 0 | SemanticEvent.loopUpdate => 0 | SemanticEvent.byteRead => 0 | SemanticEvent.byteWrite => 0 | SemanticEvent.byteComparison => 0 | SemanticEvent.outputBoundary => 0 | SemanticEvent.outputByte => 0 | SemanticEvent.basisBoundary => 0 | SemanticEvent.canonicalEof => 0 | SemanticEvent.allocateValueUnits _ => 0 | SemanticEvent.releaseValueUnits _ => 0)

@[expose] public def leftFrames (event : SemanticEvent) : Nat := (match event with | SemanticEvent.instruction _ => 0 | SemanticEvent.parameterBind => 0 | SemanticEvent.referenceRead => 0 | SemanticEvent.blockEnter => 0 | SemanticEvent.blockLeave => 1 | SemanticEvent.loopObserve => 0 | SemanticEvent.loopUpdate => 0 | SemanticEvent.byteRead => 0 | SemanticEvent.byteWrite => 0 | SemanticEvent.byteComparison => 0 | SemanticEvent.outputBoundary => 0 | SemanticEvent.outputByte => 0 | SemanticEvent.basisBoundary => 0 | SemanticEvent.canonicalEof => 0 | SemanticEvent.allocateValueUnits _ => 0 | SemanticEvent.releaseValueUnits _ => 0)

@[expose] public def eofCount (event : SemanticEvent) : Nat := (match event with | SemanticEvent.instruction _ => 0 | SemanticEvent.parameterBind => 0 | SemanticEvent.referenceRead => 0 | SemanticEvent.blockEnter => 0 | SemanticEvent.blockLeave => 0 | SemanticEvent.loopObserve => 0 | SemanticEvent.loopUpdate => 0 | SemanticEvent.byteRead => 0 | SemanticEvent.byteWrite => 0 | SemanticEvent.byteComparison => 0 | SemanticEvent.outputBoundary => 0 | SemanticEvent.outputByte => 0 | SemanticEvent.basisBoundary => 0 | SemanticEvent.canonicalEof => 1 | SemanticEvent.allocateValueUnits _ => 0 | SemanticEvent.releaseValueUnits _ => 0)

@[expose] public def basisCount (event : SemanticEvent) : Nat := (match event with | SemanticEvent.instruction _ => 0 | SemanticEvent.parameterBind => 0 | SemanticEvent.referenceRead => 0 | SemanticEvent.blockEnter => 0 | SemanticEvent.blockLeave => 0 | SemanticEvent.loopObserve => 0 | SemanticEvent.loopUpdate => 0 | SemanticEvent.byteRead => 0 | SemanticEvent.byteWrite => 0 | SemanticEvent.byteComparison => 0 | SemanticEvent.outputBoundary => 0 | SemanticEvent.outputByte => 0 | SemanticEvent.basisBoundary => 1 | SemanticEvent.canonicalEof => 0 | SemanticEvent.allocateValueUnits _ => 0 | SemanticEvent.releaseValueUnits _ => 0)

@[expose] public def advance (usage : Usage) (event : SemanticEvent) : Usage := ({ semanticWork := ((usage).semanticWork + eventWork (event)), semanticStorageUnits := (LexLeanRuntime.subtract (((usage).semanticStorageUnits + allocatedUnits (event))) (releasedUnits (event)) : Nat), peakSemanticStorageUnits := (if (Nat.ble ((usage).peakSemanticStorageUnits) (((usage).semanticStorageUnits + allocatedUnits (event)))) then ((usage).semanticStorageUnits + allocatedUnits (event)) else (usage).peakSemanticStorageUnits), outputBytes := ((usage).outputBytes + outputCount (event)), activeFrames := (LexLeanRuntime.subtract (((usage).activeFrames + enteredFrames (event))) (leftFrames (event)) : Nat), peakFrames := (if (Nat.ble ((usage).peakFrames) (((usage).activeFrames + enteredFrames (event)))) then ((usage).activeFrames + enteredFrames (event)) else (usage).peakFrames), acceptedArchives := ((usage).acceptedArchives + eofCount (event)), basisObjects := ((usage).basisObjects + basisCount (event)) } : Usage)

@[expose] public def storageFits (scope : StorageScope) (peak : Nat) : Bool := (match scope with | StorageScope.unconstrained => true | StorageScope.liveBindingPayloadBytes limit => (Nat.ble (peak) (limit)) | StorageScope.liveBindingPayloadUnits limit => (Nat.ble (peak) (limit)))

@[expose] public def charge (budget : Budget) (usage : Usage) (event : SemanticEvent) : Except (Error) (Usage) := (if (((Nat.ble ((usage).semanticStorageUnits) ((usage).peakSemanticStorageUnits)) && (Nat.ble ((usage).activeFrames) ((usage).peakFrames))) && ((Nat.ble ((usage).semanticWork) ((budget).maxSemanticWork)) && storageFits ((budget).storage) ((usage).peakSemanticStorageUnits))) then (if (!(Nat.ble (((usage).semanticWork + eventWork (event))) ((budget).maxSemanticWork))) then Except.error (Error.workLimit) else (if (!(Nat.ble (releasedUnits (event)) (((usage).semanticStorageUnits + allocatedUnits (event))))) then Except.error (Error.storageUnderflow) else (if (!(Nat.ble (leftFrames (event)) (((usage).activeFrames + enteredFrames (event))))) then Except.error (Error.frameUnderflow) else (if storageFits ((budget).storage) ((advance (usage) (event)).peakSemanticStorageUnits) then Except.ok (advance (usage) (event)) else Except.error (Error.storageLimit))))) else Except.error (Error.invalidUsage))

@[expose] public def storeEntries : (trie : Uorc.Uorc.Core.Store.Trie) -> Nat
  | Uorc.Uorc.Core.Store.Trie.empty => 0
  | Uorc.Uorc.Core.Store.Trie.leaf _ => 1
  | Uorc.Uorc.Core.Store.Trie.branch leftTrie rightTrie => (storeEntries (leftTrie) + storeEntries (rightTrie))

@[expose] public def valueUnits (value : Uorc.Uorc.Core.Types.Value) : Nat := (match value with | Uorc.Uorc.Core.Types.Value.natural _ => 8 | Uorc.Uorc.Core.Types.Value.byte _ => 1 | Uorc.Uorc.Core.Types.Value.predicate _ => 1 | Uorc.Uorc.Core.Types.Value.sequence payload => (LexLeanRuntime.length (payload) : Nat) | Uorc.Uorc.Core.Types.Value.store payload => (1 + (LexLeanRuntime.multiply (9) (storeEntries ((payload).root)) : Nat)) | Uorc.Uorc.Core.Types.Value.segmentedSequence payload => Uorc.Uorc.Core.Bytes.length (payload))

@[expose] public def appendEvents : (first : List (SemanticEvent)) -> (second : List (SemanticEvent)) -> List (SemanticEvent)
  | List.nil, second => second
  | List.cons event rest, second => (event :: appendEvents (rest) (second))

@[expose] public def workOf : (events : List (SemanticEvent)) -> Nat
  | List.nil => 0
  | List.cons event rest => (eventWork (event) + workOf (rest))

public theorem advance_commits_exact_semantic_work (usage : Usage) (event : SemanticEvent) : ((advance (usage) (event)).semanticWork = ((usage).semanticWork + eventWork (event))) := by
  rfl

public theorem advance_commits_exact_output_count (usage : Usage) (event : SemanticEvent) : ((advance (usage) (event)).outputBytes = ((usage).outputBytes + outputCount (event))) := by
  rfl

public theorem advance_keeps_basis_work_in_the_same_ledger (usage : Usage) : ((advance (usage) (SemanticEvent.basisBoundary)).semanticWork = ((usage).semanticWork + 1)) := by
  rfl

public theorem work_sum_associativity (firstWork : Nat) (secondWork : Nat) (thirdWork : Nat) : ((firstWork + (secondWork + thirdWork)) = ((firstWork + secondWork) + thirdWork)) := by
  intros
  try set_option linter.unusedSimpArgs false in simp only [← Bool.not_eq_true, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', and_true, true_and, Option.some.injEq, Nat.beq_eq, Nat.blt_eq, Nat.ble_eq, LexLeanRuntime.subtract, LexLeanRuntime.multiply, LexLeanRuntime.negate, LexLeanRuntime.equal, beq_iff_eq, decide_eq_true_eq, decide_eq_false_iff_not, Nat.add_assoc, Int.add_assoc, Int.neg_neg, Int.emod_neg, Int.neg_zero, ↓reduceIte, LexLeanLaws.lessThan_nat, LexLeanLaws.lessThan_int, LexLeanLaws.lessThan_int8, LexLeanLaws.lessThan_int16, LexLeanLaws.lessThan_int32, LexLeanLaws.lessThan_int64, LexLeanLaws.lessThan_uint8, LexLeanLaws.lessThan_uint16, LexLeanLaws.lessThan_uint32, LexLeanLaws.lessThan_uint64, LexLeanLaws.quotient_nat, LexLeanLaws.quotient_int, LexLeanLaws.remainder_nat, LexLeanLaws.remainder_int, LexLeanLaws.tdiv_ediv, LexLeanLaws.tmod_emod, LexLeanLaws.length_list, LexLeanLaws.append_list, LexLeanLaws.setFold_listFold, LexLeanLaws.mapFold_listFold, LexLeanLaws.setSize_length, LexLeanLaws.mapSize_length, LexLeanLaws.setElements_self, LexLeanLaws.mapEntries_self, LexLeanLaws.listFold_nil, LexLeanLaws.listFold_append, LexLeanLaws.listFold_prepend, LexLeanLaws.listFold_extend, LexLeanLaws.listFold_add_nat, LexLeanLaws.listFold_add_nat_self, LexLeanLaws.listFold_add_int, LexLeanLaws.listFold_add_int_self, LexLeanLaws.listFold_sub_int, LexLeanLaws.listFold_sub_int_self, LexLeanLaws.sumNat_nil, LexLeanLaws.sumNat_cons, LexLeanLaws.sumInt_nil, LexLeanLaws.sumInt_cons, LexLeanLaws.sumNat_add, LexLeanLaws.sumInt_add, LexLeanLaws.sumInt_sub, LexLeanLaws.sumInt_neg, LexLeanLaws.sumInt_neg_self, LexLeanLaws.sumNat_mul, LexLeanLaws.sumInt_mul, LexLeanLaws.sumNat_mul_self, LexLeanLaws.sumInt_mul_self, LexLeanLaws.sumNat_mul_right, LexLeanLaws.sumInt_mul_right, LexLeanLaws.sumNat_const, LexLeanLaws.sumInt_const, LexLeanLaws.sumNat_append, LexLeanLaws.sumInt_append, LexLeanLaws.sumNat_reverse, LexLeanLaws.sumInt_reverse, UInt8.le_iff_toNat_le, UInt8.lt_iff_toNat_lt, UInt16.le_iff_toNat_le, UInt16.lt_iff_toNat_lt, UInt32.le_iff_toNat_le, UInt32.lt_iff_toNat_lt, UInt64.le_iff_toNat_le, UInt64.lt_iff_toNat_lt, Int8.le_iff_toInt_le, Int8.lt_iff_toInt_lt, Int16.le_iff_toInt_le, Int16.lt_iff_toInt_lt, Int32.le_iff_toInt_le, Int32.lt_iff_toInt_lt, Int64.le_iff_toInt_le, Int64.lt_iff_toInt_lt, UInt8.reduceToNat, ← UInt8.toNat_inj, UInt16.reduceToNat, ← UInt16.toNat_inj, UInt32.reduceToNat, ← UInt32.toNat_inj, UInt64.reduceToNat, ← UInt64.toNat_inj, Int8.reduceToInt, ← Int8.toInt_inj, Int16.reduceToInt, ← Int16.toInt_inj, Int32.reduceToInt, ← Int32.toInt_inj, Int64.reduceToInt, ← Int64.toInt_inj] at *
  try set_option linter.unusedSimpArgs false in simp only [UInt8.toNat, UInt16.toNat, UInt32.toNat, UInt64.toNat, Int8.toInt, Int16.toInt, Int32.toInt, Int64.toInt, BitVec.toInt_eq_toNat_cond] at *
  all_goals (repeat' split)
  all_goals omega

public theorem event_work_is_compositional (first : List (SemanticEvent)) (second : List (SemanticEvent)) : (workOf (appendEvents (first) (second)) = (workOf (first) + workOf (second))) := by
  induction first with
  | nil =>
    intros
    subst_vars
    try set_option linter.unusedSimpArgs false in simp only [appendEvents, workOf, ← Bool.not_eq_true, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', and_true, true_and, Option.some.injEq, Nat.beq_eq, Nat.blt_eq, Nat.ble_eq, LexLeanRuntime.subtract, LexLeanRuntime.multiply, LexLeanRuntime.negate, LexLeanRuntime.equal, beq_iff_eq, decide_eq_true_eq, decide_eq_false_iff_not, Nat.add_assoc, Int.add_assoc, Int.neg_neg, Int.emod_neg, Int.neg_zero, ↓reduceIte, LexLeanLaws.lessThan_nat, LexLeanLaws.lessThan_int, LexLeanLaws.lessThan_int8, LexLeanLaws.lessThan_int16, LexLeanLaws.lessThan_int32, LexLeanLaws.lessThan_int64, LexLeanLaws.lessThan_uint8, LexLeanLaws.lessThan_uint16, LexLeanLaws.lessThan_uint32, LexLeanLaws.lessThan_uint64, LexLeanLaws.quotient_nat, LexLeanLaws.quotient_int, LexLeanLaws.remainder_nat, LexLeanLaws.remainder_int, LexLeanLaws.tdiv_ediv, LexLeanLaws.tmod_emod, LexLeanLaws.length_list, LexLeanLaws.append_list, LexLeanLaws.setFold_listFold, LexLeanLaws.mapFold_listFold, LexLeanLaws.setSize_length, LexLeanLaws.mapSize_length, LexLeanLaws.setElements_self, LexLeanLaws.mapEntries_self, LexLeanLaws.listFold_nil, LexLeanLaws.listFold_append, LexLeanLaws.listFold_prepend, LexLeanLaws.listFold_extend, LexLeanLaws.listFold_add_nat, LexLeanLaws.listFold_add_nat_self, LexLeanLaws.listFold_add_int, LexLeanLaws.listFold_add_int_self, LexLeanLaws.listFold_sub_int, LexLeanLaws.listFold_sub_int_self, LexLeanLaws.sumNat_nil, LexLeanLaws.sumNat_cons, LexLeanLaws.sumInt_nil, LexLeanLaws.sumInt_cons, LexLeanLaws.sumNat_add, LexLeanLaws.sumInt_add, LexLeanLaws.sumInt_sub, LexLeanLaws.sumInt_neg, LexLeanLaws.sumInt_neg_self, LexLeanLaws.sumNat_mul, LexLeanLaws.sumInt_mul, LexLeanLaws.sumNat_mul_self, LexLeanLaws.sumInt_mul_self, LexLeanLaws.sumNat_mul_right, LexLeanLaws.sumInt_mul_right, LexLeanLaws.sumNat_const, LexLeanLaws.sumInt_const, LexLeanLaws.sumNat_append, LexLeanLaws.sumInt_append, LexLeanLaws.sumNat_reverse, LexLeanLaws.sumInt_reverse, UInt8.le_iff_toNat_le, UInt8.lt_iff_toNat_lt, UInt16.le_iff_toNat_le, UInt16.lt_iff_toNat_lt, UInt32.le_iff_toNat_le, UInt32.lt_iff_toNat_lt, UInt64.le_iff_toNat_le, UInt64.lt_iff_toNat_lt, Int8.le_iff_toInt_le, Int8.lt_iff_toInt_lt, Int16.le_iff_toInt_le, Int16.lt_iff_toInt_lt, Int32.le_iff_toInt_le, Int32.lt_iff_toInt_lt, Int64.le_iff_toInt_le, Int64.lt_iff_toInt_lt, UInt8.reduceToNat, ← UInt8.toNat_inj, UInt16.reduceToNat, ← UInt16.toNat_inj, UInt32.reduceToNat, ← UInt32.toNat_inj, UInt64.reduceToNat, ← UInt64.toNat_inj, Int8.reduceToInt, ← Int8.toInt_inj, Int16.reduceToInt, ← Int16.toInt_inj, Int32.reduceToInt, ← Int32.toInt_inj, Int64.reduceToInt, ← Int64.toInt_inj] at *
    try set_option linter.unusedSimpArgs false in simp only [UInt8.toNat, UInt16.toNat, UInt32.toNat, UInt64.toNat, Int8.toInt, Int16.toInt, Int32.toInt, Int64.toInt, BitVec.toInt_eq_toNat_cond] at *
    all_goals (repeat' split)
    all_goals omega
  | cons event rest ih =>
    simp only [appendEvents, ih, workOf, work_sum_associativity]

@[expose] public def referenceValueUnits (value : Uorc.Uorc.Core.ReferenceSemantics.Value) : Nat := (match value with | Uorc.Uorc.Core.ReferenceSemantics.Value.natural _ => 8 | Uorc.Uorc.Core.ReferenceSemantics.Value.byte _ => 1 | Uorc.Uorc.Core.ReferenceSemantics.Value.predicate _ => 1 | Uorc.Uorc.Core.ReferenceSemantics.Value.sequence payload => (payload).length | Uorc.Uorc.Core.ReferenceSemantics.Value.store payload => (1 + (LexLeanRuntime.multiply (9) ((LexLeanRuntime.length ((payload).exceptions) : Nat)) : Nat)))

end Uorc.Uorc.Core.CanonicalCost
