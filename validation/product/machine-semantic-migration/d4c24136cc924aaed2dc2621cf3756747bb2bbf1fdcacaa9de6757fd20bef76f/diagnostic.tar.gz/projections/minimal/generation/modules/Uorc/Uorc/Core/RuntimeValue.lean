module
public import Init
public import LexLeanRuntime.Portable
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeValue

public structure Handle where
  id : UInt64

public inductive RuntimeType where
  | natural
  | byte
  | predicate
  | sequence
  | store

public inductive RootRole where
  | frame
  | continuation
  | basis
  | output
  | checkpoint
  | input
  | archive
  | checkedGraph
  | typeCache
  | bodyCache
  | lifetimeCache
  | admission
  | search
  | certificate
  | verification
  | wire

public inductive RuntimeValue where
  | natural (_ : UInt64)
  | byte (_ : UInt8)
  | predicate (_ : Bool)
  | sequence (_ : Handle)
  | store (_ : UInt8) (_ : Handle)

@[expose] public def nullHandle : Handle := ({ id := (0 : UInt64) } : Handle)

@[expose] public def isNull (handle : Handle) : Bool := (LexLeanRuntime.equal ((handle).id) ((0 : UInt64)) : Bool)

@[expose] public def sameHandle (left : Handle) (right : Handle) : Bool := (LexLeanRuntime.equal ((left).id) ((right).id) : Bool)

@[expose] public def typeOf (value : RuntimeValue) : RuntimeType := (match value with | RuntimeValue.natural _ => RuntimeType.natural | RuntimeValue.byte _ => RuntimeType.byte | RuntimeValue.predicate _ => RuntimeType.predicate | RuntimeValue.sequence _ => RuntimeType.sequence | RuntimeValue.store _ _ => RuntimeType.store)

@[expose] public def valueHandle (value : RuntimeValue) : Handle := (match value with | RuntimeValue.natural _ => nullHandle | RuntimeValue.byte _ => nullHandle | RuntimeValue.predicate _ => nullHandle | RuntimeValue.sequence h => h | RuntimeValue.store _ h => h)

@[expose] public def roleTag (role : RootRole) : UInt64 := (match role with | RootRole.frame => (0 : UInt64) | RootRole.continuation => (1 : UInt64) | RootRole.basis => (2 : UInt64) | RootRole.output => (3 : UInt64) | RootRole.checkpoint => (4 : UInt64) | RootRole.input => (5 : UInt64) | RootRole.archive => (6 : UInt64) | RootRole.checkedGraph => (7 : UInt64) | RootRole.typeCache => (8 : UInt64) | RootRole.bodyCache => (9 : UInt64) | RootRole.lifetimeCache => (10 : UInt64) | RootRole.admission => (11 : UInt64) | RootRole.search => (12 : UInt64) | RootRole.certificate => (13 : UInt64) | RootRole.verification => (14 : UInt64) | RootRole.wire => (15 : UInt64))

end Uorc.Uorc.Core.RuntimeValue
