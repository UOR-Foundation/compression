module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeValue
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeMetadata

public inductive Kind where
  | blockIndex
  | blockRecord
  | instructionIndex
  | instructionRecord
  | lifetimeIndex
  | releaseBucket
  | searchOwner
  | wireOwner

public inductive Field where
  | word (_ : UInt64)
  | link (_ : Uorc.Uorc.Core.RuntimeValue.Handle)

public inductive Error where
  | heap (_ : Uorc.Uorc.Core.Heap.HeapError)
  | invalidKind
  | invalidRecord
  | invalidField
  | missingField
  | wrongFieldType
  | addressSpaceExhausted

@[expose] public def schemaVersion : UInt64 := (1 : UInt64)

@[expose] public def kindCode (metadataKind : Kind) : UInt64 := (match metadataKind with | Kind.blockIndex => (0 : UInt64) | Kind.blockRecord => (1 : UInt64) | Kind.instructionIndex => (2 : UInt64) | Kind.instructionRecord => (3 : UInt64) | Kind.lifetimeIndex => (4 : UInt64) | Kind.releaseBucket => (5 : UInt64) | Kind.searchOwner => (6 : UInt64) | Kind.wireOwner => (7 : UInt64))

@[expose] public def branchChildren (arena : Uorc.Uorc.Core.Heap.Arena) (root : Uorc.Uorc.Core.RuntimeValue.Handle) (kind : UInt64) : Except (Error) (Uorc.Uorc.Core.Heap.Children) := (if Uorc.Uorc.Core.RuntimeValue.isNull (root) then Except.ok (({ first := Uorc.Uorc.Core.RuntimeValue.nullHandle, second := Uorc.Uorc.Core.RuntimeValue.nullHandle } : Uorc.Uorc.Core.Heap.Children)) else (match Uorc.Uorc.Core.Heap.lookup (arena) (root) with | Except.error heapFailure => Except.error (Error.heap (heapFailure)) | Except.ok entry => (match (entry).node with | Uorc.Uorc.Core.Heap.Node.image _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.metadataBranch nodeKind leftChild rightChild => (if (LexLeanRuntime.equal (nodeKind) (kind) : Bool) then Except.ok (({ first := leftChild, second := rightChild } : Uorc.Uorc.Core.Heap.Children)) else Except.error (Error.invalidKind)) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Except.error (Error.invalidRecord))))

@[expose] public def addDelta (firstDelta : Uorc.Uorc.Core.Heap.Delta) (secondDelta : Uorc.Uorc.Core.Heap.Delta) : Except (Error) (Uorc.Uorc.Core.Heap.Delta) := (match (LexLeanRuntime.checkedAdd ((firstDelta).allocatedBytes) ((secondDelta).allocatedBytes) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_allocatedBytes => (match (LexLeanRuntime.checkedAdd ((firstDelta).releasedBytes) ((secondDelta).releasedBytes) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_releasedBytes => (match (LexLeanRuntime.checkedAdd ((firstDelta).allocatedEntries) ((secondDelta).allocatedEntries) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_allocatedEntries => (match (LexLeanRuntime.checkedAdd ((firstDelta).releasedEntries) ((secondDelta).releasedEntries) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_releasedEntries => (match (LexLeanRuntime.checkedAdd ((firstDelta).retainedEdges) ((secondDelta).retainedEdges) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_retainedEdges => (match (LexLeanRuntime.checkedAdd ((firstDelta).droppedEdges) ((secondDelta).droppedEdges) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_droppedEdges => (match (LexLeanRuntime.checkedAdd ((firstDelta).retainedRoots) ((secondDelta).retainedRoots) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_retainedRoots => (match (LexLeanRuntime.checkedAdd ((firstDelta).droppedRoots) ((secondDelta).droppedRoots) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_droppedRoots => (match (LexLeanRuntime.checkedAdd ((firstDelta).work) ((secondDelta).work) : Option (UInt64)) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some sum_work => Except.ok (({ allocatedBytes := sum_allocatedBytes, releasedBytes := sum_releasedBytes, allocatedEntries := sum_allocatedEntries, releasedEntries := sum_releasedEntries, retainedEdges := sum_retainedEdges, droppedEdges := sum_droppedEdges, retainedRoots := sum_retainedRoots, droppedRoots := sum_droppedRoots, work := sum_work } : Uorc.Uorc.Core.Heap.Delta)))))))))))

@[expose] public def writePath : (depth : Nat) -> (mask : UInt64) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> (root : Uorc.Uorc.Core.RuntimeValue.Handle) -> (kind : UInt64) -> (key : UInt64) -> (field : Field) -> Except (Error) (Uorc.Uorc.Core.Heap.Allocation)
  | Nat.zero, _mask, arena, _root, kind, key, field => (match Uorc.Uorc.Core.Heap.allocate (arena) ((match field with | Field.word wordValue => Uorc.Uorc.Core.Heap.Node.metadataWord (kind) (key) (wordValue) | Field.link target => Uorc.Uorc.Core.Heap.Node.metadataLink (kind) (key) (target))) with | Except.error heapFailure => Except.error (Error.heap (heapFailure)) | Except.ok allocation => Except.ok (allocation))
  | Nat.succ remainingDepth, mask, arena, root, kind, key, field => (match branchChildren (arena) (root) (kind) with | Except.error branchError => Except.error (branchError) | Except.ok children => (match writePath (remainingDepth) (Uorc.Uorc.Core.Heap.nextKey (mask)) (arena) ((if (!(LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (key) (mask) : UInt64)) ((0 : UInt64)) : Bool)) then (children).second else (children).first)) (kind) (key) (field) with | Except.error pathError => Except.error (pathError) | Except.ok subtree => (match Uorc.Uorc.Core.Heap.allocateMoved ((subtree).arena) (Uorc.Uorc.Core.Heap.Node.metadataBranch (kind) ((if (!(LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (key) (mask) : UInt64)) ((0 : UInt64)) : Bool)) then (children).first else (subtree).handle)) ((if (!(LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (key) (mask) : UInt64)) ((0 : UInt64)) : Bool)) then (subtree).handle else (children).second))) ((!(!(LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (key) (mask) : UInt64)) ((0 : UInt64)) : Bool)))) ((!(LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (key) (mask) : UInt64)) ((0 : UInt64)) : Bool))) with | Except.error parentError => Except.error (Error.heap (parentError)) | Except.ok parent => (match addDelta ((subtree).delta) ((parent).delta) with | Except.error sumError => Except.error (sumError) | Except.ok combinedDelta => Except.ok (({ arena := (parent).arena, handle := (parent).handle, delta := combinedDelta } : Uorc.Uorc.Core.Heap.Allocation))))))

@[expose] public def put (arena : Uorc.Uorc.Core.Heap.Arena) (root : Uorc.Uorc.Core.RuntimeValue.Handle) (kind : UInt64) (key : UInt64) (field : Field) : Except (Error) (Uorc.Uorc.Core.Heap.Allocation) := (if Uorc.Uorc.Core.Heap.less (key) ((16 : UInt64)) then writePath (4) ((8 : UInt64)) (arena) (root) (kind) (key) (field) else Except.error (Error.invalidField))

@[expose] public def readPath : (depth : Nat) -> (mask : UInt64) -> (arena : Uorc.Uorc.Core.Heap.Arena) -> (root : Uorc.Uorc.Core.RuntimeValue.Handle) -> (kind : UInt64) -> (key : UInt64) -> Except (Error) (Field)
  | Nat.zero, _mask, arena, root, kind, key => (if Uorc.Uorc.Core.RuntimeValue.isNull (root) then Except.error (Error.missingField) else (match Uorc.Uorc.Core.Heap.lookup (arena) (root) with | Except.error heapFailure => Except.error (Error.heap (heapFailure)) | Except.ok entry => (match (entry).node with | Uorc.Uorc.Core.Heap.Node.image _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.metadataWord nodeKind nodeTag nodeWord => (if ((LexLeanRuntime.equal (nodeKind) (kind) : Bool) && (LexLeanRuntime.equal (nodeTag) (key) : Bool)) then Except.ok (Field.word (nodeWord)) else Except.error (Error.invalidKind)) | Uorc.Uorc.Core.Heap.Node.metadataLink nodeKind nodeTag nodeTarget => (if ((LexLeanRuntime.equal (nodeKind) (kind) : Bool) && (LexLeanRuntime.equal (nodeTag) (key) : Bool)) then Except.ok (Field.link (nodeTarget)) else Except.error (Error.invalidKind)) | Uorc.Uorc.Core.Heap.Node.metadataBranch _ _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Except.error (Error.invalidRecord) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Except.error (Error.invalidRecord))))
  | Nat.succ remainingDepth, mask, arena, root, kind, key => (match branchChildren (arena) (root) (kind) with | Except.error branchError => Except.error (branchError) | Except.ok children => readPath (remainingDepth) (Uorc.Uorc.Core.Heap.nextKey (mask)) (arena) ((if (!(LexLeanRuntime.equal ((LexLeanRuntime.bitAnd (key) (mask) : UInt64)) ((0 : UInt64)) : Bool)) then (children).second else (children).first)) (kind) (key))

@[expose] public def «at» (arena : Uorc.Uorc.Core.Heap.Arena) (root : Uorc.Uorc.Core.RuntimeValue.Handle) (kind : UInt64) (key : UInt64) : Except (Error) (Field) := (if Uorc.Uorc.Core.Heap.less (key) ((16 : UInt64)) then readPath (4) ((8 : UInt64)) (arena) (root) (kind) (key) else Except.error (Error.invalidField))

@[expose] public def wordAt (arena : Uorc.Uorc.Core.Heap.Arena) (root : Uorc.Uorc.Core.RuntimeValue.Handle) (kind : UInt64) (key : UInt64) : Except (Error) (UInt64) := (match «at» (arena) (root) (kind) (key) with | Except.error readError => Except.error (readError) | Except.ok foundField => (match foundField with | Field.word foundWord => Except.ok (foundWord) | Field.link _ => Except.error (Error.wrongFieldType)))

@[expose] public def linkAt (arena : Uorc.Uorc.Core.Heap.Arena) (root : Uorc.Uorc.Core.RuntimeValue.Handle) (kind : UInt64) (key : UInt64) : Except (Error) (Uorc.Uorc.Core.RuntimeValue.Handle) := (match «at» (arena) (root) (kind) (key) with | Except.error readError => Except.error (readError) | Except.ok foundField => (match foundField with | Field.word _ => Except.error (Error.wrongFieldType) | Field.link foundTarget => Except.ok (foundTarget)))

public structure WriteFrame where
  left : Uorc.Uorc.Core.RuntimeValue.Handle
  right : Uorc.Uorc.Core.RuntimeValue.Handle
  takeRight : Bool

public inductive WriteTask where
  | down (_ : Nat) (_ : UInt64) (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : List (WriteFrame))
  | up (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : List (WriteFrame))

public structure WriteCursor where
  oldRoot : Uorc.Uorc.Core.RuntimeValue.Handle
  kind : UInt64
  key : UInt64
  field : Field
  task : WriteTask

public inductive WriteEvent where
  | advanced (_ : Uorc.Uorc.Core.Heap.Arena) (_ : WriteCursor) (_ : Uorc.Uorc.Core.Heap.Delta)
  | done (_ : Uorc.Uorc.Core.Heap.Arena) (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : Uorc.Uorc.Core.Heap.Delta)
  | failed (_ : Error) (_ : Uorc.Uorc.Core.Heap.Arena) (_ : WriteCursor)

@[expose] public def zeroDelta : Uorc.Uorc.Core.Heap.Delta := ({ allocatedBytes := (0 : UInt64), releasedBytes := (0 : UInt64), allocatedEntries := (0 : UInt64), releasedEntries := (0 : UInt64), retainedEdges := (0 : UInt64), droppedEdges := (0 : UInt64), retainedRoots := (0 : UInt64), droppedRoots := (0 : UInt64), work := (0 : UInt64) } : Uorc.Uorc.Core.Heap.Delta)

@[expose] public def startWrite (oldRoot : Uorc.Uorc.Core.RuntimeValue.Handle) (kind : UInt64) (key : UInt64) (field : Field) : Except (Error) (WriteCursor) := (if Uorc.Uorc.Core.Heap.less (key) ((16 : UInt64)) then Except.ok (({ oldRoot := oldRoot, kind := kind, key := key, field := field, task := WriteTask.down (4) ((8 : UInt64)) (oldRoot) (([] : List (WriteFrame))) } : WriteCursor)) else Except.error (Error.invalidField))

@[expose] public def writeStep (arena : Uorc.Uorc.Core.Heap.Arena) (cursor : WriteCursor) : WriteEvent := (match (cursor).task with | WriteTask.down depth mask currentRoot path => (match depth with | Nat.zero => (match Uorc.Uorc.Core.Heap.allocate (arena) ((match (cursor).field with | Field.word wordValue => Uorc.Uorc.Core.Heap.Node.metadataWord ((cursor).kind) ((cursor).key) (wordValue) | Field.link target => Uorc.Uorc.Core.Heap.Node.metadataLink ((cursor).kind) ((cursor).key) (target))) with | Except.error heapError => WriteEvent.failed (Error.heap (heapError)) (arena) (cursor) | Except.ok allocation => WriteEvent.advanced ((allocation).arena) (({ oldRoot := (cursor).oldRoot, kind := (cursor).kind, key := (cursor).key, field := (cursor).field, task := WriteTask.up ((allocation).handle) (path) } : WriteCursor)) ((allocation).delta)) | Nat.succ remainingDepth => (match branchChildren (arena) (currentRoot) ((cursor).kind) with | Except.error branchError => WriteEvent.failed (branchError) (arena) (cursor) | Except.ok children => WriteEvent.advanced (arena) (({ oldRoot := (cursor).oldRoot, kind := (cursor).kind, key := (cursor).key, field := (cursor).field, task := WriteTask.down (remainingDepth) (Uorc.Uorc.Core.Heap.nextKey (mask)) ((if (!(LexLeanRuntime.equal ((LexLeanRuntime.bitAnd ((cursor).key) (mask) : UInt64)) ((0 : UInt64)) : Bool)) then (children).second else (children).first)) ((({ left := (children).first, right := (children).second, takeRight := (!(LexLeanRuntime.equal ((LexLeanRuntime.bitAnd ((cursor).key) (mask) : UInt64)) ((0 : UInt64)) : Bool)) } : WriteFrame) :: path)) } : WriteCursor)) (zeroDelta))) | WriteTask.up subtree path => (match path with | List.nil => WriteEvent.done (arena) (subtree) (zeroDelta) | List.cons parentFrame remainingPath => (match Uorc.Uorc.Core.Heap.allocateMoved (arena) (Uorc.Uorc.Core.Heap.Node.metadataBranch ((cursor).kind) ((if (parentFrame).takeRight then (parentFrame).left else subtree)) ((if (parentFrame).takeRight then subtree else (parentFrame).right))) ((!(parentFrame).takeRight)) ((parentFrame).takeRight) with | Except.error heapError => WriteEvent.failed (Error.heap (heapError)) (arena) (cursor) | Except.ok allocation => WriteEvent.advanced ((allocation).arena) (({ oldRoot := (cursor).oldRoot, kind := (cursor).kind, key := (cursor).key, field := (cursor).field, task := WriteTask.up ((allocation).handle) (remainingPath) } : WriteCursor)) ((allocation).delta))))

@[expose] public def temporaryRoots (cursor : WriteCursor) : List (Uorc.Uorc.Core.RuntimeValue.Handle) := (match (cursor).task with | WriteTask.down _ _ _ _ => ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) | WriteTask.up subtree _ => (if Uorc.Uorc.Core.RuntimeValue.isNull (subtree) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else (subtree :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))))

end Uorc.Uorc.Core.RuntimeMetadata
