module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeMetadata
public import Uorc.Uorc.Core.RuntimeValue
public import Uorc.Uorc.Core.RuntimeWork
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeOwnerRoots

public inductive Role where
  | search
  | wire

public inductive Error where
  | heap (_ : Uorc.Uorc.Core.Heap.HeapError)
  | wrongOwnerKind
  | invalidCursor

public structure SplitCursor where
  arena : Uorc.Uorc.Core.Heap.Arena
  phase : UInt64
  joined : Uorc.Uorc.Core.RuntimeValue.Handle
  left : Uorc.Uorc.Core.RuntimeValue.Handle
  right : Uorc.Uorc.Core.RuntimeValue.Handle
  leftOwned : Bool
  rightOwned : Bool
  joinedOwned : Bool

public inductive SplitEvent where
  | advanced (_ : SplitCursor) (_ : Uorc.Uorc.Core.Heap.Delta)
  | done (_ : Uorc.Uorc.Core.Heap.Arena) (_ : Uorc.Uorc.Core.RuntimeValue.Handle) (_ : Uorc.Uorc.Core.RuntimeValue.Handle)
  | failed (_ : Error) (_ : SplitCursor)

@[expose] public def controlBytes : UInt64 := (4096 : UInt64)

@[expose] public def controlWork : UInt64 := Uorc.Uorc.Core.RuntimeWork.fee (Uorc.Uorc.Core.RuntimeWork.Operation.controlAllocate)

@[expose] public def joinWork : UInt64 := Uorc.Uorc.Core.RuntimeWork.fee (Uorc.Uorc.Core.RuntimeWork.Operation.ownerJoin)

@[expose] public def startSplitWork : UInt64 := Uorc.Uorc.Core.RuntimeWork.fee (Uorc.Uorc.Core.RuntimeWork.Operation.ownerSplitStart)

@[expose] public def splitStepWork : UInt64 := Uorc.Uorc.Core.RuntimeWork.fee (Uorc.Uorc.Core.RuntimeWork.Operation.ownerSplitStep)

@[expose] public def kindCode (role : Role) : UInt64 := (match role with | Role.search => Uorc.Uorc.Core.RuntimeMetadata.kindCode (Uorc.Uorc.Core.RuntimeMetadata.Kind.searchOwner) | Role.wire => Uorc.Uorc.Core.RuntimeMetadata.kindCode (Uorc.Uorc.Core.RuntimeMetadata.Kind.wireOwner))

@[expose] public def beginControl (arena : Uorc.Uorc.Core.Heap.Arena) : Except (Uorc.Uorc.Core.Heap.HeapError) (Uorc.Uorc.Core.Heap.Allocation) := Uorc.Uorc.Core.Heap.allocateControl (arena) (controlBytes)

@[expose] public def joinOwned (arena : Uorc.Uorc.Core.Heap.Arena) (role : Role) (left : Uorc.Uorc.Core.RuntimeValue.Handle) (right : Uorc.Uorc.Core.RuntimeValue.Handle) : Except (Uorc.Uorc.Core.Heap.HeapError) (Uorc.Uorc.Core.Heap.Allocation) := Uorc.Uorc.Core.Heap.allocateMoved (arena) (Uorc.Uorc.Core.Heap.Node.metadataBranch (kindCode (role)) (left) (right)) (true) (true)

@[expose] public def pinBorrowed (arena : Uorc.Uorc.Core.Heap.Arena) (role : Role) (left : Uorc.Uorc.Core.RuntimeValue.Handle) (right : Uorc.Uorc.Core.RuntimeValue.Handle) : Except (Uorc.Uorc.Core.Heap.HeapError) (Uorc.Uorc.Core.Heap.Allocation) := Uorc.Uorc.Core.Heap.allocateMoved (arena) (Uorc.Uorc.Core.Heap.Node.metadataBranch (kindCode (role)) (left) (right)) (true) (false)

@[expose] public def startSplit (arena : Uorc.Uorc.Core.Heap.Arena) (role : Role) (joined : Uorc.Uorc.Core.RuntimeValue.Handle) : Except (Error) (SplitCursor) := (if Uorc.Uorc.Core.Heap.isReleasing (arena) then Except.error (Error.heap (Uorc.Uorc.Core.Heap.HeapError.releaseInProgress)) else (match Uorc.Uorc.Core.Heap.checkMoveRoot (arena) (joined) ((1 : UInt64)) with | Except.error heapFailure => Except.error (Error.heap (heapFailure)) | Except.ok _ => (match Uorc.Uorc.Core.Heap.lookup (arena) (joined) with | Except.error lookupFailure => Except.error (Error.heap (lookupFailure)) | Except.ok entry => (match (entry).node with | Uorc.Uorc.Core.Heap.Node.image _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.sequenceLeaf _ _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.sequenceBranch _ _ _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.storeLeaf _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.storeBranch _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.slot _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.rootBranch _ _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.metadataWord _ _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.metadataLink _ _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.metadataBranch field0 field1 field2 => (if (LexLeanRuntime.equal (field0) (kindCode (role)) : Bool) then Except.ok (({ arena := arena, phase := (0 : UInt64), joined := joined, left := field1, right := field2, leftOwned := false, rightOwned := false, joinedOwned := true } : SplitCursor)) else Except.error (Error.wrongOwnerKind)) | Uorc.Uorc.Core.Heap.Node.ownerRoot _ _ => Except.error (Error.wrongOwnerKind) | Uorc.Uorc.Core.Heap.Node.imageReservation _ _ => Except.error (Error.wrongOwnerKind)))))

@[expose] public def splitStep (cursor : SplitCursor) : SplitEvent := (if (LexLeanRuntime.equal ((cursor).phase) ((0 : UInt64)) : Bool) then (match Uorc.Uorc.Core.Heap.retain ((cursor).arena) ((cursor).left) with | Except.error heapFailure => SplitEvent.failed (Error.heap (heapFailure)) (cursor) | Except.ok transition => SplitEvent.advanced (({ arena := (transition).arena, phase := (1 : UInt64), joined := (cursor).joined, left := (cursor).left, right := (cursor).right, leftOwned := true, rightOwned := (cursor).rightOwned, joinedOwned := (cursor).joinedOwned } : SplitCursor)) ((transition).delta)) else (if (LexLeanRuntime.equal ((cursor).phase) ((1 : UInt64)) : Bool) then (match Uorc.Uorc.Core.Heap.retain ((cursor).arena) ((cursor).right) with | Except.error heapFailure => SplitEvent.failed (Error.heap (heapFailure)) (cursor) | Except.ok transition => SplitEvent.advanced (({ arena := (transition).arena, phase := (2 : UInt64), joined := (cursor).joined, left := (cursor).left, right := (cursor).right, leftOwned := (cursor).leftOwned, rightOwned := true, joinedOwned := (cursor).joinedOwned } : SplitCursor)) ((transition).delta)) else (if (LexLeanRuntime.equal ((cursor).phase) ((2 : UInt64)) : Bool) then (match Uorc.Uorc.Core.Heap.release ((cursor).arena) ((cursor).joined) with | Except.error heapFailure => SplitEvent.failed (Error.heap (heapFailure)) (cursor) | Except.ok transition => SplitEvent.advanced (({ arena := (transition).arena, phase := (if (transition).complete then (4 : UInt64) else (3 : UInt64)), joined := (cursor).joined, left := (cursor).left, right := (cursor).right, leftOwned := (cursor).leftOwned, rightOwned := (cursor).rightOwned, joinedOwned := false } : SplitCursor)) ((transition).delta)) else (if (LexLeanRuntime.equal ((cursor).phase) ((3 : UInt64)) : Bool) then (match Uorc.Uorc.Core.Heap.releaseStep ((cursor).arena) with | Except.error heapFailure => SplitEvent.failed (Error.heap (heapFailure)) (cursor) | Except.ok transition => SplitEvent.advanced (({ arena := (transition).arena, phase := (if (transition).complete then (4 : UInt64) else (3 : UInt64)), joined := (cursor).joined, left := (cursor).left, right := (cursor).right, leftOwned := (cursor).leftOwned, rightOwned := (cursor).rightOwned, joinedOwned := (cursor).joinedOwned } : SplitCursor)) ((transition).delta)) else (if (LexLeanRuntime.equal ((cursor).phase) ((4 : UInt64)) : Bool) then SplitEvent.done ((cursor).arena) ((cursor).left) ((cursor).right) else SplitEvent.failed (Error.invalidCursor) (cursor))))))

@[expose] public def splitRootInventory (cursor : SplitCursor) : List (Uorc.Uorc.Core.RuntimeValue.Handle) := (if (cursor).rightOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).right) then (if (cursor).leftOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).left) then (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))) else ((cursor).left :: (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))))) else (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ((cursor).right :: (if (cursor).leftOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).left) then (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))) else ((cursor).left :: (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))))) else (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))))) else (if (cursor).leftOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).left) then (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))) else ((cursor).left :: (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle))))) else (if (cursor).joinedOwned then (if Uorc.Uorc.Core.RuntimeValue.isNull ((cursor).joined) then ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)) else ((cursor).joined :: ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) else ([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))))

end Uorc.Uorc.Core.RuntimeOwnerRoots
