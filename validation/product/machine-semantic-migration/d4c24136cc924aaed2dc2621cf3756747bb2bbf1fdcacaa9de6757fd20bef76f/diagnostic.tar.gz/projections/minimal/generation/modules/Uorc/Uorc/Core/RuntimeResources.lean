module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.Resources
public import Uorc.Uorc.Core.Types
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeResources

public structure Budget where
  maxWork : UInt64
  maxOwnedBytes : UInt64
  maxOutputBytes : UInt64
  maxFrames : UInt64

public structure Usage where
  work : UInt64
  ownedBytes : UInt64
  peakOwnedBytes : UInt64
  outputBytes : UInt64
  frames : UInt64

public structure Event where
  work : UInt64
  emittedBytes : UInt64
  enteredFrames : UInt64
  exitedFrames : UInt64

public inductive Error where
  | workLimit
  | ownedByteLimit
  | outputLimit
  | frameLimit
  | addressSpaceExhausted
  | invalidUsage
  | arenaBudgetMismatch
  | heap (_ : Uorc.Uorc.Core.Heap.HeapError)

@[expose] public def profileIdentity : String := "uorc.logical-owned-bytes/1"

@[expose] public def fitsAddition (limit : UInt64) (used : UInt64) (increase : UInt64) : Bool := (match (LexLeanRuntime.checkedSubtract (limit) (used) : Option (UInt64)) with | Option.none => false | Option.some remaining => (!Uorc.Uorc.Core.Heap.less (remaining) (increase)))

@[expose] public def zeroUsage : Usage := ({ work := (0 : UInt64), ownedBytes := (0 : UInt64), peakOwnedBytes := (0 : UInt64), outputBytes := (0 : UInt64), frames := (0 : UInt64) } : Usage)

@[expose] public def validateUsage (budget : Budget) (current : Usage) : Except (Error) (Usage) := (if fitsAddition ((budget).maxWork) ((current).work) ((0 : UInt64)) then (if Uorc.Uorc.Core.Heap.less ((current).peakOwnedBytes) ((current).ownedBytes) then Except.error (Error.invalidUsage) else (if fitsAddition ((budget).maxOwnedBytes) ((current).peakOwnedBytes) ((0 : UInt64)) then (if fitsAddition ((budget).maxOutputBytes) ((current).outputBytes) ((0 : UInt64)) then (if fitsAddition ((budget).maxFrames) ((current).frames) ((0 : UInt64)) then Except.ok (current) else Except.error (Error.frameLimit)) else Except.error (Error.outputLimit)) else Except.error (Error.ownedByteLimit))) else Except.error (Error.workLimit))

@[expose] public def charge (budget : Budget) (current : Usage) (event : Event) : Except (Error) (Usage) := (match validateUsage (budget) (current) with | Except.error usageError => Except.error (usageError) | Except.ok _ => (match (LexLeanRuntime.checkedAdd ((current).work) ((event).work) : Option (UInt64)) with | Option.none => Except.error (Error.workLimit) | Option.some newWork => (if Uorc.Uorc.Core.Heap.less ((budget).maxWork) (newWork) then Except.error (Error.workLimit) else (match (LexLeanRuntime.checkedAdd ((current).outputBytes) ((event).emittedBytes) : Option (UInt64)) with | Option.none => Except.error (Error.outputLimit) | Option.some newOutput => (if Uorc.Uorc.Core.Heap.less ((budget).maxOutputBytes) (newOutput) then Except.error (Error.outputLimit) else (match (LexLeanRuntime.checkedAdd ((current).frames) ((event).enteredFrames) : Option (UInt64)) with | Option.none => Except.error (Error.frameLimit) | Option.some transientFrames => (if Uorc.Uorc.Core.Heap.less ((budget).maxFrames) (transientFrames) then Except.error (Error.frameLimit) else (match (LexLeanRuntime.checkedSubtract (transientFrames) ((event).exitedFrames) : Option (UInt64)) with | Option.none => Except.error (Error.invalidUsage) | Option.some newFrames => Except.ok (({ work := newWork, ownedBytes := (current).ownedBytes, peakOwnedBytes := (current).peakOwnedBytes, outputBytes := newOutput, frames := newFrames } : Usage))))))))))

@[expose] public def observeArena (budget : Budget) (current : Usage) (arena : Uorc.Uorc.Core.Heap.Arena) : Except (Error) (Usage) := (match validateUsage (budget) (current) with | Except.error usageError => Except.error (usageError) | Except.ok _ => (if (LexLeanRuntime.equal ((arena).maxOwnedBytes) ((budget).maxOwnedBytes) : Bool) then (match Uorc.Uorc.Core.Heap.totalOwnedBytes (arena) with | Except.error heapError => Except.error (Error.heap (heapError)) | Except.ok owned => (if Uorc.Uorc.Core.Heap.less ((budget).maxOwnedBytes) (owned) then Except.error (Error.ownedByteLimit) else Except.ok (({ work := (current).work, ownedBytes := owned, peakOwnedBytes := (if Uorc.Uorc.Core.Heap.less ((current).peakOwnedBytes) (owned) then owned else (current).peakOwnedBytes), outputBytes := (current).outputBytes, frames := (current).frames } : Usage)))) else Except.error (Error.arenaBudgetMismatch)))

public structure CounterProjection where
  work : Nat
  ownedBytes : Nat
  peakOwnedBytes : Nat
  outputBytes : Nat
  frames : Nat

@[expose] public def toCounterProjection (current : Usage) : CounterProjection := ({ work := Uorc.Uorc.Core.Types.wordToNat ((current).work), ownedBytes := Uorc.Uorc.Core.Types.wordToNat ((current).ownedBytes), peakOwnedBytes := Uorc.Uorc.Core.Types.wordToNat ((current).peakOwnedBytes), outputBytes := Uorc.Uorc.Core.Types.wordToNat ((current).outputBytes), frames := Uorc.Uorc.Core.Types.wordToNat ((current).frames) } : CounterProjection)

@[expose] public def fromDiagnosticCounters (diagnostic : Uorc.Uorc.Core.Resources.Usage) (budget : Budget) (arena : Uorc.Uorc.Core.Heap.Arena) (previousPeakBytes : UInt64) : Except (Error) (Usage) := (match Uorc.Uorc.Core.Heap.wordOfNat ((diagnostic).steps) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some oldWork => (match Uorc.Uorc.Core.Heap.wordOfNat ((diagnostic).outputBytes) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some oldOutput => (match Uorc.Uorc.Core.Heap.wordOfNat ((diagnostic).frames) with | Option.none => Except.error (Error.addressSpaceExhausted) | Option.some oldFrames => observeArena (budget) (({ work := oldWork, ownedBytes := (0 : UInt64), peakOwnedBytes := previousPeakBytes, outputBytes := oldOutput, frames := oldFrames } : Usage)) (arena))))

end Uorc.Uorc.Core.RuntimeResources
