module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.RuntimeByteBuilder
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeWork

public inductive Operation where
  | idle
  | smallControl
  | control
  | acknowledgment
  | sequenceLength
  | sequenceBegin
  | sequenceStep
  | sequenceCancel
  | heapRetain
  | heapRelease
  | heapReleaseStep
  | heapAllocate
  | ownerPin
  | ownerJoin
  | ownerSplitStart
  | ownerSplitStep
  | controlAllocate
  | tableMutation
  | metadataMutation
  | indexedStart
  | scalarCheck
  | captureCheck
  | lifetimePlanning
  | sealCheck
  | admissionInitialization
  | admissionOffer
  | boundaryTake
  | boundaryReattach
  | boundaryReturn
  | cancelDetach
  | builderControl
  | builderBoundedStep

@[expose] public def profileIdentity : String := "uorc.operational-task-fees/1"

@[expose] public def fee (operation : Operation) : UInt64 := (match operation with | Operation.idle => (0 : UInt64) | Operation.smallControl => (1 : UInt64) | Operation.control => (64 : UInt64) | Operation.acknowledgment => (64 : UInt64) | Operation.sequenceLength => (4096 : UInt64) | Operation.sequenceBegin => (4096 : UInt64) | Operation.sequenceStep => (4096 : UInt64) | Operation.sequenceCancel => (4096 : UInt64) | Operation.heapRetain => (256 : UInt64) | Operation.heapRelease => (256 : UInt64) | Operation.heapReleaseStep => (256 : UInt64) | Operation.heapAllocate => (1024 : UInt64) | Operation.ownerPin => (1024 : UInt64) | Operation.ownerJoin => (1024 : UInt64) | Operation.ownerSplitStart => (256 : UInt64) | Operation.ownerSplitStep => (256 : UInt64) | Operation.controlAllocate => (256 : UInt64) | Operation.tableMutation => (1024 : UInt64) | Operation.metadataMutation => (1024 : UInt64) | Operation.indexedStart => (4096 : UInt64) | Operation.scalarCheck => (32768 : UInt64) | Operation.captureCheck => (16384 : UInt64) | Operation.lifetimePlanning => (16384 : UInt64) | Operation.sealCheck => (8192 : UInt64) | Operation.admissionInitialization => (1024 : UInt64) | Operation.admissionOffer => (1 : UInt64) | Operation.boundaryTake => (4096 : UInt64) | Operation.boundaryReattach => (4096 : UInt64) | Operation.boundaryReturn => (256 : UInt64) | Operation.cancelDetach => (1024 : UInt64) | Operation.builderControl => (4096 : UInt64) | Operation.builderBoundedStep => (12288 : UInt64))

@[expose] public def feeWithCopy (baseFee : UInt64) (copyBytes : UInt64) : Option (UInt64) := (match (LexLeanRuntime.checkedAdd (copyBytes) (copyBytes) : Option (UInt64)) with | Option.none => Option.none | Option.some copyFee => (LexLeanRuntime.checkedAdd (baseFee) (copyFee) : Option (UInt64)))

@[expose] public def builderCopyBound (cursor : Uorc.Uorc.Core.RuntimeByteBuilder.Cursor) : UInt64 := (if (LexLeanRuntime.equal ((cursor).phase) ((2 : UInt64)) : Bool) then (1 : UInt64) else (if (LexLeanRuntime.equal ((cursor).phase) ((4 : UInt64)) : Bool) then (cursor).length else (0 : UInt64)))

@[expose] public def builderStepFee (cursor : Uorc.Uorc.Core.RuntimeByteBuilder.Cursor) : Option (UInt64) := feeWithCopy (fee (Operation.builderControl)) (builderCopyBound (cursor))

end Uorc.Uorc.Core.RuntimeWork
