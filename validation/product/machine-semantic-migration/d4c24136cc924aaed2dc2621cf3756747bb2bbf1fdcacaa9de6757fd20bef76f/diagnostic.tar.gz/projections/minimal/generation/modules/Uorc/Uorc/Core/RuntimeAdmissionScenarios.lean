module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.HeapAudit
public import Uorc.Uorc.Core.RuntimeAdmission
public import Uorc.Uorc.Core.RuntimeAdmissionCancel
public import Uorc.Uorc.Core.RuntimeOpcode
public import Uorc.Uorc.Core.RuntimeProgram
public import Uorc.Uorc.Core.RuntimeResources
public import Uorc.Uorc.Core.RuntimeTable
public import Uorc.Uorc.Core.RuntimeValue
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.RuntimeAdmissionScenarios

public inductive ScenarioError where
  | failed
  | fuelExhausted
  | admissionRejected
  | auditFailed
  | prematureReady
  | missingSeal

@[expose] public def fixture : Uorc.Uorc.Core.RuntimeAdmission.Step := Uorc.Uorc.Core.RuntimeAdmission.start (({ maxWork := (18446744073709551615 : UInt64), maxOwnedBytes := (1000000 : UInt64), maxOutputBytes := (1000000 : UInt64), maxFrames := (1000 : UInt64) } : Uorc.Uorc.Core.RuntimeResources.Budget)) (Uorc.Uorc.Core.Heap.emptyArena ((1000000 : UInt64))) (Uorc.Uorc.Core.RuntimeTable.emptyTable (Uorc.Uorc.Core.RuntimeTable.TableKind.slots (Uorc.Uorc.Core.RuntimeValue.RootRole.basis))) (({ input := Uorc.Uorc.Core.RuntimeValue.nullHandle, archive := Uorc.Uorc.Core.RuntimeValue.nullHandle, search := Uorc.Uorc.Core.RuntimeValue.nullHandle, checkpoint := Uorc.Uorc.Core.RuntimeValue.nullHandle, certificate := Uorc.Uorc.Core.RuntimeValue.nullHandle, verification := Uorc.Uorc.Core.RuntimeValue.nullHandle, wire := Uorc.Uorc.Core.RuntimeValue.nullHandle } : Uorc.Uorc.Core.RuntimeProgram.CallerRoots)) (Uorc.Uorc.Core.RuntimeResources.zeroUsage)

@[expose] public def drive : (fuel : Nat) -> (cursor : Uorc.Uorc.Core.RuntimeAdmission.Cursor) -> Uorc.Uorc.Core.RuntimeAdmission.Step
  | Nat.zero, cursor => Uorc.Uorc.Core.RuntimeAdmission.Step.pending (cursor)
  | Nat.succ rest, cursor => (match Uorc.Uorc.Core.RuntimeAdmission.step (cursor) with | Uorc.Uorc.Core.RuntimeAdmission.Step.pending next => drive (rest) (next) | Uorc.Uorc.Core.RuntimeAdmission.Step.awaiting next => Uorc.Uorc.Core.RuntimeAdmission.Step.awaiting (next) | Uorc.Uorc.Core.RuntimeAdmission.Step.ready ready => Uorc.Uorc.Core.RuntimeAdmission.Step.ready (ready) | Uorc.Uorc.Core.RuntimeAdmission.Step.failed failure next => Uorc.Uorc.Core.RuntimeAdmission.Step.failed (failure) (next))

@[expose] public def feed : (events : List (Uorc.Uorc.Core.RuntimeProgram.Event)) -> (cursor : Uorc.Uorc.Core.RuntimeAdmission.Cursor) -> Except (ScenarioError) (Uorc.Uorc.Core.RuntimeProgram.Ready)
  | List.nil, _cursor => Except.error (ScenarioError.missingSeal)
  | List.cons event rest, cursor => (match Uorc.Uorc.Core.RuntimeAdmission.offer (cursor) (event) with | Except.error _ => Except.error (ScenarioError.admissionRejected) | Except.ok offered => (match drive (2000) (offered) with | Uorc.Uorc.Core.RuntimeAdmission.Step.pending _ => Except.error (ScenarioError.fuelExhausted) | Uorc.Uorc.Core.RuntimeAdmission.Step.awaiting next => (if Uorc.Uorc.Core.HeapAudit.auditRoots ((next).arena) (Uorc.Uorc.Core.RuntimeAdmission.rootInventory (next)) then feed (rest) (next) else Except.error (ScenarioError.auditFailed)) | Uorc.Uorc.Core.RuntimeAdmission.Step.ready ready => (match rest with | List.nil => Except.ok (ready) | List.cons _ _ => Except.error (ScenarioError.prematureReady)) | Uorc.Uorc.Core.RuntimeAdmission.Step.failed _ _ => Except.error (ScenarioError.admissionRejected)))

@[expose] public def emptyLiteralReady : Except (ScenarioError) (Uorc.Uorc.Core.RuntimeProgram.Ready) := (match fixture with | Uorc.Uorc.Core.RuntimeAdmission.Step.pending _ => Except.error (ScenarioError.fuelExhausted) | Uorc.Uorc.Core.RuntimeAdmission.Step.awaiting next => feed ((Uorc.Uorc.Core.RuntimeProgram.Event.beginBlock ((0 : UInt64)) :: (Uorc.Uorc.Core.RuntimeProgram.Event.beginBody (Uorc.Uorc.Core.RuntimeValue.RuntimeType.sequence) ((1 : UInt64)) :: (Uorc.Uorc.Core.RuntimeProgram.Event.beginInstruction (Uorc.Uorc.Core.RuntimeOpcode.Opcode.sequenceConstant) :: (Uorc.Uorc.Core.RuntimeProgram.Event.beginLiteral ((0 : UInt64)) :: (Uorc.Uorc.Core.RuntimeProgram.Event.endInstruction :: (Uorc.Uorc.Core.RuntimeProgram.Event.endBlock ((1 : UInt64)) :: (Uorc.Uorc.Core.RuntimeProgram.Event.«seal» ((0 : UInt64)) :: ([] : List (Uorc.Uorc.Core.RuntimeProgram.Event)))))))))) (next) | Uorc.Uorc.Core.RuntimeAdmission.Step.ready _ => Except.error (ScenarioError.prematureReady) | Uorc.Uorc.Core.RuntimeAdmission.Step.failed _ _ => Except.error (ScenarioError.admissionRejected))

@[expose] public def run : Except (ScenarioError) (Unit) := (match emptyLiteralReady with | Except.error scenarioFailure => Except.error (scenarioFailure) | Except.ok ready => (if (Uorc.Uorc.Core.HeapAudit.auditRoots ((ready).arena) (Uorc.Uorc.Core.RuntimeProgram.rootInventory ((ready).program) ((ready).caller)) && (LexLeanRuntime.equal (((ready).usage).ownedBytes) (((ready).arena).ownedBytes) : Bool)) then Except.ok (()) else Except.error (ScenarioError.failed)))

@[expose] public def cancelDrive : (fuel : Nat) -> (cursor : Uorc.Uorc.Core.RuntimeAdmissionCancel.Cursor) -> Uorc.Uorc.Core.RuntimeAdmissionCancel.Event
  | Nat.zero, cursor => Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.pending (cursor)
  | Nat.succ rest, cursor => (match Uorc.Uorc.Core.RuntimeAdmissionCancel.tick (cursor) with | Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.pending next => cancelDrive (rest) (next) | Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.cancelled done => Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.cancelled (done) | Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.failed failure next => Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.failed (failure) (next))

@[expose] public def runCancellation : Except (ScenarioError) (Unit) := (match fixture with | Uorc.Uorc.Core.RuntimeAdmission.Step.pending _ => Except.error (ScenarioError.failed) | Uorc.Uorc.Core.RuntimeAdmission.Step.ready _ => Except.error (ScenarioError.failed) | Uorc.Uorc.Core.RuntimeAdmission.Step.failed _ _ => Except.error (ScenarioError.failed) | Uorc.Uorc.Core.RuntimeAdmission.Step.awaiting next => (match cancelDrive (100) (Uorc.Uorc.Core.RuntimeAdmissionCancel.start (next)) with | Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.pending _ => Except.error (ScenarioError.fuelExhausted) | Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.failed _ _ => Except.error (ScenarioError.failed) | Uorc.Uorc.Core.RuntimeAdmissionCancel.Event.cancelled done => (if ((LexLeanRuntime.equal (((done).arena).ownedBytes) ((0 : UInt64)) : Bool) && Uorc.Uorc.Core.HeapAudit.auditRoots ((done).arena) (([] : List (Uorc.Uorc.Core.RuntimeValue.Handle)))) then Except.ok (()) else Except.error (ScenarioError.failed))))

end Uorc.Uorc.Core.RuntimeAdmissionScenarios
