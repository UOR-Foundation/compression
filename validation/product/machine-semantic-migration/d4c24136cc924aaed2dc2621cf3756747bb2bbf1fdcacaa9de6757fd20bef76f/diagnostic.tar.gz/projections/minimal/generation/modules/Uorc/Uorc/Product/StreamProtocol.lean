module
public import Init
public import LexLeanRuntime.Portable
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Product.StreamProtocol

public inductive Phase where
  | working
  | awaitingInput
  | complete
  | cancelled
  | failed

public inductive Publication where
  | staged
  | published
  | notPublished
  | unknown

public inductive ProtocolError where
  | inputNotRequested
  | endAlreadySeen
  | notWorking
  | notReady
  | outputLimit

public inductive Input where
  | tick
  | chunk
  | endOfInput
  | cancel

public inductive InputAction where
  | run
  | admitChunk
  | sealInput
  | cancel
  | ignoreTerminal

public structure State where
  phase : Phase
  ended : Bool
  producedBytes : Nat
  verified : Bool
  publication : Publication

public inductive Decision where
  | accepted (_ : InputAction) (_ : State)
  | rejected (_ : ProtocolError)

@[expose] public def initial : State := ({ phase := Phase.working, ended := false, producedBytes := 0, verified := false, publication := Publication.staged } : State)

@[expose] public def acceptInput (s : State) (input : Input) : Decision := (match input with | Input.tick => (match (s).phase with | Phase.working => Decision.accepted (InputAction.run) (s) | Phase.awaitingInput => Decision.rejected (ProtocolError.notWorking) | Phase.complete => Decision.rejected (ProtocolError.notWorking) | Phase.cancelled => Decision.rejected (ProtocolError.notWorking) | Phase.failed => Decision.rejected (ProtocolError.notWorking)) | Input.chunk => (match (s).phase with | Phase.working => Decision.rejected (ProtocolError.inputNotRequested) | Phase.awaitingInput => (if (s).ended then Decision.rejected (ProtocolError.endAlreadySeen) else Decision.accepted (InputAction.admitChunk) (({ phase := Phase.working, ended := (s).ended, producedBytes := (s).producedBytes, verified := (s).verified, publication := (s).publication } : State))) | Phase.complete => Decision.rejected (ProtocolError.inputNotRequested) | Phase.cancelled => Decision.rejected (ProtocolError.inputNotRequested) | Phase.failed => Decision.rejected (ProtocolError.inputNotRequested)) | Input.endOfInput => (match (s).phase with | Phase.working => Decision.rejected (ProtocolError.inputNotRequested) | Phase.awaitingInput => (if (s).ended then Decision.rejected (ProtocolError.endAlreadySeen) else Decision.accepted (InputAction.sealInput) (({ phase := Phase.working, ended := true, producedBytes := (s).producedBytes, verified := (s).verified, publication := (s).publication } : State))) | Phase.complete => Decision.rejected (ProtocolError.inputNotRequested) | Phase.cancelled => Decision.rejected (ProtocolError.inputNotRequested) | Phase.failed => Decision.rejected (ProtocolError.inputNotRequested)) | Input.cancel => (match (s).phase with | Phase.working => Decision.accepted (InputAction.cancel) (({ phase := Phase.cancelled, ended := (s).ended, producedBytes := (s).producedBytes, verified := false, publication := Publication.notPublished } : State)) | Phase.awaitingInput => Decision.accepted (InputAction.cancel) (({ phase := Phase.cancelled, ended := (s).ended, producedBytes := (s).producedBytes, verified := false, publication := Publication.notPublished } : State)) | Phase.complete => Decision.accepted (InputAction.ignoreTerminal) (s) | Phase.cancelled => Decision.accepted (InputAction.ignoreTerminal) (s) | Phase.failed => Decision.accepted (InputAction.ignoreTerminal) (s)))

@[expose] public def requestInput (s : State) : Except (ProtocolError) (State) := (match (s).phase with | Phase.working => (if (s).ended then Except.error (ProtocolError.endAlreadySeen) else Except.ok (({ phase := Phase.awaitingInput, ended := (s).ended, producedBytes := (s).producedBytes, verified := (s).verified, publication := (s).publication } : State))) | Phase.awaitingInput => Except.error (ProtocolError.notWorking) | Phase.complete => Except.error (ProtocolError.notWorking) | Phase.cancelled => Except.error (ProtocolError.notWorking) | Phase.failed => Except.error (ProtocolError.notWorking))

@[expose] public def stageOutput (s : State) (bytesProduced : Nat) (limit : Nat) : Except (ProtocolError) (State) := (match (s).phase with | Phase.working => (if ((Nat.ble ((s).producedBytes) (limit)) && ((Nat.ble (bytesProduced) ((LexLeanRuntime.subtract (limit) ((s).producedBytes) : Nat))) && true)) then Except.ok (({ phase := (s).phase, ended := (s).ended, producedBytes := ((s).producedBytes + bytesProduced), verified := (s).verified, publication := (s).publication } : State)) else Except.error (ProtocolError.outputLimit)) | Phase.awaitingInput => Except.error (ProtocolError.notWorking) | Phase.complete => Except.error (ProtocolError.notWorking) | Phase.cancelled => Except.error (ProtocolError.notWorking) | Phase.failed => Except.error (ProtocolError.notWorking))

@[expose] public def completeVerified (s : State) : Except (ProtocolError) (State) := (match (s).phase with | Phase.working => (if (s).ended then Except.ok (({ phase := Phase.complete, ended := (s).ended, producedBytes := (s).producedBytes, verified := true, publication := (s).publication } : State)) else Except.error (ProtocolError.notReady)) | Phase.awaitingInput => Except.error (ProtocolError.notWorking) | Phase.complete => Except.error (ProtocolError.notWorking) | Phase.cancelled => Except.error (ProtocolError.notWorking) | Phase.failed => Except.error (ProtocolError.notWorking))

@[expose] public def canCommit (s : State) : Bool := (match (s).phase with | Phase.working => false | Phase.awaitingInput => false | Phase.complete => ((s).verified && ((match (s).publication with | Publication.staged => true | Publication.published => false | Publication.notPublished => false | Publication.unknown => false) && true)) | Phase.cancelled => false | Phase.failed => false)

@[expose] public def recordPublication (s : State) (outcome : Publication) : Except (ProtocolError) (State) := (if canCommit (s) then (match outcome with | Publication.staged => Except.error (ProtocolError.notReady) | Publication.published => Except.ok (({ phase := (s).phase, ended := (s).ended, producedBytes := (s).producedBytes, verified := (s).verified, publication := Publication.published } : State)) | Publication.notPublished => Except.ok (({ phase := (s).phase, ended := (s).ended, producedBytes := (s).producedBytes, verified := (s).verified, publication := Publication.notPublished } : State)) | Publication.unknown => Except.ok (({ phase := (s).phase, ended := (s).ended, producedBytes := (s).producedBytes, verified := (s).verified, publication := Publication.unknown } : State))) else Except.error (ProtocolError.notReady))

@[expose] public def fail (s : State) (outcome : Publication) : State := ({ phase := Phase.failed, ended := (s).ended, producedBytes := (s).producedBytes, verified := false, publication := outcome } : State)

public theorem initial_cannot_commit : (canCommit (initial) = false) := by
  rfl

public theorem chunk_needs_demand : (acceptInput (initial) (Input.chunk) = Decision.rejected (ProtocolError.inputNotRequested)) := by
  rfl

public theorem eof_needs_demand : (acceptInput (initial) (Input.endOfInput) = Decision.rejected (ProtocolError.inputNotRequested)) := by
  rfl

public theorem request_admits_chunk : (acceptInput (({ phase := Phase.awaitingInput, ended := false, producedBytes := 0, verified := false, publication := Publication.staged } : State)) (Input.chunk) = Decision.accepted (InputAction.admitChunk) (initial)) := by
  rfl

public theorem seal_is_once : (requestInput (({ phase := Phase.working, ended := true, producedBytes := 7, verified := false, publication := Publication.staged } : State)) = Except.error (ProtocolError.endAlreadySeen)) := by
  rfl

public theorem cannot_complete_before_eof : (completeVerified (initial) = Except.error (ProtocolError.notReady)) := by
  rfl

public theorem verified_complete_can_commit : (canCommit (({ phase := Phase.complete, ended := true, producedBytes := 7, verified := true, publication := Publication.staged } : State)) = true) := by
  rfl

public theorem completion_preserves_staging : (completeVerified (({ phase := Phase.working, ended := true, producedBytes := 7, verified := false, publication := Publication.staged } : State)) = Except.ok (({ phase := Phase.complete, ended := true, producedBytes := 7, verified := true, publication := Publication.staged } : State))) := by
  rfl

public theorem cancellation_never_commits : (canCommit (({ phase := Phase.cancelled, ended := true, producedBytes := 7, verified := false, publication := Publication.notPublished } : State)) = false) := by
  rfl

public theorem late_cancel_ignored : (acceptInput (({ phase := Phase.complete, ended := true, producedBytes := 7, verified := true, publication := Publication.staged } : State)) (Input.cancel) = Decision.accepted (InputAction.ignoreTerminal) (({ phase := Phase.complete, ended := true, producedBytes := 7, verified := true, publication := Publication.staged } : State))) := by
  rfl

public theorem staged_output_is_not_publication : (stageOutput (initial) (7) (7) = Except.ok (({ phase := Phase.working, ended := false, producedBytes := 7, verified := false, publication := Publication.staged } : State))) := by
  rfl

public theorem output_over_limit_rejected : (stageOutput (({ phase := Phase.working, ended := true, producedBytes := 7, verified := false, publication := Publication.staged } : State)) (1) (7) = Except.error (ProtocolError.outputLimit)) := by
  rfl

public theorem max_counter_rejected_before_add : (stageOutput (({ phase := Phase.working, ended := false, producedBytes := 18446744073709551615, verified := false, publication := Publication.staged } : State)) (1) (18446744073709551615) = Except.error (ProtocolError.outputLimit)) := by
  rfl

public theorem early_publication_rejected : (recordPublication (({ phase := Phase.working, ended := true, producedBytes := 7, verified := false, publication := Publication.staged } : State)) (Publication.published) = Except.error (ProtocolError.notReady)) := by
  rfl

@[expose] public def boundary : String := "The source controller uses this protocol around its actual operation state. An input chunk is accepted only on demand; EOF is one-shot; output remains staged until a verified completed operation permits host publication. completeVerified is called only by the independently verified operation path, never by an untrusted request flag. Atomic no-replace file publication, stdout partial-write risk, cancellation cleanup, and host outcome unknown remain distinct adapter obligations. This protocol does not itself verify archive content or prove host filesystem behavior."

end Uorc.Uorc.Product.StreamProtocol
