module
public import Init
public import LexLeanRuntime.Portable
public import LexLeanRuntime.Laws
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Core.Resources

public inductive OperationalError where
  | stepLimit
  | liveCellLimit
  | outputLimit
  | frameLimit
  | cancelled
  | hostMemory
  | timeLimit
  | ioFailure
  | internalInvariant
  | addressSpaceExhausted

public structure Budget where
  maxSteps : Nat
  maxLiveCells : Nat
  maxOutputBytes : Nat
  maxFrames : Nat

public structure Usage where
  steps : Nat
  liveCells : Nat
  peakCells : Nat
  outputBytes : Nat
  frames : Nat

public inductive EventKind where
  | dispatch
  | scalarRead
  | indexedRead
  | byteWrite
  | compareByte
  | trieEdge
  | allocate
  | retainRoot
  | dropRoot
  | control
  | outputBoundary
  | outputByte

public structure Event where
  kind : EventKind
  work : Nat
  allocatedCells : Nat
  releasedCells : Nat
  emittedBytes : Nat
  enteredFrames : Nat
  exitedFrames : Nat

@[expose] public def zeroUsage : Usage := ({ steps := 0, liveCells := 0, peakCells := 0, outputBytes := 0, frames := 0 } : Usage)

@[expose] public def eventUsage (u : Usage) (e : Event) : Usage := ({ steps := ((u).steps + (e).work), liveCells := (LexLeanRuntime.subtract (((u).liveCells + (e).allocatedCells)) ((e).releasedCells) : Nat), peakCells := (if (Nat.ble ((u).peakCells) (((u).liveCells + (e).allocatedCells))) then ((u).liveCells + (e).allocatedCells) else (u).peakCells), outputBytes := ((u).outputBytes + (e).emittedBytes), frames := (LexLeanRuntime.subtract (((u).frames + (e).enteredFrames)) ((e).exitedFrames) : Nat) } : Usage)

@[expose] public def validateUsage (budget : Budget) (u : Usage) : Except (OperationalError) (Usage) := (if (Nat.blt ((budget).maxSteps) ((u).steps)) then Except.error (OperationalError.stepLimit) else (if (Nat.blt ((budget).maxLiveCells) ((u).peakCells)) then Except.error (OperationalError.liveCellLimit) else (if (Nat.blt ((budget).maxOutputBytes) ((u).outputBytes)) then Except.error (OperationalError.outputLimit) else (if (Nat.blt ((budget).maxFrames) ((u).frames)) then Except.error (OperationalError.frameLimit) else Except.ok (u)))))

@[expose] public def fitsAddition (limit : Nat) (used : Nat) (increase : Nat) : Bool := (if (Nat.ble (used) (limit)) then (Nat.ble (increase) ((LexLeanRuntime.subtract (limit) (used) : Nat))) else false)

@[expose] public def releaseUnderflows (owned : Nat) (allocated : Nat) (released : Nat) : Bool := (if (Nat.ble (released) (owned)) then false else (Nat.blt (allocated) ((LexLeanRuntime.subtract (released) (owned) : Nat))))

@[expose] public def charge (budget : Budget) (u : Usage) (e : Event) : Except (OperationalError) (Usage) := (if (!fitsAddition ((budget).maxSteps) ((u).steps) ((e).work)) then Except.error (OperationalError.stepLimit) else (if (releaseUnderflows ((u).liveCells) ((e).allocatedCells) ((e).releasedCells) || releaseUnderflows ((u).frames) ((e).enteredFrames) ((e).exitedFrames)) then Except.error (OperationalError.internalInvariant) else (if ((Nat.blt ((budget).maxLiveCells) ((u).peakCells)) || (!fitsAddition ((budget).maxLiveCells) ((u).liveCells) ((e).allocatedCells))) then Except.error (OperationalError.liveCellLimit) else (if (!fitsAddition ((budget).maxOutputBytes) ((u).outputBytes) ((e).emittedBytes)) then Except.error (OperationalError.outputLimit) else (if (!fitsAddition ((budget).maxFrames) ((u).frames) ((e).enteredFrames)) then Except.error (OperationalError.frameLimit) else Except.ok (eventUsage (u) (e)))))))

@[expose] public def runEvents : (events : List (Event)) -> (budget : Budget) -> (u : Usage) -> Except (OperationalError) (Usage)
  | List.nil, budget, u => validateUsage (budget) (u)
  | List.cons event rest, budget, u => (match charge (budget) (u) (event) with | Except.error error => Except.error (error) | Except.ok value => runEvents (rest) (budget) (value))

@[expose] public def unitEvent (kind : EventKind) : Event := ({ kind := kind, work := 1, allocatedCells := 0, releasedCells := 0, emittedBytes := 0, enteredFrames := 0, exitedFrames := 0 } : Event)

public structure WorkPartition where
  admission : Nat
  rawBaseline : Nat
  search : Nat
  verification : Nat
  replay : Nat
  certificate : Nat

@[expose] public def totalLogicalWork (partition : WorkPartition) : Nat := ((((partition).admission + (partition).rawBaseline) + ((partition).search + (partition).verification)) + ((partition).replay + (partition).certificate))

public structure PhysicalTelemetry where
  hashBytes : Nat
  ioReadBytes : Nat
  ioWrittenBytes : Nat
  elapsedNanoseconds : Nat
  peakResidentBytes : Nat

public theorem event_step_limit : (charge (({ maxSteps := 100, maxLiveCells := 100, maxOutputBytes := 100, maxFrames := 100 } : Budget)) (zeroUsage) (({ kind := EventKind.dispatch, work := 101, allocatedCells := 0, releasedCells := 0, emittedBytes := 0, enteredFrames := 0, exitedFrames := 0 } : Event)) = Except.error (OperationalError.stepLimit)) := by
  rfl

public theorem event_live_peak_before_release : (charge (({ maxSteps := 100, maxLiveCells := 100, maxOutputBytes := 100, maxFrames := 100 } : Budget)) (zeroUsage) (({ kind := EventKind.allocate, work := 1, allocatedCells := 101, releasedCells := 101, emittedBytes := 0, enteredFrames := 0, exitedFrames := 0 } : Event)) = Except.error (OperationalError.liveCellLimit)) := by
  rfl

public theorem event_release_underflow : (charge (({ maxSteps := 100, maxLiveCells := 100, maxOutputBytes := 100, maxFrames := 100 } : Budget)) (zeroUsage) (({ kind := EventKind.dropRoot, work := 1, allocatedCells := 0, releasedCells := 1, emittedBytes := 0, enteredFrames := 0, exitedFrames := 0 } : Event)) = Except.error (OperationalError.internalInvariant)) := by
  rfl

public theorem event_output_limit : (charge (({ maxSteps := 100, maxLiveCells := 100, maxOutputBytes := 100, maxFrames := 100 } : Budget)) (zeroUsage) (({ kind := EventKind.outputByte, work := 1, allocatedCells := 0, releasedCells := 0, emittedBytes := 101, enteredFrames := 0, exitedFrames := 0 } : Event)) = Except.error (OperationalError.outputLimit)) := by
  rfl

public theorem event_frame_limit : (charge (({ maxSteps := 100, maxLiveCells := 100, maxOutputBytes := 100, maxFrames := 100 } : Budget)) (zeroUsage) (({ kind := EventKind.control, work := 1, allocatedCells := 0, releasedCells := 0, emittedBytes := 0, enteredFrames := 101, exitedFrames := 0 } : Event)) = Except.error (OperationalError.frameLimit)) := by
  rfl

public theorem empty_events_identity (budget : Budget) (u : Usage) : (runEvents (([] : List (Event))) (budget) (u) = validateUsage (budget) (u)) := by
  rfl

public theorem work_overflow_is_typed_before_addition : (charge (({ maxSteps := 18446744073709551615, maxLiveCells := 18446744073709551615, maxOutputBytes := 18446744073709551615, maxFrames := 18446744073709551615 } : Budget)) (({ steps := 18446744073709551615, liveCells := 0, peakCells := 0, outputBytes := 0, frames := 0 } : Usage)) (({ kind := EventKind.allocate, work := 1, allocatedCells := 0, releasedCells := 0, emittedBytes := 0, enteredFrames := 0, exitedFrames := 0 } : Event)) = Except.error (OperationalError.stepLimit)) := by
  rfl

public theorem owned_peak_overflow_is_typed_before_addition : (charge (({ maxSteps := 18446744073709551615, maxLiveCells := 18446744073709551615, maxOutputBytes := 18446744073709551615, maxFrames := 18446744073709551615 } : Budget)) (({ steps := 0, liveCells := 18446744073709551615, peakCells := 18446744073709551615, outputBytes := 0, frames := 0 } : Usage)) (({ kind := EventKind.allocate, work := 0, allocatedCells := 1, releasedCells := 0, emittedBytes := 0, enteredFrames := 0, exitedFrames := 0 } : Event)) = Except.error (OperationalError.liveCellLimit)) := by
  rfl

public theorem output_overflow_is_typed_before_addition : (charge (({ maxSteps := 18446744073709551615, maxLiveCells := 18446744073709551615, maxOutputBytes := 18446744073709551615, maxFrames := 18446744073709551615 } : Budget)) (({ steps := 0, liveCells := 0, peakCells := 0, outputBytes := 18446744073709551615, frames := 0 } : Usage)) (({ kind := EventKind.allocate, work := 0, allocatedCells := 0, releasedCells := 0, emittedBytes := 1, enteredFrames := 0, exitedFrames := 0 } : Event)) = Except.error (OperationalError.outputLimit)) := by
  rfl

public theorem frame_overflow_is_typed_before_addition : (charge (({ maxSteps := 18446744073709551615, maxLiveCells := 18446744073709551615, maxOutputBytes := 18446744073709551615, maxFrames := 18446744073709551615 } : Budget)) (({ steps := 0, liveCells := 0, peakCells := 0, outputBytes := 0, frames := 18446744073709551615 } : Usage)) (({ kind := EventKind.allocate, work := 0, allocatedCells := 0, releasedCells := 0, emittedBytes := 0, enteredFrames := 1, exitedFrames := 0 } : Event)) = Except.error (OperationalError.frameLimit)) := by
  rfl

public theorem replacement_checks_transient_owned_peak : (charge (({ maxSteps := 10, maxLiveCells := 1, maxOutputBytes := 10, maxFrames := 10 } : Budget)) (({ steps := 0, liveCells := 1, peakCells := 1, outputBytes := 0, frames := 0 } : Usage)) (({ kind := EventKind.allocate, work := 0, allocatedCells := 1, releasedCells := 1, emittedBytes := 0, enteredFrames := 0, exitedFrames := 0 } : Event)) = Except.error (OperationalError.liveCellLimit)) := by
  rfl

public theorem replacement_checks_transient_frame_depth : (charge (({ maxSteps := 10, maxLiveCells := 10, maxOutputBytes := 10, maxFrames := 1 } : Budget)) (({ steps := 0, liveCells := 0, peakCells := 0, outputBytes := 0, frames := 1 } : Usage)) (({ kind := EventKind.allocate, work := 0, allocatedCells := 0, releasedCells := 0, emittedBytes := 0, enteredFrames := 1, exitedFrames := 1 } : Event)) = Except.error (OperationalError.frameLimit)) := by
  rfl

public theorem false_guard_selects_false (value : Bool) : ((if false then value else false) = false) := by
  rfl

public theorem overfull_addition_guard_false (limit : Nat) : ((Nat.ble ((limit + 1)) (limit)) = false) := by
  intros
  try set_option linter.unusedSimpArgs false in simp only [← Bool.not_eq_true, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', and_true, true_and, Option.some.injEq, Nat.beq_eq, Nat.blt_eq, Nat.ble_eq, LexLeanRuntime.subtract, LexLeanRuntime.multiply, LexLeanRuntime.negate, LexLeanRuntime.equal, beq_iff_eq, decide_eq_true_eq, decide_eq_false_iff_not, Nat.add_assoc, Int.add_assoc, Int.neg_neg, Int.emod_neg, Int.neg_zero, ↓reduceIte, LexLeanLaws.lessThan_nat, LexLeanLaws.lessThan_int, LexLeanLaws.lessThan_int8, LexLeanLaws.lessThan_int16, LexLeanLaws.lessThan_int32, LexLeanLaws.lessThan_int64, LexLeanLaws.lessThan_uint8, LexLeanLaws.lessThan_uint16, LexLeanLaws.lessThan_uint32, LexLeanLaws.lessThan_uint64, LexLeanLaws.quotient_nat, LexLeanLaws.quotient_int, LexLeanLaws.remainder_nat, LexLeanLaws.remainder_int, LexLeanLaws.tdiv_ediv, LexLeanLaws.tmod_emod, LexLeanLaws.length_list, LexLeanLaws.append_list, LexLeanLaws.setFold_listFold, LexLeanLaws.mapFold_listFold, LexLeanLaws.setSize_length, LexLeanLaws.mapSize_length, LexLeanLaws.setElements_self, LexLeanLaws.mapEntries_self, LexLeanLaws.listFold_nil, LexLeanLaws.listFold_append, LexLeanLaws.listFold_prepend, LexLeanLaws.listFold_extend, LexLeanLaws.listFold_add_nat, LexLeanLaws.listFold_add_nat_self, LexLeanLaws.listFold_add_int, LexLeanLaws.listFold_add_int_self, LexLeanLaws.listFold_sub_int, LexLeanLaws.listFold_sub_int_self, LexLeanLaws.sumNat_nil, LexLeanLaws.sumNat_cons, LexLeanLaws.sumInt_nil, LexLeanLaws.sumInt_cons, LexLeanLaws.sumNat_add, LexLeanLaws.sumInt_add, LexLeanLaws.sumInt_sub, LexLeanLaws.sumInt_neg, LexLeanLaws.sumInt_neg_self, LexLeanLaws.sumNat_mul, LexLeanLaws.sumInt_mul, LexLeanLaws.sumNat_mul_self, LexLeanLaws.sumInt_mul_self, LexLeanLaws.sumNat_mul_right, LexLeanLaws.sumInt_mul_right, LexLeanLaws.sumNat_const, LexLeanLaws.sumInt_const, LexLeanLaws.sumNat_append, LexLeanLaws.sumInt_append, LexLeanLaws.sumNat_reverse, LexLeanLaws.sumInt_reverse, UInt8.le_iff_toNat_le, UInt8.lt_iff_toNat_lt, UInt16.le_iff_toNat_le, UInt16.lt_iff_toNat_lt, UInt32.le_iff_toNat_le, UInt32.lt_iff_toNat_lt, UInt64.le_iff_toNat_le, UInt64.lt_iff_toNat_lt, Int8.le_iff_toInt_le, Int8.lt_iff_toInt_lt, Int16.le_iff_toInt_le, Int16.lt_iff_toInt_lt, Int32.le_iff_toInt_le, Int32.lt_iff_toInt_lt, Int64.le_iff_toInt_le, Int64.lt_iff_toInt_lt, UInt8.reduceToNat, ← UInt8.toNat_inj, UInt16.reduceToNat, ← UInt16.toNat_inj, UInt32.reduceToNat, ← UInt32.toNat_inj, UInt64.reduceToNat, ← UInt64.toNat_inj, Int8.reduceToInt, ← Int8.toInt_inj, Int16.reduceToInt, ← Int16.toInt_inj, Int32.reduceToInt, ← Int32.toInt_inj, Int64.reduceToInt, ← Int64.toInt_inj] at *
  try set_option linter.unusedSimpArgs false in simp only [UInt8.toNat, UInt16.toNat, UInt32.toNat, UInt64.toNat, Int8.toInt, Int16.toInt, Int32.toInt, Int64.toInt, BitVec.toInt_eq_toNat_cond] at *
  all_goals (repeat' split)
  all_goals omega

public theorem addition_guard_rejects_overfull_state (limit : Nat) (increase : Nat) : (fitsAddition (limit) ((limit + 1)) (increase) = false) := by
  simp only [false_guard_selects_false, fitsAddition, overfull_addition_guard_false]

public theorem success_guard_observation (isRejected : Bool) (failureValue : OperationalError) (continuation : Except (OperationalError) (Usage)) (failureObservation : Prop) (observation : ((Usage) -> (Prop))) : ((match (if isRejected then Except.error (failureValue) else continuation) with | Except.error _ => failureObservation | Except.ok committedUsage => (observation (committedUsage))) <-> (if isRejected then failureObservation else (match continuation with | Except.error _ => failureObservation | Except.ok committedUsage => (observation (committedUsage))))) := by
  cases isRejected with
  | false =>
    rfl
  | true =>
    rfl

public theorem identical_guard_observation (isRejected : Bool) (observation : Prop) : ((if isRejected then observation else observation) <-> observation) := by
  cases isRejected with
  | false =>
    rfl
  | true =>
    rfl

public theorem event_work_projection (initialUsage : Usage) (event : Event) : ((eventUsage (initialUsage) (event)).steps = ((initialUsage).steps + (event).work)) := by
  rfl

public theorem event_output_projection (initialUsage : Usage) (event : Event) : ((eventUsage (initialUsage) (event)).outputBytes = ((initialUsage).outputBytes + (event).emittedBytes)) := by
  rfl

public theorem event_work_non_decrease (initialUsage : Usage) (event : Event) : ((Nat.ble ((initialUsage).steps) ((eventUsage (initialUsage) (event)).steps)) = true) := by
  intros
  subst_vars
  try set_option linter.unusedSimpArgs false in simp only [eventUsage, ← Bool.not_eq_true, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', and_true, true_and, Option.some.injEq, Nat.beq_eq, Nat.blt_eq, Nat.ble_eq, LexLeanRuntime.subtract, LexLeanRuntime.multiply, LexLeanRuntime.negate, LexLeanRuntime.equal, beq_iff_eq, decide_eq_true_eq, decide_eq_false_iff_not, Nat.add_assoc, Int.add_assoc, Int.neg_neg, Int.emod_neg, Int.neg_zero, ↓reduceIte, LexLeanLaws.lessThan_nat, LexLeanLaws.lessThan_int, LexLeanLaws.lessThan_int8, LexLeanLaws.lessThan_int16, LexLeanLaws.lessThan_int32, LexLeanLaws.lessThan_int64, LexLeanLaws.lessThan_uint8, LexLeanLaws.lessThan_uint16, LexLeanLaws.lessThan_uint32, LexLeanLaws.lessThan_uint64, LexLeanLaws.quotient_nat, LexLeanLaws.quotient_int, LexLeanLaws.remainder_nat, LexLeanLaws.remainder_int, LexLeanLaws.tdiv_ediv, LexLeanLaws.tmod_emod, LexLeanLaws.length_list, LexLeanLaws.append_list, LexLeanLaws.setFold_listFold, LexLeanLaws.mapFold_listFold, LexLeanLaws.setSize_length, LexLeanLaws.mapSize_length, LexLeanLaws.setElements_self, LexLeanLaws.mapEntries_self, LexLeanLaws.listFold_nil, LexLeanLaws.listFold_append, LexLeanLaws.listFold_prepend, LexLeanLaws.listFold_extend, LexLeanLaws.listFold_add_nat, LexLeanLaws.listFold_add_nat_self, LexLeanLaws.listFold_add_int, LexLeanLaws.listFold_add_int_self, LexLeanLaws.listFold_sub_int, LexLeanLaws.listFold_sub_int_self, LexLeanLaws.sumNat_nil, LexLeanLaws.sumNat_cons, LexLeanLaws.sumInt_nil, LexLeanLaws.sumInt_cons, LexLeanLaws.sumNat_add, LexLeanLaws.sumInt_add, LexLeanLaws.sumInt_sub, LexLeanLaws.sumInt_neg, LexLeanLaws.sumInt_neg_self, LexLeanLaws.sumNat_mul, LexLeanLaws.sumInt_mul, LexLeanLaws.sumNat_mul_self, LexLeanLaws.sumInt_mul_self, LexLeanLaws.sumNat_mul_right, LexLeanLaws.sumInt_mul_right, LexLeanLaws.sumNat_const, LexLeanLaws.sumInt_const, LexLeanLaws.sumNat_append, LexLeanLaws.sumInt_append, LexLeanLaws.sumNat_reverse, LexLeanLaws.sumInt_reverse, UInt8.le_iff_toNat_le, UInt8.lt_iff_toNat_lt, UInt16.le_iff_toNat_le, UInt16.lt_iff_toNat_lt, UInt32.le_iff_toNat_le, UInt32.lt_iff_toNat_lt, UInt64.le_iff_toNat_le, UInt64.lt_iff_toNat_lt, Int8.le_iff_toInt_le, Int8.lt_iff_toInt_lt, Int16.le_iff_toInt_le, Int16.lt_iff_toInt_lt, Int32.le_iff_toInt_le, Int32.lt_iff_toInt_lt, Int64.le_iff_toInt_le, Int64.lt_iff_toInt_lt, UInt8.reduceToNat, ← UInt8.toNat_inj, UInt16.reduceToNat, ← UInt16.toNat_inj, UInt32.reduceToNat, ← UInt32.toNat_inj, UInt64.reduceToNat, ← UInt64.toNat_inj, Int8.reduceToInt, ← Int8.toInt_inj, Int16.reduceToInt, ← Int16.toInt_inj, Int32.reduceToInt, ← Int32.toInt_inj, Int64.reduceToInt, ← Int64.toInt_inj] at *
  try set_option linter.unusedSimpArgs false in simp only [UInt8.toNat, UInt16.toNat, UInt32.toNat, UInt64.toNat, Int8.toInt, Int16.toInt, Int32.toInt, Int64.toInt, BitVec.toInt_eq_toNat_cond] at *
  all_goals (repeat' split)
  all_goals omega

public theorem event_peak_non_decrease (initialUsage : Usage) (event : Event) : ((Nat.ble ((initialUsage).peakCells) ((eventUsage (initialUsage) (event)).peakCells)) = true) := by
  intros
  subst_vars
  try set_option linter.unusedSimpArgs false in simp only [eventUsage, ← Bool.not_eq_true, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', and_true, true_and, Option.some.injEq, Nat.beq_eq, Nat.blt_eq, Nat.ble_eq, LexLeanRuntime.subtract, LexLeanRuntime.multiply, LexLeanRuntime.negate, LexLeanRuntime.equal, beq_iff_eq, decide_eq_true_eq, decide_eq_false_iff_not, Nat.add_assoc, Int.add_assoc, Int.neg_neg, Int.emod_neg, Int.neg_zero, ↓reduceIte, LexLeanLaws.lessThan_nat, LexLeanLaws.lessThan_int, LexLeanLaws.lessThan_int8, LexLeanLaws.lessThan_int16, LexLeanLaws.lessThan_int32, LexLeanLaws.lessThan_int64, LexLeanLaws.lessThan_uint8, LexLeanLaws.lessThan_uint16, LexLeanLaws.lessThan_uint32, LexLeanLaws.lessThan_uint64, LexLeanLaws.quotient_nat, LexLeanLaws.quotient_int, LexLeanLaws.remainder_nat, LexLeanLaws.remainder_int, LexLeanLaws.tdiv_ediv, LexLeanLaws.tmod_emod, LexLeanLaws.length_list, LexLeanLaws.append_list, LexLeanLaws.setFold_listFold, LexLeanLaws.mapFold_listFold, LexLeanLaws.setSize_length, LexLeanLaws.mapSize_length, LexLeanLaws.setElements_self, LexLeanLaws.mapEntries_self, LexLeanLaws.listFold_nil, LexLeanLaws.listFold_append, LexLeanLaws.listFold_prepend, LexLeanLaws.listFold_extend, LexLeanLaws.listFold_add_nat, LexLeanLaws.listFold_add_nat_self, LexLeanLaws.listFold_add_int, LexLeanLaws.listFold_add_int_self, LexLeanLaws.listFold_sub_int, LexLeanLaws.listFold_sub_int_self, LexLeanLaws.sumNat_nil, LexLeanLaws.sumNat_cons, LexLeanLaws.sumInt_nil, LexLeanLaws.sumInt_cons, LexLeanLaws.sumNat_add, LexLeanLaws.sumInt_add, LexLeanLaws.sumInt_sub, LexLeanLaws.sumInt_neg, LexLeanLaws.sumInt_neg_self, LexLeanLaws.sumNat_mul, LexLeanLaws.sumInt_mul, LexLeanLaws.sumNat_mul_self, LexLeanLaws.sumInt_mul_self, LexLeanLaws.sumNat_mul_right, LexLeanLaws.sumInt_mul_right, LexLeanLaws.sumNat_const, LexLeanLaws.sumInt_const, LexLeanLaws.sumNat_append, LexLeanLaws.sumInt_append, LexLeanLaws.sumNat_reverse, LexLeanLaws.sumInt_reverse, UInt8.le_iff_toNat_le, UInt8.lt_iff_toNat_lt, UInt16.le_iff_toNat_le, UInt16.lt_iff_toNat_lt, UInt32.le_iff_toNat_le, UInt32.lt_iff_toNat_lt, UInt64.le_iff_toNat_le, UInt64.lt_iff_toNat_lt, Int8.le_iff_toInt_le, Int8.lt_iff_toInt_lt, Int16.le_iff_toInt_le, Int16.lt_iff_toInt_lt, Int32.le_iff_toInt_le, Int32.lt_iff_toInt_lt, Int64.le_iff_toInt_le, Int64.lt_iff_toInt_lt, UInt8.reduceToNat, ← UInt8.toNat_inj, UInt16.reduceToNat, ← UInt16.toNat_inj, UInt32.reduceToNat, ← UInt32.toNat_inj, UInt64.reduceToNat, ← UInt64.toNat_inj, Int8.reduceToInt, ← Int8.toInt_inj, Int16.reduceToInt, ← Int16.toInt_inj, Int32.reduceToInt, ← Int32.toInt_inj, Int64.reduceToInt, ← Int64.toInt_inj] at *
  try set_option linter.unusedSimpArgs false in simp only [UInt8.toNat, UInt16.toNat, UInt32.toNat, UInt64.toNat, Int8.toInt, Int16.toInt, Int32.toInt, Int64.toInt, BitVec.toInt_eq_toNat_cond] at *
  all_goals (repeat' split)
  all_goals omega

public theorem successful_charge_commits_exact_event_work (budget : Budget) (initialUsage : Usage) (event : Event) : (match charge (budget) (initialUsage) (event) with | Except.error _ => (0 = 0) | Except.ok chargedUsage => ((chargedUsage).steps = ((initialUsage).steps + (event).work))) := by
  simp only [charge, event_work_projection, identical_guard_observation, success_guard_observation]

public theorem successful_charge_never_decreases_work (budget : Budget) (initialUsage : Usage) (event : Event) : (match charge (budget) (initialUsage) (event) with | Except.error _ => (0 = 0) | Except.ok chargedUsage => ((Nat.ble ((initialUsage).steps) ((chargedUsage).steps)) = true)) := by
  simp only [charge, event_work_non_decrease, identical_guard_observation, success_guard_observation]

public theorem successful_charge_commits_exact_output_count (budget : Budget) (initialUsage : Usage) (event : Event) : (match charge (budget) (initialUsage) (event) with | Except.error _ => (0 = 0) | Except.ok chargedUsage => ((chargedUsage).outputBytes = ((initialUsage).outputBytes + (event).emittedBytes))) := by
  simp only [charge, event_output_projection, identical_guard_observation, success_guard_observation]

public theorem successful_charge_never_lowers_owned_peak (budget : Budget) (initialUsage : Usage) (event : Event) : (match charge (budget) (initialUsage) (event) with | Except.error _ => (0 = 0) | Except.ok chargedUsage => ((Nat.ble ((initialUsage).peakCells) ((chargedUsage).peakCells)) = true)) := by
  simp only [charge, event_peak_non_decrease, identical_guard_observation, success_guard_observation]

end Uorc.Uorc.Core.Resources
