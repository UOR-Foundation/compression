module
public import Init
public import LexLeanRuntime.Portable
public import Uorc.Uorc.Core.Heap
public import Uorc.Uorc.Core.RuntimeImage
public import Uorc.Uorc.Core.RuntimeResources
public import Uorc.Uorc.Core.RuntimeValue
public import Uorc.Uorc.Core.RuntimeWork
public import Uorc.Uorc.Wire.OwnedRead
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
set_option linter.constructorNameAsVariable false
namespace Uorc.Uorc.Product.OwnedCompare

public inductive Side where
  | left
  | right

public structure Span where
  image : Uorc.Uorc.Core.RuntimeValue.Handle
  offset : UInt64
  length : UInt64
  used : UInt64

public structure Reader where
  cursor : Uorc.Uorc.Wire.OwnedRead.Cursor
  span : Option (Span)
  ended : Bool

public inductive Failure where
  | read (_ : Side) (_ : Uorc.Uorc.Wire.OwnedRead.Failure)
  | byte (_ : Side) (_ : Uorc.Uorc.Core.RuntimeImage.ImageFailure)
  | counterExhausted
  | invalidSpan

public inductive Disposition where
  | working
  | equal
  | different (_ : UInt64)
  | lengthMismatch (_ : UInt64) (_ : UInt64)
  | failed (_ : Failure)
  | cancelled

public structure Load where
  reader : Reader
  failure : Option (Failure)

@[expose] public def freshReader (cursor : Uorc.Uorc.Wire.OwnedRead.Cursor) : Reader := ({ cursor := cursor, span := Option.none, ended := false } : Reader)

@[expose] public def load (arena : Uorc.Uorc.Core.Heap.Arena) (side : Side) (reader : Reader) : Load := (match Uorc.Uorc.Wire.OwnedRead.step (arena) ((reader).cursor) with | Uorc.Uorc.Wire.OwnedRead.Step.advanced next => ({ reader := ({ cursor := next, span := (reader).span, ended := (reader).ended } : Reader), failure := Option.none } : Load) | Uorc.Uorc.Wire.OwnedRead.Step.borrowedSpan image offset length next => (if (LexLeanRuntime.equal (length) ((0 : UInt64)) : Bool) then ({ reader := reader, failure := Option.some (Failure.invalidSpan) } : Load) else ({ reader := ({ cursor := next, span := Option.some (({ image := image, offset := offset, length := length, used := (0 : UInt64) } : Span)), ended := (reader).ended } : Reader), failure := Option.none } : Load)) | Uorc.Uorc.Wire.OwnedRead.Step.complete => ({ reader := ({ cursor := (reader).cursor, span := (reader).span, ended := true } : Reader), failure := Option.none } : Load) | Uorc.Uorc.Wire.OwnedRead.Step.failed failure => ({ reader := reader, failure := Option.some (Failure.read (side) (failure)) } : Load))

@[expose] public def advanceSpan (reader : Reader) (span : Span) (used : UInt64) : Reader := ({ cursor := (reader).cursor, span := (if (LexLeanRuntime.equal (used) ((span).length) : Bool) then Option.none else Option.some (({ image := (span).image, offset := (span).offset, length := (span).length, used := used } : Span))), ended := (reader).ended } : Reader)

@[expose] public def stepWork : UInt64 := Uorc.Uorc.Core.RuntimeWork.fee (Uorc.Uorc.Core.RuntimeWork.Operation.control)

public structure BytePlan where
  leftSpan : Span
  rightSpan : Span
  leftIndex : UInt64
  rightIndex : UInt64
  leftUsed : UInt64
  rightUsed : UInt64
  nextCompared : UInt64

public structure PendingByte where
  plan : BytePlan
  leftByte : UInt8

public structure State where
  left : Reader
  right : Reader
  compared : UInt64
  result : Disposition
  pending : Option (PendingByte)

public inductive Tick where
  | advanced (_ : State) (_ : Uorc.Uorc.Core.RuntimeResources.Usage)
  | refused (_ : Uorc.Uorc.Core.RuntimeResources.Error) (_ : State) (_ : Uorc.Uorc.Core.RuntimeResources.Usage)

@[expose] public def loaded (s : State) (side : Side) (bindingLoaded : Load) : State := (match (bindingLoaded).failure with | Option.some failure => ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.failed (failure), pending := (s).pending } : State) | Option.none => (match side with | Side.left => ({ left := (bindingLoaded).reader, right := (s).right, compared := (s).compared, result := (s).result, pending := (s).pending } : State) | Side.right => ({ left := (s).left, right := (bindingLoaded).reader, compared := (s).compared, result := (s).result, pending := (s).pending } : State)))

@[expose] public def cancel (s : State) : State := ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.cancelled, pending := Option.none } : State)

@[expose] public def isEqual (s : State) : Bool := (match (s).pending with | Option.none => (match (s).result with | Disposition.working => false | Disposition.equal => true | Disposition.different _ => false | Disposition.lengthMismatch _ _ => false | Disposition.failed _ => false | Disposition.cancelled => false) | Option.some _ => false)

@[expose] public def fromReaders (leftCursor : Uorc.Uorc.Wire.OwnedRead.Cursor) (rightCursor : Uorc.Uorc.Wire.OwnedRead.Cursor) : State := ({ left := freshReader (leftCursor), right := freshReader (rightCursor), compared := (0 : UInt64), result := (if (LexLeanRuntime.equal ((leftCursor).length) ((rightCursor).length) : Bool) then Disposition.working else Disposition.lengthMismatch ((leftCursor).length) ((rightCursor).length)), pending := Option.none } : State)

@[expose] public def begin (arena : Uorc.Uorc.Core.Heap.Arena) (left : Uorc.Uorc.Core.RuntimeValue.Handle) (right : Uorc.Uorc.Core.RuntimeValue.Handle) : Except (Failure) (State) := (match Uorc.Uorc.Wire.OwnedRead.begin (arena) (left) with | Except.error failure => Except.error (Failure.read (Side.left) (failure)) | Except.ok leftReader => (match Uorc.Uorc.Wire.OwnedRead.begin (arena) (right) with | Except.error failure => Except.error (Failure.read (Side.right) (failure)) | Except.ok rightReader => Except.ok (fromReaders (leftReader) (rightReader))))

@[expose] public def prepareByte (s : State) (leftSpan : Span) (rightSpan : Span) : Except (Failure) (BytePlan) := (match (LexLeanRuntime.checkedAdd ((leftSpan).offset) ((leftSpan).used) : Option (UInt64)) with | Option.none => Except.error (Failure.counterExhausted) | Option.some leftIndex => (match (LexLeanRuntime.checkedAdd ((rightSpan).offset) ((rightSpan).used) : Option (UInt64)) with | Option.none => Except.error (Failure.counterExhausted) | Option.some rightIndex => (match (LexLeanRuntime.checkedAdd ((leftSpan).used) ((1 : UInt64)) : Option (UInt64)) with | Option.none => Except.error (Failure.counterExhausted) | Option.some leftUsed => (match (LexLeanRuntime.checkedAdd ((rightSpan).used) ((1 : UInt64)) : Option (UInt64)) with | Option.none => Except.error (Failure.counterExhausted) | Option.some rightUsed => (match (LexLeanRuntime.checkedAdd ((s).compared) ((1 : UInt64)) : Option (UInt64)) with | Option.none => Except.error (Failure.counterExhausted) | Option.some compared => Except.ok (({ leftSpan := leftSpan, rightSpan := rightSpan, leftIndex := leftIndex, rightIndex := rightIndex, leftUsed := leftUsed, rightUsed := rightUsed, nextCompared := compared } : BytePlan)))))))

@[expose] public def completeByte (s : State) (observation : PendingByte) (rightByte : UInt8) : State := (if (LexLeanRuntime.equal ((observation).leftByte) (rightByte) : Bool) then ({ left := advanceSpan ((s).left) (((observation).plan).leftSpan) (((observation).plan).leftUsed), right := advanceSpan ((s).right) (((observation).plan).rightSpan) (((observation).plan).rightUsed), compared := ((observation).plan).nextCompared, result := (s).result, pending := Option.none } : State) else ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.different ((s).compared), pending := Option.none } : State))

@[expose] public def finishByte (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) (observation : PendingByte) : State := (match Uorc.Uorc.Core.RuntimeImage.readByte (arena) ((((observation).plan).rightSpan).image) (((observation).plan).rightIndex) with | Except.error failure => ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.failed (Failure.byte (Side.right) (failure)), pending := Option.none } : State) | Except.ok rightByte => completeByte (s) (observation) (rightByte))

@[expose] public def compareByte (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) (leftSpan : Span) (rightSpan : Span) : State := (match prepareByte (s) (leftSpan) (rightSpan) with | Except.error failure => ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.failed (failure), pending := Option.none } : State) | Except.ok plan => (match Uorc.Uorc.Core.RuntimeImage.readByte (arena) (((plan).leftSpan).image) ((plan).leftIndex) with | Except.error failure => ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.failed (Failure.byte (Side.left) (failure)), pending := Option.none } : State) | Except.ok leftByte => finishByte (arena) (s) (({ plan := plan, leftByte := leftByte } : PendingByte))))

@[expose] public def step (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) : State := (match (s).result with | Disposition.working => (match (s).pending with | Option.none => (match ((s).left).span with | Option.none => (if ((s).left).ended then (match ((s).right).span with | Option.some _ => ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.lengthMismatch ((((s).left).cursor).length) ((((s).right).cursor).length), pending := (s).pending } : State) | Option.none => (if ((s).right).ended then ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.equal, pending := (s).pending } : State) else loaded (s) (Side.right) (load (arena) (Side.right) ((s).right)))) else loaded (s) (Side.left) (load (arena) (Side.left) ((s).left))) | Option.some leftSpan => (match ((s).right).span with | Option.none => (if ((s).right).ended then ({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.lengthMismatch ((((s).left).cursor).length) ((((s).right).cursor).length), pending := (s).pending } : State) else loaded (s) (Side.right) (load (arena) (Side.right) ((s).right))) | Option.some rightSpan => compareByte (arena) (s) (leftSpan) (rightSpan))) | Option.some observation => finishByte (arena) (s) (observation)) | Disposition.equal => s | Disposition.different _ => s | Disposition.lengthMismatch _ _ => s | Disposition.failed _ => s | Disposition.cancelled => s)

public theorem cancelled_step_stays_cancelled (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) : ((step (arena) (cancel (s))).result = Disposition.cancelled) := by
  rfl

@[expose] public def paidReadRight (budget : Uorc.Uorc.Core.RuntimeResources.Budget) (usage : Uorc.Uorc.Core.RuntimeResources.Usage) (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) (observation : PendingByte) : Tick := (match Uorc.Uorc.Core.RuntimeResources.charge (budget) (usage) (({ work := Uorc.Uorc.Core.RuntimeImage.readByteCost (arena) ((((observation).plan).rightSpan).image) (((observation).plan).rightIndex), emittedBytes := (0 : UInt64), enteredFrames := (0 : UInt64), exitedFrames := (0 : UInt64) } : Uorc.Uorc.Core.RuntimeResources.Event)) with | Except.error resourceFailure => Tick.refused (resourceFailure) (s) (usage) | Except.ok rightUsage => (match Uorc.Uorc.Core.RuntimeImage.readByte (arena) ((((observation).plan).rightSpan).image) (((observation).plan).rightIndex) with | Except.error failure => Tick.advanced (({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.failed (Failure.byte (Side.right) (failure)), pending := Option.none } : State)) (rightUsage) | Except.ok rightByte => Tick.advanced (completeByte (s) (observation) (rightByte)) (rightUsage)))

@[expose] public def paidReadLeft (budget : Uorc.Uorc.Core.RuntimeResources.Budget) (usage : Uorc.Uorc.Core.RuntimeResources.Usage) (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) (plan : BytePlan) : Tick := (match Uorc.Uorc.Core.RuntimeResources.charge (budget) (usage) (({ work := Uorc.Uorc.Core.RuntimeImage.readByteCost (arena) (((plan).leftSpan).image) ((plan).leftIndex), emittedBytes := (0 : UInt64), enteredFrames := (0 : UInt64), exitedFrames := (0 : UInt64) } : Uorc.Uorc.Core.RuntimeResources.Event)) with | Except.error resourceFailure => Tick.refused (resourceFailure) (s) (usage) | Except.ok leftUsage => (match Uorc.Uorc.Core.RuntimeImage.readByte (arena) (((plan).leftSpan).image) ((plan).leftIndex) with | Except.error failure => Tick.advanced (({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.failed (Failure.byte (Side.left) (failure)), pending := Option.none } : State)) (leftUsage) | Except.ok leftByte => paidReadRight (budget) (leftUsage) (arena) (({ left := (s).left, right := (s).right, compared := (s).compared, result := (s).result, pending := Option.some (({ plan := plan, leftByte := leftByte } : PendingByte)) } : State)) (({ plan := plan, leftByte := leftByte } : PendingByte))))

@[expose] public def paidCompareByte (budget : Uorc.Uorc.Core.RuntimeResources.Budget) (usage : Uorc.Uorc.Core.RuntimeResources.Usage) (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) (leftSpan : Span) (rightSpan : Span) : Tick := (match prepareByte (s) (leftSpan) (rightSpan) with | Except.error failure => Tick.advanced (({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.failed (failure), pending := Option.none } : State)) (usage) | Except.ok plan => paidReadLeft (budget) (usage) (arena) (s) (plan))

@[expose] public def paidStep (budget : Uorc.Uorc.Core.RuntimeResources.Budget) (usage : Uorc.Uorc.Core.RuntimeResources.Usage) (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) : Tick := (match ((s).left).span with | Option.none => (if ((s).left).ended then (match ((s).right).span with | Option.some _ => Tick.advanced (({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.lengthMismatch ((((s).left).cursor).length) ((((s).right).cursor).length), pending := (s).pending } : State)) (usage) | Option.none => (if ((s).right).ended then Tick.advanced (({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.equal, pending := (s).pending } : State)) (usage) else Tick.advanced (loaded (s) (Side.right) (load (arena) (Side.right) ((s).right))) (usage))) else Tick.advanced (loaded (s) (Side.left) (load (arena) (Side.left) ((s).left))) (usage)) | Option.some leftSpan => (match ((s).right).span with | Option.none => (if ((s).right).ended then Tick.advanced (({ left := (s).left, right := (s).right, compared := (s).compared, result := Disposition.lengthMismatch ((((s).left).cursor).length) ((((s).right).cursor).length), pending := (s).pending } : State)) (usage) else Tick.advanced (loaded (s) (Side.right) (load (arena) (Side.right) ((s).right))) (usage)) | Option.some rightSpan => paidCompareByte (budget) (usage) (arena) (s) (leftSpan) (rightSpan)))

public theorem cancel_clears_pending_observation (s : State) : ((cancel (s)).pending = Option.none) := by
  rfl

public theorem pending_observation_never_equal (s : State) (observation : PendingByte) : (isEqual (({ left := (s).left, right := (s).right, compared := (s).compared, result := (s).result, pending := Option.some (observation) } : State)) = false) := by
  rfl

@[expose] public def traversalWork : UInt64 := Uorc.Uorc.Core.RuntimeWork.fee (Uorc.Uorc.Core.RuntimeWork.Operation.sequenceStep)

@[expose] public def tickWork (s : State) : UInt64 := (match ((s).left).span with | Option.none => (if ((s).left).ended then (match ((s).right).span with | Option.some _ => stepWork | Option.none => (if ((s).right).ended then stepWork else traversalWork)) else traversalWork) | Option.some _ => (match ((s).right).span with | Option.some _ => stepWork | Option.none => (if ((s).right).ended then stepWork else traversalWork)))

@[expose] public def tick (budget : Uorc.Uorc.Core.RuntimeResources.Budget) (usage : Uorc.Uorc.Core.RuntimeResources.Usage) (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) : Tick := (match (s).result with | Disposition.working => (match (s).pending with | Option.none => (match Uorc.Uorc.Core.RuntimeResources.charge (budget) (usage) (({ work := tickWork (s), emittedBytes := (0 : UInt64), enteredFrames := (0 : UInt64), exitedFrames := (0 : UInt64) } : Uorc.Uorc.Core.RuntimeResources.Event)) with | Except.error failure => Tick.refused (failure) (s) (usage) | Except.ok paidUsage => paidStep (budget) (paidUsage) (arena) (s)) | Option.some observation => paidReadRight (budget) (usage) (arena) (s) (observation)) | Disposition.equal => Tick.advanced (s) (usage) | Disposition.different _ => Tick.advanced (s) (usage) | Disposition.lengthMismatch _ _ => Tick.advanced (s) (usage) | Disposition.failed _ => Tick.advanced (s) (usage) | Disposition.cancelled => Tick.advanced (s) (usage))

public theorem cancelled_tick_preserves_usage (budget : Uorc.Uorc.Core.RuntimeResources.Budget) (usage : Uorc.Uorc.Core.RuntimeResources.Usage) (arena : Uorc.Uorc.Core.Heap.Arena) (s : State) : (tick (budget) (usage) (arena) (cancel (s)) = Tick.advanced (cancel (s)) (usage)) := by
  rfl

end Uorc.Uorc.Product.OwnedCompare
